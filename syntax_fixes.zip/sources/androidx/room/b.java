package androidx.room;

import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import androidx.room.a;

/* loaded from: classes.dex */
public interface b extends IInterface {

    /* renamed from: k, reason: collision with root package name */
    public static final String f2855k = "androidx$room$IMultiInstanceInvalidationService".replace('$', '.');

    public static abstract class a extends Binder implements b {

        /* renamed from: androidx.room.b$a$a, reason: collision with other inner class name */
        public static class C0062a implements b {

            /* renamed from: a, reason: collision with root package name */
            public IBinder f2856a;

            public C0062a(IBinder iBinder) {
                this.f2856a = iBinder;
            }

            @Override // androidx.room.b
            public void J0(int i10, String[] strArr) {
                Parcel obtain = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken(b.f2855k);
                    obtain.writeInt(i10);
                    obtain.writeStringArray(strArr);
                    this.f2856a.transact(3, obtain, null, 1);
                } finally {
                    obtain.recycle();
                }
            }

            @Override // android.os.IInterface
            public IBinder asBinder() {
                return this.f2856a;
            }

            @Override // androidx.room.b
            public int i1(androidx.room.a aVar, String str) {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken(b.f2855k);
                    obtain.writeStrongInterface(aVar);
                    obtain.writeString(str);
                    this.f2856a.transact(1, obtain, obtain2, 0);
                    obtain2.readException();
                    return obtain2.readInt();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            @Override // androidx.room.b
            public void n2(androidx.room.a aVar, int i10) {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken(b.f2855k);
                    obtain.writeStrongInterface(aVar);
                    obtain.writeInt(i10);
                    this.f2856a.transact(2, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }
        }

        public a() {
            attachInterface(this, b.f2855k);
        }

        public static b r2(IBinder iBinder) {
            if (iBinder == null) {
                return null;
            }
            IInterface queryLocalInterface = iBinder.queryLocalInterface(b.f2855k);
            return (queryLocalInterface == null || !(queryLocalInterface instanceof b)) ? new C0062a(iBinder) : (b) queryLocalInterface;
        }

        @Override // android.os.IInterface
        public IBinder asBinder() {
            return this;
        }

        @Override // android.os.Binder
        public boolean onTransact(int i10, Parcel parcel, Parcel parcel2, int i11) {
            String str = b.f2855k;
            if (i10 >= 1 && i10 <= 16777215) {
                parcel.enforceInterface(str);
            }
            if (i10 == 1598968902) {
                parcel2.writeString(str);
                return true;
            }
            if (i10 == 1) {
                int i12 = i1(a.AbstractBinderC0060a.r2(parcel.readStrongBinder()), parcel.readString());
                parcel2.writeNoException();
                parcel2.writeInt(i12);
            } else if (i10 == 2) {
                n2(a.AbstractBinderC0060a.r2(parcel.readStrongBinder()), parcel.readInt());
                parcel2.writeNoException();
            } else {
                if (i10 != 3) {
                    return super.onTransact(i10, parcel, parcel2, i11);
                }
                J0(parcel.readInt(), parcel.createStringArray());
            }
            return true;
        }
    }

    void J0(int i10, String[] strArr);

    int i1(androidx.room.a aVar, String str);

    void n2(androidx.room.a aVar, int i10);


    // --- восстановлено из DEX (androidx/room/b$a$a) ---
    public static class a implements androidx.room.b {
        android.os.IBinder a;
        public a(android.os.IBinder p0) { }
        public void J0(int p0, java.lang.String[] p1) { throw new UnsupportedOperationException("stub"); }
        public android.os.IBinder asBinder() { throw new UnsupportedOperationException("stub"); }
        public int i1(androidx.room.a p0, java.lang.String p1) { throw new UnsupportedOperationException("stub"); }
        public void n2(androidx.room.a p0, int p1) { throw new UnsupportedOperationException("stub"); }
    }
}
