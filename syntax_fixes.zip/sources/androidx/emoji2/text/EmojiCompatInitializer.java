package androidx.emoji2.text;

import android.content.Context;
import android.view.ProcessLifecycleInitializer;
import android.view.l;
import android.view.s;
import androidx.annotation.NonNull;

import androidx.emoji2.text.c;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.ThreadPoolExecutor;
import u2.o;

/* loaded from: classes.dex */
public class EmojiCompatInitializer implements l5.b<Boolean> {

    public class a implements android.view.f {

        /* renamed from: a, reason: collision with root package name */
        public final /* synthetic */ l f2209a;

        public a(l lVar) {
            this.f2209a = lVar;
        }

        @Override // android.view.f
        public void onResume(@NonNull s sVar) {
            EmojiCompatInitializer.this.d();
            this.f2209a.d(this);
        }
    }

    public static class b extends androidx.emoji2.text.c.AbstractC0044c {
        public b(Context context) {
            super(new c(context));
            b(1);
        }
    }

    public static class c implements c.h {

        /* renamed from: a, reason: collision with root package name */
        public final Context f2210a;

        public class a extends c.i {

            /* renamed from: a, reason: collision with root package name */
            public final /* synthetic */ c.i f2211a;
            public final /* synthetic */ ThreadPoolExecutor b;

            public a(c.i iVar, ThreadPoolExecutor threadPoolExecutor) {
                this.f2211a = iVar;
                this.b = threadPoolExecutor;
            }

            @Override // androidx.emoji2.text.c.i
            public void a(Throwable th2) {
                try {
                    this.f2211a.a(th2);
                } finally {
                    this.b.shutdown();
                }
            }

            @Override // androidx.emoji2.text.c.i
            public void b(@NonNull f fVar) {
                try {
                    this.f2211a.b(fVar);
                } finally {
                    this.b.shutdown();
                }
            }
        }

        public c(Context context) {
            this.f2210a = context.getApplicationContext();
        }

        @Override // androidx.emoji2.text.c.h
        public void a(@NonNull final c.i iVar) {
            final ThreadPoolExecutor b = a4.b.b("EmojiCompatInitializer");
            b.execute(new Runnable() { // from class: a4.c
                @Override // java.lang.Runnable
                public final void run() {
                    EmojiCompatInitializer.c.this.c(iVar, b);
                }
            });
        }

        public void c(@NonNull c.i iVar, @NonNull ThreadPoolExecutor threadPoolExecutor) {
            try {
                e a10 = androidx.emoji2.text.a.a(this.f2210a);
                if (a10 == null) {
                    throw new RuntimeException("EmojiCompat font provider not available on this device.");
                }
                a10.c(threadPoolExecutor);
                a10.a().a(new a(iVar, threadPoolExecutor));
            } catch (Throwable th2) {
                iVar.a(th2);
                threadPoolExecutor.shutdown();
            }
        }
    }

    public static class d implements Runnable {
        @Override // java.lang.Runnable
        public void run() {
            try {
                o.a("EmojiCompat.EmojiCompatInitializer.run");
                if (androidx.emoji2.text.c.i()) {
                    androidx.emoji2.text.c.c().l();
                }
            } finally {
                o.b();
            }
        }
    }

    @Override // l5.b
    @NonNull
    public List<Class<? extends l5.b<?>>> a() {
        return Collections.singletonList(ProcessLifecycleInitializer.class);
    }

    @Override // l5.b
    @NonNull
    /* renamed from: b, reason: merged with bridge method [inline-methods] */
    public Boolean create(@NonNull Context context) {
        androidx.emoji2.text.c.h(new b(context));
        c(context);
        return Boolean.TRUE;
    }

    public void c(@NonNull Context context) {
        l a10 = ((s) l5.a.e(context).f(ProcessLifecycleInitializer.class)).a();
        a10.a(new a(a10));
    }

    public void d() {
        a4.b.c().postDelayed(new d(), 500L);
    }


    // --- восстановлено из DEX (androidx/emoji2/text/EmojiCompatInitializer$c$a) ---
    public static class a extends androidx.emoji2.text.c.i {
        androidx.emoji2.text.c.i a;
        java.util.concurrent.ThreadPoolExecutor b;
        androidx.emoji2.text.EmojiCompatInitializer.c c;
        public a(androidx.emoji2.text.EmojiCompatInitializer.c p0, androidx.emoji2.text.c.i p1, java.util.concurrent.ThreadPoolExecutor p2) { }
        public void a(java.lang.Throwable p0) { throw new UnsupportedOperationException("stub"); }
        public void b(androidx.emoji2.text.f p0) { throw new UnsupportedOperationException("stub"); }
    }
}
