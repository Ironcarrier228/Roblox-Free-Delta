package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Parcel;
import android.os.Parcelable;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.ContextThemeWrapper;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.window.OnBackInvokedCallback;
import android.window.OnBackInvokedDispatcher;
import androidx.annotation.NonNull;
import androidx.appcompat.view.menu.e;
import androidx.appcompat.view.menu.i;
import androidx.appcompat.view.menu.l;
import androidx.appcompat.widget.ActionMenuView;

import androidx.core.view.k;
import androidx.core.view.o;
import androidx.core.view.o0;
import androidx.core.view.p;
import androidx.core.view.r;
import i.j;
import j.a;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import q.b1;
import q.c0;
import q.f1;
import q.g0;
import q.h1;
import q.q;
import q.u0;

/* loaded from: classes.dex */
public class Toolbar extends ViewGroup implements o {
    public ColorStateList A;
    public boolean B;
    public boolean C;
    public final ArrayList<View> D;
    public final ArrayList<View> E;
    public final int[] F;
    public final p G;
    public ArrayList<MenuItem> H;
    public final ActionMenuView.e I;
    public androidx.appcompat.widget.d J;
    public androidx.appcompat.widget.a K;
    public f L;
    public i.a M;
    public e.a N;
    public boolean O;
    public OnBackInvokedCallback P;
    public OnBackInvokedDispatcher Q;
    public boolean R;
    public final Runnable S;

    /* renamed from: a, reason: collision with root package name */
    public ActionMenuView f1017a;
    public TextView b;

    /* renamed from: c, reason: collision with root package name */
    public TextView f1018c;

    /* renamed from: d, reason: collision with root package name */
    public ImageButton f1019d;

    /* renamed from: e, reason: collision with root package name */
    public ImageView f1020e;

    /* renamed from: f, reason: collision with root package name */
    public Drawable f1021f;

    /* renamed from: g, reason: collision with root package name */
    public CharSequence f1022g;

    /* renamed from: h, reason: collision with root package name */
    public ImageButton f1023h;

    /* renamed from: i, reason: collision with root package name */
    public View f1024i;

    /* renamed from: j, reason: collision with root package name */
    public Context f1025j;

    /* renamed from: k, reason: collision with root package name */
    public int f1026k;

    /* renamed from: l, reason: collision with root package name */
    public int f1027l;

    /* renamed from: m, reason: collision with root package name */
    public int f1028m;

    /* renamed from: n, reason: collision with root package name */
    public int f1029n;

    /* renamed from: o, reason: collision with root package name */
    public int f1030o;

    /* renamed from: p, reason: collision with root package name */
    public int f1031p;

    /* renamed from: q, reason: collision with root package name */
    public int f1032q;

    /* renamed from: r, reason: collision with root package name */
    public int f1033r;

    /* renamed from: s, reason: collision with root package name */
    public int f1034s;

    /* renamed from: t, reason: collision with root package name */
    public u0 f1035t;

    /* renamed from: u, reason: collision with root package name */
    public int f1036u;

    /* renamed from: v, reason: collision with root package name */
    public int f1037v;

    /* renamed from: w, reason: collision with root package name */
    public int f1038w;

    /* renamed from: x, reason: collision with root package name */
    public CharSequence f1039x;

    /* renamed from: y, reason: collision with root package name */
    public CharSequence f1040y;

    /* renamed from: z, reason: collision with root package name */
    public ColorStateList f1041z;

    public class a implements ActionMenuView.e {
        public a() {
        }

        @Override // androidx.appcompat.widget.ActionMenuView.e
        public boolean onMenuItemClick(MenuItem menuItem) {
            if (Toolbar.this.G.d(menuItem)) {
                return true;
            }
            Toolbar.this.getClass();
            return false;
        }
    }

    public class b implements Runnable {
        public b() {
        }

        @Override // java.lang.Runnable
        public void run() {
            Toolbar.this.R();
        }
    }

    public class c implements e.a {
        public c() {
        }

        @Override // androidx.appcompat.view.menu.e.a
        public boolean a(@NonNull androidx.appcompat.view.menu.e eVar, @NonNull MenuItem menuItem) {
            e.a aVar = Toolbar.this.N;
            return aVar != null && aVar.a(eVar, menuItem);
        }

        @Override // androidx.appcompat.view.menu.e.a
        public void b(@NonNull androidx.appcompat.view.menu.e eVar) {
            if (!Toolbar.this.f1017a.H()) {
                Toolbar.this.G.e(eVar);
            }
            e.a aVar = Toolbar.this.N;
            if (aVar != null) {
                aVar.b(eVar);
            }
        }
    }

    public class d implements View.OnClickListener {
        public d() {
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            Toolbar.this.e();
        }
    }

    public static class e {
        public static OnBackInvokedDispatcher a(@NonNull View view) {
            return view.findOnBackInvokedDispatcher();
        }

        @NonNull
        public static OnBackInvokedCallback b(@NonNull final Runnable runnable) {
            Objects.requireNonNull(runnable);
            return new OnBackInvokedCallback() { // from class: q.e1
                public final void onBackInvoked() {
                    runnable.run();
                }
            };
        }

        public static void c(@NonNull Object obj, @NonNull Object obj2) {
            ((OnBackInvokedDispatcher) obj).registerOnBackInvokedCallback(1000000, (OnBackInvokedCallback) obj2);
        }

        public static void d(@NonNull Object obj, @NonNull Object obj2) {
            ((OnBackInvokedDispatcher) obj).unregisterOnBackInvokedCallback((OnBackInvokedCallback) obj2);
        }
    }

    public class f implements androidx.appcompat.view.menu.i {

        /* renamed from: a, reason: collision with root package name */
        public androidx.appcompat.view.menu.e f1046a;
        public androidx.appcompat.view.menu.g b;

        public f() {
        }

        @Override // androidx.appcompat.view.menu.i
        public void b(androidx.appcompat.view.menu.e eVar, boolean z10) {
        }

        @Override // androidx.appcompat.view.menu.i
        public boolean c(androidx.appcompat.view.menu.e eVar, androidx.appcompat.view.menu.g gVar) {
            Toolbar.this.g();
            ViewParent parent = Toolbar.this.f1023h.getParent();
            Toolbar toolbar = Toolbar.this;
            if (parent != toolbar) {
                if (parent instanceof ViewGroup) {
                    ((ViewGroup) parent).removeView(toolbar.f1023h);
                }
                Toolbar toolbar2 = Toolbar.this;
                toolbar2.addView(toolbar2.f1023h);
            }
            Toolbar.this.f1024i = gVar.getActionView();
            this.b = gVar;
            ViewParent parent2 = Toolbar.this.f1024i.getParent();
            Toolbar toolbar3 = Toolbar.this;
            if (parent2 != toolbar3) {
                if (parent2 instanceof ViewGroup) {
                    ((ViewGroup) parent2).removeView(toolbar3.f1024i);
                }
                g generateDefaultLayoutParams = Toolbar.this.generateDefaultLayoutParams();
                Toolbar toolbar4 = Toolbar.this;
                generateDefaultLayoutParams.f19837a = (toolbar4.f1029n & 112) | 8388611;
                generateDefaultLayoutParams.b = 2;
                toolbar4.f1024i.setLayoutParams(generateDefaultLayoutParams);
                Toolbar toolbar5 = Toolbar.this;
                toolbar5.addView(toolbar5.f1024i);
            }
            Toolbar.this.I();
            Toolbar.this.requestLayout();
            gVar.r(true);
            KeyEvent.Callback callback = Toolbar.this.f1024i;
            if (callback instanceof o.c) {
                ((o.c) callback).onActionViewExpanded();
            }
            Toolbar.this.S();
            return true;
        }

        @Override // androidx.appcompat.view.menu.i
        public boolean e(l lVar) {
            return false;
        }

        @Override // androidx.appcompat.view.menu.i
        public void f(boolean z10) {
            if (this.b != null) {
                androidx.appcompat.view.menu.e eVar = this.f1046a;
                if (eVar != null) {
                    int size = eVar.size();
                    for (int i10 = 0; i10 < size; i10++) {
                        if (this.f1046a.getItem(i10) == this.b) {
                            return;
                        }
                    }
                }
                h(this.f1046a, this.b);
            }
        }

        @Override // androidx.appcompat.view.menu.i
        public boolean g() {
            return false;
        }

        @Override // androidx.appcompat.view.menu.i
        public boolean h(androidx.appcompat.view.menu.e eVar, androidx.appcompat.view.menu.g gVar) {
            KeyEvent.Callback callback = Toolbar.this.f1024i;
            if (callback instanceof o.c) {
                ((o.c) callback).onActionViewCollapsed();
            }
            Toolbar toolbar = Toolbar.this;
            toolbar.removeView(toolbar.f1024i);
            Toolbar toolbar2 = Toolbar.this;
            toolbar2.removeView(toolbar2.f1023h);
            Toolbar toolbar3 = Toolbar.this;
            toolbar3.f1024i = null;
            toolbar3.a();
            this.b = null;
            Toolbar.this.requestLayout();
            gVar.r(false);
            Toolbar.this.S();
            return true;
        }

        @Override // androidx.appcompat.view.menu.i
        public void i(Context context, androidx.appcompat.view.menu.e eVar) {
            androidx.appcompat.view.menu.g gVar;
            androidx.appcompat.view.menu.e eVar2 = this.f1046a;
            if (eVar2 != null && (gVar = this.b) != null) {
                eVar2.f(gVar);
            }
            this.f1046a = eVar;
        }
    }

    public interface h {
    }

    public Toolbar(@NonNull Context context, AttributeSet attributeSet) {
        this(context, attributeSet, i.a.Q);
    }

    private ArrayList<MenuItem> getCurrentMenuItems() {
        ArrayList<MenuItem> arrayList = new ArrayList<>();
        Menu menu = getMenu();
        for (int i10 = 0; i10 < menu.size(); i10++) {
            arrayList.add(menu.getItem(i10));
        }
        return arrayList;
    }

    private MenuInflater getMenuInflater() {
        return new o.g(getContext());
    }

    public boolean A() {
        ActionMenuView actionMenuView = this.f1017a;
        return actionMenuView != null && actionMenuView.G();
    }

    public boolean B() {
        ActionMenuView actionMenuView = this.f1017a;
        return actionMenuView != null && actionMenuView.H();
    }

    public final int C(View view, int i10, int[] iArr, int i11) {
        g gVar = (g) view.getLayoutParams();
        int i12 = ((ViewGroup.MarginLayoutParams) gVar).leftMargin - iArr[0];
        int max = i10 + Math.max(0, i12);
        iArr[0] = Math.max(0, -i12);
        int q8 = q(view, i11);
        int measuredWidth = view.getMeasuredWidth();
        view.layout(max, q8, max + measuredWidth, view.getMeasuredHeight() + q8);
        return max + measuredWidth + ((ViewGroup.MarginLayoutParams) gVar).rightMargin;
    }

    public final int D(View view, int i10, int[] iArr, int i11) {
        g gVar = (g) view.getLayoutParams();
        int i12 = ((ViewGroup.MarginLayoutParams) gVar).rightMargin - iArr[1];
        int max = i10 - Math.max(0, i12);
        iArr[1] = Math.max(0, -i12);
        int q8 = q(view, i11);
        int measuredWidth = view.getMeasuredWidth();
        view.layout(max - measuredWidth, q8, max, view.getMeasuredHeight() + q8);
        return max - (measuredWidth + ((ViewGroup.MarginLayoutParams) gVar).leftMargin);
    }

    public final int E(View view, int i10, int i11, int i12, int i13, int[] iArr) {
        ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) view.getLayoutParams();
        int i14 = marginLayoutParams.leftMargin - iArr[0];
        int i15 = marginLayoutParams.rightMargin - iArr[1];
        int max = Math.max(0, i14) + Math.max(0, i15);
        iArr[0] = Math.max(0, -i14);
        iArr[1] = Math.max(0, -i15);
        view.measure(ViewGroup.getChildMeasureSpec(i10, getPaddingLeft() + getPaddingRight() + max + i11, marginLayoutParams.width), ViewGroup.getChildMeasureSpec(i12, getPaddingTop() + getPaddingBottom() + marginLayoutParams.topMargin + marginLayoutParams.bottomMargin + i13, marginLayoutParams.height));
        return view.getMeasuredWidth() + max;
    }

    public final void F(View view, int i10, int i11, int i12, int i13, int i14) {
        ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) view.getLayoutParams();
        int childMeasureSpec = ViewGroup.getChildMeasureSpec(i10, getPaddingLeft() + getPaddingRight() + marginLayoutParams.leftMargin + marginLayoutParams.rightMargin + i11, marginLayoutParams.width);
        int childMeasureSpec2 = ViewGroup.getChildMeasureSpec(i12, getPaddingTop() + getPaddingBottom() + marginLayoutParams.topMargin + marginLayoutParams.bottomMargin + i13, marginLayoutParams.height);
        int mode = View.MeasureSpec.getMode(childMeasureSpec2);
        if (mode != 1073741824 && i14 >= 0) {
            if (mode != 0) {
                i14 = Math.min(View.MeasureSpec.getSize(childMeasureSpec2), i14);
            }
            childMeasureSpec2 = View.MeasureSpec.makeMeasureSpec(i14, 1073741824);
        }
        view.measure(childMeasureSpec, childMeasureSpec2);
    }

    public final void G() {
        Menu menu = getMenu();
        ArrayList<MenuItem> currentMenuItems = getCurrentMenuItems();
        this.G.b(menu, getMenuInflater());
        ArrayList<MenuItem> currentMenuItems2 = getCurrentMenuItems();
        currentMenuItems2.removeAll(currentMenuItems);
        this.H = currentMenuItems2;
    }

    public final void H() {
        removeCallbacks(this.S);
        post(this.S);
    }

    public void I() {
        for (int childCount = getChildCount() - 1; childCount >= 0; childCount--) {
            View childAt = getChildAt(childCount);
            if (((g) childAt.getLayoutParams()).b != 2 && childAt != this.f1017a) {
                removeViewAt(childCount);
                this.E.add(childAt);
            }
        }
    }

    public void J(int i10, int i11) {
        h();
        this.f1035t.e(i10, i11);
    }

    public void K(int i10, int i11) {
        h();
        this.f1035t.g(i10, i11);
    }

    public void L(androidx.appcompat.view.menu.e eVar, androidx.appcompat.widget.a aVar) {
        if (eVar == null && this.f1017a == null) {
            return;
        }
        k();
        androidx.appcompat.view.menu.e L = this.f1017a.L();
        if (L == eVar) {
            return;
        }
        if (L != null) {
            L.P(this.K);
            L.P(this.L);
        }
        if (this.L == null) {
            this.L = new f();
        }
        aVar.H(true);
        if (eVar != null) {
            eVar.c(aVar, this.f1025j);
            eVar.c(this.L, this.f1025j);
        } else {
            aVar.i(this.f1025j, null);
            this.L.i(this.f1025j, null);
            aVar.f(true);
            this.L.f(true);
        }
        this.f1017a.setPopupTheme(this.f1026k);
        this.f1017a.setPresenter(aVar);
        this.K = aVar;
        S();
    }

    public void M(Context context, int i10) {
        this.f1028m = i10;
        TextView textView = this.f1018c;
        if (textView != null) {
            textView.setTextAppearance(context, i10);
        }
    }

    public void N(Context context, int i10) {
        this.f1027l = i10;
        TextView textView = this.b;
        if (textView != null) {
            textView.setTextAppearance(context, i10);
        }
    }

    public final boolean O() {
        if (!this.O) {
            return false;
        }
        int childCount = getChildCount();
        for (int i10 = 0; i10 < childCount; i10++) {
            View childAt = getChildAt(i10);
            if (P(childAt) && childAt.getMeasuredWidth() > 0 && childAt.getMeasuredHeight() > 0) {
                return false;
            }
        }
        return true;
    }

    public final boolean P(View view) {
        return (view == null || view.getParent() != this || view.getVisibility() == 8) ? false : true;
    }

    @Override // androidx.core.view.o
    public void Q(@NonNull r rVar) {
        this.G.f(rVar);
    }

    public boolean R() {
        ActionMenuView actionMenuView = this.f1017a;
        return actionMenuView != null && actionMenuView.N();
    }

    public void S() {
        OnBackInvokedDispatcher onBackInvokedDispatcher;
        if (Build.VERSION.SDK_INT >= 33) {
            OnBackInvokedDispatcher a10 = e.a(this);
            boolean z10 = v() && a10 != null && isAttachedToWindow() && this.R;
            if (z10 && this.Q == null) {
                if (this.P == null) {
                    this.P = e.b(new Runnable() { // from class: q.c1
                        @Override // java.lang.Runnable
                        public final void run() {
                            Toolbar.this.e();
                        }
                    });
                }
                e.c(a10, this.P);
                this.Q = a10;
                return;
            }
            if (z10 || (onBackInvokedDispatcher = this.Q) == null) {
                return;
            }
            e.d(onBackInvokedDispatcher, this.P);
            this.Q = null;
        }
    }

    public void a() {
        for (int size = this.E.size() - 1; size >= 0; size--) {
            addView(this.E.get(size));
        }
        this.E.clear();
    }

    public final void b(List<View> list, int i10) {
        boolean z10 = getLayoutDirection() == 1;
        int childCount = getChildCount();
        int b10 = k.b(i10, getLayoutDirection());
        list.clear();
        if (!z10) {
            for (int i11 = 0; i11 < childCount; i11++) {
                View childAt = getChildAt(i11);
                g gVar = (g) childAt.getLayoutParams();
                if (gVar.b == 0 && P(childAt) && p(gVar.f19837a) == b10) {
                    list.add(childAt);
                }
            }
            return;
        }
        for (int i12 = childCount - 1; i12 >= 0; i12--) {
            View childAt2 = getChildAt(i12);
            g gVar2 = (g) childAt2.getLayoutParams();
            if (gVar2.b == 0 && P(childAt2) && p(gVar2.f19837a) == b10) {
                list.add(childAt2);
            }
        }
    }

    public final void c(View view, boolean z10) {
        ViewGroup.LayoutParams layoutParams = view.getLayoutParams();
        g generateDefaultLayoutParams = layoutParams == null ? generateDefaultLayoutParams() : !checkLayoutParams(layoutParams) ? generateLayoutParams(layoutParams) : (g) layoutParams;
        generateDefaultLayoutParams.b = 1;
        if (!z10 || this.f1024i == null) {
            addView(view, generateDefaultLayoutParams);
        } else {
            view.setLayoutParams(generateDefaultLayoutParams);
            this.E.add(view);
        }
    }

    @Override // android.view.ViewGroup
    public boolean checkLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return super.checkLayoutParams(layoutParams) && (layoutParams instanceof g);
    }

    public boolean d() {
        ActionMenuView actionMenuView;
        return getVisibility() == 0 && (actionMenuView = this.f1017a) != null && actionMenuView.I();
    }

    public void e() {
        f fVar = this.L;
        androidx.appcompat.view.menu.g gVar = fVar == null ? null : fVar.b;
        if (gVar != null) {
            gVar.collapseActionView();
        }
    }

    public void f() {
        ActionMenuView actionMenuView = this.f1017a;
        if (actionMenuView != null) {
            actionMenuView.z();
        }
    }

    public void g() {
        if (this.f1023h == null) {
            AppCompatImageButton appCompatImageButton = new AppCompatImageButton(getContext(), null, i.a.P);
            this.f1023h = appCompatImageButton;
            appCompatImageButton.setImageDrawable(this.f1021f);
            this.f1023h.setContentDescription(this.f1022g);
            g generateDefaultLayoutParams = generateDefaultLayoutParams();
            generateDefaultLayoutParams.f19837a = (this.f1029n & 112) | 8388611;
            generateDefaultLayoutParams.b = 2;
            this.f1023h.setLayoutParams(generateDefaultLayoutParams);
            this.f1023h.setOnClickListener(new d());
        }
    }

    public CharSequence getCollapseContentDescription() {
        ImageButton imageButton = this.f1023h;
        if (imageButton != null) {
            return imageButton.getContentDescription();
        }
        return null;
    }

    public Drawable getCollapseIcon() {
        ImageButton imageButton = this.f1023h;
        if (imageButton != null) {
            return imageButton.getDrawable();
        }
        return null;
    }

    public int getContentInsetEnd() {
        u0 u0Var = this.f1035t;
        if (u0Var != null) {
            return u0Var.a();
        }
        return 0;
    }

    public int getContentInsetEndWithActions() {
        int i10 = this.f1037v;
        return i10 != Integer.MIN_VALUE ? i10 : getContentInsetEnd();
    }

    public int getContentInsetLeft() {
        u0 u0Var = this.f1035t;
        if (u0Var != null) {
            return u0Var.b();
        }
        return 0;
    }

    public int getContentInsetRight() {
        u0 u0Var = this.f1035t;
        if (u0Var != null) {
            return u0Var.c();
        }
        return 0;
    }

    public int getContentInsetStart() {
        u0 u0Var = this.f1035t;
        if (u0Var != null) {
            return u0Var.d();
        }
        return 0;
    }

    public int getContentInsetStartWithNavigation() {
        int i10 = this.f1036u;
        return i10 != Integer.MIN_VALUE ? i10 : getContentInsetStart();
    }

    public int getCurrentContentInsetEnd() {
        androidx.appcompat.view.menu.e L;
        ActionMenuView actionMenuView = this.f1017a;
        return (actionMenuView == null || (L = actionMenuView.L()) == null || !L.hasVisibleItems()) ? getContentInsetEnd() : Math.max(getContentInsetEnd(), Math.max(this.f1037v, 0));
    }

    public int getCurrentContentInsetLeft() {
        return getLayoutDirection() == 1 ? getCurrentContentInsetEnd() : getCurrentContentInsetStart();
    }

    public int getCurrentContentInsetRight() {
        return getLayoutDirection() == 1 ? getCurrentContentInsetStart() : getCurrentContentInsetEnd();
    }

    public int getCurrentContentInsetStart() {
        return getNavigationIcon() != null ? Math.max(getContentInsetStart(), Math.max(this.f1036u, 0)) : getContentInsetStart();
    }

    public Drawable getLogo() {
        ImageView imageView = this.f1020e;
        if (imageView != null) {
            return imageView.getDrawable();
        }
        return null;
    }

    public CharSequence getLogoDescription() {
        ImageView imageView = this.f1020e;
        if (imageView != null) {
            return imageView.getContentDescription();
        }
        return null;
    }

    public Menu getMenu() {
        j();
        return this.f1017a.getMenu();
    }

    public View getNavButtonView() {
        return this.f1019d;
    }

    public CharSequence getNavigationContentDescription() {
        ImageButton imageButton = this.f1019d;
        if (imageButton != null) {
            return imageButton.getContentDescription();
        }
        return null;
    }

    public Drawable getNavigationIcon() {
        ImageButton imageButton = this.f1019d;
        if (imageButton != null) {
            return imageButton.getDrawable();
        }
        return null;
    }

    public androidx.appcompat.widget.a getOuterActionMenuPresenter() {
        return this.K;
    }

    public Drawable getOverflowIcon() {
        j();
        return this.f1017a.getOverflowIcon();
    }

    public Context getPopupContext() {
        return this.f1025j;
    }

    public int getPopupTheme() {
        return this.f1026k;
    }

    public CharSequence getSubtitle() {
        return this.f1040y;
    }

    public final TextView getSubtitleTextView() {
        return this.f1018c;
    }

    public CharSequence getTitle() {
        return this.f1039x;
    }

    public int getTitleMarginBottom() {
        return this.f1034s;
    }

    public int getTitleMarginEnd() {
        return this.f1032q;
    }

    public int getTitleMarginStart() {
        return this.f1031p;
    }

    public int getTitleMarginTop() {
        return this.f1033r;
    }

    public final TextView getTitleTextView() {
        return this.b;
    }

    public g0 getWrapper() {
        if (this.J == null) {
            this.J = new androidx.appcompat.widget.d(this, true);
        }
        return this.J;
    }

    public final void h() {
        if (this.f1035t == null) {
            this.f1035t = new u0();
        }
    }

    public final void i() {
        if (this.f1020e == null) {
            this.f1020e = new q(getContext());
        }
    }

    public final void j() {
        k();
        if (this.f1017a.L() == null) {
            androidx.appcompat.view.menu.e eVar = (androidx.appcompat.view.menu.e) this.f1017a.getMenu();
            if (this.L == null) {
                this.L = new f();
            }
            this.f1017a.setExpandedActionViewsExclusive(true);
            eVar.c(this.L, this.f1025j);
            S();
        }
    }

    public final void k() {
        if (this.f1017a == null) {
            ActionMenuView actionMenuView = new ActionMenuView(getContext());
            this.f1017a = actionMenuView;
            actionMenuView.setPopupTheme(this.f1026k);
            this.f1017a.setOnMenuItemClickListener(this.I);
            this.f1017a.M(this.M, new c());
            g generateDefaultLayoutParams = generateDefaultLayoutParams();
            generateDefaultLayoutParams.f19837a = (this.f1029n & 112) | 8388613;
            this.f1017a.setLayoutParams(generateDefaultLayoutParams);
            c(this.f1017a, false);
        }
    }

    public final void l() {
        if (this.f1019d == null) {
            this.f1019d = new AppCompatImageButton(getContext(), null, i.a.P);
            g generateDefaultLayoutParams = generateDefaultLayoutParams();
            generateDefaultLayoutParams.f19837a = (this.f1029n & 112) | 8388611;
            this.f1019d.setLayoutParams(generateDefaultLayoutParams);
        }
    }

    @Override // androidx.core.view.o
    public void l0(@NonNull r rVar) {
        this.G.a(rVar);
    }

    @Override // android.view.ViewGroup
    /* renamed from: m, reason: merged with bridge method [inline-methods] */
    public g generateDefaultLayoutParams() {
        return new g(-2, -2);
    }

    @Override // android.view.ViewGroup
    /* renamed from: n, reason: merged with bridge method [inline-methods] */
    public g generateLayoutParams(AttributeSet attributeSet) {
        return new g(getContext(), attributeSet);
    }

    @Override // android.view.ViewGroup
    /* renamed from: o, reason: merged with bridge method [inline-methods] */
    public g generateLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return layoutParams instanceof g ? new g((g) layoutParams) : layoutParams instanceof a.C0372a ? new g((a.C0372a) layoutParams) : layoutParams instanceof ViewGroup.MarginLayoutParams ? new g((ViewGroup.MarginLayoutParams) layoutParams) : new g(layoutParams);
    }

    @Override // android.view.ViewGroup, android.view.View
    public void onAttachedToWindow() {
        super.onAttachedToWindow();
        S();
    }

    @Override // android.view.ViewGroup, android.view.View
    public void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        removeCallbacks(this.S);
        S();
    }

    @Override // android.view.View
    public boolean onHoverEvent(MotionEvent motionEvent) {
        int actionMasked = motionEvent.getActionMasked();
        if (actionMasked == 9) {
            this.C = false;
        }
        if (!this.C) {
            boolean onHoverEvent = super.onHoverEvent(motionEvent);
            if (actionMasked == 9 && !onHoverEvent) {
                this.C = true;
            }
        }
        if (actionMasked == 10 || actionMasked == 3) {
            this.C = false;
        }
        return true;
    }

    /* JADX WARN: Removed duplicated region for block: B:107:0x01a2  */
    /* JADX WARN: Removed duplicated region for block: B:112:0x0133  */
    /* JADX WARN: Removed duplicated region for block: B:113:0x012c  */
    /* JADX WARN: Removed duplicated region for block: B:114:0x011d  */
    /* JADX WARN: Removed duplicated region for block: B:115:0x00ff  */
    /* JADX WARN: Removed duplicated region for block: B:13:0x0060  */
    /* JADX WARN: Removed duplicated region for block: B:18:0x0077  */
    /* JADX WARN: Removed duplicated region for block: B:23:0x00b4  */
    /* JADX WARN: Removed duplicated region for block: B:28:0x00cb  */
    /* JADX WARN: Removed duplicated region for block: B:33:0x00e8  */
    /* JADX WARN: Removed duplicated region for block: B:35:0x0104  */
    /* JADX WARN: Removed duplicated region for block: B:41:0x0297 A[LOOP:0: B:40:0x0295->B:41:0x0297, LOOP_END] */
    /* JADX WARN: Removed duplicated region for block: B:45:0x02b5 A[LOOP:1: B:44:0x02b3->B:45:0x02b5, LOOP_END] */
    /* JADX WARN: Removed duplicated region for block: B:49:0x02dd  */
    /* JADX WARN: Removed duplicated region for block: B:54:0x02ec A[LOOP:2: B:53:0x02ea->B:54:0x02ec, LOOP_END] */
    /* JADX WARN: Removed duplicated region for block: B:60:0x0129  */
    /* JADX WARN: Removed duplicated region for block: B:62:0x0130  */
    /* JADX WARN: Removed duplicated region for block: B:70:0x0166  */
    /* JADX WARN: Removed duplicated region for block: B:77:0x01af  */
    /* JADX WARN: Removed duplicated region for block: B:90:0x021e  */
    @Override // android.view.ViewGroup, android.view.View
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public void onLayout(boolean r20, int r21, int r22, int r23, int r24) {
        /*
            Method dump skipped, instructions count: 769
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.widget.Toolbar.onLayout(boolean, int, int, int, int):void");
    }

    @Override // android.view.View
    public void onMeasure(int i10, int i11) {
        int i12;
        int i13;
        int i14;
        int i15;
        int[] iArr;
        int i16;
        int i17;
        int i18;
        int[] iArr2 = this.F;
        boolean b10 = h1.b(this);
        int i19 = !b10 ? 1 : 0;
        if (P(this.f1019d)) {
            F(this.f1019d, i10, 0, i11, 0, this.f1030o);
            i12 = this.f1019d.getMeasuredWidth() + s(this.f1019d);
            i13 = Math.max(0, this.f1019d.getMeasuredHeight() + t(this.f1019d));
            i14 = View.combineMeasuredStates(0, this.f1019d.getMeasuredState());
        } else {
            i12 = 0;
            i13 = 0;
            i14 = 0;
        }
        if (P(this.f1023h)) {
            F(this.f1023h, i10, 0, i11, 0, this.f1030o);
            i12 = this.f1023h.getMeasuredWidth() + s(this.f1023h);
            i13 = Math.max(i13, this.f1023h.getMeasuredHeight() + t(this.f1023h));
            i14 = View.combineMeasuredStates(i14, this.f1023h.getMeasuredState());
        }
        int currentContentInsetStart = getCurrentContentInsetStart();
        int max = Math.max(currentContentInsetStart, i12);
        iArr2[b10 ? 1 : 0] = Math.max(0, currentContentInsetStart - i12);
        if (P(this.f1017a)) {
            F(this.f1017a, i10, max, i11, 0, this.f1030o);
            i15 = this.f1017a.getMeasuredWidth() + s(this.f1017a);
            i13 = Math.max(i13, this.f1017a.getMeasuredHeight() + t(this.f1017a));
            i14 = View.combineMeasuredStates(i14, this.f1017a.getMeasuredState());
        } else {
            i15 = 0;
        }
        int currentContentInsetEnd = getCurrentContentInsetEnd();
        int max2 = max + Math.max(currentContentInsetEnd, i15);
        iArr2[i19] = Math.max(0, currentContentInsetEnd - i15);
        if (P(this.f1024i)) {
            iArr = iArr2;
            max2 += E(this.f1024i, i10, max2, i11, 0, iArr);
            i13 = Math.max(i13, this.f1024i.getMeasuredHeight() + t(this.f1024i));
            i14 = View.combineMeasuredStates(i14, this.f1024i.getMeasuredState());
        } else {
            iArr = iArr2;
        }
        if (P(this.f1020e)) {
            max2 += E(this.f1020e, i10, max2, i11, 0, iArr);
            i13 = Math.max(i13, this.f1020e.getMeasuredHeight() + t(this.f1020e));
            i14 = View.combineMeasuredStates(i14, this.f1020e.getMeasuredState());
        }
        int childCount = getChildCount();
        for (int i20 = 0; i20 < childCount; i20++) {
            View childAt = getChildAt(i20);
            if (((g) childAt.getLayoutParams()).b == 0 && P(childAt)) {
                max2 += E(childAt, i10, max2, i11, 0, iArr);
                int max3 = Math.max(i13, childAt.getMeasuredHeight() + t(childAt));
                i14 = View.combineMeasuredStates(i14, childAt.getMeasuredState());
                i13 = max3;
            } else {
                max2 = max2;
            }
        }
        int i21 = max2;
        int i22 = this.f1033r + this.f1034s;
        int i23 = this.f1031p + this.f1032q;
        if (P(this.b)) {
            E(this.b, i10, i21 + i23, i11, i22, iArr);
            int measuredWidth = this.b.getMeasuredWidth() + s(this.b);
            int measuredHeight = this.b.getMeasuredHeight() + t(this.b);
            i16 = measuredWidth;
            i17 = View.combineMeasuredStates(i14, this.b.getMeasuredState());
            i18 = measuredHeight;
        } else {
            i16 = 0;
            i17 = i14;
            i18 = 0;
        }
        if (P(this.f1018c)) {
            i16 = Math.max(i16, E(this.f1018c, i10, i21 + i23, i11, i22 + i18, iArr));
            i18 += this.f1018c.getMeasuredHeight() + t(this.f1018c);
            i17 = View.combineMeasuredStates(i17, this.f1018c.getMeasuredState());
        }
        setMeasuredDimension(View.resolveSizeAndState(Math.max(i21 + i16 + getPaddingLeft() + getPaddingRight(), getSuggestedMinimumWidth()), i10, (-16777216) & i17), O() ? 0 : View.resolveSizeAndState(Math.max(Math.max(i13, i18) + getPaddingTop() + getPaddingBottom(), getSuggestedMinimumHeight()), i11, i17 << 16));
    }

    @Override // android.view.View
    public void onRestoreInstanceState(Parcelable parcelable) {
        MenuItem findItem;
        if (!(parcelable instanceof i)) {
            super.onRestoreInstanceState(parcelable);
            return;
        }
        i iVar = (i) parcelable;
        super.onRestoreInstanceState(iVar.a());
        ActionMenuView actionMenuView = this.f1017a;
        androidx.appcompat.view.menu.e L = actionMenuView != null ? actionMenuView.L() : null;
        int i10 = iVar.f1048c;
        if (i10 != 0 && this.L != null && L != null && (findItem = L.findItem(i10)) != null) {
            findItem.expandActionView();
        }
        if (iVar.f1049d) {
            H();
        }
    }

    @Override // android.view.View
    public void onRtlPropertiesChanged(int i10) {
        super.onRtlPropertiesChanged(i10);
        h();
        this.f1035t.f(i10 == 1);
    }

    @Override // android.view.View
    public Parcelable onSaveInstanceState() {
        androidx.appcompat.view.menu.g gVar;
        i iVar = new i(super.onSaveInstanceState());
        f fVar = this.L;
        if (fVar != null && (gVar = fVar.b) != null) {
            iVar.f1048c = gVar.getItemId();
        }
        iVar.f1049d = B();
        return iVar;
    }

    @Override // android.view.View
    public boolean onTouchEvent(MotionEvent motionEvent) {
        int actionMasked = motionEvent.getActionMasked();
        if (actionMasked == 0) {
            this.B = false;
        }
        if (!this.B) {
            boolean onTouchEvent = super.onTouchEvent(motionEvent);
            if (actionMasked == 0 && !onTouchEvent) {
                this.B = true;
            }
        }
        if (actionMasked == 1 || actionMasked == 3) {
            this.B = false;
        }
        return true;
    }

    public final int p(int i10) {
        int layoutDirection = getLayoutDirection();
        int b10 = k.b(i10, layoutDirection) & 7;
        return (b10 == 1 || b10 == 3 || b10 == 5) ? b10 : layoutDirection == 1 ? 5 : 3;
    }

    public final int q(View view, int i10) {
        g gVar = (g) view.getLayoutParams();
        int measuredHeight = view.getMeasuredHeight();
        int i11 = i10 > 0 ? (measuredHeight - i10) / 2 : 0;
        int r10 = r(gVar.f19837a);
        if (r10 == 48) {
            return getPaddingTop() - i11;
        }
        if (r10 == 80) {
            return (((getHeight() - getPaddingBottom()) - measuredHeight) - ((ViewGroup.MarginLayoutParams) gVar).bottomMargin) - i11;
        }
        int paddingTop = getPaddingTop();
        int paddingBottom = getPaddingBottom();
        int height = getHeight();
        int i12 = (((height - paddingTop) - paddingBottom) - measuredHeight) / 2;
        int i13 = ((ViewGroup.MarginLayoutParams) gVar).topMargin;
        if (i12 < i13) {
            i12 = i13;
        } else {
            int i14 = (((height - paddingBottom) - measuredHeight) - i12) - paddingTop;
            int i15 = ((ViewGroup.MarginLayoutParams) gVar).bottomMargin;
            if (i14 < i15) {
                i12 = Math.max(0, i12 - (i15 - i14));
            }
        }
        return paddingTop + i12;
    }

    public final int r(int i10) {
        int i11 = i10 & 112;
        return (i11 == 16 || i11 == 48 || i11 == 80) ? i11 : this.f1038w & 112;
    }

    public final int s(View view) {
        ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) view.getLayoutParams();
        return marginLayoutParams.getMarginStart() + marginLayoutParams.getMarginEnd();
    }

    public void setBackInvokedCallbackEnabled(boolean z10) {
        if (this.R != z10) {
            this.R = z10;
            S();
        }
    }

    public void setCollapseContentDescription(int i10) {
        setCollapseContentDescription(i10 != 0 ? getContext().getText(i10) : null);
    }

    public void setCollapseIcon(int i10) {
        setCollapseIcon(k.a.b(getContext(), i10));
    }

    public void setCollapsible(boolean z10) {
        this.O = z10;
        requestLayout();
    }

    public void setContentInsetEndWithActions(int i10) {
        if (i10 < 0) {
            i10 = Integer.MIN_VALUE;
        }
        if (i10 != this.f1037v) {
            this.f1037v = i10;
            if (getNavigationIcon() != null) {
                requestLayout();
            }
        }
    }

    public void setContentInsetStartWithNavigation(int i10) {
        if (i10 < 0) {
            i10 = Integer.MIN_VALUE;
        }
        if (i10 != this.f1036u) {
            this.f1036u = i10;
            if (getNavigationIcon() != null) {
                requestLayout();
            }
        }
    }

    public void setLogo(int i10) {
        setLogo(k.a.b(getContext(), i10));
    }

    public void setLogoDescription(int i10) {
        setLogoDescription(getContext().getText(i10));
    }

    public void setNavigationContentDescription(int i10) {
        setNavigationContentDescription(i10 != 0 ? getContext().getText(i10) : null);
    }

    public void setNavigationIcon(int i10) {
        setNavigationIcon(k.a.b(getContext(), i10));
    }

    public void setNavigationOnClickListener(View.OnClickListener onClickListener) {
        l();
        this.f1019d.setOnClickListener(onClickListener);
    }

    public void setOnMenuItemClickListener(h hVar) {
    }

    public void setOverflowIcon(Drawable drawable) {
        j();
        this.f1017a.setOverflowIcon(drawable);
    }

    public void setPopupTheme(int i10) {
        if (this.f1026k != i10) {
            this.f1026k = i10;
            if (i10 == 0) {
                this.f1025j = getContext();
            } else {
                this.f1025j = new ContextThemeWrapper(getContext(), i10);
            }
        }
    }

    public void setSubtitle(int i10) {
        setSubtitle(getContext().getText(i10));
    }

    public void setSubtitleTextColor(int i10) {
        setSubtitleTextColor(ColorStateList.valueOf(i10));
    }

    public void setTitle(int i10) {
        setTitle(getContext().getText(i10));
    }

    public void setTitleMarginBottom(int i10) {
        this.f1034s = i10;
        requestLayout();
    }

    public void setTitleMarginEnd(int i10) {
        this.f1032q = i10;
        requestLayout();
    }

    public void setTitleMarginStart(int i10) {
        this.f1031p = i10;
        requestLayout();
    }

    public void setTitleMarginTop(int i10) {
        this.f1033r = i10;
        requestLayout();
    }

    public void setTitleTextColor(int i10) {
        setTitleTextColor(ColorStateList.valueOf(i10));
    }

    public final int t(View view) {
        ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) view.getLayoutParams();
        return marginLayoutParams.topMargin + marginLayoutParams.bottomMargin;
    }

    public final int u(List<View> list, int[] iArr) {
        int i10 = iArr[0];
        int i11 = iArr[1];
        int size = list.size();
        int i12 = 0;
        int i13 = 0;
        while (i12 < size) {
            View view = list.get(i12);
            g gVar = (g) view.getLayoutParams();
            int i14 = ((ViewGroup.MarginLayoutParams) gVar).leftMargin - i10;
            int i15 = ((ViewGroup.MarginLayoutParams) gVar).rightMargin - i11;
            int max = Math.max(0, i14);
            int max2 = Math.max(0, i15);
            int max3 = Math.max(0, -i14);
            int max4 = Math.max(0, -i15);
            i13 += max + view.getMeasuredWidth() + max2;
            i12++;
            i11 = max4;
            i10 = max3;
        }
        return i13;
    }

    public boolean v() {
        f fVar = this.L;
        return (fVar == null || fVar.b == null) ? false : true;
    }

    public boolean w() {
        ActionMenuView actionMenuView = this.f1017a;
        return actionMenuView != null && actionMenuView.F();
    }

    public void x(int i10) {
        getMenuInflater().inflate(i10, getMenu());
    }

    public void y() {
        ArrayList<MenuItem> arrayList = this.H;
        int size = arrayList.size();
        int i10 = 0;
        while (i10 < size) {
            MenuItem menuItem = arrayList.get(i10);
            i10++;
            getMenu().removeItem(menuItem.getItemId());
        }
        G();
    }

    public final boolean z(View view) {
        return view.getParent() == this || this.E.contains(view);
    }

    public static class g extends a.C0372a {
        public int b;

        public g(@NonNull Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
            this.b = 0;
        }

        public void a(ViewGroup.MarginLayoutParams marginLayoutParams) {
            ((ViewGroup.MarginLayoutParams) this).leftMargin = marginLayoutParams.leftMargin;
            ((ViewGroup.MarginLayoutParams) this).topMargin = marginLayoutParams.topMargin;
            ((ViewGroup.MarginLayoutParams) this).rightMargin = marginLayoutParams.rightMargin;
            ((ViewGroup.MarginLayoutParams) this).bottomMargin = marginLayoutParams.bottomMargin;
        }

        public g(int i10, int i11) {
            super(i10, i11);
            this.b = 0;
            this.f19837a = 8388627;
        }

        public g(g gVar) {
            super((a.C0372a) gVar);
            this.b = 0;
            this.b = gVar.b;
        }

        public g(a.C0372a c0372a) {
            super(c0372a);
            this.b = 0;
        }

        public g(ViewGroup.MarginLayoutParams marginLayoutParams) {
            super(marginLayoutParams);
            this.b = 0;
            a(marginLayoutParams);
        }

        public g(ViewGroup.LayoutParams layoutParams) {
            super(layoutParams);
            this.b = 0;
        }
    }

    public Toolbar(@NonNull Context context, AttributeSet attributeSet, int i10) {
        super(context, attributeSet, i10);
        this.f1038w = 8388627;
        this.D = new ArrayList<>();
        this.E = new ArrayList<>();
        this.F = new int[2];
        this.G = new p(new Runnable() { // from class: q.d1
            @Override // java.lang.Runnable
            public final void run() {
                Toolbar.this.y();
            }
        });
        this.H = new ArrayList<>();
        this.I = new a();
        this.S = new b();
        b1 v8 = b1.v(getContext(), attributeSet, j.f18887f3, i10, 0);
        o0.k0(this, context, j.f18887f3, attributeSet, v8.r(), i10, 0);
        this.f1027l = v8.n(j.H3, 0);
        this.f1028m = v8.n(j.f18982y3, 0);
        this.f1038w = v8.l(j.f18892g3, this.f1038w);
        this.f1029n = v8.l(j.f18897h3, 48);
        int e10 = v8.e(j.B3, 0);
        e10 = v8.s(j.G3) ? v8.e(j.G3, e10) : e10;
        this.f1034s = e10;
        this.f1033r = e10;
        this.f1032q = e10;
        this.f1031p = e10;
        int e11 = v8.e(j.E3, -1);
        if (e11 >= 0) {
            this.f1031p = e11;
        }
        int e12 = v8.e(j.D3, -1);
        if (e12 >= 0) {
            this.f1032q = e12;
        }
        int e13 = v8.e(j.F3, -1);
        if (e13 >= 0) {
            this.f1033r = e13;
        }
        int e14 = v8.e(j.C3, -1);
        if (e14 >= 0) {
            this.f1034s = e14;
        }
        this.f1030o = v8.f(j.f18952s3, -1);
        int e15 = v8.e(j.f18932o3, Integer.MIN_VALUE);
        int e16 = v8.e(j.f18912k3, Integer.MIN_VALUE);
        int f10 = v8.f(j.f18922m3, 0);
        int f11 = v8.f(j.f18927n3, 0);
        h();
        this.f1035t.e(f10, f11);
        if (e15 != Integer.MIN_VALUE || e16 != Integer.MIN_VALUE) {
            this.f1035t.g(e15, e16);
        }
        this.f1036u = v8.e(j.f18937p3, Integer.MIN_VALUE);
        this.f1037v = v8.e(j.f18917l3, Integer.MIN_VALUE);
        this.f1021f = v8.g(j.f18907j3);
        this.f1022g = v8.p(j.f18902i3);
        CharSequence p8 = v8.p(j.A3);
        if (!TextUtils.isEmpty(p8)) {
            setTitle(p8);
        }
        CharSequence p10 = v8.p(j.f18977x3);
        if (!TextUtils.isEmpty(p10)) {
            setSubtitle(p10);
        }
        this.f1025j = getContext();
        setPopupTheme(v8.n(j.f18972w3, 0));
        Drawable g10 = v8.g(j.f18967v3);
        if (g10 != null) {
            setNavigationIcon(g10);
        }
        CharSequence p11 = v8.p(j.f18962u3);
        if (!TextUtils.isEmpty(p11)) {
            setNavigationContentDescription(p11);
        }
        Drawable g11 = v8.g(j.f18942q3);
        if (g11 != null) {
            setLogo(g11);
        }
        CharSequence p12 = v8.p(j.f18947r3);
        if (!TextUtils.isEmpty(p12)) {
            setLogoDescription(p12);
        }
        if (v8.s(j.I3)) {
            setTitleTextColor(v8.c(j.I3));
        }
        if (v8.s(j.f18987z3)) {
            setSubtitleTextColor(v8.c(j.f18987z3));
        }
        if (v8.s(j.f18957t3)) {
            x(v8.n(j.f18957t3, 0));
        }
        v8.x();
    }

    public void setCollapseContentDescription(CharSequence charSequence) {
        if (!TextUtils.isEmpty(charSequence)) {
            g();
        }
        ImageButton imageButton = this.f1023h;
        if (imageButton != null) {
            imageButton.setContentDescription(charSequence);
        }
    }

    public void setCollapseIcon(Drawable drawable) {
        if (drawable != null) {
            g();
            this.f1023h.setImageDrawable(drawable);
        } else {
            ImageButton imageButton = this.f1023h;
            if (imageButton != null) {
                imageButton.setImageDrawable(this.f1021f);
            }
        }
    }

    public void setLogo(Drawable drawable) {
        if (drawable != null) {
            i();
            if (!z(this.f1020e)) {
                c(this.f1020e, true);
            }
        } else {
            ImageView imageView = this.f1020e;
            if (imageView != null && z(imageView)) {
                removeView(this.f1020e);
                this.E.remove(this.f1020e);
            }
        }
        ImageView imageView2 = this.f1020e;
        if (imageView2 != null) {
            imageView2.setImageDrawable(drawable);
        }
    }

    public void setLogoDescription(CharSequence charSequence) {
        if (!TextUtils.isEmpty(charSequence)) {
            i();
        }
        ImageView imageView = this.f1020e;
        if (imageView != null) {
            imageView.setContentDescription(charSequence);
        }
    }

    public void setNavigationContentDescription(CharSequence charSequence) {
        if (!TextUtils.isEmpty(charSequence)) {
            l();
        }
        ImageButton imageButton = this.f1019d;
        if (imageButton != null) {
            imageButton.setContentDescription(charSequence);
            f1.a(this.f1019d, charSequence);
        }
    }

    public void setNavigationIcon(Drawable drawable) {
        if (drawable != null) {
            l();
            if (!z(this.f1019d)) {
                c(this.f1019d, true);
            }
        } else {
            ImageButton imageButton = this.f1019d;
            if (imageButton != null && z(imageButton)) {
                removeView(this.f1019d);
                this.E.remove(this.f1019d);
            }
        }
        ImageButton imageButton2 = this.f1019d;
        if (imageButton2 != null) {
            imageButton2.setImageDrawable(drawable);
        }
    }

    public void setSubtitle(CharSequence charSequence) {
        if (TextUtils.isEmpty(charSequence)) {
            TextView textView = this.f1018c;
            if (textView != null && z(textView)) {
                removeView(this.f1018c);
                this.E.remove(this.f1018c);
            }
        } else {
            if (this.f1018c == null) {
                Context context = getContext();
                c0 c0Var = new c0(context);
                this.f1018c = c0Var;
                c0Var.setSingleLine();
                this.f1018c.setEllipsize(TextUtils.TruncateAt.END);
                int i10 = this.f1028m;
                if (i10 != 0) {
                    this.f1018c.setTextAppearance(context, i10);
                }
                ColorStateList colorStateList = this.A;
                if (colorStateList != null) {
                    this.f1018c.setTextColor(colorStateList);
                }
            }
            if (!z(this.f1018c)) {
                c(this.f1018c, true);
            }
        }
        TextView textView2 = this.f1018c;
        if (textView2 != null) {
            textView2.setText(charSequence);
        }
        this.f1040y = charSequence;
    }

    public void setSubtitleTextColor(@NonNull ColorStateList colorStateList) {
        this.A = colorStateList;
        TextView textView = this.f1018c;
        if (textView != null) {
            textView.setTextColor(colorStateList);
        }
    }

    public void setTitle(CharSequence charSequence) {
        if (TextUtils.isEmpty(charSequence)) {
            TextView textView = this.b;
            if (textView != null && z(textView)) {
                removeView(this.b);
                this.E.remove(this.b);
            }
        } else {
            if (this.b == null) {
                Context context = getContext();
                c0 c0Var = new c0(context);
                this.b = c0Var;
                c0Var.setSingleLine();
                this.b.setEllipsize(TextUtils.TruncateAt.END);
                int i10 = this.f1027l;
                if (i10 != 0) {
                    this.b.setTextAppearance(context, i10);
                }
                ColorStateList colorStateList = this.f1041z;
                if (colorStateList != null) {
                    this.b.setTextColor(colorStateList);
                }
            }
            if (!z(this.b)) {
                c(this.b, true);
            }
        }
        TextView textView2 = this.b;
        if (textView2 != null) {
            textView2.setText(charSequence);
        }
        this.f1039x = charSequence;
    }

    public void setTitleTextColor(@NonNull ColorStateList colorStateList) {
        this.f1041z = colorStateList;
        TextView textView = this.b;
        if (textView != null) {
            textView.setTextColor(colorStateList);
        }
    }

    public static class i extends r3.a {
        public static final Parcelable.Creator<i> CREATOR = new a();

        /* renamed from: c, reason: collision with root package name */
        public int f1048c;

        /* renamed from: d, reason: collision with root package name */
        public boolean f1049d;

        public class a implements Parcelable.ClassLoaderCreator<i> {
            @Override // android.os.Parcelable.Creator
            /* renamed from: a, reason: merged with bridge method [inline-methods] */
            public i createFromParcel(Parcel parcel) {
                return new i(parcel, null);
            }

            @Override // android.os.Parcelable.ClassLoaderCreator
            /* renamed from: b, reason: merged with bridge method [inline-methods] */
            public i createFromParcel(Parcel parcel, ClassLoader classLoader) {
                return new i(parcel, classLoader);
            }

            @Override // android.os.Parcelable.Creator
            /* renamed from: c, reason: merged with bridge method [inline-methods] */
            public i[] newArray(int i10) {
                return new i[i10];
            }
        }

        public i(Parcel parcel, ClassLoader classLoader) {
            super(parcel, classLoader);
            this.f1048c = parcel.readInt();
            this.f1049d = parcel.readInt() != 0;
        }

        @Override // r3.a, android.os.Parcelable
        public void writeToParcel(Parcel parcel, int i10) {
            super.writeToParcel(parcel, i10);
            parcel.writeInt(this.f1048c);
            parcel.writeInt(this.f1049d ? 1 : 0);
        }

        public i(Parcelable parcelable) {
            super(parcelable);
        }
    }


    // --- восстановлено из DEX (androidx/appcompat/widget/Toolbar$i$a) ---
    public static class a implements android.os.Parcelable.ClassLoaderCreator {
        public a() { }
        public androidx.appcompat.widget.Toolbar.i a(android.os.Parcel p0) { throw new UnsupportedOperationException("stub"); }
        public androidx.appcompat.widget.Toolbar.i b(android.os.Parcel p0, java.lang.ClassLoader p1) { throw new UnsupportedOperationException("stub"); }
        public androidx.appcompat.widget.Toolbar.i[] c(int p0) { throw new UnsupportedOperationException("stub"); }
        public java.lang.Object createFromParcel(android.os.Parcel p0) { throw new UnsupportedOperationException("stub"); }
        public java.lang.Object createFromParcel(android.os.Parcel p0, java.lang.ClassLoader p1) { throw new UnsupportedOperationException("stub"); }
        public java.lang.Object[] newArray(int p0) { throw new UnsupportedOperationException("stub"); }
    }
}
