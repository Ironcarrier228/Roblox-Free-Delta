package yo;

import android.R;
import android.content.Context;
import android.util.Size;
import av.z0;
import com.github.luben.zstd.BuildConfig;
import com.google.mlkit.vision.barcode.common.Barcode;
import com.withpersona.sdk2.inquiry.network.core.InternalErrorInfo;
import com.withpersona.sdk2.inquiry.tracking.TrackingEventsLogger;
import com.withpersona.sdk2.inquiry.tracking.model.GovIdCaptureMethod;
import com.withpersona.sdk2.inquiry.tracking.model.GovIdCaptureState;
import com.withpersona.sdk2.inquiry.tracking.model.GovernmentIdStateEventData;
import cp.GovernmentIdHintWorker;
import fq.n1;
import fq.y1;
import java.io.File;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import js.b;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.Intrinsics;
import kotlin.reflect.KTypeProjection;
import kotlin.text.StringsKt;
import kotlin.time.a;
import ln.k;
import ln.o;
import ln.r;
import org.jetbrains.annotations.NotNull;
import rn.AlertContainerScreen;
import rn.AlertScreen;
import sn.a0;
import un.CameraChoices;
import un.c;
import vo.Frame;
import vo.GovernmentIdAnalyzeWorker;
import vo.IdConfig;
import vo.b3;
import vo.d2;
import vo.f;
import vo.i3;
import vo.j0;
import vo.n;
import vo.y3;
import yo.t0;

@Metadata(d1 = {"\u0000¢\u0001\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0015\u0018\u00002\u00020\u0001BQ\b\u0007\u0012\u0006\u0010\u0003\u001a\u00020\u0002\u0012\u0006\u0010\u0005\u001a\u00020\u0004\u0012\u0006\u0010\u0007\u001a\u00020\u0006\u0012\u0006\u0010\t\u001a\u00020\b\u0012\u0006\u0010\u000b\u001a\u00020\n\u0012\u0006\u0010\r\u001a\u00020\f\u0012\u0006\u0010\u000f\u001a\u00020\u000e\u0012\u0006\u0010\u0011\u001a\u00020\u0010\u0012\u0006\u0010\u0013\u001a\u00020\u0012¢\u0006\u0004\b\u0014\u0010\u0015JQ\u0010#\u001a\u00020\"2\u0006\u0010\u0017\u001a\u00020\u00162\u0006\u0010\u0019\u001a\u00020\u00182&\u0010\u001f\u001a\"0\u001aR\u001a\u0012\u0004\u0012\u00020\u0016\u0012\u0004\u0012\u00020\u001d\u0012\u0004\u0012\u00020\u001e\u0012\u0004\u0012\u00020\u00010\u001cj\u0002`\u001b2\b\u0010!\u001a\u0004\u0018\u00010 H\u0002¢\u0006\u0004\b#\u0010$Jg\u0010-\u001a\u00020\"2\u0006\u0010\u0017\u001a\u00020\u00162\u0006\u0010\u0019\u001a\u00020\u001d2&\u0010\u001f\u001a\"0\u001aR\u001a\u0012\u0004\u0012\u00020\u0016\u0012\u0004\u0012\u00020\u001d\u0012\u0004\u0012\u00020\u001e\u0012\u0004\u0012\u00020\u00010\u001cj\u0002`\u001b2\u0006\u0010&\u001a\u00020%2\u0006\u0010(\u001a\u00020'2\u0006\u0010*\u001a\u00020)2\u0006\u0010,\u001a\u00020+H\u0002¢\u0006\u0004\b-\u0010.J[\u00101\u001a\u00020\u00012\u0006\u0010\u0017\u001a\u00020\u00162\u0006\u0010\u0019\u001a\u00020\u00182&\u0010\u001f\u001a\"0\u001aR\u001a\u0012\u0004\u0012\u00020\u0016\u0012\u0004\u0012\u00020\u001d\u0012\u0004\u0012\u00020\u001e\u0012\u0004\u0012\u00020\u00010\u001cj\u0002`\u001b2\u0006\u0010(\u001a\u00020'2\f\u00100\u001a\b\u0012\u0004\u0012\u00020\u001e0/¢\u0006\u0004\b1\u00102J[\u00104\u001a\u00020\u00012\u0006\u0010\u0017\u001a\u00020\u00162\u0006\u0010\u0019\u001a\u0002032&\u0010\u001f\u001a\"0\u001aR\u001a\u0012\u0004\u0012\u00020\u0016\u0012\u0004\u0012\u00020\u001d\u0012\u0004\u0012\u00020\u001e\u0012\u0004\u0012\u00020\u00010\u001cj\u0002`\u001b2\u0006\u0010(\u001a\u00020'2\f\u00100\u001a\b\u0012\u0004\u0012\u00020\u001e0/¢\u0006\u0004\b4\u00105J[\u00107\u001a\u00020\u00012\u0006\u0010\u0017\u001a\u00020\u00162\u0006\u0010\u0019\u001a\u0002062&\u0010\u001f\u001a\"0\u001aR\u001a\u0012\u0004\u0012\u00020\u0016\u0012\u0004\u0012\u00020\u001d\u0012\u0004\u0012\u00020\u001e\u0012\u0004\u0012\u00020\u00010\u001cj\u0002`\u001b2\u0006\u0010(\u001a\u00020'2\f\u00100\u001a\b\u0012\u0004\u0012\u00020\u001e0/¢\u0006\u0004\b7\u00108R\u0014\u0010\u0003\u001a\u00020\u00028\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b9\u0010:R\u0014\u0010\u0005\u001a\u00020\u00048\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b;\u0010<R\u0014\u0010\u0007\u001a\u00020\u00068\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b=\u0010>R\u0014\u0010\t\u001a\u00020\b8\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b?\u0010@R\u0014\u0010\u000b\u001a\u00020\n8\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\bA\u0010BR\u0014\u0010\r\u001a\u00020\f8\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\bC\u0010DR\u0014\u0010\u000f\u001a\u00020\u000e8\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\bE\u0010FR\u0014\u0010\u0011\u001a\u00020\u00108\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\bG\u0010HR\u0014\u0010\u0013\u001a\u00020\u00128\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\bI\u0010J¨\u0006K"}, d2 = {"Lyo/t0;", BuildConfig.FLAVOR, "Landroid/content/Context;", "applicationContext", "Lfq/n1;", "permissionRequestWorkflow", "Lvo/o$a;", "governmentIdAnalyzeWorkerFactory", "Lcp/a$b;", "governmentIdHintWorkerFactory", "Ljs/b$a;", "webRtcWorkerFactory", "Lsn/a0$a;", "cameraXControllerFactory", "Lun/c$a;", "camera2ControllerFactory", "Lir/b;", "navigationStateManager", "Lcom/withpersona/sdk2/inquiry/tracking/TrackingEventsLogger;", "trackingEventsLogger", "<init>", "(Landroid/content/Context;Lfq/n1;Lvo/o$a;Lcp/a$b;Ljs/b$a;Lsn/a0$a;Lun/c$a;Lir/b;Lcom/withpersona/sdk2/inquiry/tracking/TrackingEventsLogger;)V", "Lvo/d2$a;", "renderProps", "Lvo/j0$n;", "renderState", "Lln/k$a;", "Lcom/withpersona/sdk2/inquiry/governmentid/RenderContext;", "Lln/k;", "Lvo/j0;", "Lvo/d2$b;", "context", "Lks/a;", "webRtcManager", BuildConfig.FLAVOR, "G0", "(Lvo/d2$a;Lvo/j0$n;Lln/k$a;Lks/a;)V", "Lvo/f;", "captureConfig", "Lip/l;", "videoCaptureHelper", "Lsn/v;", "cameraProperties", "Lvo/n$b;", "capturedId", "T", "(Lvo/d2$a;Lvo/j0;Lln/k$a;Lvo/f;Lip/l;Lsn/v;Lvo/n$b;)V", "Lln/h;", "sink", "n0", "(Lvo/d2$a;Lvo/j0$n;Lln/k$a;Lip/l;Lln/h;)Ljava/lang/Object;", "Lvo/j0$d;", "Y", "(Lvo/d2$a;Lvo/j0$d;Lln/k$a;Lip/l;Lln/h;)Ljava/lang/Object;", "Lvo/j0$g;", "j0", "(Lvo/d2$a;Lvo/j0$g;Lln/k$a;Lip/l;Lln/h;)Ljava/lang/Object;", xe.a.f36648e, "Landroid/content/Context;", k6.b.f21144e, "Lfq/n1;", "c", "Lvo/o$a;", "d", "Lcp/a$b;", "e", "Ljs/b$a;", "f", "Lsn/a0$a;", "g", "Lun/c$a;", "h", "Lir/b;", "i", "Lcom/withpersona/sdk2/inquiry/tracking/TrackingEventsLogger;", "government-id_release"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* loaded from: classes3.dex */
public final class t0 {

    /* renamed from: a, reason: collision with root package name and from kotlin metadata */
    @NotNull
    public final Context applicationContext;

    /* renamed from: b, reason: from kotlin metadata */
    @NotNull
    public final n1 permissionRequestWorkflow;

    /* renamed from: c, reason: collision with root package name and from kotlin metadata */
    @NotNull
    public final GovernmentIdAnalyzeWorker.a governmentIdAnalyzeWorkerFactory;

    /* renamed from: d, reason: collision with root package name and from kotlin metadata */
    @NotNull
    public final GovernmentIdHintWorker.b governmentIdHintWorkerFactory;

    /* renamed from: e, reason: collision with root package name and from kotlin metadata */
    @NotNull
    public final b.a webRtcWorkerFactory;

    /* renamed from: f, reason: collision with root package name and from kotlin metadata */
    @NotNull
    public final a0.a cameraXControllerFactory;

    /* renamed from: g, reason: collision with root package name and from kotlin metadata */
    @NotNull
    public final c.a camera2ControllerFactory;

    /* renamed from: h, reason: collision with root package name and from kotlin metadata */
    @NotNull
    public final ir.b navigationStateManager;

    /* renamed from: i, reason: collision with root package name and from kotlin metadata */
    @NotNull
    public final TrackingEventsLogger trackingEventsLogger;

    @Metadata(d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0002\b\u0002\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\n¢\u0006\u0004\b\u0002\u0010\u0003"}, d2 = {"Lav/p0;", BuildConfig.FLAVOR, "<anonymous>", "(Lav/p0;)V"}, k = 3, mv = {2, 2, 0})
    @gu.f(c = "com.withpersona.sdk2.inquiry.governmentid.capture.CaptureRenderer$renderHolographicTorchDelay$1", f = "CaptureRenderer.kt", l = {454}, m = "invokeSuspend")
    public static final class a extends gu.m implements Function2<av.p0, eu.b<? super Unit>, Object> {

        /* renamed from: t, reason: collision with root package name */
        public int f38043t;

        /* renamed from: u, reason: collision with root package name */
        public final /* synthetic */ j0.HolographicTorchDelay f38044u;

        /* renamed from: v, reason: collision with root package name */
        public final /* synthetic */ ln.k<d2.a, vo.j0, d2.b, Object>.a f38045v;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        /* JADX WARN: Multi-variable type inference failed */
        public a(j0.HolographicTorchDelay holographicTorchDelay, ln.k<? super d2.a, vo.j0, ? extends d2.b, ? extends Object>.a aVar, eu.b<? super a> bVar) {
            super(2, bVar);
            this.f38044u = holographicTorchDelay;
            this.f38045v = aVar;
        }

        public static final Unit p(r.c cVar) {
            Object c10 = cVar.c();
            j0.HolographicTorchDelay holographicTorchDelay = c10 instanceof j0.HolographicTorchDelay ? (j0.HolographicTorchDelay) c10 : null;
            if (holographicTorchDelay == null) {
                return Unit.f21504a;
            }
            cVar.e(j0.HolographicTorchDelay.H(holographicTorchDelay, null, null, null, 0, null, null, null, null, 0, null, false, 1023, null));
            return Unit.f21504a;
        }

        @Override // gu.a
        public final eu.b<Unit> create(Object obj, eu.b<?> bVar) {
            return new a(this.f38044u, this.f38045v, bVar);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(av.p0 p0Var, eu.b<? super Unit> bVar) {
            return ((a) create(p0Var, bVar)).invokeSuspend(Unit.f21504a);
        }

        @Override // gu.a
        public final Object invokeSuspend(Object obj) {
            ln.r<? super d2.a, vo.j0, ? extends d2.b> c10;
            Object e10 = fu.c.e();
            int i10 = this.f38043t;
            if (i10 == 0) {
                zt.o.b(obj);
                a.Companion companion = kotlin.time.a.INSTANCE;
                long p8 = kotlin.time.b.p(this.f38044u.getTorchDurationMs(), zu.b.f39510d);
                this.f38043t = 1;
                if (z0.c(p8, this) == e10) {
                    return e10;
                }
            } else {
                if (i10 != 1) {
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                zt.o.b(obj);
            }
            ln.h<ln.r<? super d2.a, vo.j0, ? extends d2.b>> d10 = this.f38045v.d();
            c10 = ln.b0.c(null, new Function1() { // from class: yo.s0
                @Override // kotlin.jvm.functions.Function1
                public final Object invoke(Object obj2) {
                    Unit p10;
                    p10 = t0.a.p((r.c) obj2);
                    return p10;
                }
            }, 1, null);
            d10.a(c10);
            return Unit.f21504a;
        }
    }

    @Metadata(d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0002\b\u0002\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\n¢\u0006\u0004\b\u0002\u0010\u0003"}, d2 = {"Lav/p0;", BuildConfig.FLAVOR, "<anonymous>", "(Lav/p0;)V"}, k = 3, mv = {2, 2, 0})
    @gu.f(c = "com.withpersona.sdk2.inquiry.governmentid.capture.CaptureRenderer$renderHolographicTorchDelay$2", f = "CaptureRenderer.kt", l = {}, m = "invokeSuspend")
    public static final class b extends gu.m implements Function2<av.p0, eu.b<? super Unit>, Object> {

        /* renamed from: t, reason: collision with root package name */
        public int f38046t;

        /* renamed from: v, reason: collision with root package name */
        public final /* synthetic */ d2.a f38048v;

        /* renamed from: w, reason: collision with root package name */
        public final /* synthetic */ j0.HolographicTorchDelay f38049w;

        /* renamed from: x, reason: collision with root package name */
        public final /* synthetic */ ln.k<d2.a, vo.j0, d2.b, Object>.a f38050x;

        /* renamed from: y, reason: collision with root package name */
        public final /* synthetic */ ip.l f38051y;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        /* JADX WARN: Multi-variable type inference failed */
        public b(d2.a aVar, j0.HolographicTorchDelay holographicTorchDelay, ln.k<? super d2.a, vo.j0, ? extends d2.b, ? extends Object>.a aVar2, ip.l lVar, eu.b<? super b> bVar) {
            super(2, bVar);
            this.f38048v = aVar;
            this.f38049w = holographicTorchDelay;
            this.f38050x = aVar2;
            this.f38051y = lVar;
        }

        @Override // gu.a
        public final eu.b<Unit> create(Object obj, eu.b<?> bVar) {
            return t0.this.new b(this.f38048v, this.f38049w, this.f38050x, this.f38051y, bVar);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(av.p0 p0Var, eu.b<? super Unit> bVar) {
            return ((b) create(p0Var, bVar)).invokeSuspend(Unit.f21504a);
        }

        @Override // gu.a
        public final Object invokeSuspend(Object obj) {
            fu.c.e();
            if (this.f38046t != 0) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            zt.o.b(obj);
            t0 t0Var = t0.this;
            d2.a aVar = this.f38048v;
            j0.HolographicTorchDelay holographicTorchDelay = this.f38049w;
            t0Var.T(aVar, holographicTorchDelay, this.f38050x, holographicTorchDelay.getCaptureConfig(), this.f38051y, this.f38049w.getCameraProperties(), this.f38049w.getCapturedImage());
            return Unit.f21504a;
        }
    }

    public t0(@NotNull Context applicationContext, @NotNull n1 permissionRequestWorkflow, @NotNull GovernmentIdAnalyzeWorker.a governmentIdAnalyzeWorkerFactory, @NotNull GovernmentIdHintWorker.b governmentIdHintWorkerFactory, @NotNull b.a webRtcWorkerFactory, @NotNull a0.a cameraXControllerFactory, @NotNull c.a camera2ControllerFactory, @NotNull ir.b navigationStateManager, @NotNull TrackingEventsLogger trackingEventsLogger) {
        Intrinsics.checkNotNullParameter(applicationContext, "applicationContext");
        Intrinsics.checkNotNullParameter(permissionRequestWorkflow, "permissionRequestWorkflow");
        Intrinsics.checkNotNullParameter(governmentIdAnalyzeWorkerFactory, "governmentIdAnalyzeWorkerFactory");
        Intrinsics.checkNotNullParameter(governmentIdHintWorkerFactory, "governmentIdHintWorkerFactory");
        Intrinsics.checkNotNullParameter(webRtcWorkerFactory, "webRtcWorkerFactory");
        Intrinsics.checkNotNullParameter(cameraXControllerFactory, "cameraXControllerFactory");
        Intrinsics.checkNotNullParameter(camera2ControllerFactory, "camera2ControllerFactory");
        Intrinsics.checkNotNullParameter(navigationStateManager, "navigationStateManager");
        Intrinsics.checkNotNullParameter(trackingEventsLogger, "trackingEventsLogger");
        this.applicationContext = applicationContext;
        this.permissionRequestWorkflow = permissionRequestWorkflow;
        this.governmentIdAnalyzeWorkerFactory = governmentIdAnalyzeWorkerFactory;
        this.governmentIdHintWorkerFactory = governmentIdHintWorkerFactory;
        this.webRtcWorkerFactory = webRtcWorkerFactory;
        this.cameraXControllerFactory = cameraXControllerFactory;
        this.camera2ControllerFactory = camera2ControllerFactory;
        this.navigationStateManager = navigationStateManager;
        this.trackingEventsLogger = trackingEventsLogger;
    }

    public static final Unit A0(r.c action) {
        Intrinsics.checkNotNullParameter(action, "$this$action");
        action.d(new d2.b.c(new InternalErrorInfo.NoDiskSpaceErrorInfo(null, 1, null)));
        return Unit.f21504a;
    }

    public static final Unit B0(j0.WaitForAutocapture waitForAutocapture, r.c action) {
        Intrinsics.checkNotNullParameter(action, "$this$action");
        if (waitForAutocapture.getManualCapture() == y3.b.a.f35072c) {
            action.e(j0.WaitForAutocapture.L(waitForAutocapture, null, null, null, y3.b.a.b, null, 0, null, null, null, null, false, false, null, null, null, 32759, null));
        }
        return Unit.f21504a;
    }

    public static final ln.r C0(final cp.d dVar) {
        ln.r c10;
        c10 = ln.b0.c(null, new Function1() { // from class: yo.n
            @Override // kotlin.jvm.functions.Function1
            public final Object invoke(Object obj) {
                Unit D0;
                D0 = t0.D0(cp.d.this, (r.c) obj);
                return D0;
            }
        }, 1, null);
        return c10;
    }

    public static final Unit D0(cp.d dVar, r.c action) {
        Intrinsics.checkNotNullParameter(action, "$this$action");
        Object c10 = action.c();
        j0.WaitForAutocapture waitForAutocapture = c10 instanceof j0.WaitForAutocapture ? (j0.WaitForAutocapture) c10 : null;
        if (waitForAutocapture == null) {
            return Unit.f21504a;
        }
        action.e(j0.WaitForAutocapture.L(waitForAutocapture, null, null, null, null, null, 0, null, null, null, null, false, false, null, dVar, null, 24575, null));
        return Unit.f21504a;
    }

    public static final ln.r E0(final j0.WaitForAutocapture waitForAutocapture, Unit it) {
        ln.r c10;
        Intrinsics.checkNotNullParameter(it, "it");
        c10 = ln.b0.c(null, new Function1() { // from class: yo.o
            @Override // kotlin.jvm.functions.Function1
            public final Object invoke(Object obj) {
                Unit F0;
                F0 = t0.F0(j0.WaitForAutocapture.this, (r.c) obj);
                return F0;
            }
        }, 1, null);
        return c10;
    }

    public static final Unit F0(j0.WaitForAutocapture waitForAutocapture, r.c action) {
        Intrinsics.checkNotNullParameter(action, "$this$action");
        if (waitForAutocapture.getManualCapture() == y3.b.a.f35072c) {
            action.e(j0.WaitForAutocapture.L(waitForAutocapture, null, null, null, y3.b.a.b, null, 0, null, null, null, null, false, false, null, null, null, 32759, null));
        }
        return Unit.f21504a;
    }

    public static final ln.r H0(final t0 t0Var, final ks.a aVar, final j0.WaitForAutocapture waitForAutocapture, final d2.a aVar2, final k.a aVar3, final b.AbstractC0389b it) {
        ln.r c10;
        ln.r c11;
        Intrinsics.checkNotNullParameter(it, "it");
        final CameraChoices b10 = un.f0.b(t0Var.applicationContext, un.m0.f33657a);
        if (it instanceof b.AbstractC0389b.C0390b) {
            c11 = ln.b0.c(null, new Function1() { // from class: yo.a0
                @Override // kotlin.jvm.functions.Function1
                public final Object invoke(Object obj) {
                    Unit I0;
                    I0 = t0.I0(ks.a.this, t0Var, b10, it, waitForAutocapture, aVar2, aVar3, (r.c) obj);
                    return I0;
                }
            }, 1, null);
            return c11;
        }
        if (!(it instanceof b.AbstractC0389b.Error)) {
            throw new zt.l();
        }
        c10 = ln.b0.c(null, new Function1() { // from class: yo.b0
            @Override // kotlin.jvm.functions.Function1
            public final Object invoke(Object obj) {
                Unit O0;
                O0 = t0.O0(k.a.this, aVar, (r.c) obj);
                return O0;
            }
        }, 1, null);
        return c10;
    }

    public static final Unit I0(final ks.a aVar, final t0 t0Var, CameraChoices cameraChoices, b.AbstractC0389b abstractC0389b, final j0.WaitForAutocapture waitForAutocapture, final d2.a aVar2, final k.a aVar3, r.c action) {
        int i10;
        int i11;
        un.h0 primaryChoice;
        un.h0 primaryChoice2;
        un.h0 primaryChoice3;
        Size size;
        un.h0 primaryChoice4;
        Size size2;
        Intrinsics.checkNotNullParameter(action, "$this$action");
        Object c10 = action.c();
        j0.WaitForAutocapture waitForAutocapture2 = c10 instanceof j0.WaitForAutocapture ? (j0.WaitForAutocapture) c10 : null;
        if (waitForAutocapture2 != null && waitForAutocapture2.getWebRtcState() == ip.x.f19685a) {
            return Unit.f21504a;
        }
        if (waitForAutocapture2 != null) {
            action.e(j0.WaitForAutocapture.L(waitForAutocapture2, null, null, null, null, null, 0, null, ip.x.f19685a, null, null, false, false, null, null, null, 32639, null));
        }
        if (aVar != null) {
            aVar.b(t0Var.webRtcWorkerFactory.getService());
        }
        if (aVar != null) {
            aVar.i(t0Var.applicationContext);
        }
        int i12 = 0;
        int width = (cameraChoices == null || (primaryChoice4 = cameraChoices.getPrimaryChoice()) == null || (size2 = primaryChoice4.getSize()) == null) ? 0 : size2.getWidth();
        if (cameraChoices != null && (primaryChoice3 = cameraChoices.getPrimaryChoice()) != null && (size = primaryChoice3.getSize()) != null) {
            i12 = size.getHeight();
        }
        if ((cameraChoices == null || (primaryChoice2 = cameraChoices.getPrimaryChoice()) == null || primaryChoice2.getRotation() != 90) && (cameraChoices == null || (primaryChoice = cameraChoices.getPrimaryChoice()) == null || primaryChoice.getRotation() != 270)) {
            i10 = i12;
            i11 = width;
        } else {
            i11 = i12;
            i10 = width;
        }
        if (aVar != null) {
            b.AbstractC0389b.C0390b c0390b = (b.AbstractC0389b.C0390b) abstractC0389b;
            aVar.f(c0390b.getResult().getUsername(), c0390b.getResult().getCredential(), c0390b.getResult().getServerUrl(), waitForAutocapture.getWebRtcJwt(), i11, i10, aVar2.getVideoCaptureConfig().getRecordAudio(), new Function0() { // from class: yo.f0
                @Override // kotlin.jvm.functions.Function0
                public final Object invoke() {
                    Unit J0;
                    J0 = t0.J0(t0.this, aVar2, waitForAutocapture);
                    return J0;
                }
            }, new Function0() { // from class: yo.g0
                @Override // kotlin.jvm.functions.Function0
                public final Object invoke() {
                    Unit K0;
                    K0 = t0.K0(k.a.this, aVar);
                    return K0;
                }
            }, new Function0() { // from class: yo.i0
                @Override // kotlin.jvm.functions.Function0
                public final Object invoke() {
                    Unit M0;
                    M0 = t0.M0(t0.this, aVar2);
                    return M0;
                }
            }, new Function1() { // from class: yo.j0
                @Override // kotlin.jvm.functions.Function1
                public final Object invoke(Object obj) {
                    Unit N0;
                    N0 = t0.N0(t0.this, (String) obj);
                    return N0;
                }
            });
        }
        return Unit.f21504a;
    }

    public static final Unit J0(t0 t0Var, d2.a aVar, j0.WaitForAutocapture waitForAutocapture) {
        TrackingEventsLogger.logVideoStartEvent$default(t0Var.trackingEventsLogger, aVar.getFromStep(), "Stream", null, false, 12, null);
        waitForAutocapture.U().invoke();
        return Unit.f21504a;
    }

    public static final Unit K0(k.a aVar, final ks.a aVar2) {
        ln.r c10;
        ln.h d10 = aVar.d();
        c10 = ln.b0.c(null, new Function1() { // from class: yo.l0
            @Override // kotlin.jvm.functions.Function1
            public final Object invoke(Object obj) {
                Unit L0;
                L0 = t0.L0(ks.a.this, (r.c) obj);
                return L0;
            }
        }, 1, null);
        d10.a(c10);
        return Unit.f21504a;
    }

    public static final Unit L0(ks.a aVar, r.c action) {
        Intrinsics.checkNotNullParameter(action, "$this$action");
        aVar.a();
        action.e(new j0.RestartStep(null, null, null, null, 0, ((vo.j0) action.c()).getCountryCode(), null, null, 223, null));
        return Unit.f21504a;
    }

    public static final Unit M0(t0 t0Var, d2.a aVar) {
        TrackingEventsLogger.logWebRtcIceCompleteEvent$default(t0Var.trackingEventsLogger, aVar.getFromStep(), null, false, 6, null);
        return Unit.f21504a;
    }

    public static final Unit N0(t0 t0Var, String step) {
        Intrinsics.checkNotNullParameter(step, "step");
        TrackingEventsLogger.logVideoStopRequestEvent$default(t0Var.trackingEventsLogger, step, false, 2, null);
        return Unit.f21504a;
    }

    public static final Unit O0(k.a aVar, final ks.a aVar2, r.c action) {
        ln.r c10;
        Intrinsics.checkNotNullParameter(action, "$this$action");
        Object c11 = action.c();
        j0.WaitForAutocapture waitForAutocapture = c11 instanceof j0.WaitForAutocapture ? (j0.WaitForAutocapture) c11 : null;
        if (waitForAutocapture == null || waitForAutocapture.getWebRtcState() == ip.x.f19685a) {
            return Unit.f21504a;
        }
        ln.h d10 = aVar.d();
        c10 = ln.b0.c(null, new Function1() { // from class: yo.e0
            @Override // kotlin.jvm.functions.Function1
            public final Object invoke(Object obj) {
                Unit P0;
                P0 = t0.P0(ks.a.this, (r.c) obj);
                return P0;
            }
        }, 1, null);
        d10.a(c10);
        return Unit.f21504a;
    }

    public static final Unit P0(ks.a aVar, r.c action) {
        Intrinsics.checkNotNullParameter(action, "$this$action");
        if (aVar != null) {
            aVar.a();
        }
        action.e(new j0.RestartStep(null, null, null, null, 0, ((vo.j0) action.c()).getCountryCode(), null, null, 223, null));
        return Unit.f21504a;
    }

    public static final Unit U(vo.j0 j0Var, i3.SideIdPart sideIdPart, vo.f fVar, sn.v vVar, int i10, n.GovernmentIdImage governmentIdImage, r.c action) {
        Intrinsics.checkNotNullParameter(action, "$this$action");
        if (action.c().getClass() != j0Var.getClass()) {
            return Unit.f21504a;
        }
        action.e(new j0.HolographicTorchDelay(sideIdPart, j0Var.D(), j0Var.C(), j0Var.getPartIndex(), j0Var.getBackState(), j0Var.getCountryCode(), fVar, vVar, i10, governmentIdImage, false, Barcode.FORMAT_UPC_E, null));
        return Unit.f21504a;
    }

    public static final Unit V(k.a aVar, final ip.l lVar) {
        ln.r c10;
        ln.h d10 = aVar.d();
        c10 = ln.b0.c(null, new Function1() { // from class: yo.c0
            @Override // kotlin.jvm.functions.Function1
            public final Object invoke(Object obj) {
                Unit W;
                W = t0.W(ip.l.this, (r.c) obj);
                return W;
            }
        }, 1, null);
        d10.a(c10);
        return Unit.f21504a;
    }

    public static final Unit W(ip.l lVar, r.c action) {
        Intrinsics.checkNotNullParameter(action, "$this$action");
        Object c10 = action.c();
        j0.WaitForAutocapture waitForAutocapture = c10 instanceof j0.WaitForAutocapture ? (j0.WaitForAutocapture) c10 : null;
        if (waitForAutocapture != null) {
            action.e(j0.WaitForAutocapture.L(waitForAutocapture, null, null, null, null, null, 0, null, lVar.d() ? ip.x.b : ip.x.f19686c, null, null, false, false, null, null, null, 32639, null));
        }
        return Unit.f21504a;
    }

    public static final Unit X(vo.j0 j0Var, vo.f fVar, n.GovernmentIdImage governmentIdImage, j0.WaitForAutocapture waitForAutocapture, sn.v vVar, r.c action) {
        Intrinsics.checkNotNullParameter(action, "$this$action");
        i3 currentPart = j0Var.getCurrentPart();
        i3.SideIdPart sideIdPart = currentPart instanceof i3.SideIdPart ? (i3.SideIdPart) currentPart : null;
        if (sideIdPart == null) {
            return Unit.f21504a;
        }
        action.e(new j0.ReviewCapturedImage(sideIdPart, ((vo.j0) action.c()).D(), fVar, governmentIdImage, ((vo.j0) action.c()).C(), ((vo.j0) action.c()).getPartIndex(), waitForAutocapture, vVar, null, false, ((vo.j0) action.c()).getCountryCode(), 768, null));
        return Unit.f21504a;
    }

    public static final ln.r Z(final cp.d dVar) {
        ln.r c10;
        c10 = ln.b0.c(null, new Function1() { // from class: yo.p
            @Override // kotlin.jvm.functions.Function1
            public final Object invoke(Object obj) {
                Unit a02;
                a02 = t0.a0(cp.d.this, (r.c) obj);
                return a02;
            }
        }, 1, null);
        return c10;
    }

    public static final Unit a0(cp.d dVar, r.c action) {
        Intrinsics.checkNotNullParameter(action, "$this$action");
        Object c10 = action.c();
        j0.CountdownToCapture countdownToCapture = c10 instanceof j0.CountdownToCapture ? (j0.CountdownToCapture) c10 : null;
        if (countdownToCapture == null) {
            return Unit.f21504a;
        }
        action.e(j0.CountdownToCapture.H(countdownToCapture, null, null, null, null, null, 0, null, null, dVar, 255, null));
        return Unit.f21504a;
    }

    public static final Unit b0(ln.h hVar) {
        hVar.a(d2.b.C0708b.f34598a);
        return Unit.f21504a;
    }

    public static final Unit c0(k.a aVar, ip.l lVar) {
        b3.S(aVar, lVar);
        return Unit.f21504a;
    }

    public static final Unit d0(j0.CountdownToCapture countdownToCapture, t0 t0Var, d2.a aVar, k.a aVar2, ip.l lVar, List absolutePaths, sn.v cameraProperties) {
        Intrinsics.checkNotNullParameter(absolutePaths, "absolutePaths");
        Intrinsics.checkNotNullParameter(cameraProperties, "cameraProperties");
        List<Frame> j32 = countdownToCapture.getIdForReview().j3();
        ArrayList arrayList = new ArrayList(kotlin.collections.q.u(j32, 10));
        Iterator<T> it = j32.iterator();
        while (it.hasNext()) {
            arrayList.add(((Frame) it.next()).getAbsoluteFilePath());
        }
        List w02 = CollectionsKt.w0(arrayList, absolutePaths);
        vo.f captureConfig = countdownToCapture.getCaptureConfig();
        n.GovernmentIdImage idForReview = countdownToCapture.getIdForReview();
        List list = w02;
        ArrayList arrayList2 = new ArrayList(kotlin.collections.q.u(list, 10));
        Iterator it2 = list.iterator();
        while (it2.hasNext()) {
            arrayList2.add(new Frame((String) it2.next(), null, 2, null));
        }
        t0Var.T(aVar, countdownToCapture, aVar2, captureConfig, lVar, cameraProperties, n.GovernmentIdImage.f(idForReview, arrayList2, null, null, null, null, null, 62, null));
        return Unit.f21504a;
    }

    public static final Unit e0(final k.a aVar, final j0.CountdownToCapture countdownToCapture, final d2.a aVar2, final ip.l lVar, final Throwable error) {
        ln.r c10;
        Intrinsics.checkNotNullParameter(error, "error");
        ln.h d10 = aVar.d();
        c10 = ln.b0.c(null, new Function1() { // from class: yo.y
            @Override // kotlin.jvm.functions.Function1
            public final Object invoke(Object obj) {
                Unit f02;
                f02 = t0.f0(j0.CountdownToCapture.this, aVar2, error, aVar, lVar, (r.c) obj);
                return f02;
            }
        }, 1, null);
        d10.a(c10);
        return Unit.f21504a;
    }

    public static final Unit f0(j0.CountdownToCapture countdownToCapture, d2.a aVar, Throwable th2, final k.a aVar2, final ip.l lVar, r.c action) {
        Intrinsics.checkNotNullParameter(action, "$this$action");
        Object c10 = action.c();
        j0.CountdownToCapture countdownToCapture2 = c10 instanceof j0.CountdownToCapture ? (j0.CountdownToCapture) c10 : null;
        if (countdownToCapture2 == null) {
            return Unit.f21504a;
        }
        action.e(new j0.WaitForAutocapture(countdownToCapture.getCurrentPart(), countdownToCapture.D(), countdownToCapture.getCaptureConfig(), b3.O((d2.a) action.b(), countdownToCapture.getCurrentPart().getSide()), countdownToCapture2.C(), countdownToCapture2.getPartIndex(), b3.x(action, false), ip.x.f19686c, aVar.getVideoCaptureConfig().getWebRtcJwt(), th2, false, false, countdownToCapture2.getCountryCode(), null, new Function0() { // from class: yo.d0
            @Override // kotlin.jvm.functions.Function0
            public final Object invoke() {
                Unit g02;
                g02 = t0.g0(k.a.this, lVar);
                return g02;
            }
        }, 11264, null));
        return Unit.f21504a;
    }

    public static final Unit g0(k.a aVar, final ip.l lVar) {
        ln.r c10;
        ln.h d10 = aVar.d();
        c10 = ln.b0.c(null, new Function1() { // from class: yo.k0
            @Override // kotlin.jvm.functions.Function1
            public final Object invoke(Object obj) {
                Unit h02;
                h02 = t0.h0(ip.l.this, (r.c) obj);
                return h02;
            }
        }, 1, null);
        d10.a(c10);
        return Unit.f21504a;
    }

    public static final Unit h0(ip.l lVar, r.c action) {
        Intrinsics.checkNotNullParameter(action, "$this$action");
        Object c10 = action.c();
        j0.WaitForAutocapture waitForAutocapture = c10 instanceof j0.WaitForAutocapture ? (j0.WaitForAutocapture) c10 : null;
        if (waitForAutocapture != null) {
            action.e(j0.WaitForAutocapture.L(waitForAutocapture, null, null, null, null, null, 0, null, lVar.d() ? ip.x.b : ip.x.f19686c, null, null, false, false, null, null, null, 32639, null));
        }
        return Unit.f21504a;
    }

    public static final Unit i0(t0 t0Var, k.a aVar, d2.a aVar2, ip.l lVar) {
        b3.U(t0Var.applicationContext, aVar, aVar2, lVar.c(aVar2));
        return Unit.f21504a;
    }

    public static final Unit k0(ln.h hVar) {
        hVar.a(d2.b.C0708b.f34598a);
        return Unit.f21504a;
    }

    public static final Unit l0(k.a aVar, ip.l lVar) {
        b3.S(aVar, lVar);
        return Unit.f21504a;
    }

    public static final Unit m0(t0 t0Var, k.a aVar, d2.a aVar2) {
        b3.U(t0Var.applicationContext, aVar, aVar2, true);
        return Unit.f21504a;
    }

    public static final Unit o0(k.a aVar, AlertScreen.b it) {
        ln.r c10;
        Intrinsics.checkNotNullParameter(it, "it");
        ln.h d10 = aVar.d();
        c10 = ln.b0.c(null, new Function1() { // from class: yo.m
            @Override // kotlin.jvm.functions.Function1
            public final Object invoke(Object obj) {
                Unit p02;
                p02 = t0.p0((r.c) obj);
                return p02;
            }
        }, 1, null);
        d10.a(c10);
        return Unit.f21504a;
    }

    public static final Unit p0(r.c action) {
        Intrinsics.checkNotNullParameter(action, "$this$action");
        vo.j0 j0Var = (vo.j0) action.c();
        if (j0Var instanceof j0.WaitForAutocapture) {
            action.e(j0.WaitForAutocapture.L((j0.WaitForAutocapture) j0Var, null, null, null, null, null, 0, null, null, null, null, false, false, null, null, null, 32255, null));
        }
        return Unit.f21504a;
    }

    public static final Unit q0(j0.WaitForAutocapture waitForAutocapture, vo.f fVar, t0 t0Var, d2.a aVar, k.a aVar2, ip.l lVar, List absolutePaths, sn.v cameraProperties) {
        Intrinsics.checkNotNullParameter(absolutePaths, "absolutePaths");
        Intrinsics.checkNotNullParameter(cameraProperties, "cameraProperties");
        List list = absolutePaths;
        ArrayList arrayList = new ArrayList(kotlin.collections.q.u(list, 10));
        Iterator it = list.iterator();
        while (it.hasNext()) {
            arrayList.add(new Frame((String) it.next(), null, 2, null));
        }
        t0Var.T(aVar, waitForAutocapture, aVar2, waitForAutocapture.getCaptureConfig(), lVar, cameraProperties, new n.GovernmentIdImage(arrayList, b3.e0(waitForAutocapture.getCurrentPart().getSide()), vo.g.b(fVar), n.a.b, null, null, 32, null));
        return Unit.f21504a;
    }

    public static final Unit r0(ln.h hVar) {
        hVar.a(d2.b.C0708b.f34598a);
        return Unit.f21504a;
    }

    public static final Unit s0(k.a aVar, ip.l lVar) {
        b3.S(aVar, lVar);
        return Unit.f21504a;
    }

    public static final Unit t0(k.a aVar, final Throwable error) {
        ln.r c10;
        Intrinsics.checkNotNullParameter(error, "error");
        ln.h d10 = aVar.d();
        c10 = ln.b0.c(null, new Function1() { // from class: yo.q
            @Override // kotlin.jvm.functions.Function1
            public final Object invoke(Object obj) {
                Unit u02;
                u02 = t0.u0(error, (r.c) obj);
                return u02;
            }
        }, 1, null);
        d10.a(c10);
        return Unit.f21504a;
    }

    public static final Unit u0(Throwable th2, r.c action) {
        Intrinsics.checkNotNullParameter(action, "$this$action");
        Object c10 = action.c();
        j0.WaitForAutocapture waitForAutocapture = c10 instanceof j0.WaitForAutocapture ? (j0.WaitForAutocapture) c10 : null;
        if (waitForAutocapture == null) {
            return Unit.f21504a;
        }
        action.e(j0.WaitForAutocapture.L(waitForAutocapture, null, null, null, y3.b.a.b, null, 0, null, null, null, th2, false, false, null, null, null, 32247, null));
        return Unit.f21504a;
    }

    public static final Unit v0(t0 t0Var, final j0.WaitForAutocapture waitForAutocapture, k.a aVar) {
        ln.r c10;
        TrackingEventsLogger.logGovernmentIdStateEvent$default(t0Var.trackingEventsLogger, new GovernmentIdStateEventData(GovIdCaptureState.TAKING_PHOTO, GovIdCaptureMethod.MANUAL, b3.d0(waitForAutocapture.getCurrentPart().getSide()), null, 8, null), false, 2, null);
        ln.h d10 = aVar.d();
        c10 = ln.b0.c(null, new Function1() { // from class: yo.z
            @Override // kotlin.jvm.functions.Function1
            public final Object invoke(Object obj) {
                Unit w02;
                w02 = t0.w0(j0.WaitForAutocapture.this, (r.c) obj);
                return w02;
            }
        }, 1, null);
        d10.a(c10);
        return Unit.f21504a;
    }

    public static final Unit w0(j0.WaitForAutocapture waitForAutocapture, r.c action) {
        Intrinsics.checkNotNullParameter(action, "$this$action");
        action.e(j0.WaitForAutocapture.L(waitForAutocapture, null, null, null, y3.b.a.f35071a, null, 0, null, null, null, null, false, false, null, null, null, 32759, null));
        return Unit.f21504a;
    }

    public static final Unit x0(t0 t0Var, k.a aVar, d2.a aVar2, ip.l lVar) {
        b3.U(t0Var.applicationContext, aVar, aVar2, lVar.c(aVar2));
        return Unit.f21504a;
    }

    public static final ln.r y0(final t0 t0Var, final j0.WaitForAutocapture waitForAutocapture, final vo.f fVar, zt.n nVar) {
        ln.r c10;
        ln.r c11;
        ln.r c12;
        Object value = nVar.getValue();
        Throwable e10 = zt.n.e(value);
        if (e10 == null) {
            final n.GovernmentIdImage governmentIdImage = (n.GovernmentIdImage) value;
            c12 = ln.b0.c(null, new Function1() { // from class: yo.u
                @Override // kotlin.jvm.functions.Function1
                public final Object invoke(Object obj) {
                    Unit z02;
                    z02 = t0.z0(t0.this, waitForAutocapture, fVar, governmentIdImage, (r.c) obj);
                    return z02;
                }
            }, 1, null);
            return c12;
        }
        String message = e10.getMessage();
        if (message == null || !StringsKt.a0(message, "ENOSPC", false, 2, null)) {
            c10 = ln.b0.c(null, new Function1() { // from class: yo.x
                @Override // kotlin.jvm.functions.Function1
                public final Object invoke(Object obj) {
                    Unit B0;
                    B0 = t0.B0(j0.WaitForAutocapture.this, (r.c) obj);
                    return B0;
                }
            }, 1, null);
            return c10;
        }
        c11 = ln.b0.c(null, new Function1() { // from class: yo.v
            @Override // kotlin.jvm.functions.Function1
            public final Object invoke(Object obj) {
                Unit A0;
                A0 = t0.A0((r.c) obj);
                return A0;
            }
        }, 1, null);
        return c11;
    }

    public static final Unit z0(t0 t0Var, j0.WaitForAutocapture waitForAutocapture, vo.f fVar, n.GovernmentIdImage governmentIdImage, r.c action) {
        Intrinsics.checkNotNullParameter(action, "$this$action");
        TrackingEventsLogger.logGovernmentIdStateEvent$default(t0Var.trackingEventsLogger, new GovernmentIdStateEventData(GovIdCaptureState.TAKING_PHOTO, GovIdCaptureMethod.AUTO, b3.d0(waitForAutocapture.getCurrentPart().getSide()), null, 8, null), false, 2, null);
        Object c10 = action.c();
        j0.WaitForAutocapture waitForAutocapture2 = c10 instanceof j0.WaitForAutocapture ? (j0.WaitForAutocapture) c10 : null;
        if (waitForAutocapture2 == null) {
            return Unit.f21504a;
        }
        action.e(new j0.CountdownToCapture(waitForAutocapture.getCurrentPart(), ((vo.j0) action.c()).D(), fVar, governmentIdImage, waitForAutocapture2.C(), waitForAutocapture2.getPartIndex(), b3.x(action, false), waitForAutocapture2.getCountryCode(), waitForAutocapture2.getHint()));
        return Unit.f21504a;
    }

    public final void G0(final d2.a renderProps, final j0.WaitForAutocapture renderState, final ln.k<? super d2.a, vo.j0, ? extends d2.b, ? extends Object>.a context, final ks.a webRtcManager) {
        ln.w.l(context, this.webRtcWorkerFactory.a(renderProps.getVideoCaptureConfig().getWebRtcJwt()), kotlin.jvm.internal.d0.k(js.b.class), BuildConfig.FLAVOR, new Function1() { // from class: yo.k
            @Override // kotlin.jvm.functions.Function1
            public final Object invoke(Object obj) {
                ln.r H0;
                H0 = t0.H0(t0.this, webRtcManager, renderState, renderProps, context, (b.AbstractC0389b) obj);
                return H0;
            }
        });
    }

    public final void T(d2.a renderProps, final vo.j0 renderState, final ln.k<? super d2.a, vo.j0, ? extends d2.b, ? extends Object>.a context, final vo.f captureConfig, final ip.l videoCaptureHelper, final sn.v cameraProperties, final n.GovernmentIdImage capturedId) {
        ln.r<? super Object, vo.j0, ? extends Object> c10;
        ln.r<? super Object, vo.j0, ? extends Object> c11;
        boolean z10 = false;
        if (!(renderState instanceof j0.HolographicTorchDelay)) {
            TrackingEventsLogger trackingEventsLogger = this.trackingEventsLogger;
            GovIdCaptureState govIdCaptureState = GovIdCaptureState.CAPTURED_PHOTO;
            GovIdCaptureMethod b10 = vo.x.b(capturedId.getCaptureMethod());
            IdConfig.e Q = b3.Q(renderState.getCurrentPart());
            TrackingEventsLogger.logGovernmentIdStateEvent$default(trackingEventsLogger, new GovernmentIdStateEventData(govIdCaptureState, b10, Q != null ? b3.d0(Q) : null, null, 8, null), false, 2, null);
        }
        Integer holographicTorchEnabledDurationMs = renderProps.getHolographicTorchEnabledDurationMs();
        int intValue = holographicTorchEnabledDurationMs != null ? holographicTorchEnabledDurationMs.intValue() : 0;
        i3 currentPart = renderState.getCurrentPart();
        i3.SideIdPart sideIdPart = currentPart instanceof i3.SideIdPart ? (i3.SideIdPart) currentPart : null;
        IdConfig c12 = vo.g.c(captureConfig);
        if (videoCaptureHelper.c(renderProps) && intValue > 0 && renderState.D().isEmpty() && sideIdPart != null) {
            z10 = true;
        }
        if (!(renderState instanceof j0.HolographicTorchDelay) && z10) {
            ln.h<ln.r<? super Object, vo.j0, ? extends Object>> d10 = context.d();
            final int i10 = intValue;
            final i3.SideIdPart sideIdPart2 = sideIdPart;
            c11 = ln.b0.c(null, new Function1() { // from class: yo.r
                @Override // kotlin.jvm.functions.Function1
                public final Object invoke(Object obj) {
                    Unit U;
                    U = t0.U(vo.j0.this, sideIdPart2, captureConfig, cameraProperties, i10, capturedId, (r.c) obj);
                    return U;
                }
            }, 1, null);
            d10.a(c11);
            return;
        }
        boolean c13 = videoCaptureHelper.c(renderProps);
        boolean shouldSkipReviewScreen = renderProps.getShouldSkipReviewScreen();
        if (c12 != null && (c13 || shouldSkipReviewScreen)) {
            b3.W(renderState, context, renderProps, capturedId, c12, videoCaptureHelper, cameraProperties, (r26 & Barcode.FORMAT_ITF) != 0, (r26 & Barcode.FORMAT_QR_CODE) != 0 ? renderState.C() : null, (r26 & Barcode.FORMAT_UPC_A) != 0 ? renderState.getPartIndex() : 0, (r26 & Barcode.FORMAT_UPC_E) != 0 ? null : null, (r26 & Barcode.FORMAT_PDF417) != 0 ? renderState.getCountryCode() : null);
        } else {
            if (sideIdPart == null) {
                return;
            }
            final j0.WaitForAutocapture waitForAutocapture = new j0.WaitForAutocapture(sideIdPart, renderState.D(), captureConfig, b3.O(renderProps, sideIdPart.getSide()), renderState.C(), renderState.getPartIndex(), renderState.getBackState(), ip.x.f19686c, renderProps.getVideoCaptureConfig().getWebRtcJwt(), null, false, false, renderState.getCountryCode(), null, new Function0() { // from class: yo.s
                @Override // kotlin.jvm.functions.Function0
                public final Object invoke() {
                    Unit V;
                    V = t0.V(k.a.this, videoCaptureHelper);
                    return V;
                }
            }, 11776, null);
            ln.h<ln.r<? super Object, vo.j0, ? extends Object>> d11 = context.d();
            c10 = ln.b0.c(null, new Function1() { // from class: yo.t
                @Override // kotlin.jvm.functions.Function1
                public final Object invoke(Object obj) {
                    Unit X;
                    X = t0.X(vo.j0.this, captureConfig, capturedId, waitForAutocapture, cameraProperties, (r.c) obj);
                    return X;
                }
            }, 1, null);
            d11.a(c10);
        }
    }

    @NotNull
    public final Object Y(@NotNull final d2.a renderProps, @NotNull final j0.CountdownToCapture renderState, @NotNull final ln.k<? super d2.a, vo.j0, ? extends d2.b, ? extends Object>.a context, @NotNull final ip.l videoCaptureHelper, @NotNull final ln.h<? super d2.b> sink) {
        y3.b f10;
        Intrinsics.checkNotNullParameter(renderProps, "renderProps");
        Intrinsics.checkNotNullParameter(renderState, "renderState");
        Intrinsics.checkNotNullParameter(context, "context");
        Intrinsics.checkNotNullParameter(videoCaptureHelper, "videoCaptureHelper");
        Intrinsics.checkNotNullParameter(sink, "sink");
        IdConfig.IdSideConfig d10 = vo.g.d(renderState.getCaptureConfig(), renderState.getCurrentPart().getSide());
        ln.w.l(context, this.governmentIdHintWorkerFactory.a(renderState.getCurrentPart().getSide()), kotlin.jvm.internal.d0.k(GovernmentIdHintWorker.class), BuildConfig.FLAVOR, new Function1() { // from class: yo.h0
            @Override // kotlin.jvm.functions.Function1
            public final Object invoke(Object obj) {
                ln.r Z;
                Z = t0.Z((cp.d) obj);
                return Z;
            }
        });
        String K = b3.K(renderProps.getStrings(), renderState.getCurrentPart().getSide(), vo.g.b(renderState.getCaptureConfig()), renderState.getCountryCode());
        String J = b3.J(renderProps.getStrings(), renderState.getCurrentPart().getSide(), vo.g.b(renderState.getCaptureConfig()), renderState.getCountryCode());
        String capturing = renderProps.getStrings().getCapturing();
        IdConfig.e side = renderState.getCurrentPart().getSide();
        y3.b.a aVar = y3.b.a.f35071a;
        y3.f overlay = d10.getOverlay();
        dp.e a10 = vo.g.a(renderState.getCaptureConfig());
        ir.a b10 = this.navigationStateManager.b();
        List<sn.e> a11 = d10.getAutoCaptureConfig().getRuleSet().a();
        int partIndex = renderState.getPartIndex();
        int imageCaptureCount = renderProps.getImageCaptureCount() - 1;
        Function1 A = b3.A(context, false, 1, null);
        zn.a e10 = videoCaptureHelper.e(renderProps);
        String R = b3.R(renderProps.getStrings(), renderState.getHint());
        ks.a webRtcManager = videoCaptureHelper.getWebRtcManager();
        f10 = vo.i0.f(renderProps, K, J, capturing, aVar, overlay, a10, side, b10, (r70 & Barcode.FORMAT_UPC_A) != 0 ? new Function2() { // from class: vo.d0
            @Override // kotlin.jvm.functions.Function2
            public final Object invoke(Object obj, Object obj2) {
                Unit h10;
                h10 = i0.h((List) obj, (sn.v) obj2);
                return h10;
            }
        } : null, new Function0() { // from class: yo.m0
            @Override // kotlin.jvm.functions.Function0
            public final Object invoke() {
                Unit b02;
                b02 = t0.b0(ln.h.this);
                return b02;
            }
        }, new Function0() { // from class: yo.n0
            @Override // kotlin.jvm.functions.Function0
            public final Object invoke() {
                Unit c02;
                c02 = t0.c0(k.a.this, videoCaptureHelper);
                return c02;
            }
        }, true, a11, renderState, partIndex, this.cameraXControllerFactory, this.camera2ControllerFactory, (262144 & r70) != 0 ? new Function2() { // from class: vo.e0
            @Override // kotlin.jvm.functions.Function2
            public final Object invoke(Object obj, Object obj2) {
                Unit i10;
                i10 = i0.i((List) obj, (sn.v) obj2);
                return i10;
            }
        } : new Function2() { // from class: yo.o0
            @Override // kotlin.jvm.functions.Function2
            public final Object invoke(Object obj, Object obj2) {
                Unit d02;
                d02 = t0.d0(j0.CountdownToCapture.this, this, renderProps, context, videoCaptureHelper, (List) obj, (sn.v) obj2);
                return d02;
            }
        }, (524288 & r70) != 0 ? new Function1() { // from class: vo.f0
            @Override // kotlin.jvm.functions.Function1
            public final Object invoke(Object obj) {
                Unit j10;
                j10 = i0.j((Throwable) obj);
                return j10;
            }
        } : new Function1() { // from class: yo.p0
            @Override // kotlin.jvm.functions.Function1
            public final Object invoke(Object obj) {
                Unit e02;
                e02 = t0.e0(k.a.this, renderState, renderProps, videoCaptureHelper, (Throwable) obj);
                return e02;
            }
        }, A, (2097152 & r70) != 0 ? zn.a.f39327c : e10, (4194304 & r70) != 0, (8388608 & r70) != 0 ? false : false, (16777216 & r70) != 0 ? false : false, (33554432 & r70) != 0 ? new Function2() { // from class: vo.g0
            @Override // kotlin.jvm.functions.Function2
            public final Object invoke(Object obj, Object obj2) {
                Unit k10;
                k10 = i0.k((File) obj, (sn.v) obj2);
                return k10;
            }
        } : null, (67108864 & r70) != 0 ? new Function0() { // from class: vo.h0
            @Override // kotlin.jvm.functions.Function0
            public final Object invoke() {
                Unit l10;
                l10 = i0.l();
                return l10;
            }
        } : null, new Function0() { // from class: yo.q0
            @Override // kotlin.jvm.functions.Function0
            public final Object invoke() {
                Unit i02;
                i02 = t0.i0(t0.this, context, renderProps, videoCaptureHelper);
                return i02;
            }
        }, (268435456 & r70) != 0 ? renderProps.getImageCaptureCount() : imageCaptureCount, (536870912 & r70) != 0 ? null : R, (1073741824 & r70) != 0 ? null : null, (r70 & Integer.MIN_VALUE) != 0 ? null : webRtcManager, (r71 & 1) != 0 ? false : false, (r71 & 2) != 0 ? kr.l.f21779a : null);
        return new AlertContainerScreen(y1.c(f10), null, 2, null);
    }

    @NotNull
    public final Object j0(@NotNull d2.a renderProps, @NotNull j0.HolographicTorchDelay renderState, @NotNull final ln.k<? super d2.a, vo.j0, ? extends d2.b, ? extends Object>.a context, @NotNull final ip.l videoCaptureHelper, @NotNull final ln.h<? super d2.b> sink) {
        final t0 t0Var;
        y3.b f10;
        final d2.a renderProps2 = renderProps;
        Intrinsics.checkNotNullParameter(renderProps2, "renderProps");
        Intrinsics.checkNotNullParameter(renderState, "renderState");
        Intrinsics.checkNotNullParameter(context, "context");
        Intrinsics.checkNotNullParameter(videoCaptureHelper, "videoCaptureHelper");
        Intrinsics.checkNotNullParameter(sink, "sink");
        context.b("holographic_torch_delay", new a(renderState, context, null));
        if (renderState.getHolographicTorchEnabled()) {
            t0Var = this;
        } else {
            b bVar = new b(renderProps2, renderState, context, videoCaptureHelper, null);
            t0Var = this;
            renderProps2 = renderProps2;
            context.b("holographic_torch_complete", bVar);
        }
        vo.f captureConfig = renderState.getCaptureConfig();
        IdConfig.IdSideConfig d10 = vo.g.d(captureConfig, renderState.getCurrentPart().getSide());
        String b10 = vo.g.b(captureConfig);
        IdConfig.e side = renderState.getCurrentPart().getSide();
        String K = b3.K(renderProps2.getStrings(), side, b10, renderState.getCountryCode());
        String J = b3.J(renderProps2.getStrings(), side, b10, renderState.getCountryCode());
        String capturing = renderProps2.getStrings().getCapturing();
        y3.b.a aVar = y3.b.a.f35071a;
        y3.f overlay = d10.getOverlay();
        dp.e a10 = vo.g.a(captureConfig);
        ir.a b11 = t0Var.navigationStateManager.b();
        List k10 = kotlin.collections.p.k();
        int partIndex = renderState.getPartIndex();
        Function1 A = b3.A(context, false, 1, null);
        zn.a e10 = videoCaptureHelper.e(renderProps2);
        ks.a webRtcManager = videoCaptureHelper.getWebRtcManager();
        f10 = vo.i0.f(renderProps2, K, J, capturing, aVar, overlay, a10, side, b11, (r70 & Barcode.FORMAT_UPC_A) != 0 ? new Function2() { // from class: vo.d0
            @Override // kotlin.jvm.functions.Function2
            public final Object invoke(Object obj, Object obj2) {
                Unit h10;
                h10 = i0.h((List) obj, (sn.v) obj2);
                return h10;
            }
        } : null, new Function0() { // from class: yo.a
            @Override // kotlin.jvm.functions.Function0
            public final Object invoke() {
                Unit k02;
                k02 = t0.k0(ln.h.this);
                return k02;
            }
        }, new Function0() { // from class: yo.l
            @Override // kotlin.jvm.functions.Function0
            public final Object invoke() {
                Unit l02;
                l02 = t0.l0(k.a.this, videoCaptureHelper);
                return l02;
            }
        }, false, k10, renderState, partIndex, t0Var.cameraXControllerFactory, t0Var.camera2ControllerFactory, (262144 & r70) != 0 ? new Function2() { // from class: vo.e0
            @Override // kotlin.jvm.functions.Function2
            public final Object invoke(Object obj, Object obj2) {
                Unit i10;
                i10 = i0.i((List) obj, (sn.v) obj2);
                return i10;
            }
        } : null, (524288 & r70) != 0 ? new Function1() { // from class: vo.f0
            @Override // kotlin.jvm.functions.Function1
            public final Object invoke(Object obj) {
                Unit j10;
                j10 = i0.j((Throwable) obj);
                return j10;
            }
        } : null, A, (2097152 & r70) != 0 ? zn.a.f39327c : e10, (4194304 & r70) != 0, (8388608 & r70) != 0 ? false : false, (16777216 & r70) != 0 ? false : false, (33554432 & r70) != 0 ? new Function2() { // from class: vo.g0
            @Override // kotlin.jvm.functions.Function2
            public final Object invoke(Object obj, Object obj2) {
                Unit k102;
                k102 = i0.k((File) obj, (sn.v) obj2);
                return k102;
            }
        } : null, (67108864 & r70) != 0 ? new Function0() { // from class: vo.h0
            @Override // kotlin.jvm.functions.Function0
            public final Object invoke() {
                Unit l10;
                l10 = i0.l();
                return l10;
            }
        } : null, new Function0() { // from class: yo.w
            @Override // kotlin.jvm.functions.Function0
            public final Object invoke() {
                Unit m02;
                m02 = t0.m0(t0.this, context, renderProps2);
                return m02;
            }
        }, (268435456 & r70) != 0 ? renderProps2.getImageCaptureCount() : 0, (536870912 & r70) != 0 ? null : null, (1073741824 & r70) != 0 ? null : null, (r70 & Integer.MIN_VALUE) != 0 ? null : webRtcManager, (r71 & 1) != 0 ? false : renderState.getHolographicTorchEnabled(), (r71 & 2) != 0 ? kr.l.f21779a : null);
        return new AlertContainerScreen(y1.c(f10), null, 2, null);
    }

    @NotNull
    public final Object n0(@NotNull final d2.a renderProps, @NotNull final j0.WaitForAutocapture renderState, @NotNull final ln.k<? super d2.a, vo.j0, ? extends d2.b, ? extends Object>.a context, @NotNull final ip.l videoCaptureHelper, @NotNull final ln.h<? super d2.b> sink) {
        y3.b f10;
        ln.k<? super d2.a, vo.j0, ? extends d2.b, ? extends Object>.a aVar;
        ip.l lVar;
        cq.c<Object, Object> c10;
        Intrinsics.checkNotNullParameter(renderProps, "renderProps");
        Intrinsics.checkNotNullParameter(renderState, "renderState");
        Intrinsics.checkNotNullParameter(context, "context");
        Intrinsics.checkNotNullParameter(videoCaptureHelper, "videoCaptureHelper");
        Intrinsics.checkNotNullParameter(sink, "sink");
        final vo.f captureConfig = renderState.getCaptureConfig();
        IdConfig.IdSideConfig d10 = vo.g.d(captureConfig, renderState.getCurrentPart().getSide());
        String b10 = vo.g.b(captureConfig);
        boolean z10 = captureConfig instanceof f.AutoClassifyConfig;
        ln.w.l(context, this.governmentIdAnalyzeWorkerFactory.a(renderState.getCurrentPart().getSide(), b10), kotlin.jvm.internal.d0.k(GovernmentIdAnalyzeWorker.class), BuildConfig.FLAVOR, new Function1() { // from class: yo.r0
            @Override // kotlin.jvm.functions.Function1
            public final Object invoke(Object obj) {
                ln.r y02;
                y02 = t0.y0(t0.this, renderState, captureConfig, (zt.n) obj);
                return y02;
            }
        });
        ln.w.l(context, this.governmentIdHintWorkerFactory.a(renderState.getCurrentPart().getSide()), kotlin.jvm.internal.d0.k(GovernmentIdHintWorker.class), BuildConfig.FLAVOR, new Function1() { // from class: yo.b
            @Override // kotlin.jvm.functions.Function1
            public final Object invoke(Object obj) {
                ln.r C0;
                C0 = t0.C0((cp.d) obj);
                return C0;
            }
        });
        zn.a e10 = videoCaptureHelper.e(renderProps);
        zn.a aVar2 = zn.a.f39326a;
        boolean z11 = e10 == aVar2 && !videoCaptureHelper.d();
        if (d10.getManualCaptureConfig().getIsEnabled() && !z11) {
            ln.w.l(context, o.Companion.b(ln.o.INSTANCE, kotlin.ranges.d.d(d10.getManualCaptureConfig().getDelayMs(), 0L), null, 2, null), kotlin.jvm.internal.d0.l(ln.o.class, KTypeProjection.INSTANCE.a(kotlin.jvm.internal.d0.k(Unit.class))), d10.getSideKey(), new Function1() { // from class: yo.c
                @Override // kotlin.jvm.functions.Function1
                public final Object invoke(Object obj) {
                    ln.r E0;
                    E0 = t0.E0(j0.WaitForAutocapture.this, (Unit) obj);
                    return E0;
                }
            });
        }
        ArrayList arrayList = new ArrayList();
        if (renderState.getError() != null) {
            Map g10 = kotlin.collections.j0.g(zt.s.a(AlertScreen.a.POSITIVE, this.applicationContext.getString(android.R.string.ok)));
            String string = this.applicationContext.getString(jq.g.f20882n);
            Intrinsics.checkNotNullExpressionValue(string, "getString(...)");
            arrayList.add(new AlertScreen(g10, string, null, false, new Function1() { // from class: yo.d
                @Override // kotlin.jvm.functions.Function1
                public final Object invoke(Object obj) {
                    Unit o02;
                    o02 = t0.o0(k.a.this, (AlertScreen.b) obj);
                    return o02;
                }
            }, 12, null));
        }
        String K = b3.K(renderProps.getStrings(), renderState.getCurrentPart().getSide(), b10, renderState.getCountryCode());
        String J = b3.J(renderProps.getStrings(), renderState.getCurrentPart().getSide(), b10, renderState.getCountryCode());
        String P = b3.P(renderProps.getStrings(), renderState.getCurrentPart().getSide(), b10, renderState.getCountryCode(), z10);
        IdConfig.e side = renderState.getCurrentPart().getSide();
        y3.b.a manualCapture = renderState.getManualCapture();
        y3.f overlay = d10.getOverlay();
        dp.e a10 = vo.g.a(captureConfig);
        ir.a b11 = this.navigationStateManager.b();
        List<sn.e> a11 = d10.getAutoCaptureConfig().getRuleSet().a();
        int partIndex = renderState.getPartIndex();
        Function1 A = b3.A(context, false, 1, null);
        zn.a e11 = videoCaptureHelper.e(renderProps);
        String R = b3.R(renderProps.getStrings(), renderState.getHint());
        zo.i L = b3.L(renderProps, renderState.getCurrentPart().getSide());
        ks.a webRtcManager = videoCaptureHelper.getWebRtcManager();
        f10 = vo.i0.f(renderProps, K, J, P, manualCapture, overlay, a10, side, b11, (r70 & Barcode.FORMAT_UPC_A) != 0 ? new Function2() { // from class: vo.d0
            @Override // kotlin.jvm.functions.Function2
            public final Object invoke(Object obj, Object obj2) {
                Unit h10;
                h10 = i0.h((List) obj, (sn.v) obj2);
                return h10;
            }
        } : new Function2() { // from class: yo.e
            @Override // kotlin.jvm.functions.Function2
            public final Object invoke(Object obj, Object obj2) {
                Unit q02;
                q02 = t0.q0(j0.WaitForAutocapture.this, captureConfig, this, renderProps, context, videoCaptureHelper, (List) obj, (sn.v) obj2);
                return q02;
            }
        }, new Function0() { // from class: yo.f
            @Override // kotlin.jvm.functions.Function0
            public final Object invoke() {
                Unit r02;
                r02 = t0.r0(ln.h.this);
                return r02;
            }
        }, new Function0() { // from class: yo.g
            @Override // kotlin.jvm.functions.Function0
            public final Object invoke() {
                Unit s02;
                s02 = t0.s0(k.a.this, videoCaptureHelper);
                return s02;
            }
        }, false, a11, renderState, partIndex, this.cameraXControllerFactory, this.camera2ControllerFactory, (262144 & r70) != 0 ? new Function2() { // from class: vo.e0
            @Override // kotlin.jvm.functions.Function2
            public final Object invoke(Object obj, Object obj2) {
                Unit i10;
                i10 = i0.i((List) obj, (sn.v) obj2);
                return i10;
            }
        } : null, (524288 & r70) != 0 ? new Function1() { // from class: vo.f0
            @Override // kotlin.jvm.functions.Function1
            public final Object invoke(Object obj) {
                Unit j10;
                j10 = i0.j((Throwable) obj);
                return j10;
            }
        } : new Function1() { // from class: yo.h
            @Override // kotlin.jvm.functions.Function1
            public final Object invoke(Object obj) {
                Unit t02;
                t02 = t0.t0(k.a.this, (Throwable) obj);
                return t02;
            }
        }, A, (2097152 & r70) != 0 ? zn.a.f39327c : e11, (4194304 & r70) != 0, (8388608 & r70) != 0 ? false : false, (16777216 & r70) != 0 ? false : false, (33554432 & r70) != 0 ? new Function2() { // from class: vo.g0
            @Override // kotlin.jvm.functions.Function2
            public final Object invoke(Object obj, Object obj2) {
                Unit k102;
                k102 = i0.k((File) obj, (sn.v) obj2);
                return k102;
            }
        } : null, (67108864 & r70) != 0 ? new Function0() { // from class: vo.h0
            @Override // kotlin.jvm.functions.Function0
            public final Object invoke() {
                Unit l10;
                l10 = i0.l();
                return l10;
            }
        } : new Function0() { // from class: yo.i
            @Override // kotlin.jvm.functions.Function0
            public final Object invoke() {
                Unit v02;
                v02 = t0.v0(t0.this, renderState, context);
                return v02;
            }
        }, new Function0() { // from class: yo.j
            @Override // kotlin.jvm.functions.Function0
            public final Object invoke() {
                Unit x02;
                x02 = t0.x0(t0.this, context, renderProps, videoCaptureHelper);
                return x02;
            }
        }, (268435456 & r70) != 0 ? renderProps.getImageCaptureCount() : 0, (536870912 & r70) != 0 ? null : R, (1073741824 & r70) != 0 ? null : L, (r70 & Integer.MIN_VALUE) != 0 ? null : webRtcManager, (r71 & 1) != 0 ? false : false, (r71 & 2) != 0 ? kr.l.f21779a : null);
        if (renderState.getCheckCameraPermissions()) {
            c10 = b3.j0(f10, this.applicationContext, context, renderProps, true, this.permissionRequestWorkflow);
        } else {
            if (renderState.getCheckAudioPermissions()) {
                lVar = videoCaptureHelper;
                if (lVar.c(renderProps) && xq.g.f(this.applicationContext) && renderProps.getVideoCaptureConfig().getRecordAudio()) {
                    c10 = b3.f0(f10, this.applicationContext, context, renderProps, true, this.permissionRequestWorkflow);
                } else {
                    aVar = context;
                }
            } else {
                aVar = context;
                lVar = videoCaptureHelper;
            }
            if (lVar.e(renderProps) == aVar2 && renderState.getWebRtcState() == ip.x.f19686c) {
                G0(renderProps, renderState, aVar, lVar.getWebRtcManager());
                c10 = y1.c(f10);
            } else {
                c10 = y1.c(f10);
            }
        }
        return new AlertContainerScreen(c10, arrayList);
    }
}
