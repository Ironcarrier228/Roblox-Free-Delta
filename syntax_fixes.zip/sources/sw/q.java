package sw;

import ew.l0;
import java.io.IOException;
import java.util.Objects;
import mv.e;
import mv.f0;
import mv.h0;
import mv.i0;

/* loaded from: classes2.dex */
public final class q<T> implements d<T> {

    /* renamed from: a, reason: collision with root package name */
    public final w f31981a;
    public final Object b;

    /* renamed from: c, reason: collision with root package name */
    public final Object[] f31982c;

    /* renamed from: d, reason: collision with root package name */
    public final e.a f31983d;

    /* renamed from: e, reason: collision with root package name */
    public final h<i0, T> f31984e;

    /* renamed from: f, reason: collision with root package name */
    public volatile boolean f31985f;

    /* renamed from: g, reason: collision with root package name */
    public mv.e f31986g;

    /* renamed from: h, reason: collision with root package name */
    public Throwable f31987h;

    /* renamed from: i, reason: collision with root package name */
    public boolean f31988i;

    public class a implements mv.f {

        /* renamed from: a, reason: collision with root package name */
        public final /* synthetic */ f f31989a;

        public a(f fVar) {
            this.f31989a = fVar;
        }

        public final void a(Throwable th2) {
            try {
                this.f31989a.a(q.this, th2);
            } catch (Throwable th3) {
                c0.t(th3);
                th3.printStackTrace();
            }
        }

        @Override // mv.f
        public void onFailure(mv.e eVar, IOException iOException) {
            a(iOException);
        }

        @Override // mv.f
        public void onResponse(mv.e eVar, h0 h0Var) {
            try {
                try {
                    this.f31989a.b(q.this, q.this.e(h0Var));
                } catch (Throwable th2) {
                    c0.t(th2);
                    th2.printStackTrace();
                }
            } catch (Throwable th3) {
                c0.t(th3);
                a(th3);
            }
        }
    }

    public static final class b extends i0 {

        /* renamed from: d, reason: collision with root package name */
        public final i0 f31990d;

        /* renamed from: e, reason: collision with root package name */
        public final ew.g f31991e;

        /* renamed from: f, reason: collision with root package name */
        public IOException f31992f;

        public class a extends ew.n {
            public a(l0 l0Var) {
                super(l0Var);
            }

            @Override // ew.n, ew.l0
            public long f3(ew.e eVar, long j10) {
                try {
                    return super.f3(eVar, j10);
                } catch (IOException e10) {
                    b.this.f31992f = e10;
                    throw e10;
                }
            }
        }

        public b(i0 i0Var) {
            this.f31990d = i0Var;
            this.f31991e = ew.v.c(new a(i0Var.getType()));
        }

        @Override // mv.i0, java.io.Closeable, java.lang.AutoCloseable
        public void close() {
            this.f31990d.close();
        }

        @Override // mv.i0
        /* renamed from: e */
        public long getContentLength() {
            return this.f31990d.getContentLength();
        }

        @Override // mv.i0
        /* renamed from: f */
        public mv.b0 getMediaType() {
            return this.f31990d.getMediaType();
        }

        public void k() {
            IOException iOException = this.f31992f;
            if (iOException != null) {
                throw iOException;
            }
        }

        @Override // mv.i0
        /* renamed from: l3 */
        public ew.g getType() {
            return this.f31991e;
        }
    }

    public static final class c extends i0 {

        /* renamed from: d, reason: collision with root package name */
        public final mv.b0 f31993d;

        /* renamed from: e, reason: collision with root package name */
        public final long f31994e;

        public c(mv.b0 b0Var, long j10) {
            this.f31993d = b0Var;
            this.f31994e = j10;
        }

        @Override // mv.i0
        /* renamed from: e */
        public long getContentLength() {
            return this.f31994e;
        }

        @Override // mv.i0
        /* renamed from: f */
        public mv.b0 getMediaType() {
            return this.f31993d;
        }

        @Override // mv.i0
        /* renamed from: l3 */
        public ew.g getType() {
            throw new IllegalStateException("Cannot read raw response body of a converted body.");
        }
    }

    public q(w wVar, Object obj, Object[] objArr, e.a aVar, h<i0, T> hVar) {
        this.f31981a = wVar;
        this.b = obj;
        this.f31982c = objArr;
        this.f31983d = aVar;
        this.f31984e = hVar;
    }

    @Override // sw.d
    public void L(f<T> fVar) {
        mv.e eVar;
        Throwable th2;
        Objects.requireNonNull(fVar, "callback == null");
        synchronized (this) {
            try {
                if (this.f31988i) {
                    throw new IllegalStateException("Already executed.");
                }
                this.f31988i = true;
                eVar = this.f31986g;
                th2 = this.f31987h;
                if (eVar == null && th2 == null) {
                    try {
                        mv.e b10 = b();
                        this.f31986g = b10;
                        eVar = b10;
                    } catch (Throwable th3) {
                        th2 = th3;
                        c0.t(th2);
                        this.f31987h = th2;
                    }
                }
            } catch (Throwable th4) {
                throw th4;
            }
        }
        if (th2 != null) {
            fVar.a(this, th2);
            return;
        }
        if (this.f31985f) {
            eVar.cancel();
        }
        eVar.b0(new a(fVar));
    }

    @Override // sw.d
    /* renamed from: a, reason: merged with bridge method [inline-methods] */
    public q<T> clone() {
        return new q<>(this.f31981a, this.b, this.f31982c, this.f31983d, this.f31984e);
    }

    public final mv.e b() {
        mv.e a10 = this.f31983d.a(this.f31981a.a(this.b, this.f31982c));
        if (a10 != null) {
            return a10;
        }
        throw new NullPointerException("Call.Factory returned null.");
    }

    public final mv.e c() {
        mv.e eVar = this.f31986g;
        if (eVar != null) {
            return eVar;
        }
        Throwable th2 = this.f31987h;
        if (th2 != null) {
            if (th2 instanceof IOException) {
                throw ((IOException) th2);
            }
            if (th2 instanceof RuntimeException) {
                throw ((RuntimeException) th2);
            }
            throw ((Error) th2);
        }
        try {
            mv.e b10 = b();
            this.f31986g = b10;
            return b10;
        } catch (IOException | Error | RuntimeException e10) {
            c0.t(e10);
            this.f31987h = e10;
            throw e10;
        }
    }

    @Override // sw.d
    public void cancel() {
        mv.e eVar;
        this.f31985f = true;
        synchronized (this) {
            eVar = this.f31986g;
        }
        if (eVar != null) {
            eVar.cancel();
        }
    }

    public x<T> e(h0 h0Var) {
        i0 body = h0Var.getBody();
        h0 c10 = h0Var.s().b(new c(body.getMediaType(), body.getContentLength())).c();
        int code = c10.getCode();
        if (code < 200 || code >= 300) {
            try {
                return x.d(c0.a(body), c10);
            } finally {
                body.close();
            }
        }
        if (code == 204 || code == 205) {
            body.close();
            return x.j(null, c10);
        }
        b bVar = new b(body);
        try {
            return x.j(this.f31984e.a(bVar), c10);
        } catch (RuntimeException e10) {
            bVar.k();
            throw e10;
        }
    }

    @Override // sw.d
    public synchronized f0 h() {
        try {
        } catch (IOException e10) {
            throw new RuntimeException("Unable to create request.", e10);
        }
        return c().getOriginalRequest();
    }

    @Override // sw.d
    public x<T> j() {
        mv.e c10;
        synchronized (this) {
            if (this.f31988i) {
                throw new IllegalStateException("Already executed.");
            }
            this.f31988i = true;
            c10 = c();
        }
        if (this.f31985f) {
            c10.cancel();
        }
        return e(c10.j());
    }

    @Override // sw.d
    public boolean m() {
        boolean z10 = true;
        if (this.f31985f) {
            return true;
        }
        synchronized (this) {
            try {
                mv.e eVar = this.f31986g;
                if (eVar == null || !eVar.getCanceled()) {
                    z10 = false;
                }
            } finally {
            }
        }
        return z10;
    }
}
