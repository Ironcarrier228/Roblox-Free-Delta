package ao;

import bo.d;
import bo.e;
import bo.f;
import bo.i;
import bo.j;
import bo.k;
import java.util.ArrayList;
import java.util.BitSet;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.function.Function;

/* loaded from: classes3.dex */
public class u implements fo.b, go.c {

    /* renamed from: a, reason: collision with root package name */
    public final fo.c f3120a;
    public final List<go.b> b;

    /* renamed from: c, reason: collision with root package name */
    public final Map<Character, io.a> f3121c;

    /* renamed from: d, reason: collision with root package name */
    public final List<go.e> f3122d;

    /* renamed from: e, reason: collision with root package name */
    public final BitSet f3123e;

    /* renamed from: f, reason: collision with root package name */
    public final BitSet f3124f;

    /* renamed from: g, reason: collision with root package name */
    public Map<Character, List<go.a>> f3125g;

    /* renamed from: h, reason: collision with root package name */
    public go.i f3126h;

    /* renamed from: i, reason: collision with root package name */
    public boolean f3127i;

    /* renamed from: j, reason: collision with root package name */
    public int f3128j;

    /* renamed from: k, reason: collision with root package name */
    public g f3129k;

    /* renamed from: l, reason: collision with root package name */
    public e f3130l;

    public static /* synthetic */ class a {

        /* renamed from: a, reason: collision with root package name */
        public static final /* synthetic */ int[] f3131a;

        static {
            int[] iArr = new int[k.a.values().length];
            f3131a = iArr;
            try {
                iArr[k.a.WRAP.ordinal()] = 1;
            } catch (NoSuchFieldError unused) {
            }
            try {
                f3131a[k.a.REPLACE.ordinal()] = 2;
            } catch (NoSuchFieldError unused2) {
            }
        }
    }

    public static class b {

        /* renamed from: a, reason: collision with root package name */
        public final List<eo.b0> f3132a;
        public final boolean b;

        /* renamed from: c, reason: collision with root package name */
        public final boolean f3133c;

        public b(List<eo.b0> list, boolean z10, boolean z11) {
            this.f3132a = list;
            this.f3133c = z10;
            this.b = z11;
        }
    }

    public static class c {

        /* renamed from: a, reason: collision with root package name */
        public final String f3134a;
        public final String b;

        public c(String str, String str2) {
            this.f3134a = str;
            this.b = str2;
        }
    }

    public static class d implements go.d {

        /* renamed from: a, reason: collision with root package name */
        public final eo.b0 f3135a;
        public final eo.b0 b;

        /* renamed from: c, reason: collision with root package name */
        public final String f3136c;

        /* renamed from: d, reason: collision with root package name */
        public final String f3137d;

        /* renamed from: e, reason: collision with root package name */
        public final String f3138e;

        /* renamed from: f, reason: collision with root package name */
        public final String f3139f;

        /* renamed from: g, reason: collision with root package name */
        public final go.h f3140g;

        @Override // go.d
        public eo.b0 a() {
            return this.f3135a;
        }

        @Override // go.d
        public String b() {
            return this.f3139f;
        }

        @Override // go.d
        public String c() {
            return this.f3137d;
        }

        @Override // go.d
        public String d() {
            return this.f3136c;
        }

        @Override // go.d
        public String e() {
            return this.f3138e;
        }

        public d(eo.b0 b0Var, eo.b0 b0Var2, String str, String str2, String str3, String str4, go.h hVar) {
            this.f3135a = b0Var;
            this.b = b0Var2;
            this.f3136c = str;
            this.f3137d = str2;
            this.f3138e = str3;
            this.f3139f = str4;
            this.f3140g = hVar;
        }
    }

    public u(fo.c cVar) {
        this.f3120a = cVar;
        List<go.b> h10 = h(cVar.e());
        this.b = h10;
        Map<Character, io.a> g10 = g(cVar.c());
        this.f3121c = g10;
        this.f3122d = j(cVar.b());
        BitSet i10 = i(cVar.d());
        this.f3124f = i10;
        this.f3123e = k(i10, g10.keySet(), h10);
    }

    public static String A(go.i iVar) {
        go.h o10 = iVar.o();
        if (!co.e.e(iVar)) {
            return null;
        }
        String c10 = iVar.d(o10, iVar.o()).c();
        return co.c.e(c10.substring(1, c10.length() - 1));
    }

    public static /* synthetic */ List c(Character ch2) {
        return new ArrayList();
    }

    public static void e(char c10, io.a aVar, Map<Character, io.a> map) {
        if (map.put(Character.valueOf(c10), aVar) == null) {
            return;
        }
        throw new IllegalArgumentException("Delimiter processor conflict with delimiter char '" + c10 + "'");
    }

    public static void f(Iterable<io.a> iterable, Map<Character, io.a> map) {
        a0 a0Var;
        for (io.a aVar : iterable) {
            char d10 = aVar.d();
            char b10 = aVar.b();
            if (d10 == b10) {
                io.a aVar2 = map.get(Character.valueOf(d10));
                if (aVar2 == null || aVar2.d() != aVar2.b()) {
                    e(d10, aVar, map);
                } else {
                    if (aVar2 instanceof a0) {
                        a0Var = (a0) aVar2;
                    } else {
                        a0 a0Var2 = new a0(d10);
                        a0Var2.e(aVar2);
                        a0Var = a0Var2;
                    }
                    a0Var.e(aVar);
                    map.put(Character.valueOf(d10), a0Var);
                }
            } else {
                e(d10, aVar, map);
                e(b10, aVar, map);
            }
        }
    }

    public static Map<Character, io.a> g(List<io.a> list) {
        List a10;
        HashMap hashMap = new HashMap();
        a10 = j.a(new Object[]{new bo.a(), new bo.m()});
        f(a10, hashMap);
        f(list, hashMap);
        return hashMap;
    }

    public static BitSet i(Set<Character> set) {
        BitSet bitSet = new BitSet();
        Iterator<Character> it = set.iterator();
        while (it.hasNext()) {
            bitSet.set(it.next().charValue());
        }
        bitSet.set(33);
        return bitSet;
    }

    public static BitSet k(BitSet bitSet, Set<Character> set, List<go.b> list) {
        BitSet bitSet2 = (BitSet) bitSet.clone();
        Iterator<Character> it = set.iterator();
        while (it.hasNext()) {
            bitSet2.set(it.next().charValue());
        }
        Iterator<go.b> it2 = list.iterator();
        while (it2.hasNext()) {
            Iterator<Character> it3 = it2.next().b().iterator();
            while (it3.hasNext()) {
                bitSet2.set(it3.next().charValue());
            }
        }
        bitSet2.set(91);
        bitSet2.set(93);
        bitSet2.set(33);
        bitSet2.set(10);
        return bitSet2;
    }

    public static c t(go.i iVar) {
        String str;
        if (!iVar.i('(')) {
            return null;
        }
        iVar.r();
        String v8 = v(iVar);
        if (v8 == null) {
            return null;
        }
        if (iVar.r() >= 1) {
            str = A(iVar);
            iVar.r();
        } else {
            str = null;
        }
        if (iVar.i(')')) {
            return new c(v8, str);
        }
        return null;
    }

    public static String v(go.i iVar) {
        String c10;
        char l10 = iVar.l();
        go.h o10 = iVar.o();
        if (!co.e.b(iVar)) {
            return null;
        }
        if (l10 == '<') {
            String c11 = iVar.d(o10, iVar.o()).c();
            c10 = c11.substring(1, c11.length() - 1);
        } else {
            c10 = iVar.d(o10, iVar.o()).c();
        }
        return co.c.e(c10);
    }

    public static String x(go.i iVar) {
        if (!iVar.i('[')) {
            return null;
        }
        go.h o10 = iVar.o();
        if (!co.e.d(iVar)) {
            return null;
        }
        go.h o11 = iVar.o();
        if (!iVar.i(']')) {
            return null;
        }
        String c10 = iVar.d(o10, o11).c();
        if (c10.length() > 999) {
            return null;
        }
        return c10;
    }

    public final eo.s B() {
        go.h o10 = this.f3126h.o();
        this.f3126h.h();
        go.h o11 = this.f3126h.o();
        eo.b0 M = M(this.f3126h.d(o10, o11));
        d(e.a(M, o10, o11, this.f3130l, this.f3129k));
        return M;
    }

    public final eo.s C() {
        char l10;
        go.h o10 = this.f3126h.o();
        this.f3126h.h();
        while (true) {
            l10 = this.f3126h.l();
            if (l10 == 0 || this.f3123e.get(l10)) {
                break;
            }
            this.f3126h.h();
        }
        go.i iVar = this.f3126h;
        fo.j d10 = iVar.d(o10, iVar.o());
        String c10 = d10.c();
        if (l10 == '\n') {
            int j10 = jo.d.j(' ', c10, c10.length() - 1, 0) + 1;
            this.f3128j = c10.length() - j10;
            c10 = c10.substring(0, j10);
        } else if (l10 == 0) {
            c10 = c10.substring(0, jo.d.l(c10, c10.length() - 1, 0) + 1);
        }
        eo.b0 b0Var = new eo.b0(c10);
        b0Var.l(d10.e());
        return b0Var;
    }

    public final void D(g gVar) {
        boolean z10;
        HashMap hashMap = new HashMap();
        g gVar2 = this.f3129k;
        while (gVar2 != null) {
            g gVar3 = gVar2.f3079f;
            if (gVar3 == gVar) {
                break;
            } else {
                gVar2 = gVar3;
            }
        }
        while (gVar2 != null) {
            char c10 = gVar2.b;
            io.a aVar = this.f3121c.get(Character.valueOf(c10));
            if (!gVar2.c() || aVar == null) {
                gVar2 = gVar2.f3080g;
            } else {
                char d10 = aVar.d();
                g gVar4 = gVar2.f3079f;
                int i10 = 0;
                boolean z11 = false;
                while (gVar4 != null && gVar4 != gVar && gVar4 != hashMap.get(Character.valueOf(c10))) {
                    if (gVar4.g() && gVar4.b == d10) {
                        i10 = aVar.a(gVar4, gVar2);
                        if (i10 > 0) {
                            z10 = true;
                            z11 = true;
                            break;
                        }
                        z11 = true;
                    }
                    gVar4 = gVar4.f3079f;
                }
                z10 = false;
                if (z10) {
                    for (int i11 = 0; i11 < i10; i11++) {
                        List<eo.b0> list = gVar4.f3075a;
                        list.remove(list.size() - 1).n();
                    }
                    for (int i12 = 0; i12 < i10; i12++) {
                        gVar2.f3075a.remove(0).n();
                    }
                    H(gVar4, gVar2);
                    if (gVar4.length() == 0) {
                        F(gVar4);
                    }
                    if (gVar2.length() == 0) {
                        g gVar5 = gVar2.f3080g;
                        F(gVar2);
                        gVar2 = gVar5;
                    }
                } else {
                    if (!z11) {
                        hashMap.put(Character.valueOf(c10), gVar2.f3079f);
                        if (!gVar2.g()) {
                            G(gVar2);
                        }
                    }
                    gVar2 = gVar2.f3080g;
                }
            }
        }
        while (true) {
            g gVar6 = this.f3129k;
            if (gVar6 == null || gVar6 == gVar) {
                return;
            } else {
                G(gVar6);
            }
        }
    }

    public final void E(g gVar) {
        g gVar2 = gVar.f3079f;
        if (gVar2 != null) {
            gVar2.f3080g = gVar.f3080g;
        }
        g gVar3 = gVar.f3080g;
        if (gVar3 == null) {
            this.f3129k = gVar2;
        } else {
            gVar3.f3079f = gVar2;
        }
    }

    public final void F(g gVar) {
        E(gVar);
    }

    public final void G(g gVar) {
        E(gVar);
    }

    public final void H(g gVar, g gVar2) {
        g gVar3 = gVar2.f3079f;
        while (gVar3 != null && gVar3 != gVar) {
            g gVar4 = gVar3.f3079f;
            G(gVar3);
            gVar3 = gVar4;
        }
    }

    public final void I() {
        this.f3130l = this.f3130l.f3070f;
    }

    public final eo.s J(e eVar, eo.s sVar, boolean z10) {
        eo.b0 b0Var;
        go.h hVar;
        while (true) {
            g gVar = this.f3129k;
            if (gVar == null || gVar == eVar.f3071g) {
                break;
            }
            G(gVar);
        }
        if (this.f3127i) {
            if (!z10 || (hVar = eVar.b) == null) {
                hVar = eVar.f3068d;
            }
            go.i iVar = this.f3126h;
            sVar.l(iVar.d(hVar, iVar.o()).e());
        }
        I();
        if (!z10 || (b0Var = eVar.f3066a) == null) {
            b0Var = eVar.f3067c;
        }
        while (b0Var != null) {
            eo.s f10 = b0Var.f();
            b0Var.n();
            b0Var = f10;
        }
        if (eVar.f3066a != null && z10) {
            return sVar;
        }
        m();
        return sVar;
    }

    public void K(fo.j jVar) {
        this.f3126h = go.i.k(jVar);
        this.f3127i = !jVar.e().isEmpty();
        this.f3128j = 0;
        this.f3129k = null;
        this.f3130l = null;
        this.f3125g = l();
    }

    public final b L(io.a aVar, char c10) {
        boolean z10;
        int n10 = this.f3126h.n();
        go.h o10 = this.f3126h.o();
        if (this.f3126h.g(c10) < aVar.c()) {
            this.f3126h.q(o10);
            return null;
        }
        ArrayList arrayList = new ArrayList();
        this.f3126h.q(o10);
        while (this.f3126h.i(c10)) {
            go.i iVar = this.f3126h;
            arrayList.add(M(iVar.d(o10, iVar.o())));
            o10 = this.f3126h.o();
        }
        int m10 = this.f3126h.m();
        boolean z11 = n10 == 0 || jo.d.f(n10);
        boolean z12 = n10 == 0 || jo.d.h(n10);
        boolean z13 = m10 == 0 || jo.d.f(m10);
        boolean z14 = m10 == 0 || jo.d.h(m10);
        boolean z15 = !z14 && (!z13 || z12 || z11);
        boolean z16 = !z12 && (!z11 || z14 || z13);
        if (c10 == '_') {
            z10 = z15 && (!z16 || z11);
            if (!z16 || (z15 && !z13)) {
                r3 = false;
            }
        } else {
            boolean z17 = z15 && c10 == aVar.d();
            r3 = z16 && c10 == aVar.b();
            z10 = z17;
        }
        return new b(arrayList, z10, r3);
    }

    public final eo.b0 M(fo.j jVar) {
        eo.b0 b0Var = new eo.b0(jVar.c());
        b0Var.l(jVar.e());
        return b0Var;
    }

    public final eo.s N(e eVar, eo.s sVar, boolean z10) {
        eo.b0 b0Var;
        go.h hVar;
        eo.s f10 = eVar.f3067c.f();
        while (f10 != null) {
            eo.s f11 = f10.f();
            sVar.c(f10);
            f10 = f11;
        }
        if (this.f3127i) {
            if (!z10 || (hVar = eVar.b) == null) {
                hVar = eVar.f3068d;
            }
            go.i iVar = this.f3126h;
            sVar.l(iVar.d(hVar, iVar.o()).e());
        }
        D(eVar.f3071g);
        n(sVar);
        if (z10 && (b0Var = eVar.f3066a) != null) {
            b0Var.n();
        }
        eVar.f3067c.n();
        I();
        if (eVar.f3066a == null) {
            m();
        }
        return sVar;
    }

    @Override // go.c
    public go.i a() {
        return this.f3126h;
    }

    @Override // fo.b
    public void b(fo.j jVar, eo.s sVar) {
        K(jVar);
        while (true) {
            List<? extends eo.s> s8 = s();
            if (s8 == null) {
                D(null);
                n(sVar);
                return;
            } else {
                Iterator<? extends eo.s> it = s8.iterator();
                while (it.hasNext()) {
                    sVar.c(it.next());
                }
            }
        }
    }

    public final void d(e eVar) {
        e eVar2 = this.f3130l;
        if (eVar2 != null) {
            eVar2.f3073i = true;
        }
        this.f3130l = eVar;
    }

    public final List<go.b> h(List<go.b> list) {
        ArrayList arrayList = new ArrayList(list);
        arrayList.add(new e.a());
        arrayList.add(new f.a());
        arrayList.add(new i.a());
        arrayList.add(new bo.d.a());
        arrayList.add(new j.a());
        return arrayList;
    }

    public final List<go.e> j(List<go.e> list) {
        ArrayList arrayList = new ArrayList(list);
        arrayList.add(new bo.g());
        return arrayList;
    }

    public final Map<Character, List<go.a>> l() {
        HashMap hashMap = new HashMap();
        for (go.b bVar : this.b) {
            go.a a10 = bVar.a();
            Iterator<Character> it = bVar.b().iterator();
            while (it.hasNext()) {
                ((List) hashMap.computeIfAbsent(it.next(), new Function() { // from class: ao.t
                    @Override // java.util.function.Function
                    public final Object apply(Object obj) {
                        return u.c((Character) obj);
                    }
                })).add(a10);
            }
        }
        return hashMap;
    }

    public final void m() {
        for (e eVar = this.f3130l; eVar != null; eVar = eVar.f3070f) {
            if (eVar.f3066a == null) {
                eVar.f3072h = false;
            }
        }
    }

    public final void n(eo.s sVar) {
        if (sVar.d() == null) {
            return;
        }
        p(sVar.d(), sVar.e());
    }

    public final void o(eo.b0 b0Var, eo.b0 b0Var2, int i10) {
        eo.z zVar;
        if (b0Var == null || b0Var2 == null || b0Var == b0Var2) {
            return;
        }
        StringBuilder sb2 = new StringBuilder(i10);
        sb2.append(b0Var.o());
        if (this.f3127i) {
            zVar = new eo.z();
            zVar.a(b0Var.h());
        } else {
            zVar = null;
        }
        eo.s f10 = b0Var.f();
        eo.s f11 = b0Var2.f();
        while (f10 != f11) {
            sb2.append(((eo.b0) f10).o());
            if (zVar != null) {
                zVar.a(f10.h());
            }
            eo.s f12 = f10.f();
            f10.n();
            f10 = f12;
        }
        b0Var.p(sb2.toString());
        if (zVar != null) {
            b0Var.l(zVar.d());
        }
    }

    public final void p(eo.s sVar, eo.s sVar2) {
        eo.b0 b0Var = null;
        eo.b0 b0Var2 = null;
        int i10 = 0;
        while (sVar != null) {
            if (sVar instanceof eo.b0) {
                b0Var2 = (eo.b0) sVar;
                if (b0Var == null) {
                    b0Var = b0Var2;
                }
                i10 += b0Var2.o().length();
            } else {
                o(b0Var, b0Var2, i10);
                n(sVar);
                b0Var = null;
                b0Var2 = null;
                i10 = 0;
            }
            if (sVar == sVar2) {
                break;
            } else {
                sVar = sVar.f();
            }
        }
        o(b0Var, b0Var2, i10);
    }

    public final eo.s q() {
        go.h o10 = this.f3126h.o();
        this.f3126h.h();
        go.h o11 = this.f3126h.o();
        e eVar = this.f3130l;
        if (eVar == null) {
            return M(this.f3126h.d(o10, o11));
        }
        if (!eVar.f3072h) {
            I();
            return M(this.f3126h.d(o10, o11));
        }
        eo.s z10 = z(eVar, o10);
        if (z10 != null) {
            return z10;
        }
        this.f3126h.q(o11);
        I();
        return M(this.f3126h.d(o10, o11));
    }

    public final List<? extends eo.s> r(io.a aVar, char c10) {
        b L = L(aVar, c10);
        if (L == null) {
            return null;
        }
        List<eo.b0> list = L.f3132a;
        g gVar = new g(list, c10, L.f3133c, L.b, this.f3129k);
        this.f3129k = gVar;
        g gVar2 = gVar.f3079f;
        if (gVar2 != null) {
            gVar2.f3080g = gVar;
        }
        return list;
    }

    public final List<? extends eo.s> s() {
        List<? extends eo.s> a10;
        List<? extends eo.s> a11;
        List<? extends eo.s> a12;
        List<? extends eo.s> a13;
        List<? extends eo.s> r10;
        List<? extends eo.s> a14;
        List<? extends eo.s> a15;
        char l10 = this.f3126h.l();
        if (l10 == 0) {
            return null;
        }
        if (l10 == '\n') {
            a10 = j.a(new Object[]{u()});
            return a10;
        }
        if (l10 == '[') {
            a11 = j.a(new Object[]{B()});
            return a11;
        }
        if (l10 == ']') {
            a12 = j.a(new Object[]{q()});
            return a12;
        }
        if (this.f3124f.get(l10)) {
            go.h o10 = this.f3126h.o();
            List<? extends eo.s> y10 = y();
            if (y10 != null) {
                return y10;
            }
            this.f3126h.q(o10);
        }
        if (!this.f3123e.get(l10)) {
            a15 = j.a(new Object[]{C()});
            return a15;
        }
        List<go.a> list = this.f3125g.get(Character.valueOf(l10));
        if (list != null) {
            go.h o11 = this.f3126h.o();
            Iterator<go.a> it = list.iterator();
            while (it.hasNext()) {
                go.g a16 = it.next().a(this);
                if (a16 instanceof bo.l) {
                    bo.l lVar = (bo.l) a16;
                    eo.s c10 = lVar.c();
                    this.f3126h.q(lVar.d());
                    if (this.f3127i && c10.h().isEmpty()) {
                        go.i iVar = this.f3126h;
                        c10.l(iVar.d(o11, iVar.o()).e());
                    }
                    a14 = j.a(new Object[]{c10});
                    return a14;
                }
                this.f3126h.q(o11);
            }
        }
        io.a aVar = this.f3121c.get(Character.valueOf(l10));
        if (aVar != null && (r10 = r(aVar, l10)) != null) {
            return r10;
        }
        a13 = j.a(new Object[]{C()});
        return a13;
    }

    public final eo.s u() {
        this.f3126h.h();
        boolean z10 = this.f3128j >= 2;
        this.f3128j = 0;
        return z10 ? new eo.i() : new eo.x();
    }

    public final go.d w(e eVar, go.h hVar) {
        go.h o10 = this.f3126h.o();
        c t8 = t(this.f3126h);
        if (t8 != null) {
            return new d(eVar.f3066a, eVar.f3067c, this.f3126h.d(eVar.f3069e, hVar).c(), null, t8.f3134a, t8.b, o10);
        }
        this.f3126h.q(o10);
        String x5 = x(this.f3126h);
        if (x5 == null) {
            this.f3126h.q(o10);
        }
        boolean z10 = x5 == null || x5.isEmpty();
        if (eVar.f3073i && z10 && eVar.f3066a == null) {
            return null;
        }
        return new d(eVar.f3066a, eVar.f3067c, this.f3126h.d(eVar.f3069e, hVar).c(), x5, null, null, o10);
    }

    public final List<? extends eo.s> y() {
        List<? extends eo.s> a10;
        go.h o10 = this.f3126h.o();
        this.f3126h.h();
        go.h o11 = this.f3126h.o();
        if (!this.f3126h.i('[')) {
            return null;
        }
        go.h o12 = this.f3126h.o();
        eo.b0 M = M(this.f3126h.d(o10, o11));
        eo.b0 M2 = M(this.f3126h.d(o11, o12));
        d(e.b(M, o10, M2, o11, o12, this.f3130l, this.f3129k));
        a10 = j.a(new Object[]{M, M2});
        return a10;
    }

    public final eo.s z(e eVar, go.h hVar) {
        go.d w5 = w(eVar, hVar);
        if (w5 == null) {
            return null;
        }
        go.h o10 = this.f3126h.o();
        Iterator<go.e> it = this.f3122d.iterator();
        while (it.hasNext()) {
            go.f a10 = it.next().a(w5, this.f3126h, this.f3120a);
            if (a10 instanceof bo.k) {
                bo.k kVar = (bo.k) a10;
                eo.s d10 = kVar.d();
                go.h e10 = kVar.e();
                boolean g10 = kVar.g();
                int i10 = a.f3131a[kVar.f().ordinal()];
                if (i10 == 1) {
                    this.f3126h.q(e10);
                    return N(eVar, d10, g10);
                }
                if (i10 == 2) {
                    this.f3126h.q(e10);
                    return J(eVar, d10, g10);
                }
            } else {
                this.f3126h.q(o10);
            }
        }
        return null;
    }
}
