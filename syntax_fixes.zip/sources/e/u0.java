package e;

import android.content.res.Resources;
import com.github.luben.zstd.BuildConfig;

import kotlin.Metadata;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;

@Metadata(d1 = {"\u0000 \n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\u0010\b\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u000b\n\u0002\b\u0010\u0018\u0000 \u000f2\u00020\u0001:\u0001\u0010B5\b\u0002\u0012\u0006\u0010\u0003\u001a\u00020\u0002\u0012\u0006\u0010\u0004\u001a\u00020\u0002\u0012\u0006\u0010\u0005\u001a\u00020\u0002\u0012\u0012\u0010\t\u001a\u000e\u0012\u0004\u0012\u00020\u0007\u0012\u0004\u0012\u00020\b0\u0006¢\u0006\u0004\b\n\u0010\u000bJ\u0017\u0010\r\u001a\u00020\u00022\u0006\u0010\f\u001a\u00020\bH\u0000¢\u0006\u0004\b\r\u0010\u000eJ\u0017\u0010\u000f\u001a\u00020\u00022\u0006\u0010\f\u001a\u00020\bH\u0000¢\u0006\u0004\b\u000f\u0010\u000eR\u0014\u0010\u0003\u001a\u00020\u00028\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b\u0010\u0010\u0011R\u001a\u0010\u0004\u001a\u00020\u00028\u0000X\u0080\u0004¢\u0006\f\n\u0004\b\u0012\u0010\u0011\u001a\u0004\b\u0013\u0010\u0014R\u001a\u0010\u0005\u001a\u00020\u00028\u0000X\u0080\u0004¢\u0006\f\n\u0004\b\u0015\u0010\u0011\u001a\u0004\b\u0015\u0010\u0014R&\u0010\t\u001a\u000e\u0012\u0004\u0012\u00020\u0007\u0012\u0004\u0012\u00020\b0\u00068\u0000X\u0080\u0004¢\u0006\f\n\u0004\b\r\u0010\u0016\u001a\u0004\b\u0012\u0010\u0017¨\u0006\u0018"}, d2 = {"Le/u0;", BuildConfig.FLAVOR, BuildConfig.FLAVOR, "lightScrim", "darkScrim", "nightMode", "Lkotlin/Function1;", "Landroid/content/res/Resources;", BuildConfig.FLAVOR, "detectDarkMode", "<init>", "(IIILkotlin/jvm/functions/Function1;)V", "isDark", "d", "(Z)I", "e", xe.a.f36648e, "I", k6.b.f21144e, "getDarkScrim$activity", "()I", "c", "Lkotlin/jvm/functions/Function1;", "()Lkotlin/jvm/functions/Function1;", "activity"}, k = 1, mv = {2, 0, 0}, xi = 48)
/* loaded from: classes.dex */
public final class u0 {

    /* renamed from: e, reason: collision with root package name and from kotlin metadata */
    @NotNull
    public static final Companion INSTANCE = new Companion(null);

    /* renamed from: a, reason: collision with root package name and from kotlin metadata */
    public final int lightScrim;

    /* renamed from: b, reason: from kotlin metadata */
    public final int darkScrim;

    /* renamed from: c, reason: collision with root package name and from kotlin metadata */
    public final int nightMode;

    /* renamed from: d, reason: collision with root package name and from kotlin metadata */
    @NotNull
    public final Function1<Resources, Boolean> detectDarkMode;

    @Metadata(d1 = {"\u0000*\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\b\u0086\u0003\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J9\u0010\f\u001a\u00020\u000b2\b\b\u0001\u0010\u0005\u001a\u00020\u00042\b\b\u0001\u0010\u0006\u001a\u00020\u00042\u0014\b\u0002\u0010\n\u001a\u000e\u0012\u0004\u0012\u00020\b\u0012\u0004\u0012\u00020\t0\u0007H\u0007¢\u0006\u0004\b\f\u0010\r¨\u0006\u000e"}, d2 = {"Le/u0$a;", BuildConfig.FLAVOR, "<init>", "()V", BuildConfig.FLAVOR, "lightScrim", "darkScrim", "Lkotlin/Function1;", "Landroid/content/res/Resources;", BuildConfig.FLAVOR, "detectDarkMode", "Le/u0;", "c", "(IILkotlin/jvm/functions/Function1;)Le/u0;", "activity"}, k = 1, mv = {2, 0, 0}, xi = 48)
    /* renamed from: e.u0$a, reason: from kotlin metadata */
    public static final class Companion {
        public /* synthetic */ Companion(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }

        /* JADX WARN: Multi-variable type inference failed */
        public static /* synthetic */ u0 d(Companion companion, int i10, int i11, Function1 function1, int i12, Object obj) {
            if ((i12 & 4) != 0) {
                function1 = new Function1() { // from class: e.t0
                    @Override // kotlin.jvm.functions.Function1
                    public final Object invoke(Object obj2) {
                        boolean e10;
                        e10 = u0.Companion.e((Resources) obj2);
                        return Boolean.valueOf(e10);
                    }
                };
            }
            return companion.c(i10, i11, function1);
        }

        public static final boolean e(Resources resources) {
            Intrinsics.checkNotNullParameter(resources, "resources");
            return (resources.getConfiguration().uiMode & 48) == 32;
        }

        @NotNull
        public final u0 b(int i10, int i11) {
            return d(this, i10, i11, null, 4, null);
        }

        @NotNull
        public final u0 c(int lightScrim, int darkScrim, @NotNull Function1<? super Resources, Boolean> detectDarkMode) {
            Intrinsics.checkNotNullParameter(detectDarkMode, "detectDarkMode");
            return new u0(lightScrim, darkScrim, 0, detectDarkMode, null);
        }

        public Companion() {
        }
    }

    public /* synthetic */ u0(int i10, int i11, int i12, Function1 function1, DefaultConstructorMarker defaultConstructorMarker) {
        this(i10, i11, i12, function1);
    }

    @NotNull
    public static final u0 a(int i10, int i11) {
        return INSTANCE.b(i10, i11);
    }

    @NotNull
    public final Function1<Resources, Boolean> b() {
        return this.detectDarkMode;
    }

    /* renamed from: c, reason: from getter */
    public final int getNightMode() {
        return this.nightMode;
    }

    public final int d(boolean isDark) {
        return isDark ? this.darkScrim : this.lightScrim;
    }

    public final int e(boolean isDark) {
        if (this.nightMode == 0) {
            return 0;
        }
        return isDark ? this.darkScrim : this.lightScrim;
    }

    /* JADX WARN: Multi-variable type inference failed */
    public u0(int i10, int i11, int i12, Function1<? super Resources, Boolean> function1) {
        this.lightScrim = i10;
        this.darkScrim = i11;
        this.nightMode = i12;
        this.detectDarkMode = function1;
    }


    // --- восстановлено из DEX (e/u0$a) ---
    public static class a {
        public a() { }
        public a(kotlin.jvm.internal.DefaultConstructorMarker p0) { }
        public boolean a(android.content.res.Resources p0) { throw new UnsupportedOperationException("stub"); }
        public e.u0 b(int p0, int p1) { throw new UnsupportedOperationException("stub"); }
        public e.u0 c(int p0, int p1, kotlin.jvm.functions.Function1 p2) { throw new UnsupportedOperationException("stub"); }
        public e.u0 d(e.u0.a p0, int p1, int p2, kotlin.jvm.functions.Function1 p3, int p4, java.lang.Object p5) { throw new UnsupportedOperationException("stub"); }
        public boolean e(android.content.res.Resources p0) { throw new UnsupportedOperationException("stub"); }
    }
}
