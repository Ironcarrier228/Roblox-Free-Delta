package g7;

import android.graphics.Bitmap;
import android.graphics.ColorFilter;
import android.graphics.Path;
import android.graphics.PointF;
import android.graphics.Typeface;

/* loaded from: classes3.dex */
public abstract class o0 {
    public static final Float A;
    public static final Float B;
    public static final Float C;
    public static final Float D;
    public static final Float E;
    public static final Float F;
    public static final Float G;
    public static final Float H;
    public static final Float I;
    public static final Float J;
    public static final ColorFilter K;
    public static final Integer[] L;
    public static final Typeface M;
    public static final Bitmap N;
    public static final CharSequence O;
    public static final Path P;

    /* renamed from: a, reason: collision with root package name */
    public static final Integer f17497a = 1;
    public static final Integer b = 2;

    /* renamed from: c, reason: collision with root package name */
    public static final Integer f17498c = 3;

    /* renamed from: d, reason: collision with root package name */
    public static final Integer f17499d = 4;

    /* renamed from: e, reason: collision with root package name */
    public static final Integer f17500e = 5;

    /* renamed from: f, reason: collision with root package name */
    public static final PointF f17501f = new PointF();

    /* renamed from: g, reason: collision with root package name */
    public static final PointF f17502g = new PointF();

    /* renamed from: h, reason: collision with root package name */
    public static final Float f17503h;

    /* renamed from: i, reason: collision with root package name */
    public static final Float f17504i;

    /* renamed from: j, reason: collision with root package name */
    public static final Float f17505j;

    /* renamed from: k, reason: collision with root package name */
    public static final PointF f17506k;

    /* renamed from: l, reason: collision with root package name */
    public static final PointF f17507l;

    /* renamed from: m, reason: collision with root package name */
    public static final Float f17508m;

    /* renamed from: n, reason: collision with root package name */
    public static final PointF f17509n;

    /* renamed from: o, reason: collision with root package name */
    public static final u7.d f17510o;

    /* renamed from: p, reason: collision with root package name */
    public static final Float f17511p;

    /* renamed from: q, reason: collision with root package name */
    public static final Float f17512q;

    /* renamed from: r, reason: collision with root package name */
    public static final Float f17513r;

    /* renamed from: s, reason: collision with root package name */
    public static final Float f17514s;

    /* renamed from: t, reason: collision with root package name */
    public static final Float f17515t;

    /* renamed from: u, reason: collision with root package name */
    public static final Float f17516u;

    /* renamed from: v, reason: collision with root package name */
    public static final Float f17517v;

    /* renamed from: w, reason: collision with root package name */
    public static final Float f17518w;

    /* renamed from: x, reason: collision with root package name */
    public static final Float f17519x;

    /* renamed from: y, reason: collision with root package name */
    public static final Float f17520y;

    /* renamed from: z, reason: collision with root package name */
    public static final Float f17521z;

    static {
        Float valueOf = Float.valueOf(15.0f);
        f17503h = valueOf;
        Float valueOf2 = Float.valueOf(16.0f);
        f17504i = valueOf2;
        Float valueOf3 = Float.valueOf(17.0f);
        f17505j = valueOf3;
        f17506k = new PointF();
        f17507l = new PointF();
        Float valueOf4 = Float.valueOf(0.0f);
        f17508m = valueOf4;
        f17509n = new PointF();
        f17510o = new u7.d();
        f17511p = Float.valueOf(1.0f);
        f17512q = valueOf4;
        f17513r = valueOf4;
        f17514s = Float.valueOf(2.0f);
        f17515t = Float.valueOf(3.0f);
        f17516u = Float.valueOf(4.0f);
        f17517v = Float.valueOf(5.0f);
        f17518w = Float.valueOf(6.0f);
        f17519x = Float.valueOf(7.0f);
        f17520y = Float.valueOf(8.0f);
        f17521z = Float.valueOf(9.0f);
        A = Float.valueOf(10.0f);
        B = Float.valueOf(11.0f);
        C = Float.valueOf(12.0f);
        D = Float.valueOf(12.1f);
        E = Float.valueOf(13.0f);
        F = Float.valueOf(14.0f);
        G = valueOf;
        H = valueOf2;
        I = valueOf3;
        J = Float.valueOf(18.0f);
        K = new ColorFilter();
        L = new Integer[0];
        M = Typeface.DEFAULT;
        N = Bitmap.createBitmap(1, 1, Bitmap.Config.ALPHA_8);
        O = "dynamic_text";
        P = new Path();
    }
}
