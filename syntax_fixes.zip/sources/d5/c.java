package d5;

import a5.q;
import a5.r;
import av.p0;
import com.github.luben.zstd.BuildConfig;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.coroutines.CoroutineContext;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import y4.c0;
import y4.f0;
import y4.g0;
import y4.u;

@Metadata(d1 = {"\u0000>\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0002\b\u0003\u001aB\u0010\t\u001a\u00028\u0000\"\u0004\b\u0000\u0010\u00002\u0006\u0010\u0002\u001a\u00020\u00012\u0006\u0010\u0004\u001a\u00020\u00032\u0006\u0010\u0005\u001a\u00020\u00032\u0012\u0010\b\u001a\u000e\u0012\u0004\u0012\u00020\u0007\u0012\u0004\u0012\u00028\u00000\u0006H\u0087@¢\u0006\u0004\b\t\u0010\n\u001aA\u0010\u000b\u001a\u00028\u0000\"\u0004\b\u0000\u0010\u00002\u0006\u0010\u0002\u001a\u00020\u00012\u0006\u0010\u0004\u001a\u00020\u00032\u0006\u0010\u0005\u001a\u00020\u00032\u0012\u0010\b\u001a\u000e\u0012\u0004\u0012\u00020\u0007\u0012\u0004\u0012\u00028\u00000\u0006H\u0007¢\u0006\u0004\b\u000b\u0010\f\u001a<\u0010\u000f\u001a\u00028\u0000\"\u0004\b\u0000\u0010\u00002\u0006\u0010\u0002\u001a\u00020\u00012\u001c\u0010\b\u001a\u0018\b\u0001\u0012\n\u0012\b\u0012\u0004\u0012\u00028\u00000\r\u0012\u0006\u0012\u0004\u0018\u00010\u000e0\u0006H\u0087@¢\u0006\u0004\b\u000f\u0010\u0010\u001a\u001c\u0010\u0012\u001a\u00020\u0011*\u00020\u00012\u0006\u0010\u0005\u001a\u00020\u0003H\u0080@¢\u0006\u0004\b\u0012\u0010\u0013\u001a\u0017\u0010\u0017\u001a\u00020\u00162\u0006\u0010\u0015\u001a\u00020\u0014H\u0007¢\u0006\u0004\b\u0017\u0010\u0018¨\u0006\u0019"}, d2 = {"R", "Ly4/u;", "db", BuildConfig.FLAVOR, "isReadOnly", "inTransaction", "Lkotlin/Function1;", "Lg5/b;", "block", "d", "(Ly4/u;ZZLkotlin/jvm/functions/Function1;Leu/b;)Ljava/lang/Object;", k6.b.f21144e, "(Ly4/u;ZZLkotlin/jvm/functions/Function1;)Ljava/lang/Object;", "Leu/b;", BuildConfig.FLAVOR, "c", "(Ly4/u;Lkotlin/jvm/functions/Function1;Leu/b;)Ljava/lang/Object;", "Lkotlin/coroutines/CoroutineContext;", xe.a.f36648e, "(Ly4/u;ZLeu/b;)Ljava/lang/Object;", "Ljava/io/File;", "databaseFile", BuildConfig.FLAVOR, "e", "(Ljava/io/File;)I", "room-runtime"}, k = 5, mv = {2, 1, 0}, xi = 48, xs = "androidx/room/util/DBUtil")
/* loaded from: classes.dex */
public final /* synthetic */ class c {

    /* JADX INFO: Add missing generic type declarations: [R] */
    @Metadata(d1 = {"\u0000\b\n\u0000\n\u0002\u0018\u0002\n\u0000\u0010\u0002\u001a\u00028\u0000\"\u0004\b\u0000\u0010\u0000*\u00020\u0001H\n"}, d2 = {"R", "Lav/p0;", "<anonymous>"}, k = 3, mv = {2, 1, 0})
    @gu.f(c = "androidx.room.util.DBUtil__DBUtil_androidKt$performBlocking$1", f = "DBUtil.android.kt", l = {72}, m = "invokeSuspend")
    public static final class a<R> extends gu.m implements Function2<p0, eu.b<? super R>, Object> {

        /* renamed from: t, reason: collision with root package name */
        public int f11848t;

        /* renamed from: u, reason: collision with root package name */
        public final /* synthetic */ CoroutineContext f11849u;

        /* renamed from: v, reason: collision with root package name */
        public final /* synthetic */ u f11850v;

        /* renamed from: w, reason: collision with root package name */
        public final /* synthetic */ boolean f11851w;

        /* renamed from: x, reason: collision with root package name */
        public final /* synthetic */ boolean f11852x;

        /* renamed from: y, reason: collision with root package name */
        public final /* synthetic */ Function1<g5.b, R> f11853y;

        @Metadata(d1 = {"\u0000\b\n\u0000\n\u0002\u0018\u0002\n\u0000\u0010\u0002\u001a\u00028\u0000\"\u0004\b\u0000\u0010\u0000*\u00020\u0001H\n"}, d2 = {"R", "Lav/p0;", "<anonymous>"}, k = 3, mv = {2, 1, 0})
        @gu.f(c = "androidx.room.util.DBUtil__DBUtil_androidKt$performBlocking$1$1", f = "DBUtil.android.kt", l = {260}, m = "invokeSuspend")
        /* renamed from: d5.c$a$a, reason: collision with other inner class name */
        public static final class C0211a extends gu.m implements Function2<p0, eu.b<? super R>, Object> {

            /* renamed from: t, reason: collision with root package name */
            public int f11854t;

            /* renamed from: u, reason: collision with root package name */
            public final /* synthetic */ u f11855u;

            /* renamed from: v, reason: collision with root package name */
            public final /* synthetic */ boolean f11856v;

            /* renamed from: w, reason: collision with root package name */
            public final /* synthetic */ boolean f11857w;

            /* renamed from: x, reason: collision with root package name */
            public final /* synthetic */ Function1<g5.b, R> f11858x;

            @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\u0010\u0003\u001a\u00028\u0000\"\u0004\b\u0000\u0010\u00002\u0006\u0010\u0002\u001a\u00020\u0001H\n"}, d2 = {"R", "Ly4/g0;", "transactor", "<anonymous>"}, k = 3, mv = {2, 1, 0})
            @gu.f(c = "androidx.room.util.DBUtil__DBUtil_androidKt$performBlocking$1$1$invokeSuspend$$inlined$internalPerform$1", f = "DBUtil.android.kt", l = {56, 57, 59, 60}, m = "invokeSuspend")
            /* renamed from: d5.c$a$a$a, reason: collision with other inner class name */
            public static final class C0212a extends gu.m implements Function2<g0, eu.b<? super R>, Object> {

                /* renamed from: t, reason: collision with root package name */
                public Object f11859t;

                /* renamed from: u, reason: collision with root package name */
                public int f11860u;

                /* renamed from: v, reason: collision with root package name */
                public /* synthetic */ Object f11861v;

                /* renamed from: w, reason: collision with root package name */
                public final /* synthetic */ boolean f11862w;

                /* renamed from: x, reason: collision with root package name */
                public final /* synthetic */ boolean f11863x;

                /* renamed from: y, reason: collision with root package name */
                public final /* synthetic */ u f11864y;

                /* renamed from: z, reason: collision with root package name */
                public final /* synthetic */ Function1 f11865z;

                @Metadata(d1 = {"\u0000\b\n\u0000\n\u0002\u0018\u0002\n\u0000\u0010\u0002\u001a\u00028\u0000\"\u0004\b\u0000\u0010\u0000*\b\u0012\u0004\u0012\u00028\u00000\u0001H\n"}, d2 = {"R", "Ly4/f0;", "<anonymous>"}, k = 3, mv = {2, 1, 0})
                @gu.f(c = "androidx.room.util.DBUtil__DBUtil_androidKt$performBlocking$1$1$invokeSuspend$$inlined$internalPerform$1$1", f = "DBUtil.android.kt", l = {}, m = "invokeSuspend")
                /* renamed from: d5.c$a$a$a$a, reason: collision with other inner class name */
                public static final class C0213a extends gu.m implements Function2<f0<R>, eu.b<? super R>, Object> {

                    /* renamed from: t, reason: collision with root package name */
                    public int f11866t;

                    /* renamed from: u, reason: collision with root package name */
                    public /* synthetic */ Object f11867u;

                    /* renamed from: v, reason: collision with root package name */
                    public final /* synthetic */ Function1 f11868v;

                    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                    public C0213a(eu.b bVar, Function1 function1) {
                        super(2, bVar);
                        this.f11868v = function1;
                    }

                    @Override // gu.a
                    public final eu.b<Unit> create(Object obj, eu.b<?> bVar) {
                        C0213a c0213a = new C0213a(bVar, this.f11868v);
                        c0213a.f11867u = obj;
                        return c0213a;
                    }

                    @Override // gu.a
                    public final Object invokeSuspend(Object obj) {
                        fu.c.e();
                        if (this.f11866t != 0) {
                            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                        }
                        zt.o.b(obj);
                        f0 f0Var = (f0) this.f11867u;
                        Intrinsics.d(f0Var, "null cannot be cast to non-null type androidx.room.coroutines.RawConnectionAccessor");
                        return this.f11868v.invoke(((q) f0Var).getDelegate());
                    }

                    @Override // kotlin.jvm.functions.Function2
                    /* renamed from: m, reason: merged with bridge method [inline-methods] */
                    public final Object invoke(f0<R> f0Var, eu.b<? super R> bVar) {
                        return ((C0213a) create(f0Var, bVar)).invokeSuspend(Unit.f21504a);
                    }
                }

                /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                public C0212a(boolean z10, boolean z11, u uVar, eu.b bVar, Function1 function1) {
                    super(2, bVar);
                    this.f11862w = z10;
                    this.f11863x = z11;
                    this.f11864y = uVar;
                    this.f11865z = function1;
                }

                @Override // gu.a
                public final eu.b<Unit> create(Object obj, eu.b<?> bVar) {
                    C0212a c0212a = new C0212a(this.f11862w, this.f11863x, this.f11864y, bVar, this.f11865z);
                    c0212a.f11861v = obj;
                    return c0212a;
                }

                /* JADX WARN: Code restructure failed: missing block: B:26:0x009f, code lost:
                
                    if (r8 != r0) goto L37;
                 */
                /* JADX WARN: Removed duplicated region for block: B:10:0x00bb  */
                @Override // gu.a
                /*
                    Code decompiled incorrectly, please refer to instructions dump.
                    To view partially-correct add '--show-bad-code' argument
                */
                public final java.lang.Object invokeSuspend(java.lang.Object r8) {
                    /*
                        Method dump skipped, instructions count: 216
                        To view this dump add '--comments-level debug' option
                    */
                    throw new UnsupportedOperationException("Method not decompiled: d5.c.a.C0211a.C0212a.invokeSuspend(java.lang.Object):java.lang.Object");
                }

                @Override // kotlin.jvm.functions.Function2
                /* renamed from: m, reason: merged with bridge method [inline-methods] */
                public final Object invoke(g0 g0Var, eu.b<? super R> bVar) {
                    return ((C0212a) create(g0Var, bVar)).invokeSuspend(Unit.f21504a);
                }
            }

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            /* JADX WARN: Multi-variable type inference failed */
            public C0211a(u uVar, boolean z10, boolean z11, Function1<? super g5.b, ? extends R> function1, eu.b<? super C0211a> bVar) {
                super(2, bVar);
                this.f11855u = uVar;
                this.f11856v = z10;
                this.f11857w = z11;
                this.f11858x = function1;
            }

            @Override // gu.a
            public final eu.b<Unit> create(Object obj, eu.b<?> bVar) {
                return new C0211a(this.f11855u, this.f11856v, this.f11857w, this.f11858x, bVar);
            }

            @Override // kotlin.jvm.functions.Function2
            public final Object invoke(p0 p0Var, eu.b<? super R> bVar) {
                return ((C0211a) create(p0Var, bVar)).invokeSuspend(Unit.f21504a);
            }

            @Override // gu.a
            public final Object invokeSuspend(Object obj) {
                Object e10 = fu.c.e();
                int i10 = this.f11854t;
                if (i10 != 0) {
                    if (i10 != 1) {
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                    zt.o.b(obj);
                    return obj;
                }
                zt.o.b(obj);
                boolean z10 = !(this.f11855u.F() && this.f11855u.G()) && this.f11856v;
                u uVar = this.f11855u;
                boolean z11 = this.f11857w;
                C0212a c0212a = new C0212a(z10, z11, uVar, null, this.f11858x);
                this.f11854t = 1;
                Object W = uVar.W(z11, c0212a, this);
                return W == e10 ? e10 : W;
            }
        }

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        /* JADX WARN: Multi-variable type inference failed */
        public a(CoroutineContext coroutineContext, u uVar, boolean z10, boolean z11, Function1<? super g5.b, ? extends R> function1, eu.b<? super a> bVar) {
            super(2, bVar);
            this.f11849u = coroutineContext;
            this.f11850v = uVar;
            this.f11851w = z10;
            this.f11852x = z11;
            this.f11853y = function1;
        }

        @Override // gu.a
        public final eu.b<Unit> create(Object obj, eu.b<?> bVar) {
            return new a(this.f11849u, this.f11850v, this.f11851w, this.f11852x, this.f11853y, bVar);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(p0 p0Var, eu.b<? super R> bVar) {
            return ((a) create(p0Var, bVar)).invokeSuspend(Unit.f21504a);
        }

        @Override // gu.a
        public final Object invokeSuspend(Object obj) {
            Object e10 = fu.c.e();
            int i10 = this.f11848t;
            if (i10 != 0) {
                if (i10 != 1) {
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                zt.o.b(obj);
                return obj;
            }
            zt.o.b(obj);
            CoroutineContext coroutineContext = this.f11849u;
            C0211a c0211a = new C0211a(this.f11850v, this.f11851w, this.f11852x, this.f11853y, null);
            this.f11848t = 1;
            Object g10 = av.i.g(coroutineContext, c0211a, this);
            return g10 == e10 ? e10 : g10;
        }
    }

    /* JADX INFO: Add missing generic type declarations: [R] */
    @Metadata(d1 = {"\u0000\b\n\u0000\n\u0002\u0018\u0002\n\u0000\u0010\u0002\u001a\u00028\u0000\"\u0004\b\u0000\u0010\u0000*\u00020\u0001H\n"}, d2 = {"R", "Lav/p0;", "<anonymous>"}, k = 3, mv = {2, 1, 0})
    @gu.f(c = "androidx.room.util.DBUtil__DBUtil_androidKt$performInTransactionSuspending$$inlined$compatCoroutineExecute$DBUtil__DBUtil_androidKt$1", f = "DBUtil.android.kt", l = {261}, m = "invokeSuspend")
    public static final class b<R> extends gu.m implements Function2<p0, eu.b<? super R>, Object> {

        /* renamed from: t, reason: collision with root package name */
        public int f11869t;

        /* renamed from: u, reason: collision with root package name */
        public final /* synthetic */ u f11870u;

        /* renamed from: v, reason: collision with root package name */
        public final /* synthetic */ Function1 f11871v;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public b(eu.b bVar, u uVar, Function1 function1) {
            super(2, bVar);
            this.f11870u = uVar;
            this.f11871v = function1;
        }

        @Override // gu.a
        public final eu.b<Unit> create(Object obj, eu.b<?> bVar) {
            return new b(bVar, this.f11870u, this.f11871v);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(p0 p0Var, eu.b<? super R> bVar) {
            return ((b) create(p0Var, bVar)).invokeSuspend(Unit.f21504a);
        }

        @Override // gu.a
        public final Object invokeSuspend(Object obj) {
            Object e10 = fu.c.e();
            int i10 = this.f11869t;
            if (i10 != 0) {
                if (i10 != 1) {
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                zt.o.b(obj);
                return obj;
            }
            zt.o.b(obj);
            u uVar = this.f11870u;
            e eVar = new e(true, false, uVar, null, this.f11871v);
            this.f11869t = 1;
            Object W = uVar.W(false, eVar, this);
            return W == e10 ? e10 : W;
        }
    }

    @Metadata(k = 3, mv = {2, 1, 0}, xi = 48)
    @gu.f(c = "androidx.room.util.DBUtil__DBUtil_androidKt", f = "DBUtil.android.kt", l = {97, 262, 264, 264}, m = "performInTransactionSuspending")
    /* renamed from: d5.c$c, reason: collision with other inner class name */
    public static final class C0214c<R> extends gu.d {

        /* renamed from: t, reason: collision with root package name */
        public Object f11872t;

        /* renamed from: u, reason: collision with root package name */
        public Object f11873u;

        /* renamed from: v, reason: collision with root package name */
        public /* synthetic */ Object f11874v;

        /* renamed from: w, reason: collision with root package name */
        public int f11875w;

        public C0214c(eu.b<? super C0214c> bVar) {
            super(bVar);
        }

        @Override // gu.a
        @Nullable
        public final Object invokeSuspend(@NotNull Object obj) {
            this.f11874v = obj;
            this.f11875w |= Integer.MIN_VALUE;
            return d5.a.d(null, null, this);
        }
    }

    /* JADX INFO: Add missing generic type declarations: [R] */
    @Metadata(d1 = {"\u0000\u0004\n\u0002\b\u0002\u0010\u0000\u001a\u0002H\u0001\"\u0004\b\u0000\u0010\u0001H\n"}, d2 = {"<anonymous>", "R"}, k = 3, mv = {2, 1, 0}, xi = 48)
    @gu.f(c = "androidx.room.util.DBUtil__DBUtil_androidKt$performInTransactionSuspending$2", f = "DBUtil.android.kt", l = {260}, m = "invokeSuspend")
    public static final class d<R> extends gu.m implements Function1<eu.b<? super R>, Object> {

        /* renamed from: t, reason: collision with root package name */
        public int f11876t;

        /* renamed from: u, reason: collision with root package name */
        public final /* synthetic */ u f11877u;

        /* renamed from: v, reason: collision with root package name */
        public final /* synthetic */ Function1<eu.b<? super R>, Object> f11878v;

        @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\u0010\u0003\u001a\u00028\u0000\"\u0004\b\u0000\u0010\u00002\u0006\u0010\u0002\u001a\u00020\u0001H\n"}, d2 = {"R", "Ly4/g0;", "transactor", "<anonymous>"}, k = 3, mv = {2, 1, 0})
        @gu.f(c = "androidx.room.util.DBUtil__DBUtil_androidKt$performInTransactionSuspending$2$invokeSuspend$$inlined$internalPerform$1", f = "DBUtil.android.kt", l = {56, 57, 59, 60, 172}, m = "invokeSuspend")
        public static final class a extends gu.m implements Function2<g0, eu.b<? super R>, Object> {

            /* renamed from: t, reason: collision with root package name */
            public Object f11879t;

            /* renamed from: u, reason: collision with root package name */
            public int f11880u;

            /* renamed from: v, reason: collision with root package name */
            public /* synthetic */ Object f11881v;

            /* renamed from: w, reason: collision with root package name */
            public final /* synthetic */ boolean f11882w;

            /* renamed from: x, reason: collision with root package name */
            public final /* synthetic */ boolean f11883x;

            /* renamed from: y, reason: collision with root package name */
            public final /* synthetic */ u f11884y;

            /* renamed from: z, reason: collision with root package name */
            public final /* synthetic */ Function1 f11885z;

            @Metadata(d1 = {"\u0000\b\n\u0000\n\u0002\u0018\u0002\n\u0000\u0010\u0002\u001a\u00028\u0000\"\u0004\b\u0000\u0010\u0000*\b\u0012\u0004\u0012\u00028\u00000\u0001H\n"}, d2 = {"R", "Ly4/f0;", "<anonymous>"}, k = 3, mv = {2, 1, 0})
            @gu.f(c = "androidx.room.util.DBUtil__DBUtil_androidKt$performInTransactionSuspending$2$invokeSuspend$$inlined$internalPerform$1$1", f = "DBUtil.android.kt", l = {60}, m = "invokeSuspend")
            /* renamed from: d5.c$d$a$a, reason: collision with other inner class name */
            public static final class C0215a extends gu.m implements Function2<f0<R>, eu.b<? super R>, Object> {

                /* renamed from: t, reason: collision with root package name */
                public int f11886t;

                /* renamed from: u, reason: collision with root package name */
                public /* synthetic */ Object f11887u;

                /* renamed from: v, reason: collision with root package name */
                public final /* synthetic */ Function1 f11888v;

                /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                public C0215a(eu.b bVar, Function1 function1) {
                    super(2, bVar);
                    this.f11888v = function1;
                }

                @Override // gu.a
                public final eu.b<Unit> create(Object obj, eu.b<?> bVar) {
                    C0215a c0215a = new C0215a(bVar, this.f11888v);
                    c0215a.f11887u = obj;
                    return c0215a;
                }

                @Override // gu.a
                public final Object invokeSuspend(Object obj) {
                    Object e10 = fu.c.e();
                    int i10 = this.f11886t;
                    if (i10 != 0) {
                        if (i10 != 1) {
                            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                        }
                        zt.o.b(obj);
                        return obj;
                    }
                    zt.o.b(obj);
                    Function1 function1 = this.f11888v;
                    this.f11886t = 1;
                    kotlin.jvm.internal.l.c(6);
                    Object invoke = function1.invoke(this);
                    kotlin.jvm.internal.l.c(7);
                    return invoke == e10 ? e10 : invoke;
                }

                @Override // kotlin.jvm.functions.Function2
                /* renamed from: m, reason: merged with bridge method [inline-methods] */
                public final Object invoke(f0<R> f0Var, eu.b<? super R> bVar) {
                    return ((C0215a) create(f0Var, bVar)).invokeSuspend(Unit.f21504a);
                }
            }

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            public a(boolean z10, boolean z11, u uVar, eu.b bVar, Function1 function1) {
                super(2, bVar);
                this.f11882w = z10;
                this.f11883x = z11;
                this.f11884y = uVar;
                this.f11885z = function1;
            }

            @Override // gu.a
            public final eu.b<Unit> create(Object obj, eu.b<?> bVar) {
                a aVar = new a(this.f11882w, this.f11883x, this.f11884y, bVar, this.f11885z);
                aVar.f11881v = obj;
                return aVar;
            }

            /* JADX WARN: Code restructure failed: missing block: B:29:0x00a5, code lost:
            
                if (r9 == r0) goto L51;
             */
            /* JADX WARN: Code restructure failed: missing block: B:34:0x008b, code lost:
            
                if (r9.A(r8) == r0) goto L51;
             */
            /* JADX WARN: Removed duplicated region for block: B:16:0x00c1  */
            @Override // gu.a
            /*
                Code decompiled incorrectly, please refer to instructions dump.
                To view partially-correct add '--show-bad-code' argument
            */
            public final java.lang.Object invokeSuspend(java.lang.Object r9) {
                /*
                    Method dump skipped, instructions count: 224
                    To view this dump add '--comments-level debug' option
                */
                throw new UnsupportedOperationException("Method not decompiled: d5.c.d.a.invokeSuspend(java.lang.Object):java.lang.Object");
            }

            @Override // kotlin.jvm.functions.Function2
            /* renamed from: m, reason: merged with bridge method [inline-methods] */
            public final Object invoke(g0 g0Var, eu.b<? super R> bVar) {
                return ((a) create(g0Var, bVar)).invokeSuspend(Unit.f21504a);
            }
        }

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        /* JADX WARN: Multi-variable type inference failed */
        public d(u uVar, Function1<? super eu.b<? super R>, ? extends Object> function1, eu.b<? super d> bVar) {
            super(1, bVar);
            this.f11877u = uVar;
            this.f11878v = function1;
        }

        @Override // gu.a
        public final eu.b<Unit> create(eu.b<?> bVar) {
            return new d(this.f11877u, this.f11878v, bVar);
        }

        @Override // gu.a
        public final Object invokeSuspend(Object obj) {
            Object e10 = fu.c.e();
            int i10 = this.f11876t;
            if (i10 != 0) {
                if (i10 != 1) {
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                zt.o.b(obj);
                return obj;
            }
            zt.o.b(obj);
            u uVar = this.f11877u;
            a aVar = new a(true, false, uVar, null, this.f11878v);
            this.f11876t = 1;
            Object W = uVar.W(false, aVar, this);
            return W == e10 ? e10 : W;
        }

        @Override // kotlin.jvm.functions.Function1
        /* renamed from: m, reason: merged with bridge method [inline-methods] */
        public final Object invoke(eu.b<? super R> bVar) {
            return ((d) create(bVar)).invokeSuspend(Unit.f21504a);
        }
    }

    /* JADX INFO: Add missing generic type declarations: [R] */
    @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\u0010\u0003\u001a\u00028\u0000\"\u0004\b\u0000\u0010\u00002\u0006\u0010\u0002\u001a\u00020\u0001H\n"}, d2 = {"R", "Ly4/g0;", "transactor", "<anonymous>"}, k = 3, mv = {2, 1, 0})
    @gu.f(c = "androidx.room.util.DBUtil__DBUtil_androidKt$performInTransactionSuspending$lambda$3$$inlined$internalPerform$1", f = "DBUtil.android.kt", l = {56, 57, 59, 60, 172}, m = "invokeSuspend")
    public static final class e<R> extends gu.m implements Function2<g0, eu.b<? super R>, Object> {

        /* renamed from: t, reason: collision with root package name */
        public Object f11889t;

        /* renamed from: u, reason: collision with root package name */
        public int f11890u;

        /* renamed from: v, reason: collision with root package name */
        public /* synthetic */ Object f11891v;

        /* renamed from: w, reason: collision with root package name */
        public final /* synthetic */ boolean f11892w;

        /* renamed from: x, reason: collision with root package name */
        public final /* synthetic */ boolean f11893x;

        /* renamed from: y, reason: collision with root package name */
        public final /* synthetic */ u f11894y;

        /* renamed from: z, reason: collision with root package name */
        public final /* synthetic */ Function1 f11895z;

        @Metadata(d1 = {"\u0000\b\n\u0000\n\u0002\u0018\u0002\n\u0000\u0010\u0002\u001a\u00028\u0000\"\u0004\b\u0000\u0010\u0000*\b\u0012\u0004\u0012\u00028\u00000\u0001H\n"}, d2 = {"R", "Ly4/f0;", "<anonymous>"}, k = 3, mv = {2, 1, 0})
        @gu.f(c = "androidx.room.util.DBUtil__DBUtil_androidKt$performInTransactionSuspending$lambda$3$$inlined$internalPerform$1$1", f = "DBUtil.android.kt", l = {60}, m = "invokeSuspend")
        public static final class a extends gu.m implements Function2<f0<R>, eu.b<? super R>, Object> {

            /* renamed from: t, reason: collision with root package name */
            public int f11896t;

            /* renamed from: u, reason: collision with root package name */
            public /* synthetic */ Object f11897u;

            /* renamed from: v, reason: collision with root package name */
            public final /* synthetic */ Function1 f11898v;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            public a(eu.b bVar, Function1 function1) {
                super(2, bVar);
                this.f11898v = function1;
            }

            @Override // gu.a
            public final eu.b<Unit> create(Object obj, eu.b<?> bVar) {
                a aVar = new a(bVar, this.f11898v);
                aVar.f11897u = obj;
                return aVar;
            }

            @Override // gu.a
            public final Object invokeSuspend(Object obj) {
                Object e10 = fu.c.e();
                int i10 = this.f11896t;
                if (i10 != 0) {
                    if (i10 != 1) {
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                    zt.o.b(obj);
                    return obj;
                }
                zt.o.b(obj);
                Function1 function1 = this.f11898v;
                this.f11896t = 1;
                kotlin.jvm.internal.l.c(6);
                Object invoke = function1.invoke(this);
                kotlin.jvm.internal.l.c(7);
                return invoke == e10 ? e10 : invoke;
            }

            @Override // kotlin.jvm.functions.Function2
            /* renamed from: m, reason: merged with bridge method [inline-methods] */
            public final Object invoke(f0<R> f0Var, eu.b<? super R> bVar) {
                return ((a) create(f0Var, bVar)).invokeSuspend(Unit.f21504a);
            }
        }

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public e(boolean z10, boolean z11, u uVar, eu.b bVar, Function1 function1) {
            super(2, bVar);
            this.f11892w = z10;
            this.f11893x = z11;
            this.f11894y = uVar;
            this.f11895z = function1;
        }

        @Override // gu.a
        public final eu.b<Unit> create(Object obj, eu.b<?> bVar) {
            e eVar = new e(this.f11892w, this.f11893x, this.f11894y, bVar, this.f11895z);
            eVar.f11891v = obj;
            return eVar;
        }

        /* JADX WARN: Code restructure failed: missing block: B:29:0x00a5, code lost:
        
            if (r9 == r0) goto L51;
         */
        /* JADX WARN: Code restructure failed: missing block: B:34:0x008b, code lost:
        
            if (r9.A(r8) == r0) goto L51;
         */
        /* JADX WARN: Removed duplicated region for block: B:16:0x00c1  */
        @Override // gu.a
        /*
            Code decompiled incorrectly, please refer to instructions dump.
            To view partially-correct add '--show-bad-code' argument
        */
        public final java.lang.Object invokeSuspend(java.lang.Object r9) {
            /*
                Method dump skipped, instructions count: 224
                To view this dump add '--comments-level debug' option
            */
            throw new UnsupportedOperationException("Method not decompiled: d5.c.e.invokeSuspend(java.lang.Object):java.lang.Object");
        }

        @Override // kotlin.jvm.functions.Function2
        /* renamed from: m, reason: merged with bridge method [inline-methods] */
        public final Object invoke(g0 g0Var, eu.b<? super R> bVar) {
            return ((e) create(g0Var, bVar)).invokeSuspend(Unit.f21504a);
        }
    }

    /* JADX INFO: Add missing generic type declarations: [R] */
    @Metadata(d1 = {"\u0000\b\n\u0000\n\u0002\u0018\u0002\n\u0000\u0010\u0002\u001a\u00028\u0000\"\u0004\b\u0000\u0010\u0000*\u00020\u0001H\n"}, d2 = {"R", "Lav/p0;", "<anonymous>"}, k = 3, mv = {2, 1, 0})
    @gu.f(c = "androidx.room.util.DBUtil__DBUtil_androidKt$performSuspending$$inlined$compatCoroutineExecute$DBUtil__DBUtil_androidKt$1", f = "DBUtil.android.kt", l = {261}, m = "invokeSuspend")
    public static final class f<R> extends gu.m implements Function2<p0, eu.b<? super R>, Object> {

        /* renamed from: t, reason: collision with root package name */
        public int f11899t;

        /* renamed from: u, reason: collision with root package name */
        public final /* synthetic */ u f11900u;

        /* renamed from: v, reason: collision with root package name */
        public final /* synthetic */ boolean f11901v;

        /* renamed from: w, reason: collision with root package name */
        public final /* synthetic */ boolean f11902w;

        /* renamed from: x, reason: collision with root package name */
        public final /* synthetic */ Function1 f11903x;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public f(eu.b bVar, u uVar, boolean z10, boolean z11, Function1 function1) {
            super(2, bVar);
            this.f11900u = uVar;
            this.f11901v = z10;
            this.f11902w = z11;
            this.f11903x = function1;
        }

        @Override // gu.a
        public final eu.b<Unit> create(Object obj, eu.b<?> bVar) {
            return new f(bVar, this.f11900u, this.f11901v, this.f11902w, this.f11903x);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(p0 p0Var, eu.b<? super R> bVar) {
            return ((f) create(p0Var, bVar)).invokeSuspend(Unit.f21504a);
        }

        @Override // gu.a
        public final Object invokeSuspend(Object obj) {
            Object e10 = fu.c.e();
            int i10 = this.f11899t;
            if (i10 != 0) {
                if (i10 != 1) {
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                zt.o.b(obj);
                return obj;
            }
            zt.o.b(obj);
            u uVar = this.f11900u;
            boolean z10 = this.f11901v;
            h hVar = new h(this.f11902w, z10, uVar, null, this.f11903x);
            this.f11899t = 1;
            Object W = uVar.W(z10, hVar, this);
            return W == e10 ? e10 : W;
        }
    }

    @Metadata(k = 3, mv = {2, 1, 0}, xi = 48)
    @gu.f(c = "androidx.room.util.DBUtil__DBUtil_androidKt", f = "DBUtil.android.kt", l = {262, 264, 264}, m = "performSuspending")
    public static final class g<R> extends gu.d {

        /* renamed from: t, reason: collision with root package name */
        public Object f11904t;

        /* renamed from: u, reason: collision with root package name */
        public Object f11905u;

        /* renamed from: v, reason: collision with root package name */
        public boolean f11906v;

        /* renamed from: w, reason: collision with root package name */
        public boolean f11907w;

        /* renamed from: x, reason: collision with root package name */
        public /* synthetic */ Object f11908x;

        /* renamed from: y, reason: collision with root package name */
        public int f11909y;

        public g(eu.b<? super g> bVar) {
            super(bVar);
        }

        @Override // gu.a
        @Nullable
        public final Object invokeSuspend(@NotNull Object obj) {
            this.f11908x = obj;
            this.f11909y |= Integer.MIN_VALUE;
            return d5.a.e(null, false, false, null, this);
        }
    }

    /* JADX INFO: Add missing generic type declarations: [R] */
    @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\u0010\u0003\u001a\u00028\u0000\"\u0004\b\u0000\u0010\u00002\u0006\u0010\u0002\u001a\u00020\u0001H\n"}, d2 = {"R", "Ly4/g0;", "transactor", "<anonymous>"}, k = 3, mv = {2, 1, 0})
    @gu.f(c = "androidx.room.util.DBUtil__DBUtil_androidKt$performSuspending$lambda$1$$inlined$internalPerform$1", f = "DBUtil.android.kt", l = {56, 57, 59, 60}, m = "invokeSuspend")
    public static final class h<R> extends gu.m implements Function2<g0, eu.b<? super R>, Object> {

        /* renamed from: t, reason: collision with root package name */
        public Object f11910t;

        /* renamed from: u, reason: collision with root package name */
        public int f11911u;

        /* renamed from: v, reason: collision with root package name */
        public /* synthetic */ Object f11912v;

        /* renamed from: w, reason: collision with root package name */
        public final /* synthetic */ boolean f11913w;

        /* renamed from: x, reason: collision with root package name */
        public final /* synthetic */ boolean f11914x;

        /* renamed from: y, reason: collision with root package name */
        public final /* synthetic */ u f11915y;

        /* renamed from: z, reason: collision with root package name */
        public final /* synthetic */ Function1 f11916z;

        @Metadata(d1 = {"\u0000\b\n\u0000\n\u0002\u0018\u0002\n\u0000\u0010\u0002\u001a\u00028\u0000\"\u0004\b\u0000\u0010\u0000*\b\u0012\u0004\u0012\u00028\u00000\u0001H\n"}, d2 = {"R", "Ly4/f0;", "<anonymous>"}, k = 3, mv = {2, 1, 0})
        @gu.f(c = "androidx.room.util.DBUtil__DBUtil_androidKt$performSuspending$lambda$1$$inlined$internalPerform$1$1", f = "DBUtil.android.kt", l = {}, m = "invokeSuspend")
        public static final class a extends gu.m implements Function2<f0<R>, eu.b<? super R>, Object> {

            /* renamed from: t, reason: collision with root package name */
            public int f11917t;

            /* renamed from: u, reason: collision with root package name */
            public /* synthetic */ Object f11918u;

            /* renamed from: v, reason: collision with root package name */
            public final /* synthetic */ Function1 f11919v;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            public a(eu.b bVar, Function1 function1) {
                super(2, bVar);
                this.f11919v = function1;
            }

            @Override // gu.a
            public final eu.b<Unit> create(Object obj, eu.b<?> bVar) {
                a aVar = new a(bVar, this.f11919v);
                aVar.f11918u = obj;
                return aVar;
            }

            @Override // gu.a
            public final Object invokeSuspend(Object obj) {
                fu.c.e();
                if (this.f11917t != 0) {
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                zt.o.b(obj);
                f0 f0Var = (f0) this.f11918u;
                Intrinsics.d(f0Var, "null cannot be cast to non-null type androidx.room.coroutines.RawConnectionAccessor");
                return this.f11919v.invoke(((q) f0Var).getDelegate());
            }

            @Override // kotlin.jvm.functions.Function2
            /* renamed from: m, reason: merged with bridge method [inline-methods] */
            public final Object invoke(f0<R> f0Var, eu.b<? super R> bVar) {
                return ((a) create(f0Var, bVar)).invokeSuspend(Unit.f21504a);
            }
        }

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public h(boolean z10, boolean z11, u uVar, eu.b bVar, Function1 function1) {
            super(2, bVar);
            this.f11913w = z10;
            this.f11914x = z11;
            this.f11915y = uVar;
            this.f11916z = function1;
        }

        @Override // gu.a
        public final eu.b<Unit> create(Object obj, eu.b<?> bVar) {
            h hVar = new h(this.f11913w, this.f11914x, this.f11915y, bVar, this.f11916z);
            hVar.f11912v = obj;
            return hVar;
        }

        /* JADX WARN: Code restructure failed: missing block: B:26:0x009f, code lost:
        
            if (r8 != r0) goto L37;
         */
        /* JADX WARN: Removed duplicated region for block: B:10:0x00bb  */
        @Override // gu.a
        /*
            Code decompiled incorrectly, please refer to instructions dump.
            To view partially-correct add '--show-bad-code' argument
        */
        public final java.lang.Object invokeSuspend(java.lang.Object r8) {
            /*
                Method dump skipped, instructions count: 216
                To view this dump add '--comments-level debug' option
            */
            throw new UnsupportedOperationException("Method not decompiled: d5.c.h.invokeSuspend(java.lang.Object):java.lang.Object");
        }

        @Override // kotlin.jvm.functions.Function2
        /* renamed from: m, reason: merged with bridge method [inline-methods] */
        public final Object invoke(g0 g0Var, eu.b<? super R> bVar) {
            return ((h) create(g0Var, bVar)).invokeSuspend(Unit.f21504a);
        }
    }

    @Nullable
    public static final Object a(@NotNull u uVar, boolean z10, @NotNull eu.b<? super CoroutineContext> bVar) {
        c0 c0Var = (c0) bVar.getContext().get(c0.INSTANCE);
        CoroutineContext transactionDispatcher = c0Var != null ? c0Var.getTransactionDispatcher() : null;
        if (uVar.F()) {
            return transactionDispatcher != null ? uVar.v().plus(transactionDispatcher) : z10 ? uVar.C() : uVar.v();
        }
        CoroutineContext v8 = uVar.v();
        if (transactionDispatcher == null) {
            transactionDispatcher = kotlin.coroutines.e.f21546a;
        }
        return v8.plus(transactionDispatcher);
    }

    public static final <R> R b(@NotNull u db2, boolean z10, boolean z11, @NotNull Function1<? super g5.b, ? extends R> block) {
        Intrinsics.checkNotNullParameter(db2, "db");
        Intrinsics.checkNotNullParameter(block, "block");
        db2.g();
        db2.h();
        CoroutineContext coroutineContext = db2.B().get();
        if (coroutineContext == null) {
            coroutineContext = kotlin.coroutines.e.f21546a;
        }
        return (R) r.a(new a(coroutineContext, db2, z11, z10, block, null));
    }

    /* JADX WARN: Removed duplicated region for block: B:21:0x00b2 A[RETURN] */
    /* JADX WARN: Removed duplicated region for block: B:22:0x00b3 A[RETURN] */
    /* JADX WARN: Removed duplicated region for block: B:27:0x0051  */
    /* JADX WARN: Removed duplicated region for block: B:9:0x0029  */
    @org.jetbrains.annotations.Nullable
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public static final <R> java.lang.Object c(@org.jetbrains.annotations.NotNull y4.u r11, @org.jetbrains.annotations.NotNull kotlin.jvm.functions.Function1<? super eu.b<? super R>, ? extends java.lang.Object> r12, @org.jetbrains.annotations.NotNull eu.b<? super R> r13) {
        /*
            boolean r1 = r13 instanceof d5.c.C0214c
            if (r1 == 0) goto L14
            r1 = r13
            d5.c$c r1 = (d5.c.C0214c) r1
            int r2 = r1.f11875w
            r4 = -2147483648(0xffffffff80000000, float:-0.0)
            r6 = r2 & r4
            if (r6 == 0) goto L14
            int r2 = r2 - r4
            r1.f11875w = r2
        L12:
            r6 = r1
            goto L1a
        L14:
            d5.c$c r1 = new d5.c$c
            r1.<init>(r13)
            goto L12
        L1a:
            java.lang.Object r0 = r6.f11874v
            java.lang.Object r7 = fu.c.e()
            int r1 = r6.f11875w
            r2 = 4
            r4 = 3
            r8 = 2
            r9 = 1
            r10 = 0
            if (r1 == 0) goto L51
            if (r1 == r9) goto L4d
            if (r1 == r8) goto L49
            if (r1 == r4) goto L3d
            if (r1 != r2) goto L35
            zt.o.b(r0)
            return r0
        L35:
            java.lang.IllegalStateException r0 = new java.lang.IllegalStateException
            java.lang.String r1 = "call to 'resume' before 'invoke' with coroutine"
            r0.<init>(r1)
            throw r0
        L3d:
            java.lang.Object r1 = r6.f11873u
            kotlin.jvm.functions.Function1 r1 = (kotlin.jvm.functions.Function1) r1
            java.lang.Object r3 = r6.f11872t
            y4.u r3 = (y4.u) r3
            zt.o.b(r0)
            goto L9f
        L49:
            zt.o.b(r0)
            return r0
        L4d:
            zt.o.b(r0)
            return r0
        L51:
            zt.o.b(r0)
            boolean r0 = r11.F()
            if (r0 == 0) goto L69
            d5.c$d r0 = new d5.c$d
            r0.<init>(r11, r12, r10)
            r6.f11875w = r9
            java.lang.Object r0 = y4.v.e(r11, r0, r6)
            if (r0 != r7) goto L68
            goto Lb2
        L68:
            return r0
        L69:
            boolean r0 = r11.F()
            if (r0 == 0) goto L90
            boolean r0 = r11.M()
            if (r0 == 0) goto L90
            boolean r0 = r11.G()
            if (r0 == 0) goto L90
            d5.c$e r0 = new d5.c$e
            r2 = 0
            r4 = 0
            r1 = 1
            r3 = r11
            r5 = r12
            r0.<init>(r1, r2, r3, r4, r5)
            r6.f11875w = r8
            r1 = 0
            java.lang.Object r0 = r11.W(r1, r0, r6)
            if (r0 != r7) goto L8f
            goto Lb2
        L8f:
            return r0
        L90:
            r6.f11872t = r11
            r6.f11873u = r12
            r6.f11875w = r4
            java.lang.Object r0 = d5.a.b(r11, r9, r6)
            if (r0 != r7) goto L9d
            goto Lb2
        L9d:
            r3 = r11
            r1 = r12
        L9f:
            kotlin.coroutines.CoroutineContext r0 = (kotlin.coroutines.CoroutineContext) r0
            d5.c$b r4 = new d5.c$b
            r4.<init>(r10, r3, r1)
            r6.f11872t = r10
            r6.f11873u = r10
            r6.f11875w = r2
            java.lang.Object r0 = av.i.g(r0, r4, r6)
            if (r0 != r7) goto Lb3
        Lb2:
            return r7
        Lb3:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: d5.c.c(y4.u, kotlin.jvm.functions.Function1, eu.b):java.lang.Object");
    }

    /* JADX WARN: Removed duplicated region for block: B:21:0x00ae A[RETURN] */
    /* JADX WARN: Removed duplicated region for block: B:22:0x00af A[RETURN] */
    /* JADX WARN: Removed duplicated region for block: B:25:0x0053  */
    /* JADX WARN: Removed duplicated region for block: B:9:0x0029  */
    @org.jetbrains.annotations.Nullable
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public static final <R> java.lang.Object d(@org.jetbrains.annotations.NotNull y4.u r14, boolean r15, boolean r16, @org.jetbrains.annotations.NotNull kotlin.jvm.functions.Function1<? super g5.b, ? extends R> r17, @org.jetbrains.annotations.NotNull eu.b<? super R> r18) {
        /*
            r0 = r18
            boolean r1 = r0 instanceof d5.c.g
            if (r1 == 0) goto L16
            r1 = r0
            d5.c$g r1 = (d5.c.g) r1
            int r2 = r1.f11909y
            r3 = -2147483648(0xffffffff80000000, float:-0.0)
            r4 = r2 & r3
            if (r4 == 0) goto L16
            int r2 = r2 - r3
            r1.f11909y = r2
        L14:
            r6 = r1
            goto L1c
        L16:
            d5.c$g r1 = new d5.c$g
            r1.<init>(r0)
            goto L14
        L1c:
            java.lang.Object r0 = r6.f11908x
            java.lang.Object r7 = fu.c.e()
            int r1 = r6.f11909y
            r2 = 3
            r3 = 2
            r8 = 1
            if (r1 == 0) goto L53
            if (r1 == r8) goto L4f
            if (r1 == r3) goto L3b
            if (r1 != r2) goto L33
            zt.o.b(r0)
            return r0
        L33:
            java.lang.IllegalStateException r14 = new java.lang.IllegalStateException
            java.lang.String r15 = "call to 'resume' before 'invoke' with coroutine"
            r14.<init>(r15)
            throw r14
        L3b:
            boolean r14 = r6.f11907w
            boolean r15 = r6.f11906v
            java.lang.Object r1 = r6.f11905u
            kotlin.jvm.functions.Function1 r1 = (kotlin.jvm.functions.Function1) r1
            java.lang.Object r3 = r6.f11904t
            y4.u r3 = (y4.u) r3
            zt.o.b(r0)
            r12 = r14
            r13 = r1
            r10 = r3
        L4d:
            r11 = r15
            goto L99
        L4f:
            zt.o.b(r0)
            return r0
        L53:
            zt.o.b(r0)
            boolean r0 = r14.F()
            if (r0 == 0) goto L7f
            boolean r0 = r14.M()
            if (r0 == 0) goto L7f
            boolean r0 = r14.G()
            if (r0 == 0) goto L7f
            d5.c$h r0 = new d5.c$h
            r4 = 0
            r3 = r14
            r2 = r15
            r1 = r16
            r5 = r17
            r0.<init>(r1, r2, r3, r4, r5)
            r2 = r0
            r6.f11909y = r8
            java.lang.Object r14 = r14.W(r15, r2, r6)
            if (r14 != r7) goto L7e
            goto Lae
        L7e:
            return r14
        L7f:
            r4 = r16
            r6.f11904t = r14
            r5 = r17
            r6.f11905u = r5
            r6.f11906v = r15
            r6.f11907w = r4
            r6.f11909y = r3
            java.lang.Object r3 = d5.a.b(r14, r4, r6)
            if (r3 != r7) goto L94
            goto Lae
        L94:
            r10 = r14
            r0 = r3
            r12 = r4
            r13 = r5
            goto L4d
        L99:
            kotlin.coroutines.CoroutineContext r0 = (kotlin.coroutines.CoroutineContext) r0
            d5.c$f r8 = new d5.c$f
            r9 = 0
            r8.<init>(r9, r10, r11, r12, r13)
            r14 = 0
            r6.f11904t = r14
            r6.f11905u = r14
            r6.f11909y = r2
            java.lang.Object r14 = av.i.g(r0, r8, r6)
            if (r14 != r7) goto Laf
        Lae:
            return r7
        Laf:
            return r14
        */
        throw new UnsupportedOperationException("Method not decompiled: d5.c.d(y4.u, boolean, boolean, kotlin.jvm.functions.Function1, eu.b):java.lang.Object");
    }

    public static final int e(@NotNull File databaseFile) {
        Intrinsics.checkNotNullParameter(databaseFile, "databaseFile");
        FileChannel channel = new FileInputStream(databaseFile).getChannel();
        try {
            ByteBuffer allocate = ByteBuffer.allocate(4);
            channel.tryLock(60L, 4L, true);
            channel.position(60L);
            if (channel.read(allocate) != 4) {
                throw new IOException("Bad database header, unable to read 4 bytes at offset 60");
            }
            allocate.rewind();
            int i10 = allocate.getInt();
            lu.c.a(channel, null);
            return i10;
        } catch (Throwable th2) {
            try {
                throw th2;
            } catch (Throwable th3) {
                lu.c.a(channel, th2);
                throw th3;
            }
        }
    }


    // --- восстановлено из DEX (d5/c$a$a) ---
    public static class a extends gu.m implements kotlin.jvm.functions.Function2 {
        int t;
        y4.u u;
        boolean v;
        boolean w;
        kotlin.jvm.functions.Function1 x;
        public a(y4.u p0, boolean p1, boolean p2, kotlin.jvm.functions.Function1 p3, eu.b p4) { }
        public eu.b create(java.lang.Object p0, eu.b p1) { throw new UnsupportedOperationException("stub"); }
        public java.lang.Object invoke(av.p0 p0, eu.b p1) { throw new UnsupportedOperationException("stub"); }
        public java.lang.Object invoke(java.lang.Object p0, java.lang.Object p1) { throw new UnsupportedOperationException("stub"); }
        public java.lang.Object invokeSuspend(java.lang.Object p0) { throw new UnsupportedOperationException("stub"); }
    }

    // --- восстановлено из DEX (d5/c$a$a$a) ---
    public static class a extends gu.m implements kotlin.jvm.functions.Function2 {
        java.lang.Object t;
        int u;
        java.lang.Object v;
        boolean w;
        boolean x;
        y4.u y;
        kotlin.jvm.functions.Function1 z;
        public a(boolean p0, boolean p1, y4.u p2, eu.b p3, kotlin.jvm.functions.Function1 p4) { }
        public eu.b create(java.lang.Object p0, eu.b p1) { throw new UnsupportedOperationException("stub"); }
        public java.lang.Object invoke(java.lang.Object p0, java.lang.Object p1) { throw new UnsupportedOperationException("stub"); }
        public java.lang.Object invokeSuspend(java.lang.Object p0) { throw new UnsupportedOperationException("stub"); }
        public java.lang.Object m(y4.g0 p0, eu.b p1) { throw new UnsupportedOperationException("stub"); }
    }

    // --- восстановлено из DEX (d5/c$a$a$a$a) ---
    public static class a extends gu.m implements kotlin.jvm.functions.Function2 {
        int t;
        java.lang.Object u;
        kotlin.jvm.functions.Function1 v;
        public a(eu.b p0, kotlin.jvm.functions.Function1 p1) { }
        public eu.b create(java.lang.Object p0, eu.b p1) { throw new UnsupportedOperationException("stub"); }
        public java.lang.Object invoke(java.lang.Object p0, java.lang.Object p1) { throw new UnsupportedOperationException("stub"); }
        public java.lang.Object invokeSuspend(java.lang.Object p0) { throw new UnsupportedOperationException("stub"); }
        public java.lang.Object m(y4.f0 p0, eu.b p1) { throw new UnsupportedOperationException("stub"); }
    }

    // --- восстановлено из DEX (d5/c$d$a) ---
    public static class a extends gu.m implements kotlin.jvm.functions.Function2 {
        java.lang.Object t;
        int u;
        java.lang.Object v;
        boolean w;
        boolean x;
        y4.u y;
        kotlin.jvm.functions.Function1 z;
        public a(boolean p0, boolean p1, y4.u p2, eu.b p3, kotlin.jvm.functions.Function1 p4) { }
        public eu.b create(java.lang.Object p0, eu.b p1) { throw new UnsupportedOperationException("stub"); }
        public java.lang.Object invoke(java.lang.Object p0, java.lang.Object p1) { throw new UnsupportedOperationException("stub"); }
        public java.lang.Object invokeSuspend(java.lang.Object p0) { throw new UnsupportedOperationException("stub"); }
        public java.lang.Object m(y4.g0 p0, eu.b p1) { throw new UnsupportedOperationException("stub"); }
    }

    // --- восстановлено из DEX (d5/c$d$a$a) ---
    public static class a extends gu.m implements kotlin.jvm.functions.Function2 {
        int t;
        java.lang.Object u;
        kotlin.jvm.functions.Function1 v;
        public a(eu.b p0, kotlin.jvm.functions.Function1 p1) { }
        public eu.b create(java.lang.Object p0, eu.b p1) { throw new UnsupportedOperationException("stub"); }
        public java.lang.Object invoke(java.lang.Object p0, java.lang.Object p1) { throw new UnsupportedOperationException("stub"); }
        public java.lang.Object invokeSuspend(java.lang.Object p0) { throw new UnsupportedOperationException("stub"); }
        public java.lang.Object m(y4.f0 p0, eu.b p1) { throw new UnsupportedOperationException("stub"); }
    }

    // --- восстановлено из DEX (d5/c$e$a) ---
    public static class a extends gu.m implements kotlin.jvm.functions.Function2 {
        int t;
        java.lang.Object u;
        kotlin.jvm.functions.Function1 v;
        public a(eu.b p0, kotlin.jvm.functions.Function1 p1) { }
        public eu.b create(java.lang.Object p0, eu.b p1) { throw new UnsupportedOperationException("stub"); }
        public java.lang.Object invoke(java.lang.Object p0, java.lang.Object p1) { throw new UnsupportedOperationException("stub"); }
        public java.lang.Object invokeSuspend(java.lang.Object p0) { throw new UnsupportedOperationException("stub"); }
        public java.lang.Object m(y4.f0 p0, eu.b p1) { throw new UnsupportedOperationException("stub"); }
    }

    // --- восстановлено из DEX (d5/c$h$a) ---
    public static class a extends gu.m implements kotlin.jvm.functions.Function2 {
        int t;
        java.lang.Object u;
        kotlin.jvm.functions.Function1 v;
        public a(eu.b p0, kotlin.jvm.functions.Function1 p1) { }
        public eu.b create(java.lang.Object p0, eu.b p1) { throw new UnsupportedOperationException("stub"); }
        public java.lang.Object invoke(java.lang.Object p0, java.lang.Object p1) { throw new UnsupportedOperationException("stub"); }
        public java.lang.Object invokeSuspend(java.lang.Object p0) { throw new UnsupportedOperationException("stub"); }
        public java.lang.Object m(y4.f0 p0, eu.b p1) { throw new UnsupportedOperationException("stub"); }
    }
}
