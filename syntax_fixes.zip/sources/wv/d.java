package wv;

import com.github.luben.zstd.BuildConfig;
import com.google.mlkit.vision.barcode.common.Barcode;
import com.withpersona.sdk2.inquiry.network.dto.InquiryField;
import ew.e;
import ew.h;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.NoSuchElementException;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.StringsKt;
import kotlin.text.x;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(d1 = {"\u0000:\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\b\u0004\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0002\b\n\n\u0002\u0010 \n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\b\b\bÆ\u0002\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\u0017\u0010\u0006\u001a\u0004\u0018\u00010\u00042\u0006\u0010\u0005\u001a\u00020\u0004¢\u0006\u0004\b\u0006\u0010\u0007J\u0017\u0010\b\u001a\u0004\u0018\u00010\u00042\u0006\u0010\u0005\u001a\u00020\u0004¢\u0006\u0004\b\b\u0010\u0007J/\u0010\u000f\u001a\u00020\u000e2\u0006\u0010\u0005\u001a\u00020\u00042\u0006\u0010\n\u001a\u00020\t2\u0006\u0010\u000b\u001a\u00020\t2\u0006\u0010\r\u001a\u00020\fH\u0002¢\u0006\u0004\b\u000f\u0010\u0010J/\u0010\u0011\u001a\u00020\u000e2\u0006\u0010\u0005\u001a\u00020\u00042\u0006\u0010\n\u001a\u00020\t2\u0006\u0010\u000b\u001a\u00020\t2\u0006\u0010\r\u001a\u00020\fH\u0002¢\u0006\u0004\b\u0011\u0010\u0010J'\u0010\u0015\u001a\u00020\t2\u0006\u0010\u0012\u001a\u00020\t2\u0006\u0010\u0013\u001a\u00020\t2\u0006\u0010\u0014\u001a\u00020\u000eH\u0002¢\u0006\u0004\b\u0015\u0010\u0016J#\u0010\u0017\u001a\u00020\u000e*\u00020\u00042\u0006\u0010\n\u001a\u00020\t2\u0006\u0010\u000b\u001a\u00020\tH\u0002¢\u0006\u0004\b\u0017\u0010\u0018J)\u0010\u001a\u001a\b\u0012\u0004\u0012\u00020\t0\u0019*\u00020\u00042\u0006\u0010\n\u001a\u00020\t2\u0006\u0010\u000b\u001a\u00020\tH\u0002¢\u0006\u0004\b\u001a\u0010\u001bR\u001a\u0010\u001f\u001a\u00020\u00048\u0006X\u0086D¢\u0006\f\n\u0004\b\u001a\u0010\u001c\u001a\u0004\b\u001d\u0010\u001eR\u0017\u0010$\u001a\u00020 8\u0006¢\u0006\f\n\u0004\b\b\u0010!\u001a\u0004\b\"\u0010#R\u0018\u0010'\u001a\u00020\t*\u00020\t8BX\u0082\u0004¢\u0006\u0006\u001a\u0004\b%\u0010&¨\u0006("}, d2 = {"Lwv/d;", BuildConfig.FLAVOR, "<init>", "()V", BuildConfig.FLAVOR, InquiryField.StringField.TYPE, "e", "(Ljava/lang/String;)Ljava/lang/String;", "c", BuildConfig.FLAVOR, "pos", "limit", "Lew/e;", "result", BuildConfig.FLAVOR, "f", "(Ljava/lang/String;IILew/e;)Z", "d", "delta", "numpoints", "first", xe.a.f36648e, "(IIZ)I", "h", "(Ljava/lang/String;II)Z", BuildConfig.FLAVOR, k6.b.f21144e, "(Ljava/lang/String;II)Ljava/util/List;", "Ljava/lang/String;", "getPREFIX_STRING", "()Ljava/lang/String;", "PREFIX_STRING", "Lew/h;", "Lew/h;", "getPREFIX", "()Lew/h;", "PREFIX", "g", "(I)I", "punycodeDigit", "okhttp"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* loaded from: classes2.dex */
public final class d {

    /* renamed from: a, reason: collision with root package name */
    @NotNull
    public static final d f36014a = new d();

    /* renamed from: b, reason: from kotlin metadata */
    @NotNull
    public static final String PREFIX_STRING = "xn--";

    /* renamed from: c, reason: collision with root package name and from kotlin metadata */
    @NotNull
    public static final h PREFIX = h.INSTANCE.d("xn--");

    public final int a(int delta, int numpoints, boolean first) {
        int i10 = first ? delta / 700 : delta / 2;
        int i11 = i10 + (i10 / numpoints);
        int i12 = 0;
        while (i11 > 455) {
            i11 /= 35;
            i12 += 36;
        }
        return i12 + ((i11 * 36) / (i11 + 38));
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r1v0, types: [char] */
    /* JADX WARN: Type inference failed for: r1v3 */
    /* JADX WARN: Type inference failed for: r1v6, types: [int] */
    public final List<Integer> b(String str, int i10, int i11) {
        ArrayList arrayList = new ArrayList();
        while (i10 < i11) {
            int charAt = str.charAt(i10);
            if (kotlin.text.b.e(charAt)) {
                int i12 = i10 + 1;
                char charAt2 = i12 < i11 ? str.charAt(i12) : (char) 0;
                if (Character.isLowSurrogate(charAt) || !Character.isLowSurrogate(charAt2)) {
                    charAt = 63;
                } else {
                    charAt = 65536 + (((charAt & 1023) << 10) | (charAt2 & 1023));
                    i10 = i12;
                }
            }
            arrayList.add(Integer.valueOf(charAt));
            i10++;
        }
        return arrayList;
    }

    @Nullable
    public final String c(@NotNull String string) {
        Intrinsics.checkNotNullParameter(string, "string");
        int length = string.length();
        e eVar = new e();
        int i10 = 0;
        while (i10 < length) {
            String str = string;
            int m02 = StringsKt.m0(str, '.', i10, false, 4, null);
            if (m02 == -1) {
                m02 = length;
            }
            if (!d(str, i10, m02, eVar)) {
                return null;
            }
            if (m02 >= length) {
                break;
            }
            eVar.writeByte(46);
            i10 = m02 + 1;
            string = str;
        }
        return eVar.V2();
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r10v0, types: [java.util.ArrayList, java.util.Collection, java.util.List] */
    /* JADX WARN: Type inference failed for: r13v2, types: [int] */
    /* JADX WARN: Type inference failed for: r13v8 */
    /* JADX WARN: Type inference failed for: r13v9 */
    /* JADX WARN: Type inference failed for: r16v0, types: [boolean] */
    public final boolean d(String string, int pos, int limit, e result) {
        int i10;
        int i11;
        int i12 = 1;
        if (!x.H(string, pos, PREFIX_STRING, 0, 4, true)) {
            result.L0(string, pos, limit);
            return true;
        }
        int i13 = pos + 4;
        var arrayList = new ArrayList();
        int s02 = StringsKt.s0(string, '-', limit, false, 4, null);
        char c10 = '0';
        char c11 = '[';
        char c12 = '{';
        boolean z10 = false;
        if (s02 >= i13) {
            while (i13 < s02) {
                int i14 = i13 + 1;
                char charAt = string.charAt(i13);
                if (('a' > charAt || charAt >= '{') && (('A' > charAt || charAt >= '[') && (('0' > charAt || charAt >= ':') && charAt != '-'))) {
                    return false;
                }
                arrayList.add(Integer.valueOf(charAt));
                i13 = i14;
            }
            i13++;
        }
        int i15 = Barcode.FORMAT_ITF;
        int i16 = 72;
        int i17 = 0;
        while (i13 < limit) {
            int i18 = i12;
            boolean z11 = z10;
            kotlin.ranges.a p8 = kotlin.ranges.d.p(kotlin.ranges.d.q(36, Integer.MAX_VALUE), 36);
            int first = p8.getFirst();
            int last = p8.getLast();
            int step = p8.getStep();
            if ((step > 0 && first <= last) || (step < 0 && last <= first)) {
                i10 = i17;
                int i19 = i18;
                while (i13 != limit) {
                    int i20 = i13 + 1;
                    char charAt2 = string.charAt(i13);
                    if ('a' <= charAt2 && charAt2 < c12) {
                        i11 = charAt2 - 'a';
                    } else if ('A' <= charAt2 && charAt2 < c11) {
                        i11 = charAt2 - 'A';
                    } else {
                        if (c10 > charAt2 || charAt2 >= ':') {
                            return z11;
                        }
                        i11 = charAt2 - 22;
                    }
                    int i21 = i19;
                    int i22 = i11 * i21;
                    int i23 = i10;
                    if (i23 > Integer.MAX_VALUE - i22) {
                        return z11;
                    }
                    i10 = i23 + i22;
                    int i24 = first <= i16 ? i18 : first >= i16 + 26 ? 26 : first - i16;
                    if (i11 >= i24) {
                        int i25 = 36 - i24;
                        if (i21 > Integer.MAX_VALUE / i25) {
                            return z11;
                        }
                        i19 = i21 * i25;
                        if (first != last) {
                            first += step;
                            i13 = i20;
                            c10 = '0';
                            c11 = '[';
                            c12 = '{';
                        }
                    }
                    i13 = i20;
                }
                return z11;
            }
            i10 = i17;
            i16 = a(i10 - i17, arrayList.size() + 1, i17 == 0 ? i18 : z11);
            int size = i10 / (arrayList.size() + 1);
            if (i15 > Integer.MAX_VALUE - size) {
                return z11;
            }
            i15 += size;
            int size2 = i10 % (arrayList.size() + 1);
            if (i15 > 1114111) {
                return z11;
            }
            arrayList.add(size2, Integer.valueOf(i15));
            i17 = size2 + 1;
            z10 = z11;
            i12 = i18;
            c10 = '0';
            c11 = '[';
            c12 = '{';
        }
        var r16 = i12;
        int size3 = arrayList.size();
        for (var r13 = z10; r13 < size3; r13++) {
            result.X(((Number) arrayList.get(r13)).intValue());
        }
        return r16;
    }

    @Nullable
    public final String e(@NotNull String string) {
        Intrinsics.checkNotNullParameter(string, "string");
        int length = string.length();
        e eVar = new e();
        int i10 = 0;
        while (i10 < length) {
            String str = string;
            int m02 = StringsKt.m0(str, '.', i10, false, 4, null);
            if (m02 == -1) {
                m02 = length;
            }
            if (!f(str, i10, m02, eVar)) {
                return null;
            }
            if (m02 >= length) {
                break;
            }
            eVar.writeByte(46);
            i10 = m02 + 1;
            string = str;
        }
        return eVar.V2();
    }

    /* JADX WARN: Multi-variable type inference failed */
    public final boolean f(String string, int pos, int limit, e result) {
        int i10;
        int i11;
        int i12;
        int i13 = 1;
        if (!h(string, pos, limit)) {
            result.L0(string, pos, limit);
            return true;
        }
        result.z1(PREFIX);
        List<Integer> b = b(string, pos, limit);
        Iterator<Integer> it = b.iterator();
        int i14 = 0;
        while (true) {
            boolean hasNext = it.hasNext();
            i10 = Barcode.FORMAT_ITF;
            if (!hasNext) {
                break;
            }
            int intValue = it.next().intValue();
            if (intValue < 128) {
                result.writeByte(intValue);
                i14++;
            }
        }
        if (i14 > 0) {
            result.writeByte(45);
        }
        int i15 = 72;
        int i16 = 0;
        int i17 = i14;
        while (i17 < b.size()) {
            Iterator<T> it2 = b.iterator();
            if (!it2.hasNext()) {
                throw new NoSuchElementException();
            }
            Object next = it2.next();
            if (it2.hasNext()) {
                int intValue2 = ((Number) next).intValue();
                if (intValue2 < i10) {
                    intValue2 = Integer.MAX_VALUE;
                }
                do {
                    Object next2 = it2.next();
                    int intValue3 = ((Number) next2).intValue();
                    if (intValue3 < i10) {
                        intValue3 = Integer.MAX_VALUE;
                    }
                    if (intValue2 > intValue3) {
                        next = next2;
                        intValue2 = intValue3;
                    }
                } while (it2.hasNext());
            }
            int intValue4 = ((Number) next).intValue();
            int i18 = (intValue4 - i10) * (i17 + 1);
            if (i16 > Integer.MAX_VALUE - i18) {
                return false;
            }
            int i19 = i16 + i18;
            Iterator<Integer> it3 = b.iterator();
            while (it3.hasNext()) {
                int intValue5 = it3.next().intValue();
                if (intValue5 < intValue4) {
                    if (i19 == Integer.MAX_VALUE) {
                        return false;
                    }
                    i19++;
                } else if (intValue5 == intValue4) {
                    kotlin.ranges.a p8 = kotlin.ranges.d.p(kotlin.ranges.d.q(36, Integer.MAX_VALUE), 36);
                    int first = p8.getFirst();
                    int last = p8.getLast();
                    int step = p8.getStep();
                    if ((step > 0 && first <= last) || (step < 0 && last <= first)) {
                        i12 = i19;
                        while (true) {
                            if (first <= i15) {
                                i11 = i13;
                            } else {
                                i11 = i13;
                                i13 = first >= i15 + 26 ? 26 : first - i15;
                            }
                            if (i12 < i13) {
                                break;
                            }
                            int i20 = i12 - i13;
                            int i21 = 36 - i13;
                            result.writeByte(g(i13 + (i20 % i21)));
                            i12 = i20 / i21;
                            if (first == last) {
                                break;
                            }
                            first += step;
                            i13 = i11;
                        }
                    } else {
                        i11 = i13;
                        i12 = i19;
                    }
                    result.writeByte(g(i12));
                    int i22 = i17 + 1;
                    i15 = a(i19, i22, i17 == i14 ? i11 : false);
                    i17 = i22;
                    i19 = 0;
                    i13 = i11;
                }
            }
            i16 = i19 + 1;
            i10 = intValue4 + 1;
        }
        return i13;
    }

    public final int g(int i10) {
        if (i10 < 26) {
            return i10 + 97;
        }
        if (i10 < 36) {
            return i10 + 22;
        }
        throw new IllegalStateException(("unexpected digit: " + i10).toString());
    }

    public final boolean h(String str, int i10, int i11) {
        while (i10 < i11) {
            if (str.charAt(i10) >= 128) {
                return true;
            }
            i10++;
        }
        return false;
    }
}
