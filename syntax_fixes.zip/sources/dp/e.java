package dp;

import com.github.luben.zstd.BuildConfig;
import com.google.mlkit.common.MlKitException;
import java.util.Map;
import kotlin.Metadata;
import kotlin.collections.k0;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;
import pm.t;
import vo.h3;
import y5.w;
import zt.l;
import zt.s;

/* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
/* JADX WARN: Unknown enum class pattern. Please report as an issue! */
@Metadata(d1 = {"\u0000\u0014\n\u0002\u0018\u0002\n\u0002\u0010\u0010\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u001d\b\u0086\u0081\u0002\u0018\u0000 \u00072\b\u0012\u0004\u0012\u00020\u00000\u0001:\u0001\u0007B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\r\u0010\u0005\u001a\u00020\u0004¢\u0006\u0004\b\u0005\u0010\u0006j\u0002\b\u0005j\u0002\b\bj\u0002\b\tj\u0002\b\nj\u0002\b\u000bj\u0002\b\fj\u0002\b\rj\u0002\b\u000ej\u0002\b\u000fj\u0002\b\u0010j\u0002\b\u0011j\u0002\b\u0012j\u0002\b\u0013j\u0002\b\u0014j\u0002\b\u0015j\u0002\b\u0016j\u0002\b\u0017j\u0002\b\u0018j\u0002\b\u0019j\u0002\b\u001aj\u0002\b\u001bj\u0002\b\u001cj\u0002\b\u001dj\u0002\b\u001ej\u0002\b\u001fj\u0002\b ¨\u0006!"}, d2 = {"Ldp/e;", BuildConfig.FLAVOR, "<init>", "(Ljava/lang/String;I)V", "Lvo/h3;", "c", "()Lvo/h3;", xe.a.f36648e, "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", t.f29212d, "u", "v", "w", "x", "y", "z", "A", "B", "government-id_release"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* loaded from: classes3.dex */
public final class e {
    public static final e A;
    public static final e B;
    public static final /* synthetic */ e[] C;
    public static final /* synthetic */ hu.a D;

    /* renamed from: a, reason: collision with root package name and from kotlin metadata */
    @NotNull
    public static final Companion INSTANCE;

    @NotNull
    public static final Map<String, e> b;

    /* renamed from: c, reason: collision with root package name */
    public static final e f12550c;

    /* renamed from: d, reason: collision with root package name */
    public static final e f12551d;

    /* renamed from: e, reason: collision with root package name */
    public static final e f12552e;

    /* renamed from: f, reason: collision with root package name */
    public static final e f12553f;

    /* renamed from: g, reason: collision with root package name */
    public static final e f12554g;

    /* renamed from: h, reason: collision with root package name */
    public static final e f12555h;

    /* renamed from: i, reason: collision with root package name */
    public static final e f12556i;

    /* renamed from: j, reason: collision with root package name */
    public static final e f12557j;

    /* renamed from: k, reason: collision with root package name */
    public static final e f12558k;

    /* renamed from: l, reason: collision with root package name */
    public static final e f12559l;

    /* renamed from: m, reason: collision with root package name */
    public static final e f12560m;

    /* renamed from: n, reason: collision with root package name */
    public static final e f12561n;

    /* renamed from: o, reason: collision with root package name */
    public static final e f12562o;

    /* renamed from: p, reason: collision with root package name */
    public static final e f12563p;

    /* renamed from: q, reason: collision with root package name */
    public static final e f12564q;

    /* renamed from: r, reason: collision with root package name */
    public static final e f12565r;

    /* renamed from: s, reason: collision with root package name */
    public static final e f12566s;

    /* renamed from: t, reason: collision with root package name */
    public static final e f12567t;

    /* renamed from: u, reason: collision with root package name */
    public static final e f12568u;

    /* renamed from: v, reason: collision with root package name */
    public static final e f12569v;

    /* renamed from: w, reason: collision with root package name */
    public static final e f12570w;

    /* renamed from: x, reason: collision with root package name */
    public static final e f12571x;

    /* renamed from: y, reason: collision with root package name */
    public static final e f12572y;

    /* renamed from: z, reason: collision with root package name */
    public static final e f12573z;

    @Metadata(d1 = {"\u0000\"\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010$\n\u0002\b\u0003\b\u0086\u0003\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\u0015\u0010\u0007\u001a\u00020\u00062\u0006\u0010\u0005\u001a\u00020\u0004¢\u0006\u0004\b\u0007\u0010\bR\u0014\u0010\t\u001a\u00020\u00048\u0006X\u0086T¢\u0006\u0006\n\u0004\b\t\u0010\nR \u0010\f\u001a\u000e\u0012\u0004\u0012\u00020\u0004\u0012\u0004\u0012\u00020\u00060\u000b8\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b\f\u0010\r¨\u0006\u000e"}, d2 = {"Ldp/e$a;", BuildConfig.FLAVOR, "<init>", "()V", BuildConfig.FLAVOR, "abbr", "Ldp/e;", xe.a.f36648e, "(Ljava/lang/String;)Ldp/e;", "KeyAutoClassification", "Ljava/lang/String;", BuildConfig.FLAVOR, "codes", "Ljava/util/Map;", "government-id_release"}, k = 1, mv = {2, 2, 0}, xi = 48)
    /* renamed from: dp.e$a, reason: from kotlin metadata */
    public static final class Companion {
        public /* synthetic */ Companion(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }

        @NotNull
        public final e a(@NotNull String abbr) {
            Intrinsics.checkNotNullParameter(abbr, "abbr");
            e eVar = (e) e.b.get(abbr);
            return eVar == null ? e.B : eVar;
        }

        public Companion() {
        }
    }

    @Metadata(k = 3, mv = {2, 2, 0}, xi = 48)
    public static final /* synthetic */ class b {

        /* renamed from: a, reason: collision with root package name */
        public static final /* synthetic */ int[] f12574a;

        static {
            int[] iArr = new int[e.values().length];
            try {
                iArr[e.f12550c.ordinal()] = 1;
            } catch (NoSuchFieldError unused) {
            }
            try {
                iArr[e.f12551d.ordinal()] = 2;
            } catch (NoSuchFieldError unused2) {
            }
            try {
                iArr[e.f12552e.ordinal()] = 3;
            } catch (NoSuchFieldError unused3) {
            }
            try {
                iArr[e.f12553f.ordinal()] = 4;
            } catch (NoSuchFieldError unused4) {
            }
            try {
                iArr[e.f12554g.ordinal()] = 5;
            } catch (NoSuchFieldError unused5) {
            }
            try {
                iArr[e.f12555h.ordinal()] = 6;
            } catch (NoSuchFieldError unused6) {
            }
            try {
                iArr[e.f12556i.ordinal()] = 7;
            } catch (NoSuchFieldError unused7) {
            }
            try {
                iArr[e.f12557j.ordinal()] = 8;
            } catch (NoSuchFieldError unused8) {
            }
            try {
                iArr[e.f12558k.ordinal()] = 9;
            } catch (NoSuchFieldError unused9) {
            }
            try {
                iArr[e.f12559l.ordinal()] = 10;
            } catch (NoSuchFieldError unused10) {
            }
            try {
                iArr[e.f12560m.ordinal()] = 11;
            } catch (NoSuchFieldError unused11) {
            }
            try {
                iArr[e.f12561n.ordinal()] = 12;
            } catch (NoSuchFieldError unused12) {
            }
            try {
                iArr[e.f12562o.ordinal()] = 13;
            } catch (NoSuchFieldError unused13) {
            }
            try {
                iArr[e.f12563p.ordinal()] = 14;
            } catch (NoSuchFieldError unused14) {
            }
            try {
                iArr[e.f12564q.ordinal()] = 15;
            } catch (NoSuchFieldError unused15) {
            }
            try {
                iArr[e.f12565r.ordinal()] = 16;
            } catch (NoSuchFieldError unused16) {
            }
            try {
                iArr[e.f12566s.ordinal()] = 17;
            } catch (NoSuchFieldError unused17) {
            }
            try {
                iArr[e.f12567t.ordinal()] = 18;
            } catch (NoSuchFieldError unused18) {
            }
            try {
                iArr[e.f12568u.ordinal()] = 19;
            } catch (NoSuchFieldError unused19) {
            }
            try {
                iArr[e.f12569v.ordinal()] = 20;
            } catch (NoSuchFieldError unused20) {
            }
            try {
                iArr[e.f12570w.ordinal()] = 21;
            } catch (NoSuchFieldError unused21) {
            }
            try {
                iArr[e.f12571x.ordinal()] = 22;
            } catch (NoSuchFieldError unused22) {
            }
            try {
                iArr[e.f12572y.ordinal()] = 23;
            } catch (NoSuchFieldError unused23) {
            }
            try {
                iArr[e.f12573z.ordinal()] = 24;
            } catch (NoSuchFieldError unused24) {
            }
            try {
                iArr[e.A.ordinal()] = 25;
            } catch (NoSuchFieldError unused25) {
            }
            try {
                iArr[e.B.ordinal()] = 26;
            } catch (NoSuchFieldError unused26) {
            }
            f12574a = iArr;
        }
    }

    static {
        e eVar = new e("DriverLicense", 0);
        f12550c = eVar;
        e eVar2 = new e("StateID", 1);
        f12551d = eVar2;
        e eVar3 = new e("Keypass", 2);
        f12552e = eVar3;
        e eVar4 = new e("MilitaryID", 3);
        f12553f = eVar4;
        e eVar5 = new e("MyNumberCard", 4);
        f12554g = eVar5;
        e eVar6 = new e("NRIC", 5);
        f12555h = eVar6;
        e eVar7 = new e("OFWID", 6);
        f12556i = eVar7;
        e eVar8 = new e("Passport", 7);
        f12557j = eVar8;
        e eVar9 = new e("PermanentResidentCard", 8);
        f12558k = eVar9;
        e eVar10 = new e("ResidencyPermit", 9);
        f12559l = eVar10;
        e eVar11 = new e("StudentPermit", 10);
        f12560m = eVar11;
        e eVar12 = new e("SocialSecurityID", 11);
        f12561n = eVar12;
        e eVar13 = new e("UMID", 12);
        f12562o = eVar13;
        e eVar14 = new e("VoterID", 13);
        f12563p = eVar14;
        e eVar15 = new e("PassportCard", 14);
        f12564q = eVar15;
        e eVar16 = new e("PostalID", 15);
        f12565r = eVar16;
        e eVar17 = new e("Visa", 16);
        f12566s = eVar17;
        e eVar18 = new e("WorkPermit", 17);
        f12567t = eVar18;
        e eVar19 = new e("CitizenshipCertificate", 18);
        f12568u = eVar19;
        e eVar20 = new e("ConsularID", 19);
        f12569v = eVar20;
        e eVar21 = new e("ForeignerID", 20);
        f12570w = eVar21;
        e eVar22 = new e("HealthInsuranceCard", 21);
        f12571x = eVar22;
        e eVar23 = new e("LongTermPass", 22);
        f12572y = eVar23;
        e eVar24 = new e("NBICertificate", 23);
        f12573z = eVar24;
        e eVar25 = new e("PermanentAccountNumber", 24);
        A = eVar25;
        B = new e("Unknown", 25);
        e[] a10 = a();
        C = a10;
        D = hu.b.a(a10);
        INSTANCE = new Companion(null);
        b = k0.m(s.a("dl", eVar), s.a("id", eVar2), s.a("keyp", eVar3), s.a("mid", eVar4), s.a("myn", eVar5), s.a("nric", eVar6), s.a("ofw", eVar7), s.a("pp", eVar8), s.a("pr", eVar9), s.a("rp", eVar10), s.a("sp", eVar11), s.a("sss", eVar12), s.a("umid", eVar13), s.a("vid", eVar14), s.a("ppc", eVar15), s.a("pid", eVar16), s.a("visa", eVar17), s.a("wp", eVar18), s.a("cct", eVar19), s.a("cid", eVar20), s.a("foid", eVar21), s.a("hic", eVar22), s.a("ltpass", eVar23), s.a("nbi", eVar24), s.a("pan", eVar25));
    }

    public e(String str, int i10) {
    }

    public static final /* synthetic */ e[] a() {
        return new e[]{f12550c, f12551d, f12552e, f12553f, f12554g, f12555h, f12556i, f12557j, f12558k, f12559l, f12560m, f12561n, f12562o, f12563p, f12564q, f12565r, f12566s, f12567t, f12568u, f12569v, f12570w, f12571x, f12572y, f12573z, A, B};
    }

    public static e valueOf(String str) {
        return (e) Enum.valueOf(e.class, str);
    }

    public static e[] values() {
        return (e[]) C.clone();
    }

    @NotNull
    public final h3 c() {
        switch (b.f12574a[ordinal()]) {
            case 1:
                return h3.b;
            case 2:
                return h3.f34657c;
            case 3:
                return h3.b;
            case 4:
                return h3.b;
            case 5:
                return h3.b;
            case 6:
                return h3.b;
            case 7:
                return h3.b;
            case 8:
                return h3.f34656a;
            case 9:
                return h3.f34658d;
            case 10:
                return h3.f34658d;
            case 11:
                return h3.b;
            case 12:
                return h3.b;
            case 13:
                return h3.b;
            case 14:
                return h3.b;
            case 15:
                return h3.f34656a;
            case 16:
                return h3.b;
            case 17:
                return h3.f34656a;
            case MlKitException.UNSUPPORTED /* 18 */:
                return h3.b;
            case 19:
                return h3.b;
            case w.f37552c /* 20 */:
                return h3.b;
            case 21:
                return h3.b;
            case 22:
                return h3.b;
            case 23:
                return h3.b;
            case 24:
                return h3.b;
            case 25:
                return h3.b;
            case 26:
                throw new RuntimeException("IdClass is 'UNKNOWN'.");
            default:
                throw new l();
        }
    }


    // --- восстановлено из DEX (dp/e$a) ---
    public static class a {
        public a() { }
        public a(kotlin.jvm.internal.DefaultConstructorMarker p0) { }
        public dp.e a(java.lang.String p0) { throw new UnsupportedOperationException("stub"); }
    }
}
