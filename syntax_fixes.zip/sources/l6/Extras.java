package l6;

import com.github.luben.zstd.BuildConfig;
import java.util.LinkedHashMap;
import java.util.Map;
import kotlin.Metadata;
import kotlin.collections.k0;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(d1 = {"\u00004\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\u0010$\n\u0002\u0018\u0002\n\u0002\b\t\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\b\u0005\u0018\u0000 \u000b2\u00020\u0001:\u0003\t\u001a\u000bB!\b\u0002\u0012\u0016\u0010\u0004\u001a\u0012\u0012\b\u0012\u0006\u0012\u0002\b\u00030\u0003\u0012\u0004\u0012\u00020\u00010\u0002¢\u0006\u0004\b\u0005\u0010\u0006J&\u0010\t\u001a\u0004\u0018\u00018\u0000\"\u0004\b\u0000\u0010\u00072\f\u0010\b\u001a\b\u0012\u0004\u0012\u00028\u00000\u0003H\u0086\u0002¢\u0006\u0004\b\t\u0010\nJ\u001d\u0010\u000b\u001a\u0012\u0012\b\u0012\u0006\u0012\u0002\b\u00030\u0003\u0012\u0004\u0012\u00020\u00010\u0002¢\u0006\u0004\b\u000b\u0010\fJ\r\u0010\u000e\u001a\u00020\r¢\u0006\u0004\b\u000e\u0010\u000fJ\u001a\u0010\u0012\u001a\u00020\u00112\b\u0010\u0010\u001a\u0004\u0018\u00010\u0001H\u0096\u0002¢\u0006\u0004\b\u0012\u0010\u0013J\u000f\u0010\u0015\u001a\u00020\u0014H\u0016¢\u0006\u0004\b\u0015\u0010\u0016J\u000f\u0010\u0018\u001a\u00020\u0017H\u0016¢\u0006\u0004\b\u0018\u0010\u0019R$\u0010\u0004\u001a\u0012\u0012\b\u0012\u0006\u0012\u0002\b\u00030\u0003\u0012\u0004\u0012\u00020\u00010\u00028\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b\u001a\u0010\u001b¨\u0006\u001c"}, d2 = {"Ll6/l;", BuildConfig.FLAVOR, BuildConfig.FLAVOR, "Ll6/l$c;", "data", "<init>", "(Ljava/util/Map;)V", "T", "key", "c", "(Ll6/l$c;)Ljava/lang/Object;", k6.b.f21144e, "()Ljava/util/Map;", "Ll6/l$a;", "d", "()Ll6/l$a;", "other", BuildConfig.FLAVOR, "equals", "(Ljava/lang/Object;)Z", BuildConfig.FLAVOR, "hashCode", "()I", BuildConfig.FLAVOR, "toString", "()Ljava/lang/String;", xe.a.f36648e, "Ljava/util/Map;", "coil-core_release"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* renamed from: l6.l, reason: from toString */
/* loaded from: classes.dex */
public final class Extras {

    /* renamed from: c, reason: collision with root package name */
    @NotNull
    public static final Extras f21920c = new a().a();

    /* renamed from: a, reason: collision with root package name and from kotlin metadata and from toString */
    @NotNull
    public final Map<c<?>, Object> data;

    @Metadata(d1 = {"\u0000\u000e\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0000\n\u0002\b\b\u0018\u0000 \t*\u0004\b\u0000\u0010\u00012\u00020\u0002:\u0001\u0006B\u000f\u0012\u0006\u0010\u0003\u001a\u00028\u0000¢\u0006\u0004\b\u0004\u0010\u0005R\u0017\u0010\u0003\u001a\u00028\u00008\u0006¢\u0006\f\n\u0004\b\u0006\u0010\u0007\u001a\u0004\b\u0006\u0010\b¨\u0006\n"}, d2 = {"Ll6/l$c;", "T", BuildConfig.FLAVOR, "default", "<init>", "(Ljava/lang/Object;)V", xe.a.f36648e, "Ljava/lang/Object;", "()Ljava/lang/Object;", k6.b.f21144e, "coil-core_release"}, k = 1, mv = {2, 2, 0}, xi = 48)
    /* renamed from: l6.l$c */
    public static final class c<T> {

        /* renamed from: b, reason: from kotlin metadata */
        @NotNull
        public static final Companion INSTANCE = new Companion(null);

        /* renamed from: a, reason: collision with root package name and from kotlin metadata */
        public final T default_;

        @Metadata(d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\b\u0086\u0003\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003¨\u0006\u0004"}, d2 = {"Ll6/l$c$a;", BuildConfig.FLAVOR, "<init>", "()V", "coil-core_release"}, k = 1, mv = {2, 2, 0}, xi = 48)
        /* renamed from: l6.l$c$a, reason: from kotlin metadata */
        public static final class Companion {
            public /* synthetic */ Companion(DefaultConstructorMarker defaultConstructorMarker) {
                this();
            }

            public Companion() {
            }
        }

        public c(T t8) {
            this.default_ = t8;
        }

        public final T a() {
            return this.default_;
        }
    }

    public /* synthetic */ Extras(Map map, DefaultConstructorMarker defaultConstructorMarker) {
        this(map);
    }

    @NotNull
    public final Map<c<?>, Object> b() {
        return this.data;
    }

    @Nullable
    public final <T> T c(@NotNull c<T> key) {
        return (T) this.data.get(key);
    }

    @NotNull
    public final a d() {
        return new a(this);
    }

    public boolean equals(@Nullable Object other) {
        if (this == other) {
            return true;
        }
        return (other instanceof Extras) && Intrinsics.c(this.data, ((Extras) other).data);
    }

    public int hashCode() {
        return this.data.hashCode();
    }

    @NotNull
    public String toString() {
        return "Extras(data=" + this.data + ')';
    }

    @Metadata(d1 = {"\u0000(\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010$\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\t\n\u0002\u0010%\n\u0002\b\u0003\u0018\u00002\u00020\u0001B\t\b\u0016¢\u0006\u0004\b\u0002\u0010\u0003B!\b\u0016\u0012\u0016\u0010\u0006\u001a\u0012\u0012\b\u0012\u0006\u0012\u0002\b\u00030\u0005\u0012\u0004\u0012\u00020\u00010\u0004¢\u0006\u0004\b\u0002\u0010\u0007B\u0011\b\u0016\u0012\u0006\u0010\t\u001a\u00020\b¢\u0006\u0004\b\u0002\u0010\nJ.\u0010\u000e\u001a\u00020\u0000\"\u0004\b\u0000\u0010\u000b2\f\u0010\f\u001a\b\u0012\u0004\u0012\u00028\u00000\u00052\b\u0010\r\u001a\u0004\u0018\u00018\u0000H\u0086\u0002¢\u0006\u0004\b\u000e\u0010\u000fJ\r\u0010\u0010\u001a\u00020\b¢\u0006\u0004\b\u0010\u0010\u0011R$\u0010\u0014\u001a\u0012\u0012\b\u0012\u0006\u0012\u0002\b\u00030\u0005\u0012\u0004\u0012\u00020\u00010\u00128\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b\u0010\u0010\u0013¨\u0006\u0015"}, d2 = {"Ll6/l$a;", BuildConfig.FLAVOR, "<init>", "()V", BuildConfig.FLAVOR, "Ll6/l$c;", "map", "(Ljava/util/Map;)V", "Ll6/l;", "extras", "(Ll6/l;)V", "T", "key", "value", k6.b.f21144e, "(Ll6/l$c;Ljava/lang/Object;)Ll6/l$a;", xe.a.f36648e, "()Ll6/l;", BuildConfig.FLAVOR, "Ljava/util/Map;", "data", "coil-core_release"}, k = 1, mv = {2, 2, 0}, xi = 48)
    /* renamed from: l6.l$a */
    public static final class a {

        /* renamed from: a, reason: collision with root package name and from kotlin metadata */
        @NotNull
        public final Map<c<?>, Object> data;

        public a() {
            this.data = new LinkedHashMap();
        }

        @NotNull
        public final Extras a() {
            return new Extras(f7.d.d(this.data), null);
        }

        @NotNull
        public final <T> a b(@NotNull c<T> key, @Nullable T value) {
            if (value != null) {
                this.data.put(key, value);
                return this;
            }
            this.data.remove(key);
            return this;
        }

        public a(@NotNull Map<c<?>, ? extends Object> map) {
            this.data = k0.y(map);
        }

        public a(@NotNull Extras extras) {
            this.data = k0.y(extras.data);
        }
    }

    public Extras(Map<c<?>, ? extends Object> map) {
        this.data = map;
    }
}
