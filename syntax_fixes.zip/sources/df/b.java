package df;

import df.a;
import java.math.BigInteger;
import java.security.GeneralSecurityException;
import java.security.spec.ECPoint;

/* loaded from: classes2.dex */
public final class b extends b1 {

    /* renamed from: a, reason: collision with root package name */
    public final c f12258a;
    public final gf.b b;

    /* renamed from: df.b$b, reason: collision with other inner class name */
    public static class C0221b {

        /* renamed from: a, reason: collision with root package name */
        public c f12259a;
        public gf.b b;

        public static void d(BigInteger bigInteger, ECPoint eCPoint, a.c cVar) {
            BigInteger order = cVar.a().getOrder();
            if (bigInteger.signum() <= 0 || bigInteger.compareTo(order) >= 0) {
                throw new GeneralSecurityException("Invalid private value");
            }
            if (!ye.g.k(bigInteger, cVar.a()).equals(eCPoint)) {
                throw new GeneralSecurityException("Invalid private value");
            }
        }

        public b a() {
            if (this.f12259a == null) {
                throw new GeneralSecurityException("Cannot build without a ecdsa public key");
            }
            gf.b bVar = this.b;
            if (bVar == null) {
                throw new GeneralSecurityException("Cannot build without a private value");
            }
            d(bVar.b(re.j.a()), this.f12259a.e(), this.f12259a.d().c());
            return new b(this.f12259a, this.b);
        }

        public C0221b b(gf.b bVar) {
            this.b = bVar;
            return this;
        }

        public C0221b c(c cVar) {
            this.f12259a = cVar;
            return this;
        }

        public C0221b() {
            this.f12259a = null;
            this.b = null;
        }
    }

    public static C0221b d() {
        return new C0221b();
    }

    public df.a e() {
        return this.f12258a.d();
    }

    public gf.b f() {
        return this.b;
    }

    @Override // df.b1
    /* renamed from: g, reason: merged with bridge method [inline-methods] */
    public c c() {
        return this.f12258a;
    }

    public b(c cVar, gf.b bVar) {
        this.f12258a = cVar;
        this.b = bVar;
    }


    // --- восстановлено из DEX (df/b$a) ---
    public static class a {
        // члены отсутствуют в DEX
    }
}
