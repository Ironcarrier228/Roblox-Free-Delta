package df;

import java.math.BigInteger;
import java.security.GeneralSecurityException;

/* loaded from: classes2.dex */
public final class s0 extends b1 {

    /* renamed from: a, reason: collision with root package name */
    public final t0 f12359a;
    public final gf.b b;

    /* renamed from: c, reason: collision with root package name */
    public final gf.b f12360c;

    /* renamed from: d, reason: collision with root package name */
    public final gf.b f12361d;

    /* renamed from: e, reason: collision with root package name */
    public final gf.b f12362e;

    /* renamed from: f, reason: collision with root package name */
    public final gf.b f12363f;

    /* renamed from: g, reason: collision with root package name */
    public final gf.b f12364g;

    public static class b {

        /* renamed from: a, reason: collision with root package name */
        public t0 f12365a;
        public gf.b b;

        /* renamed from: c, reason: collision with root package name */
        public gf.b f12366c;

        /* renamed from: d, reason: collision with root package name */
        public gf.b f12367d;

        /* renamed from: e, reason: collision with root package name */
        public gf.b f12368e;

        /* renamed from: f, reason: collision with root package name */
        public gf.b f12369f;

        /* renamed from: g, reason: collision with root package name */
        public gf.b f12370g;

        public s0 a() {
            t0 t0Var = this.f12365a;
            if (t0Var == null) {
                throw new GeneralSecurityException("Cannot build without a RSA SSA PKCS1 public key");
            }
            if (this.f12366c == null || this.f12367d == null) {
                throw new GeneralSecurityException("Cannot build without prime factors");
            }
            if (this.b == null) {
                throw new GeneralSecurityException("Cannot build without private exponent");
            }
            if (this.f12368e == null || this.f12369f == null) {
                throw new GeneralSecurityException("Cannot build without prime exponents");
            }
            if (this.f12370g == null) {
                throw new GeneralSecurityException("Cannot build without CRT coefficient");
            }
            BigInteger e10 = t0Var.e().e();
            BigInteger d10 = this.f12365a.d();
            BigInteger b = this.f12366c.b(re.j.a());
            BigInteger b10 = this.f12367d.b(re.j.a());
            BigInteger b11 = this.b.b(re.j.a());
            BigInteger b12 = this.f12368e.b(re.j.a());
            BigInteger b13 = this.f12369f.b(re.j.a());
            BigInteger b14 = this.f12370g.b(re.j.a());
            if (!b.isProbablePrime(10)) {
                throw new GeneralSecurityException("p is not a prime");
            }
            if (!b10.isProbablePrime(10)) {
                throw new GeneralSecurityException("q is not a prime");
            }
            if (!b.multiply(b10).equals(d10)) {
                throw new GeneralSecurityException("Prime p times prime q is not equal to the public key's modulus");
            }
            BigInteger bigInteger = BigInteger.ONE;
            BigInteger subtract = b.subtract(bigInteger);
            BigInteger subtract2 = b10.subtract(bigInteger);
            if (!e10.multiply(b11).mod(subtract.divide(subtract.gcd(subtract2)).multiply(subtract2)).equals(bigInteger)) {
                throw new GeneralSecurityException("D is invalid.");
            }
            if (!e10.multiply(b12).mod(subtract).equals(bigInteger)) {
                throw new GeneralSecurityException("dP is invalid.");
            }
            if (!e10.multiply(b13).mod(subtract2).equals(bigInteger)) {
                throw new GeneralSecurityException("dQ is invalid.");
            }
            if (b10.multiply(b14).mod(b).equals(bigInteger)) {
                return new s0(this.f12365a, this.f12366c, this.f12367d, this.b, this.f12368e, this.f12369f, this.f12370g);
            }
            throw new GeneralSecurityException("qInv is invalid.");
        }

        public b b(gf.b bVar) {
            this.f12370g = bVar;
            return this;
        }

        public b c(gf.b bVar, gf.b bVar2) {
            this.f12368e = bVar;
            this.f12369f = bVar2;
            return this;
        }

        public b d(gf.b bVar, gf.b bVar2) {
            this.f12366c = bVar;
            this.f12367d = bVar2;
            return this;
        }

        public b e(gf.b bVar) {
            this.b = bVar;
            return this;
        }

        public b f(t0 t0Var) {
            this.f12365a = t0Var;
            return this;
        }

        public b() {
            this.f12365a = null;
            this.b = null;
            this.f12366c = null;
            this.f12367d = null;
            this.f12368e = null;
            this.f12369f = null;
            this.f12370g = null;
        }
    }

    public static b d() {
        return new b();
    }

    public gf.b e() {
        return this.f12364g;
    }

    public r0 f() {
        return this.f12359a.e();
    }

    public gf.b g() {
        return this.f12362e;
    }

    public gf.b h() {
        return this.f12363f;
    }

    public gf.b i() {
        return this.f12360c;
    }

    public gf.b j() {
        return this.f12361d;
    }

    public gf.b k() {
        return this.b;
    }

    @Override // df.b1
    /* renamed from: l, reason: merged with bridge method [inline-methods] */
    public t0 c() {
        return this.f12359a;
    }

    public s0(t0 t0Var, gf.b bVar, gf.b bVar2, gf.b bVar3, gf.b bVar4, gf.b bVar5, gf.b bVar6) {
        this.f12359a = t0Var;
        this.f12360c = bVar;
        this.f12361d = bVar2;
        this.b = bVar3;
        this.f12362e = bVar4;
        this.f12363f = bVar5;
        this.f12364g = bVar6;
    }


    // --- восстановлено из DEX (df/s0$a) ---
    public static class a {
        // члены отсутствуют в DEX
    }
}
