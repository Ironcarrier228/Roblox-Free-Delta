package df;

import com.google.mlkit.vision.barcode.common.Barcode;
import java.math.BigInteger;
import java.security.GeneralSecurityException;
import java.security.InvalidAlgorithmParameterException;
import java.util.Objects;

/* loaded from: classes2.dex */
public final class r0 extends a1 {

    /* renamed from: g, reason: collision with root package name */
    public static final BigInteger f12339g = BigInteger.valueOf(65537);

    /* renamed from: a, reason: collision with root package name */
    public final int f12340a;
    public final BigInteger b;

    /* renamed from: c, reason: collision with root package name */
    public final d f12341c;

    /* renamed from: d, reason: collision with root package name */
    public final c f12342d;

    /* renamed from: e, reason: collision with root package name */
    public final c f12343e;

    /* renamed from: f, reason: collision with root package name */
    public final int f12344f;

    public static final class b {

        /* renamed from: g, reason: collision with root package name */
        public static final BigInteger f12345g;

        /* renamed from: h, reason: collision with root package name */
        public static final BigInteger f12346h;

        /* renamed from: a, reason: collision with root package name */
        public Integer f12347a;
        public BigInteger b;

        /* renamed from: c, reason: collision with root package name */
        public c f12348c;

        /* renamed from: d, reason: collision with root package name */
        public c f12349d;

        /* renamed from: e, reason: collision with root package name */
        public Integer f12350e;

        /* renamed from: f, reason: collision with root package name */
        public d f12351f;

        static {
            BigInteger valueOf = BigInteger.valueOf(2L);
            f12345g = valueOf;
            f12346h = valueOf.pow(Barcode.FORMAT_QR_CODE);
        }

        public r0 a() {
            Integer num = this.f12347a;
            if (num == null) {
                throw new GeneralSecurityException("key size is not set");
            }
            if (this.b == null) {
                throw new GeneralSecurityException("publicExponent is not set");
            }
            if (this.f12348c == null) {
                throw new GeneralSecurityException("signature hash type is not set");
            }
            if (this.f12349d == null) {
                throw new GeneralSecurityException("mgf1 hash type is not set");
            }
            if (this.f12351f == null) {
                throw new GeneralSecurityException("variant is not set");
            }
            if (this.f12350e == null) {
                throw new GeneralSecurityException("salt length is not set");
            }
            if (num.intValue() < 2048) {
                throw new InvalidAlgorithmParameterException(String.format("Invalid key size in bytes %d; must be at least %d bits", this.f12347a, Integer.valueOf(Barcode.FORMAT_PDF417)));
            }
            if (this.f12348c != this.f12349d) {
                throw new GeneralSecurityException("MGF1 hash is different from signature hash");
            }
            h(this.b);
            return new r0(this.f12347a.intValue(), this.b, this.f12351f, this.f12348c, this.f12349d, this.f12350e.intValue());
        }

        public b b(c cVar) {
            this.f12349d = cVar;
            return this;
        }

        public b c(int i10) {
            this.f12347a = Integer.valueOf(i10);
            return this;
        }

        public b d(BigInteger bigInteger) {
            this.b = bigInteger;
            return this;
        }

        public b e(int i10) {
            if (i10 < 0) {
                throw new GeneralSecurityException(String.format("Invalid salt length in bytes %d; salt length must be positive", Integer.valueOf(i10)));
            }
            this.f12350e = Integer.valueOf(i10);
            return this;
        }

        public b f(c cVar) {
            this.f12348c = cVar;
            return this;
        }

        public b g(d dVar) {
            this.f12351f = dVar;
            return this;
        }

        public final void h(BigInteger bigInteger) {
            int compareTo = bigInteger.compareTo(r0.f12339g);
            if (compareTo == 0) {
                return;
            }
            if (compareTo < 0) {
                throw new InvalidAlgorithmParameterException("Public exponent must be at least 65537.");
            }
            if (bigInteger.mod(f12345g).equals(BigInteger.ZERO)) {
                throw new InvalidAlgorithmParameterException("Invalid public exponent");
            }
            if (bigInteger.compareTo(f12346h) > 0) {
                throw new InvalidAlgorithmParameterException("Public exponent cannot be larger than 2^256.");
            }
        }

        public b() {
            this.f12347a = null;
            this.b = r0.f12339g;
            this.f12348c = null;
            this.f12349d = null;
            this.f12350e = null;
            this.f12351f = d.f12357e;
        }
    }

    public static final class c {
        public static final c b = new c("SHA256");

        /* renamed from: c, reason: collision with root package name */
        public static final c f12352c = new c("SHA384");

        /* renamed from: d, reason: collision with root package name */
        public static final c f12353d = new c("SHA512");

        /* renamed from: a, reason: collision with root package name */
        public final String f12354a;

        public c(String str) {
            this.f12354a = str;
        }

        public String toString() {
            return this.f12354a;
        }
    }

    public static final class d {
        public static final d b = new d("TINK");

        /* renamed from: c, reason: collision with root package name */
        public static final d f12355c = new d("CRUNCHY");

        /* renamed from: d, reason: collision with root package name */
        public static final d f12356d = new d("LEGACY");

        /* renamed from: e, reason: collision with root package name */
        public static final d f12357e = new d("NO_PREFIX");

        /* renamed from: a, reason: collision with root package name */
        public final String f12358a;

        public d(String str) {
            this.f12358a = str;
        }

        public String toString() {
            return this.f12358a;
        }
    }

    public static b b() {
        return new b();
    }

    @Override // re.x
    public boolean a() {
        return this.f12341c != d.f12357e;
    }

    public c c() {
        return this.f12343e;
    }

    public int d() {
        return this.f12340a;
    }

    public BigInteger e() {
        return this.b;
    }

    public boolean equals(Object obj) {
        if (!(obj instanceof r0)) {
            return false;
        }
        r0 r0Var = (r0) obj;
        return r0Var.d() == d() && Objects.equals(r0Var.e(), e()) && Objects.equals(r0Var.h(), h()) && Objects.equals(r0Var.g(), g()) && Objects.equals(r0Var.c(), c()) && r0Var.f() == f();
    }

    public int f() {
        return this.f12344f;
    }

    public c g() {
        return this.f12342d;
    }

    public d h() {
        return this.f12341c;
    }

    public int hashCode() {
        return Objects.hash(r0.class, Integer.valueOf(this.f12340a), this.b, this.f12341c, this.f12342d, this.f12343e, Integer.valueOf(this.f12344f));
    }

    public String toString() {
        return "RSA SSA PSS Parameters (variant: " + this.f12341c + ", signature hashType: " + this.f12342d + ", mgf1 hashType: " + this.f12343e + ", saltLengthBytes: " + this.f12344f + ", publicExponent: " + this.b + ", and " + this.f12340a + "-bit modulus)";
    }

    public r0(int i10, BigInteger bigInteger, d dVar, c cVar, c cVar2, int i11) {
        this.f12340a = i10;
        this.b = bigInteger;
        this.f12341c = dVar;
        this.f12342d = cVar;
        this.f12343e = cVar2;
        this.f12344f = i11;
    }


    // --- восстановлено из DEX (df/r0$a) ---
    public static class a {
        // члены отсутствуют в DEX
    }
}
