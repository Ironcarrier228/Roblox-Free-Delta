package df;

import com.google.mlkit.vision.barcode.common.Barcode;
import java.math.BigInteger;
import java.security.GeneralSecurityException;
import java.security.InvalidAlgorithmParameterException;
import java.util.Objects;

/* loaded from: classes2.dex */
public final class j0 extends a1 {

    /* renamed from: e, reason: collision with root package name */
    public static final BigInteger f12293e = BigInteger.valueOf(65537);

    /* renamed from: a, reason: collision with root package name */
    public final int f12294a;
    public final BigInteger b;

    /* renamed from: c, reason: collision with root package name */
    public final d f12295c;

    /* renamed from: d, reason: collision with root package name */
    public final c f12296d;

    public static final class b {

        /* renamed from: e, reason: collision with root package name */
        public static final BigInteger f12297e;

        /* renamed from: f, reason: collision with root package name */
        public static final BigInteger f12298f;

        /* renamed from: a, reason: collision with root package name */
        public Integer f12299a;
        public BigInteger b;

        /* renamed from: c, reason: collision with root package name */
        public c f12300c;

        /* renamed from: d, reason: collision with root package name */
        public d f12301d;

        static {
            BigInteger valueOf = BigInteger.valueOf(2L);
            f12297e = valueOf;
            f12298f = valueOf.pow(Barcode.FORMAT_QR_CODE);
        }

        public j0 a() {
            Integer num = this.f12299a;
            if (num == null) {
                throw new GeneralSecurityException("key size is not set");
            }
            if (this.b == null) {
                throw new GeneralSecurityException("publicExponent is not set");
            }
            if (this.f12300c == null) {
                throw new GeneralSecurityException("hash type is not set");
            }
            if (this.f12301d == null) {
                throw new GeneralSecurityException("variant is not set");
            }
            if (num.intValue() < 2048) {
                throw new InvalidAlgorithmParameterException(String.format("Invalid key size in bytes %d; must be at least 2048 bits", this.f12299a));
            }
            f(this.b);
            return new j0(this.f12299a.intValue(), this.b, this.f12301d, this.f12300c);
        }

        public b b(c cVar) {
            this.f12300c = cVar;
            return this;
        }

        public b c(int i10) {
            this.f12299a = Integer.valueOf(i10);
            return this;
        }

        public b d(BigInteger bigInteger) {
            this.b = bigInteger;
            return this;
        }

        public b e(d dVar) {
            this.f12301d = dVar;
            return this;
        }

        public final void f(BigInteger bigInteger) {
            int compareTo = bigInteger.compareTo(j0.f12293e);
            if (compareTo == 0) {
                return;
            }
            if (compareTo < 0) {
                throw new InvalidAlgorithmParameterException("Public exponent must be at least 65537.");
            }
            if (bigInteger.mod(f12297e).equals(BigInteger.ZERO)) {
                throw new InvalidAlgorithmParameterException("Invalid public exponent");
            }
            if (bigInteger.compareTo(f12298f) > 0) {
                throw new InvalidAlgorithmParameterException("Public exponent cannot be larger than 2^256.");
            }
        }

        public b() {
            this.f12299a = null;
            this.b = j0.f12293e;
            this.f12300c = null;
            this.f12301d = d.f12307e;
        }
    }

    public static final class c {
        public static final c b = new c("SHA256");

        /* renamed from: c, reason: collision with root package name */
        public static final c f12302c = new c("SHA384");

        /* renamed from: d, reason: collision with root package name */
        public static final c f12303d = new c("SHA512");

        /* renamed from: a, reason: collision with root package name */
        public final String f12304a;

        public c(String str) {
            this.f12304a = str;
        }

        public String toString() {
            return this.f12304a;
        }
    }

    public static final class d {
        public static final d b = new d("TINK");

        /* renamed from: c, reason: collision with root package name */
        public static final d f12305c = new d("CRUNCHY");

        /* renamed from: d, reason: collision with root package name */
        public static final d f12306d = new d("LEGACY");

        /* renamed from: e, reason: collision with root package name */
        public static final d f12307e = new d("NO_PREFIX");

        /* renamed from: a, reason: collision with root package name */
        public final String f12308a;

        public d(String str) {
            this.f12308a = str;
        }

        public String toString() {
            return this.f12308a;
        }
    }

    public static b b() {
        return new b();
    }

    @Override // re.x
    public boolean a() {
        return this.f12295c != d.f12307e;
    }

    public c c() {
        return this.f12296d;
    }

    public int d() {
        return this.f12294a;
    }

    public BigInteger e() {
        return this.b;
    }

    public boolean equals(Object obj) {
        if (!(obj instanceof j0)) {
            return false;
        }
        j0 j0Var = (j0) obj;
        return j0Var.d() == d() && Objects.equals(j0Var.e(), e()) && j0Var.f() == f() && j0Var.c() == c();
    }

    public d f() {
        return this.f12295c;
    }

    public int hashCode() {
        return Objects.hash(j0.class, Integer.valueOf(this.f12294a), this.b, this.f12295c, this.f12296d);
    }

    public String toString() {
        return "RSA SSA PKCS1 Parameters (variant: " + this.f12295c + ", hashType: " + this.f12296d + ", publicExponent: " + this.b + ", and " + this.f12294a + "-bit modulus)";
    }

    public j0(int i10, BigInteger bigInteger, d dVar, c cVar) {
        this.f12294a = i10;
        this.b = bigInteger;
        this.f12295c = dVar;
        this.f12296d = cVar;
    }


    // --- восстановлено из DEX (df/j0$a) ---
    public static class a {
        // члены отсутствуют в DEX
    }
}
