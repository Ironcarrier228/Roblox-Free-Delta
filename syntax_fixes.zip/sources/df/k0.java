package df;

import java.math.BigInteger;
import java.security.GeneralSecurityException;

/* loaded from: classes2.dex */
public final class k0 extends b1 {

    /* renamed from: a, reason: collision with root package name */
    public final l0 f12309a;
    public final gf.b b;

    /* renamed from: c, reason: collision with root package name */
    public final gf.b f12310c;

    /* renamed from: d, reason: collision with root package name */
    public final gf.b f12311d;

    /* renamed from: e, reason: collision with root package name */
    public final gf.b f12312e;

    /* renamed from: f, reason: collision with root package name */
    public final gf.b f12313f;

    /* renamed from: g, reason: collision with root package name */
    public final gf.b f12314g;

    public static class b {

        /* renamed from: a, reason: collision with root package name */
        public l0 f12315a;
        public gf.b b;

        /* renamed from: c, reason: collision with root package name */
        public gf.b f12316c;

        /* renamed from: d, reason: collision with root package name */
        public gf.b f12317d;

        /* renamed from: e, reason: collision with root package name */
        public gf.b f12318e;

        /* renamed from: f, reason: collision with root package name */
        public gf.b f12319f;

        /* renamed from: g, reason: collision with root package name */
        public gf.b f12320g;

        public k0 a() {
            l0 l0Var = this.f12315a;
            if (l0Var == null) {
                throw new GeneralSecurityException("Cannot build without a RSA SSA PKCS1 public key");
            }
            if (this.f12316c == null || this.f12317d == null) {
                throw new GeneralSecurityException("Cannot build without prime factors");
            }
            if (this.b == null) {
                throw new GeneralSecurityException("Cannot build without private exponent");
            }
            if (this.f12318e == null || this.f12319f == null) {
                throw new GeneralSecurityException("Cannot build without prime exponents");
            }
            if (this.f12320g == null) {
                throw new GeneralSecurityException("Cannot build without CRT coefficient");
            }
            BigInteger e10 = l0Var.e().e();
            BigInteger d10 = this.f12315a.d();
            BigInteger b = this.f12316c.b(re.j.a());
            BigInteger b10 = this.f12317d.b(re.j.a());
            BigInteger b11 = this.b.b(re.j.a());
            BigInteger b12 = this.f12318e.b(re.j.a());
            BigInteger b13 = this.f12319f.b(re.j.a());
            BigInteger b14 = this.f12320g.b(re.j.a());
            if (!b.isProbablePrime(10)) {
                throw new GeneralSecurityException("p is not a prime");
            }
            if (!b10.isProbablePrime(10)) {
                throw new GeneralSecurityException("q is not a prime");
            }
            if (!b.multiply(b10).equals(d10)) {
                throw new GeneralSecurityException("Prime p times prime q is not equal to the public key's modulus");
            }
            BigInteger bigInteger = BigInteger.ONE;
            BigInteger subtract = b.subtract(bigInteger);
            BigInteger subtract2 = b10.subtract(bigInteger);
            if (!e10.multiply(b11).mod(subtract.divide(subtract.gcd(subtract2)).multiply(subtract2)).equals(bigInteger)) {
                throw new GeneralSecurityException("D is invalid.");
            }
            if (!e10.multiply(b12).mod(subtract).equals(bigInteger)) {
                throw new GeneralSecurityException("dP is invalid.");
            }
            if (!e10.multiply(b13).mod(subtract2).equals(bigInteger)) {
                throw new GeneralSecurityException("dQ is invalid.");
            }
            if (b10.multiply(b14).mod(b).equals(bigInteger)) {
                return new k0(this.f12315a, this.f12316c, this.f12317d, this.b, this.f12318e, this.f12319f, this.f12320g);
            }
            throw new GeneralSecurityException("qInv is invalid.");
        }

        public b b(gf.b bVar) {
            this.f12320g = bVar;
            return this;
        }

        public b c(gf.b bVar, gf.b bVar2) {
            this.f12318e = bVar;
            this.f12319f = bVar2;
            return this;
        }

        public b d(gf.b bVar, gf.b bVar2) {
            this.f12316c = bVar;
            this.f12317d = bVar2;
            return this;
        }

        public b e(gf.b bVar) {
            this.b = bVar;
            return this;
        }

        public b f(l0 l0Var) {
            this.f12315a = l0Var;
            return this;
        }

        public b() {
            this.f12315a = null;
            this.b = null;
            this.f12316c = null;
            this.f12317d = null;
            this.f12318e = null;
            this.f12319f = null;
            this.f12320g = null;
        }
    }

    public static b d() {
        return new b();
    }

    public gf.b e() {
        return this.f12314g;
    }

    public j0 f() {
        return this.f12309a.e();
    }

    public gf.b g() {
        return this.f12312e;
    }

    public gf.b h() {
        return this.f12313f;
    }

    public gf.b i() {
        return this.f12310c;
    }

    public gf.b j() {
        return this.f12311d;
    }

    public gf.b k() {
        return this.b;
    }

    @Override // df.b1
    /* renamed from: l, reason: merged with bridge method [inline-methods] */
    public l0 c() {
        return this.f12309a;
    }

    public k0(l0 l0Var, gf.b bVar, gf.b bVar2, gf.b bVar3, gf.b bVar4, gf.b bVar5, gf.b bVar6) {
        this.f12309a = l0Var;
        this.f12310c = bVar;
        this.f12311d = bVar2;
        this.b = bVar3;
        this.f12312e = bVar4;
        this.f12313f = bVar5;
        this.f12314g = bVar6;
    }


    // --- восстановлено из DEX (df/k0$a) ---
    public static class a {
        // члены отсутствуют в DEX
    }
}
