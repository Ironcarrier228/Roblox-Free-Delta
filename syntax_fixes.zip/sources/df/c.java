package df;

import df.a;
import java.security.GeneralSecurityException;
import java.security.spec.ECPoint;

/* loaded from: classes2.dex */
public final class c extends c1 {

    /* renamed from: a, reason: collision with root package name */
    public final df.a f12260a;
    public final ECPoint b;

    /* renamed from: c, reason: collision with root package name */
    public final gf.a f12261c;

    /* renamed from: d, reason: collision with root package name */
    public final Integer f12262d;

    public static class b {

        /* renamed from: a, reason: collision with root package name */
        public df.a f12263a;
        public ECPoint b;

        /* renamed from: c, reason: collision with root package name */
        public Integer f12264c;

        public c a() {
            df.a aVar = this.f12263a;
            if (aVar == null) {
                throw new GeneralSecurityException("Cannot build without parameters");
            }
            ECPoint eCPoint = this.b;
            if (eCPoint == null) {
                throw new GeneralSecurityException("Cannot build without public point");
            }
            ye.g.b(eCPoint, aVar.c().a().getCurve());
            if (this.f12263a.a() && this.f12264c == null) {
                throw new GeneralSecurityException("Cannot create key without ID requirement with parameters with ID requirement");
            }
            if (!this.f12263a.a() && this.f12264c != null) {
                throw new GeneralSecurityException("Cannot create key with ID requirement with parameters without ID requirement");
            }
            return new c(this.f12263a, this.b, b(), this.f12264c);
        }

        public final gf.a b() {
            if (this.f12263a.f() == a.f.f12256e) {
                return ye.e0.f37739a;
            }
            if (this.f12263a.f() == a.f.f12255d || this.f12263a.f() == a.f.f12254c) {
                return ye.e0.a(this.f12264c.intValue());
            }
            if (this.f12263a.f() == a.f.b) {
                return ye.e0.b(this.f12264c.intValue());
            }
            throw new IllegalStateException("Unknown EcdsaParameters.Variant: " + this.f12263a.f());
        }

        public b c(Integer num) {
            this.f12264c = num;
            return this;
        }

        public b d(df.a aVar) {
            this.f12263a = aVar;
            return this;
        }

        public b e(ECPoint eCPoint) {
            this.b = eCPoint;
            return this;
        }

        public b() {
            this.f12263a = null;
            this.b = null;
            this.f12264c = null;
        }
    }

    public static b c() {
        return new b();
    }

    @Override // re.l
    public Integer a() {
        return this.f12262d;
    }

    @Override // df.c1
    public gf.a b() {
        return this.f12261c;
    }

    public df.a d() {
        return this.f12260a;
    }

    public ECPoint e() {
        return this.b;
    }

    public c(df.a aVar, ECPoint eCPoint, gf.a aVar2, Integer num) {
        this.f12260a = aVar;
        this.b = eCPoint;
        this.f12261c = aVar2;
        this.f12262d = num;
    }


    // --- восстановлено из DEX (df/c$a) ---
    public static class a {
        // члены отсутствуют в DEX
    }
}
