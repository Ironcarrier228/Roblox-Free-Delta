package df;

import df.j0;
import java.math.BigInteger;
import java.security.GeneralSecurityException;

/* loaded from: classes2.dex */
public final class l0 extends c1 {

    /* renamed from: a, reason: collision with root package name */
    public final j0 f12321a;
    public final BigInteger b;

    /* renamed from: c, reason: collision with root package name */
    public final gf.a f12322c;

    /* renamed from: d, reason: collision with root package name */
    public final Integer f12323d;

    public static class b {

        /* renamed from: a, reason: collision with root package name */
        public j0 f12324a;
        public BigInteger b;

        /* renamed from: c, reason: collision with root package name */
        public Integer f12325c;

        public l0 a() {
            if (this.f12324a == null) {
                throw new GeneralSecurityException("Cannot build without parameters");
            }
            BigInteger bigInteger = this.b;
            if (bigInteger == null) {
                throw new GeneralSecurityException("Cannot build without modulus");
            }
            int bitLength = bigInteger.bitLength();
            int d10 = this.f12324a.d();
            if (bitLength != d10) {
                throw new GeneralSecurityException("Got modulus size " + bitLength + ", but parameters requires modulus size " + d10);
            }
            if (this.f12324a.a() && this.f12325c == null) {
                throw new GeneralSecurityException("Cannot create key without ID requirement with parameters with ID requirement");
            }
            if (!this.f12324a.a() && this.f12325c != null) {
                throw new GeneralSecurityException("Cannot create key with ID requirement with parameters without ID requirement");
            }
            return new l0(this.f12324a, this.b, b(), this.f12325c);
        }

        public final gf.a b() {
            if (this.f12324a.f() == j0.d.f12307e) {
                return ye.e0.f37739a;
            }
            if (this.f12324a.f() == j0.d.f12306d || this.f12324a.f() == j0.d.f12305c) {
                return ye.e0.a(this.f12325c.intValue());
            }
            if (this.f12324a.f() == j0.d.b) {
                return ye.e0.b(this.f12325c.intValue());
            }
            throw new IllegalStateException("Unknown RsaSsaPkcs1Parameters.Variant: " + this.f12324a.f());
        }

        public b c(Integer num) {
            this.f12325c = num;
            return this;
        }

        public b d(BigInteger bigInteger) {
            this.b = bigInteger;
            return this;
        }

        public b e(j0 j0Var) {
            this.f12324a = j0Var;
            return this;
        }

        public b() {
            this.f12324a = null;
            this.b = null;
            this.f12325c = null;
        }
    }

    public static b c() {
        return new b();
    }

    @Override // re.l
    public Integer a() {
        return this.f12323d;
    }

    @Override // df.c1
    public gf.a b() {
        return this.f12322c;
    }

    public BigInteger d() {
        return this.b;
    }

    public j0 e() {
        return this.f12321a;
    }

    public l0(j0 j0Var, BigInteger bigInteger, gf.a aVar, Integer num) {
        this.f12321a = j0Var;
        this.b = bigInteger;
        this.f12322c = aVar;
        this.f12323d = num;
    }


    // --- восстановлено из DEX (df/l0$a) ---
    public static class a {
        // члены отсутствуют в DEX
    }
}
