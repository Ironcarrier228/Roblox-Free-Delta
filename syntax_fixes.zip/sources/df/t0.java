package df;

import df.r0;
import java.math.BigInteger;
import java.security.GeneralSecurityException;

/* loaded from: classes2.dex */
public final class t0 extends c1 {

    /* renamed from: a, reason: collision with root package name */
    public final r0 f12371a;
    public final BigInteger b;

    /* renamed from: c, reason: collision with root package name */
    public final gf.a f12372c;

    /* renamed from: d, reason: collision with root package name */
    public final Integer f12373d;

    public static class b {

        /* renamed from: a, reason: collision with root package name */
        public r0 f12374a;
        public BigInteger b;

        /* renamed from: c, reason: collision with root package name */
        public Integer f12375c;

        public t0 a() {
            if (this.f12374a == null) {
                throw new GeneralSecurityException("Cannot build without parameters");
            }
            BigInteger bigInteger = this.b;
            if (bigInteger == null) {
                throw new GeneralSecurityException("Cannot build without modulus");
            }
            int bitLength = bigInteger.bitLength();
            int d10 = this.f12374a.d();
            if (bitLength != d10) {
                throw new GeneralSecurityException("Got modulus size " + bitLength + ", but parameters requires modulus size " + d10);
            }
            if (this.f12374a.a() && this.f12375c == null) {
                throw new GeneralSecurityException("Cannot create key without ID requirement with parameters with ID requirement");
            }
            if (!this.f12374a.a() && this.f12375c != null) {
                throw new GeneralSecurityException("Cannot create key with ID requirement with parameters without ID requirement");
            }
            return new t0(this.f12374a, this.b, b(), this.f12375c);
        }

        public final gf.a b() {
            if (this.f12374a.h() == r0.d.f12357e) {
                return ye.e0.f37739a;
            }
            if (this.f12374a.h() == r0.d.f12356d || this.f12374a.h() == r0.d.f12355c) {
                return ye.e0.a(this.f12375c.intValue());
            }
            if (this.f12374a.h() == r0.d.b) {
                return ye.e0.b(this.f12375c.intValue());
            }
            throw new IllegalStateException("Unknown RsaSsaPssParameters.Variant: " + this.f12374a.h());
        }

        public b c(Integer num) {
            this.f12375c = num;
            return this;
        }

        public b d(BigInteger bigInteger) {
            this.b = bigInteger;
            return this;
        }

        public b e(r0 r0Var) {
            this.f12374a = r0Var;
            return this;
        }

        public b() {
            this.f12374a = null;
            this.b = null;
            this.f12375c = null;
        }
    }

    public static b c() {
        return new b();
    }

    @Override // re.l
    public Integer a() {
        return this.f12373d;
    }

    @Override // df.c1
    public gf.a b() {
        return this.f12372c;
    }

    public BigInteger d() {
        return this.b;
    }

    public r0 e() {
        return this.f12371a;
    }

    public t0(r0 r0Var, BigInteger bigInteger, gf.a aVar, Integer num) {
        this.f12371a = r0Var;
        this.b = bigInteger;
        this.f12372c = aVar;
        this.f12373d = num;
    }


    // --- восстановлено из DEX (df/t0$a) ---
    public static class a {
        // члены отсутствуют в DEX
    }
}
