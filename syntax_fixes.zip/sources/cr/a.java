package cr;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import com.github.luben.zstd.BuildConfig;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import pu.n;

@Metadata(d1 = {"\u0000V\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u000b\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\b\b\b&\u0018\u0000*\b\b\u0000\u0010\u0002*\u00020\u00012\b\u0012\u0004\u0012\u00028\u00000\u00032\u00020\u0004B)\u0012 \u0010\t\u001a\u001c\u0012\u0004\u0012\u00020\u0006\u0012\u0006\u0012\u0004\u0018\u00010\u0007\u0012\u0004\u0012\u00020\b\u0012\u0004\u0012\u00028\u00000\u0005¢\u0006\u0004\b\n\u0010\u000bJ\u0017\u0010\u000f\u001a\u00020\u000e2\u0006\u0010\r\u001a\u00020\fH\u0016¢\u0006\u0004\b\u000f\u0010\u0010J+\u0010\u0016\u001a\u00020\u00152\u0006\u0010\u0011\u001a\u00020\u00062\b\u0010\u0012\u001a\u0004\u0018\u00010\u00072\b\u0010\u0014\u001a\u0004\u0018\u00010\u0013H\u0016¢\u0006\u0004\b\u0016\u0010\u0017J\u0019\u0010\u001a\u001a\f\u0012\u0006\u0012\u0004\u0018\u00010\u0019\u0018\u00010\u0018H\u0016¢\u0006\u0004\b\u001a\u0010\u001bR1\u0010\t\u001a\u001c\u0012\u0004\u0012\u00020\u0006\u0012\u0006\u0012\u0004\u0018\u00010\u0007\u0012\u0004\u0012\u00020\b\u0012\u0004\u0012\u00028\u00000\u00058\u0006¢\u0006\f\n\u0004\b\u001c\u0010\u001d\u001a\u0004\b\u001e\u0010\u001fR*\u0010'\u001a\n\u0012\u0006\u0012\u0004\u0018\u00010\u00190 8\u0006@\u0006X\u0087.¢\u0006\u0012\n\u0004\b!\u0010\"\u001a\u0004\b#\u0010$\"\u0004\b%\u0010&¨\u0006("}, d2 = {"Lcr/a;", "Ls5/a;", "T", "Lyq/a;", "Lut/d;", "Lkotlin/Function3;", "Landroid/view/LayoutInflater;", "Landroid/view/ViewGroup;", BuildConfig.FLAVOR, "inflateFn", "<init>", "(Lpu/n;)V", "Landroid/content/Context;", "context", BuildConfig.FLAVOR, "C0", "(Landroid/content/Context;)V", "inflater", "container", "Landroid/os/Bundle;", "savedInstanceState", "Landroid/view/View;", "J0", "(Landroid/view/LayoutInflater;Landroid/view/ViewGroup;Landroid/os/Bundle;)Landroid/view/View;", "Lut/a;", BuildConfig.FLAVOR, "c", "()Lut/a;", "h0", "Lpu/n;", "getInflateFn", "()Lpu/n;", "Lut/b;", "i0", "Lut/b;", "f2", "()Lut/b;", "setAndroidInjector", "(Lut/b;)V", "androidInjector", "shared_release"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* loaded from: classes3.dex */
public abstract class a<T extends s5.a> extends yq.a<T> implements ut.d {

    /* renamed from: h0, reason: collision with root package name and from kotlin metadata */
    @NotNull
    public final n<LayoutInflater, ViewGroup, Boolean, T> inflateFn;

    /* renamed from: i0, reason: collision with root package name and from kotlin metadata */
    public ut.b<Object> androidInjector;

    /* JADX WARN: Multi-variable type inference failed */
    public a(@NotNull n<? super LayoutInflater, ? super ViewGroup, ? super Boolean, ? extends T> inflateFn) {
        Intrinsics.checkNotNullParameter(inflateFn, "inflateFn");
        this.inflateFn = inflateFn;
    }

    @Override // yq.a, f4.q
    public void C0(@NotNull Context context) {
        Intrinsics.checkNotNullParameter(context, "context");
        vt.a.b(this);
        super.C0(context);
    }

    @Override // f4.q
    @NotNull
    public View J0(@NotNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        Intrinsics.checkNotNullParameter(inflater, "inflater");
        super.J0(inflater, container, savedInstanceState);
        e2(this.inflateFn.invoke(inflater, container, Boolean.FALSE));
        View root = b2().getRoot();
        Intrinsics.checkNotNullExpressionValue(root, "getRoot(...)");
        return root;
    }

    @Override // ut.d
    @Nullable
    public ut.a<Object> c() {
        return f2();
    }

    @NotNull
    public final ut.b<Object> f2() {
        ut.b<Object> bVar = this.androidInjector;
        if (bVar != null) {
            return bVar;
        }
        Intrinsics.u("androidInjector");
        return null;
    }
}
