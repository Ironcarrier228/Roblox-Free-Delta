package ds;

import android.os.Parcel;
import android.os.Parcelable;
import com.github.luben.zstd.BuildConfig;
import ds.GovernmentIdCapture;
import java.io.Closeable;
import java.io.File;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import kotlin.Metadata;
import kotlin.collections.p;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(d1 = {"\u0000*\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\b6\u0018\u00002\u00020\u00012\u00020\u0002:\u0004\u0007\b\t\nB\t\b\u0004¢\u0006\u0004\b\u0003\u0010\u0004J\u000f\u0010\u0006\u001a\u00020\u0005H\u0016¢\u0006\u0004\b\u0006\u0010\u0004\u0082\u0001\u0004\u000b\f\r\u000e¨\u0006\u000f"}, d2 = {"Lds/g;", "Ljava/io/Closeable;", "Landroid/os/Parcelable;", "<init>", "()V", BuildConfig.FLAVOR, "close", "d", "c", k6.b.f21144e, xe.a.f36648e, "Lds/g$a;", "Lds/g$b;", "Lds/g$c;", "Lds/g$d;", "inquiry-types_release"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* loaded from: classes2.dex */
public abstract class g implements Closeable, Parcelable {

    @Metadata(d1 = {"\u0000D\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0007\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000b\n\u0002\b\n\b\u0087\b\u0018\u00002\u00020\u00012\u00020\u0002B\u001d\u0012\u0006\u0010\u0004\u001a\u00020\u0003\u0012\f\u0010\u0007\u001a\b\u0012\u0004\u0012\u00020\u00060\u0005¢\u0006\u0004\b\b\u0010\tJ\u000f\u0010\u000b\u001a\u00020\nH\u0016¢\u0006\u0004\b\u000b\u0010\fJ\r\u0010\u000e\u001a\u00020\r¢\u0006\u0004\b\u000e\u0010\u000fJ\u001d\u0010\u0013\u001a\u00020\n2\u0006\u0010\u0011\u001a\u00020\u00102\u0006\u0010\u0012\u001a\u00020\r¢\u0006\u0004\b\u0013\u0010\u0014J\u0010\u0010\u0015\u001a\u00020\u0003HÖ\u0001¢\u0006\u0004\b\u0015\u0010\u0016J\u0010\u0010\u0017\u001a\u00020\rHÖ\u0001¢\u0006\u0004\b\u0017\u0010\u000fJ\u001a\u0010\u001b\u001a\u00020\u001a2\b\u0010\u0019\u001a\u0004\u0018\u00010\u0018HÖ\u0003¢\u0006\u0004\b\u001b\u0010\u001cR\u001a\u0010\u0004\u001a\u00020\u00038\u0016X\u0096\u0004¢\u0006\f\n\u0004\b\u001d\u0010\u001e\u001a\u0004\b\u001f\u0010\u0016R\u001d\u0010\u0007\u001a\b\u0012\u0004\u0012\u00020\u00060\u00058\u0006¢\u0006\f\n\u0004\b \u0010!\u001a\u0004\b\"\u0010#¨\u0006$"}, d2 = {"Lds/g$a;", "Lds/g;", "Landroid/os/Parcelable;", BuildConfig.FLAVOR, "stepName", BuildConfig.FLAVOR, "Lds/c;", "documents", "<init>", "(Ljava/lang/String;Ljava/util/List;)V", BuildConfig.FLAVOR, "close", "()V", BuildConfig.FLAVOR, "describeContents", "()I", "Landroid/os/Parcel;", "dest", "flags", "writeToParcel", "(Landroid/os/Parcel;I)V", "toString", "()Ljava/lang/String;", "hashCode", BuildConfig.FLAVOR, "other", BuildConfig.FLAVOR, "equals", "(Ljava/lang/Object;)Z", xe.a.f36648e, "Ljava/lang/String;", "getStepName", k6.b.f21144e, "Ljava/util/List;", "getDocuments", "()Ljava/util/List;", "inquiry-types_release"}, k = 1, mv = {2, 2, 0}, xi = 48)
    /* renamed from: ds.g$a, reason: from toString */
    public static final /* data */ class DocumentStepData extends g implements Parcelable {

        @NotNull
        public static final Parcelable.Creator<DocumentStepData> CREATOR = new C0233a();

        /* renamed from: a, reason: collision with root package name and from kotlin metadata and from toString */
        @NotNull
        public final String stepName;

        /* renamed from: b, reason: from kotlin metadata and from toString */
        @NotNull
        public final List<DocumentFile> documents;

        @Metadata(k = 3, mv = {2, 2, 0}, xi = 48)
        /* renamed from: ds.g$a$a, reason: collision with other inner class name */
        public static final class C0233a implements Parcelable.Creator<DocumentStepData> {
            @Override // android.os.Parcelable.Creator
            /* renamed from: a, reason: merged with bridge method [inline-methods] */
            public final DocumentStepData createFromParcel(Parcel parcel) {
                Intrinsics.checkNotNullParameter(parcel, "parcel");
                String readString = parcel.readString();
                int readInt = parcel.readInt();
                ArrayList arrayList = new ArrayList(readInt);
                for (int i10 = 0; i10 != readInt; i10++) {
                    arrayList.add(DocumentFile.CREATOR.createFromParcel(parcel));
                }
                return new DocumentStepData(readString, arrayList);
            }

            @Override // android.os.Parcelable.Creator
            /* renamed from: b, reason: merged with bridge method [inline-methods] */
            public final DocumentStepData[] newArray(int i10) {
                return new DocumentStepData[i10];
            }
        }

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public DocumentStepData(@NotNull String stepName, @NotNull List<DocumentFile> documents) {
            super(null);
            Intrinsics.checkNotNullParameter(stepName, "stepName");
            Intrinsics.checkNotNullParameter(documents, "documents");
            this.stepName = stepName;
            this.documents = documents;
        }

        @Override // ds.g, java.io.Closeable, java.lang.AutoCloseable
        public void close() {
            Iterator<T> it = this.documents.iterator();
            while (it.hasNext()) {
                ((DocumentFile) it.next()).getData().delete();
            }
        }

        @Override // android.os.Parcelable
        public final int describeContents() {
            return 0;
        }

        public boolean equals(@Nullable Object other) {
            if (this == other) {
                return true;
            }
            if (!(other instanceof DocumentStepData)) {
                return false;
            }
            DocumentStepData documentStepData = (DocumentStepData) other;
            return Intrinsics.c(this.stepName, documentStepData.stepName) && Intrinsics.c(this.documents, documentStepData.documents);
        }

        public int hashCode() {
            return (this.stepName.hashCode() * 31) + this.documents.hashCode();
        }

        @NotNull
        public String toString() {
            return "DocumentStepData(stepName=" + this.stepName + ", documents=" + this.documents + ")";
        }

        @Override // android.os.Parcelable
        public final void writeToParcel(@NotNull Parcel dest, int flags) {
            Intrinsics.checkNotNullParameter(dest, "dest");
            dest.writeString(this.stepName);
            List<DocumentFile> list = this.documents;
            dest.writeInt(list.size());
            Iterator<DocumentFile> it = list.iterator();
            while (it.hasNext()) {
                it.next().writeToParcel(dest, flags);
            }
        }
    }

    @Metadata(d1 = {"\u0000F\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0007\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u000e\b\u0087\b\u0018\u00002\u00020\u0001B%\u0012\u0006\u0010\u0003\u001a\u00020\u0002\u0012\f\u0010\u0006\u001a\b\u0012\u0004\u0012\u00020\u00050\u0004\u0012\u0006\u0010\b\u001a\u00020\u0007¢\u0006\u0004\b\t\u0010\nJ\u000f\u0010\f\u001a\u00020\u000bH\u0016¢\u0006\u0004\b\f\u0010\rJ\r\u0010\u000f\u001a\u00020\u000e¢\u0006\u0004\b\u000f\u0010\u0010J\u001d\u0010\u0014\u001a\u00020\u000b2\u0006\u0010\u0012\u001a\u00020\u00112\u0006\u0010\u0013\u001a\u00020\u000e¢\u0006\u0004\b\u0014\u0010\u0015J\u0010\u0010\u0016\u001a\u00020\u0002HÖ\u0001¢\u0006\u0004\b\u0016\u0010\u0017J\u0010\u0010\u0018\u001a\u00020\u000eHÖ\u0001¢\u0006\u0004\b\u0018\u0010\u0010J\u001a\u0010\u001c\u001a\u00020\u001b2\b\u0010\u001a\u001a\u0004\u0018\u00010\u0019HÖ\u0003¢\u0006\u0004\b\u001c\u0010\u001dR\u001a\u0010\u0003\u001a\u00020\u00028\u0016X\u0096\u0004¢\u0006\f\n\u0004\b\u001e\u0010\u001f\u001a\u0004\b \u0010\u0017R\u001d\u0010\u0006\u001a\b\u0012\u0004\u0012\u00020\u00050\u00048\u0006¢\u0006\f\n\u0004\b!\u0010\"\u001a\u0004\b#\u0010$R\u0017\u0010\b\u001a\u00020\u00078\u0006¢\u0006\f\n\u0004\b%\u0010&\u001a\u0004\b'\u0010(¨\u0006)"}, d2 = {"Lds/g$b;", "Lds/g;", BuildConfig.FLAVOR, "stepName", BuildConfig.FLAVOR, "Lds/e;", "captures", "Lds/b;", "idDetails", "<init>", "(Ljava/lang/String;Ljava/util/List;Lds/b;)V", BuildConfig.FLAVOR, "close", "()V", BuildConfig.FLAVOR, "describeContents", "()I", "Landroid/os/Parcel;", "dest", "flags", "writeToParcel", "(Landroid/os/Parcel;I)V", "toString", "()Ljava/lang/String;", "hashCode", BuildConfig.FLAVOR, "other", BuildConfig.FLAVOR, "equals", "(Ljava/lang/Object;)Z", xe.a.f36648e, "Ljava/lang/String;", "getStepName", k6.b.f21144e, "Ljava/util/List;", "getCaptures", "()Ljava/util/List;", "c", "Lds/b;", "getIdDetails", "()Lds/b;", "inquiry-types_release"}, k = 1, mv = {2, 2, 0}, xi = 48)
    /* renamed from: ds.g$b, reason: from toString */
    public static final /* data */ class GovernmentIdStepData extends g {

        @NotNull
        public static final Parcelable.Creator<GovernmentIdStepData> CREATOR = new a();

        /* renamed from: a, reason: collision with root package name and from kotlin metadata and from toString */
        @NotNull
        public final String stepName;

        /* renamed from: b, reason: from kotlin metadata and from toString */
        @NotNull
        public final List<GovernmentIdCapture> captures;

        /* renamed from: c, reason: collision with root package name and from kotlin metadata and from toString */
        @NotNull
        public final CollectedGovernmentIdDetails idDetails;

        @Metadata(k = 3, mv = {2, 2, 0}, xi = 48)
        /* renamed from: ds.g$b$a */
        public static final class a implements Parcelable.Creator<GovernmentIdStepData> {
            @Override // android.os.Parcelable.Creator
            /* renamed from: a, reason: merged with bridge method [inline-methods] */
            public final GovernmentIdStepData createFromParcel(Parcel parcel) {
                Intrinsics.checkNotNullParameter(parcel, "parcel");
                String readString = parcel.readString();
                int readInt = parcel.readInt();
                ArrayList arrayList = new ArrayList(readInt);
                for (int i10 = 0; i10 != readInt; i10++) {
                    arrayList.add(GovernmentIdCapture.CREATOR.createFromParcel(parcel));
                }
                return new GovernmentIdStepData(readString, arrayList, CollectedGovernmentIdDetails.CREATOR.createFromParcel(parcel));
            }

            @Override // android.os.Parcelable.Creator
            /* renamed from: b, reason: merged with bridge method [inline-methods] */
            public final GovernmentIdStepData[] newArray(int i10) {
                return new GovernmentIdStepData[i10];
            }
        }

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public GovernmentIdStepData(@NotNull String stepName, @NotNull List<GovernmentIdCapture> captures, @NotNull CollectedGovernmentIdDetails idDetails) {
            super(null);
            Intrinsics.checkNotNullParameter(stepName, "stepName");
            Intrinsics.checkNotNullParameter(captures, "captures");
            Intrinsics.checkNotNullParameter(idDetails, "idDetails");
            this.stepName = stepName;
            this.captures = captures;
            this.idDetails = idDetails;
        }

        @Override // ds.g, java.io.Closeable, java.lang.AutoCloseable
        public void close() {
            Iterator<T> it = this.captures.iterator();
            while (it.hasNext()) {
                Iterator<T> it2 = ((GovernmentIdCapture) it.next()).j3().iterator();
                while (it2.hasNext()) {
                    ((GovernmentIdCapture.Frame) it2.next()).getData().delete();
                }
            }
        }

        @Override // android.os.Parcelable
        public final int describeContents() {
            return 0;
        }

        public boolean equals(@Nullable Object other) {
            if (this == other) {
                return true;
            }
            if (!(other instanceof GovernmentIdStepData)) {
                return false;
            }
            GovernmentIdStepData governmentIdStepData = (GovernmentIdStepData) other;
            return Intrinsics.c(this.stepName, governmentIdStepData.stepName) && Intrinsics.c(this.captures, governmentIdStepData.captures) && Intrinsics.c(this.idDetails, governmentIdStepData.idDetails);
        }

        public int hashCode() {
            return (((this.stepName.hashCode() * 31) + this.captures.hashCode()) * 31) + this.idDetails.hashCode();
        }

        @NotNull
        public String toString() {
            return "GovernmentIdStepData(stepName=" + this.stepName + ", captures=" + this.captures + ", idDetails=" + this.idDetails + ")";
        }

        @Override // android.os.Parcelable
        public final void writeToParcel(@NotNull Parcel dest, int flags) {
            Intrinsics.checkNotNullParameter(dest, "dest");
            dest.writeString(this.stepName);
            List<GovernmentIdCapture> list = this.captures;
            dest.writeInt(list.size());
            Iterator<GovernmentIdCapture> it = list.iterator();
            while (it.hasNext()) {
                it.next().writeToParcel(dest, flags);
            }
            this.idDetails.writeToParcel(dest, flags);
        }
    }

    @Metadata(d1 = {"\u0000<\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0007\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u000e\b\u0087\b\u0018\u00002\u00020\u0001B-\u0012\u0006\u0010\u0003\u001a\u00020\u0002\u0012\b\u0010\u0005\u001a\u0004\u0018\u00010\u0004\u0012\b\u0010\u0006\u001a\u0004\u0018\u00010\u0004\u0012\b\u0010\u0007\u001a\u0004\u0018\u00010\u0004¢\u0006\u0004\b\b\u0010\tJ\u000f\u0010\u000b\u001a\u00020\nH\u0016¢\u0006\u0004\b\u000b\u0010\fJ\r\u0010\u000e\u001a\u00020\r¢\u0006\u0004\b\u000e\u0010\u000fJ\u001d\u0010\u0013\u001a\u00020\n2\u0006\u0010\u0011\u001a\u00020\u00102\u0006\u0010\u0012\u001a\u00020\r¢\u0006\u0004\b\u0013\u0010\u0014J\u0010\u0010\u0015\u001a\u00020\u0002HÖ\u0001¢\u0006\u0004\b\u0015\u0010\u0016J\u0010\u0010\u0017\u001a\u00020\rHÖ\u0001¢\u0006\u0004\b\u0017\u0010\u000fJ\u001a\u0010\u001b\u001a\u00020\u001a2\b\u0010\u0019\u001a\u0004\u0018\u00010\u0018HÖ\u0003¢\u0006\u0004\b\u001b\u0010\u001cR\u001a\u0010\u0003\u001a\u00020\u00028\u0016X\u0096\u0004¢\u0006\f\n\u0004\b\u001d\u0010\u001e\u001a\u0004\b\u001f\u0010\u0016R\u0019\u0010\u0005\u001a\u0004\u0018\u00010\u00048\u0006¢\u0006\f\n\u0004\b \u0010!\u001a\u0004\b\"\u0010#R\u0019\u0010\u0006\u001a\u0004\u0018\u00010\u00048\u0006¢\u0006\f\n\u0004\b$\u0010!\u001a\u0004\b%\u0010#R\u0019\u0010\u0007\u001a\u0004\u0018\u00010\u00048\u0006¢\u0006\f\n\u0004\b&\u0010!\u001a\u0004\b'\u0010#¨\u0006("}, d2 = {"Lds/g$c;", "Lds/g;", BuildConfig.FLAVOR, "stepName", "Lds/f;", "centerCapture", "leftCapture", "rightCapture", "<init>", "(Ljava/lang/String;Lds/f;Lds/f;Lds/f;)V", BuildConfig.FLAVOR, "close", "()V", BuildConfig.FLAVOR, "describeContents", "()I", "Landroid/os/Parcel;", "dest", "flags", "writeToParcel", "(Landroid/os/Parcel;I)V", "toString", "()Ljava/lang/String;", "hashCode", BuildConfig.FLAVOR, "other", BuildConfig.FLAVOR, "equals", "(Ljava/lang/Object;)Z", xe.a.f36648e, "Ljava/lang/String;", "getStepName", k6.b.f21144e, "Lds/f;", "getCenterCapture", "()Lds/f;", "c", "getLeftCapture", "d", "getRightCapture", "inquiry-types_release"}, k = 1, mv = {2, 2, 0}, xi = 48)
    /* renamed from: ds.g$c, reason: from toString */
    public static final /* data */ class SelfieStepData extends g {

        @NotNull
        public static final Parcelable.Creator<SelfieStepData> CREATOR = new a();

        /* renamed from: a, reason: collision with root package name and from kotlin metadata and from toString */
        @NotNull
        public final String stepName;

        /* renamed from: b, reason: from kotlin metadata and from toString */
        @Nullable
        public final SelfieCapture centerCapture;

        /* renamed from: c, reason: collision with root package name and from kotlin metadata and from toString */
        @Nullable
        public final SelfieCapture leftCapture;

        /* renamed from: d, reason: collision with root package name and from kotlin metadata and from toString */
        @Nullable
        public final SelfieCapture rightCapture;

        @Metadata(k = 3, mv = {2, 2, 0}, xi = 48)
        /* renamed from: ds.g$c$a */
        public static final class a implements Parcelable.Creator<SelfieStepData> {
            @Override // android.os.Parcelable.Creator
            /* renamed from: a, reason: merged with bridge method [inline-methods] */
            public final SelfieStepData createFromParcel(Parcel parcel) {
                Intrinsics.checkNotNullParameter(parcel, "parcel");
                return new SelfieStepData(parcel.readString(), parcel.readInt() == 0 ? null : SelfieCapture.CREATOR.createFromParcel(parcel), parcel.readInt() == 0 ? null : SelfieCapture.CREATOR.createFromParcel(parcel), parcel.readInt() != 0 ? SelfieCapture.CREATOR.createFromParcel(parcel) : null);
            }

            @Override // android.os.Parcelable.Creator
            /* renamed from: b, reason: merged with bridge method [inline-methods] */
            public final SelfieStepData[] newArray(int i10) {
                return new SelfieStepData[i10];
            }
        }

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public SelfieStepData(@NotNull String stepName, @Nullable SelfieCapture selfieCapture, @Nullable SelfieCapture selfieCapture2, @Nullable SelfieCapture selfieCapture3) {
            super(null);
            Intrinsics.checkNotNullParameter(stepName, "stepName");
            this.stepName = stepName;
            this.centerCapture = selfieCapture;
            this.leftCapture = selfieCapture2;
            this.rightCapture = selfieCapture3;
        }

        @Override // ds.g, java.io.Closeable, java.lang.AutoCloseable
        public void close() {
            File data;
            for (SelfieCapture selfieCapture : p.n(this.centerCapture, this.leftCapture, this.rightCapture)) {
                if (selfieCapture != null && (data = selfieCapture.getData()) != null) {
                    data.delete();
                }
            }
        }

        @Override // android.os.Parcelable
        public final int describeContents() {
            return 0;
        }

        public boolean equals(@Nullable Object other) {
            if (this == other) {
                return true;
            }
            if (!(other instanceof SelfieStepData)) {
                return false;
            }
            SelfieStepData selfieStepData = (SelfieStepData) other;
            return Intrinsics.c(this.stepName, selfieStepData.stepName) && Intrinsics.c(this.centerCapture, selfieStepData.centerCapture) && Intrinsics.c(this.leftCapture, selfieStepData.leftCapture) && Intrinsics.c(this.rightCapture, selfieStepData.rightCapture);
        }

        public int hashCode() {
            int hashCode = this.stepName.hashCode() * 31;
            SelfieCapture selfieCapture = this.centerCapture;
            int hashCode2 = (hashCode + (selfieCapture == null ? 0 : selfieCapture.hashCode())) * 31;
            SelfieCapture selfieCapture2 = this.leftCapture;
            int hashCode3 = (hashCode2 + (selfieCapture2 == null ? 0 : selfieCapture2.hashCode())) * 31;
            SelfieCapture selfieCapture3 = this.rightCapture;
            return hashCode3 + (selfieCapture3 != null ? selfieCapture3.hashCode() : 0);
        }

        @NotNull
        public String toString() {
            return "SelfieStepData(stepName=" + this.stepName + ", centerCapture=" + this.centerCapture + ", leftCapture=" + this.leftCapture + ", rightCapture=" + this.rightCapture + ")";
        }

        @Override // android.os.Parcelable
        public final void writeToParcel(@NotNull Parcel dest, int flags) {
            Intrinsics.checkNotNullParameter(dest, "dest");
            dest.writeString(this.stepName);
            SelfieCapture selfieCapture = this.centerCapture;
            if (selfieCapture == null) {
                dest.writeInt(0);
            } else {
                dest.writeInt(1);
                selfieCapture.writeToParcel(dest, flags);
            }
            SelfieCapture selfieCapture2 = this.leftCapture;
            if (selfieCapture2 == null) {
                dest.writeInt(0);
            } else {
                dest.writeInt(1);
                selfieCapture2.writeToParcel(dest, flags);
            }
            SelfieCapture selfieCapture3 = this.rightCapture;
            if (selfieCapture3 == null) {
                dest.writeInt(0);
            } else {
                dest.writeInt(1);
                selfieCapture3.writeToParcel(dest, flags);
            }
        }
    }

    @Metadata(d1 = {"\u0000:\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010$\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0002\b\u0006\n\u0002\u0010\u000b\n\u0002\b\n\b\u0087\b\u0018\u00002\u00020\u0001B#\u0012\u0006\u0010\u0003\u001a\u00020\u0002\u0012\u0012\u0010\u0006\u001a\u000e\u0012\u0004\u0012\u00020\u0002\u0012\u0004\u0012\u00020\u00050\u0004¢\u0006\u0004\b\u0007\u0010\bJ\r\u0010\n\u001a\u00020\t¢\u0006\u0004\b\n\u0010\u000bJ\u001d\u0010\u0010\u001a\u00020\u000f2\u0006\u0010\r\u001a\u00020\f2\u0006\u0010\u000e\u001a\u00020\t¢\u0006\u0004\b\u0010\u0010\u0011J\u0010\u0010\u0012\u001a\u00020\u0002HÖ\u0001¢\u0006\u0004\b\u0012\u0010\u0013J\u0010\u0010\u0014\u001a\u00020\tHÖ\u0001¢\u0006\u0004\b\u0014\u0010\u000bJ\u001a\u0010\u0017\u001a\u00020\u00162\b\u0010\u0015\u001a\u0004\u0018\u00010\u0005HÖ\u0003¢\u0006\u0004\b\u0017\u0010\u0018R\u001a\u0010\u0003\u001a\u00020\u00028\u0016X\u0096\u0004¢\u0006\f\n\u0004\b\u0019\u0010\u001a\u001a\u0004\b\u001b\u0010\u0013R#\u0010\u0006\u001a\u000e\u0012\u0004\u0012\u00020\u0002\u0012\u0004\u0012\u00020\u00050\u00048\u0006¢\u0006\f\n\u0004\b\u001c\u0010\u001d\u001a\u0004\b\u001e\u0010\u001f¨\u0006 "}, d2 = {"Lds/g$d;", "Lds/g;", BuildConfig.FLAVOR, "stepName", BuildConfig.FLAVOR, BuildConfig.FLAVOR, "componentParams", "<init>", "(Ljava/lang/String;Ljava/util/Map;)V", BuildConfig.FLAVOR, "describeContents", "()I", "Landroid/os/Parcel;", "dest", "flags", BuildConfig.FLAVOR, "writeToParcel", "(Landroid/os/Parcel;I)V", "toString", "()Ljava/lang/String;", "hashCode", "other", BuildConfig.FLAVOR, "equals", "(Ljava/lang/Object;)Z", xe.a.f36648e, "Ljava/lang/String;", "getStepName", k6.b.f21144e, "Ljava/util/Map;", "getComponentParams", "()Ljava/util/Map;", "inquiry-types_release"}, k = 1, mv = {2, 2, 0}, xi = 48)
    /* renamed from: ds.g$d, reason: from toString */
    public static final /* data */ class UiStepData extends g {

        @NotNull
        public static final Parcelable.Creator<UiStepData> CREATOR = new a();

        /* renamed from: a, reason: collision with root package name and from kotlin metadata and from toString */
        @NotNull
        public final String stepName;

        /* renamed from: b, reason: from kotlin metadata and from toString */
        @NotNull
        public final Map<String, Object> componentParams;

        @Metadata(k = 3, mv = {2, 2, 0}, xi = 48)
        /* renamed from: ds.g$d$a */
        public static final class a implements Parcelable.Creator<UiStepData> {
            @Override // android.os.Parcelable.Creator
            /* renamed from: a, reason: merged with bridge method [inline-methods] */
            public final UiStepData createFromParcel(Parcel parcel) {
                Intrinsics.checkNotNullParameter(parcel, "parcel");
                String readString = parcel.readString();
                int readInt = parcel.readInt();
                LinkedHashMap linkedHashMap = new LinkedHashMap(readInt);
                for (int i10 = 0; i10 != readInt; i10++) {
                    linkedHashMap.put(parcel.readString(), parcel.readValue(UiStepData.class.getClassLoader()));
                }
                return new UiStepData(readString, linkedHashMap);
            }

            @Override // android.os.Parcelable.Creator
            /* renamed from: b, reason: merged with bridge method [inline-methods] */
            public final UiStepData[] newArray(int i10) {
                return new UiStepData[i10];
            }
        }

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public UiStepData(@NotNull String stepName, @NotNull Map<String, ? extends Object> componentParams) {
            super(null);
            Intrinsics.checkNotNullParameter(stepName, "stepName");
            Intrinsics.checkNotNullParameter(componentParams, "componentParams");
            this.stepName = stepName;
            this.componentParams = componentParams;
        }

        @Override // android.os.Parcelable
        public final int describeContents() {
            return 0;
        }

        public boolean equals(@Nullable Object other) {
            if (this == other) {
                return true;
            }
            if (!(other instanceof UiStepData)) {
                return false;
            }
            UiStepData uiStepData = (UiStepData) other;
            return Intrinsics.c(this.stepName, uiStepData.stepName) && Intrinsics.c(this.componentParams, uiStepData.componentParams);
        }

        public int hashCode() {
            return (this.stepName.hashCode() * 31) + this.componentParams.hashCode();
        }

        @NotNull
        public String toString() {
            return "UiStepData(stepName=" + this.stepName + ", componentParams=" + this.componentParams + ")";
        }

        @Override // android.os.Parcelable
        public final void writeToParcel(@NotNull Parcel dest, int flags) {
            Intrinsics.checkNotNullParameter(dest, "dest");
            dest.writeString(this.stepName);
            Map<String, Object> map = this.componentParams;
            dest.writeInt(map.size());
            for (Map.Entry<String, Object> entry : map.entrySet()) {
                dest.writeString(entry.getKey());
                dest.writeValue(entry.getValue());
            }
        }
    }

    public /* synthetic */ g(DefaultConstructorMarker defaultConstructorMarker) {
        this();
    }

    @Override // java.io.Closeable, java.lang.AutoCloseable
    public void close() {
    }

    public g() {
    }


    // --- восстановлено из DEX (ds/g$a$a) ---
    public static class a implements android.os.Parcelable.Creator {
        public a() { }
        public ds.g.a a(android.os.Parcel p0) { throw new UnsupportedOperationException("stub"); }
        public ds.g.a[] b(int p0) { throw new UnsupportedOperationException("stub"); }
        public java.lang.Object createFromParcel(android.os.Parcel p0) { throw new UnsupportedOperationException("stub"); }
        public java.lang.Object[] newArray(int p0) { throw new UnsupportedOperationException("stub"); }
    }

    // --- восстановлено из DEX (ds/g$b) ---
    public static class b extends ds.g {
        android.os.Parcelable.Creator CREATOR;
        java.lang.String a;
        java.util.List b;
        ds.b c;
        public b(java.lang.String p0, java.util.List p1, ds.b p2) { }
        public void close() { throw new UnsupportedOperationException("stub"); }
        public int describeContents() { throw new UnsupportedOperationException("stub"); }
        public boolean equals(java.lang.Object p0) { throw new UnsupportedOperationException("stub"); }
        public int hashCode() { throw new UnsupportedOperationException("stub"); }
        public java.lang.String toString() { throw new UnsupportedOperationException("stub"); }
        public void writeToParcel(android.os.Parcel p0, int p1) { throw new UnsupportedOperationException("stub"); }
    }

    // --- восстановлено из DEX (ds/g$b$a) ---
    public static class a implements android.os.Parcelable.Creator {
        public a() { }
        public ds.g.b a(android.os.Parcel p0) { throw new UnsupportedOperationException("stub"); }
        public ds.g.b[] b(int p0) { throw new UnsupportedOperationException("stub"); }
        public java.lang.Object createFromParcel(android.os.Parcel p0) { throw new UnsupportedOperationException("stub"); }
        public java.lang.Object[] newArray(int p0) { throw new UnsupportedOperationException("stub"); }
    }

    // --- восстановлено из DEX (ds/g$c) ---
    public static class c extends ds.g {
        android.os.Parcelable.Creator CREATOR;
        java.lang.String a;
        ds.f b;
        ds.f c;
        ds.f d;
        public c(java.lang.String p0, ds.f p1, ds.f p2, ds.f p3) { }
        public void close() { throw new UnsupportedOperationException("stub"); }
        public int describeContents() { throw new UnsupportedOperationException("stub"); }
        public boolean equals(java.lang.Object p0) { throw new UnsupportedOperationException("stub"); }
        public int hashCode() { throw new UnsupportedOperationException("stub"); }
        public java.lang.String toString() { throw new UnsupportedOperationException("stub"); }
        public void writeToParcel(android.os.Parcel p0, int p1) { throw new UnsupportedOperationException("stub"); }
    }

    // --- восстановлено из DEX (ds/g$c$a) ---
    public static class a implements android.os.Parcelable.Creator {
        public a() { }
        public ds.g.c a(android.os.Parcel p0) { throw new UnsupportedOperationException("stub"); }
        public ds.g.c[] b(int p0) { throw new UnsupportedOperationException("stub"); }
        public java.lang.Object createFromParcel(android.os.Parcel p0) { throw new UnsupportedOperationException("stub"); }
        public java.lang.Object[] newArray(int p0) { throw new UnsupportedOperationException("stub"); }
    }

    // --- восстановлено из DEX (ds/g$d) ---
    public static class d extends ds.g {
        android.os.Parcelable.Creator CREATOR;
        java.lang.String a;
        java.util.Map b;
        public d(java.lang.String p0, java.util.Map p1) { }
        public int describeContents() { throw new UnsupportedOperationException("stub"); }
        public boolean equals(java.lang.Object p0) { throw new UnsupportedOperationException("stub"); }
        public int hashCode() { throw new UnsupportedOperationException("stub"); }
        public java.lang.String toString() { throw new UnsupportedOperationException("stub"); }
        public void writeToParcel(android.os.Parcel p0, int p1) { throw new UnsupportedOperationException("stub"); }
    }

    // --- восстановлено из DEX (ds/g$d$a) ---
    public static class a implements android.os.Parcelable.Creator {
        public a() { }
        public ds.g.d a(android.os.Parcel p0) { throw new UnsupportedOperationException("stub"); }
        public ds.g.d[] b(int p0) { throw new UnsupportedOperationException("stub"); }
        public java.lang.Object createFromParcel(android.os.Parcel p0) { throw new UnsupportedOperationException("stub"); }
        public java.lang.Object[] newArray(int p0) { throw new UnsupportedOperationException("stub"); }
    }
}
