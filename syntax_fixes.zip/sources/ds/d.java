package ds;

import android.os.Parcel;
import android.os.Parcelable;
import com.github.luben.zstd.BuildConfig;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;

/* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
/* JADX WARN: Unknown enum class pattern. Please report as an issue! */
@Metadata(d1 = {"\u0000(\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u0010\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0002\b\u000f\b\u0087\u0081\u0002\u0018\u00002\u00020\u00012\b\u0012\u0004\u0012\u00020\u00000\u0002B\t\b\u0002¢\u0006\u0004\b\u0003\u0010\u0004J\r\u0010\u0006\u001a\u00020\u0005¢\u0006\u0004\b\u0006\u0010\u0007J\u001d\u0010\f\u001a\u00020\u000b2\u0006\u0010\t\u001a\u00020\b2\u0006\u0010\n\u001a\u00020\u0005¢\u0006\u0004\b\f\u0010\rj\u0002\b\u000ej\u0002\b\u000fj\u0002\b\u0010j\u0002\b\u0011j\u0002\b\u0012j\u0002\b\u0013j\u0002\b\u0014j\u0002\b\u0015j\u0002\b\u0016j\u0002\b\u0017j\u0002\b\u0018j\u0002\b\u0019¨\u0006\u001a"}, d2 = {"Lds/d;", "Landroid/os/Parcelable;", BuildConfig.FLAVOR, "<init>", "(Ljava/lang/String;I)V", BuildConfig.FLAVOR, "describeContents", "()I", "Landroid/os/Parcel;", "dest", "flags", BuildConfig.FLAVOR, "writeToParcel", "(Landroid/os/Parcel;I)V", xe.a.f36648e, k6.b.f21144e, "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "inquiry-types_release"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* loaded from: classes2.dex */
public final class d implements Parcelable {

    @NotNull
    public static final Parcelable.Creator<d> CREATOR;

    /* renamed from: a, reason: collision with root package name */
    public static final d f12654a = new d("NetworkError", 0);
    public static final d b = new d("CameraPermissionError", 1);

    /* renamed from: c, reason: collision with root package name */
    public static final d f12655c = new d("SdkConfigurationError", 2);

    /* renamed from: d, reason: collision with root package name */
    public static final d f12656d = new d("CameraCompatibilityError", 3);

    /* renamed from: e, reason: collision with root package name */
    public static final d f12657e = new d("IntegrationError", 4);

    /* renamed from: f, reason: collision with root package name */
    public static final d f12658f = new d("SessionTokenError", 5);

    /* renamed from: g, reason: collision with root package name */
    public static final d f12659g = new d("RateLimitExceeded", 6);

    /* renamed from: h, reason: collision with root package name */
    public static final d f12660h = new d("UnexpectedError", 7);

    /* renamed from: i, reason: collision with root package name */
    public static final d f12661i = new d("NoDiskSpaceError", 8);

    /* renamed from: j, reason: collision with root package name */
    public static final d f12662j = new d("WebRtcIntegrationError", 9);

    /* renamed from: k, reason: collision with root package name */
    public static final d f12663k = new d("InvalidOneTimeLinkCode", 10);

    /* renamed from: l, reason: collision with root package name */
    public static final d f12664l = new d("ExceptionError", 11);

    /* renamed from: m, reason: collision with root package name */
    public static final /* synthetic */ d[] f12665m;

    /* renamed from: n, reason: collision with root package name */
    public static final /* synthetic */ hu.a f12666n;

    static {
        d[] a10 = a();
        f12665m = a10;
        f12666n = hu.b.a(a10);
        CREATOR = new Parcelable.Creator<d>() { // from class: ds.d.a
            @Override // android.os.Parcelable.Creator
            /* renamed from: a, reason: merged with bridge method [inline-methods] */
            public final d createFromParcel(Parcel parcel) {
                Intrinsics.checkNotNullParameter(parcel, "parcel");
                return d.valueOf(parcel.readString());
            }

            @Override // android.os.Parcelable.Creator
            /* renamed from: b, reason: merged with bridge method [inline-methods] */
            public final d[] newArray(int i10) {
                return new d[i10];
            }
        };
    }

    public d(String str, int i10) {
    }

    public static final /* synthetic */ d[] a() {
        return new d[]{f12654a, b, f12655c, f12656d, f12657e, f12658f, f12659g, f12660h, f12661i, f12662j, f12663k, f12664l};
    }

    public static d valueOf(String str) {
        return (d) Enum.valueOf(d.class, str);
    }

    public static d[] values() {
        return (d[]) f12665m.clone();
    }

    @Override // android.os.Parcelable
    public final int describeContents() {
        return 0;
    }

    @Override // android.os.Parcelable
    public final void writeToParcel(@NotNull Parcel dest, int flags) {
        Intrinsics.checkNotNullParameter(dest, "dest");
        dest.writeString(name());
    }


    // --- восстановлено из DEX (ds/d$a) ---
    public static class a implements android.os.Parcelable.Creator {
        public a() { }
        public ds.d a(android.os.Parcel p0) { throw new UnsupportedOperationException("stub"); }
        public ds.d[] b(int p0) { throw new UnsupportedOperationException("stub"); }
        public java.lang.Object createFromParcel(android.os.Parcel p0) { throw new UnsupportedOperationException("stub"); }
        public java.lang.Object[] newArray(int p0) { throw new UnsupportedOperationException("stub"); }
    }
}
