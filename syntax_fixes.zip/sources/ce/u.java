package ce;

import android.os.Bundle;
import android.os.RemoteException;
import de.q1;
import de.r1;
import java.util.ArrayList;
import java.util.List;

/* loaded from: classes2.dex */
public final class u extends r1 {
    public final /* synthetic */ List b;

    /* renamed from: c, reason: collision with root package name */
    public final /* synthetic */ tb.k f5011c;

    /* renamed from: d, reason: collision with root package name */
    public final /* synthetic */ a0 f5012d;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public u(a0 a0Var, tb.k kVar, List list, tb.k kVar2) {
        super(kVar);
        this.f5012d = a0Var;
        this.b = list;
        this.f5011c = kVar2;
    }

    /* JADX WARN: Type inference failed for: r0v3, types: [android.os.IInterface, de.k0] */
    @Override // de.r1
    public final void c() {
        q1 q1Var;
        String str;
        Bundle j10;
        try {
            var e10 = this.f5012d.b.e();
            str = this.f5012d.f4952a;
            ArrayList i10 = a0.i(this.b);
            j10 = a0.j();
            e10.u1(str, i10, j10, new v(this.f5012d, this.f5011c));
        } catch (RemoteException e11) {
            q1Var = a0.f4950c;
            q1Var.c(e11, "deferredInstall(%s)", this.b);
            this.f5011c.d(new RuntimeException(e11));
        }
    }
}
