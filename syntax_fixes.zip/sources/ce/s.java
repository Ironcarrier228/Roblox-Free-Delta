package ce;

import android.os.RemoteException;
import de.j1;
import de.q1;
import de.r1;
import java.util.ArrayList;
import java.util.Collection;

/* loaded from: classes2.dex */
public final class s extends r1 {
    public final /* synthetic */ Collection b;

    /* renamed from: c, reason: collision with root package name */
    public final /* synthetic */ Collection f5005c;

    /* renamed from: d, reason: collision with root package name */
    public final /* synthetic */ j1 f5006d;

    /* renamed from: e, reason: collision with root package name */
    public final /* synthetic */ tb.k f5007e;

    /* renamed from: f, reason: collision with root package name */
    public final /* synthetic */ a0 f5008f;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public s(a0 a0Var, tb.k kVar, Collection collection, Collection collection2, j1 j1Var, tb.k kVar2) {
        super(kVar);
        this.f5008f = a0Var;
        this.b = collection;
        this.f5005c = collection2;
        this.f5006d = j1Var;
        this.f5007e = kVar2;
    }

    /* JADX WARN: Type inference failed for: r1v7, types: [android.os.IInterface, de.k0] */
    @Override // de.r1
    public final void c() {
        q1 q1Var;
        String str;
        ArrayList i10 = a0.i(this.b);
        i10.addAll(a0.h(this.f5005c));
        try {
            this.f5006d.b(2);
            var e10 = this.f5008f.b.e();
            str = this.f5008f.f4952a;
            e10.l0(str, i10, a0.b(this.f5006d), new y(this.f5008f, this.f5007e));
        } catch (RemoteException e11) {
            q1Var = a0.f4950c;
            q1Var.c(e11, "startInstall(%s,%s)", this.b, this.f5005c);
            this.f5007e.d(new RuntimeException(e11));
        }
    }
}
