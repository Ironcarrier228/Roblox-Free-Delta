package ce;

import android.os.Bundle;
import android.os.RemoteException;
import de.q1;
import de.r1;
import java.util.ArrayList;
import java.util.List;

/* loaded from: classes2.dex */
public final class t extends r1 {
    public final /* synthetic */ List b;

    /* renamed from: c, reason: collision with root package name */
    public final /* synthetic */ tb.k f5009c;

    /* renamed from: d, reason: collision with root package name */
    public final /* synthetic */ a0 f5010d;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public t(a0 a0Var, tb.k kVar, List list, tb.k kVar2) {
        super(kVar);
        this.f5010d = a0Var;
        this.b = list;
        this.f5009c = kVar2;
    }

    /* JADX WARN: Type inference failed for: r0v3, types: [android.os.IInterface, de.k0] */
    @Override // de.r1
    public final void c() {
        q1 q1Var;
        String str;
        Bundle j10;
        try {
            var e10 = this.f5010d.b.e();
            str = this.f5010d.f4952a;
            ArrayList i10 = a0.i(this.b);
            j10 = a0.j();
            e10.V0(str, i10, j10, new w(this.f5010d, this.f5009c));
        } catch (RemoteException e11) {
            q1Var = a0.f4950c;
            q1Var.c(e11, "deferredUninstall(%s)", this.b);
            this.f5009c.d(new RuntimeException(e11));
        }
    }
}
