package gd;

import android.R;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.os.Build;
import android.util.Log;
import androidx.annotation.NonNull;

/* loaded from: classes2.dex */
public class b {

    /* renamed from: a, reason: collision with root package name */
    public static final boolean f17683a = true;
    public static final int[] b = {android.R.attr.state_pressed};

    /* renamed from: c, reason: collision with root package name */
    public static final int[] f17684c = {android.R.attr.state_hovered, android.R.attr.state_focused};

    /* renamed from: d, reason: collision with root package name */
    public static final int[] f17685d = {android.R.attr.state_focused};

    /* renamed from: e, reason: collision with root package name */
    public static final int[] f17686e = {android.R.attr.state_hovered};

    /* renamed from: f, reason: collision with root package name */
    public static final int[] f17687f = {android.R.attr.state_selected, android.R.attr.state_pressed};

    /* renamed from: g, reason: collision with root package name */
    public static final int[] f17688g = {android.R.attr.state_selected, android.R.attr.state_hovered, android.R.attr.state_focused};

    /* renamed from: h, reason: collision with root package name */
    public static final int[] f17689h = {android.R.attr.state_selected, android.R.attr.state_focused};

    /* renamed from: i, reason: collision with root package name */
    public static final int[] f17690i = {android.R.attr.state_selected, android.R.attr.state_hovered};

    /* renamed from: j, reason: collision with root package name */
    public static final int[] f17691j = {android.R.attr.state_selected};

    /* renamed from: k, reason: collision with root package name */
    public static final int[] f17692k = {android.R.attr.state_enabled, android.R.attr.state_pressed};

    /* renamed from: l, reason: collision with root package name */
    public static final String f17693l = b.class.getSimpleName();

    @NonNull
    public static ColorStateList a(ColorStateList colorStateList) {
        if (colorStateList == null) {
            return ColorStateList.valueOf(0);
        }
        if (Build.VERSION.SDK_INT <= 27 && Color.alpha(colorStateList.getDefaultColor()) == 0 && Color.alpha(colorStateList.getColorForState(f17692k, 0)) != 0) {
            Log.w(f17693l, "Use a non-transparent color for the default color as it will be used to finish ripple animations.");
        }
        return colorStateList;
    }

    public static boolean b(@NonNull int[] iArr) {
        boolean z10 = false;
        boolean z11 = false;
        for (int i10 : iArr) {
            if (i10 == 16842910) {
                z10 = true;
            } else if (i10 == 16842908 || i10 == 16842919 || i10 == 16843623) {
                z11 = true;
            }
        }
        return z10 && z11;
    }
}
