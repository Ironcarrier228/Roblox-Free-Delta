package zt;

import com.github.luben.zstd.BuildConfig;
import java.io.Serializable;
import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
import kotlin.Metadata;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(d1 = {"\u00002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\b\u0004\n\u0002\u0010\u0000\n\u0002\b\f\b\u0002\u0018\u0000 \u001c*\u0006\b\u0000\u0010\u0001 \u00012\b\u0012\u0004\u0012\u00028\u00000\u00022\u00060\u0003j\u0002`\u0004:\u0001\u000fB\u0015\u0012\f\u0010\u0006\u001a\b\u0012\u0004\u0012\u00028\u00000\u0005¢\u0006\u0004\b\u0007\u0010\bJ\u000f\u0010\n\u001a\u00020\tH\u0016¢\u0006\u0004\b\n\u0010\u000bJ\u000f\u0010\r\u001a\u00020\fH\u0016¢\u0006\u0004\b\r\u0010\u000eR\u001e\u0010\u0006\u001a\n\u0012\u0004\u0012\u00028\u0000\u0018\u00010\u00058\u0002@\u0002X\u0082\u000e¢\u0006\u0006\n\u0004\b\u000f\u0010\u0010R\u0018\u0010\u0014\u001a\u0004\u0018\u00010\u00118\u0002@\u0002X\u0082\u000e¢\u0006\u0006\n\u0004\b\u0012\u0010\u0013R\u001a\u0010\u0018\u001a\u00020\u00118\u0002X\u0082\u0004¢\u0006\f\n\u0004\b\u0015\u0010\u0013\u0012\u0004\b\u0016\u0010\u0017R\u0014\u0010\u001b\u001a\u00028\u00008VX\u0096\u0004¢\u0006\u0006\u001a\u0004\b\u0019\u0010\u001a¨\u0006\u001d"}, d2 = {"Lzt/p;", "T", "Lzt/h;", "Ljava/io/Serializable;", "Lkotlin/io/Serializable;", "Lkotlin/Function0;", "initializer", "<init>", "(Lkotlin/jvm/functions/Function0;)V", BuildConfig.FLAVOR, "isInitialized", "()Z", BuildConfig.FLAVOR, "toString", "()Ljava/lang/String;", xe.a.f36648e, "Lkotlin/jvm/functions/Function0;", BuildConfig.FLAVOR, k6.b.f21144e, "Ljava/lang/Object;", "_value", "c", "getFinal$annotations", "()V", "final", "getValue", "()Ljava/lang/Object;", "value", "d", "kotlin-stdlib"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* loaded from: classes2.dex */
public final class p<T> implements h<T>, Serializable {

    /* renamed from: e, reason: collision with root package name */
    public static final AtomicReferenceFieldUpdater<p<?>, Object> f39492e = AtomicReferenceFieldUpdater.newUpdater(p.class, Object.class, k6.b.f21144e);

    /* renamed from: a, reason: collision with root package name and from kotlin metadata */
    @Nullable
    public volatile Function0<? extends T> initializer;

    /* renamed from: b, reason: from kotlin metadata */
    @Nullable
    public volatile Object _value;

    /* renamed from: c, reason: collision with root package name and from kotlin metadata */
    @NotNull
    public final Object final_;

    public p(@NotNull Function0<? extends T> initializer) {
        Intrinsics.checkNotNullParameter(initializer, "initializer");
        this.initializer = initializer;
        a0 a0Var = a0.f39472a;
        this._value = a0Var;
        this.final_ = a0Var;
    }

    @Override // zt.h
    public T getValue() {
        T t8 = (T) this._value;
        a0 a0Var = a0.f39472a;
        if (t8 != a0Var) {
            return t8;
        }
        Function0<? extends T> function0 = this.initializer;
        if (function0 != null) {
            T invoke = function0.invoke();
            if (y1.b.a(f39492e, this, a0Var, invoke)) {
                this.initializer = null;
                return invoke;
            }
        }
        return (T) this._value;
    }

    @Override // zt.h
    public boolean isInitialized() {
        return this._value != a0.f39472a;
    }

    @NotNull
    public String toString() {
        return isInitialized() ? String.valueOf(getValue()) : "Lazy value not initialized yet.";
    }
}
