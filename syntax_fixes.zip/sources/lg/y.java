package lg;

import java.math.BigDecimal;
import ng.c0;

/* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
/* JADX WARN: Unknown enum class pattern. Please report as an issue! */
/* loaded from: classes2.dex */
public abstract class y implements z {

    /* renamed from: a, reason: collision with root package name */
    public static final y f22150a = new a("DOUBLE", 0);
    public static final y b = new y("LAZILY_PARSED_NUMBER", 1) { // from class: lg.y.b
        {
            a aVar = null;
        }

        @Override // lg.z
        public Number a(tg.a aVar) {
            return new ng.a0(aVar.N());
        }
    };

    /* renamed from: c, reason: collision with root package name */
    public static final y f22151c = new y("LONG_OR_DOUBLE", 2) { // from class: lg.y.c
        {
            a aVar = null;
        }

        @Override // lg.z
        public Number a(tg.a aVar) {
            String N = aVar.N();
            if (N.indexOf(46) >= 0) {
                return c(N, aVar);
            }
            try {
                return Long.valueOf(Long.parseLong(N));
            } catch (NumberFormatException unused) {
                return c(N, aVar);
            }
        }

        public final Number c(String str, tg.a aVar) {
            try {
                Double valueOf = Double.valueOf(str);
                if (!valueOf.isInfinite()) {
                    if (valueOf.isNaN()) {
                    }
                    return valueOf;
                }
                if (!aVar.r()) {
                    throw new tg.d("JSON forbids NaN and infinities: " + valueOf + "; at path " + aVar.n());
                }
                return valueOf;
            } catch (NumberFormatException e10) {
                throw new p("Cannot parse " + str + "; at path " + aVar.n(), e10);
            }
        }
    };

    /* renamed from: d, reason: collision with root package name */
    public static final y f22152d = new y("BIG_DECIMAL", 3) { // from class: lg.y.d
        {
            a aVar = null;
        }

        @Override // lg.z
        /* renamed from: c, reason: merged with bridge method [inline-methods] */
        public BigDecimal a(tg.a aVar) {
            String N = aVar.N();
            try {
                return c0.b(N);
            } catch (NumberFormatException e10) {
                throw new p("Cannot parse " + N + "; at path " + aVar.n(), e10);
            }
        }
    };

    /* renamed from: e, reason: collision with root package name */
    public static final /* synthetic */ y[] f22153e = b();

    public static class a extends y {
        public a(String str, int i10) {
            super(str, i10, null);
        }

        @Override // lg.z
        /* renamed from: c, reason: merged with bridge method [inline-methods] */
        public Double a(tg.a aVar) {
            return Double.valueOf(aVar.y());
        }
    }

    public y(String str, int i10) {
    }

    public static /* synthetic */ y[] b() {
        return new y[]{f22150a, b, f22151c, f22152d};
    }

    public static y valueOf(String str) {
        return (y) Enum.valueOf(y.class, str);
    }

    public static y[] values() {
        return (y[]) f22153e.clone();
    }

    public /* synthetic */ y(String str, int i10, a aVar) {
        this(str, i10);
    }
}
