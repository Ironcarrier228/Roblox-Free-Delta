package w4;

import android.R;

/* loaded from: classes.dex */
public final class c {

    /* renamed from: a, reason: collision with root package name */
    public static int[] f35569a = {android.R.attr.orientation, android.R.attr.clipToPadding, android.R.attr.descendantFocusability, com.roblox.client.personasdk.R.attr.fastScrollEnabled, com.roblox.client.personasdk.R.attr.fastScrollHorizontalThumbDrawable, com.roblox.client.personasdk.R.attr.fastScrollHorizontalTrackDrawable, com.roblox.client.personasdk.R.attr.fastScrollVerticalThumbDrawable, com.roblox.client.personasdk.R.attr.fastScrollVerticalTrackDrawable, com.roblox.client.personasdk.R.attr.layoutManager, com.roblox.client.personasdk.R.attr.reverseLayout, com.roblox.client.personasdk.R.attr.spanCount, com.roblox.client.personasdk.R.attr.stackFromEnd};
    public static int b = 0;

    /* renamed from: c, reason: collision with root package name */
    public static int f35570c = 1;

    /* renamed from: d, reason: collision with root package name */
    public static int f35571d = 2;

    /* renamed from: e, reason: collision with root package name */
    public static int f35572e = 3;

    /* renamed from: f, reason: collision with root package name */
    public static int f35573f = 4;

    /* renamed from: g, reason: collision with root package name */
    public static int f35574g = 5;

    /* renamed from: h, reason: collision with root package name */
    public static int f35575h = 6;

    /* renamed from: i, reason: collision with root package name */
    public static int f35576i = 7;

    /* renamed from: j, reason: collision with root package name */
    public static int f35577j = 8;

    /* renamed from: k, reason: collision with root package name */
    public static int f35578k = 9;

    /* renamed from: l, reason: collision with root package name */
    public static int f35579l = 10;

    /* renamed from: m, reason: collision with root package name */
    public static int f35580m = 11;
}
