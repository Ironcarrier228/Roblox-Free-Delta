package ch;

import av.g1;
import av.l0;
import av.m0;
import av.p0;
import av.q0;
import av.x;
import av.z2;

import com.github.luben.zstd.BuildConfig;
import com.roblox.protocols.nativeadsplatforminterface.generated.INativeAdsCoreListener;
import com.roblox.protocols.nativeadsplatforminterface.generated.IPlatformNativeAds;
import com.roblox.protocols.nativeadsplatforminterface.generated.LoadAdFailureReason;
import com.roblox.universalapp.ads.NoopGmaSdkController;
import im.GetQueryInfoError;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.function.BiConsumer;
import jm.NativeAdsProgressData;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.coroutines.CoroutineContext;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.json.JSONException;
import org.json.JSONObject;
import zt.n;

@Metadata(d1 = {"\u0000\u0088\u0001\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010\u0002\n\u0002\b\u0004\n\u0002\u0010\u000b\n\u0002\b\u0003\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0012\n\u0002\u0010\t\n\u0002\b\u000b\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u000b\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0005\u0018\u0000 ]2\u00020\u0001:\u0001KB=\u0012\u0006\u0010\u0003\u001a\u00020\u0002\u0012\b\b\u0002\u0010\u0005\u001a\u00020\u0004\u0012\b\b\u0002\u0010\u0007\u001a\u00020\u0006\u0012\u0018\b\u0002\u0010\n\u001a\u0012\u0012\u0006\u0012\u0004\u0018\u00010\u0000\u0012\u0006\u0012\u0004\u0018\u00010\t0\b¢\u0006\u0004\b\u000b\u0010\fJ\u0015\u0010\u000f\u001a\u00020\u000e2\u0006\u0010\r\u001a\u00020\u0004¢\u0006\u0004\b\u000f\u0010\u0010J\r\u0010\u0011\u001a\u00020\u000e¢\u0006\u0004\b\u0011\u0010\u0012J\u0017\u0010\u0015\u001a\u00020\u000e2\u0006\u0010\u0014\u001a\u00020\u0013H\u0016¢\u0006\u0004\b\u0015\u0010\u0016J\u001f\u0010\u001b\u001a\u00020\u000e2\u0006\u0010\u0018\u001a\u00020\u00172\u0006\u0010\u001a\u001a\u00020\u0019H\u0016¢\u0006\u0004\b\u001b\u0010\u001cJ\u001f\u0010\u001f\u001a\u00020\u000e2\u0006\u0010\u001d\u001a\u00020\u00192\u0006\u0010\u001e\u001a\u00020\u0019H\u0016¢\u0006\u0004\b\u001f\u0010 J\u001f\u0010#\u001a\u00020\u000e2\u0006\u0010!\u001a\u00020\u00192\u0006\u0010\"\u001a\u00020\u0019H\u0016¢\u0006\u0004\b#\u0010 J\u001f\u0010%\u001a\u00020\u000e2\u0006\u0010!\u001a\u00020\u00192\u0006\u0010$\u001a\u00020\u0019H\u0016¢\u0006\u0004\b%\u0010 J\u0017\u0010&\u001a\u00020\u000e2\u0006\u0010!\u001a\u00020\u0019H\u0016¢\u0006\u0004\b&\u0010'J/\u0010(\u001a\u00020\u000e2\u0006\u0010\u0018\u001a\u00020\u00172\u0006\u0010!\u001a\u00020\u00192\u0006\u0010\"\u001a\u00020\u00192\u0006\u0010\u001a\u001a\u00020\u0019H\u0016¢\u0006\u0004\b(\u0010)Jg\u00103\u001a\u00020\u000e2\u0006\u0010\u0018\u001a\u00020\u00172\u0006\u0010!\u001a\u00020\u00192\u0006\u0010\"\u001a\u00020\u00192\u0006\u0010*\u001a\u00020\u00192\u0006\u0010+\u001a\u00020\u00192\u0006\u0010-\u001a\u00020,2\u0006\u0010.\u001a\u00020\u00132\u0006\u0010/\u001a\u00020\u00192\u0006\u00100\u001a\u00020\u00192\u0006\u00101\u001a\u00020\u00192\u0006\u00102\u001a\u00020\u0013H\u0016¢\u0006\u0004\b3\u00104J\u001f\u00105\u001a\u00020\u000e2\u0006\u0010\u0018\u001a\u00020\u00172\u0006\u0010!\u001a\u00020\u0019H\u0016¢\u0006\u0004\b5\u0010\u001cJ\u000f\u00106\u001a\u00020\u000eH\u0016¢\u0006\u0004\b6\u0010\u0012J\u0017\u00107\u001a\u00020\u000e2\u0006\u0010!\u001a\u00020\u0019H\u0016¢\u0006\u0004\b7\u0010'J[\u0010>\u001a\u00020\u000e2\u0006\u00109\u001a\u0002082\u0006\u0010!\u001a\u00020\u00192\u0006\u0010\"\u001a\u00020\u00192\u0012\u0010:\u001a\u000e\u0012\u0004\u0012\u00020\u0019\u0012\u0004\u0012\u00020\u000e0\b2\u001e\u0010=\u001a\u001a\u0012\u0004\u0012\u00020\u0019\u0012\u0004\u0012\u00020<\u0012\u0004\u0012\u00020\u0019\u0012\u0004\u0012\u00020\u000e0;H\u0002¢\u0006\u0004\b>\u0010?J.\u0010B\u001a\b\u0012\u0004\u0012\u00020\u00190A2\u0006\u00109\u001a\u0002082\u0006\u0010!\u001a\u00020\u00192\u0006\u0010@\u001a\u00020\u0019H\u0082@¢\u0006\u0004\bB\u0010CJ-\u0010G\u001a\u00020\u000e2\u001c\u0010F\u001a\u0018\b\u0001\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u000e0D\u0012\u0006\u0012\u0004\u0018\u00010E0\bH\u0002¢\u0006\u0004\bG\u0010HR\u0014\u0010\u0003\u001a\u00020\u00028\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\bI\u0010JR\u0016\u0010\u0005\u001a\u00020\u00048\u0002@\u0002X\u0082\u000e¢\u0006\u0006\n\u0004\bK\u0010LR\u0014\u0010\u0007\u001a\u00020\u00068\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\bM\u0010NR$\u0010\n\u001a\u0012\u0012\u0006\u0012\u0004\u0018\u00010\u0000\u0012\u0006\u0012\u0004\u0018\u00010\t0\b8\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\bO\u0010PR\u0014\u0010T\u001a\u00020Q8\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\bR\u0010SR\u0018\u0010W\u001a\u0004\u0018\u00010\t8\u0002@\u0002X\u0082\u000e¢\u0006\u0006\n\u0004\bU\u0010VR,\u0010\\\u001a\u001a\u0012\u0004\u0012\u00020\u0019\u0012\u0010\u0012\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00190A0Y0X8\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\bZ\u0010[¨\u0006^"}, d2 = {"Lch/i;", "Lcom/roblox/protocols/nativeadsplatforminterface/generated/IPlatformNativeAds;", "Lhm/i;", "moduleInstaller", "Lhm/c;", "gmaSdkController", "Lav/p0;", "scope", "Lkotlin/Function1;", "Lcom/roblox/protocols/nativeadsplatforminterface/generated/INativeAdsCoreListener;", "setPlatformImpl", "<init>", "(Lhm/i;Lhm/c;Lav/p0;Lkotlin/jvm/functions/Function1;)V", "controller", BuildConfig.FLAVOR, "n", "(Lhm/c;)V", "i", "()V", BuildConfig.FLAVOR, "eagerInstall", "install", "(Z)V", BuildConfig.FLAVOR, "id", BuildConfig.FLAVOR, "experimentVariant", "initialize", "(ILjava/lang/String;)V", "requestId", "initializeAdUnitId", "initializeSdk", "(Ljava/lang/String;Ljava/lang/String;)V", "adTracingId", "adUnitId", "loadInterstitialAd", "adResponseJson", "onServeInterstitialAdResponse", "onServeInterstitialAdFailed", "(Ljava/lang/String;)V", "getQueryInfo", "(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;)V", "adString", "durationNeededEnum", BuildConfig.FLAVOR, "durationNeededForRewardMs", "isEuUser", "creativeUrl", "uiExperimentData", "gmaAdType", "isClickable", "setAdString", "(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;JZLjava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)V", "showAd", "cleanupAd", "destroyInterstitialAd", "Lhm/a;", "adFormat", "onSuccess", "Lkotlin/Function3;", "Lcom/roblox/protocols/nativeadsplatforminterface/generated/LoadAdFailureReason;", "onFailure", "k", "(Lhm/a;Ljava/lang/String;Ljava/lang/String;Lkotlin/jvm/functions/Function1;Lpu/n;)V", "queryInfo", "Lzt/n;", "o", "(Lhm/a;Ljava/lang/String;Ljava/lang/String;Leu/b;)Ljava/lang/Object;", "Leu/b;", BuildConfig.FLAVOR, "block", "j", "(Lkotlin/jvm/functions/Function1;)V", xe.a.f36648e, "Lhm/i;", k6.b.f21144e, "Lhm/c;", "c", "Lav/p0;", "d", "Lkotlin/jvm/functions/Function1;", "Ljava/util/concurrent/atomic/AtomicBoolean;", "e", "Ljava/util/concurrent/atomic/AtomicBoolean;", "cleanedUp", "f", "Lcom/roblox/protocols/nativeadsplatforminterface/generated/INativeAdsCoreListener;", "nativeAdsCore", "Ljava/util/concurrent/ConcurrentHashMap;", "Lav/x;", "g", "Ljava/util/concurrent/ConcurrentHashMap;", "pendingServeAds", "h", "NativeShell_googleProdRelease"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* loaded from: classes2.dex */
public final class i extends IPlatformNativeAds {

    /* renamed from: a, reason: collision with root package name and from kotlin metadata */
    @NotNull
    public final hm.i moduleInstaller;

    /* renamed from: b, reason: from kotlin metadata */
    @NotNull
    public volatile hm.c gmaSdkController;

    /* renamed from: c, reason: collision with root package name and from kotlin metadata */
    @NotNull
    public final p0 scope;

    /* renamed from: d, reason: collision with root package name and from kotlin metadata */
    @NotNull
    public final Function1<i, INativeAdsCoreListener> setPlatformImpl;

    /* renamed from: e, reason: collision with root package name and from kotlin metadata */
    @NotNull
    public final AtomicBoolean cleanedUp;

    /* renamed from: f, reason: collision with root package name and from kotlin metadata */
    @Nullable
    public INativeAdsCoreListener nativeAdsCore;

    /* renamed from: g, reason: collision with root package name and from kotlin metadata */
    @NotNull
    public final ConcurrentHashMap<String, x<zt.n<String>>> pendingServeAds;

    @Metadata(k = 3, mv = {2, 2, 0}, xi = 48)
    public static final /* synthetic */ class a extends kotlin.jvm.internal.k implements Function1<IPlatformNativeAds, INativeAdsCoreListener> {

        /* renamed from: a, reason: collision with root package name */
        public static final a f5161a = new a();

        public a() {
            super(1, INativeAdsCoreListener.class, "setPlatformImpl", "setPlatformImpl(Lcom/roblox/protocols/nativeadsplatforminterface/generated/IPlatformNativeAds;)Lcom/roblox/protocols/nativeadsplatforminterface/generated/INativeAdsCoreListener;", 0);
        }

        @Override // kotlin.jvm.functions.Function1
        /* renamed from: d, reason: merged with bridge method [inline-methods] */
        public final INativeAdsCoreListener invoke(IPlatformNativeAds iPlatformNativeAds) {
            return INativeAdsCoreListener.setPlatformImpl(iPlatformNativeAds);
        }
    }

    @Metadata(k = 3, mv = {2, 2, 0}, xi = 48)
    public static final /* synthetic */ class c {

        /* renamed from: a, reason: collision with root package name */
        public static final /* synthetic */ int[] f5162a;

        static {
            int[] iArr = new int[hm.a.values().length];
            try {
                iArr[hm.a.f18276d.ordinal()] = 1;
            } catch (NoSuchFieldError unused) {
            }
            try {
                iArr[hm.a.f18275c.ordinal()] = 2;
            } catch (NoSuchFieldError unused2) {
            }
            f5162a = iArr;
        }
    }

    @Metadata(d1 = {"\u0000\u0006\n\u0000\n\u0002\u0010\u0002\u0010\u0000\u001a\u00020\u0001H\n"}, d2 = {"<anonymous>", BuildConfig.FLAVOR}, k = 3, mv = {2, 2, 0}, xi = 48)
    @gu.f(c = "com.roblox.client.ads.NativeAdsHandler$cleanupAd$1", f = "NativeAdsHandler.kt", l = {}, m = "invokeSuspend", v = 1)
    public static final class d extends gu.m implements Function1<eu.b<? super Unit>, Object> {

        /* renamed from: t, reason: collision with root package name */
        public int f5163t;

        public d(eu.b<? super d> bVar) {
            super(1, bVar);
        }

        @Override // gu.a
        public final eu.b<Unit> create(eu.b<?> bVar) {
            return i.this.new d(bVar);
        }

        @Override // gu.a
        public final Object invokeSuspend(Object obj) {
            fu.c.e();
            if (this.f5163t != 0) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            zt.o.b(obj);
            i.this.gmaSdkController.f();
            return Unit.f21504a;
        }

        @Override // kotlin.jvm.functions.Function1
        /* renamed from: m, reason: merged with bridge method [inline-methods] */
        public final Object invoke(eu.b<? super Unit> bVar) {
            return ((d) create(bVar)).invokeSuspend(Unit.f21504a);
        }
    }

    @Metadata(d1 = {"\u0000\u0006\n\u0000\n\u0002\u0010\u0002\u0010\u0000\u001a\u00020\u0001H\n"}, d2 = {"<anonymous>", BuildConfig.FLAVOR}, k = 3, mv = {2, 2, 0}, xi = 48)
    @gu.f(c = "com.roblox.client.ads.NativeAdsHandler$destroyInterstitialAd$1", f = "NativeAdsHandler.kt", l = {438}, m = "invokeSuspend", v = 1)
    public static final class e extends gu.m implements Function1<eu.b<? super Unit>, Object> {

        /* renamed from: t, reason: collision with root package name */
        public int f5165t;

        /* renamed from: v, reason: collision with root package name */
        public final /* synthetic */ String f5167v;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public e(String str, eu.b<? super e> bVar) {
            super(1, bVar);
            this.f5167v = str;
        }

        @Override // gu.a
        public final eu.b<Unit> create(eu.b<?> bVar) {
            return i.this.new e(this.f5167v, bVar);
        }

        @Override // gu.a
        public final Object invokeSuspend(Object obj) {
            Object e10 = fu.c.e();
            int i10 = this.f5165t;
            if (i10 == 0) {
                zt.o.b(obj);
                hm.c cVar = i.this.gmaSdkController;
                hm.a aVar = hm.a.f18276d;
                String str = this.f5167v;
                this.f5165t = 1;
                if (cVar.a(aVar, str, this) == e10) {
                    return e10;
                }
            } else {
                if (i10 != 1) {
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                zt.o.b(obj);
            }
            return Unit.f21504a;
        }

        @Override // kotlin.jvm.functions.Function1
        /* renamed from: m, reason: merged with bridge method [inline-methods] */
        public final Object invoke(eu.b<? super Unit> bVar) {
            return ((e) create(bVar)).invokeSuspend(Unit.f21504a);
        }
    }

    @Metadata(d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0002\b\u0002\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\n¢\u0006\u0004\b\u0002\u0010\u0003"}, d2 = {"Lav/p0;", BuildConfig.FLAVOR, "<anonymous>", "(Lav/p0;)V"}, k = 3, mv = {2, 2, 0})
    @gu.f(c = "com.roblox.client.ads.NativeAdsHandler$enqueue$1", f = "NativeAdsHandler.kt", l = {448}, m = "invokeSuspend", v = 1)
    public static final class f extends gu.m implements Function2<p0, eu.b<? super Unit>, Object> {

        /* renamed from: t, reason: collision with root package name */
        public int f5168t;

        /* renamed from: u, reason: collision with root package name */
        public final /* synthetic */ Function1<eu.b<? super Unit>, Object> f5169u;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        /* JADX WARN: Multi-variable type inference failed */
        public f(Function1<? super eu.b<? super Unit>, ? extends Object> function1, eu.b<? super f> bVar) {
            super(2, bVar);
            this.f5169u = function1;
        }

        @Override // gu.a
        public final eu.b<Unit> create(Object obj, eu.b<?> bVar) {
            return new f(this.f5169u, bVar);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(p0 p0Var, eu.b<? super Unit> bVar) {
            return ((f) create(p0Var, bVar)).invokeSuspend(Unit.f21504a);
        }

        @Override // gu.a
        public final Object invokeSuspend(Object obj) {
            Object e10 = fu.c.e();
            int i10 = this.f5168t;
            if (i10 == 0) {
                zt.o.b(obj);
                Function1<eu.b<? super Unit>, Object> function1 = this.f5169u;
                this.f5168t = 1;
                if (function1.invoke(this) == e10) {
                    return e10;
                }
            } else {
                if (i10 != 1) {
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                zt.o.b(obj);
            }
            return Unit.f21504a;
        }
    }

    @Metadata(d1 = {"\u0000\u0006\n\u0000\n\u0002\u0010\u0002\u0010\u0000\u001a\u00020\u0001H\n"}, d2 = {"<anonymous>", BuildConfig.FLAVOR}, k = 3, mv = {2, 2, 0}, xi = 48)
    @gu.f(c = "com.roblox.client.ads.NativeAdsHandler$getQueryInfo$1", f = "NativeAdsHandler.kt", l = {}, m = "invokeSuspend", v = 1)
    public static final class g extends gu.m implements Function1<eu.b<? super Unit>, Object> {

        /* renamed from: t, reason: collision with root package name */
        public int f5170t;

        /* renamed from: u, reason: collision with root package name */
        public final /* synthetic */ String f5171u;

        /* renamed from: v, reason: collision with root package name */
        public final /* synthetic */ String f5172v;

        /* renamed from: w, reason: collision with root package name */
        public final /* synthetic */ i f5173w;

        /* renamed from: x, reason: collision with root package name */
        public final /* synthetic */ int f5174x;

        /* renamed from: y, reason: collision with root package name */
        public final /* synthetic */ String f5175y;

        @Metadata(d1 = {"\u0000\u001f\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0004*\u0001\u0000\b\n\u0018\u00002\u00020\u0001J\u0019\u0010\u0005\u001a\u00020\u00042\b\u0010\u0003\u001a\u0004\u0018\u00010\u0002H\u0016¢\u0006\u0004\b\u0005\u0010\u0006J\u0017\u0010\t\u001a\u00020\u00042\u0006\u0010\b\u001a\u00020\u0007H\u0016¢\u0006\u0004\b\t\u0010\n¨\u0006\u000b"}, d2 = {"ch/i$g$a", "Lhm/j;", BuildConfig.FLAVOR, "queryInfo", BuildConfig.FLAVOR, "onSuccess", "(Ljava/lang/String;)V", "Lim/a;", "error", xe.a.f36648e, "(Lim/a;)V", "NativeShell_googleProdRelease"}, k = 1, mv = {2, 2, 0}, xi = 48)
        public static final class a implements hm.j {

            /* renamed from: a, reason: collision with root package name */
            public final /* synthetic */ i f5176a;
            public final /* synthetic */ boolean b;

            /* renamed from: c, reason: collision with root package name */
            public final /* synthetic */ int f5177c;

            @Metadata(d1 = {"\u0000\u0006\n\u0000\n\u0002\u0010\u0002\u0010\u0000\u001a\u00020\u0001H\n"}, d2 = {"<anonymous>", BuildConfig.FLAVOR}, k = 3, mv = {2, 2, 0}, xi = 48)
            @gu.f(c = "com.roblox.client.ads.NativeAdsHandler$getQueryInfo$1$1$onFailure$1", f = "NativeAdsHandler.kt", l = {}, m = "invokeSuspend", v = 1)
            /* renamed from: ch.i$g$a$a, reason: collision with other inner class name */
            public static final class C0104a extends gu.m implements Function1<eu.b<? super Unit>, Object> {

                /* renamed from: t, reason: collision with root package name */
                public int f5178t;

                /* renamed from: u, reason: collision with root package name */
                public final /* synthetic */ boolean f5179u;

                /* renamed from: v, reason: collision with root package name */
                public final /* synthetic */ GetQueryInfoError f5180v;

                /* renamed from: w, reason: collision with root package name */
                public final /* synthetic */ i f5181w;

                /* renamed from: x, reason: collision with root package name */
                public final /* synthetic */ int f5182x;

                /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                public C0104a(boolean z10, GetQueryInfoError getQueryInfoError, i iVar, int i10, eu.b<? super C0104a> bVar) {
                    super(1, bVar);
                    this.f5179u = z10;
                    this.f5180v = getQueryInfoError;
                    this.f5181w = iVar;
                    this.f5182x = i10;
                }

                @Override // gu.a
                public final eu.b<Unit> create(eu.b<?> bVar) {
                    return new C0104a(this.f5179u, this.f5180v, this.f5181w, this.f5182x, bVar);
                }

                @Override // gu.a
                public final Object invokeSuspend(Object obj) {
                    fu.c.e();
                    if (this.f5178t != 0) {
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                    zt.o.b(obj);
                    if (this.f5179u) {
                        ch.b bVar = ch.b.f5131c;
                        String message = this.f5180v.getMessage();
                        if (message == null) {
                            message = "UNKNOWN";
                        }
                        ch.l.e(bVar, message);
                    }
                    INativeAdsCoreListener iNativeAdsCoreListener = this.f5181w.nativeAdsCore;
                    if (iNativeAdsCoreListener != null) {
                        iNativeAdsCoreListener.onGetQueryInfoCompleted(this.f5182x, BuildConfig.FLAVOR);
                    }
                    return Unit.f21504a;
                }

                @Override // kotlin.jvm.functions.Function1
                /* renamed from: m, reason: merged with bridge method [inline-methods] */
                public final Object invoke(eu.b<? super Unit> bVar) {
                    return ((C0104a) create(bVar)).invokeSuspend(Unit.f21504a);
                }
            }

            @Metadata(d1 = {"\u0000\u0006\n\u0000\n\u0002\u0010\u0002\u0010\u0000\u001a\u00020\u0001H\n"}, d2 = {"<anonymous>", BuildConfig.FLAVOR}, k = 3, mv = {2, 2, 0}, xi = 48)
            @gu.f(c = "com.roblox.client.ads.NativeAdsHandler$getQueryInfo$1$1$onSuccess$1", f = "NativeAdsHandler.kt", l = {}, m = "invokeSuspend", v = 1)
            public static final class b extends gu.m implements Function1<eu.b<? super Unit>, Object> {

                /* renamed from: t, reason: collision with root package name */
                public int f5183t;

                /* renamed from: u, reason: collision with root package name */
                public final /* synthetic */ boolean f5184u;

                /* renamed from: v, reason: collision with root package name */
                public final /* synthetic */ i f5185v;

                /* renamed from: w, reason: collision with root package name */
                public final /* synthetic */ int f5186w;

                /* renamed from: x, reason: collision with root package name */
                public final /* synthetic */ String f5187x;

                /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                public b(boolean z10, i iVar, int i10, String str, eu.b<? super b> bVar) {
                    super(1, bVar);
                    this.f5184u = z10;
                    this.f5185v = iVar;
                    this.f5186w = i10;
                    this.f5187x = str;
                }

                @Override // gu.a
                public final eu.b<Unit> create(eu.b<?> bVar) {
                    return new b(this.f5184u, this.f5185v, this.f5186w, this.f5187x, bVar);
                }

                @Override // gu.a
                public final Object invokeSuspend(Object obj) {
                    fu.c.e();
                    if (this.f5183t != 0) {
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                    zt.o.b(obj);
                    if (this.f5184u) {
                        ch.l.e(ch.b.f5131c, "success");
                    }
                    INativeAdsCoreListener iNativeAdsCoreListener = this.f5185v.nativeAdsCore;
                    if (iNativeAdsCoreListener != null) {
                        int i10 = this.f5186w;
                        String str = this.f5187x;
                        if (str == null) {
                            str = BuildConfig.FLAVOR;
                        }
                        iNativeAdsCoreListener.onGetQueryInfoCompleted(i10, str);
                    }
                    return Unit.f21504a;
                }

                @Override // kotlin.jvm.functions.Function1
                /* renamed from: m, reason: merged with bridge method [inline-methods] */
                public final Object invoke(eu.b<? super Unit> bVar) {
                    return ((b) create(bVar)).invokeSuspend(Unit.f21504a);
                }
            }

            public a(i iVar, boolean z10, int i10) {
                this.f5176a = iVar;
                this.b = z10;
                this.f5177c = i10;
            }

            @Override // hm.j
            public void a(GetQueryInfoError error) {
                Intrinsics.checkNotNullParameter(error, "error");
                i iVar = this.f5176a;
                iVar.j(new C0104a(this.b, error, iVar, this.f5177c, null));
            }

            @Override // hm.j
            public void onSuccess(String queryInfo) {
                i iVar = this.f5176a;
                iVar.j(new b(this.b, iVar, this.f5177c, queryInfo, null));
            }
        }

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public g(String str, String str2, i iVar, int i10, String str3, eu.b<? super g> bVar) {
            super(1, bVar);
            this.f5171u = str;
            this.f5172v = str2;
            this.f5173w = iVar;
            this.f5174x = i10;
            this.f5175y = str3;
        }

        @Override // gu.a
        public final eu.b<Unit> create(eu.b<?> bVar) {
            return new g(this.f5171u, this.f5172v, this.f5173w, this.f5174x, this.f5175y, bVar);
        }

        @Override // gu.a
        public final Object invokeSuspend(Object obj) {
            fu.c.e();
            if (this.f5170t != 0) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            zt.o.b(obj);
            boolean z10 = Intrinsics.c(this.f5171u, "IsolatedRewarded") || Intrinsics.c(this.f5171u, "NonIsolatedRewarded");
            if (z10) {
                ch.l.f(b.b, null, 2, null);
            }
            if (this.f5172v.length() != 0) {
                this.f5173w.gmaSdkController.d(this.f5172v, this.f5175y, this.f5171u, new a(this.f5173w, z10, this.f5174x));
                return Unit.f21504a;
            }
            if (z10) {
                ch.l.e(b.f5131c, "MISSING_AD_TRACING_ID");
            }
            INativeAdsCoreListener iNativeAdsCoreListener = this.f5173w.nativeAdsCore;
            if (iNativeAdsCoreListener != null) {
                iNativeAdsCoreListener.onGetQueryInfoCompleted(this.f5174x, BuildConfig.FLAVOR);
            }
            return Unit.f21504a;
        }

        @Override // kotlin.jvm.functions.Function1
        /* renamed from: m, reason: merged with bridge method [inline-methods] */
        public final Object invoke(eu.b<? super Unit> bVar) {
            return ((g) create(bVar)).invokeSuspend(Unit.f21504a);
        }
    }

    @Metadata(d1 = {"\u0000\u0006\n\u0000\n\u0002\u0010\u0002\u0010\u0000\u001a\u00020\u0001H\n"}, d2 = {"<anonymous>", BuildConfig.FLAVOR}, k = 3, mv = {2, 2, 0}, xi = 48)
    @gu.f(c = "com.roblox.client.ads.NativeAdsHandler$initialize$1", f = "NativeAdsHandler.kt", l = {}, m = "invokeSuspend", v = 1)
    public static final class h extends gu.m implements Function1<eu.b<? super Unit>, Object> {

        /* renamed from: t, reason: collision with root package name */
        public int f5188t;

        /* renamed from: v, reason: collision with root package name */
        public final /* synthetic */ String f5190v;

        /* renamed from: w, reason: collision with root package name */
        public final /* synthetic */ int f5191w;

        @Metadata(d1 = {"\u0000\u0006\n\u0000\n\u0002\u0010\u0002\u0010\u0000\u001a\u00020\u0001H\n"}, d2 = {"<anonymous>", BuildConfig.FLAVOR}, k = 3, mv = {2, 2, 0}, xi = 48)
        @gu.f(c = "com.roblox.client.ads.NativeAdsHandler$initialize$1$1$1", f = "NativeAdsHandler.kt", l = {}, m = "invokeSuspend", v = 1)
        public static final class a extends gu.m implements Function1<eu.b<? super Unit>, Object> {

            /* renamed from: t, reason: collision with root package name */
            public int f5192t;

            /* renamed from: u, reason: collision with root package name */
            public final /* synthetic */ i f5193u;

            /* renamed from: v, reason: collision with root package name */
            public final /* synthetic */ int f5194v;

            /* renamed from: w, reason: collision with root package name */
            public final /* synthetic */ Boolean f5195w;

            /* renamed from: x, reason: collision with root package name */
            public final /* synthetic */ String f5196x;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            public a(i iVar, int i10, Boolean bool, String str, eu.b<? super a> bVar) {
                super(1, bVar);
                this.f5193u = iVar;
                this.f5194v = i10;
                this.f5195w = bool;
                this.f5196x = str;
            }

            @Override // gu.a
            public final eu.b<Unit> create(eu.b<?> bVar) {
                return new a(this.f5193u, this.f5194v, this.f5195w, this.f5196x, bVar);
            }

            @Override // gu.a
            public final Object invokeSuspend(Object obj) {
                fu.c.e();
                if (this.f5192t != 0) {
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                zt.o.b(obj);
                INativeAdsCoreListener iNativeAdsCoreListener = this.f5193u.nativeAdsCore;
                if (iNativeAdsCoreListener != null) {
                    int i10 = this.f5194v;
                    Boolean bool = this.f5195w;
                    Intrinsics.checkNotNull(bool);
                    iNativeAdsCoreListener.onInitializeCompleted(i10, bool.booleanValue(), this.f5196x);
                }
                return Unit.f21504a;
            }

            @Override // kotlin.jvm.functions.Function1
            /* renamed from: m, reason: merged with bridge method [inline-methods] */
            public final Object invoke(eu.b<? super Unit> bVar) {
                return ((a) create(bVar)).invokeSuspend(Unit.f21504a);
            }
        }

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public h(String str, int i10, eu.b<? super h> bVar) {
            super(1, bVar);
            this.f5190v = str;
            this.f5191w = i10;
        }

        public static final void q(i iVar, int i10, Boolean bool, String str) {
            iVar.j(new a(iVar, i10, bool, str, null));
        }

        @Override // gu.a
        public final eu.b<Unit> create(eu.b<?> bVar) {
            return i.this.new h(this.f5190v, this.f5191w, bVar);
        }

        @Override // gu.a
        public final Object invokeSuspend(Object obj) {
            fu.c.e();
            if (this.f5188t != 0) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            zt.o.b(obj);
            hm.c cVar = i.this.gmaSdkController;
            String str = this.f5190v;
            final i iVar = i.this;
            final int i10 = this.f5191w;
            cVar.i(str, new BiConsumer() { // from class: ch.j
                @Override // java.util.function.BiConsumer
                public final void accept(Object obj2, Object obj3) {
                    i.h.q(i.this, i10, (Boolean) obj2, (String) obj3);
                }
            });
            return Unit.f21504a;
        }

        @Override // kotlin.jvm.functions.Function1
        /* renamed from: p, reason: merged with bridge method [inline-methods] */
        public final Object invoke(eu.b<? super Unit> bVar) {
            return ((h) create(bVar)).invokeSuspend(Unit.f21504a);
        }
    }

    @Metadata(d1 = {"\u0000\u0006\n\u0000\n\u0002\u0010\u0002\u0010\u0000\u001a\u00020\u0001H\n"}, d2 = {"<anonymous>", BuildConfig.FLAVOR}, k = 3, mv = {2, 2, 0}, xi = 48)
    @gu.f(c = "com.roblox.client.ads.NativeAdsHandler$initializeSdk$1", f = "NativeAdsHandler.kt", l = {185, 198}, m = "invokeSuspend", v = 1)
    /* renamed from: ch.i$i, reason: collision with other inner class name */
    public static final class C0105i extends gu.m implements Function1<eu.b<? super Unit>, Object> {

        /* renamed from: t, reason: collision with root package name */
        public int f5197t;

        /* renamed from: v, reason: collision with root package name */
        public final /* synthetic */ String f5199v;

        /* renamed from: w, reason: collision with root package name */
        public final /* synthetic */ String f5200w;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public C0105i(String str, String str2, eu.b<? super C0105i> bVar) {
            super(1, bVar);
            this.f5199v = str;
            this.f5200w = str2;
        }

        @Override // gu.a
        public final eu.b<Unit> create(eu.b<?> bVar) {
            return i.this.new C0105i(this.f5199v, this.f5200w, bVar);
        }

        /* JADX WARN: Code restructure failed: missing block: B:44:0x0056, code lost:
        
            if (r5.b(r1, r4) == r0) goto L27;
         */
        /* JADX WARN: Code restructure failed: missing block: B:48:0x0085, code lost:
        
            if (r5 == r0) goto L27;
         */
        /* JADX WARN: Removed duplicated region for block: B:34:0x006b  */
        @Override // gu.a
        /*
            Code decompiled incorrectly, please refer to instructions dump.
            To view partially-correct add '--show-bad-code' argument
        */
        public final java.lang.Object invokeSuspend(java.lang.Object r5) {
            /*
                r4 = this;
                java.lang.Object r0 = fu.c.e()
                int r1 = r4.f5197t
                r2 = 2
                r3 = 1
                if (r1 == 0) goto L24
                if (r1 == r3) goto L20
                if (r1 != r2) goto L18
                zt.o.b(r5)
                zt.n r5 = (zt.n) r5
                java.lang.Object r5 = r5.getValue()
                goto L88
            L18:
                java.lang.IllegalStateException r5 = new java.lang.IllegalStateException
                java.lang.String r0 = "call to 'resume' before 'invoke' with coroutine"
                r5.<init>(r0)
                throw r5
            L20:
                zt.o.b(r5)
                goto L63
            L24:
                zt.o.b(r5)
                ch.i r5 = ch.i.this
                hm.c r5 = ch.i.d(r5)
                boolean r5 = r5 instanceof com.roblox.universalapp.ads.NoopGmaSdkController
                if (r5 == 0) goto L77
                boolean r5 = com.roblox.universalapp.ads.JNINativeAdsProtocol.getGmaSdkBackgroundInstallIxpEnabled()
                if (r5 != 0) goto L63
                java.lang.String r5 = "NativeAdsHandler"
                java.lang.String r1 = "gmasdk is not installed, trigger the installation"
                ok.q.h(r5, r1)
                bi.i r5 = bi.h.a()
                boolean r5 = r5.q1()
                if (r5 == 0) goto L59
                ch.i r5 = ch.i.this
                hm.i r5 = ch.i.e(r5)
                hm.i$a r1 = hm.i.a.b
                r4.f5197t = r3
                java.lang.Object r5 = r5.b(r1, r4)
                if (r5 != r0) goto L63
                goto L87
            L59:
                ch.i r5 = ch.i.this
                hm.i r5 = ch.i.e(r5)
                r0 = 0
                r5.a(r0)
            L63:
                ch.i r5 = ch.i.this
                com.roblox.protocols.nativeadsplatforminterface.generated.INativeAdsCoreListener r5 = ch.i.f(r5)
                if (r5 == 0) goto L74
                java.lang.String r0 = r4.f5199v
                com.roblox.protocols.nativeadsplatforminterface.generated.InitializeSdkFailureReason r1 = com.roblox.protocols.nativeadsplatforminterface.generated.InitializeSdkFailureReason.NOTINSTALLED
                java.lang.String r2 = "gmasdk module not installed"
                r5.onInitializeSdkFailed(r0, r1, r2)
            L74:
                kotlin.Unit r5 = kotlin.Unit.f21504a
                return r5
            L77:
                ch.i r5 = ch.i.this
                hm.c r5 = ch.i.d(r5)
                java.lang.String r1 = r4.f5200w
                r4.f5197t = r2
                java.lang.Object r5 = r5.c(r1, r4)
                if (r5 != r0) goto L88
            L87:
                return r0
            L88:
                ch.i r0 = ch.i.this
                java.lang.String r1 = r4.f5199v
                boolean r2 = zt.n.h(r5)
                if (r2 == 0) goto L9e
                r2 = r5
                kotlin.Unit r2 = (kotlin.Unit) r2
                com.roblox.protocols.nativeadsplatforminterface.generated.INativeAdsCoreListener r0 = ch.i.f(r0)
                if (r0 == 0) goto L9e
                r0.onInitializeSdkSuccess(r1)
            L9e:
                ch.i r0 = ch.i.this
                java.lang.String r1 = r4.f5199v
                java.lang.Throwable r5 = zt.n.e(r5)
                if (r5 == 0) goto Lc9
                boolean r2 = r5 instanceof hm.b
                if (r2 == 0) goto Laf
                com.roblox.protocols.nativeadsplatforminterface.generated.InitializeSdkFailureReason r2 = com.roblox.protocols.nativeadsplatforminterface.generated.InitializeSdkFailureReason.NATIVESHUTTINGDOWN
                goto Lb8
            Laf:
                boolean r2 = r5 instanceof av.e3
                if (r2 == 0) goto Lb6
                com.roblox.protocols.nativeadsplatforminterface.generated.InitializeSdkFailureReason r2 = com.roblox.protocols.nativeadsplatforminterface.generated.InitializeSdkFailureReason.TIMEDOUT
                goto Lb8
            Lb6:
                com.roblox.protocols.nativeadsplatforminterface.generated.InitializeSdkFailureReason r2 = com.roblox.protocols.nativeadsplatforminterface.generated.InitializeSdkFailureReason.UNDEFINED
            Lb8:
                com.roblox.protocols.nativeadsplatforminterface.generated.INativeAdsCoreListener r0 = ch.i.f(r0)
                if (r0 == 0) goto Lc9
                java.lang.String r5 = r5.getMessage()
                if (r5 != 0) goto Lc6
                java.lang.String r5 = ""
            Lc6:
                r0.onInitializeSdkFailed(r1, r2, r5)
            Lc9:
                kotlin.Unit r5 = kotlin.Unit.f21504a
                return r5
            */
            throw new UnsupportedOperationException("Method not decompiled: ch.i.C0105i.invokeSuspend(java.lang.Object):java.lang.Object");
        }

        @Override // kotlin.jvm.functions.Function1
        /* renamed from: m, reason: merged with bridge method [inline-methods] */
        public final Object invoke(eu.b<? super Unit> bVar) {
            return ((C0105i) create(bVar)).invokeSuspend(Unit.f21504a);
        }
    }

    @Metadata(d1 = {"\u0000\u0006\n\u0000\n\u0002\u0010\u0002\u0010\u0000\u001a\u00020\u0001H\n"}, d2 = {"<anonymous>", BuildConfig.FLAVOR}, k = 3, mv = {2, 2, 0}, xi = 48)
    @gu.f(c = "com.roblox.client.ads.NativeAdsHandler$install$1", f = "NativeAdsHandler.kt", l = {157, 159}, m = "invokeSuspend", v = 1)
    public static final class j extends gu.m implements Function1<eu.b<? super Unit>, Object> {

        /* renamed from: t, reason: collision with root package name */
        public int f5201t;

        /* renamed from: u, reason: collision with root package name */
        public final /* synthetic */ boolean f5202u;

        /* renamed from: v, reason: collision with root package name */
        public final /* synthetic */ i f5203v;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public j(boolean z10, i iVar, eu.b<? super j> bVar) {
            super(1, bVar);
            this.f5202u = z10;
            this.f5203v = iVar;
        }

        @Override // gu.a
        public final eu.b<Unit> create(eu.b<?> bVar) {
            return new j(this.f5202u, this.f5203v, bVar);
        }

        /* JADX WARN: Code restructure failed: missing block: B:18:0x0054, code lost:
        
            if (r6.b(r1, r5) == r0) goto L21;
         */
        /* JADX WARN: Code restructure failed: missing block: B:19:0x0067, code lost:
        
            return r0;
         */
        /* JADX WARN: Code restructure failed: missing block: B:21:0x0065, code lost:
        
            if (r6.b(r1, r5) == r0) goto L21;
         */
        @Override // gu.a
        /*
            Code decompiled incorrectly, please refer to instructions dump.
            To view partially-correct add '--show-bad-code' argument
        */
        public final java.lang.Object invokeSuspend(java.lang.Object r6) {
            /*
                r5 = this;
                java.lang.Object r0 = fu.c.e()
                int r1 = r5.f5201t
                r2 = 2
                r3 = 1
                if (r1 == 0) goto L1b
                if (r1 == r3) goto L17
                if (r1 != r2) goto Lf
                goto L17
            Lf:
                java.lang.IllegalStateException r6 = new java.lang.IllegalStateException
                java.lang.String r0 = "call to 'resume' before 'invoke' with coroutine"
                r6.<init>(r0)
                throw r6
            L17:
                zt.o.b(r6)
                goto L73
            L1b:
                zt.o.b(r6)
                boolean r6 = com.roblox.universalapp.ads.JNINativeAdsProtocol.getGmaSdkBackgroundInstallIxpEnabled()
                if (r6 == 0) goto L68
                boolean r6 = ai.h.y()
                if (r6 == 0) goto L68
                boolean r6 = r5.f5202u
                java.lang.StringBuilder r1 = new java.lang.StringBuilder
                r1.<init>()
                java.lang.String r4 = "engine triggered gmasdk install, eager install: "
                r1.append(r4)
                r1.append(r6)
                java.lang.String r6 = r1.toString()
                java.lang.String r1 = "NativeAdsHandler"
                ok.q.h(r1, r6)
                boolean r6 = r5.f5202u
                if (r6 == 0) goto L57
                ch.i r6 = r5.f5203v
                hm.i r6 = ch.i.e(r6)
                hm.i$a r1 = hm.i.a.b
                r5.f5201t = r3
                java.lang.Object r6 = r6.b(r1, r5)
                if (r6 != r0) goto L73
                goto L67
            L57:
                ch.i r6 = r5.f5203v
                hm.i r6 = ch.i.e(r6)
                hm.i$a r1 = hm.i.a.f18291a
                r5.f5201t = r2
                java.lang.Object r6 = r6.b(r1, r5)
                if (r6 != r0) goto L73
            L67:
                return r0
            L68:
                ch.i r6 = r5.f5203v
                hm.i r6 = ch.i.e(r6)
                boolean r0 = r5.f5202u
                r6.a(r0)
            L73:
                kotlin.Unit r6 = kotlin.Unit.f21504a
                return r6
            */
            throw new UnsupportedOperationException("Method not decompiled: ch.i.j.invokeSuspend(java.lang.Object):java.lang.Object");
        }

        @Override // kotlin.jvm.functions.Function1
        /* renamed from: m, reason: merged with bridge method [inline-methods] */
        public final Object invoke(eu.b<? super Unit> bVar) {
            return ((j) create(bVar)).invokeSuspend(Unit.f21504a);
        }
    }

    @Metadata(d1 = {"\u0000\u0006\n\u0000\n\u0002\u0010\u0002\u0010\u0000\u001a\u00020\u0001H\n"}, d2 = {"<anonymous>", BuildConfig.FLAVOR}, k = 3, mv = {2, 2, 0}, xi = 48)
    @gu.f(c = "com.roblox.client.ads.NativeAdsHandler$loadAd$1", f = "NativeAdsHandler.kt", l = {235}, m = "invokeSuspend", v = 1)
    public static final class k extends gu.m implements Function1<eu.b<? super Unit>, Object> {

        /* renamed from: t, reason: collision with root package name */
        public int f5204t;

        /* renamed from: u, reason: collision with root package name */
        public final /* synthetic */ String f5205u;

        /* renamed from: v, reason: collision with root package name */
        public final /* synthetic */ pu.n<String, LoadAdFailureReason, String, Unit> f5206v;

        /* renamed from: w, reason: collision with root package name */
        public final /* synthetic */ i f5207w;

        /* renamed from: x, reason: collision with root package name */
        public final /* synthetic */ hm.a f5208x;

        /* renamed from: y, reason: collision with root package name */
        public final /* synthetic */ String f5209y;

        /* renamed from: z, reason: collision with root package name */
        public final /* synthetic */ Function1<String, Unit> f5210z;

        @Metadata(d1 = {"\u0000\u000e\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\u0010\u0003\u001a\b\u0012\u0004\u0012\u00020\u00000\u00022\u0006\u0010\u0001\u001a\u00020\u0000H\n¢\u0006\u0004\b\u0003\u0010\u0004"}, d2 = {BuildConfig.FLAVOR, "queryInfo", "Lzt/n;", "<anonymous>", "(Ljava/lang/String;)Lzt/n;"}, k = 3, mv = {2, 2, 0})
        @gu.f(c = "com.roblox.client.ads.NativeAdsHandler$loadAd$1$1", f = "NativeAdsHandler.kt", l = {236}, m = "invokeSuspend", v = 1)
        public static final class a extends gu.m implements Function2<String, eu.b<? super zt.n<? extends String>>, Object> {

            /* renamed from: t, reason: collision with root package name */
            public int f5211t;

            /* renamed from: u, reason: collision with root package name */
            public /* synthetic */ Object f5212u;

            /* renamed from: v, reason: collision with root package name */
            public final /* synthetic */ i f5213v;

            /* renamed from: w, reason: collision with root package name */
            public final /* synthetic */ hm.a f5214w;

            /* renamed from: x, reason: collision with root package name */
            public final /* synthetic */ String f5215x;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            public a(i iVar, hm.a aVar, String str, eu.b<? super a> bVar) {
                super(2, bVar);
                this.f5213v = iVar;
                this.f5214w = aVar;
                this.f5215x = str;
            }

            @Override // gu.a
            public final eu.b<Unit> create(Object obj, eu.b<?> bVar) {
                a aVar = new a(this.f5213v, this.f5214w, this.f5215x, bVar);
                aVar.f5212u = obj;
                return aVar;
            }

            @Override // gu.a
            public final Object invokeSuspend(Object obj) {
                Object o10;
                String str = (String) this.f5212u;
                Object e10 = fu.c.e();
                int i10 = this.f5211t;
                if (i10 == 0) {
                    zt.o.b(obj);
                    i iVar = this.f5213v;
                    hm.a aVar = this.f5214w;
                    String str2 = this.f5215x;
                    this.f5212u = gu.l.a(str);
                    this.f5211t = 1;
                    o10 = iVar.o(aVar, str2, str, this);
                    if (o10 == e10) {
                        return e10;
                    }
                } else {
                    if (i10 != 1) {
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                    zt.o.b(obj);
                    o10 = ((zt.n) obj).getValue();
                }
                return zt.n.a(o10);
            }

            @Override // kotlin.jvm.functions.Function2
            /* renamed from: m, reason: merged with bridge method [inline-methods] */
            public final Object invoke(String str, eu.b<? super zt.n<String>> bVar) {
                return ((a) create(str, bVar)).invokeSuspend(Unit.f21504a);
            }
        }

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        /* JADX WARN: Multi-variable type inference failed */
        public k(String str, pu.n<? super String, ? super LoadAdFailureReason, ? super String, Unit> nVar, i iVar, hm.a aVar, String str2, Function1<? super String, Unit> function1, eu.b<? super k> bVar) {
            super(1, bVar);
            this.f5205u = str;
            this.f5206v = nVar;
            this.f5207w = iVar;
            this.f5208x = aVar;
            this.f5209y = str2;
            this.f5210z = function1;
        }

        @Override // gu.a
        public final eu.b<Unit> create(eu.b<?> bVar) {
            return new k(this.f5205u, this.f5206v, this.f5207w, this.f5208x, this.f5209y, this.f5210z, bVar);
        }

        @Override // gu.a
        public final Object invokeSuspend(Object obj) {
            k kVar;
            Object g10;
            LoadAdFailureReason a10;
            Object e10 = fu.c.e();
            int i10 = this.f5204t;
            if (i10 == 0) {
                zt.o.b(obj);
                if (this.f5205u.length() == 0) {
                    this.f5206v.invoke(this.f5205u, LoadAdFailureReason.ADTRACINGIDABSENT, "adTracingId is empty");
                    return Unit.f21504a;
                }
                hm.c cVar = this.f5207w.gmaSdkController;
                hm.a aVar = this.f5208x;
                String str = this.f5205u;
                String str2 = this.f5209y;
                a aVar2 = new a(this.f5207w, aVar, str, null);
                this.f5204t = 1;
                kVar = this;
                g10 = cVar.g(aVar, str, str2, aVar2, kVar);
                if (g10 == e10) {
                    return e10;
                }
            } else {
                if (i10 != 1) {
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                zt.o.b(obj);
                g10 = ((zt.n) obj).getValue();
                kVar = this;
            }
            Function1<String, Unit> function1 = kVar.f5210z;
            String str3 = kVar.f5205u;
            if (zt.n.h(g10)) {
                function1.invoke(str3);
            }
            pu.n<String, LoadAdFailureReason, String, Unit> nVar = kVar.f5206v;
            String str4 = kVar.f5205u;
            Throwable e11 = zt.n.e(g10);
            if (e11 != null) {
                if (e11 instanceof hm.b) {
                    a10 = LoadAdFailureReason.NATIVESHUTTINGDOWN;
                } else {
                    hm.e eVar = e11 instanceof hm.e ? (hm.e) e11 : null;
                    a10 = hm.h.a(eVar != null ? eVar.getReason() : null);
                }
                String message = e11.getMessage();
                if (message == null) {
                    message = BuildConfig.FLAVOR;
                }
                nVar.invoke(str4, a10, message);
            }
            return Unit.f21504a;
        }

        @Override // kotlin.jvm.functions.Function1
        /* renamed from: m, reason: merged with bridge method [inline-methods] */
        public final Object invoke(eu.b<? super Unit> bVar) {
            return ((k) create(bVar)).invokeSuspend(Unit.f21504a);
        }
    }

    @Metadata(d1 = {"\u0000\u0006\n\u0000\n\u0002\u0010\u0002\u0010\u0000\u001a\u00020\u0001H\n"}, d2 = {"<anonymous>", BuildConfig.FLAVOR}, k = 3, mv = {2, 2, 0}, xi = 48)
    @gu.f(c = "com.roblox.client.ads.NativeAdsHandler$replaceNoopGmaSdkController$1", f = "NativeAdsHandler.kt", l = {}, m = "invokeSuspend", v = 1)
    public static final class l extends gu.m implements Function1<eu.b<? super Unit>, Object> {

        /* renamed from: t, reason: collision with root package name */
        public int f5216t;

        /* renamed from: v, reason: collision with root package name */
        public final /* synthetic */ hm.c f5218v;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public l(hm.c cVar, eu.b<? super l> bVar) {
            super(1, bVar);
            this.f5218v = cVar;
        }

        @Override // gu.a
        public final eu.b<Unit> create(eu.b<?> bVar) {
            return i.this.new l(this.f5218v, bVar);
        }

        @Override // gu.a
        public final Object invokeSuspend(Object obj) {
            fu.c.e();
            if (this.f5216t != 0) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            zt.o.b(obj);
            i.this.gmaSdkController = this.f5218v;
            return Unit.f21504a;
        }

        @Override // kotlin.jvm.functions.Function1
        /* renamed from: m, reason: merged with bridge method [inline-methods] */
        public final Object invoke(eu.b<? super Unit> bVar) {
            return ((l) create(bVar)).invokeSuspend(Unit.f21504a);
        }
    }

    @Metadata(k = 3, mv = {2, 2, 0}, xi = 48)
    @gu.f(c = "com.roblox.client.ads.NativeAdsHandler", f = "NativeAdsHandler.kt", l = {273}, m = "serveAd-BWLJW6A", v = 1)
    public static final class m extends gu.d {
        public int B;

        /* renamed from: t, reason: collision with root package name */
        public Object f5219t;

        /* renamed from: u, reason: collision with root package name */
        public Object f5220u;

        /* renamed from: v, reason: collision with root package name */
        public Object f5221v;

        /* renamed from: w, reason: collision with root package name */
        public Object f5222w;

        /* renamed from: x, reason: collision with root package name */
        public Object f5223x;

        /* renamed from: y, reason: collision with root package name */
        public Object f5224y;

        /* renamed from: z, reason: collision with root package name */
        public /* synthetic */ Object f5225z;

        public m(eu.b<? super m> bVar) {
            super(bVar);
        }

        @Override // gu.a
        @Nullable
        public final Object invokeSuspend(@NotNull Object obj) {
            this.f5225z = obj;
            this.B |= Integer.MIN_VALUE;
            Object o10 = i.this.o(null, null, null, this);
            return o10 == fu.c.e() ? o10 : zt.n.a(o10);
        }
    }

    @Metadata(d1 = {"\u0000\u0010\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u000e\n\u0002\b\u0002\u0010\u0003\u001a\b\u0012\u0004\u0012\u00020\u00020\u0001*\u00020\u0000H\n¢\u0006\u0004\b\u0003\u0010\u0004"}, d2 = {"Lav/p0;", "Lzt/n;", BuildConfig.FLAVOR, "<anonymous>", "(Lav/p0;)Lzt/n;"}, k = 3, mv = {2, 2, 0})
    @gu.f(c = "com.roblox.client.ads.NativeAdsHandler$serveAd$2", f = "NativeAdsHandler.kt", l = {274}, m = "invokeSuspend", v = 1)
    public static final class n extends gu.m implements Function2<p0, eu.b<? super zt.n<? extends String>>, Object> {

        /* renamed from: t, reason: collision with root package name */
        public int f5226t;

        /* renamed from: u, reason: collision with root package name */
        public final /* synthetic */ x<zt.n<String>> f5227u;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public n(x<zt.n<String>> xVar, eu.b<? super n> bVar) {
            super(2, bVar);
            this.f5227u = xVar;
        }

        @Override // gu.a
        public final eu.b<Unit> create(Object obj, eu.b<?> bVar) {
            return new n(this.f5227u, bVar);
        }

        /* renamed from: invoke, reason: avoid collision after fix types in other method */
        public final Object invoke2(p0 p0Var, eu.b<? super zt.n<String>> bVar) {
            return ((n) create(p0Var, bVar)).invokeSuspend(Unit.f21504a);
        }

        @Override // gu.a
        public final Object invokeSuspend(Object obj) {
            Object e10 = fu.c.e();
            int i10 = this.f5226t;
            if (i10 != 0) {
                if (i10 != 1) {
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                zt.o.b(obj);
                return obj;
            }
            zt.o.b(obj);
            x<zt.n<String>> xVar = this.f5227u;
            this.f5226t = 1;
            Object y10 = xVar.y(this);
            return y10 == e10 ? e10 : y10;
        }

        @Override // kotlin.jvm.functions.Function2
        public /* bridge */ /* synthetic */ Object invoke(p0 p0Var, eu.b<? super zt.n<? extends String>> bVar) {
            return invoke2(p0Var, (eu.b<? super zt.n<String>>) bVar);
        }
    }

    @Metadata(d1 = {"\u0000\u0006\n\u0000\n\u0002\u0010\u0002\u0010\u0000\u001a\u00020\u0001H\n"}, d2 = {"<anonymous>", BuildConfig.FLAVOR}, k = 3, mv = {2, 2, 0}, xi = 48)
    @gu.f(c = "com.roblox.client.ads.NativeAdsHandler$setAdString$1", f = "NativeAdsHandler.kt", l = {}, m = "invokeSuspend", v = 1)
    public static final class o extends gu.m implements Function1<eu.b<? super Unit>, Object> {
        public final /* synthetic */ String A;
        public final /* synthetic */ String B;
        public final /* synthetic */ boolean C;
        public final /* synthetic */ String D;
        public final /* synthetic */ String E;
        public final /* synthetic */ String F;

        /* renamed from: t, reason: collision with root package name */
        public int f5228t;

        /* renamed from: u, reason: collision with root package name */
        public final /* synthetic */ String f5229u;

        /* renamed from: v, reason: collision with root package name */
        public final /* synthetic */ i f5230v;

        /* renamed from: w, reason: collision with root package name */
        public final /* synthetic */ int f5231w;

        /* renamed from: x, reason: collision with root package name */
        public final /* synthetic */ long f5232x;

        /* renamed from: y, reason: collision with root package name */
        public final /* synthetic */ String f5233y;

        /* renamed from: z, reason: collision with root package name */
        public final /* synthetic */ boolean f5234z;

        @Metadata(d1 = {"\u0000\u0019\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\b\u0004*\u0001\u0000\b\n\u0018\u00002\u00020\u0001J\u000f\u0010\u0003\u001a\u00020\u0002H\u0016¢\u0006\u0004\b\u0003\u0010\u0004J\u0017\u0010\u0007\u001a\u00020\u00022\u0006\u0010\u0006\u001a\u00020\u0005H\u0016¢\u0006\u0004\b\u0007\u0010\b¨\u0006\t"}, d2 = {"ch/i$o$a", "Lhm/f;", BuildConfig.FLAVOR, "onSuccess", "()V", BuildConfig.FLAVOR, "errorMessage", "onFailure", "(Ljava/lang/String;)V", "NativeShell_googleProdRelease"}, k = 1, mv = {2, 2, 0}, xi = 48)
        public static final class a implements hm.f {

            /* renamed from: a, reason: collision with root package name */
            public final /* synthetic */ i f5235a;
            public final /* synthetic */ int b;

            @Metadata(d1 = {"\u0000\u0006\n\u0000\n\u0002\u0010\u0002\u0010\u0000\u001a\u00020\u0001H\n"}, d2 = {"<anonymous>", BuildConfig.FLAVOR}, k = 3, mv = {2, 2, 0}, xi = 48)
            @gu.f(c = "com.roblox.client.ads.NativeAdsHandler$setAdString$1$1$onFailure$1", f = "NativeAdsHandler.kt", l = {}, m = "invokeSuspend", v = 1)
            /* renamed from: ch.i$o$a$a, reason: collision with other inner class name */
            public static final class C0106a extends gu.m implements Function1<eu.b<? super Unit>, Object> {

                /* renamed from: t, reason: collision with root package name */
                public int f5236t;

                /* renamed from: u, reason: collision with root package name */
                public final /* synthetic */ i f5237u;

                /* renamed from: v, reason: collision with root package name */
                public final /* synthetic */ int f5238v;

                /* renamed from: w, reason: collision with root package name */
                public final /* synthetic */ String f5239w;

                /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                public C0106a(i iVar, int i10, String str, eu.b<? super C0106a> bVar) {
                    super(1, bVar);
                    this.f5237u = iVar;
                    this.f5238v = i10;
                    this.f5239w = str;
                }

                @Override // gu.a
                public final eu.b<Unit> create(eu.b<?> bVar) {
                    return new C0106a(this.f5237u, this.f5238v, this.f5239w, bVar);
                }

                @Override // gu.a
                public final Object invokeSuspend(Object obj) {
                    fu.c.e();
                    if (this.f5236t != 0) {
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                    zt.o.b(obj);
                    INativeAdsCoreListener iNativeAdsCoreListener = this.f5237u.nativeAdsCore;
                    if (iNativeAdsCoreListener != null) {
                        iNativeAdsCoreListener.onSetAdStringCompleted(this.f5238v, false, this.f5239w);
                    }
                    return Unit.f21504a;
                }

                @Override // kotlin.jvm.functions.Function1
                /* renamed from: m, reason: merged with bridge method [inline-methods] */
                public final Object invoke(eu.b<? super Unit> bVar) {
                    return ((C0106a) create(bVar)).invokeSuspend(Unit.f21504a);
                }
            }

            @Metadata(d1 = {"\u0000\u0006\n\u0000\n\u0002\u0010\u0002\u0010\u0000\u001a\u00020\u0001H\n"}, d2 = {"<anonymous>", BuildConfig.FLAVOR}, k = 3, mv = {2, 2, 0}, xi = 48)
            @gu.f(c = "com.roblox.client.ads.NativeAdsHandler$setAdString$1$1$onSuccess$1", f = "NativeAdsHandler.kt", l = {}, m = "invokeSuspend", v = 1)
            public static final class b extends gu.m implements Function1<eu.b<? super Unit>, Object> {

                /* renamed from: t, reason: collision with root package name */
                public int f5240t;

                /* renamed from: u, reason: collision with root package name */
                public final /* synthetic */ i f5241u;

                /* renamed from: v, reason: collision with root package name */
                public final /* synthetic */ int f5242v;

                /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                public b(i iVar, int i10, eu.b<? super b> bVar) {
                    super(1, bVar);
                    this.f5241u = iVar;
                    this.f5242v = i10;
                }

                @Override // gu.a
                public final eu.b<Unit> create(eu.b<?> bVar) {
                    return new b(this.f5241u, this.f5242v, bVar);
                }

                @Override // gu.a
                public final Object invokeSuspend(Object obj) {
                    fu.c.e();
                    if (this.f5240t != 0) {
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                    zt.o.b(obj);
                    INativeAdsCoreListener iNativeAdsCoreListener = this.f5241u.nativeAdsCore;
                    if (iNativeAdsCoreListener != null) {
                        iNativeAdsCoreListener.onSetAdStringCompleted(this.f5242v, true, BuildConfig.FLAVOR);
                    }
                    return Unit.f21504a;
                }

                @Override // kotlin.jvm.functions.Function1
                /* renamed from: m, reason: merged with bridge method [inline-methods] */
                public final Object invoke(eu.b<? super Unit> bVar) {
                    return ((b) create(bVar)).invokeSuspend(Unit.f21504a);
                }
            }

            public a(i iVar, int i10) {
                this.f5235a = iVar;
                this.b = i10;
            }

            @Override // hm.f
            public void onFailure(String errorMessage) {
                Intrinsics.checkNotNullParameter(errorMessage, "errorMessage");
                i iVar = this.f5235a;
                iVar.j(new C0106a(iVar, this.b, errorMessage, null));
            }

            @Override // hm.f
            public void onSuccess() {
                i iVar = this.f5235a;
                iVar.j(new b(iVar, this.b, null));
            }
        }

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public o(String str, i iVar, int i10, long j10, String str2, boolean z10, String str3, String str4, boolean z11, String str5, String str6, String str7, eu.b<? super o> bVar) {
            super(1, bVar);
            this.f5229u = str;
            this.f5230v = iVar;
            this.f5231w = i10;
            this.f5232x = j10;
            this.f5233y = str2;
            this.f5234z = z10;
            this.A = str3;
            this.B = str4;
            this.C = z11;
            this.D = str5;
            this.E = str6;
            this.F = str7;
        }

        @Override // gu.a
        public final eu.b<Unit> create(eu.b<?> bVar) {
            return new o(this.f5229u, this.f5230v, this.f5231w, this.f5232x, this.f5233y, this.f5234z, this.A, this.B, this.C, this.D, this.E, this.F, bVar);
        }

        @Override // gu.a
        public final Object invokeSuspend(Object obj) {
            fu.c.e();
            if (this.f5228t != 0) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            zt.o.b(obj);
            if (this.f5229u.length() == 0) {
                INativeAdsCoreListener iNativeAdsCoreListener = this.f5230v.nativeAdsCore;
                if (iNativeAdsCoreListener != null) {
                    iNativeAdsCoreListener.onSetAdStringCompleted(this.f5231w, false, "adTracingId is empty");
                }
                return Unit.f21504a;
            }
            try {
                JSONObject jSONObject = new JSONObject();
                long j10 = this.f5232x;
                String str = this.f5233y;
                boolean z10 = this.f5234z;
                String str2 = this.A;
                String str3 = this.B;
                boolean z11 = this.C;
                String str4 = this.D;
                String str5 = this.E;
                String str6 = this.F;
                jSONObject.put("durationNeededForRewardMs", j10);
                jSONObject.put("durationNeededEnum", str);
                jSONObject.put("isEUUser", z10);
                jSONObject.put("moderationExternalCreativeUrl", str2);
                jSONObject.put("gmaAdType", str3);
                jSONObject.put("isClickable", z11);
                jSONObject.put("uiExperimentData", new JSONObject(str4));
                jSONObject.put("adString", str5);
                jSONObject.put("adUnitId", str6);
                this.f5230v.gmaSdkController.j(this.f5229u, jSONObject, new a(this.f5230v, this.f5231w));
                return Unit.f21504a;
            } catch (JSONException e10) {
                INativeAdsCoreListener iNativeAdsCoreListener2 = this.f5230v.nativeAdsCore;
                if (iNativeAdsCoreListener2 != null) {
                    iNativeAdsCoreListener2.onSetAdStringCompleted(this.f5231w, false, "setAdString failed to construct JSON - " + e10);
                }
                return Unit.f21504a;
            }
        }

        @Override // kotlin.jvm.functions.Function1
        /* renamed from: m, reason: merged with bridge method [inline-methods] */
        public final Object invoke(eu.b<? super Unit> bVar) {
            return ((o) create(bVar)).invokeSuspend(Unit.f21504a);
        }
    }

    @Metadata(d1 = {"\u0000\u0006\n\u0000\n\u0002\u0010\u0002\u0010\u0000\u001a\u00020\u0001H\n"}, d2 = {"<anonymous>", BuildConfig.FLAVOR}, k = 3, mv = {2, 2, 0}, xi = 48)
    @gu.f(c = "com.roblox.client.ads.NativeAdsHandler$showAd$1", f = "NativeAdsHandler.kt", l = {}, m = "invokeSuspend", v = 1)
    public static final class p extends gu.m implements Function1<eu.b<? super Unit>, Object> {

        /* renamed from: t, reason: collision with root package name */
        public int f5243t;

        /* renamed from: u, reason: collision with root package name */
        public final /* synthetic */ String f5244u;

        /* renamed from: v, reason: collision with root package name */
        public final /* synthetic */ i f5245v;

        /* renamed from: w, reason: collision with root package name */
        public final /* synthetic */ int f5246w;

        @Metadata(d1 = {"\u00003\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0007\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\b*\u0001\u0000\b\n\u0018\u00002\u00020\u0001J\u001f\u0010\u0007\u001a\u00020\u00062\u0006\u0010\u0003\u001a\u00020\u00022\u0006\u0010\u0005\u001a\u00020\u0004H\u0016¢\u0006\u0004\b\u0007\u0010\bJ!\u0010\r\u001a\u00020\u00062\b\u0010\n\u001a\u0004\u0018\u00010\t2\u0006\u0010\f\u001a\u00020\u000bH\u0016¢\u0006\u0004\b\r\u0010\u000eJ\u0017\u0010\u0011\u001a\u00020\u00062\u0006\u0010\u0010\u001a\u00020\u000fH\u0016¢\u0006\u0004\b\u0011\u0010\u0012J\u001f\u0010\u0015\u001a\u00020\u00062\u0006\u0010\u0013\u001a\u00020\t2\u0006\u0010\u0014\u001a\u00020\tH\u0016¢\u0006\u0004\b\u0015\u0010\u0016¨\u0006\u0017"}, d2 = {"ch/i$p$a", "Lhm/k;", "Ljm/c;", "status", BuildConfig.FLAVOR, "watchDuration", BuildConfig.FLAVOR, "d", "(Ljm/c;F)V", BuildConfig.FLAVOR, "gmaAdType", BuildConfig.FLAVOR, "isEndCardVisible", "c", "(Ljava/lang/String;Z)V", "Ljm/b;", "progressData", xe.a.f36648e, "(Ljm/b;)V", "reasonKey", "description", k6.b.f21144e, "(Ljava/lang/String;Ljava/lang/String;)V", "NativeShell_googleProdRelease"}, k = 1, mv = {2, 2, 0}, xi = 48)
        public static final class a implements hm.k {

            /* renamed from: a, reason: collision with root package name */
            public final /* synthetic */ i f5247a;
            public final /* synthetic */ int b;

            @Metadata(d1 = {"\u0000\u0006\n\u0000\n\u0002\u0010\u0002\u0010\u0000\u001a\u00020\u0001H\n"}, d2 = {"<anonymous>", BuildConfig.FLAVOR}, k = 3, mv = {2, 2, 0}, xi = 48)
            @gu.f(c = "com.roblox.client.ads.NativeAdsHandler$showAd$1$1$onAdProgress$1", f = "NativeAdsHandler.kt", l = {}, m = "invokeSuspend", v = 1)
            /* renamed from: ch.i$p$a$a, reason: collision with other inner class name */
            public static final class C0107a extends gu.m implements Function1<eu.b<? super Unit>, Object> {

                /* renamed from: t, reason: collision with root package name */
                public int f5248t;

                /* renamed from: u, reason: collision with root package name */
                public final /* synthetic */ i f5249u;

                /* renamed from: v, reason: collision with root package name */
                public final /* synthetic */ NativeAdsProgressData f5250v;

                /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                public C0107a(i iVar, NativeAdsProgressData nativeAdsProgressData, eu.b<? super C0107a> bVar) {
                    super(1, bVar);
                    this.f5249u = iVar;
                    this.f5250v = nativeAdsProgressData;
                }

                @Override // gu.a
                public final eu.b<Unit> create(eu.b<?> bVar) {
                    return new C0107a(this.f5249u, this.f5250v, bVar);
                }

                @Override // gu.a
                public final Object invokeSuspend(Object obj) {
                    fu.c.e();
                    if (this.f5248t != 0) {
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                    zt.o.b(obj);
                    INativeAdsCoreListener iNativeAdsCoreListener = this.f5249u.nativeAdsCore;
                    if (iNativeAdsCoreListener != null) {
                        iNativeAdsCoreListener.onAdProgress((float) this.f5250v.getAdProgress(), (float) this.f5250v.getVideoDuration(), this.f5250v.getPrice(), this.f5250v.getPricePrecisionType(), this.f5250v.getPriceCurrencyCode());
                    }
                    return Unit.f21504a;
                }

                @Override // kotlin.jvm.functions.Function1
                /* renamed from: m, reason: merged with bridge method [inline-methods] */
                public final Object invoke(eu.b<? super Unit> bVar) {
                    return ((C0107a) create(bVar)).invokeSuspend(Unit.f21504a);
                }
            }

            @Metadata(d1 = {"\u0000\u0006\n\u0000\n\u0002\u0010\u0002\u0010\u0000\u001a\u00020\u0001H\n"}, d2 = {"<anonymous>", BuildConfig.FLAVOR}, k = 3, mv = {2, 2, 0}, xi = 48)
            @gu.f(c = "com.roblox.client.ads.NativeAdsHandler$showAd$1$1$onCtaClicked$1", f = "NativeAdsHandler.kt", l = {}, m = "invokeSuspend", v = 1)
            public static final class b extends gu.m implements Function1<eu.b<? super Unit>, Object> {

                /* renamed from: t, reason: collision with root package name */
                public int f5251t;

                /* renamed from: u, reason: collision with root package name */
                public final /* synthetic */ String f5252u;

                /* renamed from: v, reason: collision with root package name */
                public final /* synthetic */ i f5253v;

                /* renamed from: w, reason: collision with root package name */
                public final /* synthetic */ boolean f5254w;

                /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                public b(String str, i iVar, boolean z10, eu.b<? super b> bVar) {
                    super(1, bVar);
                    this.f5252u = str;
                    this.f5253v = iVar;
                    this.f5254w = z10;
                }

                @Override // gu.a
                public final eu.b<Unit> create(eu.b<?> bVar) {
                    return new b(this.f5252u, this.f5253v, this.f5254w, bVar);
                }

                @Override // gu.a
                public final Object invokeSuspend(Object obj) {
                    fu.c.e();
                    if (this.f5251t != 0) {
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                    zt.o.b(obj);
                    ok.q.h("NativeAdsHandler", "cta clicked");
                    String str = this.f5252u;
                    if (str == null) {
                        ok.q.e("NativeAdsHandler", "Invalid ad type, cannot log click");
                        return Unit.f21504a;
                    }
                    String str2 = Intrinsics.c(str, "AppPromo") ? "AppPromo" : "ClickOut";
                    INativeAdsCoreListener iNativeAdsCoreListener = this.f5253v.nativeAdsCore;
                    if (iNativeAdsCoreListener != null) {
                        iNativeAdsCoreListener.onCtaClick(str2, this.f5254w);
                    }
                    return Unit.f21504a;
                }

                @Override // kotlin.jvm.functions.Function1
                /* renamed from: m, reason: merged with bridge method [inline-methods] */
                public final Object invoke(eu.b<? super Unit> bVar) {
                    return ((b) create(bVar)).invokeSuspend(Unit.f21504a);
                }
            }

            @Metadata(d1 = {"\u0000\u0006\n\u0000\n\u0002\u0010\u0002\u0010\u0000\u001a\u00020\u0001H\n"}, d2 = {"<anonymous>", BuildConfig.FLAVOR}, k = 3, mv = {2, 2, 0}, xi = 48)
            @gu.f(c = "com.roblox.client.ads.NativeAdsHandler$showAd$1$1$onPlayBackEnded$1", f = "NativeAdsHandler.kt", l = {}, m = "invokeSuspend", v = 1)
            public static final class c extends gu.m implements Function1<eu.b<? super Unit>, Object> {

                /* renamed from: t, reason: collision with root package name */
                public int f5255t;

                /* renamed from: u, reason: collision with root package name */
                public final /* synthetic */ i f5256u;

                /* renamed from: v, reason: collision with root package name */
                public final /* synthetic */ int f5257v;

                /* renamed from: w, reason: collision with root package name */
                public final /* synthetic */ jm.c f5258w;

                /* renamed from: x, reason: collision with root package name */
                public final /* synthetic */ float f5259x;

                /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                public c(i iVar, int i10, jm.c cVar, float f10, eu.b<? super c> bVar) {
                    super(1, bVar);
                    this.f5256u = iVar;
                    this.f5257v = i10;
                    this.f5258w = cVar;
                    this.f5259x = f10;
                }

                @Override // gu.a
                public final eu.b<Unit> create(eu.b<?> bVar) {
                    return new c(this.f5256u, this.f5257v, this.f5258w, this.f5259x, bVar);
                }

                @Override // gu.a
                public final Object invokeSuspend(Object obj) {
                    fu.c.e();
                    if (this.f5255t != 0) {
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                    zt.o.b(obj);
                    INativeAdsCoreListener iNativeAdsCoreListener = this.f5256u.nativeAdsCore;
                    if (iNativeAdsCoreListener != null) {
                        iNativeAdsCoreListener.onShowAdCompleted(this.f5257v, this.f5258w.getValue(), this.f5259x);
                    }
                    return Unit.f21504a;
                }

                @Override // kotlin.jvm.functions.Function1
                /* renamed from: m, reason: merged with bridge method [inline-methods] */
                public final Object invoke(eu.b<? super Unit> bVar) {
                    return ((c) create(bVar)).invokeSuspend(Unit.f21504a);
                }
            }

            @Metadata(d1 = {"\u0000\u0006\n\u0000\n\u0002\u0010\u0002\u0010\u0000\u001a\u00020\u0001H\n"}, d2 = {"<anonymous>", BuildConfig.FLAVOR}, k = 3, mv = {2, 2, 0}, xi = 48)
            @gu.f(c = "com.roblox.client.ads.NativeAdsHandler$showAd$1$1$onUserReportAd$1", f = "NativeAdsHandler.kt", l = {}, m = "invokeSuspend", v = 1)
            public static final class d extends gu.m implements Function1<eu.b<? super Unit>, Object> {

                /* renamed from: t, reason: collision with root package name */
                public int f5260t;

                /* renamed from: u, reason: collision with root package name */
                public final /* synthetic */ i f5261u;

                /* renamed from: v, reason: collision with root package name */
                public final /* synthetic */ String f5262v;

                /* renamed from: w, reason: collision with root package name */
                public final /* synthetic */ String f5263w;

                /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                public d(i iVar, String str, String str2, eu.b<? super d> bVar) {
                    super(1, bVar);
                    this.f5261u = iVar;
                    this.f5262v = str;
                    this.f5263w = str2;
                }

                @Override // gu.a
                public final eu.b<Unit> create(eu.b<?> bVar) {
                    return new d(this.f5261u, this.f5262v, this.f5263w, bVar);
                }

                @Override // gu.a
                public final Object invokeSuspend(Object obj) {
                    fu.c.e();
                    if (this.f5260t != 0) {
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                    zt.o.b(obj);
                    INativeAdsCoreListener iNativeAdsCoreListener = this.f5261u.nativeAdsCore;
                    if (iNativeAdsCoreListener != null) {
                        iNativeAdsCoreListener.onReportAd(this.f5262v, this.f5263w);
                    }
                    return Unit.f21504a;
                }

                @Override // kotlin.jvm.functions.Function1
                /* renamed from: m, reason: merged with bridge method [inline-methods] */
                public final Object invoke(eu.b<? super Unit> bVar) {
                    return ((d) create(bVar)).invokeSuspend(Unit.f21504a);
                }
            }

            public a(i iVar, int i10) {
                this.f5247a = iVar;
                this.b = i10;
            }

            @Override // hm.k
            public void a(NativeAdsProgressData progressData) {
                Intrinsics.checkNotNullParameter(progressData, "progressData");
                i iVar = this.f5247a;
                iVar.j(new C0107a(iVar, progressData, null));
            }

            @Override // hm.k
            public void b(String reasonKey, String description) {
                Intrinsics.checkNotNullParameter(reasonKey, "reasonKey");
                Intrinsics.checkNotNullParameter(description, "description");
                i iVar = this.f5247a;
                iVar.j(new d(iVar, reasonKey, description, null));
            }

            @Override // hm.k
            public void c(String gmaAdType, boolean isEndCardVisible) {
                i iVar = this.f5247a;
                iVar.j(new b(gmaAdType, iVar, isEndCardVisible, null));
            }

            @Override // hm.k
            public void d(jm.c status, float watchDuration) {
                Intrinsics.checkNotNullParameter(status, "status");
                i iVar = this.f5247a;
                iVar.j(new c(iVar, this.b, status, watchDuration, null));
            }
        }

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public p(String str, i iVar, int i10, eu.b<? super p> bVar) {
            super(1, bVar);
            this.f5244u = str;
            this.f5245v = iVar;
            this.f5246w = i10;
        }

        @Override // gu.a
        public final eu.b<Unit> create(eu.b<?> bVar) {
            return new p(this.f5244u, this.f5245v, this.f5246w, bVar);
        }

        @Override // gu.a
        public final Object invokeSuspend(Object obj) {
            fu.c.e();
            if (this.f5243t != 0) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            zt.o.b(obj);
            if (this.f5244u.length() != 0) {
                this.f5245v.gmaSdkController.b(this.f5244u, new a(this.f5245v, this.f5246w));
                return Unit.f21504a;
            }
            INativeAdsCoreListener iNativeAdsCoreListener = this.f5245v.nativeAdsCore;
            if (iNativeAdsCoreListener != null) {
                iNativeAdsCoreListener.onShowAdCompleted(this.f5246w, jm.c.f20807f.getValue(), 0.0f);
            }
            return Unit.f21504a;
        }

        @Override // kotlin.jvm.functions.Function1
        /* renamed from: m, reason: merged with bridge method [inline-methods] */
        public final Object invoke(eu.b<? super Unit> bVar) {
            return ((p) create(bVar)).invokeSuspend(Unit.f21504a);
        }
    }

    @Metadata(d1 = {"\u0000!\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0003\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0003*\u0001\u0000\b\n\u0018\u00002\u00020\u00012\u00020\u0002J\u001f\u0010\b\u001a\u00020\u00072\u0006\u0010\u0004\u001a\u00020\u00032\u0006\u0010\u0006\u001a\u00020\u0005H\u0016¢\u0006\u0004\b\b\u0010\t¨\u0006\n"}, d2 = {"ch/i$q", "Lkotlin/coroutines/a;", "Lav/m0;", "Lkotlin/coroutines/CoroutineContext;", "context", BuildConfig.FLAVOR, "exception", BuildConfig.FLAVOR, "handleException", "(Lkotlin/coroutines/CoroutineContext;Ljava/lang/Throwable;)V", "kotlinx-coroutines-core"}, k = 1, mv = {2, 2, 0}, xi = 48)
    public static final class q extends kotlin.coroutines.a implements m0 {
        public q(m0.Companion companion) {
            super(companion);
        }

        @Override // av.m0
        public void handleException(CoroutineContext context, Throwable exception) {
            ok.q.f("NativeAdsHandler", "Uncaught exception in ads task", exception);
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    public i(@NotNull hm.i moduleInstaller, @NotNull hm.c gmaSdkController, @NotNull p0 scope, @NotNull Function1<? super i, ? extends INativeAdsCoreListener> setPlatformImpl) {
        Intrinsics.checkNotNullParameter(moduleInstaller, "moduleInstaller");
        Intrinsics.checkNotNullParameter(gmaSdkController, "gmaSdkController");
        Intrinsics.checkNotNullParameter(scope, "scope");
        Intrinsics.checkNotNullParameter(setPlatformImpl, "setPlatformImpl");
        this.moduleInstaller = moduleInstaller;
        this.gmaSdkController = gmaSdkController;
        this.scope = scope;
        this.setPlatformImpl = setPlatformImpl;
        this.cleanedUp = new AtomicBoolean(false);
        this.pendingServeAds = new ConcurrentHashMap<>();
        this.nativeAdsCore = (INativeAdsCoreListener) setPlatformImpl.invoke(this);
    }

    public static final Unit l(i iVar, String it) {
        Intrinsics.checkNotNullParameter(it, "it");
        INativeAdsCoreListener iNativeAdsCoreListener = iVar.nativeAdsCore;
        if (iNativeAdsCoreListener != null) {
            iNativeAdsCoreListener.onLoadInterstitialAdSuccess(it);
        }
        return Unit.f21504a;
    }

    public static final Unit m(i iVar, String id2, LoadAdFailureReason reason, String message) {
        Intrinsics.checkNotNullParameter(id2, "id");
        Intrinsics.checkNotNullParameter(reason, "reason");
        Intrinsics.checkNotNullParameter(message, "message");
        INativeAdsCoreListener iNativeAdsCoreListener = iVar.nativeAdsCore;
        if (iNativeAdsCoreListener != null) {
            iNativeAdsCoreListener.onLoadInterstitialAdFailed(id2, reason, message);
        }
        return Unit.f21504a;
    }

    @Override // com.roblox.protocols.nativeadsplatforminterface.generated.IPlatformNativeAds
    public void cleanupAd() {
        j(new d(null));
    }

    @Override // com.roblox.protocols.nativeadsplatforminterface.generated.IPlatformNativeAds
    public void destroyInterstitialAd(@NotNull String adTracingId) {
        Intrinsics.checkNotNullParameter(adTracingId, "adTracingId");
        j(new e(adTracingId, null));
    }

    @Override // com.roblox.protocols.nativeadsplatforminterface.generated.IPlatformNativeAds
    public void getQueryInfo(int id2, @NotNull String adTracingId, @NotNull String adUnitId, @NotNull String experimentVariant) {
        Intrinsics.checkNotNullParameter(adTracingId, "adTracingId");
        Intrinsics.checkNotNullParameter(adUnitId, "adUnitId");
        Intrinsics.checkNotNullParameter(experimentVariant, "experimentVariant");
        j(new g(experimentVariant, adTracingId, this, id2, adUnitId, null));
    }

    public final void i() {
        if (!this.cleanedUp.compareAndSet(false, true)) {
            ok.q.e("NativeAdsHandler", "cleanup() called more than once");
            return;
        }
        ok.q.h("NativeAdsHandler", "cleanup");
        this.setPlatformImpl.invoke(null);
        this.nativeAdsCore = null;
        this.gmaSdkController.destroy();
        q0.f(this.scope, null, 1, null);
    }

    @Override // com.roblox.protocols.nativeadsplatforminterface.generated.IPlatformNativeAds
    public void initialize(int id2, @NotNull String experimentVariant) {
        Intrinsics.checkNotNullParameter(experimentVariant, "experimentVariant");
        j(new h(experimentVariant, id2, null));
    }

    @Override // com.roblox.protocols.nativeadsplatforminterface.generated.IPlatformNativeAds
    public void initializeSdk(@NotNull String requestId, @NotNull String initializeAdUnitId) {
        Intrinsics.checkNotNullParameter(requestId, "requestId");
        Intrinsics.checkNotNullParameter(initializeAdUnitId, "initializeAdUnitId");
        j(new C0105i(requestId, initializeAdUnitId, null));
    }

    @Override // com.roblox.protocols.nativeadsplatforminterface.generated.IPlatformNativeAds
    public void install(boolean eagerInstall) {
        j(new j(eagerInstall, this, null));
    }

    public final void j(Function1<? super eu.b<? super Unit>, ? extends Object> block) {
        if (q0.i(this.scope)) {
            av.k.d(this.scope, null, null, new f(block, null), 3, null);
        } else {
            ok.q.e("NativeAdsHandler", "Failed to enqueue ads task");
        }
    }

    public final void k(hm.a adFormat, String adTracingId, String adUnitId, Function1<? super String, Unit> onSuccess, pu.n<? super String, ? super LoadAdFailureReason, ? super String, Unit> onFailure) {
        j(new k(adTracingId, onFailure, this, adFormat, adUnitId, onSuccess, null));
    }

    @Override // com.roblox.protocols.nativeadsplatforminterface.generated.IPlatformNativeAds
    public void loadInterstitialAd(@NotNull String adTracingId, @NotNull String adUnitId) {
        Intrinsics.checkNotNullParameter(adTracingId, "adTracingId");
        Intrinsics.checkNotNullParameter(adUnitId, "adUnitId");
        k(hm.a.f18276d, adTracingId, adUnitId, new Function1() { // from class: ch.g
            @Override // kotlin.jvm.functions.Function1
            public final Object invoke(Object obj) {
                Unit l10;
                l10 = i.l(i.this, (String) obj);
                return l10;
            }
        }, new pu.n() { // from class: ch.h
            @Override // pu.n
            public final Object invoke(Object obj, Object obj2, Object obj3) {
                Unit m10;
                m10 = i.m(i.this, (String) obj, (LoadAdFailureReason) obj2, (String) obj3);
                return m10;
            }
        });
    }

    public final void n(@NotNull hm.c controller) {
        Intrinsics.checkNotNullParameter(controller, "controller");
        hm.c cVar = this.gmaSdkController;
        if ((cVar instanceof NoopGmaSdkController) && !(controller instanceof NoopGmaSdkController)) {
            j(new l(controller, null));
            return;
        }
        ok.q.e("NativeAdsHandler", "replaceNoopGmaSdkController must swap a no-op for a real controller but was " + cVar.getClass().getSimpleName() + " -> " + controller.getClass().getSimpleName());
    }

    /* JADX WARN: Removed duplicated region for block: B:18:0x004e  */
    /* JADX WARN: Removed duplicated region for block: B:9:0x0023  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final java.lang.Object o(hm.a r10, java.lang.String r11, java.lang.String r12, eu.b<? super zt.n<java.lang.String>> r13) {
        /*
            Method dump skipped, instructions count: 294
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: ch.i.o(hm.a, java.lang.String, java.lang.String, eu.b):java.lang.Object");
    }

    @Override // com.roblox.protocols.nativeadsplatforminterface.generated.IPlatformNativeAds
    public void onServeInterstitialAdFailed(@NotNull String adTracingId) {
        Intrinsics.checkNotNullParameter(adTracingId, "adTracingId");
        x<zt.n<String>> remove = this.pendingServeAds.remove(adTracingId);
        if (remove != null) {
            zt.n.Companion companion = zt.n.INSTANCE;
            remove.s(zt.n.a(zt.n.b(zt.o.a(new RuntimeException("serveAd failed")))));
        }
    }

    @Override // com.roblox.protocols.nativeadsplatforminterface.generated.IPlatformNativeAds
    public void onServeInterstitialAdResponse(@NotNull String adTracingId, @NotNull String adResponseJson) {
        Intrinsics.checkNotNullParameter(adTracingId, "adTracingId");
        Intrinsics.checkNotNullParameter(adResponseJson, "adResponseJson");
        x<zt.n<String>> remove = this.pendingServeAds.remove(adTracingId);
        if (remove != null) {
            remove.s(zt.n.a(zt.n.b(adResponseJson)));
        }
    }

    @Override // com.roblox.protocols.nativeadsplatforminterface.generated.IPlatformNativeAds
    public void setAdString(int id2, @NotNull String adTracingId, @NotNull String adUnitId, @NotNull String adString, @NotNull String durationNeededEnum, long durationNeededForRewardMs, boolean isEuUser, @NotNull String creativeUrl, @NotNull String uiExperimentData, @NotNull String gmaAdType, boolean isClickable) {
        Intrinsics.checkNotNullParameter(adTracingId, "adTracingId");
        Intrinsics.checkNotNullParameter(adUnitId, "adUnitId");
        Intrinsics.checkNotNullParameter(adString, "adString");
        Intrinsics.checkNotNullParameter(durationNeededEnum, "durationNeededEnum");
        Intrinsics.checkNotNullParameter(creativeUrl, "creativeUrl");
        Intrinsics.checkNotNullParameter(uiExperimentData, "uiExperimentData");
        Intrinsics.checkNotNullParameter(gmaAdType, "gmaAdType");
        j(new o(adTracingId, this, id2, durationNeededForRewardMs, durationNeededEnum, isEuUser, creativeUrl, gmaAdType, isClickable, uiExperimentData, adString, adUnitId, null));
    }

    @Override // com.roblox.protocols.nativeadsplatforminterface.generated.IPlatformNativeAds
    public void showAd(int id2, @NotNull String adTracingId) {
        Intrinsics.checkNotNullParameter(adTracingId, "adTracingId");
        j(new p(adTracingId, this, id2, null));
    }

    public /* synthetic */ i(hm.i iVar, hm.c cVar, p0 p0Var, Function1 function1, int i10, DefaultConstructorMarker defaultConstructorMarker) {
        this(iVar, (i10 & 2) != 0 ? new NoopGmaSdkController(null, 1, null) : cVar, (i10 & 4) != 0 ? q0.a(z2.b(null, 1, null).plus(l0.T(g1.a(), 1, null, 2, null)).plus(new q(m0.INSTANCE))) : p0Var, (i10 & 8) != 0 ? a.f5161a : function1);
    }


    // --- восстановлено из DEX (ch/i$g$a) ---
    public static class a implements hm.j {
        ch.i a;
        boolean b;
        int c;
        public a(ch.i p0, boolean p1, int p2) { }
        public void a(im.a p0) { throw new UnsupportedOperationException("stub"); }
        public void onSuccess(java.lang.String p0) { throw new UnsupportedOperationException("stub"); }
    }

    // --- восстановлено из DEX (ch/i$g$a$a) ---
    public static class a extends gu.m implements kotlin.jvm.functions.Function1 {
        int t;
        boolean u;
        im.a v;
        ch.i w;
        int x;
        public a(boolean p0, im.a p1, ch.i p2, int p3, eu.b p4) { }
        public eu.b create(eu.b p0) { throw new UnsupportedOperationException("stub"); }
        public java.lang.Object invoke(java.lang.Object p0) { throw new UnsupportedOperationException("stub"); }
        public java.lang.Object invokeSuspend(java.lang.Object p0) { throw new UnsupportedOperationException("stub"); }
        public java.lang.Object m(eu.b p0) { throw new UnsupportedOperationException("stub"); }
    }

    // --- восстановлено из DEX (ch/i$g$a$b) ---
    public static class b extends gu.m implements kotlin.jvm.functions.Function1 {
        int t;
        boolean u;
        ch.i v;
        int w;
        java.lang.String x;
        public b(boolean p0, ch.i p1, int p2, java.lang.String p3, eu.b p4) { }
        public eu.b create(eu.b p0) { throw new UnsupportedOperationException("stub"); }
        public java.lang.Object invoke(java.lang.Object p0) { throw new UnsupportedOperationException("stub"); }
        public java.lang.Object invokeSuspend(java.lang.Object p0) { throw new UnsupportedOperationException("stub"); }
        public java.lang.Object m(eu.b p0) { throw new UnsupportedOperationException("stub"); }
    }

    // --- восстановлено из DEX (ch/i$h$a) ---
    public static class a extends gu.m implements kotlin.jvm.functions.Function1 {
        int t;
        ch.i u;
        int v;
        java.lang.Boolean w;
        java.lang.String x;
        public a(ch.i p0, int p1, java.lang.Boolean p2, java.lang.String p3, eu.b p4) { }
        public eu.b create(eu.b p0) { throw new UnsupportedOperationException("stub"); }
        public java.lang.Object invoke(java.lang.Object p0) { throw new UnsupportedOperationException("stub"); }
        public java.lang.Object invokeSuspend(java.lang.Object p0) { throw new UnsupportedOperationException("stub"); }
        public java.lang.Object m(eu.b p0) { throw new UnsupportedOperationException("stub"); }
    }

    // --- восстановлено из DEX (ch/i$k$a) ---
    public static class a extends gu.m implements kotlin.jvm.functions.Function2 {
        int t;
        java.lang.Object u;
        ch.i v;
        hm.a w;
        java.lang.String x;
        public a(ch.i p0, hm.a p1, java.lang.String p2, eu.b p3) { }
        public eu.b create(java.lang.Object p0, eu.b p1) { throw new UnsupportedOperationException("stub"); }
        public java.lang.Object invoke(java.lang.Object p0, java.lang.Object p1) { throw new UnsupportedOperationException("stub"); }
        public java.lang.Object invokeSuspend(java.lang.Object p0) { throw new UnsupportedOperationException("stub"); }
        public java.lang.Object m(java.lang.String p0, eu.b p1) { throw new UnsupportedOperationException("stub"); }
    }

    // --- восстановлено из DEX (ch/i$o$a) ---
    public static class a implements hm.f {
        ch.i a;
        int b;
        public a(ch.i p0, int p1) { }
        public void onFailure(java.lang.String p0) { throw new UnsupportedOperationException("stub"); }
        public void onSuccess() { throw new UnsupportedOperationException("stub"); }
    }

    // --- восстановлено из DEX (ch/i$o$a$a) ---
    public static class a extends gu.m implements kotlin.jvm.functions.Function1 {
        int t;
        ch.i u;
        int v;
        java.lang.String w;
        public a(ch.i p0, int p1, java.lang.String p2, eu.b p3) { }
        public eu.b create(eu.b p0) { throw new UnsupportedOperationException("stub"); }
        public java.lang.Object invoke(java.lang.Object p0) { throw new UnsupportedOperationException("stub"); }
        public java.lang.Object invokeSuspend(java.lang.Object p0) { throw new UnsupportedOperationException("stub"); }
        public java.lang.Object m(eu.b p0) { throw new UnsupportedOperationException("stub"); }
    }

    // --- восстановлено из DEX (ch/i$o$a$b) ---
    public static class b extends gu.m implements kotlin.jvm.functions.Function1 {
        int t;
        ch.i u;
        int v;
        public b(ch.i p0, int p1, eu.b p2) { }
        public eu.b create(eu.b p0) { throw new UnsupportedOperationException("stub"); }
        public java.lang.Object invoke(java.lang.Object p0) { throw new UnsupportedOperationException("stub"); }
        public java.lang.Object invokeSuspend(java.lang.Object p0) { throw new UnsupportedOperationException("stub"); }
        public java.lang.Object m(eu.b p0) { throw new UnsupportedOperationException("stub"); }
    }

    // --- восстановлено из DEX (ch/i$p$a) ---
    public static class a implements hm.k {
        ch.i a;
        int b;
        public a(ch.i p0, int p1) { }
        public void a(jm.b p0) { throw new UnsupportedOperationException("stub"); }
        public void b(java.lang.String p0, java.lang.String p1) { throw new UnsupportedOperationException("stub"); }
        public void c(java.lang.String p0, boolean p1) { throw new UnsupportedOperationException("stub"); }
        public void d(jm.c p0, float p1) { throw new UnsupportedOperationException("stub"); }
    }

    // --- восстановлено из DEX (ch/i$p$a$a) ---
    public static class a extends gu.m implements kotlin.jvm.functions.Function1 {
        int t;
        ch.i u;
        jm.b v;
        public a(ch.i p0, jm.b p1, eu.b p2) { }
        public eu.b create(eu.b p0) { throw new UnsupportedOperationException("stub"); }
        public java.lang.Object invoke(java.lang.Object p0) { throw new UnsupportedOperationException("stub"); }
        public java.lang.Object invokeSuspend(java.lang.Object p0) { throw new UnsupportedOperationException("stub"); }
        public java.lang.Object m(eu.b p0) { throw new UnsupportedOperationException("stub"); }
    }

    // --- восстановлено из DEX (ch/i$p$a$b) ---
    public static class b extends gu.m implements kotlin.jvm.functions.Function1 {
        int t;
        java.lang.String u;
        ch.i v;
        boolean w;
        public b(java.lang.String p0, ch.i p1, boolean p2, eu.b p3) { }
        public eu.b create(eu.b p0) { throw new UnsupportedOperationException("stub"); }
        public java.lang.Object invoke(java.lang.Object p0) { throw new UnsupportedOperationException("stub"); }
        public java.lang.Object invokeSuspend(java.lang.Object p0) { throw new UnsupportedOperationException("stub"); }
        public java.lang.Object m(eu.b p0) { throw new UnsupportedOperationException("stub"); }
    }

    // --- восстановлено из DEX (ch/i$p$a$c) ---
    public static class c extends gu.m implements kotlin.jvm.functions.Function1 {
        int t;
        ch.i u;
        int v;
        jm.c w;
        float x;
        public c(ch.i p0, int p1, jm.c p2, float p3, eu.b p4) { }
        public eu.b create(eu.b p0) { throw new UnsupportedOperationException("stub"); }
        public java.lang.Object invoke(java.lang.Object p0) { throw new UnsupportedOperationException("stub"); }
        public java.lang.Object invokeSuspend(java.lang.Object p0) { throw new UnsupportedOperationException("stub"); }
        public java.lang.Object m(eu.b p0) { throw new UnsupportedOperationException("stub"); }
    }

    // --- восстановлено из DEX (ch/i$p$a$d) ---
    public static class d extends gu.m implements kotlin.jvm.functions.Function1 {
        int t;
        ch.i u;
        java.lang.String v;
        java.lang.String w;
        public d(ch.i p0, java.lang.String p1, java.lang.String p2, eu.b p3) { }
        public eu.b create(eu.b p0) { throw new UnsupportedOperationException("stub"); }
        public java.lang.Object invoke(java.lang.Object p0) { throw new UnsupportedOperationException("stub"); }
        public java.lang.Object invokeSuspend(java.lang.Object p0) { throw new UnsupportedOperationException("stub"); }
        public java.lang.Object m(eu.b p0) { throw new UnsupportedOperationException("stub"); }
    }
}
