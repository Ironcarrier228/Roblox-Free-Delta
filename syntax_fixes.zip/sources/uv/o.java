package uv;

import com.appsflyer.sdk_base.referrer.Payload;
import com.github.luben.zstd.BuildConfig;
import java.io.Closeable;
import java.io.IOException;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.TimeUnit;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.c0;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import uv.c;
import uv.o;
import uv.u;
import vv.WindowCounter;

@Metadata(d1 = {"\u0000È\u0001\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\b\n\u0000\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0007\n\u0002\u0010\t\n\u0002\b\t\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b%\n\u0002\u0018\u0002\n\u0002\b\t\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0010%\n\u0002\b\u0005\n\u0002\u0010\u000e\n\u0002\b\u0011\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0007\n\u0002\u0018\u0002\n\u0002\b\u0010\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\n\n\u0002\u0018\u0002\n\u0002\b\r\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0010#\n\u0002\b\u0005\u0018\u0000 Ê\u00012\u00020\u00012\u00020\u0002:\u0004Uga[B\u0011\b\u0000\u0012\u0006\u0010\u0004\u001a\u00020\u0003¢\u0006\u0004\b\u0005\u0010\u0006J-\u0010\u000f\u001a\u00020\u000e2\u0006\u0010\b\u001a\u00020\u00072\f\u0010\u000b\u001a\b\u0012\u0004\u0012\u00020\n0\t2\u0006\u0010\r\u001a\u00020\fH\u0002¢\u0006\u0004\b\u000f\u0010\u0010J\u0019\u0010\u0014\u001a\u00020\u00132\b\u0010\u0012\u001a\u0004\u0018\u00010\u0011H\u0002¢\u0006\u0004\b\u0014\u0010\u0015J\u0017\u0010\u0017\u001a\u0004\u0018\u00010\u000e2\u0006\u0010\u0016\u001a\u00020\u0007¢\u0006\u0004\b\u0017\u0010\u0018J\u0019\u0010\u001a\u001a\u0004\u0018\u00010\u000e2\u0006\u0010\u0019\u001a\u00020\u0007H\u0000¢\u0006\u0004\b\u001a\u0010\u0018J\u0017\u0010\u001d\u001a\u00020\u00132\u0006\u0010\u001c\u001a\u00020\u001bH\u0000¢\u0006\u0004\b\u001d\u0010\u001eJ#\u0010\u001f\u001a\u00020\u000e2\f\u0010\u000b\u001a\b\u0012\u0004\u0012\u00020\n0\t2\u0006\u0010\r\u001a\u00020\f¢\u0006\u0004\b\u001f\u0010 J-\u0010#\u001a\u00020\u00132\u0006\u0010\u0019\u001a\u00020\u00072\u0006\u0010!\u001a\u00020\f2\f\u0010\"\u001a\b\u0012\u0004\u0012\u00020\n0\tH\u0000¢\u0006\u0004\b#\u0010$J/\u0010(\u001a\u00020\u00132\u0006\u0010\u0019\u001a\u00020\u00072\u0006\u0010!\u001a\u00020\f2\b\u0010&\u001a\u0004\u0018\u00010%2\u0006\u0010'\u001a\u00020\u001b¢\u0006\u0004\b(\u0010)J\u001f\u0010,\u001a\u00020\u00132\u0006\u0010\u0019\u001a\u00020\u00072\u0006\u0010+\u001a\u00020*H\u0000¢\u0006\u0004\b,\u0010-J\u001f\u0010/\u001a\u00020\u00132\u0006\u0010\u0019\u001a\u00020\u00072\u0006\u0010.\u001a\u00020*H\u0000¢\u0006\u0004\b/\u0010-J\u001f\u00101\u001a\u00020\u00132\u0006\u0010\u0019\u001a\u00020\u00072\u0006\u00100\u001a\u00020\u001bH\u0000¢\u0006\u0004\b1\u00102J%\u00106\u001a\u00020\u00132\u0006\u00103\u001a\u00020\f2\u0006\u00104\u001a\u00020\u00072\u0006\u00105\u001a\u00020\u0007¢\u0006\u0004\b6\u00107J\r\u00108\u001a\u00020\u0013¢\u0006\u0004\b8\u00109J\u0015\u0010:\u001a\u00020\u00132\u0006\u0010.\u001a\u00020*¢\u0006\u0004\b:\u0010;J\u000f\u0010<\u001a\u00020\u0013H\u0016¢\u0006\u0004\b<\u00109J)\u0010@\u001a\u00020\u00132\u0006\u0010=\u001a\u00020*2\u0006\u0010>\u001a\u00020*2\b\u0010?\u001a\u0004\u0018\u00010\u0011H\u0000¢\u0006\u0004\b@\u0010AJ\u0019\u0010C\u001a\u00020\u00132\b\b\u0002\u0010B\u001a\u00020\fH\u0007¢\u0006\u0004\bC\u0010DJ\u0015\u0010F\u001a\u00020\f2\u0006\u0010E\u001a\u00020\u001b¢\u0006\u0004\bF\u0010GJ\u000f\u0010H\u001a\u00020\u0013H\u0000¢\u0006\u0004\bH\u00109J\u0017\u0010I\u001a\u00020\f2\u0006\u0010\u0019\u001a\u00020\u0007H\u0000¢\u0006\u0004\bI\u0010JJ%\u0010K\u001a\u00020\u00132\u0006\u0010\u0019\u001a\u00020\u00072\f\u0010\u000b\u001a\b\u0012\u0004\u0012\u00020\n0\tH\u0000¢\u0006\u0004\bK\u0010LJ-\u0010N\u001a\u00020\u00132\u0006\u0010\u0019\u001a\u00020\u00072\f\u0010\u000b\u001a\b\u0012\u0004\u0012\u00020\n0\t2\u0006\u0010M\u001a\u00020\fH\u0000¢\u0006\u0004\bN\u0010OJ/\u0010R\u001a\u00020\u00132\u0006\u0010\u0019\u001a\u00020\u00072\u0006\u0010Q\u001a\u00020P2\u0006\u0010'\u001a\u00020\u00072\u0006\u0010M\u001a\u00020\fH\u0000¢\u0006\u0004\bR\u0010SJ\u001f\u0010T\u001a\u00020\u00132\u0006\u0010\u0019\u001a\u00020\u00072\u0006\u0010+\u001a\u00020*H\u0000¢\u0006\u0004\bT\u0010-R\u001a\u0010Y\u001a\u00020\f8\u0000X\u0080\u0004¢\u0006\f\n\u0004\bU\u0010V\u001a\u0004\bW\u0010XR\u001a\u0010_\u001a\u00020Z8\u0000X\u0080\u0004¢\u0006\f\n\u0004\b[\u0010\\\u001a\u0004\b]\u0010^R&\u0010e\u001a\u000e\u0012\u0004\u0012\u00020\u0007\u0012\u0004\u0012\u00020\u000e0`8\u0000X\u0080\u0004¢\u0006\f\n\u0004\ba\u0010b\u001a\u0004\bc\u0010dR\u001a\u0010k\u001a\u00020f8\u0000X\u0080\u0004¢\u0006\f\n\u0004\bg\u0010h\u001a\u0004\bi\u0010jR\"\u0010q\u001a\u00020\u00078\u0000@\u0000X\u0080\u000e¢\u0006\u0012\n\u0004\b\u0012\u0010l\u001a\u0004\bm\u0010n\"\u0004\bo\u0010pR\"\u0010u\u001a\u00020\u00078\u0000@\u0000X\u0080\u000e¢\u0006\u0012\n\u0004\br\u0010l\u001a\u0004\bs\u0010n\"\u0004\bt\u0010pR\u0016\u0010w\u001a\u00020\f8\u0002@\u0002X\u0082\u000e¢\u0006\u0006\n\u0004\bv\u0010VR\u0014\u0010{\u001a\u00020x8\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\by\u0010zR\u0014\u0010\u007f\u001a\u00020|8\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b}\u0010~R\u0016\u0010\u0081\u0001\u001a\u00020|8\u0002X\u0082\u0004¢\u0006\u0007\n\u0005\b\u0080\u0001\u0010~R\u0016\u0010\u0083\u0001\u001a\u00020|8\u0002X\u0082\u0004¢\u0006\u0007\n\u0005\b\u0082\u0001\u0010~R\u0018\u0010\u0087\u0001\u001a\u00030\u0084\u00018\u0002X\u0082\u0004¢\u0006\b\n\u0006\b\u0085\u0001\u0010\u0086\u0001R\u0019\u0010\u008a\u0001\u001a\u00020\u001b8\u0002@\u0002X\u0082\u000e¢\u0006\b\n\u0006\b\u0088\u0001\u0010\u0089\u0001R\u0019\u0010\u008c\u0001\u001a\u00020\u001b8\u0002@\u0002X\u0082\u000e¢\u0006\b\n\u0006\b\u008b\u0001\u0010\u0089\u0001R\u0019\u0010\u008e\u0001\u001a\u00020\u001b8\u0002@\u0002X\u0082\u000e¢\u0006\b\n\u0006\b\u008d\u0001\u0010\u0089\u0001R\u0019\u0010\u0090\u0001\u001a\u00020\u001b8\u0002@\u0002X\u0082\u000e¢\u0006\b\n\u0006\b\u008f\u0001\u0010\u0089\u0001R\u0019\u0010\u0092\u0001\u001a\u00020\u001b8\u0002@\u0002X\u0082\u000e¢\u0006\b\n\u0006\b\u0091\u0001\u0010\u0089\u0001R\u0019\u0010\u0094\u0001\u001a\u00020\u001b8\u0002@\u0002X\u0082\u000e¢\u0006\b\n\u0006\b\u0093\u0001\u0010\u0089\u0001R \u0010\u009a\u0001\u001a\u00030\u0095\u00018\u0000X\u0080\u0004¢\u0006\u0010\n\u0006\b\u0096\u0001\u0010\u0097\u0001\u001a\u0006\b\u0098\u0001\u0010\u0099\u0001R\u001d\u0010 \u0001\u001a\u00030\u009b\u00018\u0006¢\u0006\u0010\n\u0006\b\u009c\u0001\u0010\u009d\u0001\u001a\u0006\b\u009e\u0001\u0010\u009f\u0001R*\u0010¥\u0001\u001a\u00030\u009b\u00018\u0006@\u0006X\u0086\u000e¢\u0006\u0018\n\u0006\b¡\u0001\u0010\u009d\u0001\u001a\u0006\b¢\u0001\u0010\u009f\u0001\"\u0006\b£\u0001\u0010¤\u0001R\u001d\u0010«\u0001\u001a\u00030¦\u00018\u0006¢\u0006\u0010\n\u0006\b§\u0001\u0010¨\u0001\u001a\u0006\b©\u0001\u0010ª\u0001R*\u0010°\u0001\u001a\u00020\u001b2\u0007\u0010¬\u0001\u001a\u00020\u001b8\u0006@BX\u0086\u000e¢\u0006\u0010\n\u0006\b\u00ad\u0001\u0010\u0089\u0001\u001a\u0006\b®\u0001\u0010¯\u0001R*\u0010³\u0001\u001a\u00020\u001b2\u0007\u0010¬\u0001\u001a\u00020\u001b8\u0006@BX\u0086\u000e¢\u0006\u0010\n\u0006\b±\u0001\u0010\u0089\u0001\u001a\u0006\b²\u0001\u0010¯\u0001R \u0010¹\u0001\u001a\u00030´\u00018\u0000X\u0080\u0004¢\u0006\u0010\n\u0006\bµ\u0001\u0010¶\u0001\u001a\u0006\b·\u0001\u0010¸\u0001R\u001d\u0010¿\u0001\u001a\u00030º\u00018\u0006¢\u0006\u0010\n\u0006\b»\u0001\u0010¼\u0001\u001a\u0006\b½\u0001\u0010¾\u0001R!\u0010Å\u0001\u001a\u00070À\u0001R\u00020\u00008\u0006¢\u0006\u0010\n\u0006\bÁ\u0001\u0010Â\u0001\u001a\u0006\bÃ\u0001\u0010Ä\u0001R\u001e\u0010É\u0001\u001a\t\u0012\u0004\u0012\u00020\u00070Æ\u00018\u0002X\u0082\u0004¢\u0006\b\n\u0006\bÇ\u0001\u0010È\u0001¨\u0006Ë\u0001"}, d2 = {"Luv/o;", "Ljava/io/Closeable;", BuildConfig.FLAVOR, "Luv/o$a;", "builder", "<init>", "(Luv/o$a;)V", BuildConfig.FLAVOR, "associatedStreamId", BuildConfig.FLAVOR, "Luv/d;", "requestHeaders", BuildConfig.FLAVOR, "out", "Luv/v;", "s0", "(ILjava/util/List;Z)Luv/v;", "Ljava/io/IOException;", "e", BuildConfig.FLAVOR, "N", "(Ljava/io/IOException;)V", "id", "f0", "(I)Luv/v;", "streamId", "O0", BuildConfig.FLAVOR, "read", "W0", "(J)V", "w0", "(Ljava/util/List;Z)Luv/v;", "outFinished", "alternating", "Y0", "(IZLjava/util/List;)V", "Lew/e;", "buffer", "byteCount", "X0", "(IZLew/e;J)V", "Luv/b;", "errorCode", "e1", "(ILuv/b;)V", "statusCode", "a1", "unacknowledgedBytesRead", "g1", "(IJ)V", "reply", "payload1", "payload2", "Z0", "(ZII)V", "flush", "()V", "T0", "(Luv/b;)V", "close", "connectionCode", "streamCode", "cause", "L", "(Luv/b;Luv/b;Ljava/io/IOException;)V", "sendConnectionPreface", "U0", "(Z)V", "nowNs", "n0", "(J)Z", "Q0", "M0", "(I)Z", "G0", "(ILjava/util/List;)V", "inFinished", "E0", "(ILjava/util/List;Z)V", "Lew/g;", Payload.SOURCE, "z0", "(ILew/g;IZ)V", "K0", xe.a.f36648e, "Z", "O", "()Z", "client", "Luv/o$c;", k6.b.f21144e, "Luv/o$c;", "b0", "()Luv/o$c;", "listener", BuildConfig.FLAVOR, "c", "Ljava/util/Map;", "h0", "()Ljava/util/Map;", "streams", BuildConfig.FLAVOR, "d", "Ljava/lang/String;", "Q", "()Ljava/lang/String;", "connectionName", "I", "Y", "()I", "R0", "(I)V", "lastGoodStreamId", "f", "c0", "setNextStreamId$okhttp", "nextStreamId", "g", "isShutdown", "Lqv/d;", "h", "Lqv/d;", "taskRunner", "Lqv/c;", "i", "Lqv/c;", "writerQueue", "j", "pushQueue", "k", "settingsListenerQueue", "Luv/y;", "l", "Luv/y;", "pushObserver", "m", "J", "intervalPingsSent", "n", "intervalPongsReceived", "o", "degradedPingsSent", "p", "degradedPongsReceived", "q", "awaitPongsReceived", "r", "degradedPongDeadlineNs", "Luv/c;", "s", "Luv/c;", "T", "()Luv/c;", "flowControlListener", "Luv/z;", pm.t.f29212d, "Luv/z;", "d0", "()Luv/z;", "okHttpSettings", "u", "e0", "S0", "(Luv/z;)V", "peerSettings", "Lvv/a;", "v", "Lvv/a;", "getReadBytes", "()Lvv/a;", "readBytes", "value", "w", "getWriteBytesTotal", "()J", "writeBytesTotal", "x", "i0", "writeBytesMaximum", "Lrv/a;", "y", "Lrv/a;", "getSocket$okhttp", "()Lrv/a;", "socket", "Luv/w;", "z", "Luv/w;", "k0", "()Luv/w;", "writer", "Luv/o$d;", "A", "Luv/o$d;", "getReaderRunnable", "()Luv/o$d;", "readerRunnable", BuildConfig.FLAVOR, "B", "Ljava/util/Set;", "currentPushRequests", "C", "okhttp"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* loaded from: classes2.dex */
public final class o implements Closeable {

    /* renamed from: C, reason: from kotlin metadata */
    @NotNull
    public static final Companion INSTANCE = new Companion(null);

    @NotNull
    public static final z D;

    /* renamed from: A, reason: from kotlin metadata */
    @NotNull
    public final d readerRunnable;

    /* renamed from: B, reason: from kotlin metadata */
    @NotNull
    public final Set<Integer> currentPushRequests;

    /* renamed from: a, reason: collision with root package name and from kotlin metadata */
    public final boolean client;

    /* renamed from: b, reason: from kotlin metadata */
    @NotNull
    public final c listener;

    /* renamed from: c, reason: collision with root package name and from kotlin metadata */
    @NotNull
    public final Map<Integer, v> streams;

    /* renamed from: d, reason: collision with root package name and from kotlin metadata */
    @NotNull
    public final String connectionName;

    /* renamed from: e, reason: collision with root package name and from kotlin metadata */
    public int lastGoodStreamId;

    /* renamed from: f, reason: collision with root package name and from kotlin metadata */
    public int nextStreamId;

    /* renamed from: g, reason: collision with root package name and from kotlin metadata */
    public boolean isShutdown;

    /* renamed from: h, reason: collision with root package name and from kotlin metadata */
    @NotNull
    public final qv.d taskRunner;

    /* renamed from: i, reason: collision with root package name and from kotlin metadata */
    @NotNull
    public final qv.c writerQueue;

    /* renamed from: j, reason: collision with root package name and from kotlin metadata */
    @NotNull
    public final qv.c pushQueue;

    /* renamed from: k, reason: collision with root package name and from kotlin metadata */
    @NotNull
    public final qv.c settingsListenerQueue;

    /* renamed from: l, reason: collision with root package name and from kotlin metadata */
    @NotNull
    public final y pushObserver;

    /* renamed from: m, reason: collision with root package name and from kotlin metadata */
    public long intervalPingsSent;

    /* renamed from: n, reason: collision with root package name and from kotlin metadata */
    public long intervalPongsReceived;

    /* renamed from: o, reason: collision with root package name and from kotlin metadata */
    public long degradedPingsSent;

    /* renamed from: p, reason: collision with root package name and from kotlin metadata */
    public long degradedPongsReceived;

    /* renamed from: q, reason: collision with root package name and from kotlin metadata */
    public long awaitPongsReceived;

    /* renamed from: r, reason: collision with root package name and from kotlin metadata */
    public long degradedPongDeadlineNs;

    /* renamed from: s, reason: collision with root package name and from kotlin metadata */
    @NotNull
    public final uv.c flowControlListener;

    /* renamed from: t, reason: collision with root package name and from kotlin metadata */
    @NotNull
    public final z okHttpSettings;

    /* renamed from: u, reason: collision with root package name and from kotlin metadata */
    @NotNull
    public z peerSettings;

    /* renamed from: v, reason: collision with root package name and from kotlin metadata */
    @NotNull
    public final WindowCounter readBytes;

    /* renamed from: w, reason: collision with root package name and from kotlin metadata */
    public long writeBytesTotal;

    /* renamed from: x, reason: collision with root package name and from kotlin metadata */
    public long writeBytesMaximum;

    /* renamed from: y, reason: collision with root package name and from kotlin metadata */
    @NotNull
    public final rv.a socket;

    /* renamed from: z, reason: collision with root package name and from kotlin metadata */
    @NotNull
    public final w writer;

    @Metadata(d1 = {"\u0000L\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\b\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u001b\n\u0002\u0018\u0002\n\u0002\b\u0010\u0018\u00002\u00020\u0001B\u0017\u0012\u0006\u0010\u0003\u001a\u00020\u0002\u0012\u0006\u0010\u0005\u001a\u00020\u0004¢\u0006\u0004\b\u0006\u0010\u0007J\u001d\u0010\f\u001a\u00020\u00002\u0006\u0010\t\u001a\u00020\b2\u0006\u0010\u000b\u001a\u00020\n¢\u0006\u0004\b\f\u0010\rJ\u0015\u0010\u0010\u001a\u00020\u00002\u0006\u0010\u000f\u001a\u00020\u000e¢\u0006\u0004\b\u0010\u0010\u0011J\u0015\u0010\u0014\u001a\u00020\u00002\u0006\u0010\u0013\u001a\u00020\u0012¢\u0006\u0004\b\u0014\u0010\u0015J\u0015\u0010\u0018\u001a\u00020\u00002\u0006\u0010\u0017\u001a\u00020\u0016¢\u0006\u0004\b\u0018\u0010\u0019J\r\u0010\u001b\u001a\u00020\u001a¢\u0006\u0004\b\u001b\u0010\u001cR\"\u0010\u0003\u001a\u00020\u00028\u0000@\u0000X\u0080\u000e¢\u0006\u0012\n\u0004\b\u001b\u0010\u001d\u001a\u0004\b\u001e\u0010\u001f\"\u0004\b \u0010!R\u001a\u0010\u0005\u001a\u00020\u00048\u0000X\u0080\u0004¢\u0006\f\n\u0004\b\u0018\u0010\"\u001a\u0004\b#\u0010$R\"\u0010\t\u001a\u00020\b8\u0000@\u0000X\u0080.¢\u0006\u0012\n\u0004\b\u001e\u0010%\u001a\u0004\b&\u0010'\"\u0004\b(\u0010)R\"\u0010/\u001a\u00020\n8\u0000@\u0000X\u0080.¢\u0006\u0012\n\u0004\b*\u0010+\u001a\u0004\b*\u0010,\"\u0004\b-\u0010.R\"\u0010\u000f\u001a\u00020\u000e8\u0000@\u0000X\u0080\u000e¢\u0006\u0012\n\u0004\b0\u00101\u001a\u0004\b2\u00103\"\u0004\b4\u00105R\"\u0010<\u001a\u0002068\u0000@\u0000X\u0080\u000e¢\u0006\u0012\n\u0004\b2\u00107\u001a\u0004\b8\u00109\"\u0004\b:\u0010;R\"\u0010\u0013\u001a\u00020\u00128\u0000@\u0000X\u0080\u000e¢\u0006\u0012\n\u0004\b=\u0010>\u001a\u0004\b=\u0010?\"\u0004\b@\u0010AR\"\u0010\u0017\u001a\u00020\u00168\u0000@\u0000X\u0080\u000e¢\u0006\u0012\n\u0004\b8\u0010B\u001a\u0004\b0\u0010C\"\u0004\bD\u0010E¨\u0006F"}, d2 = {"Luv/o$a;", BuildConfig.FLAVOR, BuildConfig.FLAVOR, "client", "Lqv/d;", "taskRunner", "<init>", "(ZLqv/d;)V", "Lrv/a;", "socket", BuildConfig.FLAVOR, "peerName", "o", "(Lrv/a;Ljava/lang/String;)Luv/o$a;", "Luv/o$c;", "listener", "k", "(Luv/o$c;)Luv/o$a;", BuildConfig.FLAVOR, "pingIntervalMillis", "l", "(I)Luv/o$a;", "Luv/c;", "flowControlListener", k6.b.f21144e, "(Luv/c;)Luv/o$a;", "Luv/o;", xe.a.f36648e, "()Luv/o;", "Z", "c", "()Z", "setClient$okhttp", "(Z)V", "Lqv/d;", "j", "()Lqv/d;", "Lrv/a;", "i", "()Lrv/a;", "n", "(Lrv/a;)V", "d", "Ljava/lang/String;", "()Ljava/lang/String;", "m", "(Ljava/lang/String;)V", "connectionName", "e", "Luv/o$c;", "f", "()Luv/o$c;", "setListener$okhttp", "(Luv/o$c;)V", "Luv/y;", "Luv/y;", "h", "()Luv/y;", "setPushObserver$okhttp", "(Luv/y;)V", "pushObserver", "g", "I", "()I", "setPingIntervalMillis$okhttp", "(I)V", "Luv/c;", "()Luv/c;", "setFlowControlListener$okhttp", "(Luv/c;)V", "okhttp"}, k = 1, mv = {2, 2, 0}, xi = 48)
    public static final class a {

        /* renamed from: a, reason: collision with root package name and from kotlin metadata */
        public boolean client;

        /* renamed from: b, reason: from kotlin metadata */
        @NotNull
        public final qv.d taskRunner;

        /* renamed from: c, reason: collision with root package name and from kotlin metadata */
        public rv.a socket;

        /* renamed from: d, reason: collision with root package name and from kotlin metadata */
        public String connectionName;

        /* renamed from: e, reason: collision with root package name and from kotlin metadata */
        @NotNull
        public c listener;

        /* renamed from: f, reason: collision with root package name and from kotlin metadata */
        @NotNull
        public y pushObserver;

        /* renamed from: g, reason: collision with root package name and from kotlin metadata */
        public int pingIntervalMillis;

        /* renamed from: h, reason: collision with root package name and from kotlin metadata */
        @NotNull
        public uv.c flowControlListener;

        public a(boolean z10, @NotNull qv.d taskRunner) {
            Intrinsics.checkNotNullParameter(taskRunner, "taskRunner");
            this.client = z10;
            this.taskRunner = taskRunner;
            this.listener = c.b;
            this.pushObserver = y.b;
            this.flowControlListener = c.a.f33968a;
        }

        @NotNull
        public final o a() {
            return new o(this);
        }

        @NotNull
        public final a b(@NotNull uv.c flowControlListener) {
            Intrinsics.checkNotNullParameter(flowControlListener, "flowControlListener");
            this.flowControlListener = flowControlListener;
            return this;
        }

        /* renamed from: c, reason: from getter */
        public final boolean getClient() {
            return this.client;
        }

        @NotNull
        public final String d() {
            String str = this.connectionName;
            if (str != null) {
                return str;
            }
            Intrinsics.u("connectionName");
            return null;
        }

        @NotNull
        /* renamed from: e, reason: from getter */
        public final uv.c getFlowControlListener() {
            return this.flowControlListener;
        }

        @NotNull
        /* renamed from: f, reason: from getter */
        public final c getListener() {
            return this.listener;
        }

        /* renamed from: g, reason: from getter */
        public final int getPingIntervalMillis() {
            return this.pingIntervalMillis;
        }

        @NotNull
        /* renamed from: h, reason: from getter */
        public final y getPushObserver() {
            return this.pushObserver;
        }

        @NotNull
        public final rv.a i() {
            rv.a aVar = this.socket;
            if (aVar != null) {
                return aVar;
            }
            Intrinsics.u("socket");
            return null;
        }

        @NotNull
        /* renamed from: j, reason: from getter */
        public final qv.d getTaskRunner() {
            return this.taskRunner;
        }

        @NotNull
        public final a k(@NotNull c listener) {
            Intrinsics.checkNotNullParameter(listener, "listener");
            this.listener = listener;
            return this;
        }

        @NotNull
        public final a l(int pingIntervalMillis) {
            this.pingIntervalMillis = pingIntervalMillis;
            return this;
        }

        public final void m(@NotNull String str) {
            Intrinsics.checkNotNullParameter(str, "<set-?>");
            this.connectionName = str;
        }

        public final void n(@NotNull rv.a aVar) {
            Intrinsics.checkNotNullParameter(aVar, "<set-?>");
            this.socket = aVar;
        }

        @NotNull
        public final a o(@NotNull rv.a socket, @NotNull String peerName) {
            String str;
            Intrinsics.checkNotNullParameter(socket, "socket");
            Intrinsics.checkNotNullParameter(peerName, "peerName");
            n(socket);
            if (this.client) {
                str = nv.q.f26638c + ' ' + peerName;
            } else {
                str = "MockWebServer " + peerName;
            }
            m(str);
            return this;
        }
    }

    @Metadata(d1 = {"\u0000\u001c\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010\b\n\u0002\b\u0007\b\u0086\u0003\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003R\u0017\u0010\u0005\u001a\u00020\u00048\u0006¢\u0006\f\n\u0004\b\u0005\u0010\u0006\u001a\u0004\b\u0007\u0010\bR\u0014\u0010\n\u001a\u00020\t8\u0006X\u0086T¢\u0006\u0006\n\u0004\b\n\u0010\u000bR\u0014\u0010\f\u001a\u00020\t8\u0006X\u0086T¢\u0006\u0006\n\u0004\b\f\u0010\u000bR\u0014\u0010\r\u001a\u00020\t8\u0006X\u0086T¢\u0006\u0006\n\u0004\b\r\u0010\u000bR\u0014\u0010\u000e\u001a\u00020\t8\u0006X\u0086T¢\u0006\u0006\n\u0004\b\u000e\u0010\u000bR\u0014\u0010\u000f\u001a\u00020\t8\u0006X\u0086T¢\u0006\u0006\n\u0004\b\u000f\u0010\u000b¨\u0006\u0010"}, d2 = {"Luv/o$b;", BuildConfig.FLAVOR, "<init>", "()V", "Luv/z;", "DEFAULT_SETTINGS", "Luv/z;", xe.a.f36648e, "()Luv/z;", BuildConfig.FLAVOR, "OKHTTP_CLIENT_WINDOW_SIZE", "I", "INTERVAL_PING", "DEGRADED_PING", "AWAIT_PING", "DEGRADED_PONG_TIMEOUT_NS", "okhttp"}, k = 1, mv = {2, 2, 0}, xi = 48)
    /* renamed from: uv.o$b, reason: from kotlin metadata */
    public static final class Companion {
        public /* synthetic */ Companion(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }

        @NotNull
        public final z a() {
            return o.D;
        }

        public Companion() {
        }
    }

    @Metadata(d1 = {"\u0000(\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0005\b&\u0018\u0000 \u000f2\u00020\u0001:\u0001\rB\u0007¢\u0006\u0004\b\u0002\u0010\u0003J\u0017\u0010\u0007\u001a\u00020\u00062\u0006\u0010\u0005\u001a\u00020\u0004H&¢\u0006\u0004\b\u0007\u0010\bJ\u001f\u0010\r\u001a\u00020\u00062\u0006\u0010\n\u001a\u00020\t2\u0006\u0010\f\u001a\u00020\u000bH\u0016¢\u0006\u0004\b\r\u0010\u000e¨\u0006\u0010"}, d2 = {"Luv/o$c;", BuildConfig.FLAVOR, "<init>", "()V", "Luv/v;", "stream", BuildConfig.FLAVOR, "c", "(Luv/v;)V", "Luv/o;", "connection", "Luv/z;", "settings", k6.b.f21144e, "(Luv/o;Luv/z;)V", xe.a.f36648e, "okhttp"}, k = 1, mv = {2, 2, 0}, xi = 48)
    public static abstract class c {

        @NotNull
        public static final c b = new a();

        @Metadata(d1 = {"\u0000\u0017\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0003*\u0001\u0000\b\n\u0018\u00002\u00020\u0001J\u0017\u0010\u0005\u001a\u00020\u00042\u0006\u0010\u0003\u001a\u00020\u0002H\u0016¢\u0006\u0004\b\u0005\u0010\u0006¨\u0006\u0007"}, d2 = {"uv/o$c$a", "Luv/o$c;", "Luv/v;", "stream", BuildConfig.FLAVOR, "c", "(Luv/v;)V", "okhttp"}, k = 1, mv = {2, 2, 0}, xi = 48)
        public static final class a extends c {
            @Override // uv.o.c
            public void c(v stream) {
                Intrinsics.checkNotNullParameter(stream, "stream");
                stream.g(b.f33958j, null);
            }
        }

        public void b(@NotNull o connection, @NotNull z settings) {
            Intrinsics.checkNotNullParameter(connection, "connection");
            Intrinsics.checkNotNullParameter(settings, "settings");
        }

        public abstract void c(@NotNull v stream);
    }

    @Metadata(d1 = {"\u0000X\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u000b\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\t\n\u0002\b\u0010\b\u0086\u0004\u0018\u00002\u00020\u00012\b\u0012\u0004\u0012\u00020\u00030\u0002B\u0011\b\u0000\u0012\u0006\u0010\u0005\u001a\u00020\u0004¢\u0006\u0004\b\u0006\u0010\u0007J\u0010\u0010\b\u001a\u00020\u0003H\u0096\u0002¢\u0006\u0004\b\b\u0010\tJ/\u0010\u0011\u001a\u00020\u00032\u0006\u0010\u000b\u001a\u00020\n2\u0006\u0010\r\u001a\u00020\f2\u0006\u0010\u000f\u001a\u00020\u000e2\u0006\u0010\u0010\u001a\u00020\fH\u0016¢\u0006\u0004\b\u0011\u0010\u0012J5\u0010\u0017\u001a\u00020\u00032\u0006\u0010\u000b\u001a\u00020\n2\u0006\u0010\r\u001a\u00020\f2\u0006\u0010\u0013\u001a\u00020\f2\f\u0010\u0016\u001a\b\u0012\u0004\u0012\u00020\u00150\u0014H\u0016¢\u0006\u0004\b\u0017\u0010\u0018J\u001f\u0010\u001b\u001a\u00020\u00032\u0006\u0010\r\u001a\u00020\f2\u0006\u0010\u001a\u001a\u00020\u0019H\u0016¢\u0006\u0004\b\u001b\u0010\u001cJ\u001f\u0010 \u001a\u00020\u00032\u0006\u0010\u001d\u001a\u00020\n2\u0006\u0010\u001f\u001a\u00020\u001eH\u0016¢\u0006\u0004\b \u0010!J\u001d\u0010\"\u001a\u00020\u00032\u0006\u0010\u001d\u001a\u00020\n2\u0006\u0010\u001f\u001a\u00020\u001e¢\u0006\u0004\b\"\u0010!J\u000f\u0010#\u001a\u00020\u0003H\u0016¢\u0006\u0004\b#\u0010\tJ'\u0010'\u001a\u00020\u00032\u0006\u0010$\u001a\u00020\n2\u0006\u0010%\u001a\u00020\f2\u0006\u0010&\u001a\u00020\fH\u0016¢\u0006\u0004\b'\u0010(J'\u0010,\u001a\u00020\u00032\u0006\u0010)\u001a\u00020\f2\u0006\u0010\u001a\u001a\u00020\u00192\u0006\u0010+\u001a\u00020*H\u0016¢\u0006\u0004\b,\u0010-J\u001f\u00100\u001a\u00020\u00032\u0006\u0010\r\u001a\u00020\f2\u0006\u0010/\u001a\u00020.H\u0016¢\u0006\u0004\b0\u00101J/\u00105\u001a\u00020\u00032\u0006\u0010\r\u001a\u00020\f2\u0006\u00102\u001a\u00020\f2\u0006\u00103\u001a\u00020\f2\u0006\u00104\u001a\u00020\nH\u0016¢\u0006\u0004\b5\u00106J-\u00109\u001a\u00020\u00032\u0006\u0010\r\u001a\u00020\f2\u0006\u00107\u001a\u00020\f2\f\u00108\u001a\b\u0012\u0004\u0012\u00020\u00150\u0014H\u0016¢\u0006\u0004\b9\u0010:R\u001a\u0010\u0005\u001a\u00020\u00048\u0000X\u0080\u0004¢\u0006\f\n\u0004\b\u0017\u0010;\u001a\u0004\b<\u0010=¨\u0006>"}, d2 = {"Luv/o$d;", "Luv/u$c;", "Lkotlin/Function0;", BuildConfig.FLAVOR, "Luv/u;", "reader", "<init>", "(Luv/o;Luv/u;)V", "w", "()V", BuildConfig.FLAVOR, "inFinished", BuildConfig.FLAVOR, "streamId", "Lew/g;", Payload.SOURCE, "length", "k", "(ZILew/g;I)V", "associatedStreamId", BuildConfig.FLAVOR, "Luv/d;", "headerBlock", xe.a.f36648e, "(ZIILjava/util/List;)V", "Luv/b;", "errorCode", "d", "(ILuv/b;)V", "clearPrevious", "Luv/z;", "settings", "i", "(ZLuv/z;)V", pm.t.f29212d, "h", "ack", "payload1", "payload2", "l", "(ZII)V", "lastGoodStreamId", "Lew/h;", "debugData", "j", "(ILuv/b;Lew/h;)V", BuildConfig.FLAVOR, "windowSizeIncrement", k6.b.f21144e, "(IJ)V", "streamDependency", "weight", "exclusive", "m", "(IIIZ)V", "promisedStreamId", "requestHeaders", "f", "(IILjava/util/List;)V", "Luv/u;", "getReader$okhttp", "()Luv/u;", "okhttp"}, k = 1, mv = {2, 2, 0}, xi = 48)
    public final class d implements u.c, Function0<Unit> {

        /* renamed from: a, reason: collision with root package name and from kotlin metadata */
        @NotNull
        public final u reader;
        public final /* synthetic */ o b;

        public d(@NotNull o oVar, u reader) {
            Intrinsics.checkNotNullParameter(reader, "reader");
            this.b = oVar;
            this.reader = reader;
        }

        /* JADX WARN: Multi-variable type inference failed */
        public static final Unit u(o oVar, c0 c0Var) {
            oVar.getListener().b(oVar, (z) c0Var.f21573a);
            return Unit.f21504a;
        }

        public static final Unit v(o oVar, v vVar) {
            try {
                oVar.getListener().c(vVar);
            } catch (IOException e10) {
                okhttp3.internal.platform.c.INSTANCE.e().m("Http2Connection.Listener failure for " + oVar.getConnectionName(), 4, e10);
                try {
                    vVar.g(b.f33952d, e10);
                } catch (IOException unused) {
                }
            }
            return Unit.f21504a;
        }

        public static final Unit x(o oVar, int i10, int i11) {
            oVar.Z0(true, i10, i11);
            return Unit.f21504a;
        }

        public static final Unit y(d dVar, boolean z10, z zVar) {
            dVar.t(z10, zVar);
            return Unit.f21504a;
        }

        @Override // uv.u.c
        public void a(boolean inFinished, int streamId, int associatedStreamId, @NotNull List<uv.d> headerBlock) {
            Intrinsics.checkNotNullParameter(headerBlock, "headerBlock");
            if (this.b.M0(streamId)) {
                this.b.E0(streamId, headerBlock, inFinished);
                return;
            }
            final o oVar = this.b;
            synchronized (oVar) {
                v f02 = oVar.f0(streamId);
                if (f02 != null) {
                    Unit unit = Unit.f21504a;
                    f02.A(nv.q.s(headerBlock), inFinished);
                    return;
                }
                if (oVar.isShutdown) {
                    return;
                }
                if (streamId <= oVar.getLastGoodStreamId()) {
                    return;
                }
                if (streamId % 2 == oVar.getNextStreamId() % 2) {
                    return;
                }
                final v vVar = new v(streamId, oVar, false, inFinished, nv.q.s(headerBlock));
                oVar.R0(streamId);
                oVar.h0().put(Integer.valueOf(streamId), vVar);
                qv.c.d(oVar.taskRunner.k(), oVar.getConnectionName() + '[' + streamId + "] onStream", 0L, false, new Function0() { // from class: uv.q
                    @Override // kotlin.jvm.functions.Function0
                    public final Object invoke() {
                        Unit v8;
                        v8 = o.d.v(o.this, vVar);
                        return v8;
                    }
                }, 6, null);
            }
        }

        @Override // uv.u.c
        public void b(int streamId, long windowSizeIncrement) {
            if (streamId == 0) {
                o oVar = this.b;
                synchronized (oVar) {
                    oVar.writeBytesMaximum = oVar.getWriteBytesMaximum() + windowSizeIncrement;
                    Intrinsics.d(oVar, "null cannot be cast to non-null type java.lang.Object");
                    oVar.notifyAll();
                    Unit unit = Unit.f21504a;
                }
                return;
            }
            v f02 = this.b.f0(streamId);
            if (f02 != null) {
                synchronized (f02) {
                    f02.d(windowSizeIncrement);
                    Unit unit2 = Unit.f21504a;
                }
            }
        }

        @Override // uv.u.c
        public void d(int streamId, @NotNull b errorCode) {
            Intrinsics.checkNotNullParameter(errorCode, "errorCode");
            if (this.b.M0(streamId)) {
                this.b.K0(streamId, errorCode);
                return;
            }
            v O0 = this.b.O0(streamId);
            if (O0 != null) {
                O0.B(errorCode);
            }
        }

        @Override // uv.u.c
        public void f(int streamId, int promisedStreamId, @NotNull List<uv.d> requestHeaders) {
            Intrinsics.checkNotNullParameter(requestHeaders, "requestHeaders");
            this.b.G0(promisedStreamId, requestHeaders);
        }

        @Override // uv.u.c
        public void h() {
        }

        @Override // uv.u.c
        public void i(final boolean clearPrevious, @NotNull final z settings) {
            Intrinsics.checkNotNullParameter(settings, "settings");
            qv.c.d(this.b.writerQueue, this.b.getConnectionName() + " applyAndAckSettings", 0L, false, new Function0() { // from class: uv.r
                @Override // kotlin.jvm.functions.Function0
                public final Object invoke() {
                    Unit y10;
                    y10 = o.d.y(o.d.this, clearPrevious, settings);
                    return y10;
                }
            }, 6, null);
        }

        @Override // kotlin.jvm.functions.Function0
        public /* bridge */ /* synthetic */ Unit invoke() {
            w();
            return Unit.f21504a;
        }

        @Override // uv.u.c
        public void j(int lastGoodStreamId, @NotNull b errorCode, @NotNull ew.h debugData) {
            int i10;
            Object[] array;
            Intrinsics.checkNotNullParameter(errorCode, "errorCode");
            Intrinsics.checkNotNullParameter(debugData, "debugData");
            debugData.I();
            o oVar = this.b;
            synchronized (oVar) {
                array = oVar.h0().values().toArray(new v[0]);
                oVar.isShutdown = true;
                Unit unit = Unit.f21504a;
            }
            for (v vVar : (v[]) array) {
                if (vVar.getId() > lastGoodStreamId && vVar.v()) {
                    vVar.B(b.f33958j);
                    this.b.O0(vVar.getId());
                }
            }
        }

        @Override // uv.u.c
        public void k(boolean inFinished, int streamId, @NotNull ew.g source, int length) {
            Intrinsics.checkNotNullParameter(source, "source");
            if (this.b.M0(streamId)) {
                this.b.z0(streamId, source, length, inFinished);
                return;
            }
            v f02 = this.b.f0(streamId);
            if (f02 == null) {
                this.b.e1(streamId, b.f33952d);
                long j10 = length;
                this.b.W0(j10);
                source.skip(j10);
                return;
            }
            f02.z(source, length);
            if (inFinished) {
                f02.A(mv.y.f24789c, true);
            }
        }

        @Override // uv.u.c
        public void l(boolean ack, final int payload1, final int payload2) {
            if (!ack) {
                qv.c cVar = this.b.writerQueue;
                String str = this.b.getConnectionName() + " ping";
                final o oVar = this.b;
                qv.c.d(cVar, str, 0L, false, new Function0() { // from class: uv.p
                    @Override // kotlin.jvm.functions.Function0
                    public final Object invoke() {
                        Unit x5;
                        x5 = o.d.x(o.this, payload1, payload2);
                        return x5;
                    }
                }, 6, null);
                return;
            }
            o oVar2 = this.b;
            synchronized (oVar2) {
                try {
                    if (payload1 == 1) {
                        oVar2.intervalPongsReceived++;
                    } else if (payload1 != 2) {
                        if (payload1 == 3) {
                            oVar2.awaitPongsReceived++;
                            Intrinsics.d(oVar2, "null cannot be cast to non-null type java.lang.Object");
                            oVar2.notifyAll();
                        }
                        Unit unit = Unit.f21504a;
                    } else {
                        oVar2.degradedPongsReceived++;
                    }
                } catch (Throwable th2) {
                    throw th2;
                }
            }
        }

        @Override // uv.u.c
        public void m(int streamId, int streamDependency, int weight, boolean exclusive) {
        }

        /* JADX WARN: Multi-variable type inference failed */
        /* JADX WARN: Type inference failed for: r0v25 */
        /* JADX WARN: Type inference failed for: r0v3 */
        /* JADX WARN: Type inference failed for: r0v4, types: [T, uv.z] */
        public final void t(boolean clearPrevious, @NotNull z settings) {
            Object r02 = null;
            long c10;
            int i10;
            v[] vVarArr;
            v[] vVarArr2;
            z settings2 = settings;
            Intrinsics.checkNotNullParameter(settings2, "settings");
            final c0 c0Var = new c0();
            w writer = this.b.getWriter();
            final o oVar = this.b;
            synchronized (writer) {
                synchronized (oVar) {
                    try {
                        z peerSettings = oVar.getPeerSettings();
                        if (clearPrevious) {
                            r02 = settings2;
                        } else {
                            z zVar = new z();
                            zVar.g(peerSettings);
                            zVar.g(settings2);
                            r02 = zVar;
                        }
                        c0Var.f21573a = r02;
                        c10 = r02.c() - peerSettings.c();
                        if (c10 != 0 && !oVar.h0().isEmpty()) {
                            vVarArr = (v[]) oVar.h0().values().toArray(new v[0]);
                            vVarArr2 = vVarArr;
                            oVar.S0((z) c0Var.f21573a);
                            qv.c.d(oVar.settingsListenerQueue, oVar.getConnectionName() + " onSettings", 0L, false, new Function0() { // from class: uv.s
                                @Override // kotlin.jvm.functions.Function0
                                public final Object invoke() {
                                    Unit u8;
                                    u8 = o.d.u(o.this, c0Var);
                                    return u8;
                                }
                            }, 6, null);
                            Unit unit = Unit.f21504a;
                        }
                        vVarArr = null;
                        vVarArr2 = vVarArr;
                        oVar.S0((z) c0Var.f21573a);
                        qv.c.d(oVar.settingsListenerQueue, oVar.getConnectionName() + " onSettings", 0L, false, new Function0() { // from class: uv.s
                            @Override // kotlin.jvm.functions.Function0
                            public final Object invoke() {
                                Unit u8;
                                u8 = o.d.u(o.this, c0Var);
                                return u8;
                            }
                        }, 6, null);
                        Unit unit2 = Unit.f21504a;
                    } catch (Throwable th2) {
                        throw th2;
                    }
                }
                try {
                    oVar.getWriter().a((z) c0Var.f21573a);
                } catch (IOException e10) {
                    oVar.N(e10);
                }
                Unit unit3 = Unit.f21504a;
            }
            if (vVarArr2 != null) {
                for (v vVar : vVarArr2) {
                    synchronized (vVar) {
                        vVar.d(c10);
                        Unit unit4 = Unit.f21504a;
                    }
                }
            }
        }

        /* JADX WARN: Multi-variable type inference failed */
        /* JADX WARN: Type inference failed for: r0v0, types: [uv.b] */
        /* JADX WARN: Type inference failed for: r0v3 */
        /* JADX WARN: Type inference failed for: r0v5, types: [java.io.Closeable, uv.u] */
        public void w() {
            b bVar;
            b bVar2 = b.f33953e;
            IOException e10 = null;
            try {
                try {
                    this.reader.c(this);
                    while (this.reader.b(false, this)) {
                    }
                    b bVar3 = b.f33951c;
                    try {
                        this.b.L(bVar3, b.f33959k, null);
                        bVar = bVar3;
                    } catch (IOException e11) {
                        e10 = e11;
                        b bVar4 = b.f33952d;
                        o oVar = this.b;
                        oVar.L(bVar4, bVar4, e10);
                        bVar = oVar;
                        bVar2 = this.reader;
                        nv.n.f(bVar2);
                    }
                } catch (Throwable th2) {
                    th = th2;
                    this.b.L(bVar, bVar2, e10);
                    nv.n.f(this.reader);
                    throw th;
                }
            } catch (IOException e12) {
                e10 = e12;
            } catch (Throwable th3) {
                th = th3;
                bVar = bVar2;
                this.b.L(bVar, bVar2, e10);
                nv.n.f(this.reader);
                throw th;
            }
            bVar2 = this.reader;
            nv.n.f(bVar2);
        }
    }

    static {
        z zVar = new z();
        zVar.h(4, 65535);
        zVar.h(5, 16384);
        D = zVar;
    }

    public o(@NotNull a builder) {
        Intrinsics.checkNotNullParameter(builder, "builder");
        boolean client = builder.getClient();
        this.client = client;
        this.listener = builder.getListener();
        this.streams = new LinkedHashMap();
        String d10 = builder.d();
        this.connectionName = d10;
        this.nextStreamId = builder.getClient() ? 3 : 2;
        qv.d taskRunner = builder.getTaskRunner();
        this.taskRunner = taskRunner;
        qv.c k10 = taskRunner.k();
        this.writerQueue = k10;
        this.pushQueue = taskRunner.k();
        this.settingsListenerQueue = taskRunner.k();
        this.pushObserver = builder.getPushObserver();
        this.flowControlListener = builder.getFlowControlListener();
        z zVar = new z();
        if (builder.getClient()) {
            zVar.h(4, 16777216);
        }
        this.okHttpSettings = zVar;
        this.peerSettings = D;
        this.readBytes = new WindowCounter(0);
        this.writeBytesMaximum = this.peerSettings.c();
        rv.a i10 = builder.i();
        this.socket = i10;
        this.writer = new w(i10.getSink(), client);
        this.readerRunnable = new d(this, new u(i10.getSource(), client));
        this.currentPushRequests = new LinkedHashSet();
        if (builder.getPingIntervalMillis() != 0) {
            final long nanos = TimeUnit.MILLISECONDS.toNanos(builder.getPingIntervalMillis());
            k10.k(d10 + " ping", nanos, new Function0() { // from class: uv.g
                @Override // kotlin.jvm.functions.Function0
                public final Object invoke() {
                    long k11;
                    k11 = o.k(o.this, nanos);
                    return Long.valueOf(k11);
                }
            });
        }
    }

    public static final Unit A0(o oVar, int i10, List list, boolean z10) {
        boolean c10 = oVar.pushObserver.c(i10, list, z10);
        if (c10) {
            try {
                oVar.writer.n(i10, b.f33959k);
            } catch (IOException unused) {
            }
        }
        if (c10 || z10) {
            synchronized (oVar) {
                oVar.currentPushRequests.remove(Integer.valueOf(i10));
                Unit unit = Unit.f21504a;
            }
        }
        return Unit.f21504a;
    }

    public static final Unit F0(o oVar, int i10, List list) {
        if (oVar.pushObserver.b(i10, list)) {
            try {
                oVar.writer.n(i10, b.f33959k);
                synchronized (oVar) {
                    oVar.currentPushRequests.remove(Integer.valueOf(i10));
                    Unit unit = Unit.f21504a;
                }
            } catch (IOException unused) {
            }
        }
        return Unit.f21504a;
    }

    public static final Unit I0(o oVar, int i10, b bVar) {
        oVar.pushObserver.a(i10, bVar);
        synchronized (oVar) {
            oVar.currentPushRequests.remove(Integer.valueOf(i10));
        }
        return Unit.f21504a;
    }

    public static final Unit P0(o oVar) {
        oVar.Z0(false, 2, 0);
        return Unit.f21504a;
    }

    public static /* synthetic */ void V0(o oVar, boolean z10, int i10, Object obj) {
        if ((i10 & 1) != 0) {
            z10 = true;
        }
        oVar.U0(z10);
    }

    public static final Unit c1(o oVar, int i10, b bVar) {
        try {
            oVar.a1(i10, bVar);
        } catch (IOException e10) {
            oVar.N(e10);
        }
        return Unit.f21504a;
    }

    public static final Unit f1(o oVar, int i10, long j10) {
        try {
            oVar.writer.p(i10, j10);
        } catch (IOException e10) {
            oVar.N(e10);
        }
        return Unit.f21504a;
    }

    public static final long k(o oVar, long j10) {
        boolean z10;
        synchronized (oVar) {
            long j11 = oVar.intervalPongsReceived;
            long j12 = oVar.intervalPingsSent;
            if (j11 < j12) {
                z10 = true;
            } else {
                oVar.intervalPingsSent = j12 + 1;
                z10 = false;
            }
        }
        if (z10) {
            oVar.N(null);
            return -1L;
        }
        oVar.Z0(false, 1, 0);
        return j10;
    }

    public static final Unit x0(o oVar, int i10, ew.e eVar, int i11, boolean z10) {
        try {
            boolean d10 = oVar.pushObserver.d(i10, eVar, i11, z10);
            if (d10) {
                oVar.writer.n(i10, b.f33959k);
            }
            if (d10 || z10) {
                synchronized (oVar) {
                    oVar.currentPushRequests.remove(Integer.valueOf(i10));
                    Unit unit = Unit.f21504a;
                }
            }
        } catch (IOException unused) {
        }
        return Unit.f21504a;
    }

    public final void E0(final int streamId, @NotNull final List<uv.d> requestHeaders, final boolean inFinished) {
        Intrinsics.checkNotNullParameter(requestHeaders, "requestHeaders");
        qv.c.d(this.pushQueue, this.connectionName + '[' + streamId + "] onHeaders", 0L, false, new Function0() { // from class: uv.n
            @Override // kotlin.jvm.functions.Function0
            public final Object invoke() {
                Unit A0;
                A0 = o.A0(o.this, streamId, requestHeaders, inFinished);
                return A0;
            }
        }, 6, null);
    }

    public final void G0(final int streamId, @NotNull final List<uv.d> requestHeaders) {
        Intrinsics.checkNotNullParameter(requestHeaders, "requestHeaders");
        synchronized (this) {
            if (this.currentPushRequests.contains(Integer.valueOf(streamId))) {
                e1(streamId, b.f33952d);
                return;
            }
            this.currentPushRequests.add(Integer.valueOf(streamId));
            qv.c.d(this.pushQueue, this.connectionName + '[' + streamId + "] onRequest", 0L, false, new Function0() { // from class: uv.l
                @Override // kotlin.jvm.functions.Function0
                public final Object invoke() {
                    Unit F0;
                    F0 = o.F0(o.this, streamId, requestHeaders);
                    return F0;
                }
            }, 6, null);
        }
    }

    public final void K0(final int streamId, @NotNull final b errorCode) {
        Intrinsics.checkNotNullParameter(errorCode, "errorCode");
        qv.c.d(this.pushQueue, this.connectionName + '[' + streamId + "] onReset", 0L, false, new Function0() { // from class: uv.m
            @Override // kotlin.jvm.functions.Function0
            public final Object invoke() {
                Unit I0;
                I0 = o.I0(o.this, streamId, errorCode);
                return I0;
            }
        }, 6, null);
    }

    public final void L(@NotNull b connectionCode, @NotNull b streamCode, @Nullable IOException cause) {
        int i10;
        Object[] objArr;
        Intrinsics.checkNotNullParameter(connectionCode, "connectionCode");
        Intrinsics.checkNotNullParameter(streamCode, "streamCode");
        if (nv.q.b && Thread.holdsLock(this)) {
            throw new AssertionError("Thread " + Thread.currentThread().getName() + " MUST NOT hold lock on " + this);
        }
        try {
            T0(connectionCode);
        } catch (IOException unused) {
        }
        synchronized (this) {
            try {
                if (this.streams.isEmpty()) {
                    objArr = null;
                } else {
                    objArr = this.streams.values().toArray(new v[0]);
                    this.streams.clear();
                }
                Unit unit = Unit.f21504a;
            } catch (Throwable th2) {
                throw th2;
            }
        }
        v[] vVarArr = (v[]) objArr;
        if (vVarArr != null) {
            for (v vVar : vVarArr) {
                try {
                    vVar.g(streamCode, cause);
                } catch (IOException unused2) {
                }
            }
        }
        try {
            this.writer.close();
        } catch (IOException unused3) {
        }
        try {
            this.socket.cancel();
        } catch (IOException unused4) {
        }
        this.writerQueue.q();
        this.pushQueue.q();
        this.settingsListenerQueue.q();
    }

    public final boolean M0(int streamId) {
        return streamId != 0 && (streamId & 1) == 0;
    }

    public final void N(IOException e10) {
        b bVar = b.f33952d;
        L(bVar, bVar, e10);
    }

    /* renamed from: O, reason: from getter */
    public final boolean getClient() {
        return this.client;
    }

    @Nullable
    public final v O0(int streamId) {
        v remove;
        synchronized (this) {
            remove = this.streams.remove(Integer.valueOf(streamId));
            Intrinsics.d(this, "null cannot be cast to non-null type java.lang.Object");
            notifyAll();
        }
        return remove;
    }

    @NotNull
    /* renamed from: Q, reason: from getter */
    public final String getConnectionName() {
        return this.connectionName;
    }

    public final void Q0() {
        synchronized (this) {
            long j10 = this.degradedPongsReceived;
            long j11 = this.degradedPingsSent;
            if (j10 < j11) {
                return;
            }
            this.degradedPingsSent = j11 + 1;
            this.degradedPongDeadlineNs = System.nanoTime() + 1000000000;
            Unit unit = Unit.f21504a;
            qv.c.d(this.writerQueue, this.connectionName + " ping", 0L, false, new Function0() { // from class: uv.i
                @Override // kotlin.jvm.functions.Function0
                public final Object invoke() {
                    Unit P0;
                    P0 = o.P0(o.this);
                    return P0;
                }
            }, 6, null);
        }
    }

    public final void R0(int i10) {
        this.lastGoodStreamId = i10;
    }

    public final void S0(@NotNull z zVar) {
        Intrinsics.checkNotNullParameter(zVar, "<set-?>");
        this.peerSettings = zVar;
    }

    @NotNull
    /* renamed from: T, reason: from getter */
    public final uv.c getFlowControlListener() {
        return this.flowControlListener;
    }

    public final void T0(@NotNull b statusCode) {
        Intrinsics.checkNotNullParameter(statusCode, "statusCode");
        synchronized (this.writer) {
            synchronized (this) {
                if (this.isShutdown) {
                    return;
                }
                this.isShutdown = true;
                int i10 = this.lastGoodStreamId;
                Unit unit = Unit.f21504a;
                this.writer.f(i10, statusCode, nv.n.f26634a);
            }
        }
    }

    public final void U0(boolean sendConnectionPreface) {
        if (sendConnectionPreface) {
            this.writer.b();
            this.writer.o(this.okHttpSettings);
            if (this.okHttpSettings.c() != 65535) {
                this.writer.p(0, r9 - 65535);
            }
        }
        qv.c.d(this.taskRunner.k(), this.connectionName, 0L, false, this.readerRunnable, 6, null);
    }

    public final void W0(long read) {
        synchronized (this) {
            try {
                WindowCounter.c(this.readBytes, read, 0L, 2, null);
                long a10 = this.readBytes.a();
                if (a10 >= this.okHttpSettings.c() / 2) {
                    g1(0, a10);
                    WindowCounter.c(this.readBytes, 0L, a10, 1, null);
                }
                this.flowControlListener.b(this.readBytes);
                Unit unit = Unit.f21504a;
            } catch (Throwable th2) {
                throw th2;
            }
        }
    }

    /* JADX WARN: Code restructure failed: missing block: B:21:0x003a, code lost:
    
        r2 = java.lang.Math.min((int) java.lang.Math.min(r12, r6 - r4), r8.writer.h());
        r6 = r2;
        r8.writeBytesTotal += r6;
        r4 = kotlin.Unit.f21504a;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final void X0(int r9, boolean r10, @org.jetbrains.annotations.Nullable ew.e r11, long r12) {
        /*
            r8 = this;
            r0 = 0
            int r2 = (r12 > r0 ? 1 : (r12 == r0 ? 0 : -1))
            r3 = 0
            if (r2 != 0) goto Ld
            uv.w r12 = r8.writer
            r12.c(r10, r9, r11, r3)
            return
        Ld:
            int r2 = (r12 > r0 ? 1 : (r12 == r0 ? 0 : -1))
            if (r2 <= 0) goto L71
            monitor-enter(r8)
        L12:
            long r4 = r8.writeBytesTotal     // Catch: java.lang.Throwable -> L2f java.lang.InterruptedException -> L62
            long r6 = r8.writeBytesMaximum     // Catch: java.lang.Throwable -> L2f java.lang.InterruptedException -> L62
            int r2 = (r4 > r6 ? 1 : (r4 == r6 ? 0 : -1))
            if (r2 < 0) goto L39
            java.util.Map<java.lang.Integer, uv.v> r2 = r8.streams     // Catch: java.lang.Throwable -> L2f java.lang.InterruptedException -> L62
            java.lang.Integer r4 = java.lang.Integer.valueOf(r9)     // Catch: java.lang.Throwable -> L2f java.lang.InterruptedException -> L62
            boolean r2 = r2.containsKey(r4)     // Catch: java.lang.Throwable -> L2f java.lang.InterruptedException -> L62
            if (r2 == 0) goto L31
            java.lang.String r2 = "null cannot be cast to non-null type java.lang.Object"
            kotlin.jvm.internal.Intrinsics.d(r8, r2)     // Catch: java.lang.Throwable -> L2f java.lang.InterruptedException -> L62
            r8.wait()     // Catch: java.lang.Throwable -> L2f java.lang.InterruptedException -> L62
            goto L12
        L2f:
            r9 = move-exception
            goto L6f
        L31:
            java.io.IOException r9 = new java.io.IOException     // Catch: java.lang.Throwable -> L2f java.lang.InterruptedException -> L62
            java.lang.String r10 = "stream closed"
            r9.<init>(r10)     // Catch: java.lang.Throwable -> L2f java.lang.InterruptedException -> L62
            throw r9     // Catch: java.lang.Throwable -> L2f java.lang.InterruptedException -> L62
        L39:
            long r6 = r6 - r4
            long r4 = java.lang.Math.min(r12, r6)     // Catch: java.lang.Throwable -> L2f
            int r2 = (int) r4     // Catch: java.lang.Throwable -> L2f
            uv.w r4 = r8.writer     // Catch: java.lang.Throwable -> L2f
            int r4 = r4.getMaxFrameSize()     // Catch: java.lang.Throwable -> L2f
            int r2 = java.lang.Math.min(r2, r4)     // Catch: java.lang.Throwable -> L2f
            long r4 = r8.writeBytesTotal     // Catch: java.lang.Throwable -> L2f
            long r6 = (long) r2     // Catch: java.lang.Throwable -> L2f
            long r4 = r4 + r6
            r8.writeBytesTotal = r4     // Catch: java.lang.Throwable -> L2f
            kotlin.Unit r4 = kotlin.Unit.f21504a     // Catch: java.lang.Throwable -> L2f
            monitor-exit(r8)
            long r12 = r12 - r6
            uv.w r4 = r8.writer
            if (r10 == 0) goto L5d
            int r5 = (r12 > r0 ? 1 : (r12 == r0 ? 0 : -1))
            if (r5 != 0) goto L5d
            r5 = 1
            goto L5e
        L5d:
            r5 = r3
        L5e:
            r4.c(r5, r9, r11, r2)
            goto Ld
        L62:
            java.lang.Thread r9 = java.lang.Thread.currentThread()     // Catch: java.lang.Throwable -> L2f
            r9.interrupt()     // Catch: java.lang.Throwable -> L2f
            java.io.InterruptedIOException r9 = new java.io.InterruptedIOException     // Catch: java.lang.Throwable -> L2f
            r9.<init>()     // Catch: java.lang.Throwable -> L2f
            throw r9     // Catch: java.lang.Throwable -> L2f
        L6f:
            monitor-exit(r8)
            throw r9
        L71:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: uv.o.X0(int, boolean, ew.e, long):void");
    }

    /* renamed from: Y, reason: from getter */
    public final int getLastGoodStreamId() {
        return this.lastGoodStreamId;
    }

    public final void Y0(int streamId, boolean outFinished, @NotNull List<uv.d> alternating) {
        Intrinsics.checkNotNullParameter(alternating, "alternating");
        this.writer.g(outFinished, streamId, alternating);
    }

    public final void Z0(boolean reply, int payload1, int payload2) {
        try {
            this.writer.k(reply, payload1, payload2);
        } catch (IOException e10) {
            N(e10);
        }
    }

    public final void a1(int streamId, @NotNull b statusCode) {
        Intrinsics.checkNotNullParameter(statusCode, "statusCode");
        this.writer.n(streamId, statusCode);
    }

    @NotNull
    /* renamed from: b0, reason: from getter */
    public final c getListener() {
        return this.listener;
    }

    /* renamed from: c0, reason: from getter */
    public final int getNextStreamId() {
        return this.nextStreamId;
    }

    @Override // java.io.Closeable, java.lang.AutoCloseable
    public void close() {
        L(b.f33951c, b.f33959k, null);
    }

    @NotNull
    /* renamed from: d0, reason: from getter */
    public final z getOkHttpSettings() {
        return this.okHttpSettings;
    }

    @NotNull
    /* renamed from: e0, reason: from getter */
    public final z getPeerSettings() {
        return this.peerSettings;
    }

    public final void e1(final int streamId, @NotNull final b errorCode) {
        Intrinsics.checkNotNullParameter(errorCode, "errorCode");
        qv.c.d(this.writerQueue, this.connectionName + '[' + streamId + "] writeSynReset", 0L, false, new Function0() { // from class: uv.j
            @Override // kotlin.jvm.functions.Function0
            public final Object invoke() {
                Unit c12;
                c12 = o.c1(o.this, streamId, errorCode);
                return c12;
            }
        }, 6, null);
    }

    @Nullable
    public final v f0(int id2) {
        v vVar;
        synchronized (this) {
            vVar = this.streams.get(Integer.valueOf(id2));
        }
        return vVar;
    }

    public final void flush() {
        this.writer.flush();
    }

    public final void g1(final int streamId, final long unacknowledgedBytesRead) {
        qv.c.d(this.writerQueue, this.connectionName + '[' + streamId + "] windowUpdate", 0L, false, new Function0() { // from class: uv.h
            @Override // kotlin.jvm.functions.Function0
            public final Object invoke() {
                Unit f12;
                f12 = o.f1(o.this, streamId, unacknowledgedBytesRead);
                return f12;
            }
        }, 6, null);
    }

    @NotNull
    public final Map<Integer, v> h0() {
        return this.streams;
    }

    /* renamed from: i0, reason: from getter */
    public final long getWriteBytesMaximum() {
        return this.writeBytesMaximum;
    }

    @NotNull
    /* renamed from: k0, reason: from getter */
    public final w getWriter() {
        return this.writer;
    }

    public final boolean n0(long nowNs) {
        synchronized (this) {
            if (this.isShutdown) {
                return false;
            }
            if (this.degradedPongsReceived < this.degradedPingsSent) {
                if (nowNs >= this.degradedPongDeadlineNs) {
                    return false;
                }
            }
            return true;
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:25:0x004d A[Catch: all -> 0x0043, TryCatch #1 {all -> 0x0043, blocks: (B:15:0x0027, B:17:0x002c, B:19:0x0034, B:23:0x0047, B:25:0x004d, B:26:0x0056, B:43:0x0082, B:44:0x0087), top: B:11:0x001a }] */
    /* JADX WARN: Removed duplicated region for block: B:29:0x005b A[Catch: all -> 0x0061, TryCatch #0 {all -> 0x0061, blocks: (B:27:0x0058, B:29:0x005b, B:35:0x0064, B:37:0x0068, B:38:0x0076, B:39:0x007d, B:47:0x0088, B:48:0x0089), top: B:3:0x0005 }] */
    /* JADX WARN: Removed duplicated region for block: B:32:0x0070  */
    /* JADX WARN: Removed duplicated region for block: B:35:0x0064 A[Catch: all -> 0x0061, TryCatch #0 {all -> 0x0061, blocks: (B:27:0x0058, B:29:0x005b, B:35:0x0064, B:37:0x0068, B:38:0x0076, B:39:0x007d, B:47:0x0088, B:48:0x0089), top: B:3:0x0005 }] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final uv.v s0(int r10, java.util.List<uv.d> r11, boolean r12) {
        /*
            r9 = this;
            r3 = r12 ^ 1
            uv.w r6 = r9.writer
            monitor-enter(r6)
            monitor-enter(r9)     // Catch: java.lang.Throwable -> L8a
            int r0 = r9.nextStreamId     // Catch: java.lang.Throwable -> L7e
            r1 = 1073741823(0x3fffffff, float:1.9999999)
            if (r0 <= r1) goto L18
            uv.b r0 = uv.b.f33958j     // Catch: java.lang.Throwable -> L13
            r9.T0(r0)     // Catch: java.lang.Throwable -> L13
            goto L18
        L13:
            r0 = move-exception
            r10 = r0
            r2 = r9
            goto L88
        L18:
            boolean r0 = r9.isShutdown     // Catch: java.lang.Throwable -> L7e
            if (r0 != 0) goto L81
            int r1 = r9.nextStreamId     // Catch: java.lang.Throwable -> L7e
            int r0 = r1 + 2
            r9.nextStreamId = r0     // Catch: java.lang.Throwable -> L7e
            uv.v r0 = new uv.v     // Catch: java.lang.Throwable -> L7e
            r5 = 0
            r4 = 0
            r2 = r9
            r0.<init>(r1, r2, r3, r4, r5)     // Catch: java.lang.Throwable -> L43
            if (r12 == 0) goto L46
            long r4 = r2.writeBytesTotal     // Catch: java.lang.Throwable -> L43
            long r7 = r2.writeBytesMaximum     // Catch: java.lang.Throwable -> L43
            int r12 = (r4 > r7 ? 1 : (r4 == r7 ? 0 : -1))
            if (r12 >= 0) goto L46
            long r4 = r0.getWriteBytesTotal()     // Catch: java.lang.Throwable -> L43
            long r7 = r0.getWriteBytesMaximum()     // Catch: java.lang.Throwable -> L43
            int r12 = (r4 > r7 ? 1 : (r4 == r7 ? 0 : -1))
            if (r12 < 0) goto L41
            goto L46
        L41:
            r12 = 0
            goto L47
        L43:
            r0 = move-exception
        L44:
            r10 = r0
            goto L88
        L46:
            r12 = 1
        L47:
            boolean r4 = r0.w()     // Catch: java.lang.Throwable -> L43
            if (r4 == 0) goto L56
            java.util.Map<java.lang.Integer, uv.v> r4 = r2.streams     // Catch: java.lang.Throwable -> L43
            java.lang.Integer r5 = java.lang.Integer.valueOf(r1)     // Catch: java.lang.Throwable -> L43
            r4.put(r5, r0)     // Catch: java.lang.Throwable -> L43
        L56:
            kotlin.Unit r4 = kotlin.Unit.f21504a     // Catch: java.lang.Throwable -> L43
            monitor-exit(r9)     // Catch: java.lang.Throwable -> L61
            if (r10 != 0) goto L64
            uv.w r10 = r2.writer     // Catch: java.lang.Throwable -> L61
            r10.g(r3, r1, r11)     // Catch: java.lang.Throwable -> L61
            goto L6d
        L61:
            r0 = move-exception
        L62:
            r10 = r0
            goto L8d
        L64:
            boolean r3 = r2.client     // Catch: java.lang.Throwable -> L61
            if (r3 != 0) goto L76
            uv.w r3 = r2.writer     // Catch: java.lang.Throwable -> L61
            r3.m(r10, r1, r11)     // Catch: java.lang.Throwable -> L61
        L6d:
            monitor-exit(r6)
            if (r12 == 0) goto L75
            uv.w r10 = r2.writer
            r10.flush()
        L75:
            return r0
        L76:
            java.lang.String r10 = "client streams shouldn't have associated stream IDs"
            java.lang.IllegalArgumentException r11 = new java.lang.IllegalArgumentException     // Catch: java.lang.Throwable -> L61
            r11.<init>(r10)     // Catch: java.lang.Throwable -> L61
            throw r11     // Catch: java.lang.Throwable -> L61
        L7e:
            r0 = move-exception
            r2 = r9
            goto L44
        L81:
            r2 = r9
            uv.a r10 = new uv.a     // Catch: java.lang.Throwable -> L43
            r10.<init>()     // Catch: java.lang.Throwable -> L43
            throw r10     // Catch: java.lang.Throwable -> L43
        L88:
            monitor-exit(r9)     // Catch: java.lang.Throwable -> L61
            throw r10     // Catch: java.lang.Throwable -> L61
        L8a:
            r0 = move-exception
            r2 = r9
            goto L62
        L8d:
            monitor-exit(r6)
            throw r10
        */
        throw new UnsupportedOperationException("Method not decompiled: uv.o.s0(int, java.util.List, boolean):uv.v");
    }

    @NotNull
    public final v w0(@NotNull List<uv.d> requestHeaders, boolean out) {
        Intrinsics.checkNotNullParameter(requestHeaders, "requestHeaders");
        return s0(0, requestHeaders, out);
    }

    public final void z0(final int streamId, @NotNull ew.g source, final int byteCount, final boolean inFinished) {
        Intrinsics.checkNotNullParameter(source, "source");
        final ew.e eVar = new ew.e();
        long j10 = byteCount;
        source.w1(j10);
        source.f3(eVar, j10);
        qv.c.d(this.pushQueue, this.connectionName + '[' + streamId + "] onData", 0L, false, new Function0() { // from class: uv.k
            @Override // kotlin.jvm.functions.Function0
            public final Object invoke() {
                Unit x02;
                x02 = o.x0(o.this, streamId, eVar, byteCount, inFinished);
                return x02;
            }
        }, 6, null);
    }
}
