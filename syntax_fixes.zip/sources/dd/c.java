package dd;

import android.os.Build;
import android.view.View;
import android.window.BackEvent;
import android.window.OnBackAnimationCallback;
import android.window.OnBackInvokedCallback;
import android.window.OnBackInvokedDispatcher;
import androidx.annotation.NonNull;
import e.BackEventCompat;
import java.util.Objects;

/* loaded from: classes2.dex */
public final class c {

    /* renamed from: a, reason: collision with root package name */
    public final d f12168a = a();

    @NonNull
    public final dd.b b;

    /* renamed from: c, reason: collision with root package name */
    @NonNull
    public final View f12169c;

    public static class b implements d {

        /* renamed from: a, reason: collision with root package name */
        public OnBackInvokedCallback f12170a;

        public b() {
        }

        @Override // dd.c.d
        public void a(@NonNull View view) {
            OnBackInvokedDispatcher findOnBackInvokedDispatcher = view.findOnBackInvokedDispatcher();
            if (findOnBackInvokedDispatcher == null) {
                return;
            }
            findOnBackInvokedDispatcher.unregisterOnBackInvokedCallback(this.f12170a);
            this.f12170a = null;
        }

        @Override // dd.c.d
        public void b(@NonNull dd.b bVar, @NonNull View view, boolean z10) {
            OnBackInvokedDispatcher findOnBackInvokedDispatcher;
            if (this.f12170a == null && (findOnBackInvokedDispatcher = view.findOnBackInvokedDispatcher()) != null) {
                OnBackInvokedCallback c10 = c(bVar);
                this.f12170a = c10;
                findOnBackInvokedDispatcher.registerOnBackInvokedCallback(z10 ? 1000000 : 0, c10);
            }
        }

        public OnBackInvokedCallback c(@NonNull final dd.b bVar) {
            Objects.requireNonNull(bVar);
            return new OnBackInvokedCallback() { // from class: dd.d
                public final void onBackInvoked() {
                    b.this.d();
                }
            };
        }

        public boolean d() {
            return this.f12170a != null;
        }
    }

    /* renamed from: dd.c$c, reason: collision with other inner class name */
    public static class C0219c extends b {

        /* renamed from: dd.c$c$a */
        public class a implements OnBackAnimationCallback {

            /* renamed from: a, reason: collision with root package name */
            public final /* synthetic */ dd.b f12171a;

            public a(dd.b bVar) {
                this.f12171a = bVar;
            }

            public void onBackCancelled() {
                if (C0219c.this.d()) {
                    this.f12171a.b();
                }
            }

            public void onBackInvoked() {
                this.f12171a.d();
            }

            public void onBackProgressed(@NonNull BackEvent backEvent) {
                if (C0219c.this.d()) {
                    this.f12171a.a(new BackEventCompat(backEvent));
                }
            }

            public void onBackStarted(@NonNull BackEvent backEvent) {
                if (C0219c.this.d()) {
                    this.f12171a.c(new BackEventCompat(backEvent));
                }
            }
        }

        public C0219c() {
            super();
        }

        @Override // dd.c.b
        public OnBackInvokedCallback c(@NonNull dd.b bVar) {
            return new a(bVar);
        }
    }

    public interface d {
        void a(@NonNull View view);

        void b(@NonNull dd.b bVar, @NonNull View view, boolean z10);
    }

    public c(@NonNull dd.b bVar, @NonNull View view) {
        this.b = bVar;
        this.f12169c = view;
    }

    public static d a() {
        int i10 = Build.VERSION.SDK_INT;
        if (i10 >= 34) {
            return new C0219c();
        }
        if (i10 >= 33) {
            return new b();
        }
        return null;
    }

    public void b() {
        c(false);
    }

    public final void c(boolean z10) {
        d dVar = this.f12168a;
        if (dVar != null) {
            dVar.b(this.b, this.f12169c, z10);
        }
    }

    public void d() {
        d dVar = this.f12168a;
        if (dVar != null) {
            dVar.a(this.f12169c);
        }
    }


    // --- восстановлено из DEX (dd/c$c$a) ---
    public static class a implements android.window.OnBackAnimationCallback {
        dd.b a;
        dd.c.c b;
        public a(dd.c.c p0, dd.b p1) { }
        public void onBackCancelled() { throw new UnsupportedOperationException("stub"); }
        public void onBackInvoked() { throw new UnsupportedOperationException("stub"); }
        public void onBackProgressed(android.window.BackEvent p0) { throw new UnsupportedOperationException("stub"); }
        public void onBackStarted(android.window.BackEvent p0) { throw new UnsupportedOperationException("stub"); }
    }
}
