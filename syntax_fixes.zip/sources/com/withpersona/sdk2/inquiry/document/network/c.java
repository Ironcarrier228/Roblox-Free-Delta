package com.withpersona.sdk2.inquiry.document.network;

import av.a0;
import av.g1;
import av.h2;
import av.l0;
import av.p0;
import av.q0;
import av.w0;
import com.github.luben.zstd.BuildConfig;
import com.withpersona.sdk2.inquiry.network.core.GenericFileUploadErrorResponse;
import com.withpersona.sdk2.inquiry.network.core.InternalErrorInfo;
import com.withpersona.sdk2.inquiry.network.core.NetworkCallResult;
import com.withpersona.sdk2.inquiry.network.core.NetworkUtilsKt;
import dv.i;
import gu.m;
import java.io.File;
import java.util.List;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.collections.p;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import ln.o;
import ls.j;
import mv.c0;
import no.e;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import sw.x;
import xq.k;

@Metadata(d1 = {"\u0000V\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0002\b\b\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0002\b\f\n\u0002\u0018\u0002\n\u0002\b\u0004\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u00012\b\u0012\u0004\u0012\u00020\u00020\u0003:\u0002!\u0012B9\b\u0002\u0012\u0006\u0010\u0005\u001a\u00020\u0004\u0012\u0006\u0010\u0007\u001a\u00020\u0006\u0012\u0006\u0010\b\u001a\u00020\u0004\u0012\u0006\u0010\n\u001a\u00020\t\u0012\u0006\u0010\f\u001a\u00020\u000b\u0012\u0006\u0010\u000e\u001a\u00020\r¢\u0006\u0004\b\u000f\u0010\u0010J\u001b\u0010\u0012\u001a\u00020\r2\n\u0010\u0011\u001a\u0006\u0012\u0002\b\u00030\u0001H\u0016¢\u0006\u0004\b\u0012\u0010\u0013J\u001b\u0010\u0014\u001a\u00020\r2\n\u0010\u0011\u001a\u0006\u0012\u0002\b\u00030\u0003H\u0016¢\u0006\u0004\b\u0014\u0010\u0015J\u0015\u0010\u0017\u001a\b\u0012\u0004\u0012\u00020\u00020\u0016H\u0016¢\u0006\u0004\b\u0017\u0010\u0018J\u0018\u0010\u001b\u001a\n\u0012\u0004\u0012\u00020\u001a\u0018\u00010\u0019H\u0082@¢\u0006\u0004\b\u001b\u0010\u001cJ\u0018\u0010\u001f\u001a\u00020\u001e2\u0006\u0010\u001d\u001a\u00020\u0004H\u0082@¢\u0006\u0004\b\u001f\u0010 R\u0014\u0010\u0005\u001a\u00020\u00048\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b!\u0010\"R\u0014\u0010\u0007\u001a\u00020\u00068\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b\u0014\u0010#R\u0014\u0010\b\u001a\u00020\u00048\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b$\u0010\"R\u0014\u0010\n\u001a\u00020\t8\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b%\u0010&R\u0014\u0010\f\u001a\u00020\u000b8\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b'\u0010(R\u0014\u0010\u000e\u001a\u00020\r8\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b)\u0010*R\u0014\u0010.\u001a\u00020+8\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b,\u0010-¨\u0006/"}, d2 = {"Lcom/withpersona/sdk2/inquiry/document/network/c;", "Lln/o;", "Lcom/withpersona/sdk2/inquiry/document/network/c$b;", "Lls/j;", BuildConfig.FLAVOR, "sessionToken", "Lpo/c;", "service", "documentId", "Lno/e$a;", "localDocument", "Lxq/k;", "fileHelper", BuildConfig.FLAVOR, "isSingleFileLimit", "<init>", "(Ljava/lang/String;Lpo/c;Ljava/lang/String;Lno/e$a;Lxq/k;Z)V", "otherWorker", xe.a.f36648e, "(Lln/o;)Z", "c", "(Lls/j;)Z", "Ldv/h;", "run", "()Ldv/h;", BuildConfig.FLAVOR, "Lcom/withpersona/sdk2/inquiry/document/network/DocumentFileData;", "n", "(Leu/b;)Ljava/lang/Object;", "documentFileId", BuildConfig.FLAVOR, "m", "(Ljava/lang/String;Leu/b;)Ljava/lang/Object;", k6.b.f21144e, "Ljava/lang/String;", "Lpo/c;", "d", "e", "Lno/e$a;", "f", "Lxq/k;", "g", "Z", "Lav/p0;", "h", "Lav/p0;", "serviceCoroutineScope", "document_release"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* loaded from: classes3.dex */
public final class c implements o<b>, j<b> {

    /* renamed from: b, reason: from kotlin metadata */
    @NotNull
    public final String sessionToken;

    /* renamed from: c, reason: collision with root package name and from kotlin metadata */
    @NotNull
    public final po.c service;

    /* renamed from: d, reason: collision with root package name and from kotlin metadata */
    @NotNull
    public final String documentId;

    /* renamed from: e, reason: collision with root package name and from kotlin metadata */
    @NotNull
    public final no.e.Local localDocument;

    /* renamed from: f, reason: collision with root package name and from kotlin metadata */
    @NotNull
    public final k fileHelper;

    /* renamed from: g, reason: collision with root package name and from kotlin metadata */
    public final boolean isSingleFileLimit;

    /* renamed from: h, reason: collision with root package name and from kotlin metadata */
    @NotNull
    public final p0 serviceCoroutineScope;

    @Metadata(d1 = {"\u00002\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0006\u0018\u00002\u00020\u0001B\u0019\b\u0007\u0012\u0006\u0010\u0003\u001a\u00020\u0002\u0012\u0006\u0010\u0005\u001a\u00020\u0004¢\u0006\u0004\b\u0006\u0010\u0007J-\u0010\u0010\u001a\u00020\u000f2\u0006\u0010\t\u001a\u00020\b2\u0006\u0010\n\u001a\u00020\b2\u0006\u0010\f\u001a\u00020\u000b2\u0006\u0010\u000e\u001a\u00020\r¢\u0006\u0004\b\u0010\u0010\u0011R\u0014\u0010\u0003\u001a\u00020\u00028\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b\u0010\u0010\u0012R\u0014\u0010\u0005\u001a\u00020\u00048\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b\u0013\u0010\u0014¨\u0006\u0015"}, d2 = {"Lcom/withpersona/sdk2/inquiry/document/network/c$a;", BuildConfig.FLAVOR, "Lpo/c;", "service", "Lxq/k;", "fileHelper", "<init>", "(Lpo/c;Lxq/k;)V", BuildConfig.FLAVOR, "sessionToken", "documentId", "Lno/e$a;", "localDocument", BuildConfig.FLAVOR, "isSingleFileLimit", "Lcom/withpersona/sdk2/inquiry/document/network/c;", xe.a.f36648e, "(Ljava/lang/String;Ljava/lang/String;Lno/e$a;Z)Lcom/withpersona/sdk2/inquiry/document/network/c;", "Lpo/c;", k6.b.f21144e, "Lxq/k;", "document_release"}, k = 1, mv = {2, 2, 0}, xi = 48)
    public static final class a {

        /* renamed from: a, reason: collision with root package name and from kotlin metadata */
        @NotNull
        public final po.c service;

        /* renamed from: b, reason: from kotlin metadata */
        @NotNull
        public final k fileHelper;

        public a(@NotNull po.c service, @NotNull k fileHelper) {
            Intrinsics.checkNotNullParameter(service, "service");
            Intrinsics.checkNotNullParameter(fileHelper, "fileHelper");
            this.service = service;
            this.fileHelper = fileHelper;
        }

        @NotNull
        public final c a(@NotNull String sessionToken, @NotNull String documentId, @NotNull no.e.Local localDocument, boolean isSingleFileLimit) {
            Intrinsics.checkNotNullParameter(sessionToken, "sessionToken");
            Intrinsics.checkNotNullParameter(documentId, "documentId");
            Intrinsics.checkNotNullParameter(localDocument, "localDocument");
            return new c(sessionToken, this.service, documentId, localDocument, this.fileHelper, isSingleFileLimit, null);
        }
    }

    @Metadata(d1 = {"\u0000\u001e\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\b6\u0018\u00002\u00020\u0001:\u0004\u0004\u0005\u0006\u0007B\t\b\u0004¢\u0006\u0004\b\u0002\u0010\u0003\u0082\u0001\u0004\b\t\n\u000b¨\u0006\f"}, d2 = {"Lcom/withpersona/sdk2/inquiry/document/network/c$b;", BuildConfig.FLAVOR, "<init>", "()V", "d", "c", xe.a.f36648e, k6.b.f21144e, "Lcom/withpersona/sdk2/inquiry/document/network/c$b$a;", "Lcom/withpersona/sdk2/inquiry/document/network/c$b$b;", "Lcom/withpersona/sdk2/inquiry/document/network/c$b$c;", "Lcom/withpersona/sdk2/inquiry/document/network/c$b$d;", "document_release"}, k = 1, mv = {2, 2, 0}, xi = 48)
    public static abstract class b {

        @Metadata(d1 = {"\u0000\u0010\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0007\u0018\u00002\u00020\u0001B\u000f\u0012\u0006\u0010\u0003\u001a\u00020\u0002¢\u0006\u0004\b\u0004\u0010\u0005R\u0017\u0010\u0003\u001a\u00020\u00028\u0006¢\u0006\f\n\u0004\b\u0006\u0010\u0007\u001a\u0004\b\u0006\u0010\b¨\u0006\t"}, d2 = {"Lcom/withpersona/sdk2/inquiry/document/network/c$b$a;", "Lcom/withpersona/sdk2/inquiry/document/network/c$b;", "Lcom/withpersona/sdk2/inquiry/network/core/GenericFileUploadErrorResponse$DocumentErrorResponse;", "cause", "<init>", "(Lcom/withpersona/sdk2/inquiry/network/core/GenericFileUploadErrorResponse$DocumentErrorResponse;)V", xe.a.f36648e, "Lcom/withpersona/sdk2/inquiry/network/core/GenericFileUploadErrorResponse$DocumentErrorResponse;", "()Lcom/withpersona/sdk2/inquiry/network/core/GenericFileUploadErrorResponse$DocumentErrorResponse;", "document_release"}, k = 1, mv = {2, 2, 0}, xi = 48)
        public static final class a extends b {

            /* renamed from: a, reason: collision with root package name and from kotlin metadata */
            @NotNull
            public final GenericFileUploadErrorResponse.DocumentErrorResponse cause;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            public a(@NotNull GenericFileUploadErrorResponse.DocumentErrorResponse cause) {
                super(null);
                Intrinsics.checkNotNullParameter(cause, "cause");
                this.cause = cause;
            }

            @NotNull
            /* renamed from: a, reason: from getter */
            public final GenericFileUploadErrorResponse.DocumentErrorResponse getCause() {
                return this.cause;
            }
        }

        @Metadata(d1 = {"\u0000\u0010\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0007\u0018\u00002\u00020\u0001B\u000f\u0012\u0006\u0010\u0003\u001a\u00020\u0002¢\u0006\u0004\b\u0004\u0010\u0005R\u0017\u0010\u0003\u001a\u00020\u00028\u0006¢\u0006\f\n\u0004\b\u0006\u0010\u0007\u001a\u0004\b\u0006\u0010\b¨\u0006\t"}, d2 = {"Lcom/withpersona/sdk2/inquiry/document/network/c$b$b;", "Lcom/withpersona/sdk2/inquiry/document/network/c$b;", "Lcom/withpersona/sdk2/inquiry/network/core/InternalErrorInfo;", "cause", "<init>", "(Lcom/withpersona/sdk2/inquiry/network/core/InternalErrorInfo;)V", xe.a.f36648e, "Lcom/withpersona/sdk2/inquiry/network/core/InternalErrorInfo;", "()Lcom/withpersona/sdk2/inquiry/network/core/InternalErrorInfo;", "document_release"}, k = 1, mv = {2, 2, 0}, xi = 48)
        /* renamed from: com.withpersona.sdk2.inquiry.document.network.c$b$b, reason: collision with other inner class name */
        public static final class C0167b extends b {

            /* renamed from: a, reason: collision with root package name and from kotlin metadata */
            @NotNull
            public final InternalErrorInfo cause;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            public C0167b(@NotNull InternalErrorInfo cause) {
                super(null);
                Intrinsics.checkNotNullParameter(cause, "cause");
                this.cause = cause;
            }

            @NotNull
            /* renamed from: a, reason: from getter */
            public final InternalErrorInfo getCause() {
                return this.cause;
            }
        }

        @Metadata(d1 = {"\u0000\u0010\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\b\n\u0002\b\u0007\u0018\u00002\u00020\u0001B\u000f\u0012\u0006\u0010\u0003\u001a\u00020\u0002¢\u0006\u0004\b\u0004\u0010\u0005R\u0017\u0010\u0003\u001a\u00020\u00028\u0006¢\u0006\f\n\u0004\b\u0006\u0010\u0007\u001a\u0004\b\u0006\u0010\b¨\u0006\t"}, d2 = {"Lcom/withpersona/sdk2/inquiry/document/network/c$b$c;", "Lcom/withpersona/sdk2/inquiry/document/network/c$b;", BuildConfig.FLAVOR, "progressPercentage", "<init>", "(I)V", xe.a.f36648e, "I", "()I", "document_release"}, k = 1, mv = {2, 2, 0}, xi = 48)
        /* renamed from: com.withpersona.sdk2.inquiry.document.network.c$b$c, reason: collision with other inner class name */
        public static final class C0168c extends b {

            /* renamed from: a, reason: collision with root package name and from kotlin metadata */
            public final int progressPercentage;

            public C0168c(int i10) {
                super(null);
                this.progressPercentage = i10;
            }

            /* renamed from: a, reason: from getter */
            public final int getProgressPercentage() {
                return this.progressPercentage;
            }
        }

        @Metadata(d1 = {"\u0000\u0016\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\n\u0018\u00002\u00020\u0001B\u0017\u0012\u0006\u0010\u0003\u001a\u00020\u0002\u0012\u0006\u0010\u0005\u001a\u00020\u0004¢\u0006\u0004\b\u0006\u0010\u0007R\u0017\u0010\u0003\u001a\u00020\u00028\u0006¢\u0006\f\n\u0004\b\b\u0010\t\u001a\u0004\b\n\u0010\u000bR\u0017\u0010\u0005\u001a\u00020\u00048\u0006¢\u0006\f\n\u0004\b\n\u0010\f\u001a\u0004\b\b\u0010\r¨\u0006\u000e"}, d2 = {"Lcom/withpersona/sdk2/inquiry/document/network/c$b$d;", "Lcom/withpersona/sdk2/inquiry/document/network/c$b;", "Lno/e$a;", "oldLocalDocument", "Lno/e$b;", "newRemoteDocument", "<init>", "(Lno/e$a;Lno/e$b;)V", xe.a.f36648e, "Lno/e$a;", k6.b.f21144e, "()Lno/e$a;", "Lno/e$b;", "()Lno/e$b;", "document_release"}, k = 1, mv = {2, 2, 0}, xi = 48)
        public static final class d extends b {

            /* renamed from: a, reason: collision with root package name and from kotlin metadata */
            @NotNull
            public final no.e.Local oldLocalDocument;

            /* renamed from: b, reason: from kotlin metadata */
            @NotNull
            public final no.e.Remote newRemoteDocument;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            public d(@NotNull no.e.Local oldLocalDocument, @NotNull no.e.Remote newRemoteDocument) {
                super(null);
                Intrinsics.checkNotNullParameter(oldLocalDocument, "oldLocalDocument");
                Intrinsics.checkNotNullParameter(newRemoteDocument, "newRemoteDocument");
                this.oldLocalDocument = oldLocalDocument;
                this.newRemoteDocument = newRemoteDocument;
            }

            @NotNull
            /* renamed from: a, reason: from getter */
            public final no.e.Remote getNewRemoteDocument() {
                return this.newRemoteDocument;
            }

            @NotNull
            /* renamed from: b, reason: from getter */
            public final no.e.Local getOldLocalDocument() {
                return this.oldLocalDocument;
            }
        }

        public /* synthetic */ b(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }

        public b() {
        }
    }

    @Metadata(d1 = {"\u0000\b\n\u0002\u0018\u0002\n\u0002\b\u0002\u0010\u0001\u001a\u0006\u0012\u0002\b\u00030\u0000H\n¢\u0006\u0004\b\u0001\u0010\u0002"}, d2 = {"Lsw/x;", "<anonymous>", "()Lsw/x;"}, k = 3, mv = {2, 2, 0})
    @gu.f(c = "com.withpersona.sdk2.inquiry.document.network.DocumentFileUploadWorker$deleteFile$2", f = "DocumentFileUploadWorker.kt", l = {208}, m = "invokeSuspend")
    /* renamed from: com.withpersona.sdk2.inquiry.document.network.c$c, reason: collision with other inner class name */
    public static final class C0169c extends m implements Function1<eu.b<? super x<?>>, Object> {

        /* renamed from: t, reason: collision with root package name */
        public int f9926t;

        /* renamed from: v, reason: collision with root package name */
        public final /* synthetic */ String f9928v;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public C0169c(String str, eu.b<? super C0169c> bVar) {
            super(1, bVar);
            this.f9928v = str;
        }

        @Override // gu.a
        public final eu.b<Unit> create(eu.b<?> bVar) {
            return c.this.new C0169c(this.f9928v, bVar);
        }

        @Override // gu.a
        public final Object invokeSuspend(Object obj) {
            Object e10 = fu.c.e();
            int i10 = this.f9926t;
            if (i10 != 0) {
                if (i10 != 1) {
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                zt.o.b(obj);
                return obj;
            }
            zt.o.b(obj);
            po.c cVar = c.this.service;
            String str = c.this.sessionToken;
            String str2 = this.f9928v;
            this.f9926t = 1;
            Object b = cVar.b(str, str2, this);
            return b == e10 ? e10 : b;
        }

        @Override // kotlin.jvm.functions.Function1
        /* renamed from: m, reason: merged with bridge method [inline-methods] */
        public final Object invoke(eu.b<? super x<?>> bVar) {
            return ((C0169c) create(bVar)).invokeSuspend(Unit.f21504a);
        }
    }

    @Metadata(k = 3, mv = {2, 2, 0}, xi = 48)
    @gu.f(c = "com.withpersona.sdk2.inquiry.document.network.DocumentFileUploadWorker", f = "DocumentFileUploadWorker.kt", l = {191}, m = "fetchCurrentDocuments")
    public static final class d extends gu.d {

        /* renamed from: t, reason: collision with root package name */
        public /* synthetic */ Object f9929t;

        /* renamed from: v, reason: collision with root package name */
        public int f9931v;

        public d(eu.b<? super d> bVar) {
            super(bVar);
        }

        @Override // gu.a
        @Nullable
        public final Object invokeSuspend(@NotNull Object obj) {
            this.f9929t = obj;
            this.f9931v |= Integer.MIN_VALUE;
            return c.this.n(this);
        }
    }

    @Metadata(d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\u0010\u0002\u001a\b\u0012\u0004\u0012\u00020\u00010\u0000H\n¢\u0006\u0004\b\u0002\u0010\u0003"}, d2 = {"Lsw/x;", "Lcom/withpersona/sdk2/inquiry/document/network/CreateDocumentResponse;", "<anonymous>", "()Lsw/x;"}, k = 3, mv = {2, 2, 0})
    @gu.f(c = "com.withpersona.sdk2.inquiry.document.network.DocumentFileUploadWorker$fetchCurrentDocuments$result$1", f = "DocumentFileUploadWorker.kt", l = {192}, m = "invokeSuspend")
    public static final class e extends m implements Function1<eu.b<? super x<CreateDocumentResponse>>, Object> {

        /* renamed from: t, reason: collision with root package name */
        public int f9932t;

        public e(eu.b<? super e> bVar) {
            super(1, bVar);
        }

        @Override // gu.a
        public final eu.b<Unit> create(eu.b<?> bVar) {
            return c.this.new e(bVar);
        }

        @Override // gu.a
        public final Object invokeSuspend(Object obj) {
            Object e10 = fu.c.e();
            int i10 = this.f9932t;
            if (i10 != 0) {
                if (i10 != 1) {
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                zt.o.b(obj);
                return obj;
            }
            zt.o.b(obj);
            po.c cVar = c.this.service;
            String str = c.this.sessionToken;
            String str2 = c.this.documentId;
            this.f9932t = 1;
            Object d10 = cVar.d(str, str2, this);
            return d10 == e10 ? e10 : d10;
        }

        @Override // kotlin.jvm.functions.Function1
        /* renamed from: m, reason: merged with bridge method [inline-methods] */
        public final Object invoke(eu.b<? super x<CreateDocumentResponse>> bVar) {
            return ((e) create(bVar)).invokeSuspend(Unit.f21504a);
        }
    }

    @Metadata(d1 = {"\u0000\u0010\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0002\b\u0002\u0010\u0003\u001a\u00020\u0002*\b\u0012\u0004\u0012\u00020\u00010\u0000H\n¢\u0006\u0004\b\u0003\u0010\u0004"}, d2 = {"Ldv/i;", "Lcom/withpersona/sdk2/inquiry/document/network/c$b;", BuildConfig.FLAVOR, "<anonymous>", "(Ldv/i;)V"}, k = 3, mv = {2, 2, 0})
    @gu.f(c = "com.withpersona.sdk2.inquiry.document.network.DocumentFileUploadWorker$run$1", f = "DocumentFileUploadWorker.kt", l = {66, 69, 177}, m = "invokeSuspend")
    public static final class f extends m implements Function2<i<? super b>, eu.b<? super Unit>, Object> {

        /* renamed from: t, reason: collision with root package name */
        public Object f9934t;

        /* renamed from: u, reason: collision with root package name */
        public Object f9935u;

        /* renamed from: v, reason: collision with root package name */
        public Object f9936v;

        /* renamed from: w, reason: collision with root package name */
        public Object f9937w;

        /* renamed from: x, reason: collision with root package name */
        public Object f9938x;

        /* renamed from: y, reason: collision with root package name */
        public int f9939y;

        /* renamed from: z, reason: collision with root package name */
        public /* synthetic */ Object f9940z;

        @Metadata(k = 3, mv = {2, 2, 0}, xi = 48)
        public static final class a<T> implements i {

            /* renamed from: a, reason: collision with root package name */
            public final /* synthetic */ i<b> f9941a;

            @Metadata(k = 3, mv = {2, 2, 0}, xi = 48)
            @gu.f(c = "com.withpersona.sdk2.inquiry.document.network.DocumentFileUploadWorker$run$1$1", f = "DocumentFileUploadWorker.kt", l = {178}, m = "emit")
            /* renamed from: com.withpersona.sdk2.inquiry.document.network.c$f$a$a, reason: collision with other inner class name */
            public static final class C0170a extends gu.d {

                /* renamed from: t, reason: collision with root package name */
                public Object f9942t;

                /* renamed from: u, reason: collision with root package name */
                public /* synthetic */ Object f9943u;

                /* renamed from: v, reason: collision with root package name */
                public final /* synthetic */ a<T> f9944v;

                /* renamed from: w, reason: collision with root package name */
                public int f9945w;

                /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                /* JADX WARN: Multi-variable type inference failed */
                public C0170a(a<? super T> aVar, eu.b<? super C0170a> bVar) {
                    super(bVar);
                    this.f9944v = aVar;
                }

                @Override // gu.a
                public final Object invokeSuspend(Object obj) {
                    this.f9943u = obj;
                    this.f9945w |= Integer.MIN_VALUE;
                    return this.f9944v.emit(null, this);
                }
            }

            /* JADX WARN: Multi-variable type inference failed */
            public a(i<? super b> iVar) {
                this.f9941a = iVar;
            }

            /* JADX WARN: Removed duplicated region for block: B:20:0x0035  */
            /* JADX WARN: Removed duplicated region for block: B:8:0x0023  */
            @Override // dv.i
            /* renamed from: b, reason: merged with bridge method [inline-methods] */
            /*
                Code decompiled incorrectly, please refer to instructions dump.
                To view partially-correct add '--show-bad-code' argument
            */
            public final java.lang.Object emit(com.withpersona.sdk2.inquiry.document.network.c.b r5, eu.b<? super kotlin.Unit> r6) {
                /*
                    r4 = this;
                    boolean r0 = r6 instanceof com.withpersona.sdk2.inquiry.document.network.c.f.a.C0170a
                    if (r0 == 0) goto L13
                    r0 = r6
                    com.withpersona.sdk2.inquiry.document.network.c$f$a$a r0 = (com.withpersona.sdk2.inquiry.document.network.c.f.a.C0170a) r0
                    int r1 = r0.f9945w
                    r2 = -2147483648(0xffffffff80000000, float:-0.0)
                    r3 = r1 & r2
                    if (r3 == 0) goto L13
                    int r1 = r1 - r2
                    r0.f9945w = r1
                    goto L18
                L13:
                    com.withpersona.sdk2.inquiry.document.network.c$f$a$a r0 = new com.withpersona.sdk2.inquiry.document.network.c$f$a$a
                    r0.<init>(r4, r6)
                L18:
                    java.lang.Object r6 = r0.f9943u
                    java.lang.Object r1 = fu.c.e()
                    int r2 = r0.f9945w
                    r3 = 1
                    if (r2 == 0) goto L35
                    if (r2 != r3) goto L2d
                    java.lang.Object r5 = r0.f9942t
                    com.withpersona.sdk2.inquiry.document.network.c$b r5 = (com.withpersona.sdk2.inquiry.document.network.c.b) r5
                    zt.o.b(r6)
                    goto L45
                L2d:
                    java.lang.IllegalStateException r5 = new java.lang.IllegalStateException
                    java.lang.String r6 = "call to 'resume' before 'invoke' with coroutine"
                    r5.<init>(r6)
                    throw r5
                L35:
                    zt.o.b(r6)
                    dv.i<com.withpersona.sdk2.inquiry.document.network.c$b> r6 = r4.f9941a
                    r0.f9942t = r5
                    r0.f9945w = r3
                    java.lang.Object r6 = r6.emit(r5, r0)
                    if (r6 != r1) goto L45
                    return r1
                L45:
                    boolean r6 = r5 instanceof com.withpersona.sdk2.inquiry.document.network.c.b.a
                    if (r6 != 0) goto L4d
                    boolean r5 = r5 instanceof com.withpersona.sdk2.inquiry.document.network.c.b.C0167b
                    if (r5 == 0) goto L55
                L4d:
                    kotlin.coroutines.CoroutineContext r5 = r0.getContext()
                    r6 = 0
                    av.g2.d(r5, r6, r3, r6)
                L55:
                    kotlin.Unit r5 = kotlin.Unit.f21504a
                    return r5
                */
                throw new UnsupportedOperationException("Method not decompiled: com.withpersona.sdk2.inquiry.document.network.c.f.a.emit(com.withpersona.sdk2.inquiry.document.network.c$b, eu.b):java.lang.Object");
            }
        }

        @Metadata(d1 = {"\u0000\u0010\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0002\b\u0002\u0010\u0003\u001a\u00020\u0002*\b\u0012\u0004\u0012\u00020\u00010\u0000H\n¢\u0006\u0004\b\u0003\u0010\u0004"}, d2 = {"Ldv/i;", "Lcom/withpersona/sdk2/inquiry/document/network/c$b$c;", BuildConfig.FLAVOR, "<anonymous>", "(Ldv/i;)V"}, k = 3, mv = {2, 2, 0})
        @gu.f(c = "com.withpersona.sdk2.inquiry.document.network.DocumentFileUploadWorker$run$1$progressFlow$1", f = "DocumentFileUploadWorker.kt", l = {169, 173}, m = "invokeSuspend")
        public static final class b extends m implements Function2<i<? super b.C0168c>, eu.b<? super Unit>, Object> {

            /* renamed from: t, reason: collision with root package name */
            public int f9946t;

            /* renamed from: u, reason: collision with root package name */
            public /* synthetic */ Object f9947u;

            /* renamed from: v, reason: collision with root package name */
            public final /* synthetic */ po.e f9948v;

            @Metadata(d1 = {"\u0000\f\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\b\u0010\u0000\u001a\u00020\u00012\u0006\u0010\u0002\u001a\u00020\u0003H\n"}, d2 = {"<anonymous>", BuildConfig.FLAVOR, "it", BuildConfig.FLAVOR}, k = 3, mv = {2, 2, 0}, xi = 48)
            @gu.f(c = "com.withpersona.sdk2.inquiry.document.network.DocumentFileUploadWorker$run$1$progressFlow$1$1", f = "DocumentFileUploadWorker.kt", l = {}, m = "invokeSuspend")
            public static final class a extends m implements Function2<Integer, eu.b<? super Boolean>, Object> {

                /* renamed from: t, reason: collision with root package name */
                public int f9949t;

                /* renamed from: u, reason: collision with root package name */
                public /* synthetic */ int f9950u;

                public a(eu.b<? super a> bVar) {
                    super(2, bVar);
                }

                @Override // gu.a
                public final eu.b<Unit> create(Object obj, eu.b<?> bVar) {
                    a aVar = new a(bVar);
                    aVar.f9950u = ((Number) obj).intValue();
                    return aVar;
                }

                @Override // kotlin.jvm.functions.Function2
                public /* bridge */ /* synthetic */ Object invoke(Integer num, eu.b<? super Boolean> bVar) {
                    return m(num.intValue(), bVar);
                }

                @Override // gu.a
                public final Object invokeSuspend(Object obj) {
                    int i10 = this.f9950u;
                    fu.c.e();
                    if (this.f9949t != 0) {
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                    zt.o.b(obj);
                    return gu.b.a(i10 < 100);
                }

                public final Object m(int i10, eu.b<? super Boolean> bVar) {
                    return ((a) create(Integer.valueOf(i10), bVar)).invokeSuspend(Unit.f21504a);
                }
            }

            @Metadata(k = 3, mv = {2, 2, 0}, xi = 48)
            /* renamed from: com.withpersona.sdk2.inquiry.document.network.c$f$b$b, reason: collision with other inner class name */
            public static final class C0171b<T> implements i {

                /* renamed from: a, reason: collision with root package name */
                public final /* synthetic */ i<b.C0168c> f9951a;

                /* JADX WARN: Multi-variable type inference failed */
                public C0171b(i<? super b.C0168c> iVar) {
                    this.f9951a = iVar;
                }

                public final Object b(int i10, eu.b<? super Unit> bVar) {
                    Object emit = this.f9951a.emit(new b.C0168c(i10), bVar);
                    return emit == fu.c.e() ? emit : Unit.f21504a;
                }

                @Override // dv.i
                public /* bridge */ /* synthetic */ Object emit(Object obj, eu.b bVar) {
                    return b(((Number) obj).intValue(), bVar);
                }
            }

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            public b(po.e eVar, eu.b<? super b> bVar) {
                super(2, bVar);
                this.f9948v = eVar;
            }

            @Override // gu.a
            public final eu.b<Unit> create(Object obj, eu.b<?> bVar) {
                b bVar2 = new b(this.f9948v, bVar);
                bVar2.f9947u = obj;
                return bVar2;
            }

            /* JADX WARN: Code restructure failed: missing block: B:13:0x0058, code lost:
            
                if (r0.emit(r7, r6) == r1) goto L15;
             */
            /* JADX WARN: Code restructure failed: missing block: B:14:0x005a, code lost:
            
                return r1;
             */
            /* JADX WARN: Code restructure failed: missing block: B:16:0x0042, code lost:
            
                if (r7.collect(r2, r6) == r1) goto L15;
             */
            @Override // gu.a
            /*
                Code decompiled incorrectly, please refer to instructions dump.
                To view partially-correct add '--show-bad-code' argument
            */
            public final java.lang.Object invokeSuspend(java.lang.Object r7) {
                /*
                    r6 = this;
                    java.lang.Object r0 = r6.f9947u
                    dv.i r0 = (dv.i) r0
                    java.lang.Object r1 = fu.c.e()
                    int r2 = r6.f9946t
                    r3 = 2
                    r4 = 1
                    if (r2 == 0) goto L22
                    if (r2 == r4) goto L1e
                    if (r2 != r3) goto L16
                    zt.o.b(r7)
                    goto L5b
                L16:
                    java.lang.IllegalStateException r7 = new java.lang.IllegalStateException
                    java.lang.String r0 = "call to 'resume' before 'invoke' with coroutine"
                    r7.<init>(r0)
                    throw r7
                L1e:
                    zt.o.b(r7)
                    goto L45
                L22:
                    zt.o.b(r7)
                    po.e r7 = r6.f9948v
                    dv.p0 r7 = r7.i()
                    com.withpersona.sdk2.inquiry.document.network.c$f$b$a r2 = new com.withpersona.sdk2.inquiry.document.network.c$f$b$a
                    r5 = 0
                    r2.<init>(r5)
                    dv.h r7 = dv.j.O(r7, r2)
                    com.withpersona.sdk2.inquiry.document.network.c$f$b$b r2 = new com.withpersona.sdk2.inquiry.document.network.c$f$b$b
                    r2.<init>(r0)
                    r6.f9947u = r0
                    r6.f9946t = r4
                    java.lang.Object r7 = r7.collect(r2, r6)
                    if (r7 != r1) goto L45
                    goto L5a
                L45:
                    com.withpersona.sdk2.inquiry.document.network.c$b$c r7 = new com.withpersona.sdk2.inquiry.document.network.c$b$c
                    r2 = 100
                    r7.<init>(r2)
                    java.lang.Object r2 = gu.l.a(r0)
                    r6.f9947u = r2
                    r6.f9946t = r3
                    java.lang.Object r7 = r0.emit(r7, r6)
                    if (r7 != r1) goto L5b
                L5a:
                    return r1
                L5b:
                    kotlin.Unit r7 = kotlin.Unit.f21504a
                    return r7
                */
                throw new UnsupportedOperationException("Method not decompiled: com.withpersona.sdk2.inquiry.document.network.c.f.b.invokeSuspend(java.lang.Object):java.lang.Object");
            }

            @Override // kotlin.jvm.functions.Function2
            /* renamed from: m, reason: merged with bridge method [inline-methods] */
            public final Object invoke(i<? super b.C0168c> iVar, eu.b<? super Unit> bVar) {
                return ((b) create(iVar, bVar)).invokeSuspend(Unit.f21504a);
            }
        }

        @Metadata(d1 = {"\u0000\u0010\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\u0010\u0003\u001a\b\u0012\u0004\u0012\u00020\u00020\u0001*\u00020\u0000H\n¢\u0006\u0004\b\u0003\u0010\u0004"}, d2 = {"Lav/p0;", "Lcom/withpersona/sdk2/inquiry/network/core/NetworkCallResult;", "Lcom/withpersona/sdk2/inquiry/document/network/DocumentFileUploadResponse;", "<anonymous>", "(Lav/p0;)Lcom/withpersona/sdk2/inquiry/network/core/NetworkCallResult;"}, k = 3, mv = {2, 2, 0})
        @gu.f(c = "com.withpersona.sdk2.inquiry.document.network.DocumentFileUploadWorker$run$1$result$1", f = "DocumentFileUploadWorker.kt", l = {80}, m = "invokeSuspend")
        /* renamed from: com.withpersona.sdk2.inquiry.document.network.c$f$c, reason: collision with other inner class name */
        public static final class C0172c extends m implements Function2<p0, eu.b<? super NetworkCallResult<DocumentFileUploadResponse>>, Object> {

            /* renamed from: t, reason: collision with root package name */
            public int f9952t;

            /* renamed from: u, reason: collision with root package name */
            public final /* synthetic */ c f9953u;

            /* renamed from: v, reason: collision with root package name */
            public final /* synthetic */ po.e f9954v;

            @Metadata(d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\u0010\u0002\u001a\b\u0012\u0004\u0012\u00020\u00010\u0000H\n¢\u0006\u0004\b\u0002\u0010\u0003"}, d2 = {"Lsw/x;", "Lcom/withpersona/sdk2/inquiry/document/network/DocumentFileUploadResponse;", "<anonymous>", "()Lsw/x;"}, k = 3, mv = {2, 2, 0})
            @gu.f(c = "com.withpersona.sdk2.inquiry.document.network.DocumentFileUploadWorker$run$1$result$1$1", f = "DocumentFileUploadWorker.kt", l = {81}, m = "invokeSuspend")
            /* renamed from: com.withpersona.sdk2.inquiry.document.network.c$f$c$a */
            public static final class a extends m implements Function1<eu.b<? super x<DocumentFileUploadResponse>>, Object> {

                /* renamed from: t, reason: collision with root package name */
                public int f9955t;

                /* renamed from: u, reason: collision with root package name */
                public final /* synthetic */ c f9956u;

                /* renamed from: v, reason: collision with root package name */
                public final /* synthetic */ po.e f9957v;

                /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                public a(c cVar, po.e eVar, eu.b<? super a> bVar) {
                    super(1, bVar);
                    this.f9956u = cVar;
                    this.f9957v = eVar;
                }

                @Override // gu.a
                public final eu.b<Unit> create(eu.b<?> bVar) {
                    return new a(this.f9956u, this.f9957v, bVar);
                }

                @Override // gu.a
                public final Object invokeSuspend(Object obj) {
                    Object e10 = fu.c.e();
                    int i10 = this.f9955t;
                    if (i10 != 0) {
                        if (i10 != 1) {
                            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                        }
                        zt.o.b(obj);
                        return obj;
                    }
                    zt.o.b(obj);
                    po.c cVar = this.f9956u.service;
                    String str = this.f9956u.sessionToken;
                    c0.c.Companion companion = c0.c.INSTANCE;
                    c0.c b = companion.b("data[type]", "document-file");
                    c0.c b10 = companion.b("data[attributes][document-id]", this.f9956u.documentId);
                    c0.c b11 = companion.b("data[attributes][capture-method]", this.f9956u.localDocument.getCaptureMethod().getType());
                    c0.c c10 = companion.c("data[attributes][originals][]", this.f9956u.localDocument.getAbsoluteFilePath(), this.f9957v);
                    String name = new File(this.f9956u.localDocument.getAbsoluteFilePath()).getName();
                    Intrinsics.checkNotNullExpressionValue(name, "getName(...)");
                    List<c0.c> n10 = p.n(b, b10, b11, c10, companion.b("data[attributes][name]", name));
                    this.f9955t = 1;
                    Object e11 = cVar.e(str, n10, this);
                    return e11 == e10 ? e10 : e11;
                }

                @Override // kotlin.jvm.functions.Function1
                /* renamed from: m, reason: merged with bridge method [inline-methods] */
                public final Object invoke(eu.b<? super x<DocumentFileUploadResponse>> bVar) {
                    return ((a) create(bVar)).invokeSuspend(Unit.f21504a);
                }
            }

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            public C0172c(c cVar, po.e eVar, eu.b<? super C0172c> bVar) {
                super(2, bVar);
                this.f9953u = cVar;
                this.f9954v = eVar;
            }

            @Override // gu.a
            public final eu.b<Unit> create(Object obj, eu.b<?> bVar) {
                return new C0172c(this.f9953u, this.f9954v, bVar);
            }

            @Override // kotlin.jvm.functions.Function2
            public final Object invoke(p0 p0Var, eu.b<? super NetworkCallResult<DocumentFileUploadResponse>> bVar) {
                return ((C0172c) create(p0Var, bVar)).invokeSuspend(Unit.f21504a);
            }

            @Override // gu.a
            public final Object invokeSuspend(Object obj) {
                Object e10 = fu.c.e();
                int i10 = this.f9952t;
                if (i10 != 0) {
                    if (i10 != 1) {
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                    zt.o.b(obj);
                    return obj;
                }
                zt.o.b(obj);
                a aVar = new a(this.f9953u, this.f9954v, null);
                this.f9952t = 1;
                Object enqueueVerificationRequestWithRetry = NetworkUtilsKt.enqueueVerificationRequestWithRetry(aVar, this);
                return enqueueVerificationRequestWithRetry == e10 ? e10 : enqueueVerificationRequestWithRetry;
            }
        }

        @Metadata(d1 = {"\u0000\u0010\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0002\b\u0002\u0010\u0003\u001a\u00020\u0002*\b\u0012\u0004\u0012\u00020\u00010\u0000H\n¢\u0006\u0004\b\u0003\u0010\u0004"}, d2 = {"Ldv/i;", "Lcom/withpersona/sdk2/inquiry/document/network/c$b;", BuildConfig.FLAVOR, "<anonymous>", "(Ldv/i;)V"}, k = 3, mv = {2, 2, 0})
        @gu.f(c = "com.withpersona.sdk2.inquiry.document.network.DocumentFileUploadWorker$run$1$resultFlow$1", f = "DocumentFileUploadWorker.kt", l = {106, 110, 122, 147, 149, 156, 162}, m = "invokeSuspend")
        public static final class d extends m implements Function2<i<? super b>, eu.b<? super Unit>, Object> {
            public final /* synthetic */ w0<NetworkCallResult<DocumentFileUploadResponse>> A;
            public final /* synthetic */ c B;

            /* renamed from: t, reason: collision with root package name */
            public Object f9958t;

            /* renamed from: u, reason: collision with root package name */
            public Object f9959u;

            /* renamed from: v, reason: collision with root package name */
            public Object f9960v;

            /* renamed from: w, reason: collision with root package name */
            public int f9961w;

            /* renamed from: x, reason: collision with root package name */
            public int f9962x;

            /* renamed from: y, reason: collision with root package name */
            public int f9963y;

            /* renamed from: z, reason: collision with root package name */
            public /* synthetic */ Object f9964z;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            /* JADX WARN: Multi-variable type inference failed */
            public d(w0<? extends NetworkCallResult<DocumentFileUploadResponse>> w0Var, c cVar, eu.b<? super d> bVar) {
                super(2, bVar);
                this.A = w0Var;
                this.B = cVar;
            }

            @Override // gu.a
            public final eu.b<Unit> create(Object obj, eu.b<?> bVar) {
                d dVar = new d(this.A, this.B, bVar);
                dVar.f9964z = obj;
                return dVar;
            }

            /* JADX WARN: Code restructure failed: missing block: B:21:0x0172, code lost:
            
                if (r0.emit(r5, r13) == r1) goto L57;
             */
            /* JADX WARN: Code restructure failed: missing block: B:22:0x01fc, code lost:
            
                return r1;
             */
            /* JADX WARN: Code restructure failed: missing block: B:24:0x01a4, code lost:
            
                if (r0.emit(r5, r13) == r1) goto L57;
             */
            /* JADX WARN: Code restructure failed: missing block: B:33:0x01d7, code lost:
            
                if (r0.emit(r5, r13) == r1) goto L57;
             */
            /* JADX WARN: Code restructure failed: missing block: B:35:0x01fa, code lost:
            
                if (r0.emit(r5, r13) == r1) goto L57;
             */
            /* JADX WARN: Code restructure failed: missing block: B:51:0x00c2, code lost:
            
                if (r0.emit(r7, r13) == r1) goto L57;
             */
            /* JADX WARN: Code restructure failed: missing block: B:53:0x00f0, code lost:
            
                if (r0.emit(r14, r13) == r1) goto L57;
             */
            /* JADX WARN: Code restructure failed: missing block: B:56:0x004b, code lost:
            
                if (r14 == r1) goto L57;
             */
            /* JADX WARN: Removed duplicated region for block: B:13:0x00f8  */
            @Override // gu.a
            /*
                Code decompiled incorrectly, please refer to instructions dump.
                To view partially-correct add '--show-bad-code' argument
            */
            public final java.lang.Object invokeSuspend(java.lang.Object r14) {
                /*
                    Method dump skipped, instructions count: 532
                    To view this dump add '--comments-level debug' option
                */
                throw new UnsupportedOperationException("Method not decompiled: com.withpersona.sdk2.inquiry.document.network.c.f.d.invokeSuspend(java.lang.Object):java.lang.Object");
            }

            @Override // kotlin.jvm.functions.Function2
            /* renamed from: m, reason: merged with bridge method [inline-methods] */
            public final Object invoke(i<? super b> iVar, eu.b<? super Unit> bVar) {
                return ((d) create(iVar, bVar)).invokeSuspend(Unit.f21504a);
            }
        }

        public f(eu.b<? super f> bVar) {
            super(2, bVar);
        }

        @Override // gu.a
        public final eu.b<Unit> create(Object obj, eu.b<?> bVar) {
            f fVar = c.this.new f(bVar);
            fVar.f9940z = obj;
            return fVar;
        }

        /* JADX WARN: Code restructure failed: missing block: B:14:0x012c, code lost:
        
            if (r5.collect(r6, r16) == r2) goto L27;
         */
        /* JADX WARN: Code restructure failed: missing block: B:15:0x012e, code lost:
        
            return r2;
         */
        /* JADX WARN: Code restructure failed: missing block: B:22:0x00a7, code lost:
        
            if (r8.m(r9, r16) == r2) goto L27;
         */
        /* JADX WARN: Code restructure failed: missing block: B:26:0x0079, code lost:
        
            if (r7 == r2) goto L27;
         */
        @Override // gu.a
        /*
            Code decompiled incorrectly, please refer to instructions dump.
            To view partially-correct add '--show-bad-code' argument
        */
        public final java.lang.Object invokeSuspend(java.lang.Object r17) {
            /*
                Method dump skipped, instructions count: 306
                To view this dump add '--comments-level debug' option
            */
            throw new UnsupportedOperationException("Method not decompiled: com.withpersona.sdk2.inquiry.document.network.c.f.invokeSuspend(java.lang.Object):java.lang.Object");
        }

        @Override // kotlin.jvm.functions.Function2
        /* renamed from: m, reason: merged with bridge method [inline-methods] */
        public final Object invoke(i<? super b> iVar, eu.b<? super Unit> bVar) {
            return ((f) create(iVar, bVar)).invokeSuspend(Unit.f21504a);
        }
    }

    public /* synthetic */ c(String str, po.c cVar, String str2, no.e.Local local, k kVar, boolean z10, DefaultConstructorMarker defaultConstructorMarker) {
        this(str, cVar, str2, local, kVar, z10);
    }

    @Override // ln.o
    public boolean a(@NotNull o<?> otherWorker) {
        Intrinsics.checkNotNullParameter(otherWorker, "otherWorker");
        if (!(otherWorker instanceof c)) {
            return false;
        }
        c cVar = (c) otherWorker;
        return Intrinsics.c(this.sessionToken, cVar.sessionToken) && Intrinsics.c(this.localDocument, cVar.localDocument);
    }

    @Override // ls.j
    public boolean b(@NotNull j<?> jVar) {
        return super.b(jVar);
    }

    @Override // ls.j
    public boolean c(@NotNull j<?> otherWorker) {
        Intrinsics.checkNotNullParameter(otherWorker, "otherWorker");
        if (!(otherWorker instanceof c)) {
            return false;
        }
        c cVar = (c) otherWorker;
        return Intrinsics.c(this.sessionToken, cVar.sessionToken) && Intrinsics.c(this.localDocument, cVar.localDocument);
    }

    public final Object m(String str, eu.b<? super Unit> bVar) {
        Object enqueueRetriableRequestWithRetry = NetworkUtilsKt.enqueueRetriableRequestWithRetry(new C0169c(str, null), bVar);
        return enqueueRetriableRequestWithRetry == fu.c.e() ? enqueueRetriableRequestWithRetry : Unit.f21504a;
    }

    /* JADX WARN: Removed duplicated region for block: B:12:0x0049 A[RETURN] */
    /* JADX WARN: Removed duplicated region for block: B:14:0x004a  */
    /* JADX WARN: Removed duplicated region for block: B:25:0x0032  */
    /* JADX WARN: Removed duplicated region for block: B:8:0x0024  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final java.lang.Object n(eu.b<? super java.util.List<com.withpersona.sdk2.inquiry.document.network.DocumentFileData>> r6) {
        /*
            r5 = this;
            boolean r0 = r6 instanceof com.withpersona.sdk2.inquiry.document.network.c.d
            if (r0 == 0) goto L13
            r0 = r6
            com.withpersona.sdk2.inquiry.document.network.c$d r0 = (com.withpersona.sdk2.inquiry.document.network.c.d) r0
            int r1 = r0.f9931v
            r2 = -2147483648(0xffffffff80000000, float:-0.0)
            r3 = r1 & r2
            if (r3 == 0) goto L13
            int r1 = r1 - r2
            r0.f9931v = r1
            goto L18
        L13:
            com.withpersona.sdk2.inquiry.document.network.c$d r0 = new com.withpersona.sdk2.inquiry.document.network.c$d
            r0.<init>(r6)
        L18:
            java.lang.Object r6 = r0.f9929t
            java.lang.Object r1 = fu.c.e()
            int r2 = r0.f9931v
            r3 = 1
            r4 = 0
            if (r2 == 0) goto L32
            if (r2 != r3) goto L2a
            zt.o.b(r6)
            goto L43
        L2a:
            java.lang.IllegalStateException r6 = new java.lang.IllegalStateException
            java.lang.String r0 = "call to 'resume' before 'invoke' with coroutine"
            r6.<init>(r0)
            throw r6
        L32:
            zt.o.b(r6)
            com.withpersona.sdk2.inquiry.document.network.c$e r6 = new com.withpersona.sdk2.inquiry.document.network.c$e
            r6.<init>(r4)
            r0.f9931v = r3
            java.lang.Object r6 = com.withpersona.sdk2.inquiry.network.core.NetworkUtilsKt.enqueueRetriableRequestWithRetry(r6, r0)
            if (r6 != r1) goto L43
            return r1
        L43:
            com.withpersona.sdk2.inquiry.network.core.NetworkCallResult r6 = (com.withpersona.sdk2.inquiry.network.core.NetworkCallResult) r6
            boolean r0 = r6 instanceof com.withpersona.sdk2.inquiry.network.core.NetworkCallResult.Failure
            if (r0 == 0) goto L4a
            return r4
        L4a:
            boolean r0 = r6 instanceof com.withpersona.sdk2.inquiry.network.core.NetworkCallResult.Success
            if (r0 == 0) goto L5e
            com.withpersona.sdk2.inquiry.network.core.NetworkCallResult$Success r6 = (com.withpersona.sdk2.inquiry.network.core.NetworkCallResult.Success) r6
            java.lang.Object r6 = r6.getResponse()
            com.withpersona.sdk2.inquiry.document.network.CreateDocumentResponse r6 = (com.withpersona.sdk2.inquiry.document.network.CreateDocumentResponse) r6
            if (r6 == 0) goto L5d
            java.util.List r6 = r6.b()
            return r6
        L5d:
            return r4
        L5e:
            zt.l r6 = new zt.l
            r6.<init>()
            throw r6
        */
        throw new UnsupportedOperationException("Method not decompiled: com.withpersona.sdk2.inquiry.document.network.c.n(eu.b):java.lang.Object");
    }

    @Override // ln.o, ls.j
    @NotNull
    public dv.h<b> run() {
        return dv.j.w(new f(null));
    }

    public c(String str, po.c cVar, String str2, no.e.Local local, k kVar, boolean z10) {
        a0 b10;
        this.sessionToken = str;
        this.service = cVar;
        this.documentId = str2;
        this.localDocument = local;
        this.fileHelper = kVar;
        this.isSingleFileLimit = z10;
        l0 a10 = g1.a();
        b10 = h2.b(null, 1, null);
        this.serviceCoroutineScope = q0.a(a10.plus(b10));
    }


    // --- восстановлено из DEX (com/withpersona/sdk2/inquiry/document/network/c$b$a) ---
    public static class a extends com.withpersona.sdk2.inquiry.document.network.c.b {
        com.withpersona.sdk2.inquiry.network.core.GenericFileUploadErrorResponse.DocumentErrorResponse a;
        public a(com.withpersona.sdk2.inquiry.network.core.GenericFileUploadErrorResponse.DocumentErrorResponse p0) { }
        public com.withpersona.sdk2.inquiry.network.core.GenericFileUploadErrorResponse.DocumentErrorResponse a() { throw new UnsupportedOperationException("stub"); }
    }

    // --- восстановлено из DEX (com/withpersona/sdk2/inquiry/document/network/c$b$b) ---
    public static class b extends com.withpersona.sdk2.inquiry.document.network.c.b {
        com.withpersona.sdk2.inquiry.network.core.InternalErrorInfo a;
        public b(com.withpersona.sdk2.inquiry.network.core.InternalErrorInfo p0) { }
        public com.withpersona.sdk2.inquiry.network.core.InternalErrorInfo a() { throw new UnsupportedOperationException("stub"); }
    }

    // --- восстановлено из DEX (com/withpersona/sdk2/inquiry/document/network/c$b$c) ---
    public static class c extends com.withpersona.sdk2.inquiry.document.network.c.b {
        int a;
        public c(int p0) { }
        public int a() { throw new UnsupportedOperationException("stub"); }
    }

    // --- восстановлено из DEX (com/withpersona/sdk2/inquiry/document/network/c$b$d) ---
    public static class d extends com.withpersona.sdk2.inquiry.document.network.c.b {
        no.e.a a;
        no.e.b b;
        public d(no.e.a p0, no.e.b p1) { }
        public no.e.b a() { throw new UnsupportedOperationException("stub"); }
        public no.e.a b() { throw new UnsupportedOperationException("stub"); }
    }

    // --- восстановлено из DEX (com/withpersona/sdk2/inquiry/document/network/c$f$a) ---
    public static class a implements dv.i {
        dv.i a;
        public a(dv.i p0) { }
        public java.lang.Object b(com.withpersona.sdk2.inquiry.document.network.c.b p0, eu.b p1) { throw new UnsupportedOperationException("stub"); }
        public java.lang.Object emit(java.lang.Object p0, eu.b p1) { throw new UnsupportedOperationException("stub"); }
    }

    // --- восстановлено из DEX (com/withpersona/sdk2/inquiry/document/network/c$f$a$a) ---
    public static class a extends gu.d {
        java.lang.Object t;
        java.lang.Object u;
        com.withpersona.sdk2.inquiry.document.network.c.f.a v;
        int w;
        public a(com.withpersona.sdk2.inquiry.document.network.c.f.a p0, eu.b p1) { }
        public java.lang.Object invokeSuspend(java.lang.Object p0) { throw new UnsupportedOperationException("stub"); }
    }

    // --- восстановлено из DEX (com/withpersona/sdk2/inquiry/document/network/c$f$b) ---
    public static class b extends gu.m implements kotlin.jvm.functions.Function2 {
        int t;
        java.lang.Object u;
        po.e v;
        public b(po.e p0, eu.b p1) { }
        public eu.b create(java.lang.Object p0, eu.b p1) { throw new UnsupportedOperationException("stub"); }
        public java.lang.Object invoke(java.lang.Object p0, java.lang.Object p1) { throw new UnsupportedOperationException("stub"); }
        public java.lang.Object invokeSuspend(java.lang.Object p0) { throw new UnsupportedOperationException("stub"); }
        public java.lang.Object m(dv.i p0, eu.b p1) { throw new UnsupportedOperationException("stub"); }
    }

    // --- восстановлено из DEX (com/withpersona/sdk2/inquiry/document/network/c$f$b$a) ---
    public static class a extends gu.m implements kotlin.jvm.functions.Function2 {
        int t;
        int u;
        public a(eu.b p0) { }
        public eu.b create(java.lang.Object p0, eu.b p1) { throw new UnsupportedOperationException("stub"); }
        public java.lang.Object invoke(java.lang.Object p0, java.lang.Object p1) { throw new UnsupportedOperationException("stub"); }
        public java.lang.Object invokeSuspend(java.lang.Object p0) { throw new UnsupportedOperationException("stub"); }
        public java.lang.Object m(int p0, eu.b p1) { throw new UnsupportedOperationException("stub"); }
    }

    // --- восстановлено из DEX (com/withpersona/sdk2/inquiry/document/network/c$f$b$b) ---
    public static class b implements dv.i {
        dv.i a;
        public b(dv.i p0) { }
        public java.lang.Object b(int p0, eu.b p1) { throw new UnsupportedOperationException("stub"); }
        public java.lang.Object emit(java.lang.Object p0, eu.b p1) { throw new UnsupportedOperationException("stub"); }
    }

    // --- восстановлено из DEX (com/withpersona/sdk2/inquiry/document/network/c$f$c) ---
    public static class c extends gu.m implements kotlin.jvm.functions.Function2 {
        int t;
        com.withpersona.sdk2.inquiry.document.network.c u;
        po.e v;
        public c(com.withpersona.sdk2.inquiry.document.network.c p0, po.e p1, eu.b p2) { }
        public eu.b create(java.lang.Object p0, eu.b p1) { throw new UnsupportedOperationException("stub"); }
        public java.lang.Object invoke(av.p0 p0, eu.b p1) { throw new UnsupportedOperationException("stub"); }
        public java.lang.Object invoke(java.lang.Object p0, java.lang.Object p1) { throw new UnsupportedOperationException("stub"); }
        public java.lang.Object invokeSuspend(java.lang.Object p0) { throw new UnsupportedOperationException("stub"); }
    }

    // --- восстановлено из DEX (com/withpersona/sdk2/inquiry/document/network/c$f$c$a) ---
    public static class a extends gu.m implements kotlin.jvm.functions.Function1 {
        int t;
        com.withpersona.sdk2.inquiry.document.network.c u;
        po.e v;
        public a(com.withpersona.sdk2.inquiry.document.network.c p0, po.e p1, eu.b p2) { }
        public eu.b create(eu.b p0) { throw new UnsupportedOperationException("stub"); }
        public java.lang.Object invoke(java.lang.Object p0) { throw new UnsupportedOperationException("stub"); }
        public java.lang.Object invokeSuspend(java.lang.Object p0) { throw new UnsupportedOperationException("stub"); }
        public java.lang.Object m(eu.b p0) { throw new UnsupportedOperationException("stub"); }
    }

    // --- восстановлено из DEX (com/withpersona/sdk2/inquiry/document/network/c$f$d) ---
    public static class d extends gu.m implements kotlin.jvm.functions.Function2 {
        av.w0 A;
        com.withpersona.sdk2.inquiry.document.network.c B;
        java.lang.Object t;
        java.lang.Object u;
        java.lang.Object v;
        int w;
        int x;
        int y;
        java.lang.Object z;
        public d(av.w0 p0, com.withpersona.sdk2.inquiry.document.network.c p1, eu.b p2) { }
        public eu.b create(java.lang.Object p0, eu.b p1) { throw new UnsupportedOperationException("stub"); }
        public java.lang.Object invoke(java.lang.Object p0, java.lang.Object p1) { throw new UnsupportedOperationException("stub"); }
        public java.lang.Object invokeSuspend(java.lang.Object p0) { throw new UnsupportedOperationException("stub"); }
        public java.lang.Object m(dv.i p0, eu.b p1) { throw new UnsupportedOperationException("stub"); }
    }
}
