package com.withpersona.sdk2.inquiry.ui.network;

import com.github.luben.zstd.BuildConfig;
import com.withpersona.sdk2.inquiry.network.core.InternalErrorInfo;
import com.withpersona.sdk2.inquiry.steps.ui.network.Suggestion;
import dv.h;
import dv.i;
import gu.f;
import gu.m;
import java.util.List;
import kotlin.Unit;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import ln.o;
import ls.j;
import org.jetbrains.annotations.NotNull;
import qr.x5;
import y5.w;

@kotlin.Metadata(d1 = {"\u00006\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u000b\n\u0002\b\u000b\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u00012\b\u0012\u0004\u0012\u00020\u00020\u0003:\u0002\u0016\u0012B)\b\u0002\u0012\u0006\u0010\u0005\u001a\u00020\u0004\u0012\u0006\u0010\u0007\u001a\u00020\u0006\u0012\u0006\u0010\b\u001a\u00020\u0004\u0012\u0006\u0010\n\u001a\u00020\t¢\u0006\u0004\b\u000b\u0010\fJ\u0015\u0010\u000e\u001a\b\u0012\u0004\u0012\u00020\u00020\rH\u0016¢\u0006\u0004\b\u000e\u0010\u000fJ\u001b\u0010\u0012\u001a\u00020\u00112\n\u0010\u0010\u001a\u0006\u0012\u0002\b\u00030\u0001H\u0016¢\u0006\u0004\b\u0012\u0010\u0013J\u001b\u0010\u0014\u001a\u00020\u00112\n\u0010\u0010\u001a\u0006\u0012\u0002\b\u00030\u0003H\u0016¢\u0006\u0004\b\u0014\u0010\u0015R\u0014\u0010\u0005\u001a\u00020\u00048\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b\u0016\u0010\u0017R\u0014\u0010\u0007\u001a\u00020\u00068\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b\u0014\u0010\u0018R\u0014\u0010\b\u001a\u00020\u00048\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b\u0019\u0010\u0017R\u0014\u0010\n\u001a\u00020\t8\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b\u001a\u0010\u001b¨\u0006\u001c"}, d2 = {"Lcom/withpersona/sdk2/inquiry/ui/network/b;", "Lln/o;", "Lcom/withpersona/sdk2/inquiry/ui/network/b$b;", "Lls/j;", BuildConfig.FLAVOR, "sessionToken", "Lqr/x5;", "triggeringComponent", "addressText", "Lgs/c;", "uiService", "<init>", "(Ljava/lang/String;Lqr/x5;Ljava/lang/String;Lgs/c;)V", "Ldv/h;", "run", "()Ldv/h;", "otherWorker", BuildConfig.FLAVOR, xe.a.f36648e, "(Lln/o;)Z", "c", "(Lls/j;)Z", k6.b.f21144e, "Ljava/lang/String;", "Lqr/x5;", "d", "e", "Lgs/c;", "ui_release"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* loaded from: classes3.dex */
public final class b implements o<AbstractC0196b>, j<AbstractC0196b> {

    /* renamed from: b, reason: from kotlin metadata */
    @NotNull
    public final String sessionToken;

    /* renamed from: c, reason: collision with root package name and from kotlin metadata */
    @NotNull
    public final x5 triggeringComponent;

    /* renamed from: d, reason: collision with root package name and from kotlin metadata */
    @NotNull
    public final String addressText;

    /* renamed from: e, reason: collision with root package name and from kotlin metadata */
    @NotNull
    public final gs.c uiService;

    @kotlin.Metadata(d1 = {"\u0000&\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0004\u0018\u00002\u00020\u0001B\u0011\b\u0007\u0012\u0006\u0010\u0003\u001a\u00020\u0002¢\u0006\u0004\b\u0004\u0010\u0005J%\u0010\f\u001a\u00020\u000b2\u0006\u0010\u0007\u001a\u00020\u00062\u0006\u0010\t\u001a\u00020\b2\u0006\u0010\n\u001a\u00020\u0006¢\u0006\u0004\b\f\u0010\rR\u0014\u0010\u0003\u001a\u00020\u00028\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b\f\u0010\u000e¨\u0006\u000f"}, d2 = {"Lcom/withpersona/sdk2/inquiry/ui/network/b$a;", BuildConfig.FLAVOR, "Lgs/c;", "uiService", "<init>", "(Lgs/c;)V", BuildConfig.FLAVOR, "sessionToken", "Lqr/x5;", "triggeringComponent", "addressText", "Lcom/withpersona/sdk2/inquiry/ui/network/b;", xe.a.f36648e, "(Ljava/lang/String;Lqr/x5;Ljava/lang/String;)Lcom/withpersona/sdk2/inquiry/ui/network/b;", "Lgs/c;", "ui_release"}, k = 1, mv = {2, 2, 0}, xi = 48)
    public static final class a {

        /* renamed from: a, reason: collision with root package name and from kotlin metadata */
        @NotNull
        public final gs.c uiService;

        public a(@NotNull gs.c uiService) {
            Intrinsics.checkNotNullParameter(uiService, "uiService");
            this.uiService = uiService;
        }

        @NotNull
        public final b a(@NotNull String sessionToken, @NotNull x5 triggeringComponent, @NotNull String addressText) {
            Intrinsics.checkNotNullParameter(sessionToken, "sessionToken");
            Intrinsics.checkNotNullParameter(triggeringComponent, "triggeringComponent");
            Intrinsics.checkNotNullParameter(addressText, "addressText");
            return new b(sessionToken, triggeringComponent, addressText, this.uiService, null);
        }
    }

    @kotlin.Metadata(d1 = {"\u0000\u0016\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\b6\u0018\u00002\u00020\u0001:\u0002\u0004\u0005B\t\b\u0004¢\u0006\u0004\b\u0002\u0010\u0003\u0082\u0001\u0002\u0006\u0007¨\u0006\b"}, d2 = {"Lcom/withpersona/sdk2/inquiry/ui/network/b$b;", BuildConfig.FLAVOR, "<init>", "()V", k6.b.f21144e, xe.a.f36648e, "Lcom/withpersona/sdk2/inquiry/ui/network/b$b$a;", "Lcom/withpersona/sdk2/inquiry/ui/network/b$b$b;", "ui_release"}, k = 1, mv = {2, 2, 0}, xi = 48)
    /* renamed from: com.withpersona.sdk2.inquiry.ui.network.b$b, reason: collision with other inner class name */
    public static abstract class AbstractC0196b {

        @kotlin.Metadata(d1 = {"\u0000\u0010\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\b\u0018\u00002\u00020\u0001B\u000f\u0012\u0006\u0010\u0003\u001a\u00020\u0002¢\u0006\u0004\b\u0004\u0010\u0005R\u0017\u0010\u0003\u001a\u00020\u00028\u0006¢\u0006\f\n\u0004\b\u0006\u0010\u0007\u001a\u0004\b\b\u0010\t¨\u0006\n"}, d2 = {"Lcom/withpersona/sdk2/inquiry/ui/network/b$b$a;", "Lcom/withpersona/sdk2/inquiry/ui/network/b$b;", "Lcom/withpersona/sdk2/inquiry/network/core/InternalErrorInfo;", "cause", "<init>", "(Lcom/withpersona/sdk2/inquiry/network/core/InternalErrorInfo;)V", xe.a.f36648e, "Lcom/withpersona/sdk2/inquiry/network/core/InternalErrorInfo;", "getCause", "()Lcom/withpersona/sdk2/inquiry/network/core/InternalErrorInfo;", "ui_release"}, k = 1, mv = {2, 2, 0}, xi = 48)
        /* renamed from: com.withpersona.sdk2.inquiry.ui.network.b$b$a */
        public static final class a extends AbstractC0196b {

            /* renamed from: a, reason: collision with root package name and from kotlin metadata */
            @NotNull
            public final InternalErrorInfo cause;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            public a(@NotNull InternalErrorInfo cause) {
                super(null);
                Intrinsics.checkNotNullParameter(cause, "cause");
                this.cause = cause;
            }
        }

        @kotlin.Metadata(d1 = {"\u0000\u0014\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\b\u0007\u0018\u00002\u00020\u0001B\u0015\u0012\f\u0010\u0004\u001a\b\u0012\u0004\u0012\u00020\u00030\u0002¢\u0006\u0004\b\u0005\u0010\u0006R\u001d\u0010\u0004\u001a\b\u0012\u0004\u0012\u00020\u00030\u00028\u0006¢\u0006\f\n\u0004\b\u0007\u0010\b\u001a\u0004\b\u0007\u0010\t¨\u0006\n"}, d2 = {"Lcom/withpersona/sdk2/inquiry/ui/network/b$b$b;", "Lcom/withpersona/sdk2/inquiry/ui/network/b$b;", BuildConfig.FLAVOR, "Lcom/withpersona/sdk2/inquiry/steps/ui/network/Suggestion;", "results", "<init>", "(Ljava/util/List;)V", xe.a.f36648e, "Ljava/util/List;", "()Ljava/util/List;", "ui_release"}, k = 1, mv = {2, 2, 0}, xi = 48)
        /* renamed from: com.withpersona.sdk2.inquiry.ui.network.b$b$b, reason: collision with other inner class name */
        public static final class C0197b extends AbstractC0196b {

            /* renamed from: a, reason: collision with root package name and from kotlin metadata */
            @NotNull
            public final List<Suggestion> results;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            public C0197b(@NotNull List<Suggestion> results) {
                super(null);
                Intrinsics.checkNotNullParameter(results, "results");
                this.results = results;
            }

            @NotNull
            public final List<Suggestion> a() {
                return this.results;
            }
        }

        public /* synthetic */ AbstractC0196b(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }

        public AbstractC0196b() {
        }
    }

    @kotlin.Metadata(d1 = {"\u0000\u0010\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0002\b\u0002\u0010\u0003\u001a\u00020\u0002*\b\u0012\u0004\u0012\u00020\u00010\u0000H\n¢\u0006\u0004\b\u0003\u0010\u0004"}, d2 = {"Ldv/i;", "Lcom/withpersona/sdk2/inquiry/ui/network/b$b;", BuildConfig.FLAVOR, "<anonymous>", "(Ldv/i;)V"}, k = 3, mv = {2, 2, 0})
    @f(c = "com.withpersona.sdk2.inquiry.ui.network.UiAddressAutocompleteWorker$run$1", f = "UiAddressAutocompleteWorker.kt", l = {w.f37552c, 29, 31}, m = "invokeSuspend")
    public static final class c extends m implements Function2<i<? super AbstractC0196b>, eu.b<? super Unit>, Object> {

        /* renamed from: t, reason: collision with root package name */
        public Object f11479t;

        /* renamed from: u, reason: collision with root package name */
        public int f11480u;

        /* renamed from: v, reason: collision with root package name */
        public /* synthetic */ Object f11481v;

        public c(eu.b<? super c> bVar) {
            super(2, bVar);
        }

        @Override // gu.a
        public final eu.b<Unit> create(Object obj, eu.b<?> bVar) {
            c cVar = b.this.new c(bVar);
            cVar.f11481v = obj;
            return cVar;
        }

        /* JADX WARN: Code restructure failed: missing block: B:16:0x007a, code lost:
        
            if (r0.emit(r2, r9) == r1) goto L29;
         */
        /* JADX WARN: Code restructure failed: missing block: B:17:0x00ae, code lost:
        
            return r1;
         */
        /* JADX WARN: Code restructure failed: missing block: B:25:0x00ac, code lost:
        
            if (r0.emit(r2, r9) == r1) goto L29;
         */
        /* JADX WARN: Code restructure failed: missing block: B:28:0x0054, code lost:
        
            if (r10 == r1) goto L29;
         */
        @Override // gu.a
        /*
            Code decompiled incorrectly, please refer to instructions dump.
            To view partially-correct add '--show-bad-code' argument
        */
        public final java.lang.Object invokeSuspend(java.lang.Object r10) {
            /*
                r9 = this;
                java.lang.Object r0 = r9.f11481v
                dv.i r0 = (dv.i) r0
                java.lang.Object r1 = fu.c.e()
                int r2 = r9.f11480u
                r3 = 3
                r4 = 2
                r5 = 1
                if (r2 == 0) goto L2b
                if (r2 == r5) goto L27
                if (r2 == r4) goto L1e
                if (r2 != r3) goto L16
                goto L1e
            L16:
                java.lang.IllegalStateException r10 = new java.lang.IllegalStateException
                java.lang.String r0 = "call to 'resume' before 'invoke' with coroutine"
                r10.<init>(r0)
                throw r10
            L1e:
                java.lang.Object r0 = r9.f11479t
                sw.x r0 = (sw.x) r0
                zt.o.b(r10)
                goto Laf
            L27:
                zt.o.b(r10)
                goto L57
            L2b:
                zt.o.b(r10)
                com.withpersona.sdk2.inquiry.ui.network.b r10 = com.withpersona.sdk2.inquiry.ui.network.b.this
                gs.c r10 = com.withpersona.sdk2.inquiry.ui.network.b.g(r10)
                com.withpersona.sdk2.inquiry.ui.network.b r2 = com.withpersona.sdk2.inquiry.ui.network.b.this
                java.lang.String r2 = com.withpersona.sdk2.inquiry.ui.network.b.e(r2)
                com.withpersona.sdk2.inquiry.ui.network.AddressAutocompleteRequest$a r6 = com.withpersona.sdk2.inquiry.ui.network.AddressAutocompleteRequest.INSTANCE
                com.withpersona.sdk2.inquiry.ui.network.b r7 = com.withpersona.sdk2.inquiry.ui.network.b.this
                qr.x5 r7 = com.withpersona.sdk2.inquiry.ui.network.b.f(r7)
                com.withpersona.sdk2.inquiry.ui.network.b r8 = com.withpersona.sdk2.inquiry.ui.network.b.this
                java.lang.String r8 = com.withpersona.sdk2.inquiry.ui.network.b.d(r8)
                com.withpersona.sdk2.inquiry.ui.network.AddressAutocompleteRequest r6 = r6.a(r7, r8)
                r9.f11481v = r0
                r9.f11480u = r5
                java.lang.Object r10 = r10.b(r2, r6, r9)
                if (r10 != r1) goto L57
                goto Lae
            L57:
                sw.x r10 = (sw.x) r10
                boolean r2 = r10.g()
                if (r2 != 0) goto L7d
                com.withpersona.sdk2.inquiry.ui.network.b$b$a r2 = new com.withpersona.sdk2.inquiry.ui.network.b$b$a
                com.withpersona.sdk2.inquiry.network.core.InternalErrorInfo$NetworkErrorInfo r3 = com.withpersona.sdk2.inquiry.network.core.NetworkUtilsKt.toErrorInfo(r10)
                r2.<init>(r3)
                java.lang.Object r3 = gu.l.a(r0)
                r9.f11481v = r3
                java.lang.Object r10 = gu.l.a(r10)
                r9.f11479t = r10
                r9.f11480u = r4
                java.lang.Object r10 = r0.emit(r2, r9)
                if (r10 != r1) goto Laf
                goto Lae
            L7d:
                com.withpersona.sdk2.inquiry.ui.network.b$b$b r2 = new com.withpersona.sdk2.inquiry.ui.network.b$b$b
                java.lang.Object r4 = r10.a()
                com.withpersona.sdk2.inquiry.steps.ui.network.AddressAutocompleteResponse r4 = (com.withpersona.sdk2.inquiry.steps.ui.network.AddressAutocompleteResponse) r4
                if (r4 == 0) goto L93
                com.withpersona.sdk2.inquiry.steps.ui.network.Meta r4 = r4.getMeta()
                if (r4 == 0) goto L93
                java.util.List r4 = r4.a()
                if (r4 != 0) goto L97
            L93:
                java.util.List r4 = kotlin.collections.p.k()
            L97:
                r2.<init>(r4)
                java.lang.Object r4 = gu.l.a(r0)
                r9.f11481v = r4
                java.lang.Object r10 = gu.l.a(r10)
                r9.f11479t = r10
                r9.f11480u = r3
                java.lang.Object r10 = r0.emit(r2, r9)
                if (r10 != r1) goto Laf
            Lae:
                return r1
            Laf:
                kotlin.Unit r10 = kotlin.Unit.f21504a
                return r10
            */
            throw new UnsupportedOperationException("Method not decompiled: com.withpersona.sdk2.inquiry.ui.network.b.c.invokeSuspend(java.lang.Object):java.lang.Object");
        }

        @Override // kotlin.jvm.functions.Function2
        /* renamed from: m, reason: merged with bridge method [inline-methods] */
        public final Object invoke(i<? super AbstractC0196b> iVar, eu.b<? super Unit> bVar) {
            return ((c) create(iVar, bVar)).invokeSuspend(Unit.f21504a);
        }
    }

    public /* synthetic */ b(String str, x5 x5Var, String str2, gs.c cVar, DefaultConstructorMarker defaultConstructorMarker) {
        this(str, x5Var, str2, cVar);
    }

    @Override // ln.o
    public boolean a(@NotNull o<?> otherWorker) {
        Intrinsics.checkNotNullParameter(otherWorker, "otherWorker");
        return (otherWorker instanceof b) && Intrinsics.c(this.addressText, ((b) otherWorker).addressText);
    }

    @Override // ls.j
    public boolean b(@NotNull j<?> jVar) {
        return super.b(jVar);
    }

    @Override // ls.j
    public boolean c(@NotNull j<?> otherWorker) {
        Intrinsics.checkNotNullParameter(otherWorker, "otherWorker");
        return (otherWorker instanceof b) && Intrinsics.c(this.addressText, ((b) otherWorker).addressText);
    }

    @Override // ln.o, ls.j
    @NotNull
    public h<AbstractC0196b> run() {
        return dv.j.w(new c(null));
    }

    public b(String str, x5 x5Var, String str2, gs.c cVar) {
        this.sessionToken = str;
        this.triggeringComponent = x5Var;
        this.addressText = str2;
        this.uiService = cVar;
    }


    // --- восстановлено из DEX (com/withpersona/sdk2/inquiry/ui/network/b$b$a) ---
    public static class a extends com.withpersona.sdk2.inquiry.ui.network.b.b {
        com.withpersona.sdk2.inquiry.network.core.InternalErrorInfo a;
        public a(com.withpersona.sdk2.inquiry.network.core.InternalErrorInfo p0) { }
    }

    // --- восстановлено из DEX (com/withpersona/sdk2/inquiry/ui/network/b$b$b) ---
    public static class b extends com.withpersona.sdk2.inquiry.ui.network.b.b {
        java.util.List a;
        public b(java.util.List p0) { }
        public java.util.List a() { throw new UnsupportedOperationException("stub"); }
    }
}
