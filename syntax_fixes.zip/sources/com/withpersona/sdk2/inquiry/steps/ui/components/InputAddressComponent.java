package com.withpersona.sdk2.inquiry.steps.ui.components;

import android.os.Parcel;
import android.os.Parcelable;
import com.github.luben.zstd.BuildConfig;
import com.google.mlkit.vision.barcode.common.Barcode;
import com.withpersona.sdk2.inquiry.network.dto.JsonLogicBoolean;
import com.withpersona.sdk2.inquiry.network.dto.ui.components.InputAddress;
import com.withpersona.sdk2.inquiry.steps.ui.network.Suggestion;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import nn.s;
import nn.v;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import pm.t;
import qr.h0;
import qr.q0;
import qr.w;
import qr.x5;
import sr.q;

@Metadata(d1 = {"\u0000\u0084\u0001\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u000e\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0010\t\n\u0002\b\u0013\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0002\b\u0007\n\u0002\u0010\u0000\n\u0002\b5\n\u0002\u0010!\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0007\n\u0002\u0018\u0002\n\u0002\b\u0014\b\u0087\b\u0018\u0000 J2\u00020\u00012\u00020\u00022\u00020\u00032\u00020\u0004:\u0001?B\u009f\u0001\u0012\u0006\u0010\u0006\u001a\u00020\u0005\u0012\u0006\u0010\u0007\u001a\u00020\u0005\u0012\u0006\u0010\b\u001a\u00020\u0005\u0012\u0006\u0010\t\u001a\u00020\u0005\u0012\u0006\u0010\n\u001a\u00020\u0005\u0012\u0006\u0010\u000b\u001a\u00020\u0005\u0012\b\u0010\r\u001a\u0004\u0018\u00010\f\u0012\b\u0010\u000e\u001a\u0004\u0018\u00010\f\u0012\u0006\u0010\u0010\u001a\u00020\u000f\u0012\n\b\u0002\u0010\u0011\u001a\u0004\u0018\u00010\u0005\u0012\u0010\b\u0002\u0010\u0014\u001a\n\u0012\u0004\u0012\u00020\u0013\u0018\u00010\u0012\u0012\n\b\u0002\u0010\u0015\u001a\u0004\u0018\u00010\u0005\u0012\n\b\u0002\u0010\u0017\u001a\u0004\u0018\u00010\u0016\u0012\n\b\u0002\u0010\u0018\u001a\u0004\u0018\u00010\u0016\u0012\b\b\u0002\u0010\u001a\u001a\u00020\u0019¢\u0006\u0004\b\u001b\u0010\u001cJ\u0019\u0010\u001e\u001a\u00020\u00002\b\u0010\u001d\u001a\u0004\u0018\u00010\u0016H\u0016¢\u0006\u0004\b\u001e\u0010\u001fJ\u0019\u0010!\u001a\u00020\u00002\b\u0010 \u001a\u0004\u0018\u00010\u0005H\u0016¢\u0006\u0004\b!\u0010\"J\u0019\u0010#\u001a\u00020\u00002\b\u0010 \u001a\u0004\u0018\u00010\u0005H\u0016¢\u0006\u0004\b#\u0010\"J\u0019\u0010$\u001a\u00020\u00002\b\u0010 \u001a\u0004\u0018\u00010\u0005H\u0016¢\u0006\u0004\b$\u0010\"J\u0019\u0010%\u001a\u00020\u00002\b\u0010 \u001a\u0004\u0018\u00010\u0005H\u0016¢\u0006\u0004\b%\u0010\"J\u0019\u0010&\u001a\u00020\u00002\b\u0010 \u001a\u0004\u0018\u00010\u0005H\u0016¢\u0006\u0004\b&\u0010\"J\u0019\u0010'\u001a\u00020\u00002\b\u0010\u0011\u001a\u0004\u0018\u00010\u0005H\u0016¢\u0006\u0004\b'\u0010\"J\u001f\u0010(\u001a\u00020\u00002\u000e\u0010\u0014\u001a\n\u0012\u0004\u0012\u00020\u0013\u0018\u00010\u0012H\u0016¢\u0006\u0004\b(\u0010)J\u0019\u0010+\u001a\u00020\u00002\b\u0010*\u001a\u0004\u0018\u00010\u0005H\u0016¢\u0006\u0004\b+\u0010\"J\u0019\u0010,\u001a\u00020\u00002\b\u0010\u0017\u001a\u0004\u0018\u00010\u0016H\u0016¢\u0006\u0004\b,\u0010\u001fJ\r\u0010.\u001a\u00020-¢\u0006\u0004\b.\u0010/J\u001d\u00104\u001a\u0002032\u0006\u00101\u001a\u0002002\u0006\u00102\u001a\u00020-¢\u0006\u0004\b4\u00105Jº\u0001\u00106\u001a\u00020\u00002\b\b\u0002\u0010\u0006\u001a\u00020\u00052\b\b\u0002\u0010\u0007\u001a\u00020\u00052\b\b\u0002\u0010\b\u001a\u00020\u00052\b\b\u0002\u0010\t\u001a\u00020\u00052\b\b\u0002\u0010\n\u001a\u00020\u00052\b\b\u0002\u0010\u000b\u001a\u00020\u00052\n\b\u0002\u0010\r\u001a\u0004\u0018\u00010\f2\n\b\u0002\u0010\u000e\u001a\u0004\u0018\u00010\f2\b\b\u0002\u0010\u0010\u001a\u00020\u000f2\n\b\u0002\u0010\u0011\u001a\u0004\u0018\u00010\u00052\u0010\b\u0002\u0010\u0014\u001a\n\u0012\u0004\u0012\u00020\u0013\u0018\u00010\u00122\n\b\u0002\u0010\u0015\u001a\u0004\u0018\u00010\u00052\n\b\u0002\u0010\u0017\u001a\u0004\u0018\u00010\u00162\n\b\u0002\u0010\u0018\u001a\u0004\u0018\u00010\u00162\b\b\u0002\u0010\u001a\u001a\u00020\u0019HÆ\u0001¢\u0006\u0004\b6\u00107J\u0010\u00108\u001a\u00020\u0005HÖ\u0001¢\u0006\u0004\b8\u00109J\u0010\u0010:\u001a\u00020-HÖ\u0001¢\u0006\u0004\b:\u0010/J\u001a\u0010=\u001a\u00020\u00162\b\u0010<\u001a\u0004\u0018\u00010;HÖ\u0003¢\u0006\u0004\b=\u0010>R\u001a\u0010\u0006\u001a\u00020\u00058\u0016X\u0096\u0004¢\u0006\f\n\u0004\b?\u0010@\u001a\u0004\bA\u00109R\"\u0010\u0007\u001a\u00020\u00058\u0006@\u0006X\u0086\u000e¢\u0006\u0012\n\u0004\bB\u0010@\u001a\u0004\bC\u00109\"\u0004\bD\u0010ER\"\u0010\b\u001a\u00020\u00058\u0006@\u0006X\u0086\u000e¢\u0006\u0012\n\u0004\bF\u0010@\u001a\u0004\bG\u00109\"\u0004\bH\u0010ER\"\u0010\t\u001a\u00020\u00058\u0006@\u0006X\u0086\u000e¢\u0006\u0012\n\u0004\bI\u0010@\u001a\u0004\bJ\u00109\"\u0004\bK\u0010ER\"\u0010\n\u001a\u00020\u00058\u0006@\u0006X\u0086\u000e¢\u0006\u0012\n\u0004\bL\u0010@\u001a\u0004\bM\u00109\"\u0004\bN\u0010ER\"\u0010\u000b\u001a\u00020\u00058\u0006@\u0006X\u0086\u000e¢\u0006\u0012\n\u0004\bO\u0010@\u001a\u0004\bP\u00109\"\u0004\bQ\u0010ER\u001c\u0010\r\u001a\u0004\u0018\u00010\f8\u0016X\u0096\u0004¢\u0006\f\n\u0004\bR\u0010S\u001a\u0004\bT\u0010UR\u001c\u0010\u000e\u001a\u0004\u0018\u00010\f8\u0016X\u0096\u0004¢\u0006\f\n\u0004\bV\u0010S\u001a\u0004\bW\u0010UR\u0017\u0010\u0010\u001a\u00020\u000f8\u0006¢\u0006\f\n\u0004\bX\u0010Y\u001a\u0004\bZ\u0010[R$\u0010\u0011\u001a\u0004\u0018\u00010\u00058\u0006@\u0006X\u0086\u000e¢\u0006\u0012\n\u0004\b#\u0010@\u001a\u0004\b\\\u00109\"\u0004\b]\u0010ER*\u0010\u0014\u001a\n\u0012\u0004\u0012\u00020\u0013\u0018\u00010\u00128\u0006@\u0006X\u0086\u000e¢\u0006\u0012\n\u0004\b$\u0010^\u001a\u0004\b_\u0010`\"\u0004\ba\u0010bR$\u0010\u0015\u001a\u0004\u0018\u00010\u00058\u0006@\u0006X\u0086\u000e¢\u0006\u0012\n\u0004\bc\u0010@\u001a\u0004\bd\u00109\"\u0004\be\u0010ER$\u0010\u0017\u001a\u0004\u0018\u00010\u00168\u0006@\u0006X\u0086\u000e¢\u0006\u0012\n\u0004\bf\u0010g\u001a\u0004\bh\u0010i\"\u0004\bj\u0010kR$\u0010\u0018\u001a\u0004\u0018\u00010\u00168\u0006@\u0006X\u0086\u000e¢\u0006\u0012\n\u0004\bl\u0010g\u001a\u0004\bm\u0010i\"\u0004\bn\u0010kR\u001a\u0010\u001a\u001a\u00020\u00198\u0016X\u0096\u0004¢\u0006\f\n\u0004\b\u001e\u0010n\u001a\u0004\bo\u0010pR&\u0010u\u001a\b\u0012\u0004\u0012\u00020r0q8\u0016X\u0096\u0004¢\u0006\u0012\n\u0004\b&\u0010^\u0012\u0004\bs\u0010t\u001a\u0004\bX\u0010`R(\u0010}\u001a\u00020v8\u0016@\u0016X\u0096\u000e¢\u0006\u0018\n\u0004\b!\u0010w\u0012\u0004\b|\u0010t\u001a\u0004\bx\u0010y\"\u0004\bz\u0010{R-\u0010\u0084\u0001\u001a\u00020~8\u0016@\u0016X\u0097\u000e¢\u0006\u001c\n\u0004\bx\u0010\u007f\u0012\u0005\b\u0083\u0001\u0010t\u001a\u0005\bc\u0010\u0080\u0001\"\u0006\b\u0081\u0001\u0010\u0082\u0001R-\u0010\u0087\u0001\u001a\u00020~8\u0016@\u0016X\u0097\u000e¢\u0006\u001c\n\u0004\b%\u0010\u007f\u0012\u0005\b\u0086\u0001\u0010t\u001a\u0005\bl\u0010\u0080\u0001\"\u0006\b\u0085\u0001\u0010\u0082\u0001R-\u0010\u008a\u0001\u001a\u00020~8\u0016@\u0016X\u0097\u000e¢\u0006\u001c\n\u0004\b6\u0010\u007f\u0012\u0005\b\u0089\u0001\u0010t\u001a\u0005\b?\u0010\u0080\u0001\"\u0006\b\u0088\u0001\u0010\u0082\u0001R.\u0010\u008e\u0001\u001a\u00020~8\u0016@\u0016X\u0097\u000e¢\u0006\u001d\n\u0005\b\u008b\u0001\u0010\u007f\u0012\u0005\b\u008d\u0001\u0010t\u001a\u0005\bR\u0010\u0080\u0001\"\u0006\b\u008c\u0001\u0010\u0082\u0001R-\u0010\u0091\u0001\u001a\u00020~8\u0016@\u0016X\u0097\u000e¢\u0006\u001c\n\u0004\bZ\u0010\u007f\u0012\u0005\b\u0090\u0001\u0010t\u001a\u0005\bO\u0010\u0080\u0001\"\u0006\b\u008f\u0001\u0010\u0082\u0001¨\u0006\u0092\u0001"}, d2 = {"Lcom/withpersona/sdk2/inquiry/steps/ui/components/InputAddressComponent;", "Lqr/x5;", "Lqr/c;", "Lqr/w;", "Lqr/h0;", BuildConfig.FLAVOR, "name", "street1", "street2", "city", "subdivision", "postalCode", "Lcom/withpersona/sdk2/inquiry/network/dto/JsonLogicBoolean;", "hidden", "disabled", "Lsr/b;", "autocompleteMethod", "searchQuery", BuildConfig.FLAVOR, "Lcom/withpersona/sdk2/inquiry/steps/ui/network/Suggestion;", "searchResults", "selectedSearchResultId", BuildConfig.FLAVOR, "isAddressAutocompleteLoading", "isAddressComponentsCollapsed", BuildConfig.FLAVOR, "lastValueUpdateTs", "<init>", "(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lcom/withpersona/sdk2/inquiry/network/dto/JsonLogicBoolean;Lcom/withpersona/sdk2/inquiry/network/dto/JsonLogicBoolean;Lsr/b;Ljava/lang/String;Ljava/util/List;Ljava/lang/String;Ljava/lang/Boolean;Ljava/lang/Boolean;J)V", "newState", "o", "(Ljava/lang/Boolean;)Lcom/withpersona/sdk2/inquiry/steps/ui/components/InputAddressComponent;", "newString", "q", "(Ljava/lang/String;)Lcom/withpersona/sdk2/inquiry/steps/ui/components/InputAddressComponent;", "j", "k", "s", "p", "T", "U", "(Ljava/util/List;)Lcom/withpersona/sdk2/inquiry/steps/ui/components/InputAddressComponent;", "resultId", "V", "S", BuildConfig.FLAVOR, "describeContents", "()I", "Landroid/os/Parcel;", "dest", "flags", BuildConfig.FLAVOR, "writeToParcel", "(Landroid/os/Parcel;I)V", t.f29212d, "(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lcom/withpersona/sdk2/inquiry/network/dto/JsonLogicBoolean;Lcom/withpersona/sdk2/inquiry/network/dto/JsonLogicBoolean;Lsr/b;Ljava/lang/String;Ljava/util/List;Ljava/lang/String;Ljava/lang/Boolean;Ljava/lang/Boolean;J)Lcom/withpersona/sdk2/inquiry/steps/ui/components/InputAddressComponent;", "toString", "()Ljava/lang/String;", "hashCode", BuildConfig.FLAVOR, "other", "equals", "(Ljava/lang/Object;)Z", xe.a.f36648e, "Ljava/lang/String;", "getName", k6.b.f21144e, "C", "setStreet1", "(Ljava/lang/String;)V", "c", "D", "setStreet2", "d", "w", "setCity", "e", "F", "setSubdivision", "f", "x", "setPostalCode", "g", "Lcom/withpersona/sdk2/inquiry/network/dto/JsonLogicBoolean;", "getHidden", "()Lcom/withpersona/sdk2/inquiry/network/dto/JsonLogicBoolean;", "h", "getDisabled", "i", "Lsr/b;", "v", "()Lsr/b;", "y", "setSearchQuery", "Ljava/util/List;", "z", "()Ljava/util/List;", "setSearchResults", "(Ljava/util/List;)V", "l", "B", "setSelectedSearchResultId", "m", "Ljava/lang/Boolean;", "G", "()Ljava/lang/Boolean;", "setAddressAutocompleteLoading", "(Ljava/lang/Boolean;)V", "n", "H", "J", "S0", "()J", BuildConfig.FLAVOR, "Lbs/a;", "getAssociatedViews$annotations", "()V", "associatedViews", "Lsr/q;", "Lsr/q;", "r", "()Lsr/q;", "L", "(Lsr/q;)V", "isAddressFieldCollapsed$annotations", "isAddressFieldCollapsed", "Lnn/s;", "Lnn/s;", "()Lnn/s;", "O", "(Lnn/s;)V", "getTextControllerForAddressStreet1$annotations", "textControllerForAddressStreet1", "P", "getTextControllerForAddressStreet2$annotations", "textControllerForAddressStreet2", "M", "getTextControllerForAddressCity$annotations", "textControllerForAddressCity", "u", "R", "getTextControllerForAddressSubdivision$annotations", "textControllerForAddressSubdivision", "N", "getTextControllerForAddressPostalCode$annotations", "textControllerForAddressPostalCode", "ui-step-renderer_release"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* loaded from: classes3.dex */
public final /* data */ class InputAddressComponent implements x5, qr.c, w, h0 {

    /* renamed from: a, reason: collision with root package name and from kotlin metadata and from toString */
    @NotNull
    public final String name;

    /* renamed from: b, reason: from kotlin metadata and from toString */
    @NotNull
    public String street1;

    /* renamed from: c, reason: collision with root package name and from kotlin metadata and from toString */
    @NotNull
    public String street2;

    /* renamed from: d, reason: collision with root package name and from kotlin metadata and from toString */
    @NotNull
    public String city;

    /* renamed from: e, reason: collision with root package name and from kotlin metadata and from toString */
    @NotNull
    public String subdivision;

    /* renamed from: f, reason: collision with root package name and from kotlin metadata and from toString */
    @NotNull
    public String postalCode;

    /* renamed from: g, reason: collision with root package name and from kotlin metadata and from toString */
    @Nullable
    public final JsonLogicBoolean hidden;

    /* renamed from: h, reason: collision with root package name and from kotlin metadata and from toString */
    @Nullable
    public final JsonLogicBoolean disabled;

    /* renamed from: i, reason: collision with root package name and from kotlin metadata and from toString */
    @NotNull
    public final sr.b autocompleteMethod;

    /* renamed from: j, reason: collision with root package name and from kotlin metadata and from toString */
    @Nullable
    public String searchQuery;

    /* renamed from: k, reason: collision with root package name and from kotlin metadata and from toString */
    @Nullable
    public List<Suggestion> searchResults;

    /* renamed from: l, reason: collision with root package name and from kotlin metadata and from toString */
    @Nullable
    public String selectedSearchResultId;

    /* renamed from: m, reason: collision with root package name and from kotlin metadata and from toString */
    @Nullable
    public Boolean isAddressAutocompleteLoading;

    /* renamed from: n, reason: collision with root package name and from kotlin metadata and from toString */
    @Nullable
    public Boolean isAddressComponentsCollapsed;

    /* renamed from: o, reason: collision with root package name and from kotlin metadata and from toString */
    public final long lastValueUpdateTs;

    /* renamed from: p, reason: collision with root package name and from kotlin metadata */
    @NotNull
    public final List<bs.a> associatedViews;

    /* renamed from: q, reason: collision with root package name and from kotlin metadata */
    @NotNull
    public q isAddressFieldCollapsed;

    /* renamed from: r, reason: collision with root package name and from kotlin metadata */
    @NotNull
    public s textControllerForAddressStreet1;

    /* renamed from: s, reason: collision with root package name and from kotlin metadata */
    @NotNull
    public s textControllerForAddressStreet2;

    /* renamed from: t, reason: collision with root package name and from kotlin metadata */
    @NotNull
    public s textControllerForAddressCity;

    /* renamed from: u, reason: collision with root package name and from kotlin metadata */
    @NotNull
    public s textControllerForAddressSubdivision;

    /* renamed from: v, reason: collision with root package name and from kotlin metadata */
    @NotNull
    public s textControllerForAddressPostalCode;

    /* renamed from: w, reason: collision with root package name and from kotlin metadata */
    @NotNull
    public static final Companion INSTANCE = new Companion(null);

    @NotNull
    public static final Parcelable.Creator<InputAddressComponent> CREATOR = new b();

    @Metadata(d1 = {"\u0000\u001a\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\b\u0086\u0003\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\u0015\u0010\u0007\u001a\u00020\u00062\u0006\u0010\u0005\u001a\u00020\u0004¢\u0006\u0004\b\u0007\u0010\b¨\u0006\t"}, d2 = {"Lcom/withpersona/sdk2/inquiry/steps/ui/components/InputAddressComponent$a;", BuildConfig.FLAVOR, "<init>", "()V", "Lcom/withpersona/sdk2/inquiry/network/dto/ui/components/InputAddress;", "config", "Lcom/withpersona/sdk2/inquiry/steps/ui/components/InputAddressComponent;", xe.a.f36648e, "(Lcom/withpersona/sdk2/inquiry/network/dto/ui/components/InputAddress;)Lcom/withpersona/sdk2/inquiry/steps/ui/components/InputAddressComponent;", "ui-step-renderer_release"}, k = 1, mv = {2, 2, 0}, xi = 48)
    /* renamed from: com.withpersona.sdk2.inquiry.steps.ui.components.InputAddressComponent$a, reason: from kotlin metadata */
    public static final class Companion {
        public /* synthetic */ Companion(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }

        @NotNull
        public final InputAddressComponent a(@NotNull InputAddress config) {
            String str;
            String str2;
            String str3;
            String str4;
            String str5;
            String str6;
            boolean e10;
            String addressAutocompleteMethod;
            Intrinsics.checkNotNullParameter(config, "config");
            InputAddress.Attributes attributes = config.getAttributes();
            if (attributes == null || (addressAutocompleteMethod = attributes.getAddressAutocompleteMethod()) == null) {
                str = null;
            } else {
                Locale US = Locale.US;
                Intrinsics.checkNotNullExpressionValue(US, "US");
                str = addressAutocompleteMethod.toLowerCase(US);
                Intrinsics.checkNotNullExpressionValue(str, "toLowerCase(...)");
            }
            sr.b bVar = Intrinsics.c(str, "google_maps") ? sr.b.f31872a : sr.b.b;
            String name = config.getName();
            if (attributes == null || (str2 = attributes.getPrefillAddressStreet1()) == null) {
                str2 = BuildConfig.FLAVOR;
            }
            if (attributes == null || (str3 = attributes.getPrefillAddressStreet2()) == null) {
                str3 = BuildConfig.FLAVOR;
            }
            if (attributes == null || (str4 = attributes.getPrefillAddressCity()) == null) {
                str4 = BuildConfig.FLAVOR;
            }
            if (attributes == null || (str5 = attributes.getPrefillAddressSubdivision()) == null) {
                str5 = BuildConfig.FLAVOR;
            }
            if (attributes == null || (str6 = attributes.getPrefillAddressPostalCode()) == null) {
                str6 = BuildConfig.FLAVOR;
            }
            JsonLogicBoolean hidden = attributes != null ? attributes.getHidden() : null;
            JsonLogicBoolean disabled = attributes != null ? attributes.getDisabled() : null;
            e10 = q0.e(config);
            return new InputAddressComponent(name, str2, str3, str4, str5, str6, hidden, disabled, bVar, null, null, null, null, Boolean.valueOf(e10 && bVar != sr.b.b), 0L, 24064, null);
        }

        public Companion() {
        }
    }

    @Metadata(k = 3, mv = {2, 2, 0}, xi = 48)
    public static final class b implements Parcelable.Creator<InputAddressComponent> {
        @Override // android.os.Parcelable.Creator
        /* renamed from: a, reason: merged with bridge method [inline-methods] */
        public final InputAddressComponent createFromParcel(Parcel parcel) {
            ArrayList arrayList;
            Intrinsics.checkNotNullParameter(parcel, "parcel");
            String readString = parcel.readString();
            String readString2 = parcel.readString();
            String readString3 = parcel.readString();
            String readString4 = parcel.readString();
            String readString5 = parcel.readString();
            String readString6 = parcel.readString();
            JsonLogicBoolean jsonLogicBoolean = (JsonLogicBoolean) parcel.readParcelable(InputAddressComponent.class.getClassLoader());
            JsonLogicBoolean jsonLogicBoolean2 = (JsonLogicBoolean) parcel.readParcelable(InputAddressComponent.class.getClassLoader());
            sr.b valueOf = sr.b.valueOf(parcel.readString());
            String readString7 = parcel.readString();
            if (parcel.readInt() == 0) {
                arrayList = null;
            } else {
                int readInt = parcel.readInt();
                arrayList = new ArrayList(readInt);
                for (int i10 = 0; i10 != readInt; i10++) {
                    arrayList.add(Suggestion.CREATOR.createFromParcel(parcel));
                }
            }
            return new InputAddressComponent(readString, readString2, readString3, readString4, readString5, readString6, jsonLogicBoolean, jsonLogicBoolean2, valueOf, readString7, arrayList, parcel.readString(), parcel.readInt() == 0 ? null : Boolean.valueOf(parcel.readInt() != 0), parcel.readInt() != 0 ? Boolean.valueOf(parcel.readInt() != 0) : null, parcel.readLong());
        }

        @Override // android.os.Parcelable.Creator
        /* renamed from: b, reason: merged with bridge method [inline-methods] */
        public final InputAddressComponent[] newArray(int i10) {
            return new InputAddressComponent[i10];
        }
    }

    public InputAddressComponent(@NotNull String name, @NotNull String street1, @NotNull String street2, @NotNull String city, @NotNull String subdivision, @NotNull String postalCode, @Nullable JsonLogicBoolean jsonLogicBoolean, @Nullable JsonLogicBoolean jsonLogicBoolean2, @NotNull sr.b autocompleteMethod, @Nullable String str, @Nullable List<Suggestion> list, @Nullable String str2, @Nullable Boolean bool, @Nullable Boolean bool2, long j10) {
        Intrinsics.checkNotNullParameter(name, "name");
        Intrinsics.checkNotNullParameter(street1, "street1");
        Intrinsics.checkNotNullParameter(street2, "street2");
        Intrinsics.checkNotNullParameter(city, "city");
        Intrinsics.checkNotNullParameter(subdivision, "subdivision");
        Intrinsics.checkNotNullParameter(postalCode, "postalCode");
        Intrinsics.checkNotNullParameter(autocompleteMethod, "autocompleteMethod");
        this.name = name;
        this.street1 = street1;
        this.street2 = street2;
        this.city = city;
        this.subdivision = subdivision;
        this.postalCode = postalCode;
        this.hidden = jsonLogicBoolean;
        this.disabled = jsonLogicBoolean2;
        this.autocompleteMethod = autocompleteMethod;
        this.searchQuery = str;
        this.searchResults = list;
        this.selectedSearchResultId = str2;
        this.isAddressAutocompleteLoading = bool;
        this.isAddressComponentsCollapsed = bool2;
        this.lastValueUpdateTs = j10;
        this.associatedViews = new ArrayList();
        Boolean bool3 = this.isAddressComponentsCollapsed;
        this.isAddressFieldCollapsed = new q(bool3 != null ? bool3.booleanValue() : true);
        this.textControllerForAddressStreet1 = v.a(this.street1);
        this.textControllerForAddressStreet2 = v.a(this.street2);
        this.textControllerForAddressCity = v.a(this.city);
        this.textControllerForAddressSubdivision = v.a(this.subdivision);
        this.textControllerForAddressPostalCode = v.a(this.postalCode);
    }

    @hn.g(ignore = true)
    public static /* synthetic */ void getTextControllerForAddressCity$annotations() {
    }

    @hn.g(ignore = true)
    public static /* synthetic */ void getTextControllerForAddressPostalCode$annotations() {
    }

    @hn.g(ignore = true)
    public static /* synthetic */ void getTextControllerForAddressStreet1$annotations() {
    }

    @hn.g(ignore = true)
    public static /* synthetic */ void getTextControllerForAddressStreet2$annotations() {
    }

    @hn.g(ignore = true)
    public static /* synthetic */ void getTextControllerForAddressSubdivision$annotations() {
    }

    public static /* synthetic */ InputAddressComponent u(InputAddressComponent inputAddressComponent, String str, String str2, String str3, String str4, String str5, String str6, JsonLogicBoolean jsonLogicBoolean, JsonLogicBoolean jsonLogicBoolean2, sr.b bVar, String str7, List list, String str8, Boolean bool, Boolean bool2, long j10, int i10, Object obj) {
        long j11;
        String str9;
        String str10 = (i10 & 1) != 0 ? inputAddressComponent.name : str;
        String str11 = (i10 & 2) != 0 ? inputAddressComponent.street1 : str2;
        String str12 = (i10 & 4) != 0 ? inputAddressComponent.street2 : str3;
        String str13 = (i10 & 8) != 0 ? inputAddressComponent.city : str4;
        String str14 = (i10 & 16) != 0 ? inputAddressComponent.subdivision : str5;
        String str15 = (i10 & 32) != 0 ? inputAddressComponent.postalCode : str6;
        JsonLogicBoolean jsonLogicBoolean3 = (i10 & 64) != 0 ? inputAddressComponent.hidden : jsonLogicBoolean;
        JsonLogicBoolean jsonLogicBoolean4 = (i10 & Barcode.FORMAT_ITF) != 0 ? inputAddressComponent.disabled : jsonLogicBoolean2;
        sr.b bVar2 = (i10 & Barcode.FORMAT_QR_CODE) != 0 ? inputAddressComponent.autocompleteMethod : bVar;
        String str16 = (i10 & Barcode.FORMAT_UPC_A) != 0 ? inputAddressComponent.searchQuery : str7;
        List list2 = (i10 & Barcode.FORMAT_UPC_E) != 0 ? inputAddressComponent.searchResults : list;
        String str17 = (i10 & Barcode.FORMAT_PDF417) != 0 ? inputAddressComponent.selectedSearchResultId : str8;
        Boolean bool3 = (i10 & Barcode.FORMAT_AZTEC) != 0 ? inputAddressComponent.isAddressAutocompleteLoading : bool;
        Boolean bool4 = (i10 & 8192) != 0 ? inputAddressComponent.isAddressComponentsCollapsed : bool2;
        if ((i10 & 16384) != 0) {
            str9 = str10;
            j11 = inputAddressComponent.lastValueUpdateTs;
        } else {
            j11 = j10;
            str9 = str10;
        }
        return inputAddressComponent.t(str9, str11, str12, str13, str14, str15, jsonLogicBoolean3, jsonLogicBoolean4, bVar2, str16, list2, str17, bool3, bool4, j11);
    }

    @Nullable
    /* renamed from: B, reason: from getter */
    public final String getSelectedSearchResultId() {
        return this.selectedSearchResultId;
    }

    @NotNull
    /* renamed from: C, reason: from getter */
    public final String getStreet1() {
        return this.street1;
    }

    @NotNull
    /* renamed from: D, reason: from getter */
    public final String getStreet2() {
        return this.street2;
    }

    @NotNull
    /* renamed from: F, reason: from getter */
    public final String getSubdivision() {
        return this.subdivision;
    }

    @Nullable
    /* renamed from: G, reason: from getter */
    public final Boolean getIsAddressAutocompleteLoading() {
        return this.isAddressAutocompleteLoading;
    }

    @Nullable
    /* renamed from: H, reason: from getter */
    public final Boolean getIsAddressComponentsCollapsed() {
        return this.isAddressComponentsCollapsed;
    }

    public final void J(@Nullable Boolean bool) {
        this.isAddressComponentsCollapsed = bool;
    }

    public void L(@NotNull q qVar) {
        Intrinsics.checkNotNullParameter(qVar, "<set-?>");
        this.isAddressFieldCollapsed = qVar;
    }

    public void M(@NotNull s sVar) {
        Intrinsics.checkNotNullParameter(sVar, "<set-?>");
        this.textControllerForAddressCity = sVar;
    }

    public void N(@NotNull s sVar) {
        Intrinsics.checkNotNullParameter(sVar, "<set-?>");
        this.textControllerForAddressPostalCode = sVar;
    }

    public void O(@NotNull s sVar) {
        Intrinsics.checkNotNullParameter(sVar, "<set-?>");
        this.textControllerForAddressStreet1 = sVar;
    }

    public void P(@NotNull s sVar) {
        Intrinsics.checkNotNullParameter(sVar, "<set-?>");
        this.textControllerForAddressStreet2 = sVar;
    }

    public void R(@NotNull s sVar) {
        Intrinsics.checkNotNullParameter(sVar, "<set-?>");
        this.textControllerForAddressSubdivision = sVar;
    }

    @NotNull
    public InputAddressComponent S(@Nullable Boolean isAddressAutocompleteLoading) {
        InputAddressComponent f10;
        f10 = q0.f(u(this, null, null, null, null, null, null, null, null, null, null, null, null, isAddressAutocompleteLoading, null, System.currentTimeMillis(), 12287, null), this);
        return f10;
    }

    @Override // qr.x5
    /* renamed from: S0, reason: from getter */
    public long getLastValueUpdateTs() {
        return this.lastValueUpdateTs;
    }

    @NotNull
    public InputAddressComponent T(@Nullable String searchQuery) {
        InputAddressComponent f10;
        f10 = q0.f(u(this, null, null, null, null, null, null, null, null, null, searchQuery, null, null, null, null, System.currentTimeMillis(), 15871, null), this);
        return f10;
    }

    @NotNull
    public InputAddressComponent U(@Nullable List<Suggestion> searchResults) {
        InputAddressComponent f10;
        f10 = q0.f(u(this, null, null, null, null, null, null, null, null, null, null, searchResults, null, null, null, System.currentTimeMillis(), 15359, null), this);
        return f10;
    }

    @NotNull
    public InputAddressComponent V(@Nullable String resultId) {
        InputAddressComponent f10;
        f10 = q0.f(u(this, null, null, null, null, null, null, null, null, null, null, null, resultId, null, null, System.currentTimeMillis(), 14335, null), this);
        return f10;
    }

    @Override // qr.c
    @NotNull
    /* renamed from: a, reason: from getter */
    public s getTextControllerForAddressCity() {
        return this.textControllerForAddressCity;
    }

    @Override // android.os.Parcelable
    public final int describeContents() {
        return 0;
    }

    public boolean equals(@Nullable Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof InputAddressComponent)) {
            return false;
        }
        InputAddressComponent inputAddressComponent = (InputAddressComponent) other;
        return Intrinsics.c(this.name, inputAddressComponent.name) && Intrinsics.c(this.street1, inputAddressComponent.street1) && Intrinsics.c(this.street2, inputAddressComponent.street2) && Intrinsics.c(this.city, inputAddressComponent.city) && Intrinsics.c(this.subdivision, inputAddressComponent.subdivision) && Intrinsics.c(this.postalCode, inputAddressComponent.postalCode) && Intrinsics.c(this.hidden, inputAddressComponent.hidden) && Intrinsics.c(this.disabled, inputAddressComponent.disabled) && this.autocompleteMethod == inputAddressComponent.autocompleteMethod && Intrinsics.c(this.searchQuery, inputAddressComponent.searchQuery) && Intrinsics.c(this.searchResults, inputAddressComponent.searchResults) && Intrinsics.c(this.selectedSearchResultId, inputAddressComponent.selectedSearchResultId) && Intrinsics.c(this.isAddressAutocompleteLoading, inputAddressComponent.isAddressAutocompleteLoading) && Intrinsics.c(this.isAddressComponentsCollapsed, inputAddressComponent.isAddressComponentsCollapsed) && this.lastValueUpdateTs == inputAddressComponent.lastValueUpdateTs;
    }

    @Override // qr.c
    @NotNull
    /* renamed from: f, reason: from getter */
    public s getTextControllerForAddressPostalCode() {
        return this.textControllerForAddressPostalCode;
    }

    @Override // qr.c
    @NotNull
    /* renamed from: g, reason: from getter */
    public s getTextControllerForAddressSubdivision() {
        return this.textControllerForAddressSubdivision;
    }

    @Override // qr.w
    @Nullable
    public JsonLogicBoolean getDisabled() {
        return this.disabled;
    }

    @Override // qr.h0
    @Nullable
    public JsonLogicBoolean getHidden() {
        return this.hidden;
    }

    @Override // qr.x5
    @NotNull
    public String getName() {
        return this.name;
    }

    public int hashCode() {
        int hashCode = ((((((((((this.name.hashCode() * 31) + this.street1.hashCode()) * 31) + this.street2.hashCode()) * 31) + this.city.hashCode()) * 31) + this.subdivision.hashCode()) * 31) + this.postalCode.hashCode()) * 31;
        JsonLogicBoolean jsonLogicBoolean = this.hidden;
        int hashCode2 = (hashCode + (jsonLogicBoolean == null ? 0 : jsonLogicBoolean.hashCode())) * 31;
        JsonLogicBoolean jsonLogicBoolean2 = this.disabled;
        int hashCode3 = (((hashCode2 + (jsonLogicBoolean2 == null ? 0 : jsonLogicBoolean2.hashCode())) * 31) + this.autocompleteMethod.hashCode()) * 31;
        String str = this.searchQuery;
        int hashCode4 = (hashCode3 + (str == null ? 0 : str.hashCode())) * 31;
        List<Suggestion> list = this.searchResults;
        int hashCode5 = (hashCode4 + (list == null ? 0 : list.hashCode())) * 31;
        String str2 = this.selectedSearchResultId;
        int hashCode6 = (hashCode5 + (str2 == null ? 0 : str2.hashCode())) * 31;
        Boolean bool = this.isAddressAutocompleteLoading;
        int hashCode7 = (hashCode6 + (bool == null ? 0 : bool.hashCode())) * 31;
        Boolean bool2 = this.isAddressComponentsCollapsed;
        return ((hashCode7 + (bool2 != null ? bool2.hashCode() : 0)) * 31) + Long.hashCode(this.lastValueUpdateTs);
    }

    @Override // qr.h0
    @NotNull
    public List<bs.a> i() {
        return this.associatedViews;
    }

    @Override // qr.c
    @NotNull
    public InputAddressComponent j(@Nullable String newString) {
        InputAddressComponent f10;
        f10 = q0.f(u(this, null, null, newString == null ? BuildConfig.FLAVOR : newString, null, null, null, null, null, null, null, null, null, null, null, System.currentTimeMillis(), 16379, null), this);
        return f10;
    }

    @Override // qr.c
    @NotNull
    public InputAddressComponent k(@Nullable String newString) {
        InputAddressComponent f10;
        f10 = q0.f(u(this, null, null, null, newString == null ? BuildConfig.FLAVOR : newString, null, null, null, null, null, null, null, null, null, null, System.currentTimeMillis(), 16375, null), this);
        return f10;
    }

    @Override // qr.c
    @NotNull
    /* renamed from: l, reason: from getter */
    public s getTextControllerForAddressStreet1() {
        return this.textControllerForAddressStreet1;
    }

    @Override // qr.c
    @NotNull
    /* renamed from: n, reason: from getter */
    public s getTextControllerForAddressStreet2() {
        return this.textControllerForAddressStreet2;
    }

    @Override // qr.c
    @NotNull
    public InputAddressComponent o(@Nullable Boolean newState) {
        InputAddressComponent f10;
        f10 = q0.f(u(this, null, null, null, null, null, null, null, null, null, null, null, null, null, newState, System.currentTimeMillis(), 8191, null), this);
        return f10;
    }

    @Override // qr.c
    @NotNull
    public InputAddressComponent p(@Nullable String newString) {
        InputAddressComponent f10;
        f10 = q0.f(u(this, null, null, null, null, null, newString == null ? BuildConfig.FLAVOR : newString, null, null, null, null, null, null, null, null, System.currentTimeMillis(), 16351, null), this);
        return f10;
    }

    @Override // qr.c
    @NotNull
    public InputAddressComponent q(@Nullable String newString) {
        InputAddressComponent f10;
        f10 = q0.f(u(this, null, newString == null ? BuildConfig.FLAVOR : newString, null, null, null, null, null, null, null, null, null, null, null, null, System.currentTimeMillis(), 16381, null), this);
        return f10;
    }

    @Override // qr.c
    @NotNull
    /* renamed from: r, reason: from getter */
    public q getIsAddressFieldCollapsed() {
        return this.isAddressFieldCollapsed;
    }

    @Override // qr.c
    @NotNull
    public InputAddressComponent s(@Nullable String newString) {
        InputAddressComponent f10;
        f10 = q0.f(u(this, null, null, null, null, newString == null ? BuildConfig.FLAVOR : newString, null, null, null, null, null, null, null, null, null, System.currentTimeMillis(), 16367, null), this);
        return f10;
    }

    @NotNull
    public final InputAddressComponent t(@NotNull String name, @NotNull String street1, @NotNull String street2, @NotNull String city, @NotNull String subdivision, @NotNull String postalCode, @Nullable JsonLogicBoolean hidden, @Nullable JsonLogicBoolean disabled, @NotNull sr.b autocompleteMethod, @Nullable String searchQuery, @Nullable List<Suggestion> searchResults, @Nullable String selectedSearchResultId, @Nullable Boolean isAddressAutocompleteLoading, @Nullable Boolean isAddressComponentsCollapsed, long lastValueUpdateTs) {
        Intrinsics.checkNotNullParameter(name, "name");
        Intrinsics.checkNotNullParameter(street1, "street1");
        Intrinsics.checkNotNullParameter(street2, "street2");
        Intrinsics.checkNotNullParameter(city, "city");
        Intrinsics.checkNotNullParameter(subdivision, "subdivision");
        Intrinsics.checkNotNullParameter(postalCode, "postalCode");
        Intrinsics.checkNotNullParameter(autocompleteMethod, "autocompleteMethod");
        return new InputAddressComponent(name, street1, street2, city, subdivision, postalCode, hidden, disabled, autocompleteMethod, searchQuery, searchResults, selectedSearchResultId, isAddressAutocompleteLoading, isAddressComponentsCollapsed, lastValueUpdateTs);
    }

    @NotNull
    public String toString() {
        return "InputAddressComponent(name=" + this.name + ", street1=" + this.street1 + ", street2=" + this.street2 + ", city=" + this.city + ", subdivision=" + this.subdivision + ", postalCode=" + this.postalCode + ", hidden=" + this.hidden + ", disabled=" + this.disabled + ", autocompleteMethod=" + this.autocompleteMethod + ", searchQuery=" + this.searchQuery + ", searchResults=" + this.searchResults + ", selectedSearchResultId=" + this.selectedSearchResultId + ", isAddressAutocompleteLoading=" + this.isAddressAutocompleteLoading + ", isAddressComponentsCollapsed=" + this.isAddressComponentsCollapsed + ", lastValueUpdateTs=" + this.lastValueUpdateTs + ")";
    }

    @NotNull
    /* renamed from: v, reason: from getter */
    public final sr.b getAutocompleteMethod() {
        return this.autocompleteMethod;
    }

    @NotNull
    /* renamed from: w, reason: from getter */
    public final String getCity() {
        return this.city;
    }

    @Override // android.os.Parcelable
    public final void writeToParcel(@NotNull Parcel dest, int flags) {
        Intrinsics.checkNotNullParameter(dest, "dest");
        dest.writeString(this.name);
        dest.writeString(this.street1);
        dest.writeString(this.street2);
        dest.writeString(this.city);
        dest.writeString(this.subdivision);
        dest.writeString(this.postalCode);
        dest.writeParcelable(this.hidden, flags);
        dest.writeParcelable(this.disabled, flags);
        dest.writeString(this.autocompleteMethod.name());
        dest.writeString(this.searchQuery);
        List<Suggestion> list = this.searchResults;
        if (list == null) {
            dest.writeInt(0);
        } else {
            dest.writeInt(1);
            dest.writeInt(list.size());
            Iterator<Suggestion> it = list.iterator();
            while (it.hasNext()) {
                it.next().writeToParcel(dest, flags);
            }
        }
        dest.writeString(this.selectedSearchResultId);
        Boolean bool = this.isAddressAutocompleteLoading;
        if (bool == null) {
            dest.writeInt(0);
        } else {
            dest.writeInt(1);
            dest.writeInt(bool.booleanValue() ? 1 : 0);
        }
        Boolean bool2 = this.isAddressComponentsCollapsed;
        if (bool2 == null) {
            dest.writeInt(0);
        } else {
            dest.writeInt(1);
            dest.writeInt(bool2.booleanValue() ? 1 : 0);
        }
        dest.writeLong(this.lastValueUpdateTs);
    }

    @NotNull
    /* renamed from: x, reason: from getter */
    public final String getPostalCode() {
        return this.postalCode;
    }

    @Nullable
    /* renamed from: y, reason: from getter */
    public final String getSearchQuery() {
        return this.searchQuery;
    }

    @Nullable
    public final List<Suggestion> z() {
        return this.searchResults;
    }

    public /* synthetic */ InputAddressComponent(String str, String str2, String str3, String str4, String str5, String str6, JsonLogicBoolean jsonLogicBoolean, JsonLogicBoolean jsonLogicBoolean2, sr.b bVar, String str7, List list, String str8, Boolean bool, Boolean bool2, long j10, int i10, DefaultConstructorMarker defaultConstructorMarker) {
        this(str, str2, str3, str4, str5, str6, jsonLogicBoolean, jsonLogicBoolean2, bVar, (i10 & Barcode.FORMAT_UPC_A) != 0 ? null : str7, (i10 & Barcode.FORMAT_UPC_E) != 0 ? null : list, (i10 & Barcode.FORMAT_PDF417) != 0 ? null : str8, (i10 & Barcode.FORMAT_AZTEC) != 0 ? null : bool, (i10 & 8192) != 0 ? null : bool2, (i10 & 16384) != 0 ? 0L : j10);
    }


    // --- восстановлено из DEX (com/withpersona/sdk2/inquiry/steps/ui/components/InputAddressComponent$a) ---
    public static class a {
        public a() { }
        public a(kotlin.jvm.internal.DefaultConstructorMarker p0) { }
        public com.withpersona.sdk2.inquiry.steps.ui.components.InputAddressComponent a(com.withpersona.sdk2.inquiry.network.dto.ui.components.InputAddress p0) { throw new UnsupportedOperationException("stub"); }
    }
}
