package com.withpersona.sdk2.inquiry.selfie.view;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewPropertyAnimator;
import android.widget.ImageView;
import androidx.constraintlayout.widget.ConstraintLayout;
import com.github.luben.zstd.BuildConfig;
import com.google.mlkit.common.MlKitException;
import com.withpersona.sdk2.inquiry.network.dto.ui.components.RemoteImage;
import com.withpersona.sdk2.inquiry.network.dto.ui.styling.StepStyles;

import com.withpersona.sdk2.inquiry.shared.ui.ThemeableLottieAnimationView;
import g7.i;
import g7.n0;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import mq.w;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import xq.j;
import xq.z;
import zt.h;
import zt.l;

@Metadata(d1 = {"\u0000\u0080\u0001\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\b\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0010\t\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0015\n\u0002\u0018\u0002\n\u0002\b\r\n\u0002\u0010!\n\u0002\b\u000b\u0018\u00002\u00020\u0001:\u0001_B'\b\u0007\u0012\u0006\u0010\u0003\u001a\u00020\u0002\u0012\n\b\u0002\u0010\u0005\u001a\u0004\u0018\u00010\u0004\u0012\b\b\u0002\u0010\u0007\u001a\u00020\u0006¢\u0006\u0004\b\b\u0010\tJ\u0015\u0010\r\u001a\u00020\f2\u0006\u0010\u000b\u001a\u00020\n¢\u0006\u0004\b\r\u0010\u000eJ\u0015\u0010\u0011\u001a\u00020\f2\u0006\u0010\u0010\u001a\u00020\u000f¢\u0006\u0004\b\u0011\u0010\u0012J1\u0010\u0019\u001a\u00020\f2\u0006\u0010\u0014\u001a\u00020\u00132\b\b\u0002\u0010\u0016\u001a\u00020\u00152\u0010\b\u0002\u0010\u0018\u001a\n\u0012\u0004\u0012\u00020\f\u0018\u00010\u0017¢\u0006\u0004\b\u0019\u0010\u001aJ\u0019\u0010\u001d\u001a\u00020\u00152\b\u0010\u001c\u001a\u0004\u0018\u00010\u001bH\u0016¢\u0006\u0004\b\u001d\u0010\u001eJ\r\u0010\u001f\u001a\u00020\u0015¢\u0006\u0004\b\u001f\u0010 J\u001b\u0010\"\u001a\u00020\f2\f\u0010!\u001a\b\u0012\u0004\u0012\u00020\f0\u0017¢\u0006\u0004\b\"\u0010#J-\u0010&\u001a\u00020\f*\u00020$2\b\b\u0001\u0010%\u001a\u00020\u00062\u000e\u0010\u0018\u001a\n\u0012\u0004\u0012\u00020\f\u0018\u00010\u0017H\u0002¢\u0006\u0004\b&\u0010'J#\u0010(\u001a\u00020\f*\u00020$2\u000e\u0010\u0018\u001a\n\u0012\u0004\u0012\u00020\f\u0018\u00010\u0017H\u0002¢\u0006\u0004\b(\u0010)J\u001d\u0010-\u001a\u00020,*\u00020\n2\b\b\u0002\u0010+\u001a\u00020*H\u0002¢\u0006\u0004\b-\u0010.J\u001d\u0010/\u001a\u00020,*\u00020\n2\b\b\u0002\u0010+\u001a\u00020*H\u0002¢\u0006\u0004\b/\u0010.J\u001d\u00103\u001a\u00020\f*\u0002002\b\u00102\u001a\u0004\u0018\u000101H\u0002¢\u0006\u0004\b3\u00104J\u0017\u00105\u001a\u00020\u00152\u0006\u0010\u0003\u001a\u00020\u0002H\u0002¢\u0006\u0004\b5\u00106R\u0014\u00109\u001a\u00020$8\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b7\u00108R\u001d\u0010>\u001a\u0004\u0018\u0001018BX\u0082\u0084\u0002¢\u0006\f\n\u0004\b:\u0010;\u001a\u0004\b<\u0010=R\u001d\u0010A\u001a\u0004\u0018\u0001018BX\u0082\u0084\u0002¢\u0006\f\n\u0004\b?\u0010;\u001a\u0004\b@\u0010=R\u0014\u0010D\u001a\u00020\u00068\u0002X\u0083\u0004¢\u0006\u0006\n\u0004\bB\u0010CR\u0014\u0010F\u001a\u00020\u00068\u0002X\u0083\u0004¢\u0006\u0006\n\u0004\bE\u0010CR$\u0010N\u001a\u0004\u0018\u00010G8\u0006@\u0006X\u0086\u000e¢\u0006\u0012\n\u0004\bH\u0010I\u001a\u0004\bJ\u0010K\"\u0004\bL\u0010MR$\u0010R\u001a\u0004\u0018\u00010G8\u0006@\u0006X\u0086\u000e¢\u0006\u0012\n\u0004\bO\u0010I\u001a\u0004\bP\u0010K\"\u0004\bQ\u0010MR\u0016\u0010\u000b\u001a\u00020\n8\u0002@\u0002X\u0082.¢\u0006\u0006\n\u0004\bS\u0010TR \u0010X\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\f0\u00170U8\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\bV\u0010WR \u0010Y\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\f0\u00170U8\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\bC\u0010WR\u0018\u0010[\u001a\u0004\u0018\u00010\n8\u0002@\u0002X\u0082\u000e¢\u0006\u0006\n\u0004\bZ\u0010TR\u0018\u0010^\u001a\u0004\u0018\u00010\u00138\u0002@\u0002X\u0082\u000e¢\u0006\u0006\n\u0004\b\\\u0010]¨\u0006`"}, d2 = {"Lcom/withpersona/sdk2/inquiry/selfie/view/OldSelfieOverlayView;", "Landroidx/constraintlayout/widget/ConstraintLayout;", "Landroid/content/Context;", "context", "Landroid/util/AttributeSet;", "attrs", BuildConfig.FLAVOR, "defStyleAttr", "<init>", "(Landroid/content/Context;Landroid/util/AttributeSet;I)V", "Landroid/view/View;", "previewView", BuildConfig.FLAVOR, "setPreviewView", "(Landroid/view/View;)V", "Lcom/withpersona/sdk2/inquiry/network/dto/ui/styling/StepStyles$SelfieStepStyle;", "styles", "W", "(Lcom/withpersona/sdk2/inquiry/network/dto/ui/styling/StepStyles$SelfieStepStyle;)V", "Lcom/withpersona/sdk2/inquiry/selfie/view/OldSelfieOverlayView$b;", "viewState", BuildConfig.FLAVOR, "showProgress", "Lkotlin/Function0;", "onAnimationEnd", "e0", "(Lcom/withpersona/sdk2/inquiry/selfie/view/OldSelfieOverlayView$b;ZLkotlin/jvm/functions/Function0;)V", "Landroid/view/MotionEvent;", "event", "onTouchEvent", "(Landroid/view/MotionEvent;)Z", "a0", "()Z", "onComplete", "X", "(Lkotlin/jvm/functions/Function0;)V", "Loq/b;", "rawRes", "i0", "(Loq/b;ILkotlin/jvm/functions/Function0;)V", "b0", "(Loq/b;Lkotlin/jvm/functions/Function0;)V", BuildConfig.FLAVOR, "duration", "Landroid/view/ViewPropertyAnimator;", "R", "(Landroid/view/View;J)Landroid/view/ViewPropertyAnimator;", "U", "Landroid/widget/ImageView;", "Landroid/graphics/drawable/Drawable;", "drawable", "n0", "(Landroid/widget/ImageView;Landroid/graphics/drawable/Drawable;)V", "p0", "(Landroid/content/Context;)Z", "z", "Loq/b;", "binding", "A", "Lzt/h;", "getDrawableLeft", "()Landroid/graphics/drawable/Drawable;", "drawableLeft", "B", "getDrawableRight", "drawableRight", "C", "I", "leftPoseAnimation", "D", "rightPoseAnimation", "Lcom/withpersona/sdk2/inquiry/network/dto/ui/components/RemoteImage;", "E", "Lcom/withpersona/sdk2/inquiry/network/dto/ui/components/RemoteImage;", "getLeftPoseImage", "()Lcom/withpersona/sdk2/inquiry/network/dto/ui/components/RemoteImage;", "setLeftPoseImage", "(Lcom/withpersona/sdk2/inquiry/network/dto/ui/components/RemoteImage;)V", "leftPoseImage", "F", "getRightPoseImage", "setRightPoseImage", "rightPoseImage", "G", "Landroid/view/View;", BuildConfig.FLAVOR, "H", "Ljava/util/List;", "oneShotOnCompositionLoadedListeners", "oneShotOnAnimationCompleteListeners", "J", "remoteImageView", "K", "Lcom/withpersona/sdk2/inquiry/selfie/view/OldSelfieOverlayView$b;", "currentViewState", k6.b.f21144e, "selfie_release"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* loaded from: classes3.dex */
public final class OldSelfieOverlayView extends ConstraintLayout {

    /* renamed from: A, reason: from kotlin metadata */
    @NotNull
    public final h drawableLeft;

    /* renamed from: B, reason: from kotlin metadata */
    @NotNull
    public final h drawableRight;

    /* renamed from: C, reason: from kotlin metadata */
    public final int leftPoseAnimation;

    /* renamed from: D, reason: from kotlin metadata */
    public final int rightPoseAnimation;

    /* renamed from: E, reason: from kotlin metadata */
    @Nullable
    public RemoteImage leftPoseImage;

    /* renamed from: F, reason: from kotlin metadata */
    @Nullable
    public RemoteImage rightPoseImage;

    /* renamed from: G, reason: from kotlin metadata */
    public View previewView;

    /* renamed from: H, reason: from kotlin metadata */
    @NotNull
    public final List<Function0<Unit>> oneShotOnCompositionLoadedListeners;

    /* renamed from: I, reason: from kotlin metadata */
    @NotNull
    public final List<Function0<Unit>> oneShotOnAnimationCompleteListeners;

    /* renamed from: J, reason: from kotlin metadata */
    @Nullable
    public View remoteImageView;

    /* renamed from: K, reason: from kotlin metadata */
    @Nullable
    public b currentViewState;

    /* renamed from: z, reason: collision with root package name and from kotlin metadata */
    @NotNull
    public final oq.b binding;

    @Metadata(d1 = {"\u0000\u0017\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0003*\u0001\u0000\b\n\u0018\u00002\u00020\u0001J\u0017\u0010\u0005\u001a\u00020\u00042\u0006\u0010\u0003\u001a\u00020\u0002H\u0016¢\u0006\u0004\b\u0005\u0010\u0006¨\u0006\u0007"}, d2 = {"com/withpersona/sdk2/inquiry/selfie/view/OldSelfieOverlayView$a", "Landroid/animation/AnimatorListenerAdapter;", "Landroid/animation/Animator;", "animation", BuildConfig.FLAVOR, "onAnimationEnd", "(Landroid/animation/Animator;)V", "selfie_release"}, k = 1, mv = {2, 2, 0}, xi = 48)
    public static final class a extends AnimatorListenerAdapter {
        public a() {
        }

        @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
        public void onAnimationEnd(Animator animation) {
            Intrinsics.checkNotNullParameter(animation, "animation");
            List M0 = CollectionsKt.M0(OldSelfieOverlayView.this.oneShotOnAnimationCompleteListeners);
            OldSelfieOverlayView.this.oneShotOnAnimationCompleteListeners.clear();
            Iterator it = M0.iterator();
            while (it.hasNext()) {
                ((Function0) it.next()).invoke();
            }
        }
    }

    /* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
    /* JADX WARN: Unknown enum class pattern. Please report as an issue! */
    @Metadata(d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0010\u0010\n\u0002\b\u0015\b\u0086\u0081\u0002\u0018\u00002\b\u0012\u0004\u0012\u00020\u00000\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003j\u0002\b\u0004j\u0002\b\u0005j\u0002\b\u0006j\u0002\b\u0007j\u0002\b\bj\u0002\b\tj\u0002\b\nj\u0002\b\u000bj\u0002\b\fj\u0002\b\rj\u0002\b\u000ej\u0002\b\u000fj\u0002\b\u0010j\u0002\b\u0011j\u0002\b\u0012j\u0002\b\u0013j\u0002\b\u0014j\u0002\b\u0015¨\u0006\u0016"}, d2 = {"Lcom/withpersona/sdk2/inquiry/selfie/view/OldSelfieOverlayView$b;", BuildConfig.FLAVOR, "<init>", "(Ljava/lang/String;I)V", xe.a.f36648e, k6.b.f21144e, "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "selfie_release"}, k = 1, mv = {2, 2, 0}, xi = 48)
    public static final class b {

        /* renamed from: a, reason: collision with root package name */
        public static final b f10980a = new b("CLEAR", 0);
        public static final b b = new b("CENTER", 1);

        /* renamed from: c, reason: collision with root package name */
        public static final b f10981c = new b("CENTER_COMPLETE", 2);

        /* renamed from: d, reason: collision with root package name */
        public static final b f10982d = new b("LOOK_LEFT_HINT", 3);

        /* renamed from: e, reason: collision with root package name */
        public static final b f10983e = new b("LOOK_LEFT", 4);

        /* renamed from: f, reason: collision with root package name */
        public static final b f10984f = new b("LOOK_LEFT_COMPLETE", 5);

        /* renamed from: g, reason: collision with root package name */
        public static final b f10985g = new b("LOOK_RIGHT_HINT", 6);

        /* renamed from: h, reason: collision with root package name */
        public static final b f10986h = new b("LOOK_RIGHT", 7);

        /* renamed from: i, reason: collision with root package name */
        public static final b f10987i = new b("LOOK_RIGHT_COMPLETE", 8);

        /* renamed from: j, reason: collision with root package name */
        public static final b f10988j = new b("LOOK_UP_HINT", 9);

        /* renamed from: k, reason: collision with root package name */
        public static final b f10989k = new b("LOOK_UP", 10);

        /* renamed from: l, reason: collision with root package name */
        public static final b f10990l = new b("LOOK_UP_COMPLETE", 11);

        /* renamed from: m, reason: collision with root package name */
        public static final b f10991m = new b("LOOK_DOWN_HINT", 12);

        /* renamed from: n, reason: collision with root package name */
        public static final b f10992n = new b("LOOK_DOWN", 13);

        /* renamed from: o, reason: collision with root package name */
        public static final b f10993o = new b("LOOK_DOWN_COMPLETE", 14);

        /* renamed from: p, reason: collision with root package name */
        public static final b f10994p = new b("FINALIZING", 15);

        /* renamed from: q, reason: collision with root package name */
        public static final b f10995q = new b("COMPLETE_WITH_CAPTURE", 16);

        /* renamed from: r, reason: collision with root package name */
        public static final b f10996r = new b("COMPLETE", 17);

        /* renamed from: s, reason: collision with root package name */
        public static final /* synthetic */ b[] f10997s;

        /* renamed from: t, reason: collision with root package name */
        public static final /* synthetic */ hu.a f10998t;

        static {
            b[] a10 = a();
            f10997s = a10;
            f10998t = hu.b.a(a10);
        }

        public b(String str, int i10) {
        }

        public static final /* synthetic */ b[] a() {
            return new b[]{f10980a, b, f10981c, f10982d, f10983e, f10984f, f10985g, f10986h, f10987i, f10988j, f10989k, f10990l, f10991m, f10992n, f10993o, f10994p, f10995q, f10996r};
        }

        public static b valueOf(String str) {
            return (b) Enum.valueOf(b.class, str);
        }

        public static b[] values() {
            return (b[]) f10997s.clone();
        }
    }

    @Metadata(k = 3, mv = {2, 2, 0}, xi = 48)
    public static final /* synthetic */ class c {

        /* renamed from: a, reason: collision with root package name */
        public static final /* synthetic */ int[] f10999a;

        static {
            int[] iArr = new int[b.values().length];
            try {
                iArr[b.f10980a.ordinal()] = 1;
            } catch (NoSuchFieldError unused) {
            }
            try {
                iArr[b.b.ordinal()] = 2;
            } catch (NoSuchFieldError unused2) {
            }
            try {
                iArr[b.f10981c.ordinal()] = 3;
            } catch (NoSuchFieldError unused3) {
            }
            try {
                iArr[b.f10982d.ordinal()] = 4;
            } catch (NoSuchFieldError unused4) {
            }
            try {
                iArr[b.f10983e.ordinal()] = 5;
            } catch (NoSuchFieldError unused5) {
            }
            try {
                iArr[b.f10984f.ordinal()] = 6;
            } catch (NoSuchFieldError unused6) {
            }
            try {
                iArr[b.f10985g.ordinal()] = 7;
            } catch (NoSuchFieldError unused7) {
            }
            try {
                iArr[b.f10986h.ordinal()] = 8;
            } catch (NoSuchFieldError unused8) {
            }
            try {
                iArr[b.f10987i.ordinal()] = 9;
            } catch (NoSuchFieldError unused9) {
            }
            try {
                iArr[b.f10994p.ordinal()] = 10;
            } catch (NoSuchFieldError unused10) {
            }
            try {
                iArr[b.f10995q.ordinal()] = 11;
            } catch (NoSuchFieldError unused11) {
            }
            try {
                iArr[b.f10996r.ordinal()] = 12;
            } catch (NoSuchFieldError unused12) {
            }
            try {
                iArr[b.f10988j.ordinal()] = 13;
            } catch (NoSuchFieldError unused13) {
            }
            try {
                iArr[b.f10989k.ordinal()] = 14;
            } catch (NoSuchFieldError unused14) {
            }
            try {
                iArr[b.f10990l.ordinal()] = 15;
            } catch (NoSuchFieldError unused15) {
            }
            try {
                iArr[b.f10991m.ordinal()] = 16;
            } catch (NoSuchFieldError unused16) {
            }
            try {
                iArr[b.f10992n.ordinal()] = 17;
            } catch (NoSuchFieldError unused17) {
            }
            try {
                iArr[b.f10993o.ordinal()] = 18;
            } catch (NoSuchFieldError unused18) {
            }
            f10999a = iArr;
        }
    }

    /* JADX WARN: 'this' call moved to the top of the method (can break code semantics) */
    public OldSelfieOverlayView(@NotNull Context context, @Nullable AttributeSet attributeSet) {
        this(context, attributeSet, 0, 4, null);
        Intrinsics.checkNotNullParameter(context, "context");
    }

    public static void I(OldSelfieOverlayView oldSelfieOverlayView, i iVar) {
        List M0 = CollectionsKt.M0(oldSelfieOverlayView.oneShotOnCompositionLoadedListeners);
        oldSelfieOverlayView.oneShotOnCompositionLoadedListeners.clear();
        Iterator it = M0.iterator();
        while (it.hasNext()) {
            ((Function0) it.next()).invoke();
        }
    }

    public static /* synthetic */ ViewPropertyAnimator S(OldSelfieOverlayView oldSelfieOverlayView, View view, long j10, int i10, Object obj) {
        if ((i10 & 1) != 0) {
            j10 = 200;
        }
        return oldSelfieOverlayView.R(view, j10);
    }

    public static final void T(View view) {
        view.setVisibility(4);
    }

    public static /* synthetic */ ViewPropertyAnimator V(OldSelfieOverlayView oldSelfieOverlayView, View view, long j10, int i10, Object obj) {
        if ((i10 & 1) != 0) {
            j10 = 200;
        }
        return oldSelfieOverlayView.U(view, j10);
    }

    public static final Drawable Y(Context context) {
        Integer f10 = z.f(context, jq.a.f20839q, null, false, 6, null);
        return f10 != null ? l2.b.f(context, f10.intValue()) : l2.b.f(context, w.f24127c);
    }

    public static final Drawable Z(Context context) {
        Integer f10 = z.f(context, jq.a.f20841s, null, false, 6, null);
        return f10 != null ? l2.b.f(context, f10.intValue()) : l2.b.f(context, w.f24128d);
    }

    public static final void c0(OldSelfieOverlayView oldSelfieOverlayView, oq.b bVar, final Function0 function0) {
        View blindsView = bVar.b;
        Intrinsics.checkNotNullExpressionValue(blindsView, "blindsView");
        oldSelfieOverlayView.R(blindsView, 80L).withEndAction(new Runnable() { // from class: wq.l
            @Override // java.lang.Runnable
            public final void run() {
                OldSelfieOverlayView.d0(Function0.this);
            }
        });
    }

    public static final void d0(Function0 function0) {
        if (function0 != null) {
            function0.invoke();
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    public static /* synthetic */ void f0(OldSelfieOverlayView oldSelfieOverlayView, b bVar, boolean z10, Function0 function0, int i10, Object obj) {
        if ((i10 & 2) != 0) {
            z10 = true;
        }
        if ((i10 & 4) != 0) {
            function0 = null;
        }
        oldSelfieOverlayView.e0(bVar, z10, function0);
    }

    public static final Unit g0(OldSelfieOverlayView oldSelfieOverlayView, Function0 function0) {
        oldSelfieOverlayView.i0(oldSelfieOverlayView.binding, mq.z.f24345d, function0);
        return Unit.f21504a;
    }

    private final Drawable getDrawableLeft() {
        return (Drawable) this.drawableLeft.getValue();
    }

    private final Drawable getDrawableRight() {
        return (Drawable) this.drawableRight.getValue();
    }

    public static final Unit h0(OldSelfieOverlayView oldSelfieOverlayView, Function0 function0) {
        oldSelfieOverlayView.i0(oldSelfieOverlayView.binding, mq.z.f24345d, function0);
        return Unit.f21504a;
    }

    public static final Unit j0(final oq.b bVar, final OldSelfieOverlayView oldSelfieOverlayView, final Function0 function0) {
        bVar.f28339d.setFrame(0);
        ThemeableLottieAnimationView hintAnimation = bVar.f28339d;
        Intrinsics.checkNotNullExpressionValue(hintAnimation, "hintAnimation");
        V(oldSelfieOverlayView, hintAnimation, 0L, 1, null).withEndAction(new Runnable() { // from class: wq.b
            @Override // java.lang.Runnable
            public final void run() {
                OldSelfieOverlayView.k0(OldSelfieOverlayView.this, bVar, function0);
            }
        });
        View hintOverlayView = bVar.f28341f;
        Intrinsics.checkNotNullExpressionValue(hintOverlayView, "hintOverlayView");
        V(oldSelfieOverlayView, hintOverlayView, 0L, 1, null);
        return Unit.f21504a;
    }

    public static final void k0(final OldSelfieOverlayView oldSelfieOverlayView, final oq.b bVar, final Function0 function0) {
        oldSelfieOverlayView.oneShotOnAnimationCompleteListeners.add(new Function0() { // from class: wq.c
            @Override // kotlin.jvm.functions.Function0
            public final Object invoke() {
                Unit l02;
                l02 = OldSelfieOverlayView.l0(OldSelfieOverlayView.this, bVar, function0);
                return l02;
            }
        });
        bVar.f28339d.v();
    }

    public static final Unit l0(OldSelfieOverlayView oldSelfieOverlayView, oq.b bVar, final Function0 function0) {
        ThemeableLottieAnimationView hintAnimation = bVar.f28339d;
        Intrinsics.checkNotNullExpressionValue(hintAnimation, "hintAnimation");
        S(oldSelfieOverlayView, hintAnimation, 0L, 1, null).withEndAction(new Runnable() { // from class: wq.d
            @Override // java.lang.Runnable
            public final void run() {
                OldSelfieOverlayView.m0(Function0.this);
            }
        });
        View hintOverlayView = bVar.f28341f;
        Intrinsics.checkNotNullExpressionValue(hintOverlayView, "hintOverlayView");
        S(oldSelfieOverlayView, hintOverlayView, 0L, 1, null);
        return Unit.f21504a;
    }

    public static final void m0(Function0 function0) {
        if (function0 != null) {
            function0.invoke();
        }
    }

    public static final void o0(ImageView imageView) {
        imageView.setImageDrawable(null);
    }

    public final ViewPropertyAnimator R(final View view, long j10) {
        ViewPropertyAnimator withEndAction = view.animate().alpha(0.0f).setDuration(j10).withEndAction(new Runnable() { // from class: wq.m
            @Override // java.lang.Runnable
            public final void run() {
                OldSelfieOverlayView.T(view);
            }
        });
        Intrinsics.checkNotNullExpressionValue(withEndAction, "withEndAction(...)");
        return withEndAction;
    }

    public final ViewPropertyAnimator U(View view, long j10) {
        if (view.getVisibility() != 0) {
            view.setAlpha(0.0f);
            view.setVisibility(0);
        }
        ViewPropertyAnimator duration = view.animate().alpha(1.0f).setDuration(j10);
        Intrinsics.checkNotNullExpressionValue(duration, "setDuration(...)");
        return duration;
    }

    public final void W(@NotNull StepStyles.SelfieStepStyle styles) {
        Intrinsics.checkNotNullParameter(styles, "styles");
        Integer selfieCaptureFeedBoxBorderColorValue = styles.getSelfieCaptureFeedBoxBorderColorValue();
        if (selfieCaptureFeedBoxBorderColorValue != null) {
            this.binding.f28343h.setStrokeColor(selfieCaptureFeedBoxBorderColorValue.intValue());
        }
        Double selfieCaptureFeedBoxBorderWidthValue = styles.getSelfieCaptureFeedBoxBorderWidthValue();
        if (selfieCaptureFeedBoxBorderWidthValue != null) {
            this.binding.f28343h.setStrokeWidth((float) j.a(selfieCaptureFeedBoxBorderWidthValue.doubleValue()));
        }
        Integer selfieCaptureIconStrokeColor = styles.getSelfieCaptureIconStrokeColor();
        if (selfieCaptureIconStrokeColor != null) {
            int intValue = selfieCaptureIconStrokeColor.intValue();
            this.binding.f28339d.F(Color.parseColor("#022050"), intValue);
            this.binding.f28339d.F(Color.parseColor("#280087"), intValue);
        }
        Integer captureCompleteIconStrokeColor = styles.getCaptureCompleteIconStrokeColor();
        if (captureCompleteIconStrokeColor != null) {
            this.binding.f28339d.F(Color.parseColor("#3BC170"), captureCompleteIconStrokeColor.intValue());
        }
        Integer selfieCaptureIconFillColor = styles.getSelfieCaptureIconFillColor();
        if (selfieCaptureIconFillColor != null) {
            int intValue2 = selfieCaptureIconFillColor.intValue();
            this.binding.f28339d.F(Color.parseColor("#AA85FF"), intValue2);
            this.binding.f28339d.F(Color.parseColor("#8552FF"), intValue2);
        }
        Integer selfieCaptureIconBackgroundFillColor = styles.getSelfieCaptureIconBackgroundFillColor();
        if (selfieCaptureIconBackgroundFillColor != null) {
            this.binding.f28339d.F(Color.parseColor("#DBCCFF"), selfieCaptureIconBackgroundFillColor.intValue());
        }
    }

    public final void X(@NotNull Function0<Unit> onComplete) {
        Intrinsics.checkNotNullParameter(onComplete, "onComplete");
        Pi2CircleMaskView.e(this.binding.f28338c, false, onComplete, 1, null);
    }

    public final boolean a0() {
        return this.binding.f28338c.g();
    }

    public final void b0(final oq.b bVar, final Function0<Unit> function0) {
        View blindsView = bVar.b;
        Intrinsics.checkNotNullExpressionValue(blindsView, "blindsView");
        U(blindsView, 80L).withEndAction(new Runnable() { // from class: wq.k
            @Override // java.lang.Runnable
            public final void run() {
                OldSelfieOverlayView.c0(OldSelfieOverlayView.this, bVar, function0);
            }
        });
    }

    public final void e0(@NotNull b viewState, boolean showProgress, @Nullable final Function0<Unit> onAnimationEnd) {
        Intrinsics.checkNotNullParameter(viewState, "viewState");
        if (this.currentViewState == viewState) {
            return;
        }
        this.currentViewState = viewState;
        removeView(this.remoteImageView);
        Context context = getContext();
        Intrinsics.checkNotNullExpressionValue(context, "getContext(...)");
        boolean p02 = p0(context);
        oq.b bVar = this.binding;
        if (showProgress) {
            bVar.f28343h.setVisibility(0);
        } else {
            bVar.f28343h.setVisibility(8);
        }
        switch (c.f10999a[viewState.ordinal()]) {
            case 1:
                bVar.f28338c.h();
                bVar.f28343h.f(0.0f, onAnimationEnd);
                return;
            case 2:
                Pi2CircleMaskView.e(bVar.f28338c, false, null, 3, null);
                bVar.f28343h.f(0.0f, onAnimationEnd);
                return;
            case 3:
                Pi2CircleMaskView.e(bVar.f28338c, false, null, 3, null);
                Pi2ProgressArcView.g(bVar.f28343h, 0.0f, null, 2, null);
                b0(this.binding, onAnimationEnd);
                return;
            case 4:
                Pi2CircleMaskView.e(bVar.f28338c, false, null, 3, null);
                Pi2ProgressArcView.g(bVar.f28343h, 0.0f, null, 2, null);
                if (p02) {
                    i0(this.binding, this.leftPoseAnimation, onAnimationEnd);
                    return;
                } else {
                    if (onAnimationEnd != null) {
                        onAnimationEnd.invoke();
                        return;
                    }
                    return;
                }
            case 5:
                Pi2CircleMaskView.e(bVar.f28338c, false, null, 3, null);
                bVar.f28343h.f(0.0f, onAnimationEnd);
                if (p02) {
                    return;
                }
                RemoteImage remoteImage = this.leftPoseImage;
                if (remoteImage != null) {
                    this.remoteImageView = as.c.e(remoteImage, this, true);
                    return;
                }
                bVar.f28342g.setVisibility(0);
                ImageView hintImage = bVar.f28340e;
                Intrinsics.checkNotNullExpressionValue(hintImage, "hintImage");
                n0(hintImage, getDrawableLeft());
                return;
            case 6:
                Pi2CircleMaskView.e(bVar.f28338c, false, null, 3, null);
                Pi2ProgressArcView.g(bVar.f28343h, 50.0f, null, 2, null);
                b0(this.binding, onAnimationEnd);
                return;
            case 7:
                Pi2CircleMaskView.e(bVar.f28338c, false, null, 3, null);
                Pi2ProgressArcView.g(bVar.f28343h, 50.0f, null, 2, null);
                if (p02) {
                    i0(this.binding, this.rightPoseAnimation, onAnimationEnd);
                    return;
                } else {
                    if (onAnimationEnd != null) {
                        onAnimationEnd.invoke();
                        return;
                    }
                    return;
                }
            case 8:
                Pi2CircleMaskView.e(bVar.f28338c, false, null, 3, null);
                bVar.f28343h.f(50.0f, onAnimationEnd);
                if (p02) {
                    return;
                }
                RemoteImage remoteImage2 = this.rightPoseImage;
                if (remoteImage2 != null) {
                    this.remoteImageView = as.c.e(remoteImage2, this, true);
                    return;
                }
                bVar.f28342g.setVisibility(0);
                ImageView hintImage2 = bVar.f28340e;
                Intrinsics.checkNotNullExpressionValue(hintImage2, "hintImage");
                n0(hintImage2, getDrawableRight());
                return;
            case 9:
                Pi2CircleMaskView.e(bVar.f28338c, false, null, 3, null);
                Pi2ProgressArcView.g(bVar.f28343h, 100.0f, null, 2, null);
                b0(this.binding, onAnimationEnd);
                return;
            case 10:
                Pi2CircleMaskView.e(bVar.f28338c, false, null, 3, null);
                bVar.f28343h.e();
                return;
            case 11:
                Pi2CircleMaskView.e(bVar.f28338c, false, null, 3, null);
                Pi2ProgressArcView.g(bVar.f28343h, 100.0f, null, 2, null);
                b0(this.binding, new Function0() { // from class: wq.g
                    @Override // kotlin.jvm.functions.Function0
                    public final Object invoke() {
                        Unit g02;
                        g02 = OldSelfieOverlayView.g0(OldSelfieOverlayView.this, onAnimationEnd);
                        return g02;
                    }
                });
                return;
            case 12:
                Pi2CircleMaskView.e(bVar.f28338c, false, null, 3, null);
                bVar.f28343h.f(100.0f, new Function0() { // from class: wq.h
                    @Override // kotlin.jvm.functions.Function0
                    public final Object invoke() {
                        Unit h02;
                        h02 = OldSelfieOverlayView.h0(OldSelfieOverlayView.this, onAnimationEnd);
                        return h02;
                    }
                });
                return;
            case 13:
            case 14:
            case 15:
            case 16:
            case 17:
            case MlKitException.UNSUPPORTED /* 18 */:
                throw new IllegalStateException("Up or down pose is not supported in legacy Selfie flow.");
            default:
                throw new l();
        }
    }

    @Nullable
    public final RemoteImage getLeftPoseImage() {
        return this.leftPoseImage;
    }

    @Nullable
    public final RemoteImage getRightPoseImage() {
        return this.rightPoseImage;
    }

    public final void i0(final oq.b bVar, int i10, final Function0<Unit> function0) {
        this.oneShotOnCompositionLoadedListeners.add(new Function0() { // from class: wq.i
            @Override // kotlin.jvm.functions.Function0
            public final Object invoke() {
                Unit j02;
                j02 = OldSelfieOverlayView.j0(oq.b.this, this, function0);
                return j02;
            }
        });
        bVar.f28339d.setAnimation(i10);
    }

    public final void n0(final ImageView imageView, Drawable drawable) {
        if (Intrinsics.c(imageView.getDrawable(), drawable)) {
            return;
        }
        if (drawable == null) {
            S(this, imageView, 0L, 1, null).withEndAction(new Runnable() { // from class: wq.j
                @Override // java.lang.Runnable
                public final void run() {
                    OldSelfieOverlayView.o0(imageView);
                }
            });
            return;
        }
        imageView.setImageDrawable(drawable);
        imageView.setAlpha(0.0f);
        V(this, imageView, 0L, 1, null);
    }

    @Override // android.view.View
    public boolean onTouchEvent(@Nullable MotionEvent event) {
        return false;
    }

    public final boolean p0(Context context) {
        return (z.f(context, jq.a.f20839q, null, false, 6, null) == null || z.f(context, jq.a.f20841s, null, false, 6, null) == null) && this.leftPoseImage == null && this.rightPoseImage == null;
    }

    public final void setLeftPoseImage(@Nullable RemoteImage remoteImage) {
        this.leftPoseImage = remoteImage;
    }

    public final void setPreviewView(@NotNull View previewView) {
        Intrinsics.checkNotNullParameter(previewView, "previewView");
        this.previewView = previewView;
    }

    public final void setRightPoseImage(@Nullable RemoteImage remoteImage) {
        this.rightPoseImage = remoteImage;
    }

    public /* synthetic */ OldSelfieOverlayView(Context context, AttributeSet attributeSet, int i10, int i11, DefaultConstructorMarker defaultConstructorMarker) {
        this(context, (i11 & 2) != 0 ? null : attributeSet, (i11 & 4) != 0 ? 0 : i10);
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public OldSelfieOverlayView(@NotNull final Context context, @Nullable AttributeSet attributeSet, int i10) {
        super(context, attributeSet, i10);
        Intrinsics.checkNotNullParameter(context, "context");
        oq.b b10 = oq.b.b(LayoutInflater.from(context), this);
        Intrinsics.checkNotNullExpressionValue(b10, "inflate(...)");
        this.binding = b10;
        this.drawableLeft = zt.i.a(new Function0() { // from class: wq.a
            @Override // kotlin.jvm.functions.Function0
            public final Object invoke() {
                Drawable Y;
                Y = OldSelfieOverlayView.Y(context);
                return Y;
            }
        });
        this.drawableRight = zt.i.a(new Function0() { // from class: wq.e
            @Override // kotlin.jvm.functions.Function0
            public final Object invoke() {
                Drawable Z;
                Z = OldSelfieOverlayView.Z(context);
                return Z;
            }
        });
        Integer f10 = z.f(context, jq.a.f20840r, null, false, 6, null);
        this.leftPoseAnimation = f10 != null ? f10.intValue() : mq.z.f24346e;
        Integer f11 = z.f(context, jq.a.f20840r, null, false, 6, null);
        this.rightPoseAnimation = f11 != null ? f11.intValue() : mq.z.f24348g;
        this.oneShotOnCompositionLoadedListeners = new ArrayList();
        this.oneShotOnAnimationCompleteListeners = new ArrayList();
        ThemeableLottieAnimationView themeableLottieAnimationView = b10.f28339d;
        themeableLottieAnimationView.j(new n0() { // from class: wq.f
            @Override // g7.n0
            public final void a(g7.i iVar) {
                OldSelfieOverlayView.I(OldSelfieOverlayView.this, iVar);
            }
        });
        themeableLottieAnimationView.i(new a());
        int parseColor = Color.parseColor("#022050");
        Context context2 = b10.getRoot().getContext();
        Intrinsics.checkNotNullExpressionValue(context2, "getContext(...)");
        themeableLottieAnimationView.F(parseColor, z.d(context2, jc.b.f20296m, null, false, 6, null));
        int parseColor2 = Color.parseColor("#AA85FF");
        Context context3 = b10.getRoot().getContext();
        Intrinsics.checkNotNullExpressionValue(context3, "getContext(...)");
        themeableLottieAnimationView.F(parseColor2, z.d(context3, jc.b.f20297n, null, false, 6, null));
        int parseColor3 = Color.parseColor("#280087");
        Context context4 = b10.getRoot().getContext();
        Intrinsics.checkNotNullExpressionValue(context4, "getContext(...)");
        themeableLottieAnimationView.F(parseColor3, z.d(context4, jc.b.f20296m, null, false, 6, null));
        int parseColor4 = Color.parseColor("#8552FF");
        Context context5 = b10.getRoot().getContext();
        Intrinsics.checkNotNullExpressionValue(context5, "getContext(...)");
        themeableLottieAnimationView.F(parseColor4, z.d(context5, jc.b.f20297n, null, false, 6, null));
        Context context6 = b10.getRoot().getContext();
        Intrinsics.checkNotNullExpressionValue(context6, "getContext(...)");
        int d10 = z.d(context6, jc.b.f20297n, null, false, 6, null);
        Context context7 = b10.getRoot().getContext();
        Intrinsics.checkNotNullExpressionValue(context7, "getContext(...)");
        themeableLottieAnimationView.F(Color.parseColor("#DBCCFF"), androidx.core.graphics.c.c(d10, z.d(context7, jc.b.f20298o, null, false, 6, null), 0.66f));
    }
}
