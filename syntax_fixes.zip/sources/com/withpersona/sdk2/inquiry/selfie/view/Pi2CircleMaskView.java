package com.withpersona.sdk2.inquiry.selfie.view;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewPropertyAnimator;
import com.github.luben.zstd.BuildConfig;

import k6.b;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import mq.a0;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import xe.a;

@Metadata(d1 = {"\u0000V\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0004\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0007\n\u0000\n\u0002\u0010\t\n\u0002\b\t\n\u0002\u0018\u0002\n\u0002\b\u0006\u0018\u0000 .2\u00020\u0001:\u0001\"B'\b\u0007\u0012\u0006\u0010\u0003\u001a\u00020\u0002\u0012\n\b\u0002\u0010\u0005\u001a\u0004\u0018\u00010\u0004\u0012\b\b\u0002\u0010\u0007\u001a\u00020\u0006¢\u0006\u0004\b\b\u0010\tJ\u0017\u0010\r\u001a\u00020\f2\u0006\u0010\u000b\u001a\u00020\nH\u0014¢\u0006\u0004\b\r\u0010\u000eJ\r\u0010\u000f\u001a\u00020\f¢\u0006\u0004\b\u000f\u0010\u0010J)\u0010\u0015\u001a\u00020\f2\b\b\u0002\u0010\u0012\u001a\u00020\u00112\u0010\b\u0002\u0010\u0014\u001a\n\u0012\u0004\u0012\u00020\f\u0018\u00010\u0013¢\u0006\u0004\b\u0015\u0010\u0016J\r\u0010\u0017\u001a\u00020\u0011¢\u0006\u0004\b\u0017\u0010\u0018J\u000f\u0010\u0019\u001a\u00020\fH\u0014¢\u0006\u0004\b\u0019\u0010\u0010J\u000f\u0010\u001b\u001a\u00020\u001aH\u0002¢\u0006\u0004\b\u001b\u0010\u001cJ\u0017\u0010 \u001a\u00020\u001f2\u0006\u0010\u001e\u001a\u00020\u001dH\u0002¢\u0006\u0004\b \u0010!R\u0014\u0010$\u001a\u00020\u001d8\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b\"\u0010#R\u0014\u0010&\u001a\u00020\u00068\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b \u0010%R\u0018\u0010(\u001a\u0004\u0018\u00010\u001a8\u0002@\u0002X\u0082\u000e¢\u0006\u0006\n\u0004\b\u001b\u0010'R\u0016\u0010+\u001a\u00020)8\u0002@\u0002X\u0082\u000e¢\u0006\u0006\n\u0004\b\u0015\u0010*R\u0016\u0010-\u001a\u00020)8\u0002@\u0002X\u0082\u000e¢\u0006\u0006\n\u0004\b,\u0010*¨\u0006/"}, d2 = {"Lcom/withpersona/sdk2/inquiry/selfie/view/Pi2CircleMaskView;", "Landroid/view/View;", "Landroid/content/Context;", "context", "Landroid/util/AttributeSet;", "attrs", BuildConfig.FLAVOR, "defStyleAttr", "<init>", "(Landroid/content/Context;Landroid/util/AttributeSet;I)V", "Landroid/graphics/Canvas;", "canvas", BuildConfig.FLAVOR, "onDraw", "(Landroid/graphics/Canvas;)V", "h", "()V", BuildConfig.FLAVOR, "animated", "Lkotlin/Function0;", "onComplete", "d", "(ZLkotlin/jvm/functions/Function0;)V", "g", "()Z", "onDetachedFromWindow", "Landroid/graphics/Bitmap;", "c", "()Landroid/graphics/Bitmap;", BuildConfig.FLAVOR, "targetScaleX", BuildConfig.FLAVOR, b.f21144e, "(F)J", a.f36648e, "F", "size", "I", "maskColor", "Landroid/graphics/Bitmap;", "mask", "Landroid/graphics/Paint;", "Landroid/graphics/Paint;", "paint", "e", "clearPaint", "f", "selfie_release"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* loaded from: classes3.dex */
public final class Pi2CircleMaskView extends View {

    /* renamed from: a, reason: collision with root package name and from kotlin metadata */
    public final float size;

    /* renamed from: b, reason: from kotlin metadata */
    public final int maskColor;

    /* renamed from: c, reason: collision with root package name and from kotlin metadata */
    @Nullable
    public Bitmap mask;

    /* renamed from: d, reason: collision with root package name and from kotlin metadata */
    @NotNull
    public Paint paint;

    /* renamed from: e, reason: collision with root package name and from kotlin metadata */
    @NotNull
    public Paint clearPaint;

    /* JADX WARN: 'this' call moved to the top of the method (can break code semantics) */
    public Pi2CircleMaskView(@NotNull Context context, @Nullable AttributeSet attributeSet) {
        this(context, attributeSet, 0, 4, null);
        Intrinsics.checkNotNullParameter(context, "context");
    }

    /* JADX WARN: Multi-variable type inference failed */
    public static /* synthetic */ void e(Pi2CircleMaskView pi2CircleMaskView, boolean z10, Function0 function0, int i10, Object obj) {
        if ((i10 & 1) != 0) {
            z10 = true;
        }
        if ((i10 & 2) != 0) {
            function0 = null;
        }
        pi2CircleMaskView.d(z10, function0);
    }

    public static final void f(Function0 function0) {
        if (function0 != null) {
            function0.invoke();
        }
    }

    public final long b(float targetScaleX) {
        return su.b.f((Math.abs(getScaleX() - targetScaleX) / 4.0f) * 500);
    }

    public final Bitmap c() {
        Bitmap bitmap = this.mask;
        if (bitmap != null) {
            if (bitmap.getWidth() != getWidth() || bitmap.getHeight() != getHeight()) {
                bitmap = null;
            }
            if (bitmap != null) {
                return bitmap;
            }
        }
        Bitmap createBitmap = Bitmap.createBitmap(getWidth(), getHeight(), Bitmap.Config.ARGB_8888);
        Intrinsics.checkNotNullExpressionValue(createBitmap, "createBitmap(...)");
        Canvas canvas = new Canvas(createBitmap);
        canvas.drawColor(this.maskColor);
        canvas.drawCircle(canvas.getWidth() / 2.0f, canvas.getHeight() / 2.0f, this.size * Math.min(canvas.getWidth(), canvas.getHeight()), this.clearPaint);
        this.mask = createBitmap;
        return createBitmap;
    }

    public final void d(boolean animated, @Nullable final Function0<Unit> onComplete) {
        if (animated) {
            ViewPropertyAnimator animate = animate();
            animate.setDuration(b(1.0f));
            animate.scaleX(1.0f);
            animate.scaleY(1.0f);
            animate.withEndAction(new Runnable() { // from class: wq.n
                @Override // java.lang.Runnable
                public final void run() {
                    Pi2CircleMaskView.f(Function0.this);
                }
            });
            animate.start();
            return;
        }
        getAnimation().cancel();
        setScaleX(1.0f);
        setScaleY(1.0f);
        if (onComplete != null) {
            onComplete.invoke();
        }
    }

    public final boolean g() {
        return (getScaleX() == 5.0f && getScaleY() == 5.0f) ? false : true;
    }

    public final void h() {
        if (getScaleX() == 5.0f && getScaleY() == 5.0f) {
            return;
        }
        ViewPropertyAnimator animate = animate();
        animate.setDuration(b(5.0f));
        animate.scaleX(5.0f);
        animate.scaleY(5.0f);
        animate.start();
    }

    @Override // android.view.View
    public void onDetachedFromWindow() {
        Bitmap bitmap;
        Bitmap bitmap2 = this.mask;
        if (bitmap2 != null && !bitmap2.isRecycled() && (bitmap = this.mask) != null) {
            bitmap.recycle();
        }
        this.mask = null;
        super.onDetachedFromWindow();
    }

    @Override // android.view.View
    public void onDraw(@NotNull Canvas canvas) {
        Intrinsics.checkNotNullParameter(canvas, "canvas");
        canvas.drawBitmap(c(), 0.0f, 0.0f, this.paint);
    }

    public /* synthetic */ Pi2CircleMaskView(Context context, AttributeSet attributeSet, int i10, int i11, DefaultConstructorMarker defaultConstructorMarker) {
        this(context, (i11 & 2) != 0 ? null : attributeSet, (i11 & 4) != 0 ? 0 : i10);
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public Pi2CircleMaskView(@NotNull Context context, @Nullable AttributeSet attributeSet, int i10) {
        super(context, attributeSet, i10);
        Intrinsics.checkNotNullParameter(context, "context");
        this.paint = new Paint(7);
        Paint paint = new Paint(1);
        paint.setColor(0);
        paint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.CLEAR));
        this.clearPaint = paint;
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, a0.f23485a, i10, 0);
        Intrinsics.checkNotNullExpressionValue(obtainStyledAttributes, "obtainStyledAttributes(...)");
        try {
            this.size = obtainStyledAttributes.getFloat(a0.b, 0.4f);
            this.maskColor = obtainStyledAttributes.getColor(a0.f23486c, -16777216);
            obtainStyledAttributes.recycle();
            setWillNotDraw(false);
        } catch (Throwable th2) {
            obtainStyledAttributes.recycle();
            throw th2;
        }
    }


    // --- восстановлено из DEX (com/withpersona/sdk2/inquiry/selfie/view/Pi2CircleMaskView$a) ---
    public static class a {
        public a() { }
        public a(kotlin.jvm.internal.DefaultConstructorMarker p0) { }
    }
}
