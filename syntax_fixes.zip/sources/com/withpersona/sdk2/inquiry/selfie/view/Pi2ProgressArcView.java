package com.withpersona.sdk2.inquiry.selfie.view;

import android.animation.Animator;
import android.animation.ValueAnimator;
import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.view.View;
import android.view.animation.LinearInterpolator;
import com.github.luben.zstd.BuildConfig;

import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import mq.a0;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import xe.a;

@Metadata(d1 = {"\u0000L\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0002\b\u0004\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0010\u0007\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\b\n\u0002\u0018\u0002\n\u0002\b\b\u0018\u0000 /2\u00020\u0001:\u0001 B'\b\u0007\u0012\u0006\u0010\u0003\u001a\u00020\u0002\u0012\n\b\u0002\u0010\u0005\u001a\u0004\u0018\u00010\u0004\u0012\b\b\u0002\u0010\u0007\u001a\u00020\u0006¢\u0006\u0004\b\b\u0010\tJ\u0015\u0010\f\u001a\u00020\u000b2\u0006\u0010\n\u001a\u00020\u0006¢\u0006\u0004\b\f\u0010\rJ\u0015\u0010\u0010\u001a\u00020\u000b2\u0006\u0010\u000f\u001a\u00020\u000e¢\u0006\u0004\b\u0010\u0010\u0011J'\u0010\u0015\u001a\u00020\u000b2\u0006\u0010\u0012\u001a\u00020\u000e2\u0010\b\u0002\u0010\u0014\u001a\n\u0012\u0004\u0012\u00020\u000b\u0018\u00010\u0013¢\u0006\u0004\b\u0015\u0010\u0016J\r\u0010\u0017\u001a\u00020\u000b¢\u0006\u0004\b\u0017\u0010\u0018J\u0017\u0010\u001b\u001a\u00020\u000b2\u0006\u0010\u001a\u001a\u00020\u0019H\u0014¢\u0006\u0004\b\u001b\u0010\u001cJ'\u0010\u001d\u001a\u00020\u000b2\u0006\u0010\u0012\u001a\u00020\u000e2\u000e\u0010\u0014\u001a\n\u0012\u0004\u0012\u00020\u000b\u0018\u00010\u0013H\u0002¢\u0006\u0004\b\u001d\u0010\u0016J\u000f\u0010\u001e\u001a\u00020\u000bH\u0002¢\u0006\u0004\b\u001e\u0010\u0018R\u0014\u0010\"\u001a\u00020\u001f8\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b \u0010!R\u0014\u0010%\u001a\u00020\u000e8\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b#\u0010$R\u0014\u0010'\u001a\u00020\u000e8\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b&\u0010$R\u0016\u0010\u0012\u001a\u00020\u000e8\u0002@\u0002X\u0082\u000e¢\u0006\u0006\n\u0004\b\u001e\u0010$R\u0018\u0010*\u001a\u0004\u0018\u00010(8\u0002@\u0002X\u0082\u000e¢\u0006\u0006\n\u0004\b\u0017\u0010)R\u0018\u0010+\u001a\u0004\u0018\u00010(8\u0002@\u0002X\u0082\u000e¢\u0006\u0006\n\u0004\b\u0015\u0010)R\u0018\u0010-\u001a\u0004\u0018\u00010(8\u0002@\u0002X\u0082\u000e¢\u0006\u0006\n\u0004\b,\u0010)R\u0016\u0010.\u001a\u00020\u000e8\u0002@\u0002X\u0082\u000e¢\u0006\u0006\n\u0004\b\u001d\u0010$¨\u00060"}, d2 = {"Lcom/withpersona/sdk2/inquiry/selfie/view/Pi2ProgressArcView;", "Landroid/view/View;", "Landroid/content/Context;", "context", "Landroid/util/AttributeSet;", "attrs", BuildConfig.FLAVOR, "defStyleAttr", "<init>", "(Landroid/content/Context;Landroid/util/AttributeSet;I)V", "newColor", BuildConfig.FLAVOR, "setStrokeColor", "(I)V", BuildConfig.FLAVOR, "newWidth", "setStrokeWidth", "(F)V", "progress", "Lkotlin/Function0;", "onAnimationEnd", "f", "(FLkotlin/jvm/functions/Function0;)V", "e", "()V", "Landroid/graphics/Canvas;", "canvas", "onDraw", "(Landroid/graphics/Canvas;)V", "h", "d", "Landroid/graphics/Paint;", a.f36648e, "Landroid/graphics/Paint;", "paint", k6.b.f21144e, "F", "size", "c", "startAngle", "Landroid/animation/ValueAnimator;", "Landroid/animation/ValueAnimator;", "animator", "indeterminateAnimator", "g", "rotateToZeroAnimator", "_rotation", "i", "selfie_release"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* loaded from: classes3.dex */
public final class Pi2ProgressArcView extends View {

    /* renamed from: a, reason: collision with root package name and from kotlin metadata */
    @NotNull
    public final Paint paint;

    /* renamed from: b, reason: from kotlin metadata */
    public final float size;

    /* renamed from: c, reason: collision with root package name and from kotlin metadata */
    public final float startAngle;

    /* renamed from: d, reason: collision with root package name and from kotlin metadata */
    public float progress;

    /* renamed from: e, reason: collision with root package name and from kotlin metadata */
    @Nullable
    public ValueAnimator animator;

    /* renamed from: f, reason: collision with root package name and from kotlin metadata */
    @Nullable
    public ValueAnimator indeterminateAnimator;

    /* renamed from: g, reason: collision with root package name and from kotlin metadata */
    @Nullable
    public ValueAnimator rotateToZeroAnimator;

    /* renamed from: h, reason: collision with root package name and from kotlin metadata */
    public float _rotation;

    @Metadata(d1 = {"\u0000\u001f\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0010\u0007\n\u0002\b\b*\u0001\u0000\b\n\u0018\u00002\u00020\u0001J\u0017\u0010\u0005\u001a\u00020\u00042\u0006\u0010\u0003\u001a\u00020\u0002H\u0016¢\u0006\u0004\b\u0005\u0010\u0006R\"\u0010\u000e\u001a\u00020\u00078\u0006@\u0006X\u0086\u000e¢\u0006\u0012\n\u0004\b\b\u0010\t\u001a\u0004\b\n\u0010\u000b\"\u0004\b\f\u0010\r¨\u0006\u000f"}, d2 = {"com/withpersona/sdk2/inquiry/selfie/view/Pi2ProgressArcView$b", "Landroid/animation/ValueAnimator$AnimatorUpdateListener;", "Landroid/animation/ValueAnimator;", "animator", BuildConfig.FLAVOR, "onAnimationUpdate", "(Landroid/animation/ValueAnimator;)V", BuildConfig.FLAVOR, a.f36648e, "F", "getLastProgress", "()F", "setLastProgress", "(F)V", "lastProgress", "selfie_release"}, k = 1, mv = {2, 2, 0}, xi = 48)
    public static final class b implements ValueAnimator.AnimatorUpdateListener {

        /* renamed from: a, reason: collision with root package name and from kotlin metadata */
        public float lastProgress;
        public final /* synthetic */ ValueAnimator b;

        /* renamed from: c, reason: collision with root package name */
        public final /* synthetic */ Pi2ProgressArcView f11014c;

        public b(ValueAnimator valueAnimator, Pi2ProgressArcView pi2ProgressArcView) {
            this.b = valueAnimator;
            this.f11014c = pi2ProgressArcView;
        }

        @Override // android.animation.ValueAnimator.AnimatorUpdateListener
        public void onAnimationUpdate(ValueAnimator animator) {
            Intrinsics.checkNotNullParameter(animator, "animator");
            Object animatedValue = this.b.getAnimatedValue();
            Intrinsics.d(animatedValue, "null cannot be cast to non-null type kotlin.Float");
            float floatValue = ((Float) animatedValue).floatValue();
            float abs = Math.abs(floatValue - this.lastProgress);
            float f10 = this.f11014c._rotation;
            Pi2ProgressArcView pi2ProgressArcView = this.f11014c;
            pi2ProgressArcView._rotation = (pi2ProgressArcView._rotation + abs) % 360;
            if (f10 > this.f11014c._rotation) {
                this.f11014c._rotation = 0.0f;
                animator.cancel();
            }
            this.lastProgress = floatValue;
            this.f11014c.invalidate();
        }
    }

    @Metadata(k = 3, mv = {2, 2, 0}, xi = 48)
    public static final class c implements Runnable {

        /* renamed from: a, reason: collision with root package name */
        public final /* synthetic */ Function0 f11015a;

        public c(Function0 function) {
            Intrinsics.checkNotNullParameter(function, "function");
            this.f11015a = function;
        }

        @Override // java.lang.Runnable
        public final /* synthetic */ void run() {
            this.f11015a.invoke();
        }
    }

    @Metadata(d1 = {"\u0000\u001f\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0010\u0007\n\u0002\b\b*\u0001\u0000\b\n\u0018\u00002\u00020\u0001J\u0017\u0010\u0005\u001a\u00020\u00042\u0006\u0010\u0003\u001a\u00020\u0002H\u0016¢\u0006\u0004\b\u0005\u0010\u0006R\"\u0010\u000e\u001a\u00020\u00078\u0006@\u0006X\u0086\u000e¢\u0006\u0012\n\u0004\b\b\u0010\t\u001a\u0004\b\n\u0010\u000b\"\u0004\b\f\u0010\r¨\u0006\u000f"}, d2 = {"com/withpersona/sdk2/inquiry/selfie/view/Pi2ProgressArcView$d", "Landroid/animation/ValueAnimator$AnimatorUpdateListener;", "Landroid/animation/ValueAnimator;", "animator", BuildConfig.FLAVOR, "onAnimationUpdate", "(Landroid/animation/ValueAnimator;)V", BuildConfig.FLAVOR, a.f36648e, "F", "getLastProgress", "()F", "setLastProgress", "(F)V", "lastProgress", "selfie_release"}, k = 1, mv = {2, 2, 0}, xi = 48)
    public static final class d implements ValueAnimator.AnimatorUpdateListener {

        /* renamed from: a, reason: collision with root package name and from kotlin metadata */
        public float lastProgress;
        public final /* synthetic */ ValueAnimator b;

        /* renamed from: c, reason: collision with root package name */
        public final /* synthetic */ Pi2ProgressArcView f11017c;

        public d(ValueAnimator valueAnimator, Pi2ProgressArcView pi2ProgressArcView) {
            this.b = valueAnimator;
            this.f11017c = pi2ProgressArcView;
        }

        @Override // android.animation.ValueAnimator.AnimatorUpdateListener
        public void onAnimationUpdate(ValueAnimator animator) {
            Intrinsics.checkNotNullParameter(animator, "animator");
            Object animatedValue = this.b.getAnimatedValue();
            Intrinsics.d(animatedValue, "null cannot be cast to non-null type kotlin.Float");
            float floatValue = ((Float) animatedValue).floatValue();
            float abs = Math.abs(floatValue - this.lastProgress);
            Pi2ProgressArcView pi2ProgressArcView = this.f11017c;
            pi2ProgressArcView._rotation = (pi2ProgressArcView._rotation + abs) % 360;
            this.lastProgress = floatValue;
            this.f11017c.invalidate();
        }
    }

    @Metadata(d1 = {"\u0000\u0017\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0007*\u0001\u0000\b\n\u0018\u00002\u00020\u0001J\u0017\u0010\u0005\u001a\u00020\u00042\u0006\u0010\u0003\u001a\u00020\u0002H\u0016¢\u0006\u0004\b\u0005\u0010\u0006J\u0017\u0010\u0007\u001a\u00020\u00042\u0006\u0010\u0003\u001a\u00020\u0002H\u0016¢\u0006\u0004\b\u0007\u0010\u0006J\u0017\u0010\b\u001a\u00020\u00042\u0006\u0010\u0003\u001a\u00020\u0002H\u0016¢\u0006\u0004\b\b\u0010\u0006J\u0017\u0010\t\u001a\u00020\u00042\u0006\u0010\u0003\u001a\u00020\u0002H\u0016¢\u0006\u0004\b\t\u0010\u0006¨\u0006\u000b¸\u0006\n"}, d2 = {"androidx/core/animation/AnimatorKt$addListener$listener$1", "Landroid/animation/Animator$AnimatorListener;", "Landroid/animation/Animator;", "animator", BuildConfig.FLAVOR, "onAnimationRepeat", "(Landroid/animation/Animator;)V", "onAnimationEnd", "onAnimationCancel", "onAnimationStart", "androidx/core/animation/AnimatorKt$doOnEnd$$inlined$addListener$1", "core-ktx_release"}, k = 1, mv = {2, 2, 0})
    public static final class e implements Animator.AnimatorListener {

        /* renamed from: a, reason: collision with root package name */
        public final /* synthetic */ Function0 f11018a;
        public final /* synthetic */ Pi2ProgressArcView b;

        public e(Function0 function0, Pi2ProgressArcView pi2ProgressArcView) {
            this.f11018a = function0;
            this.b = pi2ProgressArcView;
        }

        @Override // android.animation.Animator.AnimatorListener
        public void onAnimationCancel(@NotNull Animator animator) {
            Intrinsics.e(animator, "animator");
        }

        @Override // android.animation.Animator.AnimatorListener
        public void onAnimationEnd(@NotNull Animator animator) {
            Intrinsics.e(animator, "animator");
            Function0 function0 = this.f11018a;
            if (function0 != null) {
                this.b.postDelayed(new c(function0), 100L);
            }
        }

        @Override // android.animation.Animator.AnimatorListener
        public void onAnimationRepeat(@NotNull Animator animator) {
            Intrinsics.e(animator, "animator");
        }

        @Override // android.animation.Animator.AnimatorListener
        public void onAnimationStart(@NotNull Animator animator) {
            Intrinsics.e(animator, "animator");
        }
    }

    /* JADX WARN: 'this' call moved to the top of the method (can break code semantics) */
    public Pi2ProgressArcView(@NotNull Context context, @Nullable AttributeSet attributeSet) {
        this(context, attributeSet, 0, 4, null);
        Intrinsics.checkNotNullParameter(context, "context");
    }

    /* JADX WARN: Multi-variable type inference failed */
    public static /* synthetic */ void g(Pi2ProgressArcView pi2ProgressArcView, float f10, Function0 function0, int i10, Object obj) {
        if ((i10 & 2) != 0) {
            function0 = null;
        }
        pi2ProgressArcView.f(f10, function0);
    }

    public static final void i(Pi2ProgressArcView pi2ProgressArcView, ValueAnimator valueAnimator, ValueAnimator it) {
        Intrinsics.checkNotNullParameter(it, "it");
        Object animatedValue = valueAnimator.getAnimatedValue();
        Intrinsics.d(animatedValue, "null cannot be cast to non-null type kotlin.Float");
        pi2ProgressArcView.progress = ((Float) animatedValue).floatValue();
        pi2ProgressArcView.invalidate();
    }

    public final void d() {
        if (this._rotation == 0.0f) {
            return;
        }
        ValueAnimator ofFloat = ValueAnimator.ofFloat(0.0f, 100.0f);
        ofFloat.setDuration(300L);
        ofFloat.addUpdateListener(new b(ofFloat, this));
        ofFloat.setInterpolator(new LinearInterpolator());
        ofFloat.setRepeatCount(-1);
        ofFloat.setRepeatMode(2);
        ofFloat.start();
        this.rotateToZeroAnimator = ofFloat;
    }

    public final void e() {
        ValueAnimator valueAnimator = this.rotateToZeroAnimator;
        if (valueAnimator != null) {
            valueAnimator.cancel();
        }
        ValueAnimator valueAnimator2 = this.indeterminateAnimator;
        if (valueAnimator2 != null) {
            valueAnimator2.cancel();
        }
        h(25.0f, null);
        ValueAnimator ofFloat = ValueAnimator.ofFloat(0.0f, 100.0f);
        ofFloat.setDuration(300L);
        ofFloat.addUpdateListener(new d(ofFloat, this));
        ofFloat.setInterpolator(new LinearInterpolator());
        ofFloat.setRepeatCount(-1);
        ofFloat.setRepeatMode(2);
        ofFloat.start();
        this.indeterminateAnimator = ofFloat;
    }

    public final void f(float progress, @Nullable Function0<Unit> onAnimationEnd) {
        ValueAnimator valueAnimator = this.indeterminateAnimator;
        if (valueAnimator != null) {
            valueAnimator.cancel();
        }
        d();
        h(progress, onAnimationEnd);
    }

    public final void h(float progress, Function0<Unit> onAnimationEnd) {
        if (this.progress == progress) {
            if (onAnimationEnd != null) {
                onAnimationEnd.invoke();
                return;
            }
            return;
        }
        ValueAnimator valueAnimator = this.animator;
        if (valueAnimator != null) {
            valueAnimator.cancel();
        }
        float f10 = this.progress;
        final ValueAnimator ofFloat = ValueAnimator.ofFloat(f10, progress);
        ofFloat.setDuration((long) (1000 * (Math.abs(progress - f10) / 100.0f)));
        ofFloat.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() { // from class: wq.o
            @Override // android.animation.ValueAnimator.AnimatorUpdateListener
            public final void onAnimationUpdate(ValueAnimator valueAnimator2) {
                Pi2ProgressArcView.i(Pi2ProgressArcView.this, ofFloat, valueAnimator2);
            }
        });
        Intrinsics.checkNotNull(ofFloat);
        ofFloat.addListener(new e(onAnimationEnd, this));
        ofFloat.start();
        this.animator = ofFloat;
    }

    @Override // android.view.View
    public void onDraw(@NotNull Canvas canvas) {
        Intrinsics.checkNotNullParameter(canvas, "canvas");
        int width = getWidth() / 2;
        int height = getHeight() / 2;
        float min = (this.size * Math.min(getWidth(), getHeight())) - (this.paint.getStrokeWidth() / 2);
        float f10 = width;
        float f11 = height;
        canvas.drawArc(f10 - min, f11 - min, f10 + min, f11 + min, this.startAngle + this._rotation, (this.progress * 360) / 100.0f, false, this.paint);
    }

    public final void setStrokeColor(int newColor) {
        this.paint.setColor(newColor);
    }

    public final void setStrokeWidth(float newWidth) {
        this.paint.setStrokeWidth(newWidth);
    }

    public /* synthetic */ Pi2ProgressArcView(Context context, AttributeSet attributeSet, int i10, int i11, DefaultConstructorMarker defaultConstructorMarker) {
        this(context, (i11 & 2) != 0 ? null : attributeSet, (i11 & 4) != 0 ? 0 : i10);
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public Pi2ProgressArcView(@NotNull Context context, @Nullable AttributeSet attributeSet, int i10) {
        super(context, attributeSet, i10);
        Intrinsics.checkNotNullParameter(context, "context");
        Paint paint = new Paint(1);
        this.paint = paint;
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, a0.f23487d, i10, 0);
        Intrinsics.checkNotNullExpressionValue(obtainStyledAttributes, "obtainStyledAttributes(...)");
        try {
            this.size = obtainStyledAttributes.getFloat(a0.f23488e, 0.4f);
            this.startAngle = obtainStyledAttributes.getFloat(a0.f23490g, 270.0f);
            this.progress = obtainStyledAttributes.getFloat(a0.f23489f, 0.0f);
            paint.setColor(obtainStyledAttributes.getColor(a0.f23491h, -1));
            paint.setStrokeWidth(obtainStyledAttributes.getDimensionPixelSize(a0.f23492i, 4));
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeCap(Paint.Cap.BUTT);
            obtainStyledAttributes.recycle();
            setWillNotDraw(false);
        } catch (Throwable th2) {
            obtainStyledAttributes.recycle();
            throw th2;
        }
    }


    // --- восстановлено из DEX (com/withpersona/sdk2/inquiry/selfie/view/Pi2ProgressArcView$a) ---
    public static class a {
        public a() { }
        public a(kotlin.jvm.internal.DefaultConstructorMarker p0) { }
    }
}
