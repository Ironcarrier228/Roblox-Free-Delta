package com.withpersona.sdk2.inquiry.selfie.view;

import android.animation.Animator;
import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.util.AttributeSet;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.view.animation.LinearInterpolator;
import android.widget.FrameLayout;
import com.github.luben.zstd.BuildConfig;
import com.google.mlkit.vision.barcode.common.Barcode;

import k6.b;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.y;
import kotlin.ranges.d;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import pm.t;
import xe.a;
import zt.l;

@Metadata(d1 = {"\u0000\u0086\u0001\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\b\n\u0002\b\u0004\n\u0002\u0010\u0002\n\u0002\b\u0004\n\u0002\u0010\u000b\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0007\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u000b\n\u0002\u0018\u0002\n\u0002\bS\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\n\n\u0002\u0018\u0002\n\u0002\b\n\u0018\u0000 ¬\u00012\u00020\u0001:\u0006MUPWSJB\u001b\b\u0016\u0012\u0006\u0010\u0003\u001a\u00020\u0002\u0012\b\u0010\u0005\u001a\u0004\u0018\u00010\u0004¢\u0006\u0004\b\u0006\u0010\u0007J/\u0010\u000e\u001a\u00020\r2\u0006\u0010\t\u001a\u00020\b2\u0006\u0010\n\u001a\u00020\b2\u0006\u0010\u000b\u001a\u00020\b2\u0006\u0010\f\u001a\u00020\bH\u0014¢\u0006\u0004\b\u000e\u0010\u000fJ\u000f\u0010\u0010\u001a\u00020\rH\u0014¢\u0006\u0004\b\u0010\u0010\u0011J\u0015\u0010\u0014\u001a\u00020\r2\u0006\u0010\u0013\u001a\u00020\u0012¢\u0006\u0004\b\u0014\u0010\u0015J\u001f\u0010\u0019\u001a\u00020\r2\u0006\u0010\u0017\u001a\u00020\u00162\b\b\u0002\u0010\u0018\u001a\u00020\u0012¢\u0006\u0004\b\u0019\u0010\u001aJ\u0017\u0010\u001d\u001a\u00020\r2\b\u0010\u001c\u001a\u0004\u0018\u00010\u001b¢\u0006\u0004\b\u001d\u0010\u001eJ\u0015\u0010!\u001a\u00020\r2\u0006\u0010 \u001a\u00020\u001f¢\u0006\u0004\b!\u0010\"J\u0017\u0010%\u001a\u00020\r2\u0006\u0010$\u001a\u00020#H\u0014¢\u0006\u0004\b%\u0010&J\u001f\u0010(\u001a\u00020\r2\u0006\u0010'\u001a\u00020\u00162\u0006\u0010\u0017\u001a\u00020\u0016H\u0002¢\u0006\u0004\b(\u0010)J'\u0010/\u001a\n .*\u0004\u0018\u00010-0-2\u0006\u0010+\u001a\u00020*2\u0006\u0010,\u001a\u00020*H\u0002¢\u0006\u0004\b/\u00100J\u000f\u00101\u001a\u00020\rH\u0002¢\u0006\u0004\b1\u0010\u0011JS\u0010;\u001a\u00020\r*\u0002022\u0006\u00103\u001a\u00020\u001f2\u0006\u00104\u001a\u00020\u001f2\u0006\u00105\u001a\u00020\u001f2\u0006\u00106\u001a\u00020\u001f2\u0006\u00107\u001a\u00020\u001f2\u0006\u00108\u001a\u00020\u001f2\u0006\u00109\u001a\u00020\b2\u0006\u0010:\u001a\u00020\u001fH\u0002¢\u0006\u0004\b;\u0010<J\u000f\u0010=\u001a\u00020\rH\u0002¢\u0006\u0004\b=\u0010\u0011J\u000f\u0010?\u001a\u00020>H\u0002¢\u0006\u0004\b?\u0010@J\u000f\u0010A\u001a\u00020>H\u0002¢\u0006\u0004\bA\u0010@J\u000f\u0010\t\u001a\u00020>H\u0002¢\u0006\u0004\b\t\u0010@J+\u0010E\u001a\u00020\r*\u00020*2\u0006\u0010B\u001a\u00020*2\u0006\u0010C\u001a\u00020*2\u0006\u0010D\u001a\u00020\u001fH\u0002¢\u0006\u0004\bE\u0010FJ\u001b\u0010G\u001a\u00020**\u00020*2\u0006\u0010 \u001a\u00020\u001fH\u0002¢\u0006\u0004\bG\u0010HJ\u000f\u0010I\u001a\u00020\rH\u0002¢\u0006\u0004\bI\u0010\u0011R\u0016\u0010L\u001a\u00020\u00168\u0002@\u0002X\u0082\u000e¢\u0006\u0006\n\u0004\bJ\u0010KR\u0016\u0010O\u001a\u00020\u001f8\u0002@\u0002X\u0082\u000e¢\u0006\u0006\n\u0004\bM\u0010NR\u0014\u0010R\u001a\u00020\b8\u0002X\u0082D¢\u0006\u0006\n\u0004\bP\u0010QR\u0014\u0010T\u001a\u00020\b8\u0002X\u0082D¢\u0006\u0006\n\u0004\bS\u0010QR\u0014\u0010V\u001a\u00020\b8\u0002X\u0082D¢\u0006\u0006\n\u0004\bU\u0010QR\u0014\u0010X\u001a\u00020\b8\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\bW\u0010QR\u0014\u0010Z\u001a\u00020\b8\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\bY\u0010QR\u0014\u0010[\u001a\u00020\u001f8\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b\n\u0010NR\u0014\u0010]\u001a\u00020\u001f8\u0002X\u0082D¢\u0006\u0006\n\u0004\b\\\u0010NR\u0014\u0010_\u001a\u00020\u001f8\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b^\u0010NR\u0014\u0010a\u001a\u00020\u001f8\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b`\u0010NR\u0014\u0010c\u001a\u00020\u001f8\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\bb\u0010NR\u0014\u0010e\u001a\u0002028\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b;\u0010dR\u0014\u0010f\u001a\u0002028\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b=\u0010dR\u0014\u0010g\u001a\u0002028\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\bG\u0010dR\u0014\u0010i\u001a\u0002028\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\bh\u0010dR\u0014\u0010j\u001a\u0002028\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\bE\u0010dR\u0014\u0010l\u001a\u0002028\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\bk\u0010dR\u0014\u0010m\u001a\u0002028\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\bA\u0010dR\u0014\u0010n\u001a\u0002028\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b?\u0010dR\u0014\u0010o\u001a\u0002028\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b/\u0010dR\u0014\u0010q\u001a\u0002028\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\bp\u0010dR\u0014\u0010r\u001a\u0002028\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b\t\u0010dR\u0014\u0010s\u001a\u0002028\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b(\u0010dR\u0014\u0010v\u001a\u00020>8\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\bt\u0010uR\u0014\u0010x\u001a\u00020>8\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\bw\u0010uR\u0014\u0010z\u001a\u00020>8\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\by\u0010uR\u0014\u0010|\u001a\u00020>8\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b{\u0010uR\u0014\u0010~\u001a\u00020>8\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b}\u0010uR\u0014\u0010\u007f\u001a\u00020>8\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b\u0019\u0010uR\u0016\u0010\u0081\u0001\u001a\u00020>8\u0002X\u0082\u0004¢\u0006\u0007\n\u0005\b\u0080\u0001\u0010uR\u0015\u0010\u0082\u0001\u001a\u00020>8\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\bN\u0010uR\u0015\u0010\u0083\u0001\u001a\u00020>8\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\bI\u0010uR\u0015\u0010\u0084\u0001\u001a\u00020>8\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b1\u0010uR\u0017\u0010\u0085\u0001\u001a\u00020\u001f8\u0002@\u0002X\u0082\u000e¢\u0006\u0006\n\u0004\bQ\u0010NR\u0018\u0010\u0087\u0001\u001a\u00020\u001f8\u0002@\u0002X\u0082\u000e¢\u0006\u0007\n\u0005\b\u0086\u0001\u0010NR\u0018\u0010\u0089\u0001\u001a\u00020\u001f8\u0002@\u0002X\u0082\u000e¢\u0006\u0007\n\u0005\b\u0088\u0001\u0010NR\u0018\u0010\u008b\u0001\u001a\u00020\u001f8\u0002@\u0002X\u0082\u000e¢\u0006\u0007\n\u0005\b\u008a\u0001\u0010NR\u0017\u0010\u008e\u0001\u001a\u00020*8\u0002X\u0082\u0004¢\u0006\b\n\u0006\b\u008c\u0001\u0010\u008d\u0001R\u001b\u0010\u0091\u0001\u001a\u0004\u0018\u00010-8\u0002@\u0002X\u0082\u000e¢\u0006\b\n\u0006\b\u008f\u0001\u0010\u0090\u0001R\u001c\u0010\u0095\u0001\u001a\u0005\u0018\u00010\u0092\u00018\u0002@\u0002X\u0082\u000e¢\u0006\b\n\u0006\b\u0093\u0001\u0010\u0094\u0001R\u001b\u0010\u0097\u0001\u001a\u0004\u0018\u00010-8\u0002@\u0002X\u0082\u000e¢\u0006\b\n\u0006\b\u0096\u0001\u0010\u0090\u0001R\u001c\u0010\u009b\u0001\u001a\u0005\u0018\u00010\u0098\u00018\u0002@\u0002X\u0082\u000e¢\u0006\b\n\u0006\b\u0099\u0001\u0010\u009a\u0001R\u001b\u0010\u009d\u0001\u001a\u0004\u0018\u00010-8\u0002@\u0002X\u0082\u000e¢\u0006\b\n\u0006\b\u009c\u0001\u0010\u0090\u0001R\u0018\u0010\u001c\u001a\u00020\u001b8\u0002@\u0002X\u0082\u000e¢\u0006\b\n\u0006\b\u009e\u0001\u0010\u009f\u0001R\u0019\u0010¢\u0001\u001a\u00020\u00128\u0002@\u0002X\u0082\u000e¢\u0006\b\n\u0006\b \u0001\u0010¡\u0001R\u001a\u0010,\u001a\u00030£\u0001*\u00020\u00168BX\u0082\u0004¢\u0006\u0007\u001a\u0005\bh\u0010¤\u0001R\u001a\u0010¦\u0001\u001a\u00020\u0012*\u00020*8BX\u0082\u0004¢\u0006\u0007\u001a\u0005\bk\u0010¥\u0001R-\u0010«\u0001\u001a\u00020\b*\u00020>2\u0007\u0010§\u0001\u001a\u00020\b8B@BX\u0082\u000e¢\u0006\u000f\u001a\u0006\b¨\u0001\u0010©\u0001\"\u0005\b}\u0010ª\u0001¨\u0006\u00ad\u0001"}, d2 = {"Lcom/withpersona/sdk2/inquiry/selfie/view/SelfieOverlayView;", "Landroid/widget/FrameLayout;", "Landroid/content/Context;", "context", "Landroid/util/AttributeSet;", "attrs", "<init>", "(Landroid/content/Context;Landroid/util/AttributeSet;)V", BuildConfig.FLAVOR, "w", "h", "oldw", "oldh", BuildConfig.FLAVOR, "onSizeChanged", "(IIII)V", "onDetachedFromWindow", "()V", BuildConfig.FLAVOR, "mirrored", "setIsPreviewMirrored", "(Z)V", "Lcom/withpersona/sdk2/inquiry/selfie/view/SelfieOverlayView$e;", "newState", "animate", "D", "(Lcom/withpersona/sdk2/inquiry/selfie/view/SelfieOverlayView$e;Z)V", "Lxn/b;", "brightnessInfo", "setCameraStreamBrightnessInfo", "(Lxn/b;)V", BuildConfig.FLAVOR, "intensity", "setIntensity", "(F)V", "Landroid/graphics/Canvas;", "canvas", "onDraw", "(Landroid/graphics/Canvas;)V", "oldState", "x", "(Lcom/withpersona/sdk2/inquiry/selfie/view/SelfieOverlayView$e;Lcom/withpersona/sdk2/inquiry/selfie/view/SelfieOverlayView$e;)V", "Lcom/withpersona/sdk2/inquiry/selfie/view/SelfieOverlayView$a;", "startState", "endState", "Landroid/animation/ValueAnimator;", "kotlin.jvm.PlatformType", "u", "(Lcom/withpersona/sdk2/inquiry/selfie/view/SelfieOverlayView$a;Lcom/withpersona/sdk2/inquiry/selfie/view/SelfieOverlayView$a;)Landroid/animation/ValueAnimator;", "H", "Landroid/graphics/Path;", "left", "top", "right", "bottom", "startAngle", "sweepAngle", "numTicks", "tickLength", "m", "(Landroid/graphics/Path;FFFFFFIF)V", "n", "Landroid/graphics/Paint;", t.f29212d, "()Landroid/graphics/Paint;", "s", "start", "end", "percent", "q", "(Lcom/withpersona/sdk2/inquiry/selfie/view/SelfieOverlayView$a;Lcom/withpersona/sdk2/inquiry/selfie/view/SelfieOverlayView$a;Lcom/withpersona/sdk2/inquiry/selfie/view/SelfieOverlayView$a;F)V", "o", "(Lcom/withpersona/sdk2/inquiry/selfie/view/SelfieOverlayView$a;F)Lcom/withpersona/sdk2/inquiry/selfie/view/SelfieOverlayView$a;", "G", a.f36648e, "Lcom/withpersona/sdk2/inquiry/selfie/view/SelfieOverlayView$e;", "state", b.f21144e, "F", "currentIntensity", "c", "I", "colorOnSurface", "d", "shadowColor", "e", "accentColor", "f", "arcBaseColor", "g", "arcHighlightColor", "arcInset", "i", "arcGapDegrees", "j", "arcStrokeWidth", "k", "arcDialStrokeWidth", "l", "arcTickLength", "Landroid/graphics/Path;", "arcTop", "arcBottom", "arcLeft", "p", "arcRight", "arcDialLeft", "r", "arcDialRight", "arcDialTop", "arcDialBottom", "arcDialHighlightClipPathRight", "v", "arcDialHighlightClipPathLeft", "arcDialHighlightClipPathTop", "arcDialHighlightClipPathBottom", "y", "Landroid/graphics/Paint;", "arcTopPaint", "z", "arcBottomPaint", "A", "arcLeftPaint", "B", "arcRightPaint", "C", "shadowPaint", "arcDialLeftPaint", "E", "arcDialRightPaint", "arcDialTopPaint", "arcDialBottomPaint", "filledArcDialPaint", "arcDialLeftIntensity", "J", "arcDialRightIntensity", "K", "arcDialTopIntensity", "L", "arcDialBottomIntensity", "M", "Lcom/withpersona/sdk2/inquiry/selfie/view/SelfieOverlayView$a;", "arcHoverState", "N", "Landroid/animation/ValueAnimator;", "stateAnimator", "Lcom/withpersona/sdk2/inquiry/selfie/view/SelfieOverlayView$f;", "O", "Lcom/withpersona/sdk2/inquiry/selfie/view/SelfieOverlayView$f;", "stateAnimationState", "P", "intensityAnimator", "Lcom/withpersona/sdk2/inquiry/selfie/view/SelfieOverlayView$d;", "Q", "Lcom/withpersona/sdk2/inquiry/selfie/view/SelfieOverlayView$d;", "intensityAnimationState", "R", "directionHintAnimator", "S", "Lxn/b;", "T", "Z", "isPreviewMirrored", "Lcom/withpersona/sdk2/inquiry/selfie/view/SelfieOverlayView$c;", "(Lcom/withpersona/sdk2/inquiry/selfie/view/SelfieOverlayView$e;)Lcom/withpersona/sdk2/inquiry/selfie/view/SelfieOverlayView$c;", "(Lcom/withpersona/sdk2/inquiry/selfie/view/SelfieOverlayView$a;)Z", "isIdentity", "value", "getShadowAlpha", "(Landroid/graphics/Paint;)I", "(Landroid/graphics/Paint;I)V", "shadowAlpha", "U", "selfie_release"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* loaded from: classes3.dex */
public final class SelfieOverlayView extends FrameLayout {

    /* renamed from: A, reason: from kotlin metadata */
    @NotNull
    public final Paint arcLeftPaint;

    /* renamed from: B, reason: from kotlin metadata */
    @NotNull
    public final Paint arcRightPaint;

    /* renamed from: C, reason: from kotlin metadata */
    @NotNull
    public final Paint shadowPaint;

    /* renamed from: D, reason: from kotlin metadata */
    @NotNull
    public final Paint arcDialLeftPaint;

    /* renamed from: E, reason: from kotlin metadata */
    @NotNull
    public final Paint arcDialRightPaint;

    /* renamed from: F, reason: from kotlin metadata */
    @NotNull
    public final Paint arcDialTopPaint;

    /* renamed from: G, reason: from kotlin metadata */
    @NotNull
    public final Paint arcDialBottomPaint;

    /* renamed from: H, reason: from kotlin metadata */
    @NotNull
    public final Paint filledArcDialPaint;

    /* renamed from: I, reason: from kotlin metadata */
    public float arcDialLeftIntensity;

    /* renamed from: J, reason: from kotlin metadata */
    public float arcDialRightIntensity;

    /* renamed from: K, reason: from kotlin metadata */
    public float arcDialTopIntensity;

    /* renamed from: L, reason: from kotlin metadata */
    public float arcDialBottomIntensity;

    /* renamed from: M, reason: from kotlin metadata */
    @NotNull
    public final ArcHoverState arcHoverState;

    /* renamed from: N, reason: from kotlin metadata */
    @Nullable
    public ValueAnimator stateAnimator;

    /* renamed from: O, reason: from kotlin metadata */
    @Nullable
    public StateAnimationState stateAnimationState;

    /* renamed from: P, reason: from kotlin metadata */
    @Nullable
    public ValueAnimator intensityAnimator;

    /* renamed from: Q, reason: from kotlin metadata */
    @Nullable
    public IntensityAnimationState intensityAnimationState;

    /* renamed from: R, reason: from kotlin metadata */
    @Nullable
    public ValueAnimator directionHintAnimator;

    /* renamed from: S, reason: from kotlin metadata */
    @NotNull
    public xn.b brightnessInfo;

    /* renamed from: T, reason: from kotlin metadata */
    public boolean isPreviewMirrored;

    /* renamed from: a, reason: collision with root package name and from kotlin metadata */
    @NotNull
    public e state;

    /* renamed from: b, reason: from kotlin metadata */
    public float currentIntensity;

    /* renamed from: c, reason: collision with root package name and from kotlin metadata */
    public final int colorOnSurface;

    /* renamed from: d, reason: collision with root package name and from kotlin metadata */
    public final int shadowColor;

    /* renamed from: e, reason: collision with root package name and from kotlin metadata */
    public final int accentColor;

    /* renamed from: f, reason: collision with root package name and from kotlin metadata */
    public final int arcBaseColor;

    /* renamed from: g, reason: collision with root package name and from kotlin metadata */
    public final int arcHighlightColor;

    /* renamed from: h, reason: collision with root package name and from kotlin metadata */
    public final float arcInset;

    /* renamed from: i, reason: collision with root package name and from kotlin metadata */
    public final float arcGapDegrees;

    /* renamed from: j, reason: collision with root package name and from kotlin metadata */
    public final float arcStrokeWidth;

    /* renamed from: k, reason: collision with root package name and from kotlin metadata */
    public final float arcDialStrokeWidth;

    /* renamed from: l, reason: collision with root package name and from kotlin metadata */
    public final float arcTickLength;

    /* renamed from: m, reason: collision with root package name and from kotlin metadata */
    @NotNull
    public final Path arcTop;

    /* renamed from: n, reason: collision with root package name and from kotlin metadata */
    @NotNull
    public final Path arcBottom;

    /* renamed from: o, reason: collision with root package name and from kotlin metadata */
    @NotNull
    public final Path arcLeft;

    /* renamed from: p, reason: collision with root package name and from kotlin metadata */
    @NotNull
    public final Path arcRight;

    /* renamed from: q, reason: collision with root package name and from kotlin metadata */
    @NotNull
    public final Path arcDialLeft;

    /* renamed from: r, reason: collision with root package name and from kotlin metadata */
    @NotNull
    public final Path arcDialRight;

    /* renamed from: s, reason: collision with root package name and from kotlin metadata */
    @NotNull
    public final Path arcDialTop;

    /* renamed from: t, reason: collision with root package name and from kotlin metadata */
    @NotNull
    public final Path arcDialBottom;

    /* renamed from: u, reason: collision with root package name and from kotlin metadata */
    @NotNull
    public final Path arcDialHighlightClipPathRight;

    /* renamed from: v, reason: collision with root package name and from kotlin metadata */
    @NotNull
    public final Path arcDialHighlightClipPathLeft;

    /* renamed from: w, reason: collision with root package name and from kotlin metadata */
    @NotNull
    public final Path arcDialHighlightClipPathTop;

    /* renamed from: x, reason: collision with root package name and from kotlin metadata */
    @NotNull
    public final Path arcDialHighlightClipPathBottom;

    /* renamed from: y, reason: collision with root package name and from kotlin metadata */
    @NotNull
    public final Paint arcTopPaint;

    /* renamed from: z, reason: collision with root package name and from kotlin metadata */
    @NotNull
    public final Paint arcBottomPaint;

    /* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
    /* JADX WARN: Unknown enum class pattern. Please report as an issue! */
    @Metadata(d1 = {"\u0000\u0010\n\u0002\u0018\u0002\n\u0002\u0010\u0010\n\u0002\u0010\u0007\n\u0002\b\u001c\b\u0082\u0081\u0002\u0018\u00002\b\u0012\u0004\u0012\u00020\u00000\u0001BI\b\u0002\u0012\u0006\u0010\u0003\u001a\u00020\u0002\u0012\u0006\u0010\u0004\u001a\u00020\u0002\u0012\u0006\u0010\u0005\u001a\u00020\u0002\u0012\u0006\u0010\u0006\u001a\u00020\u0002\u0012\u0006\u0010\u0007\u001a\u00020\u0002\u0012\u0006\u0010\b\u001a\u00020\u0002\u0012\u0006\u0010\t\u001a\u00020\u0002\u0012\u0006\u0010\n\u001a\u00020\u0002¢\u0006\u0004\b\u000b\u0010\fR\u0017\u0010\u0003\u001a\u00020\u00028\u0006¢\u0006\f\n\u0004\b\r\u0010\u000e\u001a\u0004\b\u000f\u0010\u0010R\u0017\u0010\u0004\u001a\u00020\u00028\u0006¢\u0006\f\n\u0004\b\u0011\u0010\u000e\u001a\u0004\b\u0011\u0010\u0010R\u0017\u0010\u0005\u001a\u00020\u00028\u0006¢\u0006\f\n\u0004\b\u0012\u0010\u000e\u001a\u0004\b\u0013\u0010\u0010R\u0017\u0010\u0006\u001a\u00020\u00028\u0006¢\u0006\f\n\u0004\b\u0014\u0010\u000e\u001a\u0004\b\u0015\u0010\u0010R\u0017\u0010\u0007\u001a\u00020\u00028\u0006¢\u0006\f\n\u0004\b\u0016\u0010\u000e\u001a\u0004\b\u0014\u0010\u0010R\u0017\u0010\b\u001a\u00020\u00028\u0006¢\u0006\f\n\u0004\b\u0017\u0010\u000e\u001a\u0004\b\u0016\u0010\u0010R\u0017\u0010\t\u001a\u00020\u00028\u0006¢\u0006\f\n\u0004\b\u0018\u0010\u000e\u001a\u0004\b\u0019\u0010\u0010R\u0017\u0010\n\u001a\u00020\u00028\u0006¢\u0006\f\n\u0004\b\u0019\u0010\u000e\u001a\u0004\b\u0012\u0010\u0010j\u0002\b\u001aj\u0002\b\u001bj\u0002\b\u0013j\u0002\b\u001cj\u0002\b\u0015j\u0002\b\u001dj\u0002\b\u000f¨\u0006\u001e"}, d2 = {"Lcom/withpersona/sdk2/inquiry/selfie/view/SelfieOverlayView$c;", BuildConfig.FLAVOR, BuildConfig.FLAVOR, "arcTopAlpha", "arcBottomAlpha", "arcLeftAlpha", "arcRightAlpha", "arcDialLeftAlpha", "arcDialRightAlpha", "arcDialTopAlpha", "arcDialBottomAlpha", "<init>", "(Ljava/lang/String;IFFFFFFFF)V", a.f36648e, "F", "o", "()F", b.f21144e, "c", "k", "d", "m", "e", "f", "g", "h", "i", "j", "l", "n", "selfie_release"}, k = 1, mv = {2, 2, 0}, xi = 48)
    public static final class c {

        /* renamed from: i, reason: collision with root package name */
        public static final c f11052i = new c("Center", 0, 1.0f, 1.0f, 1.0f, 1.0f, 0.0f, 0.0f, 0.0f, 0.0f);

        /* renamed from: j, reason: collision with root package name */
        public static final c f11053j = new c("Left", 1, 0.1f, 0.1f, 0.0f, 0.1f, 1.0f, 0.0f, 0.0f, 0.0f);

        /* renamed from: k, reason: collision with root package name */
        public static final c f11054k = new c("Right", 2, 0.1f, 0.1f, 0.1f, 0.0f, 0.0f, 1.0f, 0.0f, 0.0f);

        /* renamed from: l, reason: collision with root package name */
        public static final c f11055l = new c("Up", 3, 0.0f, 0.1f, 0.1f, 0.1f, 0.0f, 0.0f, 1.0f, 0.0f);

        /* renamed from: m, reason: collision with root package name */
        public static final c f11056m = new c("Down", 4, 0.1f, 0.0f, 0.1f, 0.1f, 0.0f, 0.0f, 0.0f, 1.0f);

        /* renamed from: n, reason: collision with root package name */
        public static final c f11057n = new c("None", 5, 0.1f, 0.1f, 0.1f, 0.1f, 0.0f, 0.0f, 0.0f, 0.0f);

        /* renamed from: o, reason: collision with root package name */
        public static final c f11058o = new c("Finalizing", 6, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f);

        /* renamed from: p, reason: collision with root package name */
        public static final /* synthetic */ c[] f11059p;

        /* renamed from: q, reason: collision with root package name */
        public static final /* synthetic */ hu.a f11060q;

        /* renamed from: a, reason: collision with root package name and from kotlin metadata */
        public final float arcTopAlpha;

        /* renamed from: b, reason: from kotlin metadata */
        public final float arcBottomAlpha;

        /* renamed from: c, reason: collision with root package name and from kotlin metadata */
        public final float arcLeftAlpha;

        /* renamed from: d, reason: collision with root package name and from kotlin metadata */
        public final float arcRightAlpha;

        /* renamed from: e, reason: collision with root package name and from kotlin metadata */
        public final float arcDialLeftAlpha;

        /* renamed from: f, reason: collision with root package name and from kotlin metadata */
        public final float arcDialRightAlpha;

        /* renamed from: g, reason: collision with root package name and from kotlin metadata */
        public final float arcDialTopAlpha;

        /* renamed from: h, reason: collision with root package name and from kotlin metadata */
        public final float arcDialBottomAlpha;

        static {
            c[] a10 = a();
            f11059p = a10;
            f11060q = hu.b.a(a10);
        }

        public c(String str, int i10, float f10, float f11, float f12, float f13, float f14, float f15, float f16, float f17) {
            this.arcTopAlpha = f10;
            this.arcBottomAlpha = f11;
            this.arcLeftAlpha = f12;
            this.arcRightAlpha = f13;
            this.arcDialLeftAlpha = f14;
            this.arcDialRightAlpha = f15;
            this.arcDialTopAlpha = f16;
            this.arcDialBottomAlpha = f17;
        }

        public static final /* synthetic */ c[] a() {
            return new c[]{f11052i, f11053j, f11054k, f11055l, f11056m, f11057n, f11058o};
        }

        public static c valueOf(String str) {
            return (c) Enum.valueOf(c.class, str);
        }

        public static c[] values() {
            return (c[]) f11059p.clone();
        }

        /* renamed from: b, reason: from getter */
        public final float getArcBottomAlpha() {
            return this.arcBottomAlpha;
        }

        /* renamed from: c, reason: from getter */
        public final float getArcDialBottomAlpha() {
            return this.arcDialBottomAlpha;
        }

        /* renamed from: d, reason: from getter */
        public final float getArcDialLeftAlpha() {
            return this.arcDialLeftAlpha;
        }

        /* renamed from: e, reason: from getter */
        public final float getArcDialRightAlpha() {
            return this.arcDialRightAlpha;
        }

        /* renamed from: h, reason: from getter */
        public final float getArcDialTopAlpha() {
            return this.arcDialTopAlpha;
        }

        /* renamed from: k, reason: from getter */
        public final float getArcLeftAlpha() {
            return this.arcLeftAlpha;
        }

        /* renamed from: m, reason: from getter */
        public final float getArcRightAlpha() {
            return this.arcRightAlpha;
        }

        /* renamed from: o, reason: from getter */
        public final float getArcTopAlpha() {
            return this.arcTopAlpha;
        }
    }

    @Metadata(d1 = {"\u0000(\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\u0010\u0007\n\u0002\b\u0005\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0003\n\u0002\u0010\u000b\n\u0002\b\f\b\u0082\b\u0018\u00002\u00020\u0001B\u001f\u0012\u0006\u0010\u0003\u001a\u00020\u0002\u0012\u0006\u0010\u0004\u001a\u00020\u0002\u0012\u0006\u0010\u0005\u001a\u00020\u0002¢\u0006\u0004\b\u0006\u0010\u0007J\u0010\u0010\t\u001a\u00020\bHÖ\u0001¢\u0006\u0004\b\t\u0010\nJ\u0010\u0010\f\u001a\u00020\u000bHÖ\u0001¢\u0006\u0004\b\f\u0010\rJ\u001a\u0010\u0010\u001a\u00020\u000f2\b\u0010\u000e\u001a\u0004\u0018\u00010\u0001HÖ\u0003¢\u0006\u0004\b\u0010\u0010\u0011R\"\u0010\u0003\u001a\u00020\u00028\u0006@\u0006X\u0086\u000e¢\u0006\u0012\n\u0004\b\u0012\u0010\u0013\u001a\u0004\b\u0014\u0010\u0015\"\u0004\b\u0016\u0010\u0017R\"\u0010\u0004\u001a\u00020\u00028\u0006@\u0006X\u0086\u000e¢\u0006\u0012\n\u0004\b\u0014\u0010\u0013\u001a\u0004\b\u0018\u0010\u0015\"\u0004\b\u0019\u0010\u0017R\"\u0010\u0005\u001a\u00020\u00028\u0006@\u0006X\u0086\u000e¢\u0006\u0012\n\u0004\b\u0018\u0010\u0013\u001a\u0004\b\u0012\u0010\u0015\"\u0004\b\u001a\u0010\u0017¨\u0006\u001b"}, d2 = {"Lcom/withpersona/sdk2/inquiry/selfie/view/SelfieOverlayView$d;", BuildConfig.FLAVOR, BuildConfig.FLAVOR, "progress", "startIntensity", "endIntensity", "<init>", "(FFF)V", BuildConfig.FLAVOR, "toString", "()Ljava/lang/String;", BuildConfig.FLAVOR, "hashCode", "()I", "other", BuildConfig.FLAVOR, "equals", "(Ljava/lang/Object;)Z", a.f36648e, "F", b.f21144e, "()F", "d", "(F)V", "c", "setStartIntensity", "setEndIntensity", "selfie_release"}, k = 1, mv = {2, 2, 0}, xi = 48)
    /* renamed from: com.withpersona.sdk2.inquiry.selfie.view.SelfieOverlayView$d, reason: from toString */
    public static final /* data */ class IntensityAnimationState {

        /* renamed from: a, reason: collision with root package name and from kotlin metadata and from toString */
        public float progress;

        /* renamed from: b, reason: from kotlin metadata and from toString */
        public float startIntensity;

        /* renamed from: c, reason: collision with root package name and from kotlin metadata and from toString */
        public float endIntensity;

        public IntensityAnimationState(float f10, float f11, float f12) {
            this.progress = f10;
            this.startIntensity = f11;
            this.endIntensity = f12;
        }

        /* renamed from: a, reason: from getter */
        public final float getEndIntensity() {
            return this.endIntensity;
        }

        /* renamed from: b, reason: from getter */
        public final float getProgress() {
            return this.progress;
        }

        /* renamed from: c, reason: from getter */
        public final float getStartIntensity() {
            return this.startIntensity;
        }

        public final void d(float f10) {
            this.progress = f10;
        }

        public boolean equals(@Nullable Object other) {
            if (this == other) {
                return true;
            }
            if (!(other instanceof IntensityAnimationState)) {
                return false;
            }
            IntensityAnimationState intensityAnimationState = (IntensityAnimationState) other;
            return Float.compare(this.progress, intensityAnimationState.progress) == 0 && Float.compare(this.startIntensity, intensityAnimationState.startIntensity) == 0 && Float.compare(this.endIntensity, intensityAnimationState.endIntensity) == 0;
        }

        public int hashCode() {
            return (((Float.hashCode(this.progress) * 31) + Float.hashCode(this.startIntensity)) * 31) + Float.hashCode(this.endIntensity);
        }

        @NotNull
        public String toString() {
            return "IntensityAnimationState(progress=" + this.progress + ", startIntensity=" + this.startIntensity + ", endIntensity=" + this.endIntensity + ")";
        }
    }

    /* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
    /* JADX WARN: Unknown enum class pattern. Please report as an issue! */
    @Metadata(d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0010\u0010\n\u0002\b\n\b\u0086\u0081\u0002\u0018\u00002\b\u0012\u0004\u0012\u00020\u00000\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003j\u0002\b\u0004j\u0002\b\u0005j\u0002\b\u0006j\u0002\b\u0007j\u0002\b\bj\u0002\b\tj\u0002\b\n¨\u0006\u000b"}, d2 = {"Lcom/withpersona/sdk2/inquiry/selfie/view/SelfieOverlayView$e;", BuildConfig.FLAVOR, "<init>", "(Ljava/lang/String;I)V", a.f36648e, b.f21144e, "c", "d", "e", "f", "g", "selfie_release"}, k = 1, mv = {2, 2, 0}, xi = 48)
    public static final class e {

        /* renamed from: a, reason: collision with root package name */
        public static final e f11070a = new e("Center", 0);
        public static final e b = new e("Left", 1);

        /* renamed from: c, reason: collision with root package name */
        public static final e f11071c = new e("Right", 2);

        /* renamed from: d, reason: collision with root package name */
        public static final e f11072d = new e("Up", 3);

        /* renamed from: e, reason: collision with root package name */
        public static final e f11073e = new e("Down", 4);

        /* renamed from: f, reason: collision with root package name */
        public static final e f11074f = new e("None", 5);

        /* renamed from: g, reason: collision with root package name */
        public static final e f11075g = new e("Finalizing", 6);

        /* renamed from: h, reason: collision with root package name */
        public static final /* synthetic */ e[] f11076h;

        /* renamed from: i, reason: collision with root package name */
        public static final /* synthetic */ hu.a f11077i;

        static {
            e[] a10 = a();
            f11076h = a10;
            f11077i = hu.b.a(a10);
        }

        public e(String str, int i10) {
        }

        public static final /* synthetic */ e[] a() {
            return new e[]{f11070a, b, f11071c, f11072d, f11073e, f11074f, f11075g};
        }

        public static e valueOf(String str) {
            return (e) Enum.valueOf(e.class, str);
        }

        public static e[] values() {
            return (e[]) f11076h.clone();
        }
    }

    @Metadata(d1 = {"\u0000.\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0007\n\u0002\b\f\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u001b\b\u0082\b\u0018\u00002\u00020\u0001Bo\u0012\u0006\u0010\u0003\u001a\u00020\u0002\u0012\u0006\u0010\u0005\u001a\u00020\u0004\u0012\u0006\u0010\u0006\u001a\u00020\u0004\u0012\u0006\u0010\b\u001a\u00020\u0007\u0012\u0006\u0010\t\u001a\u00020\u0007\u0012\u0006\u0010\n\u001a\u00020\u0007\u0012\u0006\u0010\u000b\u001a\u00020\u0007\u0012\u0006\u0010\f\u001a\u00020\u0007\u0012\u0006\u0010\r\u001a\u00020\u0007\u0012\u0006\u0010\u000e\u001a\u00020\u0007\u0012\u0006\u0010\u000f\u001a\u00020\u0007\u0012\u0006\u0010\u0010\u001a\u00020\u0007\u0012\u0006\u0010\u0011\u001a\u00020\u0007¢\u0006\u0004\b\u0012\u0010\u0013J\u0010\u0010\u0015\u001a\u00020\u0014HÖ\u0001¢\u0006\u0004\b\u0015\u0010\u0016J\u0010\u0010\u0018\u001a\u00020\u0017HÖ\u0001¢\u0006\u0004\b\u0018\u0010\u0019J\u001a\u0010\u001b\u001a\u00020\u00022\b\u0010\u001a\u001a\u0004\u0018\u00010\u0001HÖ\u0003¢\u0006\u0004\b\u001b\u0010\u001cR\u0017\u0010\u0003\u001a\u00020\u00028\u0006¢\u0006\f\n\u0004\b\u001d\u0010\u001e\u001a\u0004\b\u001d\u0010\u001fR\u0017\u0010\u0005\u001a\u00020\u00048\u0006¢\u0006\f\n\u0004\b \u0010!\u001a\u0004\b\"\u0010#R\u0017\u0010\u0006\u001a\u00020\u00048\u0006¢\u0006\f\n\u0004\b$\u0010!\u001a\u0004\b \u0010#R\u0017\u0010\b\u001a\u00020\u00078\u0006¢\u0006\f\n\u0004\b%\u0010&\u001a\u0004\b'\u0010(R\"\u0010\t\u001a\u00020\u00078\u0006@\u0006X\u0086\u000e¢\u0006\u0012\n\u0004\b)\u0010&\u001a\u0004\b$\u0010(\"\u0004\b*\u0010+R\u0017\u0010\n\u001a\u00020\u00078\u0006¢\u0006\f\n\u0004\b,\u0010&\u001a\u0004\b-\u0010(R\u0017\u0010\u000b\u001a\u00020\u00078\u0006¢\u0006\f\n\u0004\b.\u0010&\u001a\u0004\b%\u0010(R\u0017\u0010\f\u001a\u00020\u00078\u0006¢\u0006\f\n\u0004\b/\u0010&\u001a\u0004\b0\u0010(R\u0017\u0010\r\u001a\u00020\u00078\u0006¢\u0006\f\n\u0004\b0\u0010&\u001a\u0004\b1\u0010(R\u0017\u0010\u000e\u001a\u00020\u00078\u0006¢\u0006\f\n\u0004\b1\u0010&\u001a\u0004\b,\u0010(R\u0017\u0010\u000f\u001a\u00020\u00078\u0006¢\u0006\f\n\u0004\b-\u0010&\u001a\u0004\b.\u0010(R\u0017\u0010\u0010\u001a\u00020\u00078\u0006¢\u0006\f\n\u0004\b'\u0010&\u001a\u0004\b/\u0010(R\u0017\u0010\u0011\u001a\u00020\u00078\u0006¢\u0006\f\n\u0004\b\"\u0010&\u001a\u0004\b)\u0010(¨\u00062"}, d2 = {"Lcom/withpersona/sdk2/inquiry/selfie/view/SelfieOverlayView$f;", BuildConfig.FLAVOR, BuildConfig.FLAVOR, "animating", "Lcom/withpersona/sdk2/inquiry/selfie/view/SelfieOverlayView$e;", "startState", "endState", BuildConfig.FLAVOR, "startIntensity", "progress", "startArcTopAlpha", "startArcBottomAlpha", "startArcLeftAlpha", "startArcRightAlpha", "startArcDialLeftAlpha", "startArcDialRightAlpha", "startArcDialTopAlpha", "startArcDialBottomAlpha", "<init>", "(ZLcom/withpersona/sdk2/inquiry/selfie/view/SelfieOverlayView$e;Lcom/withpersona/sdk2/inquiry/selfie/view/SelfieOverlayView$e;FFFFFFFFFF)V", BuildConfig.FLAVOR, "toString", "()Ljava/lang/String;", BuildConfig.FLAVOR, "hashCode", "()I", "other", "equals", "(Ljava/lang/Object;)Z", a.f36648e, "Z", "()Z", b.f21144e, "Lcom/withpersona/sdk2/inquiry/selfie/view/SelfieOverlayView$e;", "m", "()Lcom/withpersona/sdk2/inquiry/selfie/view/SelfieOverlayView$e;", "c", "d", "F", "l", "()F", "e", "n", "(F)V", "f", "k", "g", "h", "i", "j", "selfie_release"}, k = 1, mv = {2, 2, 0}, xi = 48)
    /* renamed from: com.withpersona.sdk2.inquiry.selfie.view.SelfieOverlayView$f, reason: from toString */
    public static final /* data */ class StateAnimationState {

        /* renamed from: a, reason: collision with root package name and from kotlin metadata and from toString */
        public final boolean animating;

        /* renamed from: b, reason: from kotlin metadata and from toString */
        @NotNull
        public final e startState;

        /* renamed from: c, reason: collision with root package name and from kotlin metadata and from toString */
        @NotNull
        public final e endState;

        /* renamed from: d, reason: collision with root package name and from kotlin metadata and from toString */
        public final float startIntensity;

        /* renamed from: e, reason: collision with root package name and from kotlin metadata and from toString */
        public float progress;

        /* renamed from: f, reason: collision with root package name and from kotlin metadata and from toString */
        public final float startArcTopAlpha;

        /* renamed from: g, reason: collision with root package name and from kotlin metadata and from toString */
        public final float startArcBottomAlpha;

        /* renamed from: h, reason: collision with root package name and from kotlin metadata and from toString */
        public final float startArcLeftAlpha;

        /* renamed from: i, reason: collision with root package name and from kotlin metadata and from toString */
        public final float startArcRightAlpha;

        /* renamed from: j, reason: collision with root package name and from kotlin metadata and from toString */
        public final float startArcDialLeftAlpha;

        /* renamed from: k, reason: collision with root package name and from kotlin metadata and from toString */
        public final float startArcDialRightAlpha;

        /* renamed from: l, reason: collision with root package name and from kotlin metadata and from toString */
        public final float startArcDialTopAlpha;

        /* renamed from: m, reason: collision with root package name and from kotlin metadata and from toString */
        public final float startArcDialBottomAlpha;

        public StateAnimationState(boolean z10, @NotNull e startState, @NotNull e endState, float f10, float f11, float f12, float f13, float f14, float f15, float f16, float f17, float f18, float f19) {
            Intrinsics.checkNotNullParameter(startState, "startState");
            Intrinsics.checkNotNullParameter(endState, "endState");
            this.animating = z10;
            this.startState = startState;
            this.endState = endState;
            this.startIntensity = f10;
            this.progress = f11;
            this.startArcTopAlpha = f12;
            this.startArcBottomAlpha = f13;
            this.startArcLeftAlpha = f14;
            this.startArcRightAlpha = f15;
            this.startArcDialLeftAlpha = f16;
            this.startArcDialRightAlpha = f17;
            this.startArcDialTopAlpha = f18;
            this.startArcDialBottomAlpha = f19;
        }

        /* renamed from: a, reason: from getter */
        public final boolean getAnimating() {
            return this.animating;
        }

        @NotNull
        /* renamed from: b, reason: from getter */
        public final e getEndState() {
            return this.endState;
        }

        /* renamed from: c, reason: from getter */
        public final float getProgress() {
            return this.progress;
        }

        /* renamed from: d, reason: from getter */
        public final float getStartArcBottomAlpha() {
            return this.startArcBottomAlpha;
        }

        /* renamed from: e, reason: from getter */
        public final float getStartArcDialBottomAlpha() {
            return this.startArcDialBottomAlpha;
        }

        public boolean equals(@Nullable Object other) {
            if (this == other) {
                return true;
            }
            if (!(other instanceof StateAnimationState)) {
                return false;
            }
            StateAnimationState stateAnimationState = (StateAnimationState) other;
            return this.animating == stateAnimationState.animating && this.startState == stateAnimationState.startState && this.endState == stateAnimationState.endState && Float.compare(this.startIntensity, stateAnimationState.startIntensity) == 0 && Float.compare(this.progress, stateAnimationState.progress) == 0 && Float.compare(this.startArcTopAlpha, stateAnimationState.startArcTopAlpha) == 0 && Float.compare(this.startArcBottomAlpha, stateAnimationState.startArcBottomAlpha) == 0 && Float.compare(this.startArcLeftAlpha, stateAnimationState.startArcLeftAlpha) == 0 && Float.compare(this.startArcRightAlpha, stateAnimationState.startArcRightAlpha) == 0 && Float.compare(this.startArcDialLeftAlpha, stateAnimationState.startArcDialLeftAlpha) == 0 && Float.compare(this.startArcDialRightAlpha, stateAnimationState.startArcDialRightAlpha) == 0 && Float.compare(this.startArcDialTopAlpha, stateAnimationState.startArcDialTopAlpha) == 0 && Float.compare(this.startArcDialBottomAlpha, stateAnimationState.startArcDialBottomAlpha) == 0;
        }

        /* renamed from: f, reason: from getter */
        public final float getStartArcDialLeftAlpha() {
            return this.startArcDialLeftAlpha;
        }

        /* renamed from: g, reason: from getter */
        public final float getStartArcDialRightAlpha() {
            return this.startArcDialRightAlpha;
        }

        /* renamed from: h, reason: from getter */
        public final float getStartArcDialTopAlpha() {
            return this.startArcDialTopAlpha;
        }

        public int hashCode() {
            return (((((((((((((((((((((((Boolean.hashCode(this.animating) * 31) + this.startState.hashCode()) * 31) + this.endState.hashCode()) * 31) + Float.hashCode(this.startIntensity)) * 31) + Float.hashCode(this.progress)) * 31) + Float.hashCode(this.startArcTopAlpha)) * 31) + Float.hashCode(this.startArcBottomAlpha)) * 31) + Float.hashCode(this.startArcLeftAlpha)) * 31) + Float.hashCode(this.startArcRightAlpha)) * 31) + Float.hashCode(this.startArcDialLeftAlpha)) * 31) + Float.hashCode(this.startArcDialRightAlpha)) * 31) + Float.hashCode(this.startArcDialTopAlpha)) * 31) + Float.hashCode(this.startArcDialBottomAlpha);
        }

        /* renamed from: i, reason: from getter */
        public final float getStartArcLeftAlpha() {
            return this.startArcLeftAlpha;
        }

        /* renamed from: j, reason: from getter */
        public final float getStartArcRightAlpha() {
            return this.startArcRightAlpha;
        }

        /* renamed from: k, reason: from getter */
        public final float getStartArcTopAlpha() {
            return this.startArcTopAlpha;
        }

        /* renamed from: l, reason: from getter */
        public final float getStartIntensity() {
            return this.startIntensity;
        }

        @NotNull
        /* renamed from: m, reason: from getter */
        public final e getStartState() {
            return this.startState;
        }

        public final void n(float f10) {
            this.progress = f10;
        }

        @NotNull
        public String toString() {
            return "StateAnimationState(animating=" + this.animating + ", startState=" + this.startState + ", endState=" + this.endState + ", startIntensity=" + this.startIntensity + ", progress=" + this.progress + ", startArcTopAlpha=" + this.startArcTopAlpha + ", startArcBottomAlpha=" + this.startArcBottomAlpha + ", startArcLeftAlpha=" + this.startArcLeftAlpha + ", startArcRightAlpha=" + this.startArcRightAlpha + ", startArcDialLeftAlpha=" + this.startArcDialLeftAlpha + ", startArcDialRightAlpha=" + this.startArcDialRightAlpha + ", startArcDialTopAlpha=" + this.startArcDialTopAlpha + ", startArcDialBottomAlpha=" + this.startArcDialBottomAlpha + ")";
        }
    }

    @Metadata(k = 3, mv = {2, 2, 0}, xi = 48)
    public static final /* synthetic */ class g {

        /* renamed from: a, reason: collision with root package name */
        public static final /* synthetic */ int[] f11090a;

        static {
            int[] iArr = new int[e.values().length];
            try {
                iArr[e.f11070a.ordinal()] = 1;
            } catch (NoSuchFieldError unused) {
            }
            try {
                iArr[e.b.ordinal()] = 2;
            } catch (NoSuchFieldError unused2) {
            }
            try {
                iArr[e.f11071c.ordinal()] = 3;
            } catch (NoSuchFieldError unused3) {
            }
            try {
                iArr[e.f11072d.ordinal()] = 4;
            } catch (NoSuchFieldError unused4) {
            }
            try {
                iArr[e.f11073e.ordinal()] = 5;
            } catch (NoSuchFieldError unused5) {
            }
            try {
                iArr[e.f11074f.ordinal()] = 6;
            } catch (NoSuchFieldError unused6) {
            }
            try {
                iArr[e.f11075g.ordinal()] = 7;
            } catch (NoSuchFieldError unused7) {
            }
            f11090a = iArr;
        }
    }

    @Metadata(d1 = {"\u0000\u0017\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0006*\u0001\u0000\b\n\u0018\u00002\u00020\u0001J\u0017\u0010\u0005\u001a\u00020\u00042\u0006\u0010\u0003\u001a\u00020\u0002H\u0016¢\u0006\u0004\b\u0005\u0010\u0006J\u0017\u0010\u0007\u001a\u00020\u00042\u0006\u0010\u0003\u001a\u00020\u0002H\u0016¢\u0006\u0004\b\u0007\u0010\u0006J\u0017\u0010\b\u001a\u00020\u00042\u0006\u0010\u0003\u001a\u00020\u0002H\u0016¢\u0006\u0004\b\b\u0010\u0006J\u0017\u0010\t\u001a\u00020\u00042\u0006\u0010\u0003\u001a\u00020\u0002H\u0016¢\u0006\u0004\b\t\u0010\u0006¨\u0006\n"}, d2 = {"com/withpersona/sdk2/inquiry/selfie/view/SelfieOverlayView$h", "Landroid/animation/Animator$AnimatorListener;", "Landroid/animation/Animator;", "animator", BuildConfig.FLAVOR, "onAnimationRepeat", "(Landroid/animation/Animator;)V", "onAnimationEnd", "onAnimationCancel", "onAnimationStart", "core-ktx_release"}, k = 1, mv = {2, 2, 0})
    public static final class h implements Animator.AnimatorListener {

        /* renamed from: a, reason: collision with root package name */
        public final /* synthetic */ y f11091a;
        public final /* synthetic */ e b;

        /* renamed from: c, reason: collision with root package name */
        public final /* synthetic */ SelfieOverlayView f11092c;

        /* renamed from: d, reason: collision with root package name */
        public final /* synthetic */ y f11093d;

        public h(y yVar, e eVar, SelfieOverlayView selfieOverlayView, y yVar2) {
            this.f11091a = yVar;
            this.b = eVar;
            this.f11092c = selfieOverlayView;
            this.f11093d = yVar2;
        }

        @Override // android.animation.Animator.AnimatorListener
        public void onAnimationCancel(@NotNull Animator animator) {
            Intrinsics.e(animator, "animator");
            this.f11093d.f21589a = true;
        }

        @Override // android.animation.Animator.AnimatorListener
        public void onAnimationEnd(@NotNull Animator animator) {
            Intrinsics.e(animator, "animator");
            if (this.f11091a.f21589a) {
                return;
            }
            SelfieOverlayView.z(this.b, this.f11092c);
        }

        @Override // android.animation.Animator.AnimatorListener
        public void onAnimationRepeat(@NotNull Animator animator) {
            Intrinsics.e(animator, "animator");
        }

        @Override // android.animation.Animator.AnimatorListener
        public void onAnimationStart(@NotNull Animator animator) {
            Intrinsics.e(animator, "animator");
        }
    }

    @Metadata(d1 = {"\u0000\u0017\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0007*\u0001\u0000\b\n\u0018\u00002\u00020\u0001J\u0017\u0010\u0005\u001a\u00020\u00042\u0006\u0010\u0003\u001a\u00020\u0002H\u0016¢\u0006\u0004\b\u0005\u0010\u0006J\u0017\u0010\u0007\u001a\u00020\u00042\u0006\u0010\u0003\u001a\u00020\u0002H\u0016¢\u0006\u0004\b\u0007\u0010\u0006J\u0017\u0010\b\u001a\u00020\u00042\u0006\u0010\u0003\u001a\u00020\u0002H\u0016¢\u0006\u0004\b\b\u0010\u0006J\u0017\u0010\t\u001a\u00020\u00042\u0006\u0010\u0003\u001a\u00020\u0002H\u0016¢\u0006\u0004\b\t\u0010\u0006¨\u0006\u000b¸\u0006\n"}, d2 = {"androidx/core/animation/AnimatorKt$addListener$listener$1", "Landroid/animation/Animator$AnimatorListener;", "Landroid/animation/Animator;", "animator", BuildConfig.FLAVOR, "onAnimationRepeat", "(Landroid/animation/Animator;)V", "onAnimationEnd", "onAnimationCancel", "onAnimationStart", "androidx/core/animation/AnimatorKt$doOnEnd$$inlined$addListener$1", "core-ktx_release"}, k = 1, mv = {2, 2, 0})
    public static final class i implements Animator.AnimatorListener {
        public i() {
        }

        @Override // android.animation.Animator.AnimatorListener
        public void onAnimationCancel(@NotNull Animator animator) {
            Intrinsics.e(animator, "animator");
        }

        @Override // android.animation.Animator.AnimatorListener
        public void onAnimationEnd(@NotNull Animator animator) {
            Intrinsics.e(animator, "animator");
            SelfieOverlayView.this.intensityAnimationState = null;
        }

        @Override // android.animation.Animator.AnimatorListener
        public void onAnimationRepeat(@NotNull Animator animator) {
            Intrinsics.e(animator, "animator");
        }

        @Override // android.animation.Animator.AnimatorListener
        public void onAnimationStart(@NotNull Animator animator) {
            Intrinsics.e(animator, "animator");
        }
    }

    @Metadata(d1 = {"\u0000\u0017\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0007*\u0001\u0000\b\n\u0018\u00002\u00020\u0001J\u0017\u0010\u0005\u001a\u00020\u00042\u0006\u0010\u0003\u001a\u00020\u0002H\u0016¢\u0006\u0004\b\u0005\u0010\u0006J\u0017\u0010\u0007\u001a\u00020\u00042\u0006\u0010\u0003\u001a\u00020\u0002H\u0016¢\u0006\u0004\b\u0007\u0010\u0006J\u0017\u0010\b\u001a\u00020\u00042\u0006\u0010\u0003\u001a\u00020\u0002H\u0016¢\u0006\u0004\b\b\u0010\u0006J\u0017\u0010\t\u001a\u00020\u00042\u0006\u0010\u0003\u001a\u00020\u0002H\u0016¢\u0006\u0004\b\t\u0010\u0006¨\u0006\u000b¸\u0006\n"}, d2 = {"androidx/core/animation/AnimatorKt$addListener$listener$1", "Landroid/animation/Animator$AnimatorListener;", "Landroid/animation/Animator;", "animator", BuildConfig.FLAVOR, "onAnimationRepeat", "(Landroid/animation/Animator;)V", "onAnimationEnd", "onAnimationCancel", "onAnimationStart", "androidx/core/animation/AnimatorKt$doOnEnd$$inlined$addListener$1", "core-ktx_release"}, k = 1, mv = {2, 2, 0})
    public static final class j implements Animator.AnimatorListener {
        public j() {
        }

        @Override // android.animation.Animator.AnimatorListener
        public void onAnimationCancel(@NotNull Animator animator) {
            Intrinsics.e(animator, "animator");
        }

        @Override // android.animation.Animator.AnimatorListener
        public void onAnimationEnd(@NotNull Animator animator) {
            Intrinsics.e(animator, "animator");
            StateAnimationState stateAnimationState = SelfieOverlayView.this.stateAnimationState;
            if (stateAnimationState != null) {
                e eVar = SelfieOverlayView.this.state;
                SelfieOverlayView.this.state = stateAnimationState.getEndState();
                SelfieOverlayView.this.x(eVar, stateAnimationState.getEndState());
            }
            SelfieOverlayView.this.stateAnimationState = null;
        }

        @Override // android.animation.Animator.AnimatorListener
        public void onAnimationRepeat(@NotNull Animator animator) {
            Intrinsics.e(animator, "animator");
        }

        @Override // android.animation.Animator.AnimatorListener
        public void onAnimationStart(@NotNull Animator animator) {
            Intrinsics.e(animator, "animator");
        }
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public SelfieOverlayView(@NotNull Context context, @Nullable AttributeSet attributeSet) {
        super(context, attributeSet);
        Intrinsics.checkNotNullParameter(context, "context");
        this.state = e.f11070a;
        this.colorOnSurface = -1;
        this.shadowColor = -16777216;
        this.accentColor = -13910906;
        this.arcBaseColor = -1;
        this.arcHighlightColor = -13910906;
        this.arcInset = (float) xq.j.a(48.0d);
        this.arcGapDegrees = 20.0f;
        this.arcStrokeWidth = (float) xq.j.a(4.0d);
        this.arcDialStrokeWidth = (float) xq.j.a(2.0d);
        this.arcTickLength = (float) xq.j.a(24.0d);
        this.arcTop = new Path();
        this.arcBottom = new Path();
        this.arcLeft = new Path();
        this.arcRight = new Path();
        this.arcDialLeft = new Path();
        this.arcDialRight = new Path();
        this.arcDialTop = new Path();
        this.arcDialBottom = new Path();
        this.arcDialHighlightClipPathRight = new Path();
        this.arcDialHighlightClipPathLeft = new Path();
        this.arcDialHighlightClipPathTop = new Path();
        this.arcDialHighlightClipPathBottom = new Path();
        this.arcTopPaint = t();
        this.arcBottomPaint = t();
        this.arcLeftPaint = t();
        this.arcRightPaint = t();
        this.shadowPaint = w();
        Paint s8 = s();
        s8.setAlpha(0);
        this.arcDialLeftPaint = s8;
        Paint s10 = s();
        s10.setAlpha(0);
        this.arcDialRightPaint = s10;
        Paint s11 = s();
        s11.setAlpha(0);
        this.arcDialTopPaint = s11;
        Paint s12 = s();
        s12.setAlpha(0);
        this.arcDialBottomPaint = s12;
        Paint s13 = s();
        s13.setColor(-13910906);
        this.filledArcDialPaint = s13;
        this.arcHoverState = o(new ArcHoverState(0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 511, null), this.currentIntensity);
        this.brightnessInfo = new xn.b(null, 1, null);
        setWillNotDraw(false);
    }

    public static final void A(SelfieOverlayView selfieOverlayView, ArcHoverState arcHoverState, ArcHoverState arcHoverState2, ValueAnimator it) {
        Intrinsics.checkNotNullParameter(it, "it");
        selfieOverlayView.q(selfieOverlayView.arcHoverState, arcHoverState, arcHoverState2, it.getAnimatedFraction());
        IntensityAnimationState intensityAnimationState = selfieOverlayView.intensityAnimationState;
        if (intensityAnimationState != null) {
            intensityAnimationState.d(it.getAnimatedFraction());
        }
        selfieOverlayView.n();
    }

    public static final void B(SelfieOverlayView selfieOverlayView, ValueAnimator it) {
        Intrinsics.checkNotNullParameter(it, "it");
        IntensityAnimationState intensityAnimationState = selfieOverlayView.intensityAnimationState;
        if (intensityAnimationState != null) {
            intensityAnimationState.d(it.getAnimatedFraction());
        }
        selfieOverlayView.n();
    }

    public static /* synthetic */ void E(SelfieOverlayView selfieOverlayView, e eVar, boolean z10, int i10, Object obj) {
        if ((i10 & 2) != 0) {
            z10 = true;
        }
        selfieOverlayView.D(eVar, z10);
    }

    public static final void F(SelfieOverlayView selfieOverlayView, ValueAnimator it) {
        Intrinsics.checkNotNullParameter(it, "it");
        StateAnimationState stateAnimationState = selfieOverlayView.stateAnimationState;
        if (stateAnimationState != null) {
            stateAnimationState.n(it.getAnimatedFraction());
        }
        selfieOverlayView.n();
    }

    public static final void v(SelfieOverlayView selfieOverlayView, ArcHoverState arcHoverState, ArcHoverState arcHoverState2, ValueAnimator it) {
        Intrinsics.checkNotNullParameter(it, "it");
        selfieOverlayView.q(selfieOverlayView.arcHoverState, arcHoverState, arcHoverState2, it.getAnimatedFraction());
        selfieOverlayView.n();
    }

    public static final void y(SelfieOverlayView selfieOverlayView, ArcHoverState arcHoverState, ArcHoverState arcHoverState2, ValueAnimator it) {
        Intrinsics.checkNotNullParameter(it, "it");
        selfieOverlayView.q(selfieOverlayView.arcHoverState, arcHoverState, arcHoverState2, it.getAnimatedFraction());
        selfieOverlayView.invalidate();
    }

    public static final void z(e eVar, SelfieOverlayView selfieOverlayView) {
        switch (g.f11090a[eVar.ordinal()]) {
            case 1:
            case 6:
            case 7:
                return;
            case 2:
                ArcHoverState b = ArcHoverState.b(selfieOverlayView.arcHoverState, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 511, null);
                ArcHoverState arcHoverState = new ArcHoverState(0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 511, null);
                arcHoverState.n(-((float) xq.j.c(48.0d)));
                Unit unit = Unit.f21504a;
                ValueAnimator u8 = selfieOverlayView.u(b, arcHoverState);
                u8.start();
                selfieOverlayView.directionHintAnimator = u8;
                return;
            case 3:
                ArcHoverState b10 = ArcHoverState.b(selfieOverlayView.arcHoverState, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 511, null);
                ArcHoverState arcHoverState2 = new ArcHoverState(0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 511, null);
                arcHoverState2.p((float) xq.j.c(48.0d));
                Unit unit2 = Unit.f21504a;
                ValueAnimator u10 = selfieOverlayView.u(b10, arcHoverState2);
                u10.start();
                selfieOverlayView.directionHintAnimator = u10;
                return;
            case 4:
                ArcHoverState b11 = ArcHoverState.b(selfieOverlayView.arcHoverState, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 511, null);
                ArcHoverState arcHoverState3 = new ArcHoverState(0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 511, null);
                arcHoverState3.t(-((float) xq.j.c(48.0d)));
                Unit unit3 = Unit.f21504a;
                ValueAnimator u11 = selfieOverlayView.u(b11, arcHoverState3);
                u11.start();
                selfieOverlayView.directionHintAnimator = u11;
                return;
            case 5:
                ArcHoverState b12 = ArcHoverState.b(selfieOverlayView.arcHoverState, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 511, null);
                ArcHoverState arcHoverState4 = new ArcHoverState(0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 511, null);
                arcHoverState4.m((float) xq.j.c(48.0d));
                Unit unit4 = Unit.f21504a;
                ValueAnimator u12 = selfieOverlayView.u(b12, arcHoverState4);
                u12.start();
                selfieOverlayView.directionHintAnimator = u12;
                return;
            default:
                throw new l();
        }
    }

    public final void C(Paint paint, int i10) {
        if (paint.getAlpha() == i10) {
            return;
        }
        paint.setShadowLayer(this.arcStrokeWidth * 2, 0.0f, 0.0f, androidx.core.graphics.c.l(this.shadowColor, i10));
        paint.setAlpha(i10);
    }

    public final void D(@NotNull e newState, boolean animate) {
        Intrinsics.checkNotNullParameter(newState, "newState");
        StateAnimationState stateAnimationState = this.stateAnimationState;
        if (stateAnimationState != null && stateAnimationState.getAnimating()) {
            StateAnimationState stateAnimationState2 = this.stateAnimationState;
            if ((stateAnimationState2 != null ? stateAnimationState2.getEndState() : null) == newState) {
                return;
            }
        }
        StateAnimationState stateAnimationState3 = this.stateAnimationState;
        if ((stateAnimationState3 == null || !stateAnimationState3.getAnimating()) && this.state == newState) {
            return;
        }
        ValueAnimator valueAnimator = this.stateAnimator;
        if (valueAnimator != null) {
            valueAnimator.cancel();
            valueAnimator.removeAllUpdateListeners();
        }
        if (!animate) {
            e eVar = this.state;
            this.state = newState;
            this.stateAnimationState = null;
            n();
            x(eVar, newState);
            return;
        }
        this.stateAnimationState = new StateAnimationState(true, this.state, newState, this.currentIntensity, 0.0f, this.arcTopPaint.getAlpha() / 255.0f, this.arcBottomPaint.getAlpha() / 255.0f, this.arcLeftPaint.getAlpha() / 255.0f, this.arcRightPaint.getAlpha() / 255.0f, this.arcDialLeftPaint.getAlpha() / 255.0f, this.arcDialRightPaint.getAlpha() / 255.0f, this.arcDialTopPaint.getAlpha() / 255.0f, this.arcDialBottomPaint.getAlpha() / 255.0f);
        ValueAnimator ofFloat = ValueAnimator.ofFloat(0.0f, 1.0f);
        ofFloat.setInterpolator(new LinearInterpolator());
        ofFloat.setStartDelay(0L);
        ofFloat.setRepeatCount(0);
        ofFloat.setDuration(400L);
        ofFloat.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() { // from class: wq.r
            @Override // android.animation.ValueAnimator.AnimatorUpdateListener
            public final void onAnimationUpdate(ValueAnimator valueAnimator2) {
                SelfieOverlayView.F(SelfieOverlayView.this, valueAnimator2);
            }
        });
        Intrinsics.checkNotNull(ofFloat);
        ofFloat.addListener(new j());
        ofFloat.start();
        this.stateAnimator = ofFloat;
    }

    public final void G() {
        float measuredWidth = getMeasuredWidth();
        float measuredHeight = getMeasuredHeight();
        float f10 = measuredWidth / 2.0f;
        float f11 = measuredHeight / 2.0f;
        Path path = this.arcDialHighlightClipPathLeft;
        float f12 = this.arcDialLeftIntensity * 45.0f;
        path.reset();
        path.moveTo(f10, f11);
        path.arcTo(0.0f, 0.0f, measuredWidth, measuredHeight, 180.0f - f12, f12 * 2.0f, false);
        path.close();
        Path path2 = this.arcDialHighlightClipPathRight;
        float f13 = this.arcDialRightIntensity * 45.0f;
        path2.reset();
        path2.moveTo(f10, f11);
        path2.arcTo(0.0f, 0.0f, measuredWidth, measuredHeight, -f13, f13 * 2.0f, false);
        path2.close();
        Path path3 = this.arcDialHighlightClipPathTop;
        float f14 = this.arcDialTopIntensity * 45.0f;
        path3.reset();
        path3.moveTo(f10, f11);
        path3.arcTo(0.0f, 0.0f, measuredWidth, measuredHeight, 270.0f - f14, f14 * 2.0f, false);
        path3.close();
        Path path4 = this.arcDialHighlightClipPathBottom;
        float f15 = this.arcDialBottomIntensity * 45.0f;
        path4.reset();
        path4.moveTo(f10, f11);
        path4.arcTo(0.0f, 0.0f, measuredWidth, measuredHeight, 90.0f - f15, f15 * 2.0f, false);
        path4.close();
    }

    public final void H() {
        int measuredWidth = getMeasuredWidth();
        int measuredHeight = getMeasuredHeight();
        float f10 = this.arcGapDegrees / 2.0f;
        this.arcTop.reset();
        Path path = this.arcTop;
        float f11 = this.arcInset;
        float f12 = measuredWidth;
        float f13 = measuredHeight;
        float f14 = f10 + 225.0f;
        path.addArc(f11, f11, f12 - f11, f13 - f11, f14, 90.0f - this.arcGapDegrees);
        this.arcBottom.reset();
        Path path2 = this.arcBottom;
        float f15 = this.arcInset;
        float f16 = f10 + 45.0f;
        path2.addArc(f15, f15, f12 - f15, f13 - f15, f16, 90.0f - this.arcGapDegrees);
        this.arcLeft.reset();
        Path path3 = this.arcLeft;
        float f17 = this.arcInset;
        float f18 = f10 + 135.0f;
        path3.addArc(f17, f17, f12 - f17, f13 - f17, f18, 90.0f - this.arcGapDegrees);
        this.arcRight.reset();
        Path path4 = this.arcRight;
        float f19 = this.arcInset;
        float f20 = f10 + 315.0f;
        path4.addArc(f19, f19, f12 - f19, f13 - f19, f20, 90.0f - this.arcGapDegrees);
        this.arcDialLeft.reset();
        Path path5 = this.arcDialLeft;
        float f21 = this.arcInset;
        m(path5, f21, f21, f12 - f21, f13 - f21, f18, 90.0f - this.arcGapDegrees, 30, this.arcTickLength);
        this.arcDialRight.reset();
        Path path6 = this.arcDialRight;
        float f22 = this.arcInset;
        m(path6, f22, f22, f12 - f22, f13 - f22, f20, 90.0f - this.arcGapDegrees, 30, this.arcTickLength);
        this.arcDialTop.reset();
        Path path7 = this.arcDialTop;
        float f23 = this.arcInset;
        m(path7, f23, f23, f12 - f23, f13 - f23, f14, 90.0f - this.arcGapDegrees, 30, this.arcTickLength);
        this.arcDialBottom.reset();
        Path path8 = this.arcDialBottom;
        float f24 = this.arcInset;
        m(path8, f24, f24, f12 - f24, f13 - f24, f16, 90.0f - this.arcGapDegrees, 30, this.arcTickLength);
        invalidate();
    }

    public final void m(Path path, float f10, float f11, float f12, float f13, float f14, float f15, int i10, float f16) {
        int i11 = i10;
        float f17 = (f12 - f10) / 2.0f;
        float f18 = f17 + f10;
        float f19 = f17 + f11;
        float f20 = f16 / 2;
        double radians = Math.toRadians(f14);
        double radians2 = Math.toRadians(f15) / (i11 - 1);
        int i12 = 0;
        while (i12 < i11) {
            double cos = Math.cos(radians);
            double sin = Math.sin(radians);
            double d10 = f17 - f20;
            float f21 = f18;
            float f22 = f19;
            float f23 = f20;
            double d11 = f17 + f20;
            path.moveTo(((float) (d10 * cos)) + f21, ((float) (d10 * sin)) + f22);
            path.lineTo(((float) (cos * d11)) + f21, ((float) (d11 * sin)) + f22);
            radians += radians2;
            i12++;
            f20 = f23;
            f17 = f17;
            f18 = f21;
            i11 = i10;
            f19 = f22;
        }
    }

    public final void n() {
        float arcTopAlpha;
        float arcBottomAlpha;
        float arcLeftAlpha;
        float arcRightAlpha;
        float arcDialLeftAlpha;
        float arcDialRightAlpha;
        float arcDialTopAlpha;
        float arcDialBottomAlpha;
        e eVar;
        StateAnimationState stateAnimationState = this.stateAnimationState;
        IntensityAnimationState intensityAnimationState = this.intensityAnimationState;
        if (stateAnimationState != null) {
            float progress = stateAnimationState.getProgress();
            c p8 = p(stateAnimationState.getEndState());
            float startArcTopAlpha = stateAnimationState.getStartArcTopAlpha();
            arcTopAlpha = ((p8.getArcTopAlpha() - startArcTopAlpha) * progress) + startArcTopAlpha;
            float startArcBottomAlpha = stateAnimationState.getStartArcBottomAlpha();
            arcBottomAlpha = ((p8.getArcBottomAlpha() - startArcBottomAlpha) * progress) + startArcBottomAlpha;
            float startArcLeftAlpha = stateAnimationState.getStartArcLeftAlpha();
            arcLeftAlpha = ((p8.getArcLeftAlpha() - startArcLeftAlpha) * progress) + startArcLeftAlpha;
            float startArcRightAlpha = stateAnimationState.getStartArcRightAlpha();
            arcRightAlpha = ((p8.getArcRightAlpha() - startArcRightAlpha) * progress) + startArcRightAlpha;
            float startArcDialLeftAlpha = stateAnimationState.getStartArcDialLeftAlpha();
            arcDialLeftAlpha = ((p8.getArcDialLeftAlpha() - startArcDialLeftAlpha) * progress) + startArcDialLeftAlpha;
            float startArcDialRightAlpha = stateAnimationState.getStartArcDialRightAlpha();
            arcDialRightAlpha = ((p8.getArcDialRightAlpha() - startArcDialRightAlpha) * progress) + startArcDialRightAlpha;
            float startArcDialTopAlpha = stateAnimationState.getStartArcDialTopAlpha();
            arcDialTopAlpha = ((p8.getArcDialTopAlpha() - startArcDialTopAlpha) * progress) + startArcDialTopAlpha;
            float startArcDialBottomAlpha = stateAnimationState.getStartArcDialBottomAlpha();
            arcDialBottomAlpha = ((p8.getArcDialBottomAlpha() - startArcDialBottomAlpha) * progress) + startArcDialBottomAlpha;
        } else {
            arcTopAlpha = p(this.state).getArcTopAlpha();
            arcBottomAlpha = p(this.state).getArcBottomAlpha();
            arcLeftAlpha = p(this.state).getArcLeftAlpha();
            arcRightAlpha = p(this.state).getArcRightAlpha();
            arcDialLeftAlpha = p(this.state).getArcDialLeftAlpha();
            arcDialRightAlpha = p(this.state).getArcDialRightAlpha();
            arcDialTopAlpha = p(this.state).getArcDialTopAlpha();
            arcDialBottomAlpha = p(this.state).getArcDialBottomAlpha();
        }
        e startState = stateAnimationState != null ? stateAnimationState.getStartState() : null;
        if (stateAnimationState == null || (eVar = stateAnimationState.getEndState()) == null) {
            eVar = this.state;
        }
        float endIntensity = intensityAnimationState != null ? ((intensityAnimationState.getEndIntensity() - intensityAnimationState.getStartIntensity()) * intensityAnimationState.getProgress()) + intensityAnimationState.getStartIntensity() : this.currentIntensity;
        this.currentIntensity = endIntensity;
        e eVar2 = e.f11070a;
        float startIntensity = eVar == eVar2 ? endIntensity : startState == eVar2 ? stateAnimationState.getStartIntensity() : 0.0f;
        e eVar3 = e.b;
        float f10 = eVar == eVar3 ? endIntensity : 0.0f;
        e eVar4 = e.f11071c;
        float f11 = eVar == eVar4 ? endIntensity : 0.0f;
        e eVar5 = e.f11072d;
        float f12 = eVar == eVar5 ? endIntensity : 0.0f;
        float f13 = startIntensity;
        e eVar6 = e.f11073e;
        if (eVar != eVar6) {
            endIntensity = 0.0f;
        }
        float f14 = ((arcTopAlpha - 0.1f) / 1.0f) * f13;
        float f15 = arcDialBottomAlpha;
        float f16 = ((arcBottomAlpha - 0.1f) / 1.0f) * f13;
        float f17 = arcTopAlpha;
        float f18 = ((arcLeftAlpha - 0.1f) / 1.0f) * f13;
        float f19 = arcBottomAlpha;
        float f20 = ((arcRightAlpha - 0.1f) / 1.0f) * f13;
        float f21 = ((arcDialLeftAlpha - 0.1f) / 1.0f) * f10;
        float f22 = ((arcDialRightAlpha - 0.1f) / 1.0f) * f11;
        float f23 = ((arcDialTopAlpha - 0.1f) / 1.0f) * f12;
        float f24 = ((f15 - 0.1f) / 1.0f) * endIntensity;
        float f25 = arcLeftAlpha;
        float f26 = arcRightAlpha;
        this.arcTopPaint.setColor(androidx.core.graphics.c.c(this.arcBaseColor, this.arcHighlightColor, f14));
        this.arcBottomPaint.setColor(androidx.core.graphics.c.c(this.arcBaseColor, this.arcHighlightColor, f16));
        this.arcLeftPaint.setColor(androidx.core.graphics.c.c(this.arcBaseColor, this.arcHighlightColor, f18));
        this.arcRightPaint.setColor(androidx.core.graphics.c.c(this.arcBaseColor, this.arcHighlightColor, f20));
        if (startState == eVar5) {
            f23 = stateAnimationState.getStartIntensity();
        } else if (startState == eVar6) {
            f24 = stateAnimationState.getStartIntensity();
        } else if (startState == eVar3) {
            f21 = stateAnimationState.getStartIntensity();
        } else if (startState == eVar4) {
            f22 = stateAnimationState.getStartIntensity();
        }
        float f27 = f22;
        float f28 = f21;
        float f29 = f23;
        float f30 = f24;
        boolean z10 = (this.arcDialLeftIntensity == f28 && this.arcDialRightIntensity == f27 && this.arcDialTopIntensity == f29 && this.arcDialBottomIntensity == f30) ? false : true;
        this.arcDialLeftIntensity = f28;
        this.arcDialRightIntensity = f27;
        this.arcDialTopIntensity = f29;
        this.arcDialBottomIntensity = f30;
        float f31 = 255;
        this.arcTopPaint.setAlpha((int) (f17 * f31));
        this.arcBottomPaint.setAlpha((int) (f19 * f31));
        this.arcLeftPaint.setAlpha((int) (f25 * f31));
        this.arcRightPaint.setAlpha((int) (f26 * f31));
        this.arcDialLeftPaint.setAlpha((int) (arcDialLeftAlpha * f31));
        this.arcDialRightPaint.setAlpha((int) (arcDialRightAlpha * f31));
        this.arcDialTopPaint.setAlpha((int) (arcDialTopAlpha * f31));
        this.arcDialBottomPaint.setAlpha((int) (f15 * f31));
        this.arcTopPaint.setStrokeWidth(this.arcStrokeWidth * this.arcHoverState.getArcThicknessMultiplier());
        this.arcBottomPaint.setStrokeWidth(this.arcStrokeWidth * this.arcHoverState.getArcThicknessMultiplier());
        this.arcLeftPaint.setStrokeWidth(this.arcStrokeWidth * this.arcHoverState.getArcThicknessMultiplier());
        this.arcRightPaint.setStrokeWidth(this.arcStrokeWidth * this.arcHoverState.getArcThicknessMultiplier());
        if (z10) {
            G();
        }
        invalidate();
    }

    public final ArcHoverState o(ArcHoverState arcHoverState, float f10) {
        float c10 = (float) xq.j.c(48.0d);
        arcHoverState.s(0.0f);
        float f11 = c10 * f10;
        arcHoverState.t(f11);
        arcHoverState.l(0.0f);
        float f12 = (-c10) * f10;
        arcHoverState.m(f12);
        arcHoverState.n(f11);
        arcHoverState.o(0.0f);
        arcHoverState.p(f12);
        arcHoverState.q(0.0f);
        arcHoverState.r(f10 + 1.0f);
        return arcHoverState;
    }

    @Override // android.view.ViewGroup, android.view.View
    public void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        ValueAnimator valueAnimator = this.stateAnimator;
        if (valueAnimator != null) {
            valueAnimator.cancel();
        }
        ValueAnimator valueAnimator2 = this.intensityAnimator;
        if (valueAnimator2 != null) {
            valueAnimator2.cancel();
        }
        ValueAnimator valueAnimator3 = this.directionHintAnimator;
        if (valueAnimator3 != null) {
            valueAnimator3.cancel();
        }
    }

    @Override // android.view.View
    public void onDraw(@NotNull Canvas canvas) {
        int save;
        Intrinsics.checkNotNullParameter(canvas, "canvas");
        super.onDraw(canvas);
        if (this.arcDialTopPaint.getAlpha() > 0) {
            save = canvas.save();
            try {
                canvas.translate(this.arcHoverState.getArcTopTranslateX(), this.arcHoverState.getArcTopTranslateY());
                if (this.brightnessInfo.i() > 0.5f) {
                    C(this.shadowPaint, (int) (this.arcDialTopPaint.getAlpha() * (((this.brightnessInfo.i() - 0.5f) * 0.66f) + 0.0f)));
                    canvas.drawPath(this.arcDialTop, this.shadowPaint);
                }
                canvas.drawPath(this.arcDialTop, this.arcDialTopPaint);
                canvas.clipPath(this.arcDialHighlightClipPathTop);
                canvas.drawPath(this.arcDialTop, this.filledArcDialPaint);
                canvas.restoreToCount(save);
            } finally {
            }
        }
        if (this.arcTopPaint.getAlpha() > 0) {
            float arcTopTranslateX = this.arcHoverState.getArcTopTranslateX();
            float arcTopTranslateY = this.arcHoverState.getArcTopTranslateY();
            int save2 = canvas.save();
            canvas.translate(arcTopTranslateX, arcTopTranslateY);
            try {
                if (this.brightnessInfo.i() > 0.5f) {
                    C(this.shadowPaint, (int) (this.arcTopPaint.getAlpha() * (((this.brightnessInfo.i() - 0.5f) * 0.66f) + 0.0f)));
                    canvas.drawPath(this.arcTop, this.shadowPaint);
                }
                canvas.drawPath(this.arcTop, this.arcTopPaint);
                canvas.restoreToCount(save2);
            } finally {
            }
        }
        if (this.arcDialBottomPaint.getAlpha() > 0) {
            int save3 = canvas.save();
            try {
                canvas.translate(this.arcHoverState.getArcBottomTranslateX(), this.arcHoverState.getArcBottomTranslateY());
                if (this.brightnessInfo.a() > 0.5f) {
                    C(this.shadowPaint, (int) (this.arcDialBottomPaint.getAlpha() * (((this.brightnessInfo.a() - 0.5f) * 0.66f) + 0.0f)));
                    canvas.drawPath(this.arcDialBottom, this.shadowPaint);
                }
                canvas.drawPath(this.arcDialBottom, this.arcDialBottomPaint);
                canvas.clipPath(this.arcDialHighlightClipPathBottom);
                canvas.drawPath(this.arcDialBottom, this.filledArcDialPaint);
                canvas.restoreToCount(save3);
            } finally {
                canvas.restoreToCount(save3);
            }
        }
        if (this.arcBottomPaint.getAlpha() > 0) {
            float arcBottomTranslateX = this.arcHoverState.getArcBottomTranslateX();
            float arcBottomTranslateY = this.arcHoverState.getArcBottomTranslateY();
            int save4 = canvas.save();
            canvas.translate(arcBottomTranslateX, arcBottomTranslateY);
            try {
                if (this.brightnessInfo.a() > 0.5f) {
                    C(this.shadowPaint, (int) (this.arcBottomPaint.getAlpha() * (((this.brightnessInfo.a() - 0.5f) * 0.66f) + 0.0f)));
                    canvas.drawPath(this.arcBottom, this.shadowPaint);
                }
                canvas.drawPath(this.arcBottom, this.arcBottomPaint);
                canvas.restoreToCount(save4);
            } finally {
                canvas.restoreToCount(save4);
            }
        }
        float g10 = this.isPreviewMirrored ? this.brightnessInfo.g() : this.brightnessInfo.f();
        float f10 = this.isPreviewMirrored ? this.brightnessInfo.f() : this.brightnessInfo.g();
        if (this.arcDialLeftPaint.getAlpha() > 0) {
            int save5 = canvas.save();
            try {
                canvas.translate(this.arcHoverState.getArcLeftTranslateX(), this.arcHoverState.getArcLeftTranslateY());
                if (g10 > 0.5f) {
                    C(this.shadowPaint, (int) (this.arcDialLeftPaint.getAlpha() * (((g10 - 0.5f) * 0.66f) + 0.0f)));
                    canvas.drawPath(this.arcDialLeft, this.shadowPaint);
                }
                canvas.drawPath(this.arcDialLeft, this.arcDialLeftPaint);
                canvas.clipPath(this.arcDialHighlightClipPathLeft);
                canvas.drawPath(this.arcDialLeft, this.filledArcDialPaint);
                canvas.restoreToCount(save5);
            } finally {
                canvas.restoreToCount(save5);
            }
        }
        if (this.arcLeftPaint.getAlpha() > 0) {
            float arcLeftTranslateX = this.arcHoverState.getArcLeftTranslateX();
            float arcLeftTranslateY = this.arcHoverState.getArcLeftTranslateY();
            save = canvas.save();
            canvas.translate(arcLeftTranslateX, arcLeftTranslateY);
            if (g10 > 0.5f) {
                try {
                    C(this.shadowPaint, (int) (this.arcLeftPaint.getAlpha() * (((g10 - 0.5f) * 0.66f) + 0.0f)));
                    canvas.drawPath(this.arcLeft, this.shadowPaint);
                } finally {
                    canvas.restoreToCount(save);
                }
            }
            canvas.drawPath(this.arcLeft, this.arcLeftPaint);
            canvas.restoreToCount(save);
        }
        if (this.arcDialRightPaint.getAlpha() > 0) {
            int save6 = canvas.save();
            try {
                canvas.translate(this.arcHoverState.getArcRightTranslateX(), this.arcHoverState.getArcRightTranslateY());
                if (f10 > 0.5f) {
                    C(this.shadowPaint, (int) (this.arcDialRightPaint.getAlpha() * (((f10 - 0.5f) * 0.66f) + 0.0f)));
                    canvas.drawPath(this.arcDialRight, this.shadowPaint);
                }
                canvas.drawPath(this.arcDialRight, this.arcDialRightPaint);
                canvas.clipPath(this.arcDialHighlightClipPathRight);
                canvas.drawPath(this.arcDialRight, this.filledArcDialPaint);
                canvas.restoreToCount(save6);
            } finally {
                canvas.restoreToCount(save6);
            }
        }
        if (this.arcRightPaint.getAlpha() > 0) {
            float arcRightTranslateX = this.arcHoverState.getArcRightTranslateX();
            float arcRightTranslateY = this.arcHoverState.getArcRightTranslateY();
            int save7 = canvas.save();
            canvas.translate(arcRightTranslateX, arcRightTranslateY);
            if (f10 > 0.5f) {
                try {
                    C(this.shadowPaint, (int) (this.arcRightPaint.getAlpha() * ((0.66f * (f10 - 0.5f)) + 0.0f)));
                    canvas.drawPath(this.arcRight, this.shadowPaint);
                } finally {
                    canvas.restoreToCount(save7);
                }
            }
            canvas.drawPath(this.arcRight, this.arcRightPaint);
            canvas.restoreToCount(save7);
        }
    }

    @Override // android.view.View
    public void onSizeChanged(int w5, int h10, int oldw, int oldh) {
        super.onSizeChanged(w5, h10, oldw, oldh);
        H();
    }

    public final c p(e eVar) {
        switch (g.f11090a[eVar.ordinal()]) {
            case 1:
                return c.f11052i;
            case 2:
                return c.f11053j;
            case 3:
                return c.f11054k;
            case 4:
                return c.f11055l;
            case 5:
                return c.f11056m;
            case 6:
                return c.f11057n;
            case 7:
                return c.f11058o;
            default:
                throw new l();
        }
    }

    public final void q(ArcHoverState arcHoverState, ArcHoverState arcHoverState2, ArcHoverState arcHoverState3, float f10) {
        float arcTopTranslateX = arcHoverState2.getArcTopTranslateX();
        arcHoverState.s(((arcHoverState3.getArcTopTranslateX() - arcTopTranslateX) * f10) + arcTopTranslateX);
        float arcTopTranslateY = arcHoverState2.getArcTopTranslateY();
        arcHoverState.t(((arcHoverState3.getArcTopTranslateY() - arcTopTranslateY) * f10) + arcTopTranslateY);
        float arcBottomTranslateX = arcHoverState2.getArcBottomTranslateX();
        arcHoverState.l(((arcHoverState3.getArcBottomTranslateX() - arcBottomTranslateX) * f10) + arcBottomTranslateX);
        float arcBottomTranslateY = arcHoverState2.getArcBottomTranslateY();
        arcHoverState.m(((arcHoverState3.getArcBottomTranslateY() - arcBottomTranslateY) * f10) + arcBottomTranslateY);
        float arcLeftTranslateX = arcHoverState2.getArcLeftTranslateX();
        arcHoverState.n(((arcHoverState3.getArcLeftTranslateX() - arcLeftTranslateX) * f10) + arcLeftTranslateX);
        float arcLeftTranslateY = arcHoverState2.getArcLeftTranslateY();
        arcHoverState.o(((arcHoverState3.getArcLeftTranslateY() - arcLeftTranslateY) * f10) + arcLeftTranslateY);
        float arcRightTranslateX = arcHoverState2.getArcRightTranslateX();
        arcHoverState.p(((arcHoverState3.getArcRightTranslateX() - arcRightTranslateX) * f10) + arcRightTranslateX);
        float arcRightTranslateY = arcHoverState2.getArcRightTranslateY();
        arcHoverState.q(((arcHoverState3.getArcRightTranslateY() - arcRightTranslateY) * f10) + arcRightTranslateY);
        float arcThicknessMultiplier = arcHoverState2.getArcThicknessMultiplier();
        arcHoverState.r(((arcHoverState3.getArcThicknessMultiplier() - arcThicknessMultiplier) * f10) + arcThicknessMultiplier);
    }

    public final boolean r(ArcHoverState arcHoverState) {
        return arcHoverState.getArcTopTranslateX() == 0.0f && arcHoverState.getArcTopTranslateY() == 0.0f && arcHoverState.getArcBottomTranslateX() == 0.0f && arcHoverState.getArcBottomTranslateY() == 0.0f && arcHoverState.getArcLeftTranslateX() == 0.0f && arcHoverState.getArcLeftTranslateY() == 0.0f && arcHoverState.getArcRightTranslateX() == 0.0f && arcHoverState.getArcRightTranslateY() == 0.0f && arcHoverState.getArcThicknessMultiplier() == 1.0f;
    }

    public final Paint s() {
        Paint t8 = t();
        t8.setStrokeWidth(this.arcDialStrokeWidth);
        return t8;
    }

    public final void setCameraStreamBrightnessInfo(@Nullable xn.b brightnessInfo) {
        if (brightnessInfo == null) {
            brightnessInfo = new xn.b(null, 1, null);
        }
        this.brightnessInfo = brightnessInfo;
        invalidate();
    }

    public final void setIntensity(float intensity) {
        if (this.currentIntensity == intensity) {
            return;
        }
        float i10 = d.i(intensity, 0.0f, 1.0f);
        ValueAnimator valueAnimator = this.intensityAnimator;
        if (valueAnimator != null) {
            valueAnimator.cancel();
            valueAnimator.removeAllUpdateListeners();
        }
        this.intensityAnimationState = new IntensityAnimationState(0.0f, this.currentIntensity, i10);
        ValueAnimator ofFloat = ValueAnimator.ofFloat(0.0f, 1.0f);
        ofFloat.setInterpolator(new LinearInterpolator());
        ofFloat.setStartDelay(0L);
        ofFloat.setRepeatCount(0);
        ofFloat.setDuration(200L);
        if (this.state == e.f11070a) {
            final ArcHoverState b = ArcHoverState.b(this.arcHoverState, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 511, null);
            final ArcHoverState o10 = o(new ArcHoverState(0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 511, null), i10);
            ofFloat.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() { // from class: wq.p
                @Override // android.animation.ValueAnimator.AnimatorUpdateListener
                public final void onAnimationUpdate(ValueAnimator valueAnimator2) {
                    SelfieOverlayView.A(SelfieOverlayView.this, b, o10, valueAnimator2);
                }
            });
        } else {
            ofFloat.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() { // from class: wq.q
                @Override // android.animation.ValueAnimator.AnimatorUpdateListener
                public final void onAnimationUpdate(ValueAnimator valueAnimator2) {
                    SelfieOverlayView.B(SelfieOverlayView.this, valueAnimator2);
                }
            });
        }
        Intrinsics.checkNotNull(ofFloat);
        ofFloat.addListener(new i());
        ofFloat.start();
        this.intensityAnimator = ofFloat;
    }

    public final void setIsPreviewMirrored(boolean mirrored) {
        if (this.isPreviewMirrored == mirrored) {
            return;
        }
        this.isPreviewMirrored = mirrored;
        invalidate();
    }

    public final Paint t() {
        Paint paint = new Paint();
        paint.setAntiAlias(true);
        paint.setColor(this.colorOnSurface);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(this.arcStrokeWidth);
        paint.setStrokeCap(Paint.Cap.ROUND);
        return paint;
    }

    public final ValueAnimator u(final ArcHoverState startState, final ArcHoverState endState) {
        ValueAnimator ofFloat = ValueAnimator.ofFloat(0.0f, 1.0f);
        ofFloat.setInterpolator(new AccelerateDecelerateInterpolator());
        ofFloat.setRepeatMode(2);
        ofFloat.setStartDelay(0L);
        ofFloat.setRepeatCount(-1);
        ofFloat.setDuration(700L);
        ofFloat.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() { // from class: wq.t
            @Override // android.animation.ValueAnimator.AnimatorUpdateListener
            public final void onAnimationUpdate(ValueAnimator valueAnimator) {
                SelfieOverlayView.v(SelfieOverlayView.this, startState, endState, valueAnimator);
            }
        });
        return ofFloat;
    }

    public final Paint w() {
        Paint t8 = t();
        t8.setStrokeWidth(this.arcStrokeWidth);
        t8.setColor(this.shadowColor);
        t8.setShadowLayer(this.arcStrokeWidth * 2, 0.0f, 0.0f, this.shadowColor);
        return t8;
    }

    public final void x(e oldState, e newState) {
        if (oldState == newState) {
            return;
        }
        ValueAnimator valueAnimator = this.directionHintAnimator;
        if (valueAnimator != null) {
            valueAnimator.cancel();
            valueAnimator.removeAllUpdateListeners();
        }
        if (r(this.arcHoverState)) {
            z(newState, this);
            return;
        }
        ValueAnimator ofFloat = ValueAnimator.ofFloat(0.0f, 1.0f);
        ofFloat.setInterpolator(new LinearInterpolator());
        ofFloat.setStartDelay(0L);
        ofFloat.setRepeatCount(0);
        ofFloat.setDuration(250L);
        final ArcHoverState b = ArcHoverState.b(this.arcHoverState, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 511, null);
        final ArcHoverState arcHoverState = new ArcHoverState(0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 511, null);
        y yVar = new y();
        ofFloat.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() { // from class: wq.s
            @Override // android.animation.ValueAnimator.AnimatorUpdateListener
            public final void onAnimationUpdate(ValueAnimator valueAnimator2) {
                SelfieOverlayView.y(SelfieOverlayView.this, b, arcHoverState, valueAnimator2);
            }
        });
        Intrinsics.checkNotNull(ofFloat);
        ofFloat.addListener(new h(yVar, newState, this, yVar));
        ofFloat.start();
        this.directionHintAnimator = ofFloat;
    }

    @Metadata(d1 = {"\u0000(\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\u0010\u0007\n\u0002\b\r\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0003\n\u0002\u0010\u000b\n\u0002\b\u0019\b\u0082\b\u0018\u00002\u00020\u0001Ba\u0012\b\b\u0002\u0010\u0003\u001a\u00020\u0002\u0012\b\b\u0002\u0010\u0004\u001a\u00020\u0002\u0012\b\b\u0002\u0010\u0005\u001a\u00020\u0002\u0012\b\b\u0002\u0010\u0006\u001a\u00020\u0002\u0012\b\b\u0002\u0010\u0007\u001a\u00020\u0002\u0012\b\b\u0002\u0010\b\u001a\u00020\u0002\u0012\b\b\u0002\u0010\t\u001a\u00020\u0002\u0012\b\b\u0002\u0010\n\u001a\u00020\u0002\u0012\b\b\u0002\u0010\u000b\u001a\u00020\u0002¢\u0006\u0004\b\f\u0010\rJj\u0010\u000e\u001a\u00020\u00002\b\b\u0002\u0010\u0003\u001a\u00020\u00022\b\b\u0002\u0010\u0004\u001a\u00020\u00022\b\b\u0002\u0010\u0005\u001a\u00020\u00022\b\b\u0002\u0010\u0006\u001a\u00020\u00022\b\b\u0002\u0010\u0007\u001a\u00020\u00022\b\b\u0002\u0010\b\u001a\u00020\u00022\b\b\u0002\u0010\t\u001a\u00020\u00022\b\b\u0002\u0010\n\u001a\u00020\u00022\b\b\u0002\u0010\u000b\u001a\u00020\u0002HÆ\u0001¢\u0006\u0004\b\u000e\u0010\u000fJ\u0010\u0010\u0011\u001a\u00020\u0010HÖ\u0001¢\u0006\u0004\b\u0011\u0010\u0012J\u0010\u0010\u0014\u001a\u00020\u0013HÖ\u0001¢\u0006\u0004\b\u0014\u0010\u0015J\u001a\u0010\u0018\u001a\u00020\u00172\b\u0010\u0016\u001a\u0004\u0018\u00010\u0001HÖ\u0003¢\u0006\u0004\b\u0018\u0010\u0019R\"\u0010\u0003\u001a\u00020\u00028\u0006@\u0006X\u0086\u000e¢\u0006\u0012\n\u0004\b\u000e\u0010\u001a\u001a\u0004\b\u001b\u0010\u001c\"\u0004\b\u001d\u0010\u001eR\"\u0010\u0004\u001a\u00020\u00028\u0006@\u0006X\u0086\u000e¢\u0006\u0012\n\u0004\b\u001f\u0010\u001a\u001a\u0004\b \u0010\u001c\"\u0004\b!\u0010\u001eR\"\u0010\u0005\u001a\u00020\u00028\u0006@\u0006X\u0086\u000e¢\u0006\u0012\n\u0004\b\"\u0010\u001a\u001a\u0004\b\"\u0010\u001c\"\u0004\b#\u0010\u001eR\"\u0010\u0006\u001a\u00020\u00028\u0006@\u0006X\u0086\u000e¢\u0006\u0012\n\u0004\b$\u0010\u001a\u001a\u0004\b$\u0010\u001c\"\u0004\b%\u0010\u001eR\"\u0010\u0007\u001a\u00020\u00028\u0006@\u0006X\u0086\u000e¢\u0006\u0012\n\u0004\b&\u0010\u001a\u001a\u0004\b&\u0010\u001c\"\u0004\b'\u0010\u001eR\"\u0010\b\u001a\u00020\u00028\u0006@\u0006X\u0086\u000e¢\u0006\u0012\n\u0004\b(\u0010\u001a\u001a\u0004\b(\u0010\u001c\"\u0004\b)\u0010\u001eR\"\u0010\t\u001a\u00020\u00028\u0006@\u0006X\u0086\u000e¢\u0006\u0012\n\u0004\b*\u0010\u001a\u001a\u0004\b*\u0010\u001c\"\u0004\b+\u0010\u001eR\"\u0010\n\u001a\u00020\u00028\u0006@\u0006X\u0086\u000e¢\u0006\u0012\n\u0004\b,\u0010\u001a\u001a\u0004\b,\u0010\u001c\"\u0004\b-\u0010\u001eR\"\u0010\u000b\u001a\u00020\u00028\u0006@\u0006X\u0086\u000e¢\u0006\u0012\n\u0004\b.\u0010\u001a\u001a\u0004\b.\u0010\u001c\"\u0004\b/\u0010\u001e¨\u00060"}, d2 = {"Lcom/withpersona/sdk2/inquiry/selfie/view/SelfieOverlayView$a;", BuildConfig.FLAVOR, BuildConfig.FLAVOR, "arcTopTranslateX", "arcTopTranslateY", "arcBottomTranslateX", "arcBottomTranslateY", "arcLeftTranslateX", "arcLeftTranslateY", "arcRightTranslateX", "arcRightTranslateY", "arcThicknessMultiplier", "<init>", "(FFFFFFFFF)V", a.f36648e, "(FFFFFFFFF)Lcom/withpersona/sdk2/inquiry/selfie/view/SelfieOverlayView$a;", BuildConfig.FLAVOR, "toString", "()Ljava/lang/String;", BuildConfig.FLAVOR, "hashCode", "()I", "other", BuildConfig.FLAVOR, "equals", "(Ljava/lang/Object;)Z", "F", "j", "()F", "s", "(F)V", b.f21144e, "k", t.f29212d, "c", "l", "d", "m", "e", "n", "f", "o", "g", "p", "h", "q", "i", "r", "selfie_release"}, k = 1, mv = {2, 2, 0}, xi = 48)
    /* renamed from: com.withpersona.sdk2.inquiry.selfie.view.SelfieOverlayView$a, reason: from toString */
    public static final /* data */ class ArcHoverState {

        /* renamed from: a, reason: collision with root package name and from kotlin metadata and from toString */
        public float arcTopTranslateX;

        /* renamed from: b, reason: from kotlin metadata and from toString */
        public float arcTopTranslateY;

        /* renamed from: c, reason: collision with root package name and from kotlin metadata and from toString */
        public float arcBottomTranslateX;

        /* renamed from: d, reason: collision with root package name and from kotlin metadata and from toString */
        public float arcBottomTranslateY;

        /* renamed from: e, reason: collision with root package name and from kotlin metadata and from toString */
        public float arcLeftTranslateX;

        /* renamed from: f, reason: collision with root package name and from kotlin metadata and from toString */
        public float arcLeftTranslateY;

        /* renamed from: g, reason: collision with root package name and from kotlin metadata and from toString */
        public float arcRightTranslateX;

        /* renamed from: h, reason: collision with root package name and from kotlin metadata and from toString */
        public float arcRightTranslateY;

        /* renamed from: i, reason: collision with root package name and from kotlin metadata and from toString */
        public float arcThicknessMultiplier;

        public ArcHoverState(float f10, float f11, float f12, float f13, float f14, float f15, float f16, float f17, float f18) {
            this.arcTopTranslateX = f10;
            this.arcTopTranslateY = f11;
            this.arcBottomTranslateX = f12;
            this.arcBottomTranslateY = f13;
            this.arcLeftTranslateX = f14;
            this.arcLeftTranslateY = f15;
            this.arcRightTranslateX = f16;
            this.arcRightTranslateY = f17;
            this.arcThicknessMultiplier = f18;
        }

        public static /* synthetic */ ArcHoverState b(ArcHoverState arcHoverState, float f10, float f11, float f12, float f13, float f14, float f15, float f16, float f17, float f18, int i10, Object obj) {
            if ((i10 & 1) != 0) {
                f10 = arcHoverState.arcTopTranslateX;
            }
            if ((i10 & 2) != 0) {
                f11 = arcHoverState.arcTopTranslateY;
            }
            if ((i10 & 4) != 0) {
                f12 = arcHoverState.arcBottomTranslateX;
            }
            if ((i10 & 8) != 0) {
                f13 = arcHoverState.arcBottomTranslateY;
            }
            if ((i10 & 16) != 0) {
                f14 = arcHoverState.arcLeftTranslateX;
            }
            if ((i10 & 32) != 0) {
                f15 = arcHoverState.arcLeftTranslateY;
            }
            if ((i10 & 64) != 0) {
                f16 = arcHoverState.arcRightTranslateX;
            }
            if ((i10 & Barcode.FORMAT_ITF) != 0) {
                f17 = arcHoverState.arcRightTranslateY;
            }
            if ((i10 & Barcode.FORMAT_QR_CODE) != 0) {
                f18 = arcHoverState.arcThicknessMultiplier;
            }
            float f19 = f17;
            float f20 = f18;
            float f21 = f15;
            float f22 = f16;
            float f23 = f14;
            float f24 = f12;
            return arcHoverState.a(f10, f11, f24, f13, f23, f21, f22, f19, f20);
        }

        @NotNull
        public final ArcHoverState a(float arcTopTranslateX, float arcTopTranslateY, float arcBottomTranslateX, float arcBottomTranslateY, float arcLeftTranslateX, float arcLeftTranslateY, float arcRightTranslateX, float arcRightTranslateY, float arcThicknessMultiplier) {
            return new ArcHoverState(arcTopTranslateX, arcTopTranslateY, arcBottomTranslateX, arcBottomTranslateY, arcLeftTranslateX, arcLeftTranslateY, arcRightTranslateX, arcRightTranslateY, arcThicknessMultiplier);
        }

        /* renamed from: c, reason: from getter */
        public final float getArcBottomTranslateX() {
            return this.arcBottomTranslateX;
        }

        /* renamed from: d, reason: from getter */
        public final float getArcBottomTranslateY() {
            return this.arcBottomTranslateY;
        }

        /* renamed from: e, reason: from getter */
        public final float getArcLeftTranslateX() {
            return this.arcLeftTranslateX;
        }

        public boolean equals(@Nullable Object other) {
            if (this == other) {
                return true;
            }
            if (!(other instanceof ArcHoverState)) {
                return false;
            }
            ArcHoverState arcHoverState = (ArcHoverState) other;
            return Float.compare(this.arcTopTranslateX, arcHoverState.arcTopTranslateX) == 0 && Float.compare(this.arcTopTranslateY, arcHoverState.arcTopTranslateY) == 0 && Float.compare(this.arcBottomTranslateX, arcHoverState.arcBottomTranslateX) == 0 && Float.compare(this.arcBottomTranslateY, arcHoverState.arcBottomTranslateY) == 0 && Float.compare(this.arcLeftTranslateX, arcHoverState.arcLeftTranslateX) == 0 && Float.compare(this.arcLeftTranslateY, arcHoverState.arcLeftTranslateY) == 0 && Float.compare(this.arcRightTranslateX, arcHoverState.arcRightTranslateX) == 0 && Float.compare(this.arcRightTranslateY, arcHoverState.arcRightTranslateY) == 0 && Float.compare(this.arcThicknessMultiplier, arcHoverState.arcThicknessMultiplier) == 0;
        }

        /* renamed from: f, reason: from getter */
        public final float getArcLeftTranslateY() {
            return this.arcLeftTranslateY;
        }

        /* renamed from: g, reason: from getter */
        public final float getArcRightTranslateX() {
            return this.arcRightTranslateX;
        }

        /* renamed from: h, reason: from getter */
        public final float getArcRightTranslateY() {
            return this.arcRightTranslateY;
        }

        public int hashCode() {
            return (((((((((((((((Float.hashCode(this.arcTopTranslateX) * 31) + Float.hashCode(this.arcTopTranslateY)) * 31) + Float.hashCode(this.arcBottomTranslateX)) * 31) + Float.hashCode(this.arcBottomTranslateY)) * 31) + Float.hashCode(this.arcLeftTranslateX)) * 31) + Float.hashCode(this.arcLeftTranslateY)) * 31) + Float.hashCode(this.arcRightTranslateX)) * 31) + Float.hashCode(this.arcRightTranslateY)) * 31) + Float.hashCode(this.arcThicknessMultiplier);
        }

        /* renamed from: i, reason: from getter */
        public final float getArcThicknessMultiplier() {
            return this.arcThicknessMultiplier;
        }

        /* renamed from: j, reason: from getter */
        public final float getArcTopTranslateX() {
            return this.arcTopTranslateX;
        }

        /* renamed from: k, reason: from getter */
        public final float getArcTopTranslateY() {
            return this.arcTopTranslateY;
        }

        public final void l(float f10) {
            this.arcBottomTranslateX = f10;
        }

        public final void m(float f10) {
            this.arcBottomTranslateY = f10;
        }

        public final void n(float f10) {
            this.arcLeftTranslateX = f10;
        }

        public final void o(float f10) {
            this.arcLeftTranslateY = f10;
        }

        public final void p(float f10) {
            this.arcRightTranslateX = f10;
        }

        public final void q(float f10) {
            this.arcRightTranslateY = f10;
        }

        public final void r(float f10) {
            this.arcThicknessMultiplier = f10;
        }

        public final void s(float f10) {
            this.arcTopTranslateX = f10;
        }

        public final void t(float f10) {
            this.arcTopTranslateY = f10;
        }

        @NotNull
        public String toString() {
            return "ArcHoverState(arcTopTranslateX=" + this.arcTopTranslateX + ", arcTopTranslateY=" + this.arcTopTranslateY + ", arcBottomTranslateX=" + this.arcBottomTranslateX + ", arcBottomTranslateY=" + this.arcBottomTranslateY + ", arcLeftTranslateX=" + this.arcLeftTranslateX + ", arcLeftTranslateY=" + this.arcLeftTranslateY + ", arcRightTranslateX=" + this.arcRightTranslateX + ", arcRightTranslateY=" + this.arcRightTranslateY + ", arcThicknessMultiplier=" + this.arcThicknessMultiplier + ")";
        }

        public /* synthetic */ ArcHoverState(float f10, float f11, float f12, float f13, float f14, float f15, float f16, float f17, float f18, int i10, DefaultConstructorMarker defaultConstructorMarker) {
            this((i10 & 1) != 0 ? 0.0f : f10, (i10 & 2) != 0 ? 0.0f : f11, (i10 & 4) != 0 ? 0.0f : f12, (i10 & 8) != 0 ? 0.0f : f13, (i10 & 16) != 0 ? 0.0f : f14, (i10 & 32) != 0 ? 0.0f : f15, (i10 & 64) != 0 ? 0.0f : f16, (i10 & Barcode.FORMAT_ITF) != 0 ? 0.0f : f17, (i10 & Barcode.FORMAT_QR_CODE) != 0 ? 1.0f : f18);
        }
    }


    // --- восстановлено из DEX (com/withpersona/sdk2/inquiry/selfie/view/SelfieOverlayView$a) ---
    public static class a {
        float a;
        float b;
        float c;
        float d;
        float e;
        float f;
        float g;
        float h;
        float i;
        public a(float p0, float p1, float p2, float p3, float p4, float p5, float p6, float p7, float p8) { }
        public a(float p0, float p1, float p2, float p3, float p4, float p5, float p6, float p7, float p8, int p9, kotlin.jvm.internal.DefaultConstructorMarker p10) { }
        public com.withpersona.sdk2.inquiry.selfie.view.SelfieOverlayView.a a(float p0, float p1, float p2, float p3, float p4, float p5, float p6, float p7, float p8) { throw new UnsupportedOperationException("stub"); }
        public com.withpersona.sdk2.inquiry.selfie.view.SelfieOverlayView.a b(com.withpersona.sdk2.inquiry.selfie.view.SelfieOverlayView.a p0, float p1, float p2, float p3, float p4, float p5, float p6, float p7, float p8, float p9, int p10, java.lang.Object p11) { throw new UnsupportedOperationException("stub"); }
        public float c() { throw new UnsupportedOperationException("stub"); }
        public float d() { throw new UnsupportedOperationException("stub"); }
        public float e() { throw new UnsupportedOperationException("stub"); }
        public boolean equals(java.lang.Object p0) { throw new UnsupportedOperationException("stub"); }
        public float f() { throw new UnsupportedOperationException("stub"); }
        public float g() { throw new UnsupportedOperationException("stub"); }
        public float h() { throw new UnsupportedOperationException("stub"); }
        public int hashCode() { throw new UnsupportedOperationException("stub"); }
        public float i() { throw new UnsupportedOperationException("stub"); }
        public float j() { throw new UnsupportedOperationException("stub"); }
        public float k() { throw new UnsupportedOperationException("stub"); }
        public void l(float p0) { throw new UnsupportedOperationException("stub"); }
        public void m(float p0) { throw new UnsupportedOperationException("stub"); }
        public void n(float p0) { throw new UnsupportedOperationException("stub"); }
        public void o(float p0) { throw new UnsupportedOperationException("stub"); }
        public void p(float p0) { throw new UnsupportedOperationException("stub"); }
        public void q(float p0) { throw new UnsupportedOperationException("stub"); }
        public void r(float p0) { throw new UnsupportedOperationException("stub"); }
        public void s(float p0) { throw new UnsupportedOperationException("stub"); }
        public void t(float p0) { throw new UnsupportedOperationException("stub"); }
        public java.lang.String toString() { throw new UnsupportedOperationException("stub"); }
    }

    // --- восстановлено из DEX (com/withpersona/sdk2/inquiry/selfie/view/SelfieOverlayView$b) ---
    public static class b {
        public b() { }
        public b(kotlin.jvm.internal.DefaultConstructorMarker p0) { }
    }

    // --- восстановлено из DEX (com/withpersona/sdk2/inquiry/selfie/view/SelfieOverlayView$d) ---
    public static class d {
        float a;
        float b;
        float c;
        public d(float p0, float p1, float p2) { }
        public float a() { throw new UnsupportedOperationException("stub"); }
        public float b() { throw new UnsupportedOperationException("stub"); }
        public float c() { throw new UnsupportedOperationException("stub"); }
        public void d(float p0) { throw new UnsupportedOperationException("stub"); }
        public boolean equals(java.lang.Object p0) { throw new UnsupportedOperationException("stub"); }
        public int hashCode() { throw new UnsupportedOperationException("stub"); }
        public java.lang.String toString() { throw new UnsupportedOperationException("stub"); }
    }

    // --- восстановлено из DEX (com/withpersona/sdk2/inquiry/selfie/view/SelfieOverlayView$f) ---
    public static class f {
        boolean a;
        com.withpersona.sdk2.inquiry.selfie.view.SelfieOverlayView.e b;
        com.withpersona.sdk2.inquiry.selfie.view.SelfieOverlayView.e c;
        float d;
        float e;
        float f;
        float g;
        float h;
        float i;
        float j;
        float k;
        float l;
        float m;
        public f(boolean p0, com.withpersona.sdk2.inquiry.selfie.view.SelfieOverlayView.e p1, com.withpersona.sdk2.inquiry.selfie.view.SelfieOverlayView.e p2, float p3, float p4, float p5, float p6, float p7, float p8, float p9, float p10, float p11, float p12) { }
        public boolean a() { throw new UnsupportedOperationException("stub"); }
        public com.withpersona.sdk2.inquiry.selfie.view.SelfieOverlayView.e b() { throw new UnsupportedOperationException("stub"); }
        public float c() { throw new UnsupportedOperationException("stub"); }
        public float d() { throw new UnsupportedOperationException("stub"); }
        public float e() { throw new UnsupportedOperationException("stub"); }
        public boolean equals(java.lang.Object p0) { throw new UnsupportedOperationException("stub"); }
        public float f() { throw new UnsupportedOperationException("stub"); }
        public float g() { throw new UnsupportedOperationException("stub"); }
        public float h() { throw new UnsupportedOperationException("stub"); }
        public int hashCode() { throw new UnsupportedOperationException("stub"); }
        public float i() { throw new UnsupportedOperationException("stub"); }
        public float j() { throw new UnsupportedOperationException("stub"); }
        public float k() { throw new UnsupportedOperationException("stub"); }
        public float l() { throw new UnsupportedOperationException("stub"); }
        public com.withpersona.sdk2.inquiry.selfie.view.SelfieOverlayView.e m() { throw new UnsupportedOperationException("stub"); }
        public void n(float p0) { throw new UnsupportedOperationException("stub"); }
        public java.lang.String toString() { throw new UnsupportedOperationException("stub"); }
    }
}
