package com.withpersona.sdk2.inquiry.shared.ui;

import android.animation.Animator;
import android.animation.ValueAnimator;
import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.view.View;
import android.view.animation.LinearInterpolator;
import androidx.core.graphics.c;
import com.github.luben.zstd.BuildConfig;

import k6.b;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.internal.Intrinsics;
import kr.a0;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import xq.j;
import xq.w;

@Metadata(d1 = {"\u0000^\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\r\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0007\n\u0002\b\u0010\u0018\u00002\u00020\u0001B\u001d\b\u0016\u0012\b\u0010\u0003\u001a\u0004\u0018\u00010\u0002\u0012\b\u0010\u0005\u001a\u0004\u0018\u00010\u0004¢\u0006\u0004\b\u0006\u0010\u0007J\u000f\u0010\t\u001a\u00020\bH\u0014¢\u0006\u0004\b\t\u0010\nJ\u001f\u0010\u000e\u001a\u00020\b2\u0006\u0010\f\u001a\u00020\u000b2\u0006\u0010\r\u001a\u00020\u000bH\u0014¢\u0006\u0004\b\u000e\u0010\u000fJ\u0017\u0010\u0012\u001a\u00020\b2\u0006\u0010\u0011\u001a\u00020\u0010H\u0016¢\u0006\u0004\b\u0012\u0010\u0013J\u0015\u0010\u0015\u001a\u00020\b2\u0006\u0010\u0014\u001a\u00020\u000b¢\u0006\u0004\b\u0015\u0010\u0016J#\u0010\u0017\u001a\u00020\b2\b\u0010\u0003\u001a\u0004\u0018\u00010\u00022\b\u0010\u0005\u001a\u0004\u0018\u00010\u0004H\u0002¢\u0006\u0004\b\u0017\u0010\u0007J/\u0010\u001c\u001a\u00020\b2\u0006\u0010\u0018\u001a\u00020\u000b2\u0006\u0010\u0019\u001a\u00020\u000b2\u0006\u0010\u001a\u001a\u00020\u000b2\u0006\u0010\u001b\u001a\u00020\u000bH\u0002¢\u0006\u0004\b\u001c\u0010\u001dR\u0018\u0010!\u001a\u0004\u0018\u00010\u001e8\u0002@\u0002X\u0082\u000e¢\u0006\u0006\n\u0004\b\u001f\u0010 R\u0016\u0010$\u001a\u00020\u000b8\u0002@\u0002X\u0082\u000e¢\u0006\u0006\n\u0004\b\"\u0010#R\u0018\u0010(\u001a\u0004\u0018\u00010%8\u0002@\u0002X\u0082\u000e¢\u0006\u0006\n\u0004\b&\u0010'R\u0016\u0010\u0014\u001a\u00020\u000b8\u0002@\u0002X\u0082\u000e¢\u0006\u0006\n\u0004\b)\u0010#R\u0018\u0010,\u001a\u0004\u0018\u00010*8\u0002@\u0002X\u0082\u000e¢\u0006\u0006\n\u0004\b\u0017\u0010+R\u0014\u00100\u001a\u00020-8\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b.\u0010/R\u0014\u00103\u001a\u0002018\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b\u001c\u00102R\"\u0010;\u001a\u0002048\u0006@\u0006X\u0086\u000e¢\u0006\u0012\n\u0004\b5\u00106\u001a\u0004\b7\u00108\"\u0004\b9\u0010:R.\u0010C\u001a\u0004\u0018\u00010\u00012\b\u0010<\u001a\u0004\u0018\u00010\u00018\u0006@FX\u0086\u000e¢\u0006\u0012\n\u0004\b=\u0010>\u001a\u0004\b?\u0010@\"\u0004\bA\u0010B¨\u0006D"}, d2 = {"Lcom/withpersona/sdk2/inquiry/shared/ui/SpotlightView;", "Landroid/view/View;", "Landroid/content/Context;", "context", "Landroid/util/AttributeSet;", "attrs", "<init>", "(Landroid/content/Context;Landroid/util/AttributeSet;)V", BuildConfig.FLAVOR, "onFinishInflate", "()V", BuildConfig.FLAVOR, "widthMeasureSpec", "heightMeasureSpec", "onMeasure", "(II)V", "Landroid/graphics/Canvas;", "canvas", "draw", "(Landroid/graphics/Canvas;)V", "borderColor", "setBorderColor", "(I)V", "e", "left", "top", "right", "bottom", "g", "(IIII)V", "Landroid/animation/ValueAnimator;", xe.a.f36648e, "Landroid/animation/ValueAnimator;", "intensityAnimator", b.f21144e, "I", "targetViewId", "Landroid/graphics/Path;", "c", "Landroid/graphics/Path;", "clipPath", "d", "Landroid/graphics/Rect;", "Landroid/graphics/Rect;", "rect", "Landroid/graphics/Paint;", "f", "Landroid/graphics/Paint;", "borderPaint", "Landroid/view/View$OnLayoutChangeListener;", "Landroid/view/View$OnLayoutChangeListener;", "targetLayoutChangeListener", BuildConfig.FLAVOR, "h", "F", "getRadius", "()F", "setRadius", "(F)V", "radius", "value", "i", "Landroid/view/View;", "getTargetView", "()Landroid/view/View;", "setTargetView", "(Landroid/view/View;)V", "targetView", "shared_release"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* loaded from: classes3.dex */
public final class SpotlightView extends View {

    /* renamed from: a, reason: collision with root package name and from kotlin metadata */
    @Nullable
    public ValueAnimator intensityAnimator;

    /* renamed from: b, reason: from kotlin metadata */
    public int targetViewId;

    /* renamed from: c, reason: collision with root package name and from kotlin metadata */
    @Nullable
    public Path clipPath;

    /* renamed from: d, reason: collision with root package name and from kotlin metadata */
    public int borderColor;

    /* renamed from: e, reason: collision with root package name and from kotlin metadata */
    @Nullable
    public Rect rect;

    /* renamed from: f, reason: collision with root package name and from kotlin metadata */
    @NotNull
    public final Paint borderPaint;

    /* renamed from: g, reason: collision with root package name and from kotlin metadata */
    @NotNull
    public final View.OnLayoutChangeListener targetLayoutChangeListener;

    /* renamed from: h, reason: collision with root package name and from kotlin metadata */
    public float radius;

    /* renamed from: i, reason: collision with root package name and from kotlin metadata */
    @Nullable
    public View targetView;

    @Metadata(d1 = {"\u0000\u0017\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0006*\u0001\u0000\b\n\u0018\u00002\u00020\u0001J\u0017\u0010\u0005\u001a\u00020\u00042\u0006\u0010\u0003\u001a\u00020\u0002H\u0016¢\u0006\u0004\b\u0005\u0010\u0006J\u0017\u0010\u0007\u001a\u00020\u00042\u0006\u0010\u0003\u001a\u00020\u0002H\u0016¢\u0006\u0004\b\u0007\u0010\u0006J\u0017\u0010\b\u001a\u00020\u00042\u0006\u0010\u0003\u001a\u00020\u0002H\u0016¢\u0006\u0004\b\b\u0010\u0006J\u0017\u0010\t\u001a\u00020\u00042\u0006\u0010\u0003\u001a\u00020\u0002H\u0016¢\u0006\u0004\b\t\u0010\u0006¨\u0006\n"}, d2 = {"androidx/core/animation/AnimatorKt$addListener$listener$1", "Landroid/animation/Animator$AnimatorListener;", "Landroid/animation/Animator;", "animator", BuildConfig.FLAVOR, "onAnimationRepeat", "(Landroid/animation/Animator;)V", "onAnimationEnd", "onAnimationCancel", "onAnimationStart", "core-ktx_release"}, k = 1, mv = {2, 2, 0}, xi = 48)
    public static final class a implements Animator.AnimatorListener {
        public a() {
        }

        @Override // android.animation.Animator.AnimatorListener
        public void onAnimationCancel(Animator animator) {
        }

        @Override // android.animation.Animator.AnimatorListener
        public void onAnimationEnd(Animator animator) {
            SpotlightView.this.intensityAnimator = null;
        }

        @Override // android.animation.Animator.AnimatorListener
        public void onAnimationRepeat(Animator animator) {
        }

        @Override // android.animation.Animator.AnimatorListener
        public void onAnimationStart(Animator animator) {
        }
    }

    public SpotlightView(@Nullable Context context, @Nullable AttributeSet attributeSet) {
        super(context, attributeSet);
        Paint paint = new Paint();
        paint.setStrokeWidth((float) j.a(7.0d));
        paint.setAntiAlias(true);
        paint.setStyle(Paint.Style.STROKE);
        this.borderPaint = paint;
        this.targetLayoutChangeListener = new View.OnLayoutChangeListener() { // from class: kr.s
            @Override // android.view.View.OnLayoutChangeListener
            public final void onLayoutChange(View view, int i10, int i11, int i12, int i13, int i14, int i15, int i16, int i17) {
                SpotlightView.i(SpotlightView.this, view, i10, i11, i12, i13, i14, i15, i16, i17);
            }
        };
        e(context, attributeSet);
    }

    public static final Unit f(SpotlightView spotlightView) {
        Object parent = spotlightView.getParent();
        if (parent instanceof View) {
            spotlightView.setTargetView(((View) parent).findViewById(spotlightView.targetViewId));
        }
        return Unit.f21504a;
    }

    public static final void h(SpotlightView spotlightView, int i10, int i11, ValueAnimator it) {
        Intrinsics.checkNotNullParameter(it, "it");
        spotlightView.borderColor = c.c(i10, i11, it.getAnimatedFraction());
        spotlightView.invalidate();
    }

    public static final void i(SpotlightView spotlightView, View view, int i10, int i11, int i12, int i13, int i14, int i15, int i16, int i17) {
        spotlightView.g(i10, i11, i12, i13);
    }

    @Override // android.view.View
    public void draw(@NotNull Canvas canvas) {
        Canvas canvas2;
        Intrinsics.checkNotNullParameter(canvas, "canvas");
        Path path = this.clipPath;
        if (path == null) {
            super.draw(canvas);
            return;
        }
        int save = canvas.save();
        try {
            canvas.clipOutPath(path);
            super.draw(canvas);
            int i10 = this.borderColor;
            if (i10 != 0) {
                this.borderPaint.setColor(i10);
                Rect rect = this.rect;
                if (rect != null) {
                    float f10 = rect.left;
                    float f11 = rect.top;
                    float f12 = rect.right;
                    float f13 = rect.bottom;
                    float f14 = this.radius;
                    canvas2 = canvas;
                    try {
                        canvas2.drawRoundRect(f10, f11, f12, f13, f14, f14, this.borderPaint);
                        canvas2.restoreToCount(save);
                    } catch (Throwable th2) {
                        th = th2;
                        Throwable th3 = th;
                        canvas2.restoreToCount(save);
                        throw th3;
                    }
                }
            }
            canvas2 = canvas;
            canvas2.restoreToCount(save);
        } catch (Throwable th4) {
            th = th4;
            canvas2 = canvas;
        }
    }

    public final void e(Context context, AttributeSet attrs) {
        Resources.Theme theme;
        TypedArray obtainStyledAttributes;
        if (context == null || (theme = context.getTheme()) == null || (obtainStyledAttributes = theme.obtainStyledAttributes(attrs, w.f37084j, 0, 0)) == null) {
            return;
        }
        try {
            this.targetViewId = obtainStyledAttributes.getResourceId(w.f37086l, 0);
            this.radius = obtainStyledAttributes.getDimensionPixelSize(w.f37085k, 0);
        } finally {
            obtainStyledAttributes.recycle();
        }
    }

    public final void g(int left, int top, int right, int bottom) {
        this.rect = new Rect(left, top, right, bottom);
        Path path = new Path();
        float f10 = this.radius;
        path.addRoundRect(left, top, right, bottom, f10, f10, Path.Direction.CW);
        this.clipPath = path;
        invalidate();
    }

    public final float getRadius() {
        return this.radius;
    }

    @Nullable
    public final View getTargetView() {
        return this.targetView;
    }

    @Override // android.view.View
    public void onFinishInflate() {
        super.onFinishInflate();
        a0.b(this, new Function0() { // from class: kr.r
            @Override // kotlin.jvm.functions.Function0
            public final Object invoke() {
                Unit f10;
                f10 = SpotlightView.f(SpotlightView.this);
                return f10;
            }
        });
    }

    @Override // android.view.View
    public void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        super.onMeasure(widthMeasureSpec, heightMeasureSpec);
        View view = this.targetView;
        if (view != null) {
            g(view.getLeft(), view.getTop(), view.getRight(), view.getBottom());
        }
    }

    public final void setBorderColor(final int borderColor) {
        final int i10 = this.borderColor;
        if (i10 == borderColor) {
            return;
        }
        ValueAnimator valueAnimator = this.intensityAnimator;
        if (valueAnimator != null) {
            valueAnimator.cancel();
            valueAnimator.removeAllUpdateListeners();
        }
        ValueAnimator ofFloat = ValueAnimator.ofFloat(0.0f, 1.0f);
        ofFloat.setInterpolator(new LinearInterpolator());
        ofFloat.setStartDelay(0L);
        ofFloat.setRepeatCount(0);
        ofFloat.setDuration(200L);
        ofFloat.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() { // from class: kr.q
            @Override // android.animation.ValueAnimator.AnimatorUpdateListener
            public final void onAnimationUpdate(ValueAnimator valueAnimator2) {
                SpotlightView.h(SpotlightView.this, i10, borderColor, valueAnimator2);
            }
        });
        Intrinsics.checkNotNull(ofFloat);
        ofFloat.addListener(new a());
        ofFloat.start();
        this.intensityAnimator = ofFloat;
    }

    public final void setRadius(float f10) {
        this.radius = f10;
    }

    public final void setTargetView(@Nullable View view) {
        View view2 = this.targetView;
        if (view2 != null) {
            view2.removeOnLayoutChangeListener(this.targetLayoutChangeListener);
        }
        this.targetView = view;
        if (view != null) {
            view.addOnLayoutChangeListener(this.targetLayoutChangeListener);
            g(view.getLeft(), view.getTop(), view.getRight(), view.getBottom());
        }
        requestLayout();
    }
}
