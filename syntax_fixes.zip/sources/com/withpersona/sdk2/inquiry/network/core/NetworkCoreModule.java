package com.withpersona.sdk2.inquiry.network.core;

import android.content.Context;
import bq.e;
import com.github.luben.zstd.BuildConfig;

import hn.h;
import hn.w;
import java.io.IOException;
import java.net.ConnectException;
import java.net.SocketTimeoutException;
import java.net.UnknownHostException;
import java.util.Iterator;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.TimeUnit;
import kotlin.Unit;
import kotlin.collections.q0;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.DefaultConstructorMarker;
import mo.k;
import mv.a0;
import mv.b0;
import mv.d0;
import mv.e0;
import mv.f0;
import mv.h0;
import mv.i0;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import sw.y;

/* loaded from: classes3.dex */
public final class NetworkCoreModule {

    @NotNull
    public static final Companion Companion = new Companion(null);

    @Nullable
    private String certificateFingerprint;

    @Nullable
    private String environmentId;

    @Nullable
    private final String locale;
    private final boolean redactAppIdentifyingInformation;

    @Nullable
    private final String styleVariant;
    private final boolean useServerStyle;

    public static final class Companion {
        public /* synthetic */ Companion(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }

        @NotNull
        public final Set<h.e> provideMoshiJsonAdapterFactory() {
            return q0.g(ErrorResponse.Companion.getAdapter(), InternalErrorInfo.Companion.createAdapter());
        }

        private Companion() {
        }
    }

    public static final class NetworkConstants {

        @NotNull
        public static final String HEADER_KEY_PERSONA_ENVIRONMENT_ID = "Persona-Environment-Id";

        @NotNull
        public static final String HEADER_KEY_PERSONA_ORGANIZATION_ID = "Persona-Organization-Id";

        @NotNull
        public static final NetworkConstants INSTANCE = new NetworkConstants();

        private NetworkConstants() {
        }
    }

    public NetworkCoreModule(boolean z10, @Nullable String str, @Nullable String str2, @Nullable String str3, boolean z11) {
        this.useServerStyle = z10;
        this.environmentId = str;
        this.locale = str2;
        this.styleVariant = str3;
        this.redactAppIdentifyingInformation = z11;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final h0 interceptor$lambda$10(w wVar, a0.a aVar) {
        String str = BuildConfig.FLAVOR;
        try {
            return aVar.a(aVar.h());
        } catch (ConnectException e10) {
            h0.a f10 = new h0.a().q(aVar.h()).o(e0.f24579f).f(0);
            String localizedMessage = e10.getLocalizedMessage();
            if (localizedMessage != null) {
                str = localizedMessage;
            }
            return f10.l(str).b(i0.INSTANCE.c(wVar.c(ErrorResponse.class).toJson(ErrorResponse.Companion.create(e10.getLocalizedMessage())), b0.INSTANCE.a("application/json"))).c();
        } catch (SocketTimeoutException e11) {
            h0.a f11 = new h0.a().q(aVar.h()).o(e0.f24579f).f(0);
            String localizedMessage2 = e11.getLocalizedMessage();
            if (localizedMessage2 != null) {
                str = localizedMessage2;
            }
            return f11.l(str).b(i0.INSTANCE.c(wVar.c(ErrorResponse.class).toJson(ErrorResponse.Companion.create(e11.getLocalizedMessage())), b0.INSTANCE.a("application/json"))).c();
        } catch (UnknownHostException e12) {
            h0.a f12 = new h0.a().q(aVar.h()).o(e0.f24579f).f(0);
            String localizedMessage3 = e12.getLocalizedMessage();
            if (localizedMessage3 != null) {
                str = localizedMessage3;
            }
            return f12.l(str).b(i0.INSTANCE.c(wVar.c(ErrorResponse.class).toJson(ErrorResponse.Companion.create(e12.getLocalizedMessage())), b0.INSTANCE.a("application/json"))).c();
        } catch (IOException e13) {
            h0.a f13 = new h0.a().q(aVar.h()).o(e0.f24579f).f(0);
            String localizedMessage4 = e13.getLocalizedMessage();
            if (localizedMessage4 != null) {
                str = localizedMessage4;
            }
            return f13.l(str).b(i0.INSTANCE.c(wVar.c(ErrorResponse.class).toJson(ErrorResponse.Companion.create(e13.getLocalizedMessage())), b0.INSTANCE.a("application/json"))).c();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit okhttpClient$lambda$0(NetworkCoreModule networkCoreModule, String str) {
        networkCoreModule.certificateFingerprint = str;
        return Unit.f21504a;
    }

    @NotNull
    public static final Set<h.e> provideMoshiJsonAdapterFactory() {
        return Companion.provideMoshiJsonAdapterFactory();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final h0 responseInterceptor$lambda$9(NetworkStateManager networkStateManager, NetworkCoreModule networkCoreModule, a0.a aVar) {
        h0 a10 = aVar.a(aVar.h());
        String a11 = a10.getHeaders().a(NetworkConstants.HEADER_KEY_PERSONA_ORGANIZATION_ID);
        if (a11 != null) {
            networkStateManager.setOrganizationId(a11);
        }
        String a12 = a10.getHeaders().a(NetworkConstants.HEADER_KEY_PERSONA_ENVIRONMENT_ID);
        if (a12 != null) {
            networkCoreModule.environmentId = a12;
        }
        return a10;
    }

    @NotNull
    public final a0 interceptor(@NotNull final w wVar) {
        return new a0() { // from class: com.withpersona.sdk2.inquiry.network.core.e
            @Override // mv.a0
            public final h0 intercept(a0.a aVar) {
                h0 interceptor$lambda$10;
                interceptor$lambda$10 = NetworkCoreModule.interceptor$lambda$10(w.this, aVar);
                return interceptor$lambda$10;
            }
        };
    }

    @NotNull
    public final String keyInflection() {
        return "camel";
    }

    @NotNull
    public final w moshi(@NotNull Set<Object> set, @NotNull Set<JsonAdapterBinding<?>> set2, @NotNull Set<h.e> set3) {
        w.b bVar = new w.b();
        Iterator<T> it = set.iterator();
        while (it.hasNext()) {
            bVar.b(it.next());
        }
        Iterator<T> it2 = set2.iterator();
        while (it2.hasNext()) {
            JsonAdapterBinding jsonAdapterBinding = (JsonAdapterBinding) it2.next();
            bVar.c(jsonAdapterBinding.getClazz(), jsonAdapterBinding.getJsonAdapter());
        }
        Iterator<T> it3 = set3.iterator();
        while (it3.hasNext()) {
            bVar.a((h.e) it3.next());
        }
        return bVar.d();
    }

    @NotNull
    public final d0 okhttpClient(@NotNull Set<a0> set, @NotNull final Map<String, String> map, @NotNull final Context context, @NotNull final k kVar, @NotNull final mo.b bVar, @NotNull final e.a aVar, @NotNull final NetworkStateManager networkStateManager) {
        d0.a b = new d0.a().k(new b(new Function1() { // from class: com.withpersona.sdk2.inquiry.network.core.c
            @Override // kotlin.jvm.functions.Function1
            public final Object invoke(Object obj) {
                Unit okhttpClient$lambda$0;
                okhttpClient$lambda$0 = NetworkCoreModule.okhttpClient$lambda$0(NetworkCoreModule.this, (String) obj);
                return okhttpClient$lambda$0;
            }
        })).b(new a0() { // from class: com.withpersona.sdk2.inquiry.network.core.NetworkCoreModule$okhttpClient$$inlined$-addNetworkInterceptor$1
            @Override // mv.a0
            @NotNull
            public final h0 intercept(@NotNull a0.a aVar2) {
                String str;
                String str2;
                boolean z10;
                String str3;
                String str4;
                f0.a j10 = aVar2.h().j();
                if (!aVar2.h().getHeaders().d().contains("Accept")) {
                    j10 = j10.m("Accept", "application/json");
                }
                f0.a m10 = j10.m("Persona-Version", "2025-11-18").m("Persona-Device-Manufacturer", mo.b.this.c()).m("Persona-Device-Model", mo.b.this.b()).m("Persona-Device-OS", "Android").m("Persona-Device-OS-Version", mo.b.this.d()).m("VTDGJLGG", String.valueOf(mo.b.this.a()));
                str = this.styleVariant;
                if (str == null) {
                    str = (context.getResources().getConfiguration().uiMode & 48) == 32 ? "dark" : "light";
                }
                f0.a m11 = m10.m("Persona-Style-Variant", str);
                str2 = this.locale;
                if (str2 == null) {
                    str2 = Locale.getDefault().toString();
                }
                f0.a m12 = m11.m("Persona-Device-Locale", str2);
                z10 = this.redactAppIdentifyingInformation;
                if (!z10) {
                    m12.m("Persona-App-Bundle", context.getPackageName());
                    m12.m("Persona-Device-Vendor-Id", kVar.b());
                }
                String organizationId = networkStateManager.getOrganizationId();
                if (organizationId != null) {
                    m12.m(NetworkCoreModule.NetworkConstants.HEADER_KEY_PERSONA_ORGANIZATION_ID, organizationId);
                }
                str3 = this.environmentId;
                if (str3 != null) {
                    m12.m(NetworkCoreModule.NetworkConstants.HEADER_KEY_PERSONA_ENVIRONMENT_ID, str3);
                }
                for (Map.Entry entry : map.entrySet()) {
                    m12.m((String) entry.getKey(), (String) entry.getValue());
                }
                str4 = this.certificateFingerprint;
                if (str4 != null) {
                    m12.m("BMRWJMTB", str4);
                }
                return aVar2.a(a.a(a.f10942a, m12.b(), aVar.create(NetworkUtilsKt.SUBSYSTEM), 0L, 2, (Object) null));
            }
        });
        TimeUnit timeUnit = TimeUnit.MINUTES;
        d0.a f10 = b.T(1L, timeUnit).W(1L, timeUnit).f(1L, timeUnit);
        Iterator<T> it = set.iterator();
        while (it.hasNext()) {
            f10.a((a0) it.next());
        }
        return f10.c();
    }

    @NotNull
    public final a0 responseInterceptor(@NotNull final NetworkStateManager networkStateManager) {
        return new a0() { // from class: com.withpersona.sdk2.inquiry.network.core.d
            @Override // mv.a0
            public final h0 intercept(a0.a aVar) {
                h0 responseInterceptor$lambda$9;
                responseInterceptor$lambda$9 = NetworkCoreModule.responseInterceptor$lambda$9(NetworkStateManager.this, this, aVar);
                return responseInterceptor$lambda$9;
            }
        };
    }

    @NotNull
    public final y retrofit(@NotNull String str, @NotNull d0 d0Var, @NotNull w wVar) {
        return new y.b().g(d0Var).c(str).b(uw.a.f(wVar)).e();
    }

    @NotNull
    public final String useServerStyles() {
        return String.valueOf(this.useServerStyle);
    }

    public /* synthetic */ NetworkCoreModule(boolean z10, String str, String str2, String str3, boolean z11, int i10, DefaultConstructorMarker defaultConstructorMarker) {
        this(z10, (i10 & 2) != 0 ? null : str, str2, str3, z11);
    }
}
