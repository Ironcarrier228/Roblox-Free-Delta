package com.withpersona.sdk2.inquiry.internal.fallbackmode;

import av.p0;
import com.github.luben.zstd.BuildConfig;
import com.withpersona.sdk2.inquiry.internal.fallbackmode.FallbackModeService;
import com.withpersona.sdk2.inquiry.internal.fallbackmode.i;
import com.withpersona.sdk2.inquiry.network.core.NetworkCallResult;
import com.withpersona.sdk2.inquiry.network.core.NetworkUtilsKt;
import com.withpersona.sdk2.inquiry.network.dto.InquiryFieldMap;
import gu.l;
import gu.m;
import hn.w;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.Intrinsics;
import mv.b0;
import mv.g0;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import sw.x;
import up.InquiryAttributes;
import zt.n;
import zt.o;

@Metadata(d1 = {"\u0000R\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0010\b\u0000\u0018\u00002\u00020\u0001B!\b\u0007\u0012\u0006\u0010\u0003\u001a\u00020\u0002\u0012\u0006\u0010\u0005\u001a\u00020\u0004\u0012\u0006\u0010\u0007\u001a\u00020\u0006¢\u0006\u0004\b\b\u0010\tJ\u001e\u0010\u000e\u001a\b\u0012\u0004\u0012\u00020\r0\f2\u0006\u0010\u000b\u001a\u00020\nH\u0096@¢\u0006\u0004\b\u000e\u0010\u000fJ$\u0010\u0015\u001a\u0006\u0012\u0002\b\u00030\u00142\u0006\u0010\u0011\u001a\u00020\u00102\u0006\u0010\u0013\u001a\u00020\u0012H\u0096@¢\u0006\u0004\b\u0015\u0010\u0016J$\u0010\u0017\u001a\u0006\u0012\u0002\b\u00030\u00142\u0006\u0010\u0011\u001a\u00020\u00102\u0006\u0010\u0013\u001a\u00020\u0012H\u0096@¢\u0006\u0004\b\u0017\u0010\u0016J\u000f\u0010\u0019\u001a\u00020\u0018H\u0002¢\u0006\u0004\b\u0019\u0010\u001aJ,\u0010\u001d\u001a\u0006\u0012\u0002\b\u00030\u00142\u0006\u0010\u0011\u001a\u00020\u00102\u0006\u0010\u0013\u001a\u00020\u00122\u0006\u0010\u001c\u001a\u00020\u001bH\u0082@¢\u0006\u0004\b\u001d\u0010\u001eR\u0017\u0010\u0003\u001a\u00020\u00028\u0006¢\u0006\f\n\u0004\b\u0015\u0010\u001f\u001a\u0004\b \u0010!R\u0017\u0010\u0005\u001a\u00020\u00048\u0006¢\u0006\f\n\u0004\b\u000e\u0010\"\u001a\u0004\b#\u0010$R\u0017\u0010\u0007\u001a\u00020\u00068\u0006¢\u0006\f\n\u0004\b\u0017\u0010%\u001a\u0004\b&\u0010'R\u0016\u0010*\u001a\u00020\u00188\u0002@\u0002X\u0082\u000e¢\u0006\u0006\n\u0004\b(\u0010)¨\u0006+"}, d2 = {"Lcom/withpersona/sdk2/inquiry/internal/fallbackmode/d;", "Lrp/a;", "Lcom/withpersona/sdk2/inquiry/internal/fallbackmode/FallbackModeService;", "service", "Lhn/w;", "moshi", "Lcom/withpersona/sdk2/inquiry/internal/fallbackmode/i$a;", "staticTemplateSessionFactory", "<init>", "(Lcom/withpersona/sdk2/inquiry/internal/fallbackmode/FallbackModeService;Lhn/w;Lcom/withpersona/sdk2/inquiry/internal/fallbackmode/i$a;)V", "Lup/e;", "attributes", "Lzt/n;", "Lcom/withpersona/sdk2/inquiry/internal/fallbackmode/i;", k6.b.f21144e, "(Lup/e;Leu/b;)Ljava/lang/Object;", BuildConfig.FLAVOR, "sessionToken", "Lmv/g0;", "body", "Lsw/x;", xe.a.f36648e, "(Ljava/lang/String;Lmv/g0;Leu/b;)Ljava/lang/Object;", "c", BuildConfig.FLAVOR, "f", "()I", "Lrp/h;", "endpoint", "h", "(Ljava/lang/String;Lmv/g0;Lrp/h;Leu/b;)Ljava/lang/Object;", "Lcom/withpersona/sdk2/inquiry/internal/fallbackmode/FallbackModeService;", "g", "()Lcom/withpersona/sdk2/inquiry/internal/fallbackmode/FallbackModeService;", "Lhn/w;", "getMoshi", "()Lhn/w;", "Lcom/withpersona/sdk2/inquiry/internal/fallbackmode/i$a;", "getStaticTemplateSessionFactory", "()Lcom/withpersona/sdk2/inquiry/internal/fallbackmode/i$a;", "d", "I", "requestCount", "inquiry-internal_release"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* loaded from: classes3.dex */
public final class d implements rp.a {

    /* renamed from: a, reason: collision with root package name and from kotlin metadata */
    @NotNull
    public final FallbackModeService service;

    /* renamed from: b, reason: from kotlin metadata */
    @NotNull
    public final w moshi;

    /* renamed from: c, reason: collision with root package name and from kotlin metadata */
    @NotNull
    public final i.a staticTemplateSessionFactory;

    /* renamed from: d, reason: collision with root package name and from kotlin metadata */
    public int requestCount;

    @Metadata(k = 3, mv = {2, 2, 0}, xi = 48)
    @gu.f(c = "com.withpersona.sdk2.inquiry.internal.fallbackmode.FallbackModeApiController", f = "ApiController.kt", l = {84, 120}, m = "createSession-gIAlu-s")
    public static final class a extends gu.d {

        /* renamed from: t, reason: collision with root package name */
        public Object f10394t;

        /* renamed from: u, reason: collision with root package name */
        public Object f10395u;

        /* renamed from: v, reason: collision with root package name */
        public Object f10396v;

        /* renamed from: w, reason: collision with root package name */
        public /* synthetic */ Object f10397w;

        /* renamed from: y, reason: collision with root package name */
        public int f10399y;

        public a(eu.b<? super a> bVar) {
            super(bVar);
        }

        @Override // gu.a
        @Nullable
        public final Object invokeSuspend(@NotNull Object obj) {
            this.f10397w = obj;
            this.f10399y |= Integer.MIN_VALUE;
            Object b = d.this.b(null, this);
            return b == fu.c.e() ? b : n.a(b);
        }
    }

    @Metadata(d1 = {"\u0000\u0010\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\u0010\u0003\u001a\b\u0012\u0004\u0012\u00020\u00020\u0001*\u00020\u0000H\n¢\u0006\u0004\b\u0003\u0010\u0004"}, d2 = {"Lav/p0;", "Lcom/withpersona/sdk2/inquiry/network/core/NetworkCallResult;", "Lcom/withpersona/sdk2/inquiry/internal/fallbackmode/FallbackModeService$StatusResponse;", "<anonymous>", "(Lav/p0;)Lcom/withpersona/sdk2/inquiry/network/core/NetworkCallResult;"}, k = 3, mv = {2, 2, 0})
    @gu.f(c = "com.withpersona.sdk2.inquiry.internal.fallbackmode.FallbackModeApiController$createSession$response$1", f = "ApiController.kt", l = {85}, m = "invokeSuspend")
    public static final class b extends m implements Function2<p0, eu.b<? super NetworkCallResult<FallbackModeService.StatusResponse>>, Object> {

        /* renamed from: t, reason: collision with root package name */
        public int f10400t;

        /* renamed from: u, reason: collision with root package name */
        public final /* synthetic */ InquiryAttributes f10401u;

        /* renamed from: v, reason: collision with root package name */
        public final /* synthetic */ d f10402v;

        @Metadata(d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\u0010\u0002\u001a\b\u0012\u0004\u0012\u00020\u00010\u0000H\n¢\u0006\u0004\b\u0002\u0010\u0003"}, d2 = {"Lsw/x;", "Lcom/withpersona/sdk2/inquiry/internal/fallbackmode/FallbackModeService$StatusResponse;", "<anonymous>", "()Lsw/x;"}, k = 3, mv = {2, 2, 0})
        @gu.f(c = "com.withpersona.sdk2.inquiry.internal.fallbackmode.FallbackModeApiController$createSession$response$1$1", f = "ApiController.kt", l = {88}, m = "invokeSuspend")
        public static final class a extends m implements Function1<eu.b<? super x<FallbackModeService.StatusResponse>>, Object> {

            /* renamed from: t, reason: collision with root package name */
            public Object f10403t;

            /* renamed from: u, reason: collision with root package name */
            public int f10404u;

            /* renamed from: v, reason: collision with root package name */
            public final /* synthetic */ InquiryAttributes f10405v;

            /* renamed from: w, reason: collision with root package name */
            public final /* synthetic */ d f10406w;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            public a(InquiryAttributes inquiryAttributes, d dVar, eu.b<? super a> bVar) {
                super(1, bVar);
                this.f10405v = inquiryAttributes;
                this.f10406w = dVar;
            }

            @Override // gu.a
            public final eu.b<Unit> create(eu.b<?> bVar) {
                return new a(this.f10405v, this.f10406w, bVar);
            }

            @Override // gu.a
            public final Object invokeSuspend(Object obj) {
                String str;
                Object e10 = fu.c.e();
                int i10 = this.f10404u;
                if (i10 != 0) {
                    if (i10 != 1) {
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                    o.b(obj);
                    return obj;
                }
                o.b(obj);
                String sessionToken = this.f10405v.getSessionToken();
                if (sessionToken == null || sessionToken.length() == 0) {
                    str = null;
                } else {
                    str = "Bearer " + com.withpersona.sdk2.inquiry.internal.h.INSTANCE.a(this.f10405v.getSessionToken());
                }
                FallbackModeService service = this.f10406w.getService();
                FallbackModeService.StatusRequest statusRequest = new FallbackModeService.StatusRequest(this.f10405v.getTemplateId());
                this.f10403t = l.a(str);
                this.f10404u = 1;
                Object c10 = service.c(str, statusRequest, this);
                return c10 == e10 ? e10 : c10;
            }

            @Override // kotlin.jvm.functions.Function1
            /* renamed from: m, reason: merged with bridge method [inline-methods] */
            public final Object invoke(eu.b<? super x<FallbackModeService.StatusResponse>> bVar) {
                return ((a) create(bVar)).invokeSuspend(Unit.f21504a);
            }
        }

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public b(InquiryAttributes inquiryAttributes, d dVar, eu.b<? super b> bVar) {
            super(2, bVar);
            this.f10401u = inquiryAttributes;
            this.f10402v = dVar;
        }

        @Override // gu.a
        public final eu.b<Unit> create(Object obj, eu.b<?> bVar) {
            return new b(this.f10401u, this.f10402v, bVar);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(p0 p0Var, eu.b<? super NetworkCallResult<FallbackModeService.StatusResponse>> bVar) {
            return ((b) create(p0Var, bVar)).invokeSuspend(Unit.f21504a);
        }

        @Override // gu.a
        public final Object invokeSuspend(Object obj) {
            Object e10 = fu.c.e();
            int i10 = this.f10400t;
            if (i10 != 0) {
                if (i10 != 1) {
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                o.b(obj);
                return obj;
            }
            o.b(obj);
            a aVar = new a(this.f10401u, this.f10402v, null);
            this.f10400t = 1;
            Object enqueueRetriableRequestWithRetry = NetworkUtilsKt.enqueueRetriableRequestWithRetry(aVar, this);
            return enqueueRetriableRequestWithRetry == e10 ? e10 : enqueueRetriableRequestWithRetry;
        }
    }

    @Metadata(d1 = {"\u0000\u0010\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\u0010\u0003\u001a\b\u0012\u0004\u0012\u00020\u00020\u0001*\u00020\u0000H\n¢\u0006\u0004\b\u0003\u0010\u0004"}, d2 = {"Lav/p0;", "Lcom/withpersona/sdk2/inquiry/network/core/NetworkCallResult;", "Lcom/withpersona/sdk2/inquiry/internal/fallbackmode/FallbackModeService$SessionIdResponse;", "<anonymous>", "(Lav/p0;)Lcom/withpersona/sdk2/inquiry/network/core/NetworkCallResult;"}, k = 3, mv = {2, 2, 0})
    @gu.f(c = "com.withpersona.sdk2.inquiry.internal.fallbackmode.FallbackModeApiController$createSession$sessionIdResponse$1", f = "ApiController.kt", l = {121}, m = "invokeSuspend")
    public static final class c extends m implements Function2<p0, eu.b<? super NetworkCallResult<FallbackModeService.SessionIdResponse>>, Object> {

        /* renamed from: t, reason: collision with root package name */
        public int f10407t;

        /* renamed from: v, reason: collision with root package name */
        public final /* synthetic */ InquiryAttributes f10409v;

        @Metadata(d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\u0010\u0002\u001a\b\u0012\u0004\u0012\u00020\u00010\u0000H\n¢\u0006\u0004\b\u0002\u0010\u0003"}, d2 = {"Lsw/x;", "Lcom/withpersona/sdk2/inquiry/internal/fallbackmode/FallbackModeService$SessionIdResponse;", "<anonymous>", "()Lsw/x;"}, k = 3, mv = {2, 2, 0})
        @gu.f(c = "com.withpersona.sdk2.inquiry.internal.fallbackmode.FallbackModeApiController$createSession$sessionIdResponse$1$1", f = "ApiController.kt", l = {122}, m = "invokeSuspend")
        public static final class a extends m implements Function1<eu.b<? super x<FallbackModeService.SessionIdResponse>>, Object> {

            /* renamed from: t, reason: collision with root package name */
            public int f10410t;

            /* renamed from: u, reason: collision with root package name */
            public final /* synthetic */ d f10411u;

            /* renamed from: v, reason: collision with root package name */
            public final /* synthetic */ InquiryAttributes f10412v;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            public a(d dVar, InquiryAttributes inquiryAttributes, eu.b<? super a> bVar) {
                super(1, bVar);
                this.f10411u = dVar;
                this.f10412v = inquiryAttributes;
            }

            @Override // gu.a
            public final eu.b<Unit> create(eu.b<?> bVar) {
                return new a(this.f10411u, this.f10412v, bVar);
            }

            @Override // gu.a
            public final Object invokeSuspend(Object obj) {
                Object e10 = fu.c.e();
                int i10 = this.f10410t;
                if (i10 != 0) {
                    if (i10 != 1) {
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                    o.b(obj);
                    return obj;
                }
                o.b(obj);
                FallbackModeService service = this.f10411u.getService();
                FallbackModeService.SessionIdRequest sessionIdRequest = new FallbackModeService.SessionIdRequest(this.f10412v.getTemplateId(), this.f10412v.getTemplateVersion(), this.f10412v.getInquiryId(), this.f10412v.getReferenceId(), this.f10412v.getAccountId(), up.b.a(this.f10412v.getEnvironment()), this.f10412v.getEnvironmentId(), this.f10412v.d() != null ? new InquiryFieldMap(up.a.t(this.f10412v.d())) : null, this.f10412v.getThemeSetId());
                this.f10410t = 1;
                Object b = service.b(sessionIdRequest, this);
                return b == e10 ? e10 : b;
            }

            @Override // kotlin.jvm.functions.Function1
            /* renamed from: m, reason: merged with bridge method [inline-methods] */
            public final Object invoke(eu.b<? super x<FallbackModeService.SessionIdResponse>> bVar) {
                return ((a) create(bVar)).invokeSuspend(Unit.f21504a);
            }
        }

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public c(InquiryAttributes inquiryAttributes, eu.b<? super c> bVar) {
            super(2, bVar);
            this.f10409v = inquiryAttributes;
        }

        @Override // gu.a
        public final eu.b<Unit> create(Object obj, eu.b<?> bVar) {
            return d.this.new c(this.f10409v, bVar);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(p0 p0Var, eu.b<? super NetworkCallResult<FallbackModeService.SessionIdResponse>> bVar) {
            return ((c) create(p0Var, bVar)).invokeSuspend(Unit.f21504a);
        }

        @Override // gu.a
        public final Object invokeSuspend(Object obj) {
            Object e10 = fu.c.e();
            int i10 = this.f10407t;
            if (i10 != 0) {
                if (i10 != 1) {
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                o.b(obj);
                return obj;
            }
            o.b(obj);
            a aVar = new a(d.this, this.f10409v, null);
            this.f10407t = 1;
            Object enqueueRetriableRequestWithRetry = NetworkUtilsKt.enqueueRetriableRequestWithRetry(aVar, this);
            return enqueueRetriableRequestWithRetry == e10 ? e10 : enqueueRetriableRequestWithRetry;
        }
    }

    @Metadata(k = 3, mv = {2, 2, 0}, xi = 48)
    @gu.f(c = "com.withpersona.sdk2.inquiry.internal.fallbackmode.FallbackModeApiController", f = "ApiController.kt", l = {175, 210}, m = "transition")
    /* renamed from: com.withpersona.sdk2.inquiry.internal.fallbackmode.d$d, reason: collision with other inner class name */
    public static final class C0180d extends gu.d {
        public int A;

        /* renamed from: t, reason: collision with root package name */
        public Object f10413t;

        /* renamed from: u, reason: collision with root package name */
        public Object f10414u;

        /* renamed from: v, reason: collision with root package name */
        public Object f10415v;

        /* renamed from: w, reason: collision with root package name */
        public Object f10416w;

        /* renamed from: x, reason: collision with root package name */
        public Object f10417x;

        /* renamed from: y, reason: collision with root package name */
        public /* synthetic */ Object f10418y;

        public C0180d(eu.b<? super C0180d> bVar) {
            super(bVar);
        }

        @Override // gu.a
        @Nullable
        public final Object invokeSuspend(@NotNull Object obj) {
            this.f10418y = obj;
            this.A |= Integer.MIN_VALUE;
            return d.this.h(null, null, null, this);
        }
    }

    @Metadata(d1 = {"\u0000\u0010\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\u0010\u0003\u001a\b\u0012\u0004\u0012\u00020\u00020\u0001*\u00020\u0000H\n¢\u0006\u0004\b\u0003\u0010\u0004"}, d2 = {"Lav/p0;", "Lcom/withpersona/sdk2/inquiry/network/core/NetworkCallResult;", "Lcom/withpersona/sdk2/inquiry/internal/fallbackmode/FallbackModeService$UploadUrlResponse;", "<anonymous>", "(Lav/p0;)Lcom/withpersona/sdk2/inquiry/network/core/NetworkCallResult;"}, k = 3, mv = {2, 2, 0})
    @gu.f(c = "com.withpersona.sdk2.inquiry.internal.fallbackmode.FallbackModeApiController$transition$result$1", f = "ApiController.kt", l = {176}, m = "invokeSuspend")
    public static final class e extends m implements Function2<p0, eu.b<? super NetworkCallResult<FallbackModeService.UploadUrlResponse>>, Object> {

        /* renamed from: t, reason: collision with root package name */
        public int f10420t;

        /* renamed from: v, reason: collision with root package name */
        public final /* synthetic */ String f10422v;

        /* renamed from: w, reason: collision with root package name */
        public final /* synthetic */ rp.h f10423w;

        /* renamed from: x, reason: collision with root package name */
        public final /* synthetic */ g0 f10424x;

        @Metadata(d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\u0010\u0002\u001a\b\u0012\u0004\u0012\u00020\u00010\u0000H\n¢\u0006\u0004\b\u0002\u0010\u0003"}, d2 = {"Lsw/x;", "Lcom/withpersona/sdk2/inquiry/internal/fallbackmode/FallbackModeService$UploadUrlResponse;", "<anonymous>", "()Lsw/x;"}, k = 3, mv = {2, 2, 0})
        @gu.f(c = "com.withpersona.sdk2.inquiry.internal.fallbackmode.FallbackModeApiController$transition$result$1$1", f = "ApiController.kt", l = {177}, m = "invokeSuspend")
        public static final class a extends m implements Function1<eu.b<? super x<FallbackModeService.UploadUrlResponse>>, Object> {

            /* renamed from: t, reason: collision with root package name */
            public int f10425t;

            /* renamed from: u, reason: collision with root package name */
            public final /* synthetic */ d f10426u;

            /* renamed from: v, reason: collision with root package name */
            public final /* synthetic */ String f10427v;

            /* renamed from: w, reason: collision with root package name */
            public final /* synthetic */ rp.h f10428w;

            /* renamed from: x, reason: collision with root package name */
            public final /* synthetic */ g0 f10429x;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            public a(d dVar, String str, rp.h hVar, g0 g0Var, eu.b<? super a> bVar) {
                super(1, bVar);
                this.f10426u = dVar;
                this.f10427v = str;
                this.f10428w = hVar;
                this.f10429x = g0Var;
            }

            @Override // gu.a
            public final eu.b<Unit> create(eu.b<?> bVar) {
                return new a(this.f10426u, this.f10427v, this.f10428w, this.f10429x, bVar);
            }

            @Override // gu.a
            public final Object invokeSuspend(Object obj) {
                String str;
                Object e10 = fu.c.e();
                int i10 = this.f10425t;
                if (i10 != 0) {
                    if (i10 != 1) {
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                    o.b(obj);
                    return obj;
                }
                o.b(obj);
                FallbackModeService service = this.f10426u.getService();
                String str2 = this.f10427v;
                rp.h hVar = this.f10428w;
                int f10 = this.f10426u.f();
                long a10 = this.f10429x.a();
                b0 mediaType = this.f10429x.getMediaType();
                if (mediaType == null || (str = mediaType.getMediaType()) == null) {
                    str = "application/json";
                }
                FallbackModeService.UploadUrlRequest uploadUrlRequest = new FallbackModeService.UploadUrlRequest(a10, str);
                this.f10425t = 1;
                Object a11 = service.a(str2, hVar, f10, uploadUrlRequest, this);
                return a11 == e10 ? e10 : a11;
            }

            @Override // kotlin.jvm.functions.Function1
            /* renamed from: m, reason: merged with bridge method [inline-methods] */
            public final Object invoke(eu.b<? super x<FallbackModeService.UploadUrlResponse>> bVar) {
                return ((a) create(bVar)).invokeSuspend(Unit.f21504a);
            }
        }

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public e(String str, rp.h hVar, g0 g0Var, eu.b<? super e> bVar) {
            super(2, bVar);
            this.f10422v = str;
            this.f10423w = hVar;
            this.f10424x = g0Var;
        }

        @Override // gu.a
        public final eu.b<Unit> create(Object obj, eu.b<?> bVar) {
            return d.this.new e(this.f10422v, this.f10423w, this.f10424x, bVar);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(p0 p0Var, eu.b<? super NetworkCallResult<FallbackModeService.UploadUrlResponse>> bVar) {
            return ((e) create(p0Var, bVar)).invokeSuspend(Unit.f21504a);
        }

        @Override // gu.a
        public final Object invokeSuspend(Object obj) {
            Object e10 = fu.c.e();
            int i10 = this.f10420t;
            if (i10 != 0) {
                if (i10 != 1) {
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                o.b(obj);
                return obj;
            }
            o.b(obj);
            a aVar = new a(d.this, this.f10422v, this.f10423w, this.f10424x, null);
            this.f10420t = 1;
            Object enqueueRetriableRequestWithRetry = NetworkUtilsKt.enqueueRetriableRequestWithRetry(aVar, this);
            return enqueueRetriableRequestWithRetry == e10 ? e10 : enqueueRetriableRequestWithRetry;
        }
    }

    @Metadata(d1 = {"\u0000\u0010\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\u0010\u0003\u001a\b\u0012\u0004\u0012\u00020\u00020\u0001*\u00020\u0000H\n¢\u0006\u0004\b\u0003\u0010\u0004"}, d2 = {"Lav/p0;", "Lcom/withpersona/sdk2/inquiry/network/core/NetworkCallResult;", BuildConfig.FLAVOR, "<anonymous>", "(Lav/p0;)Lcom/withpersona/sdk2/inquiry/network/core/NetworkCallResult;"}, k = 3, mv = {2, 2, 0})
    @gu.f(c = "com.withpersona.sdk2.inquiry.internal.fallbackmode.FallbackModeApiController$transition$uploadResult$1", f = "ApiController.kt", l = {211}, m = "invokeSuspend")
    public static final class f extends m implements Function2<p0, eu.b<? super NetworkCallResult<Object>>, Object> {

        /* renamed from: t, reason: collision with root package name */
        public int f10430t;

        /* renamed from: v, reason: collision with root package name */
        public final /* synthetic */ String f10432v;

        /* renamed from: w, reason: collision with root package name */
        public final /* synthetic */ g0 f10433w;

        @Metadata(d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\u0010\u0002\u001a\b\u0012\u0004\u0012\u00020\u00010\u0000H\n¢\u0006\u0004\b\u0002\u0010\u0003"}, d2 = {"Lsw/x;", BuildConfig.FLAVOR, "<anonymous>", "()Lsw/x;"}, k = 3, mv = {2, 2, 0})
        @gu.f(c = "com.withpersona.sdk2.inquiry.internal.fallbackmode.FallbackModeApiController$transition$uploadResult$1$1", f = "ApiController.kt", l = {212}, m = "invokeSuspend")
        public static final class a extends m implements Function1<eu.b<? super x<Object>>, Object> {

            /* renamed from: t, reason: collision with root package name */
            public int f10434t;

            /* renamed from: u, reason: collision with root package name */
            public final /* synthetic */ d f10435u;

            /* renamed from: v, reason: collision with root package name */
            public final /* synthetic */ String f10436v;

            /* renamed from: w, reason: collision with root package name */
            public final /* synthetic */ g0 f10437w;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            public a(d dVar, String str, g0 g0Var, eu.b<? super a> bVar) {
                super(1, bVar);
                this.f10435u = dVar;
                this.f10436v = str;
                this.f10437w = g0Var;
            }

            @Override // gu.a
            public final eu.b<Unit> create(eu.b<?> bVar) {
                return new a(this.f10435u, this.f10436v, this.f10437w, bVar);
            }

            @Override // gu.a
            public final Object invokeSuspend(Object obj) {
                Object e10 = fu.c.e();
                int i10 = this.f10434t;
                if (i10 != 0) {
                    if (i10 != 1) {
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                    o.b(obj);
                    return obj;
                }
                o.b(obj);
                FallbackModeService service = this.f10435u.getService();
                String str = this.f10436v;
                g0 g0Var = this.f10437w;
                this.f10434t = 1;
                Object d10 = service.d(str, g0Var, this);
                return d10 == e10 ? e10 : d10;
            }

            @Override // kotlin.jvm.functions.Function1
            /* renamed from: m, reason: merged with bridge method [inline-methods] */
            public final Object invoke(eu.b<? super x<Object>> bVar) {
                return ((a) create(bVar)).invokeSuspend(Unit.f21504a);
            }
        }

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public f(String str, g0 g0Var, eu.b<? super f> bVar) {
            super(2, bVar);
            this.f10432v = str;
            this.f10433w = g0Var;
        }

        @Override // gu.a
        public final eu.b<Unit> create(Object obj, eu.b<?> bVar) {
            return d.this.new f(this.f10432v, this.f10433w, bVar);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(p0 p0Var, eu.b<? super NetworkCallResult<Object>> bVar) {
            return ((f) create(p0Var, bVar)).invokeSuspend(Unit.f21504a);
        }

        @Override // gu.a
        public final Object invokeSuspend(Object obj) {
            Object e10 = fu.c.e();
            int i10 = this.f10430t;
            if (i10 != 0) {
                if (i10 != 1) {
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                o.b(obj);
                return obj;
            }
            o.b(obj);
            a aVar = new a(d.this, this.f10432v, this.f10433w, null);
            this.f10430t = 1;
            Object enqueueRetriableRequestWithRetry = NetworkUtilsKt.enqueueRetriableRequestWithRetry(aVar, this);
            return enqueueRetriableRequestWithRetry == e10 ? e10 : enqueueRetriableRequestWithRetry;
        }
    }

    public d(@NotNull FallbackModeService service, @NotNull w moshi, @NotNull i.a staticTemplateSessionFactory) {
        Intrinsics.checkNotNullParameter(service, "service");
        Intrinsics.checkNotNullParameter(moshi, "moshi");
        Intrinsics.checkNotNullParameter(staticTemplateSessionFactory, "staticTemplateSessionFactory");
        this.service = service;
        this.moshi = moshi;
        this.staticTemplateSessionFactory = staticTemplateSessionFactory;
    }

    @Override // rp.a
    @Nullable
    public Object a(@NotNull String str, @NotNull g0 g0Var, @NotNull eu.b<? super x<?>> bVar) {
        return h(str, g0Var, rp.h.f30839a, bVar);
    }

    /* JADX WARN: Code restructure failed: missing block: B:70:0x0078, code lost:
    
        if (r9 == r1) goto L58;
     */
    /* JADX WARN: Removed duplicated region for block: B:13:0x0111  */
    /* JADX WARN: Removed duplicated region for block: B:22:0x0125  */
    /* JADX WARN: Removed duplicated region for block: B:24:0x0137  */
    /* JADX WARN: Removed duplicated region for block: B:31:0x0082  */
    /* JADX WARN: Removed duplicated region for block: B:33:0x0094  */
    /* JADX WARN: Removed duplicated region for block: B:65:0x004a  */
    /* JADX WARN: Removed duplicated region for block: B:8:0x0025  */
    @Override // rp.a
    @org.jetbrains.annotations.Nullable
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public java.lang.Object b(@org.jetbrains.annotations.NotNull up.InquiryAttributes r8, @org.jetbrains.annotations.NotNull eu.b<? super zt.n<com.withpersona.sdk2.inquiry.internal.fallbackmode.i>> r9) {
        /*
            Method dump skipped, instructions count: 390
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: com.withpersona.sdk2.inquiry.internal.fallbackmode.d.b(up.e, eu.b):java.lang.Object");
    }

    @Override // rp.a
    @Nullable
    public Object c(@NotNull String str, @NotNull g0 g0Var, @NotNull eu.b<? super x<?>> bVar) {
        return h(str, g0Var, rp.h.b, bVar);
    }

    public final int f() {
        int i10 = this.requestCount + 1;
        this.requestCount = i10;
        return i10;
    }

    @NotNull
    /* renamed from: g, reason: from getter */
    public final FallbackModeService getService() {
        return this.service;
    }

    /* JADX WARN: Code restructure failed: missing block: B:39:0x0136, code lost:
    
        if (r0 == r7) goto L36;
     */
    /* JADX WARN: Removed duplicated region for block: B:28:0x00a3  */
    /* JADX WARN: Removed duplicated region for block: B:30:0x00ca  */
    /* JADX WARN: Removed duplicated region for block: B:44:0x0069  */
    /* JADX WARN: Removed duplicated region for block: B:9:0x0034  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final java.lang.Object h(java.lang.String r17, mv.g0 r18, rp.h r19, eu.b<? super sw.x<?>> r20) {
        /*
            Method dump skipped, instructions count: 382
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: com.withpersona.sdk2.inquiry.internal.fallbackmode.d.h(java.lang.String, mv.g0, rp.h, eu.b):java.lang.Object");
    }


    // --- восстановлено из DEX (com/withpersona/sdk2/inquiry/internal/fallbackmode/d$b$a) ---
    public static class a extends gu.m implements kotlin.jvm.functions.Function1 {
        java.lang.Object t;
        int u;
        up.e v;
        com.withpersona.sdk2.inquiry.internal.fallbackmode.d w;
        public a(up.e p0, com.withpersona.sdk2.inquiry.internal.fallbackmode.d p1, eu.b p2) { }
        public eu.b create(eu.b p0) { throw new UnsupportedOperationException("stub"); }
        public java.lang.Object invoke(java.lang.Object p0) { throw new UnsupportedOperationException("stub"); }
        public java.lang.Object invokeSuspend(java.lang.Object p0) { throw new UnsupportedOperationException("stub"); }
        public java.lang.Object m(eu.b p0) { throw new UnsupportedOperationException("stub"); }
    }

    // --- восстановлено из DEX (com/withpersona/sdk2/inquiry/internal/fallbackmode/d$c$a) ---
    public static class a extends gu.m implements kotlin.jvm.functions.Function1 {
        int t;
        com.withpersona.sdk2.inquiry.internal.fallbackmode.d u;
        up.e v;
        public a(com.withpersona.sdk2.inquiry.internal.fallbackmode.d p0, up.e p1, eu.b p2) { }
        public eu.b create(eu.b p0) { throw new UnsupportedOperationException("stub"); }
        public java.lang.Object invoke(java.lang.Object p0) { throw new UnsupportedOperationException("stub"); }
        public java.lang.Object invokeSuspend(java.lang.Object p0) { throw new UnsupportedOperationException("stub"); }
        public java.lang.Object m(eu.b p0) { throw new UnsupportedOperationException("stub"); }
    }

    // --- восстановлено из DEX (com/withpersona/sdk2/inquiry/internal/fallbackmode/d$e$a) ---
    public static class a extends gu.m implements kotlin.jvm.functions.Function1 {
        int t;
        com.withpersona.sdk2.inquiry.internal.fallbackmode.d u;
        java.lang.String v;
        rp.h w;
        mv.g0 x;
        public a(com.withpersona.sdk2.inquiry.internal.fallbackmode.d p0, java.lang.String p1, rp.h p2, mv.g0 p3, eu.b p4) { }
        public eu.b create(eu.b p0) { throw new UnsupportedOperationException("stub"); }
        public java.lang.Object invoke(java.lang.Object p0) { throw new UnsupportedOperationException("stub"); }
        public java.lang.Object invokeSuspend(java.lang.Object p0) { throw new UnsupportedOperationException("stub"); }
        public java.lang.Object m(eu.b p0) { throw new UnsupportedOperationException("stub"); }
    }

    // --- восстановлено из DEX (com/withpersona/sdk2/inquiry/internal/fallbackmode/d$f$a) ---
    public static class a extends gu.m implements kotlin.jvm.functions.Function1 {
        int t;
        com.withpersona.sdk2.inquiry.internal.fallbackmode.d u;
        java.lang.String v;
        mv.g0 w;
        public a(com.withpersona.sdk2.inquiry.internal.fallbackmode.d p0, java.lang.String p1, mv.g0 p2, eu.b p3) { }
        public eu.b create(eu.b p0) { throw new UnsupportedOperationException("stub"); }
        public java.lang.Object invoke(java.lang.Object p0) { throw new UnsupportedOperationException("stub"); }
        public java.lang.Object invokeSuspend(java.lang.Object p0) { throw new UnsupportedOperationException("stub"); }
        public java.lang.Object m(eu.b p0) { throw new UnsupportedOperationException("stub"); }
    }
}
