package com.withpersona.sdk2.inquiry.internal.network;

import com.github.luben.zstd.BuildConfig;
import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;

@Metadata(d1 = {"\u0000\u0010\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\u0018\u0002\n\u0002\b\t\b\u0001\u0018\u0000 \t2\u00020\u0001:\u0002\n\u0006B\u000f\u0012\u0006\u0010\u0003\u001a\u00020\u0002¢\u0006\u0004\b\u0004\u0010\u0005R\u0017\u0010\u0003\u001a\u00020\u00028\u0006¢\u0006\f\n\u0004\b\u0006\u0010\u0007\u001a\u0004\b\u0006\u0010\b¨\u0006\u000b"}, d2 = {"Lcom/withpersona/sdk2/inquiry/internal/network/TransitionBackRequest;", BuildConfig.FLAVOR, "Lcom/withpersona/sdk2/inquiry/internal/network/TransitionBackRequest$Meta;", "meta", "<init>", "(Lcom/withpersona/sdk2/inquiry/internal/network/TransitionBackRequest$Meta;)V", xe.a.f36648e, "Lcom/withpersona/sdk2/inquiry/internal/network/TransitionBackRequest$Meta;", "()Lcom/withpersona/sdk2/inquiry/internal/network/TransitionBackRequest$Meta;", k6.b.f21144e, "Meta", "inquiry-internal_release"}, k = 1, mv = {2, 2, 0}, xi = 48)
@hn.i(generateAdapter = true)
/* loaded from: classes3.dex */
public final class TransitionBackRequest {

    /* renamed from: b, reason: from kotlin metadata */
    @NotNull
    public static final Companion INSTANCE = new Companion(null);

    /* renamed from: a, reason: collision with root package name and from kotlin metadata */
    @NotNull
    public final Meta meta;

    @Metadata(d1 = {"\u0000\u0010\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\u0010\u000e\n\u0002\b\u0007\b\u0007\u0018\u00002\u00020\u0001B\u000f\u0012\u0006\u0010\u0003\u001a\u00020\u0002¢\u0006\u0004\b\u0004\u0010\u0005R\u0017\u0010\u0003\u001a\u00020\u00028\u0006¢\u0006\f\n\u0004\b\u0006\u0010\u0007\u001a\u0004\b\u0006\u0010\b¨\u0006\t"}, d2 = {"Lcom/withpersona/sdk2/inquiry/internal/network/TransitionBackRequest$Meta;", BuildConfig.FLAVOR, BuildConfig.FLAVOR, "fromStep", "<init>", "(Ljava/lang/String;)V", xe.a.f36648e, "Ljava/lang/String;", "()Ljava/lang/String;", "inquiry-internal_release"}, k = 1, mv = {2, 2, 0}, xi = 48)
    @hn.i(generateAdapter = true)
    public static final class Meta {

        /* renamed from: a, reason: collision with root package name and from kotlin metadata */
        @NotNull
        public final String fromStep;

        public Meta(@NotNull String fromStep) {
            Intrinsics.checkNotNullParameter(fromStep, "fromStep");
            this.fromStep = fromStep;
        }

        @NotNull
        /* renamed from: a, reason: from getter */
        public final String getFromStep() {
            return this.fromStep;
        }
    }

    @Metadata(d1 = {"\u0000\u001a\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\b\u0086\u0003\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\u0015\u0010\u0007\u001a\u00020\u00062\u0006\u0010\u0005\u001a\u00020\u0004¢\u0006\u0004\b\u0007\u0010\b¨\u0006\t"}, d2 = {"Lcom/withpersona/sdk2/inquiry/internal/network/TransitionBackRequest$a;", BuildConfig.FLAVOR, "<init>", "()V", BuildConfig.FLAVOR, "fromStep", "Lcom/withpersona/sdk2/inquiry/internal/network/TransitionBackRequest;", xe.a.f36648e, "(Ljava/lang/String;)Lcom/withpersona/sdk2/inquiry/internal/network/TransitionBackRequest;", "inquiry-internal_release"}, k = 1, mv = {2, 2, 0}, xi = 48)
    /* renamed from: com.withpersona.sdk2.inquiry.internal.network.TransitionBackRequest$a, reason: from kotlin metadata */
    public static final class Companion {
        public /* synthetic */ Companion(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }

        @NotNull
        public final TransitionBackRequest a(@NotNull String fromStep) {
            Intrinsics.checkNotNullParameter(fromStep, "fromStep");
            return new TransitionBackRequest(new Meta(fromStep));
        }

        public Companion() {
        }
    }

    public TransitionBackRequest(@NotNull Meta meta) {
        Intrinsics.checkNotNullParameter(meta, "meta");
        this.meta = meta;
    }

    @NotNull
    /* renamed from: a, reason: from getter */
    public final Meta getMeta() {
        return this.meta;
    }


    // --- восстановлено из DEX (com/withpersona/sdk2/inquiry/internal/network/TransitionBackRequest$a) ---
    public static class a {
        public a() { }
        public a(kotlin.jvm.internal.DefaultConstructorMarker p0) { }
        public com.withpersona.sdk2.inquiry.internal.network.TransitionBackRequest a(java.lang.String p0) { throw new UnsupportedOperationException("stub"); }
    }
}
