package com.withpersona.sdk2.inquiry.internal;

import android.os.Parcel;
import android.os.Parcelable;
import com.github.luben.zstd.BuildConfig;
import com.google.mlkit.vision.barcode.common.Barcode;
import com.withpersona.sdk2.inquiry.InquiryField;
import com.withpersona.sdk2.inquiry.network.core.InternalErrorInfo;
import com.withpersona.sdk2.inquiry.network.dto.ui.components.Title;
import com.withpersona.sdk2.inquiry.network.dto.ui.styling.StepStyle;
import java.util.LinkedHashMap;
import java.util.Map;
import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(d1 = {"\u0000\"\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u000e\n\u0002\b\u0007\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\bv\u0018\u00002\u00020\u0001:\u0004\u0006\u0007\b\tR\u0016\u0010\u0005\u001a\u0004\u0018\u00010\u00028&X¦\u0004¢\u0006\u0006\u001a\u0004\b\u0003\u0010\u0004\u0082\u0001\u0004\n\u000b\f\r¨\u0006\u000eÀ\u0006\u0003"}, d2 = {"Lcom/withpersona/sdk2/inquiry/internal/l;", "Landroid/os/Parcelable;", BuildConfig.FLAVOR, "A", "()Ljava/lang/String;", "sessionToken", k6.b.f21144e, "d", xe.a.f36648e, "c", "Lcom/withpersona/sdk2/inquiry/internal/l$a;", "Lcom/withpersona/sdk2/inquiry/internal/l$b;", "Lcom/withpersona/sdk2/inquiry/internal/l$c;", "Lcom/withpersona/sdk2/inquiry/internal/l$d;", "inquiry-internal_release"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* loaded from: classes3.dex */
public interface l extends Parcelable {

    @Metadata(d1 = {"\u0000B\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0010$\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0002\b\u0005\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u000f\b\u0087\b\u0018\u00002\u00020\u0001B?\u0012\u0006\u0010\u0003\u001a\u00020\u0002\u0012\u0006\u0010\u0004\u001a\u00020\u0002\u0012\u0012\u0010\u0007\u001a\u000e\u0012\u0004\u0012\u00020\u0002\u0012\u0004\u0012\u00020\u00060\u0005\u0012\b\u0010\b\u001a\u0004\u0018\u00010\u0002\u0012\b\u0010\t\u001a\u0004\u0018\u00010\u0002¢\u0006\u0004\b\n\u0010\u000bJ\r\u0010\r\u001a\u00020\f¢\u0006\u0004\b\r\u0010\u000eJ\u001d\u0010\u0013\u001a\u00020\u00122\u0006\u0010\u0010\u001a\u00020\u000f2\u0006\u0010\u0011\u001a\u00020\f¢\u0006\u0004\b\u0013\u0010\u0014J\u0010\u0010\u0015\u001a\u00020\u0002HÖ\u0001¢\u0006\u0004\b\u0015\u0010\u0016J\u0010\u0010\u0017\u001a\u00020\fHÖ\u0001¢\u0006\u0004\b\u0017\u0010\u000eJ\u001a\u0010\u001b\u001a\u00020\u001a2\b\u0010\u0019\u001a\u0004\u0018\u00010\u0018HÖ\u0003¢\u0006\u0004\b\u001b\u0010\u001cR\u0017\u0010\u0003\u001a\u00020\u00028\u0006¢\u0006\f\n\u0004\b\u001d\u0010\u001e\u001a\u0004\b\u001f\u0010\u0016R\u0017\u0010\u0004\u001a\u00020\u00028\u0006¢\u0006\f\n\u0004\b \u0010\u001e\u001a\u0004\b!\u0010\u0016R#\u0010\u0007\u001a\u000e\u0012\u0004\u0012\u00020\u0002\u0012\u0004\u0012\u00020\u00060\u00058\u0006¢\u0006\f\n\u0004\b\"\u0010#\u001a\u0004\b\u001d\u0010$R\u001c\u0010\b\u001a\u0004\u0018\u00010\u00028\u0016X\u0096\u0004¢\u0006\f\n\u0004\b%\u0010\u001e\u001a\u0004\b&\u0010\u0016R\u0019\u0010\t\u001a\u0004\u0018\u00010\u00028\u0006¢\u0006\f\n\u0004\b'\u0010\u001e\u001a\u0004\b(\u0010\u0016¨\u0006)"}, d2 = {"Lcom/withpersona/sdk2/inquiry/internal/l$b;", "Lcom/withpersona/sdk2/inquiry/internal/l;", BuildConfig.FLAVOR, "inquiryId", "inquiryStatus", BuildConfig.FLAVOR, "Lcom/withpersona/sdk2/inquiry/InquiryField;", "fields", "sessionToken", "redirectUri", "<init>", "(Ljava/lang/String;Ljava/lang/String;Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V", BuildConfig.FLAVOR, "describeContents", "()I", "Landroid/os/Parcel;", "dest", "flags", BuildConfig.FLAVOR, "writeToParcel", "(Landroid/os/Parcel;I)V", "toString", "()Ljava/lang/String;", "hashCode", BuildConfig.FLAVOR, "other", BuildConfig.FLAVOR, "equals", "(Ljava/lang/Object;)Z", xe.a.f36648e, "Ljava/lang/String;", "f", k6.b.f21144e, "g", "c", "Ljava/util/Map;", "()Ljava/util/Map;", "d", "A", "e", "i", "inquiry-internal_release"}, k = 1, mv = {2, 2, 0}, xi = 48)
    /* renamed from: com.withpersona.sdk2.inquiry.internal.l$b, reason: from toString */
    public static final /* data */ class Complete implements l {

        @NotNull
        public static final Parcelable.Creator<Complete> CREATOR = new a();

        /* renamed from: a, reason: collision with root package name and from kotlin metadata and from toString */
        @NotNull
        public final String inquiryId;

        /* renamed from: b, reason: from kotlin metadata and from toString */
        @NotNull
        public final String inquiryStatus;

        /* renamed from: c, reason: collision with root package name and from kotlin metadata and from toString */
        @NotNull
        public final Map<String, InquiryField> fields;

        /* renamed from: d, reason: collision with root package name and from kotlin metadata and from toString */
        @Nullable
        public final String sessionToken;

        /* renamed from: e, reason: collision with root package name and from kotlin metadata and from toString */
        @Nullable
        public final String redirectUri;

        @Metadata(k = 3, mv = {2, 2, 0}, xi = 48)
        /* renamed from: com.withpersona.sdk2.inquiry.internal.l$b$a */
        public static final class a implements Parcelable.Creator<Complete> {
            @Override // android.os.Parcelable.Creator
            /* renamed from: a, reason: merged with bridge method [inline-methods] */
            public final Complete createFromParcel(Parcel parcel) {
                Intrinsics.checkNotNullParameter(parcel, "parcel");
                String readString = parcel.readString();
                String readString2 = parcel.readString();
                int readInt = parcel.readInt();
                LinkedHashMap linkedHashMap = new LinkedHashMap(readInt);
                int i10 = 0;
                while (true) {
                    String readString3 = parcel.readString();
                    if (i10 == readInt) {
                        return new Complete(readString, readString2, linkedHashMap, readString3, parcel.readString());
                    }
                    linkedHashMap.put(readString3, parcel.readParcelable(Complete.class.getClassLoader()));
                    i10++;
                }
            }

            @Override // android.os.Parcelable.Creator
            /* renamed from: b, reason: merged with bridge method [inline-methods] */
            public final Complete[] newArray(int i10) {
                return new Complete[i10];
            }
        }

        /* JADX WARN: Multi-variable type inference failed */
        public Complete(@NotNull String inquiryId, @NotNull String inquiryStatus, @NotNull Map<String, ? extends InquiryField> fields, @Nullable String str, @Nullable String str2) {
            Intrinsics.checkNotNullParameter(inquiryId, "inquiryId");
            Intrinsics.checkNotNullParameter(inquiryStatus, "inquiryStatus");
            Intrinsics.checkNotNullParameter(fields, "fields");
            this.inquiryId = inquiryId;
            this.inquiryStatus = inquiryStatus;
            this.fields = fields;
            this.sessionToken = str;
            this.redirectUri = str2;
        }

        @Override // com.withpersona.sdk2.inquiry.internal.l
        @Nullable
        /* renamed from: A, reason: from getter */
        public String getSessionToken() {
            return this.sessionToken;
        }

        @NotNull
        public final Map<String, InquiryField> a() {
            return this.fields;
        }

        @Override // android.os.Parcelable
        public final int describeContents() {
            return 0;
        }

        public boolean equals(@Nullable Object other) {
            if (this == other) {
                return true;
            }
            if (!(other instanceof Complete)) {
                return false;
            }
            Complete complete = (Complete) other;
            return Intrinsics.c(this.inquiryId, complete.inquiryId) && Intrinsics.c(this.inquiryStatus, complete.inquiryStatus) && Intrinsics.c(this.fields, complete.fields) && Intrinsics.c(this.sessionToken, complete.sessionToken) && Intrinsics.c(this.redirectUri, complete.redirectUri);
        }

        @NotNull
        /* renamed from: f, reason: from getter */
        public final String getInquiryId() {
            return this.inquiryId;
        }

        @NotNull
        /* renamed from: g, reason: from getter */
        public final String getInquiryStatus() {
            return this.inquiryStatus;
        }

        public int hashCode() {
            int hashCode = ((((this.inquiryId.hashCode() * 31) + this.inquiryStatus.hashCode()) * 31) + this.fields.hashCode()) * 31;
            String str = this.sessionToken;
            int hashCode2 = (hashCode + (str == null ? 0 : str.hashCode())) * 31;
            String str2 = this.redirectUri;
            return hashCode2 + (str2 != null ? str2.hashCode() : 0);
        }

        @Nullable
        /* renamed from: i, reason: from getter */
        public final String getRedirectUri() {
            return this.redirectUri;
        }

        @NotNull
        public String toString() {
            return "Complete(inquiryId=" + this.inquiryId + ", inquiryStatus=" + this.inquiryStatus + ", fields=" + this.fields + ", sessionToken=" + this.sessionToken + ", redirectUri=" + this.redirectUri + ")";
        }

        @Override // android.os.Parcelable
        public final void writeToParcel(@NotNull Parcel dest, int flags) {
            Intrinsics.checkNotNullParameter(dest, "dest");
            dest.writeString(this.inquiryId);
            dest.writeString(this.inquiryStatus);
            Map<String, InquiryField> map = this.fields;
            dest.writeInt(map.size());
            for (Map.Entry<String, InquiryField> entry : map.entrySet()) {
                dest.writeString(entry.getKey());
                dest.writeParcelable(entry.getValue(), flags);
            }
            dest.writeString(this.sessionToken);
            dest.writeString(this.redirectUri);
        }
    }

    @Metadata(d1 = {"\u0000B\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0002\b\u0005\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u000f\b\u0087\b\u0018\u00002\u00020\u0001B+\u0012\b\u0010\u0003\u001a\u0004\u0018\u00010\u0002\u0012\u0006\u0010\u0005\u001a\u00020\u0004\u0012\u0006\u0010\u0007\u001a\u00020\u0006\u0012\b\u0010\b\u001a\u0004\u0018\u00010\u0002¢\u0006\u0004\b\t\u0010\nJ\r\u0010\f\u001a\u00020\u000b¢\u0006\u0004\b\f\u0010\rJ\u001d\u0010\u0012\u001a\u00020\u00112\u0006\u0010\u000f\u001a\u00020\u000e2\u0006\u0010\u0010\u001a\u00020\u000b¢\u0006\u0004\b\u0012\u0010\u0013J\u0010\u0010\u0014\u001a\u00020\u0002HÖ\u0001¢\u0006\u0004\b\u0014\u0010\u0015J\u0010\u0010\u0016\u001a\u00020\u000bHÖ\u0001¢\u0006\u0004\b\u0016\u0010\rJ\u001a\u0010\u001a\u001a\u00020\u00192\b\u0010\u0018\u001a\u0004\u0018\u00010\u0017HÖ\u0003¢\u0006\u0004\b\u001a\u0010\u001bR\u0019\u0010\u0003\u001a\u0004\u0018\u00010\u00028\u0006¢\u0006\f\n\u0004\b\u001c\u0010\u001d\u001a\u0004\b\u001e\u0010\u0015R\u0017\u0010\u0005\u001a\u00020\u00048\u0006¢\u0006\f\n\u0004\b\u001f\u0010 \u001a\u0004\b!\u0010\"R\u0017\u0010\u0007\u001a\u00020\u00068\u0006¢\u0006\f\n\u0004\b#\u0010$\u001a\u0004\b\u001c\u0010%R\u001c\u0010\b\u001a\u0004\u0018\u00010\u00028\u0016X\u0096\u0004¢\u0006\f\n\u0004\b&\u0010\u001d\u001a\u0004\b'\u0010\u0015¨\u0006("}, d2 = {"Lcom/withpersona/sdk2/inquiry/internal/l$c;", "Lcom/withpersona/sdk2/inquiry/internal/l;", BuildConfig.FLAVOR, "debugMessage", "Lds/d;", "errorCode", "Lcom/withpersona/sdk2/inquiry/network/core/InternalErrorInfo;", "cause", "sessionToken", "<init>", "(Ljava/lang/String;Lds/d;Lcom/withpersona/sdk2/inquiry/network/core/InternalErrorInfo;Ljava/lang/String;)V", BuildConfig.FLAVOR, "describeContents", "()I", "Landroid/os/Parcel;", "dest", "flags", BuildConfig.FLAVOR, "writeToParcel", "(Landroid/os/Parcel;I)V", "toString", "()Ljava/lang/String;", "hashCode", BuildConfig.FLAVOR, "other", BuildConfig.FLAVOR, "equals", "(Ljava/lang/Object;)Z", xe.a.f36648e, "Ljava/lang/String;", "f", k6.b.f21144e, "Lds/d;", "g", "()Lds/d;", "c", "Lcom/withpersona/sdk2/inquiry/network/core/InternalErrorInfo;", "()Lcom/withpersona/sdk2/inquiry/network/core/InternalErrorInfo;", "d", "A", "inquiry-internal_release"}, k = 1, mv = {2, 2, 0}, xi = 48)
    /* renamed from: com.withpersona.sdk2.inquiry.internal.l$c, reason: from toString */
    public static final /* data */ class Error implements l {

        @NotNull
        public static final Parcelable.Creator<Error> CREATOR = new a();

        /* renamed from: a, reason: collision with root package name and from kotlin metadata and from toString */
        @Nullable
        public final String debugMessage;

        /* renamed from: b, reason: from kotlin metadata and from toString */
        @NotNull
        public final ds.d errorCode;

        /* renamed from: c, reason: collision with root package name and from kotlin metadata and from toString */
        @NotNull
        public final InternalErrorInfo cause;

        /* renamed from: d, reason: collision with root package name and from kotlin metadata and from toString */
        @Nullable
        public final String sessionToken;

        @Metadata(k = 3, mv = {2, 2, 0}, xi = 48)
        /* renamed from: com.withpersona.sdk2.inquiry.internal.l$c$a */
        public static final class a implements Parcelable.Creator<Error> {
            @Override // android.os.Parcelable.Creator
            /* renamed from: a, reason: merged with bridge method [inline-methods] */
            public final Error createFromParcel(Parcel parcel) {
                Intrinsics.checkNotNullParameter(parcel, "parcel");
                return new Error(parcel.readString(), (ds.d) parcel.readParcelable(Error.class.getClassLoader()), (InternalErrorInfo) parcel.readParcelable(Error.class.getClassLoader()), parcel.readString());
            }

            @Override // android.os.Parcelable.Creator
            /* renamed from: b, reason: merged with bridge method [inline-methods] */
            public final Error[] newArray(int i10) {
                return new Error[i10];
            }
        }

        public Error(@Nullable String str, @NotNull ds.d errorCode, @NotNull InternalErrorInfo cause, @Nullable String str2) {
            Intrinsics.checkNotNullParameter(errorCode, "errorCode");
            Intrinsics.checkNotNullParameter(cause, "cause");
            this.debugMessage = str;
            this.errorCode = errorCode;
            this.cause = cause;
            this.sessionToken = str2;
        }

        @Override // com.withpersona.sdk2.inquiry.internal.l
        @Nullable
        /* renamed from: A, reason: from getter */
        public String getSessionToken() {
            return this.sessionToken;
        }

        @NotNull
        /* renamed from: a, reason: from getter */
        public final InternalErrorInfo getCause() {
            return this.cause;
        }

        @Override // android.os.Parcelable
        public final int describeContents() {
            return 0;
        }

        public boolean equals(@Nullable Object other) {
            if (this == other) {
                return true;
            }
            if (!(other instanceof Error)) {
                return false;
            }
            Error error = (Error) other;
            return Intrinsics.c(this.debugMessage, error.debugMessage) && this.errorCode == error.errorCode && Intrinsics.c(this.cause, error.cause) && Intrinsics.c(this.sessionToken, error.sessionToken);
        }

        @Nullable
        /* renamed from: f, reason: from getter */
        public final String getDebugMessage() {
            return this.debugMessage;
        }

        @NotNull
        /* renamed from: g, reason: from getter */
        public final ds.d getErrorCode() {
            return this.errorCode;
        }

        public int hashCode() {
            String str = this.debugMessage;
            int hashCode = (((((str == null ? 0 : str.hashCode()) * 31) + this.errorCode.hashCode()) * 31) + this.cause.hashCode()) * 31;
            String str2 = this.sessionToken;
            return hashCode + (str2 != null ? str2.hashCode() : 0);
        }

        @NotNull
        public String toString() {
            return "Error(debugMessage=" + this.debugMessage + ", errorCode=" + this.errorCode + ", cause=" + this.cause + ", sessionToken=" + this.sessionToken + ")";
        }

        @Override // android.os.Parcelable
        public final void writeToParcel(@NotNull Parcel dest, int flags) {
            Intrinsics.checkNotNullParameter(dest, "dest");
            dest.writeString(this.debugMessage);
            dest.writeParcelable(this.errorCode, flags);
            dest.writeParcelable(this.cause, flags);
            dest.writeString(this.sessionToken);
        }
    }

    @Metadata(d1 = {"\u00006\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u000e\n\u0002\b\u0004\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0002\b\u0005\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0007\b\u0087\b\u0018\u00002\u00020\u0001B\u0019\u0012\u0006\u0010\u0003\u001a\u00020\u0002\u0012\b\u0010\u0004\u001a\u0004\u0018\u00010\u0002¢\u0006\u0004\b\u0005\u0010\u0006J\r\u0010\b\u001a\u00020\u0007¢\u0006\u0004\b\b\u0010\tJ\u001d\u0010\u000e\u001a\u00020\r2\u0006\u0010\u000b\u001a\u00020\n2\u0006\u0010\f\u001a\u00020\u0007¢\u0006\u0004\b\u000e\u0010\u000fJ\u0010\u0010\u0010\u001a\u00020\u0002HÖ\u0001¢\u0006\u0004\b\u0010\u0010\u0011J\u0010\u0010\u0012\u001a\u00020\u0007HÖ\u0001¢\u0006\u0004\b\u0012\u0010\tJ\u001a\u0010\u0016\u001a\u00020\u00152\b\u0010\u0014\u001a\u0004\u0018\u00010\u0013HÖ\u0003¢\u0006\u0004\b\u0016\u0010\u0017R\u0017\u0010\u0003\u001a\u00020\u00028\u0006¢\u0006\f\n\u0004\b\u0018\u0010\u0019\u001a\u0004\b\u0018\u0010\u0011R\u001c\u0010\u0004\u001a\u0004\u0018\u00010\u00028\u0016X\u0096\u0004¢\u0006\f\n\u0004\b\u001a\u0010\u0019\u001a\u0004\b\u001b\u0010\u0011¨\u0006\u001c"}, d2 = {"Lcom/withpersona/sdk2/inquiry/internal/l$d;", "Lcom/withpersona/sdk2/inquiry/internal/l;", BuildConfig.FLAVOR, "inquiryId", "sessionToken", "<init>", "(Ljava/lang/String;Ljava/lang/String;)V", BuildConfig.FLAVOR, "describeContents", "()I", "Landroid/os/Parcel;", "dest", "flags", BuildConfig.FLAVOR, "writeToParcel", "(Landroid/os/Parcel;I)V", "toString", "()Ljava/lang/String;", "hashCode", BuildConfig.FLAVOR, "other", BuildConfig.FLAVOR, "equals", "(Ljava/lang/Object;)Z", xe.a.f36648e, "Ljava/lang/String;", k6.b.f21144e, "A", "inquiry-internal_release"}, k = 1, mv = {2, 2, 0}, xi = 48)
    /* renamed from: com.withpersona.sdk2.inquiry.internal.l$d, reason: from toString */
    public static final /* data */ class ReinitializeWithFallbackMode implements l {

        @NotNull
        public static final Parcelable.Creator<ReinitializeWithFallbackMode> CREATOR = new a();

        /* renamed from: a, reason: collision with root package name and from kotlin metadata and from toString */
        @NotNull
        public final String inquiryId;

        /* renamed from: b, reason: from kotlin metadata and from toString */
        @Nullable
        public final String sessionToken;

        @Metadata(k = 3, mv = {2, 2, 0}, xi = 48)
        /* renamed from: com.withpersona.sdk2.inquiry.internal.l$d$a */
        public static final class a implements Parcelable.Creator<ReinitializeWithFallbackMode> {
            @Override // android.os.Parcelable.Creator
            /* renamed from: a, reason: merged with bridge method [inline-methods] */
            public final ReinitializeWithFallbackMode createFromParcel(Parcel parcel) {
                Intrinsics.checkNotNullParameter(parcel, "parcel");
                return new ReinitializeWithFallbackMode(parcel.readString(), parcel.readString());
            }

            @Override // android.os.Parcelable.Creator
            /* renamed from: b, reason: merged with bridge method [inline-methods] */
            public final ReinitializeWithFallbackMode[] newArray(int i10) {
                return new ReinitializeWithFallbackMode[i10];
            }
        }

        public ReinitializeWithFallbackMode(@NotNull String inquiryId, @Nullable String str) {
            Intrinsics.checkNotNullParameter(inquiryId, "inquiryId");
            this.inquiryId = inquiryId;
            this.sessionToken = str;
        }

        @Override // com.withpersona.sdk2.inquiry.internal.l
        @Nullable
        /* renamed from: A, reason: from getter */
        public String getSessionToken() {
            return this.sessionToken;
        }

        @NotNull
        /* renamed from: a, reason: from getter */
        public final String getInquiryId() {
            return this.inquiryId;
        }

        @Override // android.os.Parcelable
        public final int describeContents() {
            return 0;
        }

        public boolean equals(@Nullable Object other) {
            if (this == other) {
                return true;
            }
            if (!(other instanceof ReinitializeWithFallbackMode)) {
                return false;
            }
            ReinitializeWithFallbackMode reinitializeWithFallbackMode = (ReinitializeWithFallbackMode) other;
            return Intrinsics.c(this.inquiryId, reinitializeWithFallbackMode.inquiryId) && Intrinsics.c(this.sessionToken, reinitializeWithFallbackMode.sessionToken);
        }

        public int hashCode() {
            int hashCode = this.inquiryId.hashCode() * 31;
            String str = this.sessionToken;
            return hashCode + (str == null ? 0 : str.hashCode());
        }

        @NotNull
        public String toString() {
            return "ReinitializeWithFallbackMode(inquiryId=" + this.inquiryId + ", sessionToken=" + this.sessionToken + ")";
        }

        @Override // android.os.Parcelable
        public final void writeToParcel(@NotNull Parcel dest, int flags) {
            Intrinsics.checkNotNullParameter(dest, "dest");
            dest.writeString(this.inquiryId);
            dest.writeString(this.sessionToken);
        }
    }

    @Nullable
    /* renamed from: A */
    String getSessionToken();

    @Metadata(d1 = {"\u0000@\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0010\u000b\n\u0002\b\u0005\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0002\b\u0007\n\u0002\u0010\u0000\n\u0002\b\u0019\b\u0087\b\u0018\u00002\u00020\u0001Bm\u0012\b\u0010\u0003\u001a\u0004\u0018\u00010\u0002\u0012\b\u0010\u0004\u001a\u0004\u0018\u00010\u0002\u0012\b\u0010\u0006\u001a\u0004\u0018\u00010\u0005\u0012\b\u0010\u0007\u001a\u0004\u0018\u00010\u0002\u0012\b\u0010\b\u001a\u0004\u0018\u00010\u0002\u0012\b\u0010\t\u001a\u0004\u0018\u00010\u0002\u0012\b\u0010\n\u001a\u0004\u0018\u00010\u0002\u0012\b\b\u0002\u0010\f\u001a\u00020\u000b\u0012\b\b\u0002\u0010\r\u001a\u00020\u000b\u0012\n\b\u0002\u0010\u000e\u001a\u0004\u0018\u00010\u0002¢\u0006\u0004\b\u000f\u0010\u0010J\r\u0010\u0012\u001a\u00020\u0011¢\u0006\u0004\b\u0012\u0010\u0013J\u001d\u0010\u0018\u001a\u00020\u00172\u0006\u0010\u0015\u001a\u00020\u00142\u0006\u0010\u0016\u001a\u00020\u0011¢\u0006\u0004\b\u0018\u0010\u0019J\u0084\u0001\u0010\u001a\u001a\u00020\u00002\n\b\u0002\u0010\u0003\u001a\u0004\u0018\u00010\u00022\n\b\u0002\u0010\u0004\u001a\u0004\u0018\u00010\u00022\n\b\u0002\u0010\u0006\u001a\u0004\u0018\u00010\u00052\n\b\u0002\u0010\u0007\u001a\u0004\u0018\u00010\u00022\n\b\u0002\u0010\b\u001a\u0004\u0018\u00010\u00022\n\b\u0002\u0010\t\u001a\u0004\u0018\u00010\u00022\n\b\u0002\u0010\n\u001a\u0004\u0018\u00010\u00022\b\b\u0002\u0010\f\u001a\u00020\u000b2\b\b\u0002\u0010\r\u001a\u00020\u000b2\n\b\u0002\u0010\u000e\u001a\u0004\u0018\u00010\u0002HÆ\u0001¢\u0006\u0004\b\u001a\u0010\u001bJ\u0010\u0010\u001c\u001a\u00020\u0002HÖ\u0001¢\u0006\u0004\b\u001c\u0010\u001dJ\u0010\u0010\u001e\u001a\u00020\u0011HÖ\u0001¢\u0006\u0004\b\u001e\u0010\u0013J\u001a\u0010!\u001a\u00020\u000b2\b\u0010 \u001a\u0004\u0018\u00010\u001fHÖ\u0003¢\u0006\u0004\b!\u0010\"R\u0019\u0010\u0003\u001a\u0004\u0018\u00010\u00028\u0006¢\u0006\f\n\u0004\b\u001a\u0010#\u001a\u0004\b$\u0010\u001dR\u001c\u0010\u0004\u001a\u0004\u0018\u00010\u00028\u0016X\u0096\u0004¢\u0006\f\n\u0004\b%\u0010#\u001a\u0004\b&\u0010\u001dR\u0019\u0010\u0006\u001a\u0004\u0018\u00010\u00058\u0006¢\u0006\f\n\u0004\b'\u0010(\u001a\u0004\b)\u0010*R\u0019\u0010\u0007\u001a\u0004\u0018\u00010\u00028\u0006¢\u0006\f\n\u0004\b+\u0010#\u001a\u0004\b,\u0010\u001dR\u0019\u0010\b\u001a\u0004\u0018\u00010\u00028\u0006¢\u0006\f\n\u0004\b-\u0010#\u001a\u0004\b.\u0010\u001dR\u0019\u0010\t\u001a\u0004\u0018\u00010\u00028\u0006¢\u0006\f\n\u0004\b/\u0010#\u001a\u0004\b0\u0010\u001dR\u0019\u0010\n\u001a\u0004\u0018\u00010\u00028\u0006¢\u0006\f\n\u0004\b1\u0010#\u001a\u0004\b1\u0010\u001dR\u0017\u0010\f\u001a\u00020\u000b8\u0006¢\u0006\f\n\u0004\b2\u00103\u001a\u0004\b4\u00105R\u0017\u0010\r\u001a\u00020\u000b8\u0006¢\u0006\f\n\u0004\b4\u00103\u001a\u0004\b6\u00105R\u0019\u0010\u000e\u001a\u0004\u0018\u00010\u00028\u0006¢\u0006\f\n\u0004\b$\u0010#\u001a\u0004\b7\u0010\u001d¨\u00068"}, d2 = {"Lcom/withpersona/sdk2/inquiry/internal/l$a;", "Lcom/withpersona/sdk2/inquiry/internal/l;", BuildConfig.FLAVOR, "inquiryId", "sessionToken", "Lcom/withpersona/sdk2/inquiry/network/dto/ui/styling/StepStyle;", "styles", Title.type, "message", "resumeButtonText", "cancelButtonText", BuildConfig.FLAVOR, "force", "skipBackendCall", "redirectUri", "<init>", "(Ljava/lang/String;Ljava/lang/String;Lcom/withpersona/sdk2/inquiry/network/dto/ui/styling/StepStyle;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ZZLjava/lang/String;)V", BuildConfig.FLAVOR, "describeContents", "()I", "Landroid/os/Parcel;", "dest", "flags", BuildConfig.FLAVOR, "writeToParcel", "(Landroid/os/Parcel;I)V", xe.a.f36648e, "(Ljava/lang/String;Ljava/lang/String;Lcom/withpersona/sdk2/inquiry/network/dto/ui/styling/StepStyle;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ZZLjava/lang/String;)Lcom/withpersona/sdk2/inquiry/internal/l$a;", "toString", "()Ljava/lang/String;", "hashCode", BuildConfig.FLAVOR, "other", "equals", "(Ljava/lang/Object;)Z", "Ljava/lang/String;", "j", k6.b.f21144e, "A", "c", "Lcom/withpersona/sdk2/inquiry/network/dto/ui/styling/StepStyle;", "p", "()Lcom/withpersona/sdk2/inquiry/network/dto/ui/styling/StepStyle;", "d", "getTitle", "e", "k", "f", "n", "g", "h", "Z", "i", "()Z", "o", "l", "inquiry-internal_release"}, k = 1, mv = {2, 2, 0}, xi = 48)
    /* renamed from: com.withpersona.sdk2.inquiry.internal.l$a, reason: from toString */
    public static final /* data */ class Cancel implements l {

        @NotNull
        public static final Parcelable.Creator<Cancel> CREATOR = new C0183a();

        /* renamed from: a, reason: collision with root package name and from kotlin metadata and from toString */
        @Nullable
        public final String inquiryId;

        /* renamed from: b, reason: from kotlin metadata and from toString */
        @Nullable
        public final String sessionToken;

        /* renamed from: c, reason: collision with root package name and from kotlin metadata and from toString */
        @Nullable
        public final StepStyle styles;

        /* renamed from: d, reason: collision with root package name and from kotlin metadata and from toString */
        @Nullable
        public final String title;

        /* renamed from: e, reason: collision with root package name and from kotlin metadata and from toString */
        @Nullable
        public final String message;

        /* renamed from: f, reason: collision with root package name and from kotlin metadata and from toString */
        @Nullable
        public final String resumeButtonText;

        /* renamed from: g, reason: collision with root package name and from kotlin metadata and from toString */
        @Nullable
        public final String cancelButtonText;

        /* renamed from: h, reason: collision with root package name and from kotlin metadata and from toString */
        public final boolean force;

        /* renamed from: i, reason: collision with root package name and from kotlin metadata and from toString */
        public final boolean skipBackendCall;

        /* renamed from: j, reason: collision with root package name and from kotlin metadata and from toString */
        @Nullable
        public final String redirectUri;

        @Metadata(k = 3, mv = {2, 2, 0}, xi = 48)
        /* renamed from: com.withpersona.sdk2.inquiry.internal.l$a$a, reason: collision with other inner class name */
        public static final class C0183a implements Parcelable.Creator<Cancel> {
            @Override // android.os.Parcelable.Creator
            /* renamed from: a, reason: merged with bridge method [inline-methods] */
            public final Cancel createFromParcel(Parcel parcel) {
                boolean z10;
                Intrinsics.checkNotNullParameter(parcel, "parcel");
                String readString = parcel.readString();
                String readString2 = parcel.readString();
                StepStyle stepStyle = (StepStyle) parcel.readParcelable(Cancel.class.getClassLoader());
                String readString3 = parcel.readString();
                String readString4 = parcel.readString();
                String readString5 = parcel.readString();
                String readString6 = parcel.readString();
                boolean z11 = false;
                if (parcel.readInt() != 0) {
                    z10 = false;
                    z11 = true;
                } else {
                    z10 = false;
                }
                return new Cancel(readString, readString2, stepStyle, readString3, readString4, readString5, readString6, z11, parcel.readInt() == 0 ? z10 : true, parcel.readString());
            }

            @Override // android.os.Parcelable.Creator
            /* renamed from: b, reason: merged with bridge method [inline-methods] */
            public final Cancel[] newArray(int i10) {
                return new Cancel[i10];
            }
        }

        public Cancel(@Nullable String str, @Nullable String str2, @Nullable StepStyle stepStyle, @Nullable String str3, @Nullable String str4, @Nullable String str5, @Nullable String str6, boolean z10, boolean z11, @Nullable String str7) {
            this.inquiryId = str;
            this.sessionToken = str2;
            this.styles = stepStyle;
            this.title = str3;
            this.message = str4;
            this.resumeButtonText = str5;
            this.cancelButtonText = str6;
            this.force = z10;
            this.skipBackendCall = z11;
            this.redirectUri = str7;
        }

        public static /* synthetic */ Cancel f(Cancel cancel, String str, String str2, StepStyle stepStyle, String str3, String str4, String str5, String str6, boolean z10, boolean z11, String str7, int i10, Object obj) {
            if ((i10 & 1) != 0) {
                str = cancel.inquiryId;
            }
            if ((i10 & 2) != 0) {
                str2 = cancel.sessionToken;
            }
            if ((i10 & 4) != 0) {
                stepStyle = cancel.styles;
            }
            if ((i10 & 8) != 0) {
                str3 = cancel.title;
            }
            if ((i10 & 16) != 0) {
                str4 = cancel.message;
            }
            if ((i10 & 32) != 0) {
                str5 = cancel.resumeButtonText;
            }
            if ((i10 & 64) != 0) {
                str6 = cancel.cancelButtonText;
            }
            if ((i10 & Barcode.FORMAT_ITF) != 0) {
                z10 = cancel.force;
            }
            if ((i10 & Barcode.FORMAT_QR_CODE) != 0) {
                z11 = cancel.skipBackendCall;
            }
            if ((i10 & Barcode.FORMAT_UPC_A) != 0) {
                str7 = cancel.redirectUri;
            }
            boolean z12 = z11;
            String str8 = str7;
            String str9 = str6;
            boolean z13 = z10;
            String str10 = str4;
            String str11 = str5;
            return cancel.a(str, str2, stepStyle, str3, str10, str11, str9, z13, z12, str8);
        }

        @Override // com.withpersona.sdk2.inquiry.internal.l
        @Nullable
        /* renamed from: A, reason: from getter */
        public String getSessionToken() {
            return this.sessionToken;
        }

        @NotNull
        public final Cancel a(@Nullable String inquiryId, @Nullable String sessionToken, @Nullable StepStyle styles, @Nullable String title, @Nullable String message, @Nullable String resumeButtonText, @Nullable String cancelButtonText, boolean force, boolean skipBackendCall, @Nullable String redirectUri) {
            return new Cancel(inquiryId, sessionToken, styles, title, message, resumeButtonText, cancelButtonText, force, skipBackendCall, redirectUri);
        }

        @Override // android.os.Parcelable
        public final int describeContents() {
            return 0;
        }

        public boolean equals(@Nullable Object other) {
            if (this == other) {
                return true;
            }
            if (!(other instanceof Cancel)) {
                return false;
            }
            Cancel cancel = (Cancel) other;
            return Intrinsics.c(this.inquiryId, cancel.inquiryId) && Intrinsics.c(this.sessionToken, cancel.sessionToken) && Intrinsics.c(this.styles, cancel.styles) && Intrinsics.c(this.title, cancel.title) && Intrinsics.c(this.message, cancel.message) && Intrinsics.c(this.resumeButtonText, cancel.resumeButtonText) && Intrinsics.c(this.cancelButtonText, cancel.cancelButtonText) && this.force == cancel.force && this.skipBackendCall == cancel.skipBackendCall && Intrinsics.c(this.redirectUri, cancel.redirectUri);
        }

        @Nullable
        /* renamed from: g, reason: from getter */
        public final String getCancelButtonText() {
            return this.cancelButtonText;
        }

        @Nullable
        public final String getTitle() {
            return this.title;
        }

        public int hashCode() {
            String str = this.inquiryId;
            int hashCode = (str == null ? 0 : str.hashCode()) * 31;
            String str2 = this.sessionToken;
            int hashCode2 = (hashCode + (str2 == null ? 0 : str2.hashCode())) * 31;
            StepStyle stepStyle = this.styles;
            int hashCode3 = (hashCode2 + (stepStyle == null ? 0 : stepStyle.hashCode())) * 31;
            String str3 = this.title;
            int hashCode4 = (hashCode3 + (str3 == null ? 0 : str3.hashCode())) * 31;
            String str4 = this.message;
            int hashCode5 = (hashCode4 + (str4 == null ? 0 : str4.hashCode())) * 31;
            String str5 = this.resumeButtonText;
            int hashCode6 = (hashCode5 + (str5 == null ? 0 : str5.hashCode())) * 31;
            String str6 = this.cancelButtonText;
            int hashCode7 = (((((hashCode6 + (str6 == null ? 0 : str6.hashCode())) * 31) + Boolean.hashCode(this.force)) * 31) + Boolean.hashCode(this.skipBackendCall)) * 31;
            String str7 = this.redirectUri;
            return hashCode7 + (str7 != null ? str7.hashCode() : 0);
        }

        /* renamed from: i, reason: from getter */
        public final boolean getForce() {
            return this.force;
        }

        @Nullable
        /* renamed from: j, reason: from getter */
        public final String getInquiryId() {
            return this.inquiryId;
        }

        @Nullable
        /* renamed from: k, reason: from getter */
        public final String getMessage() {
            return this.message;
        }

        @Nullable
        /* renamed from: l, reason: from getter */
        public final String getRedirectUri() {
            return this.redirectUri;
        }

        @Nullable
        /* renamed from: n, reason: from getter */
        public final String getResumeButtonText() {
            return this.resumeButtonText;
        }

        /* renamed from: o, reason: from getter */
        public final boolean getSkipBackendCall() {
            return this.skipBackendCall;
        }

        @Nullable
        /* renamed from: p, reason: from getter */
        public final StepStyle getStyles() {
            return this.styles;
        }

        @NotNull
        public String toString() {
            return "Cancel(inquiryId=" + this.inquiryId + ", sessionToken=" + this.sessionToken + ", styles=" + this.styles + ", title=" + this.title + ", message=" + this.message + ", resumeButtonText=" + this.resumeButtonText + ", cancelButtonText=" + this.cancelButtonText + ", force=" + this.force + ", skipBackendCall=" + this.skipBackendCall + ", redirectUri=" + this.redirectUri + ")";
        }

        @Override // android.os.Parcelable
        public final void writeToParcel(@NotNull Parcel dest, int flags) {
            Intrinsics.checkNotNullParameter(dest, "dest");
            dest.writeString(this.inquiryId);
            dest.writeString(this.sessionToken);
            dest.writeParcelable(this.styles, flags);
            dest.writeString(this.title);
            dest.writeString(this.message);
            dest.writeString(this.resumeButtonText);
            dest.writeString(this.cancelButtonText);
            dest.writeInt(this.force ? 1 : 0);
            dest.writeInt(this.skipBackendCall ? 1 : 0);
            dest.writeString(this.redirectUri);
        }

        public /* synthetic */ Cancel(String str, String str2, StepStyle stepStyle, String str3, String str4, String str5, String str6, boolean z10, boolean z11, String str7, int i10, DefaultConstructorMarker defaultConstructorMarker) {
            this(str, str2, stepStyle, str3, str4, str5, str6, (i10 & Barcode.FORMAT_ITF) != 0 ? false : z10, (i10 & Barcode.FORMAT_QR_CODE) != 0 ? false : z11, (i10 & Barcode.FORMAT_UPC_A) != 0 ? null : str7);
        }
    }


    // --- восстановлено из DEX (com/withpersona/sdk2/inquiry/internal/l$a$a) ---
    public static class a implements android.os.Parcelable.Creator {
        public a() { }
        public com.withpersona.sdk2.inquiry.internal.l.a a(android.os.Parcel p0) { throw new UnsupportedOperationException("stub"); }
        public com.withpersona.sdk2.inquiry.internal.l.a[] b(int p0) { throw new UnsupportedOperationException("stub"); }
        public java.lang.Object createFromParcel(android.os.Parcel p0) { throw new UnsupportedOperationException("stub"); }
        public java.lang.Object[] newArray(int p0) { throw new UnsupportedOperationException("stub"); }
    }

    // --- восстановлено из DEX (com/withpersona/sdk2/inquiry/internal/l$b) ---
    public static class b implements com.withpersona.sdk2.inquiry.internal.l {
        android.os.Parcelable.Creator CREATOR;
        java.lang.String a;
        java.lang.String b;
        java.util.Map c;
        java.lang.String d;
        java.lang.String e;
        public b(java.lang.String p0, java.lang.String p1, java.util.Map p2, java.lang.String p3, java.lang.String p4) { }
        public java.lang.String A() { throw new UnsupportedOperationException("stub"); }
        public java.util.Map a() { throw new UnsupportedOperationException("stub"); }
        public int describeContents() { throw new UnsupportedOperationException("stub"); }
        public boolean equals(java.lang.Object p0) { throw new UnsupportedOperationException("stub"); }
        public java.lang.String f() { throw new UnsupportedOperationException("stub"); }
        public java.lang.String g() { throw new UnsupportedOperationException("stub"); }
        public int hashCode() { throw new UnsupportedOperationException("stub"); }
        public java.lang.String i() { throw new UnsupportedOperationException("stub"); }
        public java.lang.String toString() { throw new UnsupportedOperationException("stub"); }
        public void writeToParcel(android.os.Parcel p0, int p1) { throw new UnsupportedOperationException("stub"); }
    }

    // --- восстановлено из DEX (com/withpersona/sdk2/inquiry/internal/l$b$a) ---
    public static class a implements android.os.Parcelable.Creator {
        public a() { }
        public com.withpersona.sdk2.inquiry.internal.l.b a(android.os.Parcel p0) { throw new UnsupportedOperationException("stub"); }
        public com.withpersona.sdk2.inquiry.internal.l.b[] b(int p0) { throw new UnsupportedOperationException("stub"); }
        public java.lang.Object createFromParcel(android.os.Parcel p0) { throw new UnsupportedOperationException("stub"); }
        public java.lang.Object[] newArray(int p0) { throw new UnsupportedOperationException("stub"); }
    }

    // --- восстановлено из DEX (com/withpersona/sdk2/inquiry/internal/l$c) ---
    public static class c implements com.withpersona.sdk2.inquiry.internal.l {
        android.os.Parcelable.Creator CREATOR;
        java.lang.String a;
        ds.d b;
        com.withpersona.sdk2.inquiry.network.core.InternalErrorInfo c;
        java.lang.String d;
        public c(java.lang.String p0, ds.d p1, com.withpersona.sdk2.inquiry.network.core.InternalErrorInfo p2, java.lang.String p3) { }
        public java.lang.String A() { throw new UnsupportedOperationException("stub"); }
        public com.withpersona.sdk2.inquiry.network.core.InternalErrorInfo a() { throw new UnsupportedOperationException("stub"); }
        public int describeContents() { throw new UnsupportedOperationException("stub"); }
        public boolean equals(java.lang.Object p0) { throw new UnsupportedOperationException("stub"); }
        public java.lang.String f() { throw new UnsupportedOperationException("stub"); }
        public ds.d g() { throw new UnsupportedOperationException("stub"); }
        public int hashCode() { throw new UnsupportedOperationException("stub"); }
        public java.lang.String toString() { throw new UnsupportedOperationException("stub"); }
        public void writeToParcel(android.os.Parcel p0, int p1) { throw new UnsupportedOperationException("stub"); }
    }

    // --- восстановлено из DEX (com/withpersona/sdk2/inquiry/internal/l$c$a) ---
    public static class a implements android.os.Parcelable.Creator {
        public a() { }
        public com.withpersona.sdk2.inquiry.internal.l.c a(android.os.Parcel p0) { throw new UnsupportedOperationException("stub"); }
        public com.withpersona.sdk2.inquiry.internal.l.c[] b(int p0) { throw new UnsupportedOperationException("stub"); }
        public java.lang.Object createFromParcel(android.os.Parcel p0) { throw new UnsupportedOperationException("stub"); }
        public java.lang.Object[] newArray(int p0) { throw new UnsupportedOperationException("stub"); }
    }

    // --- восстановлено из DEX (com/withpersona/sdk2/inquiry/internal/l$d) ---
    public static class d implements com.withpersona.sdk2.inquiry.internal.l {
        android.os.Parcelable.Creator CREATOR;
        java.lang.String a;
        java.lang.String b;
        public d(java.lang.String p0, java.lang.String p1) { }
        public java.lang.String A() { throw new UnsupportedOperationException("stub"); }
        public java.lang.String a() { throw new UnsupportedOperationException("stub"); }
        public int describeContents() { throw new UnsupportedOperationException("stub"); }
        public boolean equals(java.lang.Object p0) { throw new UnsupportedOperationException("stub"); }
        public int hashCode() { throw new UnsupportedOperationException("stub"); }
        public java.lang.String toString() { throw new UnsupportedOperationException("stub"); }
        public void writeToParcel(android.os.Parcel p0, int p1) { throw new UnsupportedOperationException("stub"); }
    }

    // --- восстановлено из DEX (com/withpersona/sdk2/inquiry/internal/l$d$a) ---
    public static class a implements android.os.Parcelable.Creator {
        public a() { }
        public com.withpersona.sdk2.inquiry.internal.l.d a(android.os.Parcel p0) { throw new UnsupportedOperationException("stub"); }
        public com.withpersona.sdk2.inquiry.internal.l.d[] b(int p0) { throw new UnsupportedOperationException("stub"); }
        public java.lang.Object createFromParcel(android.os.Parcel p0) { throw new UnsupportedOperationException("stub"); }
        public java.lang.Object[] newArray(int p0) { throw new UnsupportedOperationException("stub"); }
    }
}
