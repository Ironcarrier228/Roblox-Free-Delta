package com.google.firebase.concurrent;

import ag.b;
import android.annotation.SuppressLint;
import android.os.StrictMode;
import com.google.firebase.components.ComponentRegistrar;

import java.util.Arrays;
import java.util.List;
import java.util.concurrent.Executor;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ThreadFactory;
import mf.a;
import mf.d;
import of.c;
import of.e0;
import of.g;
import of.x;
import pf.o;

@SuppressLint({"ThreadPoolCreation"})
/* loaded from: classes2.dex */
public class ExecutorsRegistrar implements ComponentRegistrar {

    /* renamed from: a, reason: collision with root package name */
    public static final x<ScheduledExecutorService> f8599a = new x<>(new b() { // from class: pf.q
        @Override // ag.b
        public final Object get() {
            ScheduledExecutorService m10;
            m10 = ExecutorsRegistrar.m(Executors.newFixedThreadPool(4, ExecutorsRegistrar.k("Firebase Background", 10, ExecutorsRegistrar.i())));
            return m10;
        }
    });
    public static final x<ScheduledExecutorService> b = new x<>(new b() { // from class: pf.r
        @Override // ag.b
        public final Object get() {
            ScheduledExecutorService m10;
            m10 = ExecutorsRegistrar.m(Executors.newFixedThreadPool(Math.max(2, Runtime.getRuntime().availableProcessors()), ExecutorsRegistrar.k("Firebase Lite", 0, ExecutorsRegistrar.l())));
            return m10;
        }
    });

    /* renamed from: c, reason: collision with root package name */
    public static final x<ScheduledExecutorService> f8600c = new x<>(new b() { // from class: pf.s
        @Override // ag.b
        public final Object get() {
            ScheduledExecutorService m10;
            m10 = ExecutorsRegistrar.m(Executors.newCachedThreadPool(ExecutorsRegistrar.j("Firebase Blocking", 11)));
            return m10;
        }
    });

    /* renamed from: d, reason: collision with root package name */
    public static final x<ScheduledExecutorService> f8601d = new x<>(new b() { // from class: pf.t
        @Override // ag.b
        public final Object get() {
            ScheduledExecutorService newSingleThreadScheduledExecutor;
            newSingleThreadScheduledExecutor = Executors.newSingleThreadScheduledExecutor(ExecutorsRegistrar.j("Firebase Scheduler", 0));
            return newSingleThreadScheduledExecutor;
        }
    });

    public static StrictMode.ThreadPolicy i() {
        StrictMode.ThreadPolicy.Builder detectNetwork = new StrictMode.ThreadPolicy.Builder().detectNetwork();
        detectNetwork.detectResourceMismatches();
        detectNetwork.detectUnbufferedIo();
        return detectNetwork.penaltyLog().build();
    }

    public static ThreadFactory j(String str, int i10) {
        return new pf.b(str, i10, null);
    }

    public static ThreadFactory k(String str, int i10, StrictMode.ThreadPolicy threadPolicy) {
        return new pf.b(str, i10, threadPolicy);
    }

    public static StrictMode.ThreadPolicy l() {
        return new StrictMode.ThreadPolicy.Builder().detectAll().penaltyLog().build();
    }

    public static ScheduledExecutorService m(ExecutorService executorService) {
        return new o(executorService, f8601d.get());
    }

    @Override // com.google.firebase.components.ComponentRegistrar
    public List<c<?>> getComponents() {
        return Arrays.asList(c.f(e0.a(a.class, ScheduledExecutorService.class), e0.a(a.class, ExecutorService.class), e0.a(a.class, Executor.class)).f(new g() { // from class: pf.u
            @Override // of.g
            public final Object create(of.d dVar) {
                ScheduledExecutorService scheduledExecutorService;
                scheduledExecutorService = ExecutorsRegistrar.f8599a.get();
                return scheduledExecutorService;
            }
        }).d(), c.f(e0.a(mf.b.class, ScheduledExecutorService.class), e0.a(mf.b.class, ExecutorService.class), e0.a(mf.b.class, Executor.class)).f(new g() { // from class: pf.v
            @Override // of.g
            public final Object create(of.d dVar) {
                ScheduledExecutorService scheduledExecutorService;
                scheduledExecutorService = ExecutorsRegistrar.f8600c.get();
                return scheduledExecutorService;
            }
        }).d(), c.f(e0.a(mf.c.class, ScheduledExecutorService.class), e0.a(mf.c.class, ExecutorService.class), e0.a(mf.c.class, Executor.class)).f(new g() { // from class: pf.w
            @Override // of.g
            public final Object create(of.d dVar) {
                ScheduledExecutorService scheduledExecutorService;
                scheduledExecutorService = ExecutorsRegistrar.b.get();
                return scheduledExecutorService;
            }
        }).d(), c.e(e0.a(d.class, Executor.class)).f(new g() { // from class: pf.x
            @Override // of.g
            public final Object create(of.d dVar) {
                Executor executor;
                executor = a0.INSTANCE;
                return executor;
            }
        }).d());
    }
}
