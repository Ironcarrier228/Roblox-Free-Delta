package com.google.android.gms.identitycredentials;

import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.ResultReceiver;
import androidx.annotation.NonNull;
import com.github.luben.zstd.BuildConfig;
import com.google.android.gms.common.internal.ReflectedParcelable;
import java.util.List;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import ta.q;
import ta.x;
import xe.a;

@Metadata(d1 = {"\u0000B\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0018\b\u0007\u0018\u0000 *2\u00020\u00012\u00020\u0002:\u0001+B\u0011\b\u0017\u0012\u0006\u0010\u0004\u001a\u00020\u0003¢\u0006\u0004\b\u0005\u0010\u0006B9\b\u0007\u0012\u000e\b\u0001\u0010\t\u001a\b\u0012\u0004\u0012\u00020\b0\u0007\u0012\b\b\u0001\u0010\n\u001a\u00020\u0003\u0012\n\b\u0003\u0010\f\u001a\u0004\u0018\u00010\u000b\u0012\b\b\u0001\u0010\u000e\u001a\u00020\r¢\u0006\u0004\b\u0005\u0010\u000fJ\u001f\u0010\u0015\u001a\u00020\u00142\u0006\u0010\u0011\u001a\u00020\u00102\u0006\u0010\u0013\u001a\u00020\u0012H\u0016¢\u0006\u0004\b\u0015\u0010\u0016J\u000f\u0010\u0017\u001a\u00020\u0003H\u0007¢\u0006\u0004\b\u0017\u0010\u0018R \u0010\t\u001a\b\u0012\u0004\u0012\u00020\b0\u00078\u0006X\u0087\u0004¢\u0006\f\n\u0004\b\u0019\u0010\u001a\u001a\u0004\b\u001b\u0010\u001cR\u001a\u0010\n\u001a\u00020\u00038\u0006X\u0087\u0004¢\u0006\f\n\u0004\b\u001d\u0010\u001e\u001a\u0004\b\u001f\u0010\u0018R\u001c\u0010\f\u001a\u0004\u0018\u00010\u000b8\u0006X\u0087\u0004¢\u0006\f\n\u0004\b \u0010!\u001a\u0004\b\"\u0010#R \u0010\u000e\u001a\u00020\r8\u0006X\u0087\u0004¢\u0006\u0012\n\u0004\b$\u0010%\u0012\u0004\b(\u0010)\u001a\u0004\b&\u0010'¨\u0006,"}, d2 = {"Lcom/google/android/gms/identitycredentials/GetCredentialRequest;", "Lp9/a;", "Lcom/google/android/gms/common/internal/ReflectedParcelable;", "Landroid/os/Bundle;", "bundle", "<init>", "(Landroid/os/Bundle;)V", BuildConfig.FLAVOR, "Lta/q;", "credentialOptions", "data", BuildConfig.FLAVOR, "origin", "Landroid/os/ResultReceiver;", "resultReceiver", "(Ljava/util/List;Landroid/os/Bundle;Ljava/lang/String;Landroid/os/ResultReceiver;)V", "Landroid/os/Parcel;", "dest", BuildConfig.FLAVOR, "flags", BuildConfig.FLAVOR, "writeToParcel", "(Landroid/os/Parcel;I)V", "toBundle", "()Landroid/os/Bundle;", "f", "Ljava/util/List;", "A3", "()Ljava/util/List;", "g", "Landroid/os/Bundle;", "B3", "h", "Ljava/lang/String;", "C3", "()Ljava/lang/String;", "i", "Landroid/os/ResultReceiver;", "D3", "()Landroid/os/ResultReceiver;", "getResultReceiver$annotations", "()V", "j", a.f36648e, "java.com.google.android.gmscore.integ.client.identity_credentials_identity_credentials"}, k = 1, mv = {2, 1, 0}, xi = 48)
/* loaded from: classes.dex */
public final class GetCredentialRequest extends p9.a implements ReflectedParcelable {

    /* renamed from: f, reason: collision with root package name and from kotlin metadata */
    @NotNull
    public final List<q> credentialOptions;

    /* renamed from: g, reason: collision with root package name and from kotlin metadata */
    @NotNull
    public final Bundle data;

    /* renamed from: h, reason: collision with root package name and from kotlin metadata */
    @Nullable
    public final String origin;

    /* renamed from: i, reason: collision with root package name and from kotlin metadata */
    @NotNull
    public final ResultReceiver resultReceiver;

    @NotNull
    public static final Parcelable.Creator<GetCredentialRequest> CREATOR = new x();

    public GetCredentialRequest(@NonNull List<q> credentialOptions, @NonNull Bundle data, @Nullable String str, @NonNull ResultReceiver resultReceiver) {
        Intrinsics.checkNotNullParameter(credentialOptions, "credentialOptions");
        Intrinsics.checkNotNullParameter(data, "data");
        Intrinsics.checkNotNullParameter(resultReceiver, "resultReceiver");
        this.credentialOptions = credentialOptions;
        this.data = data;
        this.origin = str;
        this.resultReceiver = resultReceiver;
    }

    @NotNull
    public final List<q> A3() {
        return this.credentialOptions;
    }

    @NotNull
    /* renamed from: B3, reason: from getter */
    public final Bundle getData() {
        return this.data;
    }

    /* renamed from: C3, reason: from getter */
    public final String getOrigin() {
        return this.origin;
    }

    @NotNull
    /* renamed from: D3, reason: from getter */
    public final ResultReceiver getResultReceiver() {
        return this.resultReceiver;
    }

    @Override // android.os.Parcelable
    public void writeToParcel(@NonNull Parcel dest, int flags) {
        Intrinsics.checkNotNullParameter(dest, "dest");
        x.c(this, dest, flags);
    }


    // --- восстановлено из DEX (com/google/android/gms/identitycredentials/GetCredentialRequest$a) ---
    public static class a {
        public a() { }
        public a(kotlin.jvm.internal.DefaultConstructorMarker p0) { }
    }
}
