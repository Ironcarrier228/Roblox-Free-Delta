package com.google.android.material.bottomappbar;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.drawable.Drawable;
import android.os.Parcel;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import androidx.annotation.NonNull;
import androidx.appcompat.widget.ActionMenuView;
import androidx.appcompat.widget.Toolbar;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.core.view.o0;
import bd.r;
import com.google.android.material.behavior.HideBottomViewOnScrollBehavior;
import com.google.android.material.floatingactionbutton.ExtendedFloatingActionButton;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.mlkit.common.MlKitException;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.List;
import jc.j;

/* loaded from: classes2.dex */
public class BottomAppBar extends Toolbar implements CoordinatorLayout.b {

    /* renamed from: s0, reason: collision with root package name */
    public static final int f7466s0 = j.f20452o;

    /* renamed from: t0, reason: collision with root package name */
    public static final int f7467t0 = jc.b.F;

    /* renamed from: u0, reason: collision with root package name */
    public static final int f7468u0 = jc.b.P;
    public Integer T;
    public final id.g U;
    public Animator V;
    public Animator W;

    /* renamed from: a0, reason: collision with root package name */
    public int f7469a0;

    /* renamed from: b0, reason: collision with root package name */
    public int f7470b0;

    /* renamed from: c0, reason: collision with root package name */
    public int f7471c0;

    /* renamed from: d0, reason: collision with root package name */
    public final int f7472d0;

    /* renamed from: e0, reason: collision with root package name */
    public int f7473e0;

    /* renamed from: f0, reason: collision with root package name */
    public int f7474f0;

    /* renamed from: g0, reason: collision with root package name */
    public final boolean f7475g0;

    /* renamed from: h0, reason: collision with root package name */
    public boolean f7476h0;

    /* renamed from: i0, reason: collision with root package name */
    public int f7477i0;

    /* renamed from: j0, reason: collision with root package name */
    public ArrayList<g> f7478j0;

    /* renamed from: k0, reason: collision with root package name */
    public int f7479k0;

    /* renamed from: l0, reason: collision with root package name */
    public boolean f7480l0;

    /* renamed from: m0, reason: collision with root package name */
    public boolean f7481m0;

    /* renamed from: n0, reason: collision with root package name */
    public Behavior f7482n0;

    /* renamed from: o0, reason: collision with root package name */
    public int f7483o0;

    /* renamed from: p0, reason: collision with root package name */
    public int f7484p0;

    /* renamed from: q0, reason: collision with root package name */
    public int f7485q0;

    /* renamed from: r0, reason: collision with root package name */
    @NonNull
    public AnimatorListenerAdapter f7486r0;

    public class a extends AnimatorListenerAdapter {
        public a() {
        }

        @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
        public void onAnimationEnd(Animator animator) {
            BottomAppBar.this.v0();
            BottomAppBar.this.V = null;
        }

        @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
        public void onAnimationStart(Animator animator) {
            BottomAppBar.this.w0();
        }
    }

    public class b extends FloatingActionButton.b {

        /* renamed from: a, reason: collision with root package name */
        public final /* synthetic */ int f7493a;

        public class a extends FloatingActionButton.b {
            public a() {
            }

            @Override // com.google.android.material.floatingactionbutton.FloatingActionButton.b
            public void b(FloatingActionButton floatingActionButton) {
                BottomAppBar.this.v0();
            }
        }

        public b(int i10) {
            this.f7493a = i10;
        }

        @Override // com.google.android.material.floatingactionbutton.FloatingActionButton.b
        public void a(@NonNull FloatingActionButton floatingActionButton) {
            floatingActionButton.setTranslationX(BottomAppBar.this.A0(this.f7493a));
            floatingActionButton.s(new a());
        }
    }

    public class c extends AnimatorListenerAdapter {
        public c() {
        }

        @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
        public void onAnimationEnd(Animator animator) {
            BottomAppBar.this.v0();
            BottomAppBar.this.f7480l0 = false;
            BottomAppBar.this.W = null;
        }

        @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
        public void onAnimationStart(Animator animator) {
            BottomAppBar.this.w0();
        }
    }

    public class d extends AnimatorListenerAdapter {

        /* renamed from: a, reason: collision with root package name */
        public boolean f7496a;
        public final /* synthetic */ ActionMenuView b;

        /* renamed from: c, reason: collision with root package name */
        public final /* synthetic */ int f7497c;

        /* renamed from: d, reason: collision with root package name */
        public final /* synthetic */ boolean f7498d;

        public d(ActionMenuView actionMenuView, int i10, boolean z10) {
            this.b = actionMenuView;
            this.f7497c = i10;
            this.f7498d = z10;
        }

        @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
        public void onAnimationCancel(Animator animator) {
            this.f7496a = true;
        }

        @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
        public void onAnimationEnd(Animator animator) {
            if (this.f7496a) {
                return;
            }
            boolean z10 = BottomAppBar.this.f7479k0 != 0;
            BottomAppBar bottomAppBar = BottomAppBar.this;
            bottomAppBar.F0(bottomAppBar.f7479k0);
            BottomAppBar.this.L0(this.b, this.f7497c, this.f7498d, z10);
        }
    }

    public class e implements Runnable {

        /* renamed from: a, reason: collision with root package name */
        public final /* synthetic */ ActionMenuView f7500a;
        public final /* synthetic */ int b;

        /* renamed from: c, reason: collision with root package name */
        public final /* synthetic */ boolean f7501c;

        public e(ActionMenuView actionMenuView, int i10, boolean z10) {
            this.f7500a = actionMenuView;
            this.b = i10;
            this.f7501c = z10;
        }

        @Override // java.lang.Runnable
        public void run() {
            this.f7500a.setTranslationX(BottomAppBar.this.z0(r0, this.b, this.f7501c));
        }
    }

    public class f extends AnimatorListenerAdapter {
        public f() {
        }

        @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
        public void onAnimationStart(Animator animator) {
            BottomAppBar.this.f7486r0.onAnimationStart(animator);
            FloatingActionButton x02 = BottomAppBar.this.x0();
            if (x02 != null) {
                x02.setTranslationX(BottomAppBar.this.getFabTranslationX());
            }
        }
    }

    public interface g {
        void a(BottomAppBar bottomAppBar);

        void b(BottomAppBar bottomAppBar);
    }

    public static class h extends r3.a {
        public static final Parcelable.Creator<h> CREATOR = new a();

        /* renamed from: c, reason: collision with root package name */
        public int f7504c;

        /* renamed from: d, reason: collision with root package name */
        public boolean f7505d;

        public class a implements Parcelable.ClassLoaderCreator<h> {
            @Override // android.os.Parcelable.Creator
            /* renamed from: a, reason: merged with bridge method [inline-methods] */
            public h createFromParcel(@NonNull Parcel parcel) {
                return new h(parcel, null);
            }

            @Override // android.os.Parcelable.ClassLoaderCreator
            @NonNull
            /* renamed from: b, reason: merged with bridge method [inline-methods] */
            public h createFromParcel(@NonNull Parcel parcel, ClassLoader classLoader) {
                return new h(parcel, classLoader);
            }

            @Override // android.os.Parcelable.Creator
            @NonNull
            /* renamed from: c, reason: merged with bridge method [inline-methods] */
            public h[] newArray(int i10) {
                return new h[i10];
            }
        }

        public h(Parcelable parcelable) {
            super(parcelable);
        }

        @Override // r3.a, android.os.Parcelable
        public void writeToParcel(@NonNull Parcel parcel, int i10) {
            super.writeToParcel(parcel, i10);
            parcel.writeInt(this.f7504c);
            parcel.writeInt(this.f7505d ? 1 : 0);
        }

        public h(@NonNull Parcel parcel, ClassLoader classLoader) {
            super(parcel, classLoader);
            this.f7504c = parcel.readInt();
            this.f7505d = parcel.readInt() != 0;
        }
    }

    private Drawable E0(Drawable drawable) {
        if (drawable == null || this.T == null) {
            return drawable;
        }
        Drawable r10 = q2.a.r(drawable.mutate());
        q2.a.n(r10, this.T.intValue());
        return r10;
    }

    public static void M0(BottomAppBar bottomAppBar, View view) {
        CoordinatorLayout.f fVar = (CoordinatorLayout.f) view.getLayoutParams();
        fVar.f1536d = 17;
        int i10 = bottomAppBar.f7471c0;
        if (i10 == 1) {
            fVar.f1536d = 17 | 48;
        }
        if (i10 == 0) {
            fVar.f1536d |= 80;
        }
    }

    private ActionMenuView getActionMenuView() {
        for (int i10 = 0; i10 < getChildCount(); i10++) {
            View childAt = getChildAt(i10);
            if (childAt instanceof ActionMenuView) {
                return (ActionMenuView) childAt;
            }
        }
        return null;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public int getBottomInset() {
        return this.f7483o0;
    }

    private int getFabAlignmentAnimationDuration() {
        return dd.h.f(getContext(), f7467t0, MlKitException.LOW_LIGHT_AUTO_EXPOSURE_COMPUTATION_FAILURE);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public float getFabTranslationX() {
        return A0(this.f7469a0);
    }

    private float getFabTranslationY() {
        if (this.f7471c0 == 1) {
            return -getTopEdgeTreatment().c();
        }
        return y0() != null ? (-((getMeasuredHeight() + getBottomInset()) - r0.getMeasuredHeight())) / 2 : 0;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public int getLeftInset() {
        return this.f7485q0;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public int getRightInset() {
        return this.f7484p0;
    }

    @NonNull
    private mc.b getTopEdgeTreatment() {
        return (mc.b) this.U.E().p();
    }

    public final float A0(int i10) {
        boolean h10 = r.h(this);
        if (i10 != 1) {
            return 0.0f;
        }
        return ((getMeasuredWidth() / 2) - ((h10 ? this.f7485q0 : this.f7484p0) + ((this.f7473e0 == -1 || y0() == null) ? this.f7472d0 : (r6.getMeasuredWidth() / 2) + this.f7473e0))) * (h10 ? -1 : 1);
    }

    public final boolean B0() {
        FloatingActionButton x02 = x0();
        return x02 != null && x02.p();
    }

    public final void C0(int i10, boolean z10) {
        if (!o0.R(this)) {
            this.f7480l0 = false;
            F0(this.f7479k0);
            return;
        }
        Animator animator = this.W;
        if (animator != null) {
            animator.cancel();
        }
        ArrayList arrayList = new ArrayList();
        if (!B0()) {
            i10 = 0;
            z10 = false;
        }
        u0(i10, z10, arrayList);
        AnimatorSet animatorSet = new AnimatorSet();
        animatorSet.playTogether(arrayList);
        this.W = animatorSet;
        animatorSet.addListener(new c());
        this.W.start();
    }

    public final void D0(int i10) {
        if (this.f7469a0 == i10 || !o0.R(this)) {
            return;
        }
        Animator animator = this.V;
        if (animator != null) {
            animator.cancel();
        }
        ArrayList arrayList = new ArrayList();
        if (this.f7470b0 == 1) {
            t0(i10, arrayList);
        } else {
            s0(i10, arrayList);
        }
        AnimatorSet animatorSet = new AnimatorSet();
        animatorSet.playTogether(arrayList);
        animatorSet.setInterpolator(dd.h.g(getContext(), f7468u0, kc.a.f21323a));
        this.V = animatorSet;
        animatorSet.addListener(new a());
        this.V.start();
    }

    public void F0(int i10) {
        if (i10 != 0) {
            this.f7479k0 = 0;
            getMenu().clear();
            x(i10);
        }
    }

    public final void G0() {
        ActionMenuView actionMenuView = getActionMenuView();
        if (actionMenuView == null || this.W != null) {
            return;
        }
        actionMenuView.setAlpha(1.0f);
        if (B0()) {
            K0(actionMenuView, this.f7469a0, this.f7481m0);
        } else {
            K0(actionMenuView, 0, false);
        }
    }

    public final void H0() {
        getTopEdgeTreatment().s(getFabTranslationX());
        this.U.b0((this.f7481m0 && B0() && this.f7471c0 == 1) ? 1.0f : 0.0f);
        View y02 = y0();
        if (y02 != null) {
            y02.setTranslationY(getFabTranslationY());
            y02.setTranslationX(getFabTranslationX());
        }
    }

    public void I0(int i10, int i11) {
        this.f7479k0 = i11;
        this.f7480l0 = true;
        C0(i10, this.f7481m0);
        D0(i10);
        this.f7469a0 = i10;
    }

    public boolean J0(int i10) {
        float f10 = i10;
        if (f10 == getTopEdgeTreatment().k()) {
            return false;
        }
        getTopEdgeTreatment().r(f10);
        this.U.invalidateSelf();
        return true;
    }

    public final void K0(@NonNull ActionMenuView actionMenuView, int i10, boolean z10) {
        L0(actionMenuView, i10, z10, false);
    }

    public final void L0(@NonNull ActionMenuView actionMenuView, int i10, boolean z10, boolean z11) {
        e eVar = new e(actionMenuView, i10, z10);
        if (z11) {
            actionMenuView.post(eVar);
        } else {
            eVar.run();
        }
    }

    public ColorStateList getBackgroundTint() {
        return this.U.I();
    }

    public float getCradleVerticalOffset() {
        return getTopEdgeTreatment().c();
    }

    public int getFabAlignmentMode() {
        return this.f7469a0;
    }

    public int getFabAlignmentModeEndMargin() {
        return this.f7473e0;
    }

    public int getFabAnchorMode() {
        return this.f7471c0;
    }

    public int getFabAnimationMode() {
        return this.f7470b0;
    }

    public float getFabCradleMargin() {
        return getTopEdgeTreatment().f();
    }

    public float getFabCradleRoundedCornerRadius() {
        return getTopEdgeTreatment().i();
    }

    public boolean getHideOnScroll() {
        return this.f7476h0;
    }

    public int getMenuAlignmentMode() {
        return this.f7474f0;
    }

    @Override // androidx.appcompat.widget.Toolbar, android.view.ViewGroup, android.view.View
    public void onAttachedToWindow() {
        super.onAttachedToWindow();
        id.h.f(this, this.U);
        if (getParent() instanceof ViewGroup) {
            ((ViewGroup) getParent()).setClipChildren(false);
        }
    }

    @Override // androidx.appcompat.widget.Toolbar, android.view.ViewGroup, android.view.View
    public void onLayout(boolean z10, int i10, int i11, int i12, int i13) {
        super.onLayout(z10, i10, i11, i12, i13);
        if (z10) {
            r0();
            H0();
            final View y02 = y0();
            if (y02 != null && o0.R(y02)) {
                y02.post(new Runnable() { // from class: mc.a
                    @Override // java.lang.Runnable
                    public final void run() {
                        y02.requestLayout();
                    }
                });
            }
        }
        G0();
    }

    @Override // androidx.appcompat.widget.Toolbar, android.view.View
    public void onRestoreInstanceState(Parcelable parcelable) {
        if (!(parcelable instanceof h)) {
            super.onRestoreInstanceState(parcelable);
            return;
        }
        h hVar = (h) parcelable;
        super.onRestoreInstanceState(hVar.a());
        this.f7469a0 = hVar.f7504c;
        this.f7481m0 = hVar.f7505d;
    }

    @Override // androidx.appcompat.widget.Toolbar, android.view.View
    @NonNull
    public Parcelable onSaveInstanceState() {
        h hVar = new h(super.onSaveInstanceState());
        hVar.f7504c = this.f7469a0;
        hVar.f7505d = this.f7481m0;
        return hVar;
    }

    public final void q0(@NonNull FloatingActionButton floatingActionButton) {
        floatingActionButton.e(this.f7486r0);
        floatingActionButton.f(new f());
        floatingActionButton.g(null);
    }

    public final void r0() {
        Animator animator = this.W;
        if (animator != null) {
            animator.cancel();
        }
        Animator animator2 = this.V;
        if (animator2 != null) {
            animator2.cancel();
        }
    }

    public void s0(int i10, List<Animator> list) {
        FloatingActionButton x02 = x0();
        if (x02 == null || x02.o()) {
            return;
        }
        w0();
        x02.m(new b(i10));
    }

    public void setBackgroundTint(ColorStateList colorStateList) {
        q2.a.o(this.U, colorStateList);
    }

    public void setCradleVerticalOffset(float f10) {
        if (f10 != getCradleVerticalOffset()) {
            getTopEdgeTreatment().l(f10);
            this.U.invalidateSelf();
            H0();
        }
    }

    @Override // android.view.View
    public void setElevation(float f10) {
        this.U.Z(f10);
        getBehavior().M(this, this.U.D() - this.U.C());
    }

    public void setFabAlignmentMode(int i10) {
        I0(i10, 0);
    }

    public void setFabAlignmentModeEndMargin(int i10) {
        if (this.f7473e0 != i10) {
            this.f7473e0 = i10;
            H0();
        }
    }

    public void setFabAnchorMode(int i10) {
        this.f7471c0 = i10;
        H0();
        View y02 = y0();
        if (y02 != null) {
            M0(this, y02);
            y02.requestLayout();
            this.U.invalidateSelf();
        }
    }

    public void setFabAnimationMode(int i10) {
        this.f7470b0 = i10;
    }

    public void setFabCornerSize(float f10) {
        if (f10 != getTopEdgeTreatment().e()) {
            getTopEdgeTreatment().o(f10);
            this.U.invalidateSelf();
        }
    }

    public void setFabCradleMargin(float f10) {
        if (f10 != getFabCradleMargin()) {
            getTopEdgeTreatment().p(f10);
            this.U.invalidateSelf();
        }
    }

    public void setFabCradleRoundedCornerRadius(float f10) {
        if (f10 != getFabCradleRoundedCornerRadius()) {
            getTopEdgeTreatment().q(f10);
            this.U.invalidateSelf();
        }
    }

    public void setHideOnScroll(boolean z10) {
        this.f7476h0 = z10;
    }

    public void setMenuAlignmentMode(int i10) {
        if (this.f7474f0 != i10) {
            this.f7474f0 = i10;
            ActionMenuView actionMenuView = getActionMenuView();
            if (actionMenuView != null) {
                K0(actionMenuView, this.f7469a0, B0());
            }
        }
    }

    @Override // androidx.appcompat.widget.Toolbar
    public void setNavigationIcon(Drawable drawable) {
        super.setNavigationIcon(E0(drawable));
    }

    public void setNavigationIconTint(int i10) {
        this.T = Integer.valueOf(i10);
        Drawable navigationIcon = getNavigationIcon();
        if (navigationIcon != null) {
            setNavigationIcon(navigationIcon);
        }
    }

    @Override // androidx.appcompat.widget.Toolbar
    public void setSubtitle(CharSequence charSequence) {
    }

    @Override // androidx.appcompat.widget.Toolbar
    public void setTitle(CharSequence charSequence) {
    }

    public final void t0(int i10, @NonNull List<Animator> list) {
        ObjectAnimator ofFloat = ObjectAnimator.ofFloat(x0(), "translationX", A0(i10));
        ofFloat.setDuration(getFabAlignmentAnimationDuration());
        list.add(ofFloat);
    }

    public final void u0(int i10, boolean z10, @NonNull List<Animator> list) {
        ActionMenuView actionMenuView = getActionMenuView();
        if (actionMenuView == null) {
            return;
        }
        float fabAlignmentAnimationDuration = getFabAlignmentAnimationDuration();
        Animator ofFloat = ObjectAnimator.ofFloat(actionMenuView, "alpha", 1.0f);
        ofFloat.setDuration((long) (0.8f * fabAlignmentAnimationDuration));
        if (Math.abs(actionMenuView.getTranslationX() - z0(actionMenuView, i10, z10)) <= 1.0f) {
            if (actionMenuView.getAlpha() < 1.0f) {
                list.add(ofFloat);
            }
        } else {
            ObjectAnimator ofFloat2 = ObjectAnimator.ofFloat(actionMenuView, "alpha", 0.0f);
            ofFloat2.setDuration((long) (fabAlignmentAnimationDuration * 0.2f));
            ofFloat2.addListener(new d(actionMenuView, i10, z10));
            AnimatorSet animatorSet = new AnimatorSet();
            animatorSet.playSequentially(ofFloat2, ofFloat);
            list.add(animatorSet);
        }
    }

    public final void v0() {
        ArrayList<g> arrayList;
        int i10 = this.f7477i0 - 1;
        this.f7477i0 = i10;
        if (i10 != 0 || (arrayList = this.f7478j0) == null) {
            return;
        }
        int size = arrayList.size();
        int i11 = 0;
        while (i11 < size) {
            g gVar = arrayList.get(i11);
            i11++;
            gVar.a(this);
        }
    }

    public final void w0() {
        ArrayList<g> arrayList;
        int i10 = this.f7477i0;
        this.f7477i0 = i10 + 1;
        if (i10 != 0 || (arrayList = this.f7478j0) == null) {
            return;
        }
        int size = arrayList.size();
        int i11 = 0;
        while (i11 < size) {
            g gVar = arrayList.get(i11);
            i11++;
            gVar.b(this);
        }
    }

    public final FloatingActionButton x0() {
        View y02 = y0();
        if (y02 instanceof FloatingActionButton) {
            return (FloatingActionButton) y02;
        }
        return null;
    }

    public final View y0() {
        if (!(getParent() instanceof CoordinatorLayout)) {
            return null;
        }
        for (View view : ((CoordinatorLayout) getParent()).s(this)) {
            if ((view instanceof FloatingActionButton) || (view instanceof ExtendedFloatingActionButton)) {
                return view;
            }
        }
        return null;
    }

    public int z0(@NonNull ActionMenuView actionMenuView, int i10, boolean z10) {
        int i11 = 0;
        if (this.f7474f0 != 1 && (i10 != 1 || !z10)) {
            return 0;
        }
        boolean h10 = r.h(this);
        int measuredWidth = h10 ? getMeasuredWidth() : 0;
        for (int i12 = 0; i12 < getChildCount(); i12++) {
            View childAt = getChildAt(i12);
            if ((childAt.getLayoutParams() instanceof Toolbar.g) && (((Toolbar.g) childAt.getLayoutParams()).f19837a & 8388615) == 8388611) {
                measuredWidth = h10 ? Math.min(measuredWidth, childAt.getLeft()) : Math.max(measuredWidth, childAt.getRight());
            }
        }
        int right = h10 ? actionMenuView.getRight() : actionMenuView.getLeft();
        int i13 = h10 ? this.f7484p0 : -this.f7485q0;
        if (getNavigationIcon() == null) {
            i11 = getResources().getDimensionPixelOffset(jc.d.f20342m);
            if (!h10) {
                i11 = -i11;
            }
        }
        return measuredWidth - ((right + i13) + i11);
    }

    @Override // androidx.coordinatorlayout.widget.CoordinatorLayout.b
    @NonNull
    public Behavior getBehavior() {
        if (this.f7482n0 == null) {
            this.f7482n0 = new Behavior();
        }
        return this.f7482n0;
    }

    public static class Behavior extends HideBottomViewOnScrollBehavior<BottomAppBar> {

        /* renamed from: m, reason: collision with root package name */
        @NonNull
        public final Rect f7487m;

        /* renamed from: n, reason: collision with root package name */
        public WeakReference<BottomAppBar> f7488n;

        /* renamed from: o, reason: collision with root package name */
        public int f7489o;

        /* renamed from: p, reason: collision with root package name */
        public final View.OnLayoutChangeListener f7490p;

        public class a implements View.OnLayoutChangeListener {
            public a() {
            }

            @Override // android.view.View.OnLayoutChangeListener
            public void onLayoutChange(View view, int i10, int i11, int i12, int i13, int i14, int i15, int i16, int i17) {
                BottomAppBar bottomAppBar = (BottomAppBar) Behavior.this.f7488n.get();
                if (bottomAppBar == null || !((view instanceof FloatingActionButton) || (view instanceof ExtendedFloatingActionButton))) {
                    view.removeOnLayoutChangeListener(this);
                    return;
                }
                int height = view.getHeight();
                if (view instanceof FloatingActionButton) {
                    FloatingActionButton floatingActionButton = (FloatingActionButton) view;
                    floatingActionButton.j(Behavior.this.f7487m);
                    int height2 = Behavior.this.f7487m.height();
                    bottomAppBar.J0(height2);
                    bottomAppBar.setFabCornerSize(floatingActionButton.getShapeAppearanceModel().r().a(new RectF(Behavior.this.f7487m)));
                    height = height2;
                }
                CoordinatorLayout.f fVar = (CoordinatorLayout.f) view.getLayoutParams();
                if (Behavior.this.f7489o == 0) {
                    if (bottomAppBar.f7471c0 == 1) {
                        ((ViewGroup.MarginLayoutParams) fVar).bottomMargin = bottomAppBar.getBottomInset() + (bottomAppBar.getResources().getDimensionPixelOffset(jc.d.N) - ((view.getMeasuredHeight() - height) / 2));
                    }
                    ((ViewGroup.MarginLayoutParams) fVar).leftMargin = bottomAppBar.getLeftInset();
                    ((ViewGroup.MarginLayoutParams) fVar).rightMargin = bottomAppBar.getRightInset();
                    if (r.h(view)) {
                        ((ViewGroup.MarginLayoutParams) fVar).leftMargin += bottomAppBar.f7472d0;
                    } else {
                        ((ViewGroup.MarginLayoutParams) fVar).rightMargin += bottomAppBar.f7472d0;
                    }
                }
                bottomAppBar.H0();
            }
        }

        public Behavior() {
            this.f7490p = new a();
            this.f7487m = new Rect();
        }

        @Override // com.google.android.material.behavior.HideBottomViewOnScrollBehavior, androidx.coordinatorlayout.widget.CoordinatorLayout.c
        /* renamed from: V, reason: merged with bridge method [inline-methods] */
        public boolean p(@NonNull CoordinatorLayout coordinatorLayout, @NonNull BottomAppBar bottomAppBar, int i10) {
            this.f7488n = new WeakReference<>(bottomAppBar);
            View y02 = bottomAppBar.y0();
            if (y02 != null && !o0.R(y02)) {
                BottomAppBar.M0(bottomAppBar, y02);
                this.f7489o = ((ViewGroup.MarginLayoutParams) ((CoordinatorLayout.f) y02.getLayoutParams())).bottomMargin;
                if (y02 instanceof FloatingActionButton) {
                    FloatingActionButton floatingActionButton = (FloatingActionButton) y02;
                    if (bottomAppBar.f7471c0 == 0 && bottomAppBar.f7475g0) {
                        o0.u0(floatingActionButton, 0.0f);
                        floatingActionButton.setCompatElevation(0.0f);
                    }
                    if (floatingActionButton.getShowMotionSpec() == null) {
                        floatingActionButton.setShowMotionSpecResource(jc.a.b);
                    }
                    if (floatingActionButton.getHideMotionSpec() == null) {
                        floatingActionButton.setHideMotionSpecResource(jc.a.f20273a);
                    }
                    bottomAppBar.q0(floatingActionButton);
                }
                y02.addOnLayoutChangeListener(this.f7490p);
                bottomAppBar.H0();
            }
            coordinatorLayout.I(bottomAppBar, i10);
            return super.p(coordinatorLayout, bottomAppBar, i10);
        }

        @Override // com.google.android.material.behavior.HideBottomViewOnScrollBehavior, androidx.coordinatorlayout.widget.CoordinatorLayout.c
        /* renamed from: W, reason: merged with bridge method [inline-methods] */
        public boolean E(@NonNull CoordinatorLayout coordinatorLayout, @NonNull BottomAppBar bottomAppBar, @NonNull View view, @NonNull View view2, int i10, int i11) {
            return bottomAppBar.getHideOnScroll() && super.E(coordinatorLayout, bottomAppBar, view, view2, i10, i11);
        }

        public Behavior(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
            this.f7490p = new a();
            this.f7487m = new Rect();
        }
    }


    // --- восстановлено из DEX (com/google/android/material/bottomappbar/BottomAppBar$Behavior$a) ---
    public static class a implements android.view.View.OnLayoutChangeListener {
        com.google.android.material.bottomappbar.BottomAppBar.Behavior a;
        public a(com.google.android.material.bottomappbar.BottomAppBar.Behavior p0) { }
        public void onLayoutChange(android.view.View p0, int p1, int p2, int p3, int p4, int p5, int p6, int p7, int p8) { throw new UnsupportedOperationException("stub"); }
    }

    // --- восстановлено из DEX (com/google/android/material/bottomappbar/BottomAppBar$b$a) ---
    public static class a extends com.google.android.material.floatingactionbutton.FloatingActionButton.b {
        com.google.android.material.bottomappbar.BottomAppBar.b a;
        public a(com.google.android.material.bottomappbar.BottomAppBar.b p0) { }
        public void b(com.google.android.material.floatingactionbutton.FloatingActionButton p0) { throw new UnsupportedOperationException("stub"); }
    }

    // --- восстановлено из DEX (com/google/android/material/bottomappbar/BottomAppBar$h$a) ---
    public static class a implements android.os.Parcelable.ClassLoaderCreator {
        public a() { }
        public com.google.android.material.bottomappbar.BottomAppBar.h a(android.os.Parcel p0) { throw new UnsupportedOperationException("stub"); }
        public com.google.android.material.bottomappbar.BottomAppBar.h b(android.os.Parcel p0, java.lang.ClassLoader p1) { throw new UnsupportedOperationException("stub"); }
        public com.google.android.material.bottomappbar.BottomAppBar.h[] c(int p0) { throw new UnsupportedOperationException("stub"); }
        public java.lang.Object createFromParcel(android.os.Parcel p0) { throw new UnsupportedOperationException("stub"); }
        public java.lang.Object createFromParcel(android.os.Parcel p0, java.lang.ClassLoader p1) { throw new UnsupportedOperationException("stub"); }
        public java.lang.Object[] newArray(int p0) { throw new UnsupportedOperationException("stub"); }
    }
}
