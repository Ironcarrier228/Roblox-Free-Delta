package com.google.android.material.checkbox;

import android.R;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.graphics.Canvas;
import android.graphics.PorterDuff;
import android.graphics.Rect;
import android.graphics.drawable.AnimatedStateListDrawable;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Parcel;
import android.os.Parcelable;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.View;
import android.view.accessibility.AccessibilityNodeInfo;
import android.view.autofill.AutofillManager;
import android.widget.CompoundButton;
import androidx.annotation.NonNull;
import bd.r;
import java.util.Iterator;
import java.util.LinkedHashSet;
import jc.f;
import jc.i;
import jc.j;
import jc.k;
import q.b1;
import q.g;

/* loaded from: classes2.dex */
public class MaterialCheckBox extends g {
    public static final int[] A;
    public static final int[][] B;

    @SuppressLint({"DiscouragedApi"})
    public static final int C;

    /* renamed from: y, reason: collision with root package name */
    public static final int f7659y = j.f20458u;

    /* renamed from: z, reason: collision with root package name */
    public static final int[] f7660z = {jc.b.f20278b0};

    /* renamed from: e, reason: collision with root package name */
    @NonNull
    public final LinkedHashSet<c> f7661e;

    /* renamed from: f, reason: collision with root package name */
    @NonNull
    public final LinkedHashSet<b> f7662f;

    /* renamed from: g, reason: collision with root package name */
    public ColorStateList f7663g;

    /* renamed from: h, reason: collision with root package name */
    public boolean f7664h;

    /* renamed from: i, reason: collision with root package name */
    public boolean f7665i;

    /* renamed from: j, reason: collision with root package name */
    public boolean f7666j;

    /* renamed from: k, reason: collision with root package name */
    public CharSequence f7667k;

    /* renamed from: l, reason: collision with root package name */
    public Drawable f7668l;

    /* renamed from: m, reason: collision with root package name */
    public Drawable f7669m;

    /* renamed from: n, reason: collision with root package name */
    public boolean f7670n;

    /* renamed from: o, reason: collision with root package name */
    public ColorStateList f7671o;

    /* renamed from: p, reason: collision with root package name */
    public ColorStateList f7672p;

    /* renamed from: q, reason: collision with root package name */
    @NonNull
    public PorterDuff.Mode f7673q;

    /* renamed from: r, reason: collision with root package name */
    public int f7674r;

    /* renamed from: s, reason: collision with root package name */
    public int[] f7675s;

    /* renamed from: t, reason: collision with root package name */
    public boolean f7676t;

    /* renamed from: u, reason: collision with root package name */
    public CharSequence f7677u;

    /* renamed from: v, reason: collision with root package name */
    public CompoundButton.OnCheckedChangeListener f7678v;

    /* renamed from: w, reason: collision with root package name */
    public final q5.c f7679w;

    /* renamed from: x, reason: collision with root package name */
    public final q5.b f7680x;

    public class a extends q5.b {
        public a() {
        }

        @Override // q5.b
        public void b(Drawable drawable) {
            super.b(drawable);
            ColorStateList colorStateList = MaterialCheckBox.this.f7671o;
            if (colorStateList != null) {
                q2.a.o(drawable, colorStateList);
            }
        }

        @Override // q5.b
        public void c(Drawable drawable) {
            super.c(drawable);
            MaterialCheckBox materialCheckBox = MaterialCheckBox.this;
            ColorStateList colorStateList = materialCheckBox.f7671o;
            if (colorStateList != null) {
                q2.a.n(drawable, colorStateList.getColorForState(materialCheckBox.f7675s, MaterialCheckBox.this.f7671o.getDefaultColor()));
            }
        }
    }

    public interface b {
        void a(@NonNull MaterialCheckBox materialCheckBox, int i10);
    }

    public interface c {
        void a(@NonNull MaterialCheckBox materialCheckBox, boolean z10);
    }

    public static class d extends View.BaseSavedState {

        @NonNull
        public static final Parcelable.Creator<d> CREATOR = new a();

        /* renamed from: a, reason: collision with root package name */
        public int f7681a;

        public class a implements Parcelable.Creator<d> {
            @Override // android.os.Parcelable.Creator
            /* renamed from: a, reason: merged with bridge method [inline-methods] */
            public d createFromParcel(Parcel parcel) {
                return new d(parcel, null);
            }

            @Override // android.os.Parcelable.Creator
            /* renamed from: b, reason: merged with bridge method [inline-methods] */
            public d[] newArray(int i10) {
                return new d[i10];
            }
        }

        public /* synthetic */ d(Parcel parcel, a aVar) {
            this(parcel);
        }

        @NonNull
        public final String a() {
            int i10 = this.f7681a;
            return i10 != 1 ? i10 != 2 ? "unchecked" : "indeterminate" : "checked";
        }

        @NonNull
        public String toString() {
            return "MaterialCheckBox.SavedState{" + Integer.toHexString(System.identityHashCode(this)) + " CheckedState=" + a() + "}";
        }

        @Override // android.view.View.BaseSavedState, android.view.AbsSavedState, android.os.Parcelable
        public void writeToParcel(Parcel parcel, int i10) {
            super.writeToParcel(parcel, i10);
            parcel.writeValue(Integer.valueOf(this.f7681a));
        }

        public d(Parcelable parcelable) {
            super(parcelable);
        }

        public d(Parcel parcel) {
            super(parcel);
            this.f7681a = ((Integer) parcel.readValue(getClass().getClassLoader())).intValue();
        }
    }

    static {
        int i10 = jc.b.f20277a0;
        A = new int[]{i10};
        B = new int[][]{new int[]{android.R.attr.state_enabled, i10}, new int[]{android.R.attr.state_enabled, android.R.attr.state_checked}, new int[]{android.R.attr.state_enabled, -16842912}, new int[]{-16842910, android.R.attr.state_checked}, new int[]{-16842910, -16842912}};
        C = Resources.getSystem().getIdentifier("btn_check_material_anim", "drawable", "android");
    }

    public MaterialCheckBox(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, jc.b.f20281d);
    }

    @NonNull
    private String getButtonStateDescription() {
        int i10 = this.f7674r;
        return i10 == 1 ? getResources().getString(i.f20423h) : i10 == 0 ? getResources().getString(i.f20425j) : getResources().getString(i.f20424i);
    }

    private ColorStateList getMaterialThemeColorsTintList() {
        if (this.f7663g == null) {
            int[][] iArr = B;
            int[] iArr2 = new int[iArr.length];
            int d10 = vc.a.d(this, jc.b.f20287g);
            int d11 = vc.a.d(this, jc.b.f20291i);
            int d12 = vc.a.d(this, jc.b.f20298o);
            int d13 = vc.a.d(this, jc.b.f20293j);
            iArr2[0] = vc.a.j(d12, d11, 1.0f);
            iArr2[1] = vc.a.j(d12, d10, 1.0f);
            iArr2[2] = vc.a.j(d12, d13, 0.54f);
            iArr2[3] = vc.a.j(d12, d13, 0.38f);
            iArr2[4] = vc.a.j(d12, d13, 0.38f);
            this.f7663g = new ColorStateList(iArr, iArr2);
        }
        return this.f7663g;
    }

    private ColorStateList getSuperButtonTintList() {
        ColorStateList colorStateList = this.f7671o;
        return colorStateList != null ? colorStateList : super.getButtonTintList() != null ? super.getButtonTintList() : getSupportButtonTintList();
    }

    public void c(@NonNull b bVar) {
        this.f7662f.add(bVar);
    }

    public final boolean d(b1 b1Var) {
        return b1Var.n(k.M3, 0) == C && b1Var.n(k.N3, 0) == 0;
    }

    public boolean e() {
        return this.f7666j;
    }

    public final void f() {
        this.f7668l = xc.c.d(this.f7668l, this.f7671o, d3.d.c(this));
        this.f7669m = xc.c.d(this.f7669m, this.f7672p, this.f7673q);
        h();
        i();
        super.setButtonDrawable(xc.c.a(this.f7668l, this.f7669m));
        refreshDrawableState();
    }

    public final void g() {
        if (Build.VERSION.SDK_INT < 30 || this.f7677u != null) {
            return;
        }
        super.setStateDescription(getButtonStateDescription());
    }

    @Override // android.widget.CompoundButton
    public Drawable getButtonDrawable() {
        return this.f7668l;
    }

    public Drawable getButtonIconDrawable() {
        return this.f7669m;
    }

    public ColorStateList getButtonIconTintList() {
        return this.f7672p;
    }

    @NonNull
    public PorterDuff.Mode getButtonIconTintMode() {
        return this.f7673q;
    }

    @Override // android.widget.CompoundButton
    public ColorStateList getButtonTintList() {
        return this.f7671o;
    }

    public int getCheckedState() {
        return this.f7674r;
    }

    public CharSequence getErrorAccessibilityLabel() {
        return this.f7667k;
    }

    public final void h() {
        q5.c cVar;
        if (this.f7670n) {
            q5.c cVar2 = this.f7679w;
            if (cVar2 != null) {
                cVar2.f(this.f7680x);
                this.f7679w.b(this.f7680x);
            }
            Drawable drawable = this.f7668l;
            if (!(drawable instanceof AnimatedStateListDrawable) || (cVar = this.f7679w) == null) {
                return;
            }
            ((AnimatedStateListDrawable) drawable).addTransition(f.b, f.W, cVar, false);
            ((AnimatedStateListDrawable) this.f7668l).addTransition(f.f20376j, f.W, this.f7679w, false);
        }
    }

    public final void i() {
        ColorStateList colorStateList;
        ColorStateList colorStateList2;
        Drawable drawable = this.f7668l;
        if (drawable != null && (colorStateList2 = this.f7671o) != null) {
            q2.a.o(drawable, colorStateList2);
        }
        Drawable drawable2 = this.f7669m;
        if (drawable2 == null || (colorStateList = this.f7672p) == null) {
            return;
        }
        q2.a.o(drawable2, colorStateList);
    }

    @Override // android.widget.CompoundButton, android.widget.Checkable
    public boolean isChecked() {
        return this.f7674r == 1;
    }

    public final void j() {
    }

    @Override // android.widget.TextView, android.view.View
    public void onAttachedToWindow() {
        super.onAttachedToWindow();
        if (this.f7664h && this.f7671o == null && this.f7672p == null) {
            setUseMaterialThemeColors(true);
        }
    }

    @Override // android.widget.CompoundButton, android.widget.TextView, android.view.View
    public int[] onCreateDrawableState(int i10) {
        int[] onCreateDrawableState = super.onCreateDrawableState(i10 + 2);
        if (getCheckedState() == 2) {
            View.mergeDrawableStates(onCreateDrawableState, f7660z);
        }
        if (e()) {
            View.mergeDrawableStates(onCreateDrawableState, A);
        }
        this.f7675s = xc.c.f(onCreateDrawableState);
        j();
        return onCreateDrawableState;
    }

    @Override // android.widget.CompoundButton, android.widget.TextView, android.view.View
    public void onDraw(Canvas canvas) {
        Drawable a10;
        if (!this.f7665i || !TextUtils.isEmpty(getText()) || (a10 = d3.d.a(this)) == null) {
            super.onDraw(canvas);
            return;
        }
        int width = ((getWidth() - a10.getIntrinsicWidth()) / 2) * (r.h(this) ? -1 : 1);
        int save = canvas.save();
        canvas.translate(width, 0.0f);
        super.onDraw(canvas);
        canvas.restoreToCount(save);
        if (getBackground() != null) {
            Rect bounds = a10.getBounds();
            q2.a.l(getBackground(), bounds.left + width, bounds.top, bounds.right + width, bounds.bottom);
        }
    }

    @Override // android.view.View
    public void onInitializeAccessibilityNodeInfo(AccessibilityNodeInfo accessibilityNodeInfo) {
        super.onInitializeAccessibilityNodeInfo(accessibilityNodeInfo);
        if (accessibilityNodeInfo != null && e()) {
            accessibilityNodeInfo.setText(((Object) accessibilityNodeInfo.getText()) + ", " + ((Object) this.f7667k));
        }
    }

    @Override // android.widget.CompoundButton, android.widget.TextView, android.view.View
    public void onRestoreInstanceState(Parcelable parcelable) {
        if (!(parcelable instanceof d)) {
            super.onRestoreInstanceState(parcelable);
            return;
        }
        d dVar = (d) parcelable;
        super.onRestoreInstanceState(dVar.getSuperState());
        setCheckedState(dVar.f7681a);
    }

    @Override // android.widget.CompoundButton, android.widget.TextView, android.view.View
    public Parcelable onSaveInstanceState() {
        d dVar = new d(super.onSaveInstanceState());
        dVar.f7681a = getCheckedState();
        return dVar;
    }

    @Override // q.g, android.widget.CompoundButton
    public void setButtonDrawable(int i10) {
        setButtonDrawable(k.a.b(getContext(), i10));
    }

    public void setButtonIconDrawable(Drawable drawable) {
        this.f7669m = drawable;
        f();
    }

    public void setButtonIconDrawableResource(int i10) {
        setButtonIconDrawable(k.a.b(getContext(), i10));
    }

    public void setButtonIconTintList(ColorStateList colorStateList) {
        if (this.f7672p == colorStateList) {
            return;
        }
        this.f7672p = colorStateList;
        f();
    }

    public void setButtonIconTintMode(@NonNull PorterDuff.Mode mode) {
        if (this.f7673q == mode) {
            return;
        }
        this.f7673q = mode;
        f();
    }

    @Override // android.widget.CompoundButton
    public void setButtonTintList(ColorStateList colorStateList) {
        if (this.f7671o == colorStateList) {
            return;
        }
        this.f7671o = colorStateList;
        f();
    }

    @Override // android.widget.CompoundButton
    public void setButtonTintMode(PorterDuff.Mode mode) {
        setSupportButtonTintMode(mode);
        f();
    }

    public void setCenterIfNoTextEnabled(boolean z10) {
        this.f7665i = z10;
    }

    @Override // android.widget.CompoundButton, android.widget.Checkable
    public void setChecked(boolean z10) {
        setCheckedState(z10 ? 1 : 0);
    }

    public void setCheckedState(int i10) {
        CompoundButton.OnCheckedChangeListener onCheckedChangeListener;
        if (this.f7674r != i10) {
            this.f7674r = i10;
            super.setChecked(i10 == 1);
            refreshDrawableState();
            g();
            if (this.f7676t) {
                return;
            }
            this.f7676t = true;
            LinkedHashSet<b> linkedHashSet = this.f7662f;
            if (linkedHashSet != null) {
                Iterator<b> it = linkedHashSet.iterator();
                while (it.hasNext()) {
                    it.next().a(this, this.f7674r);
                }
            }
            if (this.f7674r != 2 && (onCheckedChangeListener = this.f7678v) != null) {
                onCheckedChangeListener.onCheckedChanged(this, isChecked());
            }
            AutofillManager autofillManager = (AutofillManager) getContext().getSystemService(AutofillManager.class);
            if (autofillManager != null) {
                autofillManager.notifyValueChanged(this);
            }
            this.f7676t = false;
        }
    }

    @Override // android.widget.TextView, android.view.View
    public void setEnabled(boolean z10) {
        super.setEnabled(z10);
        j();
    }

    public void setErrorAccessibilityLabel(CharSequence charSequence) {
        this.f7667k = charSequence;
    }

    public void setErrorAccessibilityLabelResource(int i10) {
        setErrorAccessibilityLabel(i10 != 0 ? getResources().getText(i10) : null);
    }

    public void setErrorShown(boolean z10) {
        if (this.f7666j == z10) {
            return;
        }
        this.f7666j = z10;
        refreshDrawableState();
        Iterator<c> it = this.f7661e.iterator();
        while (it.hasNext()) {
            it.next().a(this, this.f7666j);
        }
    }

    @Override // android.widget.CompoundButton
    public void setOnCheckedChangeListener(CompoundButton.OnCheckedChangeListener onCheckedChangeListener) {
        this.f7678v = onCheckedChangeListener;
    }

    @Override // android.widget.CompoundButton, android.view.View
    public void setStateDescription(CharSequence charSequence) {
        this.f7677u = charSequence;
        if (charSequence == null) {
            g();
        } else {
            super.setStateDescription(charSequence);
        }
    }

    public void setUseMaterialThemeColors(boolean z10) {
        this.f7664h = z10;
        if (z10) {
            d3.d.d(this, getMaterialThemeColorsTintList());
        } else {
            d3.d.d(this, null);
        }
    }

    @Override // android.widget.CompoundButton, android.widget.Checkable
    public void toggle() {
        setChecked(!isChecked());
    }

    /* JADX WARN: Illegal instructions before constructor call */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public MaterialCheckBox(android.content.Context r8, android.util.AttributeSet r9, int r10) {
        /*
            r7 = this;
            int r4 = com.google.android.material.checkbox.MaterialCheckBox.f7659y
            android.content.Context r8 = od.a.c(r8, r9, r10, r4)
            r7.<init>(r8, r9, r10)
            java.util.LinkedHashSet r8 = new java.util.LinkedHashSet
            r8.<init>()
            r7.f7661e = r8
            java.util.LinkedHashSet r8 = new java.util.LinkedHashSet
            r8.<init>()
            r7.f7662f = r8
            android.content.Context r8 = r7.getContext()
            int r0 = jc.e.f20362h
            q5.c r8 = q5.c.a(r8, r0)
            r7.f7679w = r8
            com.google.android.material.checkbox.MaterialCheckBox$a r8 = new com.google.android.material.checkbox.MaterialCheckBox$a
            r8.<init>()
            r7.f7680x = r8
            android.content.Context r0 = r7.getContext()
            android.graphics.drawable.Drawable r8 = d3.d.a(r7)
            r7.f7668l = r8
            android.content.res.ColorStateList r8 = r7.getSuperButtonTintList()
            r7.f7671o = r8
            r8 = 0
            r7.setSupportButtonTintList(r8)
            int[] r2 = jc.k.L3
            r6 = 0
            int[] r5 = new int[r6]
            r1 = r9
            r3 = r10
            q.b1 r9 = bd.o.j(r0, r1, r2, r3, r4, r5)
            int r10 = jc.k.O3
            android.graphics.drawable.Drawable r10 = r9.g(r10)
            r7.f7669m = r10
            android.graphics.drawable.Drawable r10 = r7.f7668l
            r1 = 1
            if (r10 == 0) goto L7b
            boolean r10 = bd.o.g(r0)
            if (r10 == 0) goto L7b
            boolean r10 = r7.d(r9)
            if (r10 == 0) goto L7b
            super.setButtonDrawable(r8)
            int r8 = jc.e.f20361g
            android.graphics.drawable.Drawable r8 = k.a.b(r0, r8)
            r7.f7668l = r8
            r7.f7670n = r1
            android.graphics.drawable.Drawable r8 = r7.f7669m
            if (r8 != 0) goto L7b
            int r8 = jc.e.f20363i
            android.graphics.drawable.Drawable r8 = k.a.b(r0, r8)
            r7.f7669m = r8
        L7b:
            int r8 = jc.k.P3
            android.content.res.ColorStateList r8 = fd.c.b(r0, r9, r8)
            r7.f7672p = r8
            int r8 = jc.k.Q3
            r10 = -1
            int r8 = r9.k(r8, r10)
            android.graphics.PorterDuff$Mode r10 = android.graphics.PorterDuff.Mode.SRC_IN
            android.graphics.PorterDuff$Mode r8 = bd.r.i(r8, r10)
            r7.f7673q = r8
            int r8 = jc.k.V3
            boolean r8 = r9.a(r8, r6)
            r7.f7664h = r8
            int r8 = jc.k.R3
            boolean r8 = r9.a(r8, r1)
            r7.f7665i = r8
            int r8 = jc.k.U3
            boolean r8 = r9.a(r8, r6)
            r7.f7666j = r8
            int r8 = jc.k.T3
            java.lang.CharSequence r8 = r9.p(r8)
            r7.f7667k = r8
            int r8 = jc.k.S3
            boolean r8 = r9.s(r8)
            if (r8 == 0) goto Lc3
            int r8 = jc.k.S3
            int r8 = r9.k(r8, r6)
            r7.setCheckedState(r8)
        Lc3:
            r9.x()
            r7.f()
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.material.checkbox.MaterialCheckBox.<init>(android.content.Context, android.util.AttributeSet, int):void");
    }

    @Override // q.g, android.widget.CompoundButton
    public void setButtonDrawable(Drawable drawable) {
        this.f7668l = drawable;
        this.f7670n = false;
        f();
    }
}
