package com.google.android.material.search;

import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Parcel;
import android.os.Parcelable;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.Menu;
import android.view.View;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.appcompat.widget.ActionMenuView;
import androidx.appcompat.widget.Toolbar;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.core.view.o0;
import bd.p;
import com.google.android.material.appbar.AppBarLayout;
import id.g;
import id.h;
import jc.b;
import jc.d;
import jc.e;
import jc.j;

/* loaded from: classes2.dex */
public class SearchBar extends Toolbar {

    /* renamed from: i0, reason: collision with root package name */
    public static final int f7992i0 = j.f20449l;
    public final TextView T;
    public final boolean U;
    public final boolean V;
    public final Drawable W;

    /* renamed from: a0, reason: collision with root package name */
    public final boolean f7993a0;

    /* renamed from: b0, reason: collision with root package name */
    public final boolean f7994b0;

    /* renamed from: c0, reason: collision with root package name */
    public View f7995c0;

    /* renamed from: d0, reason: collision with root package name */
    public Integer f7996d0;

    /* renamed from: e0, reason: collision with root package name */
    public Drawable f7997e0;

    /* renamed from: f0, reason: collision with root package name */
    public int f7998f0;

    /* renamed from: g0, reason: collision with root package name */
    public boolean f7999g0;

    /* renamed from: h0, reason: collision with root package name */
    public g f8000h0;

    public static class a extends r3.a {
        public static final Parcelable.Creator<a> CREATOR = new C0128a();

        /* renamed from: c, reason: collision with root package name */
        public String f8002c;

        /* renamed from: com.google.android.material.search.SearchBar$a$a, reason: collision with other inner class name */
        public class C0128a implements Parcelable.ClassLoaderCreator<a> {
            @Override // android.os.Parcelable.Creator
            /* renamed from: a, reason: merged with bridge method [inline-methods] */
            public a createFromParcel(Parcel parcel) {
                return new a(parcel);
            }

            @Override // android.os.Parcelable.ClassLoaderCreator
            /* renamed from: b, reason: merged with bridge method [inline-methods] */
            public a createFromParcel(Parcel parcel, ClassLoader classLoader) {
                return new a(parcel, classLoader);
            }

            @Override // android.os.Parcelable.Creator
            /* renamed from: c, reason: merged with bridge method [inline-methods] */
            public a[] newArray(int i10) {
                return new a[i10];
            }
        }

        public a(Parcel parcel) {
            this(parcel, null);
        }

        @Override // r3.a, android.os.Parcelable
        public void writeToParcel(Parcel parcel, int i10) {
            super.writeToParcel(parcel, i10);
            parcel.writeString(this.f8002c);
        }

        public a(Parcel parcel, ClassLoader classLoader) {
            super(parcel, classLoader);
            this.f8002c = parcel.readString();
        }

        public a(Parcelable parcelable) {
            super(parcelable);
        }
    }

    private Drawable W(Drawable drawable) {
        int d10;
        if (!this.f7993a0 || drawable == null) {
            return drawable;
        }
        Integer num = this.f7996d0;
        if (num != null) {
            d10 = num.intValue();
        } else {
            d10 = vc.a.d(this, drawable == this.W ? b.f20294k : b.f20293j);
        }
        Drawable r10 = q2.a.r(drawable.mutate());
        q2.a.n(r10, d10);
        return r10;
    }

    private void setNavigationIconDecorative(boolean z10) {
        ImageButton d10 = p.d(this);
        if (d10 == null) {
            return;
        }
        d10.setClickable(!z10);
        d10.setFocusable(!z10);
        Drawable background = d10.getBackground();
        if (background != null) {
            this.f7997e0 = background;
        }
        d10.setBackgroundDrawable(z10 ? null : this.f7997e0);
        Z();
    }

    public final int T(int i10, int i11) {
        return i10 == 0 ? i11 : i10;
    }

    public final void U() {
        View view = this.f7995c0;
        if (view == null) {
            return;
        }
        int measuredWidth = view.getMeasuredWidth();
        int measuredWidth2 = (getMeasuredWidth() / 2) - (measuredWidth / 2);
        int i10 = measuredWidth2 + measuredWidth;
        int measuredHeight = this.f7995c0.getMeasuredHeight();
        int measuredHeight2 = (getMeasuredHeight() / 2) - (measuredHeight / 2);
        V(this.f7995c0, measuredWidth2, measuredHeight2, i10, measuredHeight2 + measuredHeight);
    }

    public final void V(View view, int i10, int i11, int i12, int i13) {
        if (o0.z(this) == 1) {
            view.layout(getMeasuredWidth() - i12, i11, getMeasuredWidth() - i10, i13);
        } else {
            view.layout(i10, i11, i12, i13);
        }
    }

    public final void X(int i10, int i11) {
        View view = this.f7995c0;
        if (view != null) {
            view.measure(i10, i11);
        }
    }

    public final void Y() {
        if (this.V && (getLayoutParams() instanceof ViewGroup.MarginLayoutParams)) {
            Resources resources = getResources();
            int dimensionPixelSize = resources.getDimensionPixelSize(d.f20348s);
            int dimensionPixelSize2 = resources.getDimensionPixelSize(getDefaultMarginVerticalResource());
            ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) getLayoutParams();
            marginLayoutParams.leftMargin = T(marginLayoutParams.leftMargin, dimensionPixelSize);
            marginLayoutParams.topMargin = T(marginLayoutParams.topMargin, dimensionPixelSize2);
            marginLayoutParams.rightMargin = T(marginLayoutParams.rightMargin, dimensionPixelSize);
            marginLayoutParams.bottomMargin = T(marginLayoutParams.bottomMargin, dimensionPixelSize2);
        }
    }

    public final void Z() {
        if (Build.VERSION.SDK_INT < 34) {
            return;
        }
        boolean z10 = getLayoutDirection() == 1;
        ImageButton d10 = p.d(this);
        int width = (d10 == null || !d10.isClickable()) ? 0 : z10 ? getWidth() - d10.getLeft() : d10.getRight();
        ActionMenuView a10 = p.a(this);
        int right = a10 != null ? z10 ? a10.getRight() : getWidth() - a10.getLeft() : 0;
        float f10 = -(z10 ? right : width);
        if (!z10) {
            width = right;
        }
        setHandwritingBoundsOffsets(f10, 0.0f, -width, 0.0f);
    }

    public final void a0() {
        if (getLayoutParams() instanceof AppBarLayout.d) {
            AppBarLayout.d dVar = (AppBarLayout.d) getLayoutParams();
            if (this.f7999g0) {
                if (dVar.c() == 0) {
                    dVar.g(53);
                }
            } else if (dVar.c() == 53) {
                dVar.g(0);
            }
        }
    }

    @Override // android.view.ViewGroup
    public void addView(View view, int i10, ViewGroup.LayoutParams layoutParams) {
        if (this.U && this.f7995c0 == null && !(view instanceof ActionMenuView)) {
            this.f7995c0 = view;
            view.setAlpha(0.0f);
        }
        super.addView(view, i10, layoutParams);
    }

    public View getCenterView() {
        return this.f7995c0;
    }

    public float getCompatElevation() {
        g gVar = this.f8000h0;
        return gVar != null ? gVar.w() : o0.u(this);
    }

    public float getCornerSize() {
        return this.f8000h0.J();
    }

    public int getDefaultMarginVerticalResource() {
        return d.f20349t;
    }

    public int getDefaultNavigationIconResource() {
        return e.f20357c;
    }

    public CharSequence getHint() {
        return this.T.getHint();
    }

    public int getMenuResId() {
        return this.f7998f0;
    }

    public int getStrokeColor() {
        return this.f8000h0.F().getDefaultColor();
    }

    public float getStrokeWidth() {
        return this.f8000h0.H();
    }

    @NonNull
    public CharSequence getText() {
        return this.T.getText();
    }

    @NonNull
    public TextView getTextView() {
        return this.T;
    }

    @Override // androidx.appcompat.widget.Toolbar, android.view.ViewGroup, android.view.View
    public void onAttachedToWindow() {
        super.onAttachedToWindow();
        h.f(this, this.f8000h0);
        Y();
        a0();
    }

    @Override // android.view.View
    public void onInitializeAccessibilityNodeInfo(AccessibilityNodeInfo accessibilityNodeInfo) {
        super.onInitializeAccessibilityNodeInfo(accessibilityNodeInfo);
        accessibilityNodeInfo.setClassName(EditText.class.getCanonicalName());
        accessibilityNodeInfo.setEditable(isEnabled());
        CharSequence text = getText();
        boolean isEmpty = TextUtils.isEmpty(text);
        accessibilityNodeInfo.setHintText(getHint());
        accessibilityNodeInfo.setShowingHintText(isEmpty);
        if (isEmpty) {
            text = getHint();
        }
        accessibilityNodeInfo.setText(text);
    }

    @Override // androidx.appcompat.widget.Toolbar, android.view.ViewGroup, android.view.View
    public void onLayout(boolean z10, int i10, int i11, int i12, int i13) {
        super.onLayout(z10, i10, i11, i12, i13);
        U();
        Z();
    }

    @Override // androidx.appcompat.widget.Toolbar, android.view.View
    public void onMeasure(int i10, int i11) {
        super.onMeasure(i10, i11);
        X(i10, i11);
    }

    @Override // androidx.appcompat.widget.Toolbar, android.view.View
    public void onRestoreInstanceState(Parcelable parcelable) {
        if (!(parcelable instanceof a)) {
            super.onRestoreInstanceState(parcelable);
            return;
        }
        a aVar = (a) parcelable;
        super.onRestoreInstanceState(aVar.a());
        setText(aVar.f8002c);
    }

    @Override // androidx.appcompat.widget.Toolbar, android.view.View
    @NonNull
    public Parcelable onSaveInstanceState() {
        a aVar = new a(super.onSaveInstanceState());
        CharSequence text = getText();
        aVar.f8002c = text == null ? null : text.toString();
        return aVar;
    }

    public void setCenterView(View view) {
        View view2 = this.f7995c0;
        if (view2 != null) {
            removeView(view2);
            this.f7995c0 = null;
        }
        if (view != null) {
            addView(view);
        }
    }

    public void setDefaultScrollFlagsEnabled(boolean z10) {
        this.f7999g0 = z10;
        a0();
    }

    @Override // android.view.View
    public void setElevation(float f10) {
        super.setElevation(f10);
        g gVar = this.f8000h0;
        if (gVar != null) {
            gVar.Z(f10);
        }
    }

    public void setHint(CharSequence charSequence) {
        this.T.setHint(charSequence);
    }

    @Override // androidx.appcompat.widget.Toolbar
    public void setNavigationIcon(Drawable drawable) {
        super.setNavigationIcon(W(drawable));
    }

    @Override // androidx.appcompat.widget.Toolbar
    public void setNavigationOnClickListener(View.OnClickListener onClickListener) {
        if (this.f7994b0) {
            return;
        }
        super.setNavigationOnClickListener(onClickListener);
        setNavigationIconDecorative(onClickListener == null);
    }

    public void setOnLoadAnimationFadeInEnabled(boolean z10) {
        throw null;
    }

    public void setStrokeColor(int i10) {
        if (getStrokeColor() != i10) {
            this.f8000h0.i0(ColorStateList.valueOf(i10));
        }
    }

    public void setStrokeWidth(float f10) {
        if (getStrokeWidth() != f10) {
            this.f8000h0.j0(f10);
        }
    }

    @Override // androidx.appcompat.widget.Toolbar
    public void setSubtitle(CharSequence charSequence) {
    }

    public void setText(CharSequence charSequence) {
        this.T.setText(charSequence);
    }

    @Override // androidx.appcompat.widget.Toolbar
    public void setTitle(CharSequence charSequence) {
    }

    @Override // androidx.appcompat.widget.Toolbar
    public void x(int i10) {
        Menu menu = getMenu();
        boolean z10 = menu instanceof androidx.appcompat.view.menu.e;
        if (z10) {
            ((androidx.appcompat.view.menu.e) menu).e0();
        }
        super.x(i10);
        this.f7998f0 = i10;
        if (z10) {
            ((androidx.appcompat.view.menu.e) menu).d0();
        }
    }

    public static class ScrollingViewBehavior extends AppBarLayout.ScrollingViewBehavior {

        /* renamed from: h, reason: collision with root package name */
        public boolean f8001h;

        public ScrollingViewBehavior() {
            this.f8001h = false;
        }

        @Override // lc.b
        public boolean T() {
            return true;
        }

        public final void Y(AppBarLayout appBarLayout) {
            appBarLayout.setBackgroundColor(0);
            appBarLayout.setTargetElevation(0.0f);
        }

        @Override // com.google.android.material.appbar.AppBarLayout.ScrollingViewBehavior, androidx.coordinatorlayout.widget.CoordinatorLayout.c
        public boolean l(@NonNull CoordinatorLayout coordinatorLayout, @NonNull View view, @NonNull View view2) {
            boolean l10 = super.l(coordinatorLayout, view, view2);
            if (!this.f8001h && (view2 instanceof AppBarLayout)) {
                this.f8001h = true;
                Y((AppBarLayout) view2);
            }
            return l10;
        }

        public ScrollingViewBehavior(@NonNull Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
            this.f8001h = false;
        }
    }

    public void setHint(int i10) {
        this.T.setHint(i10);
    }

    public void setText(int i10) {
        this.T.setText(i10);
    }


    // --- восстановлено из DEX (com/google/android/material/search/SearchBar$a$a) ---
    public static class a implements android.os.Parcelable.ClassLoaderCreator {
        public a() { }
        public com.google.android.material.search.SearchBar.a a(android.os.Parcel p0) { throw new UnsupportedOperationException("stub"); }
        public com.google.android.material.search.SearchBar.a b(android.os.Parcel p0, java.lang.ClassLoader p1) { throw new UnsupportedOperationException("stub"); }
        public com.google.android.material.search.SearchBar.a[] c(int p0) { throw new UnsupportedOperationException("stub"); }
        public java.lang.Object createFromParcel(android.os.Parcel p0) { throw new UnsupportedOperationException("stub"); }
        public java.lang.Object createFromParcel(android.os.Parcel p0, java.lang.ClassLoader p1) { throw new UnsupportedOperationException("stub"); }
        public java.lang.Object[] newArray(int p0) { throw new UnsupportedOperationException("stub"); }
    }
}
