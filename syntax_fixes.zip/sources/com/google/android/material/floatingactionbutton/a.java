package com.google.android.material.floatingactionbutton;

import android.R;
import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.AnimatorSet;
import android.animation.FloatEvaluator;
import android.animation.ObjectAnimator;
import android.animation.TimeInterpolator;
import android.animation.TypeEvaluator;
import android.animation.ValueAnimator;
import android.content.res.ColorStateList;
import android.graphics.Matrix;
import android.graphics.PorterDuff;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.InsetDrawable;
import android.os.Build;
import android.util.Property;
import android.view.View;
import android.view.ViewTreeObserver;
import androidx.annotation.NonNull;
import androidx.core.view.o0;
import id.n;
import java.util.ArrayList;

/* loaded from: classes2.dex */
public class a {
    public static final TimeInterpolator D = kc.a.f21324c;
    public static final int E = jc.b.F;
    public static final int F = jc.b.P;
    public static final int G = jc.b.G;
    public static final int H = jc.b.N;
    public static final int[] I = {android.R.attr.state_pressed, android.R.attr.state_enabled};
    public static final int[] J = {android.R.attr.state_hovered, android.R.attr.state_focused, android.R.attr.state_enabled};
    public static final int[] K = {android.R.attr.state_focused, android.R.attr.state_enabled};
    public static final int[] L = {android.R.attr.state_hovered, android.R.attr.state_enabled};
    public static final int[] M = {android.R.attr.state_enabled};
    public static final int[] N = new int[0];
    public ViewTreeObserver.OnPreDrawListener C;

    /* renamed from: a, reason: collision with root package name */
    public id.k f7876a;
    public id.g b;

    /* renamed from: c, reason: collision with root package name */
    public Drawable f7877c;

    /* renamed from: d, reason: collision with root package name */
    public ad.a f7878d;

    /* renamed from: e, reason: collision with root package name */
    public Drawable f7879e;

    /* renamed from: f, reason: collision with root package name */
    public boolean f7880f;

    /* renamed from: h, reason: collision with root package name */
    public float f7882h;

    /* renamed from: i, reason: collision with root package name */
    public float f7883i;

    /* renamed from: j, reason: collision with root package name */
    public float f7884j;

    /* renamed from: k, reason: collision with root package name */
    public int f7885k;

    /* renamed from: l, reason: collision with root package name */
    @NonNull
    public final bd.j f7886l;

    /* renamed from: m, reason: collision with root package name */
    public Animator f7887m;

    /* renamed from: n, reason: collision with root package name */
    public kc.h f7888n;

    /* renamed from: o, reason: collision with root package name */
    public kc.h f7889o;

    /* renamed from: p, reason: collision with root package name */
    public float f7890p;

    /* renamed from: r, reason: collision with root package name */
    public int f7892r;

    /* renamed from: t, reason: collision with root package name */
    public ArrayList<Animator.AnimatorListener> f7894t;

    /* renamed from: u, reason: collision with root package name */
    public ArrayList<Animator.AnimatorListener> f7895u;

    /* renamed from: v, reason: collision with root package name */
    public ArrayList<j> f7896v;

    /* renamed from: w, reason: collision with root package name */
    public final FloatingActionButton f7897w;

    /* renamed from: x, reason: collision with root package name */
    public final hd.b f7898x;

    /* renamed from: g, reason: collision with root package name */
    public boolean f7881g = true;

    /* renamed from: q, reason: collision with root package name */
    public float f7891q = 1.0f;

    /* renamed from: s, reason: collision with root package name */
    public int f7893s = 0;

    /* renamed from: y, reason: collision with root package name */
    public final Rect f7899y = new Rect();

    /* renamed from: z, reason: collision with root package name */
    public final RectF f7900z = new RectF();
    public final RectF A = new RectF();
    public final Matrix B = new Matrix();

    /* renamed from: com.google.android.material.floatingactionbutton.a$a, reason: collision with other inner class name */
    public class C0126a extends AnimatorListenerAdapter {

        /* renamed from: a, reason: collision with root package name */
        public boolean f7901a;
        public final /* synthetic */ boolean b;

        /* renamed from: c, reason: collision with root package name */
        public final /* synthetic */ k f7902c;

        public C0126a(boolean z10, k kVar) {
            this.b = z10;
            this.f7902c = kVar;
        }

        @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
        public void onAnimationCancel(Animator animator) {
            this.f7901a = true;
        }

        @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
        public void onAnimationEnd(Animator animator) {
            a.this.f7893s = 0;
            a.this.f7887m = null;
            if (this.f7901a) {
                return;
            }
            FloatingActionButton floatingActionButton = a.this.f7897w;
            boolean z10 = this.b;
            floatingActionButton.b(z10 ? 8 : 4, z10);
            k kVar = this.f7902c;
            if (kVar != null) {
                kVar.b();
            }
        }

        @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
        public void onAnimationStart(Animator animator) {
            a.this.f7897w.b(0, this.b);
            a.this.f7893s = 1;
            a.this.f7887m = animator;
            this.f7901a = false;
        }
    }

    public class b extends AnimatorListenerAdapter {

        /* renamed from: a, reason: collision with root package name */
        public final /* synthetic */ boolean f7904a;
        public final /* synthetic */ k b;

        public b(boolean z10, k kVar) {
            this.f7904a = z10;
            this.b = kVar;
        }

        @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
        public void onAnimationEnd(Animator animator) {
            a.this.f7893s = 0;
            a.this.f7887m = null;
            k kVar = this.b;
            if (kVar != null) {
                kVar.a();
            }
        }

        @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
        public void onAnimationStart(Animator animator) {
            a.this.f7897w.b(0, this.f7904a);
            a.this.f7893s = 2;
            a.this.f7887m = animator;
        }
    }

    public class c extends kc.g {
        public c() {
        }

        @Override // android.animation.TypeEvaluator
        /* renamed from: a, reason: merged with bridge method [inline-methods] */
        public Matrix evaluate(float f10, @NonNull Matrix matrix, @NonNull Matrix matrix2) {
            a.this.f7891q = f10;
            return super.evaluate(f10, matrix, matrix2);
        }
    }

    public class d implements ValueAnimator.AnimatorUpdateListener {

        /* renamed from: a, reason: collision with root package name */
        public final /* synthetic */ float f7907a;
        public final /* synthetic */ float b;

        /* renamed from: c, reason: collision with root package name */
        public final /* synthetic */ float f7908c;

        /* renamed from: d, reason: collision with root package name */
        public final /* synthetic */ float f7909d;

        /* renamed from: e, reason: collision with root package name */
        public final /* synthetic */ float f7910e;

        /* renamed from: f, reason: collision with root package name */
        public final /* synthetic */ float f7911f;

        /* renamed from: g, reason: collision with root package name */
        public final /* synthetic */ float f7912g;

        /* renamed from: h, reason: collision with root package name */
        public final /* synthetic */ Matrix f7913h;

        public d(float f10, float f11, float f12, float f13, float f14, float f15, float f16, Matrix matrix) {
            this.f7907a = f10;
            this.b = f11;
            this.f7908c = f12;
            this.f7909d = f13;
            this.f7910e = f14;
            this.f7911f = f15;
            this.f7912g = f16;
            this.f7913h = matrix;
        }

        @Override // android.animation.ValueAnimator.AnimatorUpdateListener
        public void onAnimationUpdate(ValueAnimator valueAnimator) {
            float floatValue = ((Float) valueAnimator.getAnimatedValue()).floatValue();
            a.this.f7897w.setAlpha(kc.a.b(this.f7907a, this.b, 0.0f, 0.2f, floatValue));
            a.this.f7897w.setScaleX(kc.a.a(this.f7908c, this.f7909d, floatValue));
            a.this.f7897w.setScaleY(kc.a.a(this.f7910e, this.f7909d, floatValue));
            a.this.f7891q = kc.a.a(this.f7911f, this.f7912g, floatValue);
            a.this.h(kc.a.a(this.f7911f, this.f7912g, floatValue), this.f7913h);
            a.this.f7897w.setImageMatrix(this.f7913h);
        }
    }

    public class e implements TypeEvaluator<Float> {

        /* renamed from: a, reason: collision with root package name */
        public FloatEvaluator f7915a = new FloatEvaluator();

        public e() {
        }

        @Override // android.animation.TypeEvaluator
        /* renamed from: a, reason: merged with bridge method [inline-methods] */
        public Float evaluate(float f10, Float f11, Float f12) {
            float floatValue = this.f7915a.evaluate(f10, (Number) f11, (Number) f12).floatValue();
            if (floatValue < 0.1f) {
                floatValue = 0.0f;
            }
            return Float.valueOf(floatValue);
        }
    }

    public class f implements ViewTreeObserver.OnPreDrawListener {
        public f() {
        }

        @Override // android.view.ViewTreeObserver.OnPreDrawListener
        public boolean onPreDraw() {
            a.this.H();
            return true;
        }
    }

    public class g extends m {
        public g() {
            super(a.this, null);
        }

        @Override // com.google.android.material.floatingactionbutton.a.m
        public float a() {
            return 0.0f;
        }
    }

    public class h extends m {
        public h() {
            super(a.this, null);
        }

        @Override // com.google.android.material.floatingactionbutton.a.m
        public float a() {
            a aVar = a.this;
            return aVar.f7882h + aVar.f7883i;
        }
    }

    public class i extends m {
        public i() {
            super(a.this, null);
        }

        @Override // com.google.android.material.floatingactionbutton.a.m
        public float a() {
            a aVar = a.this;
            return aVar.f7882h + aVar.f7884j;
        }
    }

    public interface j {
        void a();

        void b();
    }

    public interface k {
        void a();

        void b();
    }

    public class l extends m {
        public l() {
            super(a.this, null);
        }

        @Override // com.google.android.material.floatingactionbutton.a.m
        public float a() {
            return a.this.f7882h;
        }
    }

    public abstract class m extends AnimatorListenerAdapter implements ValueAnimator.AnimatorUpdateListener {

        /* renamed from: a, reason: collision with root package name */
        public boolean f7921a;
        public float b;

        /* renamed from: c, reason: collision with root package name */
        public float f7922c;

        public m() {
        }

        public abstract float a();

        @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
        public void onAnimationEnd(Animator animator) {
            a.this.g0((int) this.f7922c);
            this.f7921a = false;
        }

        @Override // android.animation.ValueAnimator.AnimatorUpdateListener
        public void onAnimationUpdate(@NonNull ValueAnimator valueAnimator) {
            if (!this.f7921a) {
                id.g gVar = a.this.b;
                this.b = gVar == null ? 0.0f : gVar.w();
                this.f7922c = a();
                this.f7921a = true;
            }
            a aVar = a.this;
            float f10 = this.b;
            aVar.g0((int) (f10 + ((this.f7922c - f10) * valueAnimator.getAnimatedFraction())));
        }

        public /* synthetic */ m(a aVar, C0126a c0126a) {
            this();
        }
    }

    public a(FloatingActionButton floatingActionButton, hd.b bVar) {
        this.f7897w = floatingActionButton;
        this.f7898x = bVar;
        bd.j jVar = new bd.j();
        this.f7886l = jVar;
        jVar.a(I, k(new i()));
        jVar.a(J, k(new h()));
        jVar.a(K, k(new h()));
        jVar.a(L, k(new h()));
        jVar.a(M, k(new l()));
        jVar.a(N, k(new g()));
        this.f7890p = floatingActionButton.getRotation();
    }

    public void A() {
        throw null;
    }

    public void B() {
        id.g gVar = this.b;
        if (gVar != null) {
            id.h.f(this.f7897w, gVar);
        }
        if (K()) {
            this.f7897w.getViewTreeObserver().addOnPreDrawListener(q());
        }
    }

    public void C() {
        throw null;
    }

    public void D() {
        ViewTreeObserver viewTreeObserver = this.f7897w.getViewTreeObserver();
        ViewTreeObserver.OnPreDrawListener onPreDrawListener = this.C;
        if (onPreDrawListener != null) {
            viewTreeObserver.removeOnPreDrawListener(onPreDrawListener);
            this.C = null;
        }
    }

    public void E(int[] iArr) {
        throw null;
    }

    public void F(float f10, float f11, float f12) {
        throw null;
    }

    public void G(@NonNull Rect rect) {
        x2.g.h(this.f7879e, "Didn't initialize content background");
        if (!Z()) {
            this.f7898x.b(this.f7879e);
        } else {
            this.f7898x.b(new InsetDrawable(this.f7879e, rect.left, rect.top, rect.right, rect.bottom));
        }
    }

    public void H() {
        float rotation = this.f7897w.getRotation();
        if (this.f7890p != rotation) {
            this.f7890p = rotation;
            d0();
        }
    }

    public void I() {
        ArrayList<j> arrayList = this.f7896v;
        if (arrayList != null) {
            int size = arrayList.size();
            int i10 = 0;
            while (i10 < size) {
                j jVar = arrayList.get(i10);
                i10++;
                jVar.b();
            }
        }
    }

    public void J() {
        ArrayList<j> arrayList = this.f7896v;
        if (arrayList != null) {
            int size = arrayList.size();
            int i10 = 0;
            while (i10 < size) {
                j jVar = arrayList.get(i10);
                i10++;
                jVar.a();
            }
        }
    }

    public boolean K() {
        throw null;
    }

    public void L(ColorStateList colorStateList) {
        id.g gVar = this.b;
        if (gVar != null) {
            gVar.setTintList(colorStateList);
        }
        ad.a aVar = this.f7878d;
        if (aVar != null) {
            aVar.c(colorStateList);
        }
    }

    public void M(PorterDuff.Mode mode) {
        id.g gVar = this.b;
        if (gVar != null) {
            gVar.setTintMode(mode);
        }
    }

    public final void N(float f10) {
        if (this.f7882h != f10) {
            this.f7882h = f10;
            F(f10, this.f7883i, this.f7884j);
        }
    }

    public void O(boolean z10) {
        this.f7880f = z10;
    }

    public final void P(kc.h hVar) {
        this.f7889o = hVar;
    }

    public final void Q(float f10) {
        if (this.f7883i != f10) {
            this.f7883i = f10;
            F(this.f7882h, f10, this.f7884j);
        }
    }

    public final void R(float f10) {
        this.f7891q = f10;
        Matrix matrix = this.B;
        h(f10, matrix);
        this.f7897w.setImageMatrix(matrix);
    }

    public final void S(int i10) {
        if (this.f7892r != i10) {
            this.f7892r = i10;
            e0();
        }
    }

    public void T(int i10) {
        this.f7885k = i10;
    }

    public final void U(float f10) {
        if (this.f7884j != f10) {
            this.f7884j = f10;
            F(this.f7882h, this.f7883i, f10);
        }
    }

    public void V(ColorStateList colorStateList) {
        Drawable drawable = this.f7877c;
        if (drawable != null) {
            q2.a.o(drawable, gd.b.a(colorStateList));
        }
    }

    public void W(boolean z10) {
        this.f7881g = z10;
        f0();
    }

    public final void X(@NonNull id.k kVar) {
        this.f7876a = kVar;
        id.g gVar = this.b;
        if (gVar != null) {
            gVar.setShapeAppearanceModel(kVar);
        }
        Object obj = this.f7877c;
        if (obj instanceof n) {
            ((n) obj).setShapeAppearanceModel(kVar);
        }
        ad.a aVar = this.f7878d;
        if (aVar != null) {
            aVar.f(kVar);
        }
    }

    public final void Y(kc.h hVar) {
        this.f7888n = hVar;
    }

    public boolean Z() {
        throw null;
    }

    public final boolean a0() {
        return o0.R(this.f7897w) && !this.f7897w.isInEditMode();
    }

    public final boolean b0() {
        return !this.f7880f || this.f7897w.getSizeDimension() >= this.f7885k;
    }

    public void c0(k kVar, boolean z10) {
        a aVar;
        AnimatorSet j10;
        if (z()) {
            return;
        }
        Animator animator = this.f7887m;
        if (animator != null) {
            animator.cancel();
        }
        int i10 = 0;
        boolean z11 = this.f7888n == null;
        if (!a0()) {
            this.f7897w.b(0, z10);
            this.f7897w.setAlpha(1.0f);
            this.f7897w.setScaleY(1.0f);
            this.f7897w.setScaleX(1.0f);
            R(1.0f);
            if (kVar != null) {
                kVar.a();
                return;
            }
            return;
        }
        if (this.f7897w.getVisibility() != 0) {
            this.f7897w.setAlpha(0.0f);
            this.f7897w.setScaleY(z11 ? 0.4f : 0.0f);
            this.f7897w.setScaleX(z11 ? 0.4f : 0.0f);
            R(z11 ? 0.4f : 0.0f);
        }
        kc.h hVar = this.f7888n;
        if (hVar != null) {
            j10 = i(hVar, 1.0f, 1.0f, 1.0f);
            aVar = this;
        } else {
            aVar = this;
            j10 = aVar.j(1.0f, 1.0f, 1.0f, E, F);
        }
        j10.addListener(new b(z10, kVar));
        ArrayList<Animator.AnimatorListener> arrayList = aVar.f7894t;
        if (arrayList != null) {
            int size = arrayList.size();
            while (i10 < size) {
                Animator.AnimatorListener animatorListener = arrayList.get(i10);
                i10++;
                j10.addListener(animatorListener);
            }
        }
        j10.start();
    }

    public void d0() {
        throw null;
    }

    public void e(@NonNull Animator.AnimatorListener animatorListener) {
        if (this.f7895u == null) {
            this.f7895u = new ArrayList<>();
        }
        this.f7895u.add(animatorListener);
    }

    public final void e0() {
        R(this.f7891q);
    }

    public void f(@NonNull Animator.AnimatorListener animatorListener) {
        if (this.f7894t == null) {
            this.f7894t = new ArrayList<>();
        }
        this.f7894t.add(animatorListener);
    }

    public final void f0() {
        Rect rect = this.f7899y;
        r(rect);
        G(rect);
        this.f7898x.a(rect.left, rect.top, rect.right, rect.bottom);
    }

    public void g(@NonNull j jVar) {
        if (this.f7896v == null) {
            this.f7896v = new ArrayList<>();
        }
        this.f7896v.add(jVar);
    }

    public void g0(float f10) {
        id.g gVar = this.b;
        if (gVar != null) {
            gVar.Z(f10);
        }
    }

    public final void h(float f10, @NonNull Matrix matrix) {
        matrix.reset();
        if (this.f7897w.getDrawable() == null || this.f7892r == 0) {
            return;
        }
        RectF rectF = this.f7900z;
        RectF rectF2 = this.A;
        rectF.set(0.0f, 0.0f, r0.getIntrinsicWidth(), r0.getIntrinsicHeight());
        int i10 = this.f7892r;
        rectF2.set(0.0f, 0.0f, i10, i10);
        matrix.setRectToRect(rectF, rectF2, Matrix.ScaleToFit.CENTER);
        int i11 = this.f7892r;
        matrix.postScale(f10, f10, i11 / 2.0f, i11 / 2.0f);
    }

    public final void h0(ObjectAnimator objectAnimator) {
        if (Build.VERSION.SDK_INT != 26) {
            return;
        }
        objectAnimator.setEvaluator(new e());
    }

    @NonNull
    public final AnimatorSet i(@NonNull kc.h hVar, float f10, float f11, float f12) {
        ArrayList arrayList = new ArrayList();
        ObjectAnimator ofFloat = ObjectAnimator.ofFloat(this.f7897w, (Property<FloatingActionButton, Float>) View.ALPHA, f10);
        hVar.e("opacity").a(ofFloat);
        arrayList.add(ofFloat);
        ObjectAnimator ofFloat2 = ObjectAnimator.ofFloat(this.f7897w, (Property<FloatingActionButton, Float>) View.SCALE_X, f11);
        hVar.e("scale").a(ofFloat2);
        h0(ofFloat2);
        arrayList.add(ofFloat2);
        ObjectAnimator ofFloat3 = ObjectAnimator.ofFloat(this.f7897w, (Property<FloatingActionButton, Float>) View.SCALE_Y, f11);
        hVar.e("scale").a(ofFloat3);
        h0(ofFloat3);
        arrayList.add(ofFloat3);
        h(f12, this.B);
        ObjectAnimator ofObject = ObjectAnimator.ofObject(this.f7897w, new kc.f(), new c(), new Matrix(this.B));
        hVar.e("iconScale").a(ofObject);
        arrayList.add(ofObject);
        AnimatorSet animatorSet = new AnimatorSet();
        kc.b.a(animatorSet, arrayList);
        return animatorSet;
    }

    public final AnimatorSet j(float f10, float f11, float f12, int i10, int i11) {
        AnimatorSet animatorSet = new AnimatorSet();
        ArrayList arrayList = new ArrayList();
        ValueAnimator ofFloat = ValueAnimator.ofFloat(0.0f, 1.0f);
        ofFloat.addUpdateListener(new d(this.f7897w.getAlpha(), f10, this.f7897w.getScaleX(), f11, this.f7897w.getScaleY(), this.f7891q, f12, new Matrix(this.B)));
        arrayList.add(ofFloat);
        kc.b.a(animatorSet, arrayList);
        animatorSet.setDuration(dd.h.f(this.f7897w.getContext(), i10, this.f7897w.getContext().getResources().getInteger(jc.g.b)));
        animatorSet.setInterpolator(dd.h.g(this.f7897w.getContext(), i11, kc.a.b));
        return animatorSet;
    }

    @NonNull
    public final ValueAnimator k(@NonNull m mVar) {
        ValueAnimator valueAnimator = new ValueAnimator();
        valueAnimator.setInterpolator(D);
        valueAnimator.setDuration(100L);
        valueAnimator.addListener(mVar);
        valueAnimator.addUpdateListener(mVar);
        valueAnimator.setFloatValues(0.0f, 1.0f);
        return valueAnimator;
    }

    public final Drawable l() {
        return this.f7879e;
    }

    public float m() {
        throw null;
    }

    public boolean n() {
        return this.f7880f;
    }

    public final kc.h o() {
        return this.f7889o;
    }

    public float p() {
        return this.f7883i;
    }

    @NonNull
    public final ViewTreeObserver.OnPreDrawListener q() {
        if (this.C == null) {
            this.C = new f();
        }
        return this.C;
    }

    public void r(@NonNull Rect rect) {
        int v8 = v();
        int max = Math.max(v8, (int) Math.ceil(this.f7881g ? m() + this.f7884j : 0.0f));
        int max2 = Math.max(v8, (int) Math.ceil(r1 * 1.5f));
        rect.set(max, max2, max, max2);
    }

    public float s() {
        return this.f7884j;
    }

    public final id.k t() {
        return this.f7876a;
    }

    public final kc.h u() {
        return this.f7888n;
    }

    public int v() {
        if (this.f7880f) {
            return Math.max((this.f7885k - this.f7897w.getSizeDimension()) / 2, 0);
        }
        return 0;
    }

    public void w(k kVar, boolean z10) {
        a aVar;
        AnimatorSet j10;
        if (y()) {
            return;
        }
        Animator animator = this.f7887m;
        if (animator != null) {
            animator.cancel();
        }
        if (!a0()) {
            this.f7897w.b(z10 ? 8 : 4, z10);
            if (kVar != null) {
                kVar.b();
                return;
            }
            return;
        }
        kc.h hVar = this.f7889o;
        if (hVar != null) {
            j10 = i(hVar, 0.0f, 0.0f, 0.0f);
            aVar = this;
        } else {
            aVar = this;
            j10 = aVar.j(0.0f, 0.4f, 0.4f, G, H);
        }
        j10.addListener(new C0126a(z10, kVar));
        ArrayList<Animator.AnimatorListener> arrayList = aVar.f7895u;
        if (arrayList != null) {
            int size = arrayList.size();
            int i10 = 0;
            while (i10 < size) {
                Animator.AnimatorListener animatorListener = arrayList.get(i10);
                i10++;
                j10.addListener(animatorListener);
            }
        }
        j10.start();
    }

    public void x(ColorStateList colorStateList, PorterDuff.Mode mode, ColorStateList colorStateList2, int i10) {
        throw null;
    }

    public boolean y() {
        return this.f7897w.getVisibility() == 0 ? this.f7893s == 1 : this.f7893s != 2;
    }

    public boolean z() {
        return this.f7897w.getVisibility() != 0 ? this.f7893s == 2 : this.f7893s != 1;
    }
}
