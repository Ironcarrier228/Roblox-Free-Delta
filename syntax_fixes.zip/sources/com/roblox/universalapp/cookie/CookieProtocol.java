package com.roblox.universalapp.cookie;

import an.b;
import android.os.Handler;
import android.os.Looper;
import android.webkit.ValueCallback;
import androidx.annotation.Keep;

import com.roblox.universalapp.cookie.JNICookieProtocol;
import dl.e;
import dl.j;
import ok.q;

/* loaded from: classes2.dex */
public class CookieProtocol {

    public static class OnSetCookieHandlerImpl implements JNICookieProtocol.OnSetCookieHandler {
        private static final String TAG = "OnSetCookieHandlerImpl";

        public static /* synthetic */ void b(String str, Boolean bool) {
            if (bool.booleanValue()) {
                q.h(TAG, "Updated WebViewCookieHandler with Cookies from URL " + str);
                return;
            }
            q.e(TAG, "Failed to update WebViewCookieHandler with Cookies from URL " + str);
        }

        @Override // com.roblox.universalapp.cookie.JNICookieProtocol.OnSetCookieHandler
        public void onSetCookie(String[] strArr, final String str) {
            for (final String str2 : strArr) {
                new Handler(Looper.getMainLooper()).post(new Runnable() { // from class: om.b
                    @Override // java.lang.Runnable
                    public final void run() {
                        j.e().j(r0, str2, new ValueCallback() { // from class: om.a
                            @Override // android.webkit.ValueCallback
                            public final void onReceiveValue(Object obj) {
                                CookieProtocol.OnSetCookieHandlerImpl.b(r1, (Boolean) obj);
                            }
                        }, e.c.f12526d);
                    }
                });
            }
        }
    }

    public static class a {

        /* renamed from: a, reason: collision with root package name */
        public static final CookieProtocol f9803a = new CookieProtocol();
    }

    public static CookieProtocol a() {
        return a.f9803a;
    }

    @Keep
    public static void setCookie(String str, String str2) {
        q.b("CookieProtocol", "setCookie() url = " + str + " cookie = " + str2);
        j.e().k(str, str2, e.c.f12526d);
    }

    public CookieProtocol() {
        b.a(new OnSetCookieHandlerImpl());
    }
}
