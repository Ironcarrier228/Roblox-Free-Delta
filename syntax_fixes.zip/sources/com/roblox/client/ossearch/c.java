package com.roblox.client.ossearch;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import com.github.luben.zstd.BuildConfig;
import com.roblox.client.RobloxApplication;
import java.io.File;
import java.io.FileOutputStream;
import java.util.Collection;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.function.BiConsumer;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.collections.m;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import lu.k;
import ok.q;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import zt.h;
import zt.i;
import zt.n;
import zt.o;

@Metadata(d1 = {"\u0000E\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0006\n\u0002\b\u0006*\u0001\u001c\u0018\u0000  2\u00020\u0001:\u0001\u0016B\u0011\b\u0001\u0012\u0006\u0010\u0003\u001a\u00020\u0002¢\u0006\u0004\b\u0004\u0010\u0005J\u0017\u0010\t\u001a\u0004\u0018\u00010\b2\u0006\u0010\u0007\u001a\u00020\u0006¢\u0006\u0004\b\t\u0010\nJ\u001d\u0010\r\u001a\u00020\f2\u0006\u0010\u0007\u001a\u00020\u00062\u0006\u0010\u000b\u001a\u00020\b¢\u0006\u0004\b\r\u0010\u000eJ\r\u0010\u0010\u001a\u00020\u000f¢\u0006\u0004\b\u0010\u0010\u0011J\u0013\u0010\u0013\u001a\u00020\u0012*\u00020\u0006H\u0002¢\u0006\u0004\b\u0013\u0010\u0014R\u0014\u0010\u0018\u001a\u00020\u00158\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b\u0016\u0010\u0017R\u0014\u0010\u001b\u001a\u00020\u00128\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b\u0019\u0010\u001aR\u0014\u0010\u001f\u001a\u00020\u001c8\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b\u001d\u0010\u001e¨\u0006!"}, d2 = {"Lcom/roblox/client/ossearch/c;", BuildConfig.FLAVOR, "Landroid/content/Context;", "context", "<init>", "(Landroid/content/Context;)V", BuildConfig.FLAVOR, "thumbnailId", "Landroid/graphics/Bitmap;", "i", "(Ljava/lang/String;)Landroid/graphics/Bitmap;", "bitmap", BuildConfig.FLAVOR, "k", "(Ljava/lang/String;Landroid/graphics/Bitmap;)Z", BuildConfig.FLAVOR, "f", "()V", "Ljava/io/File;", "l", "(Ljava/lang/String;)Ljava/io/File;", BuildConfig.FLAVOR, xe.a.f36648e, "I", "maxEntries", k6.b.f21144e, "Ljava/io/File;", "cacheDir", "com/roblox/client/ossearch/c$b", "c", "Lcom/roblox/client/ossearch/c$b;", "lru", "d", "NativeShell_googleProdRelease"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* loaded from: classes2.dex */
public final class c {

    /* renamed from: d, reason: collision with root package name and from kotlin metadata */
    @NotNull
    public static final Companion INSTANCE = new Companion(null);

    /* renamed from: e, reason: collision with root package name */
    @NotNull
    public static final h<c> f9059e = i.a(new Function0() { // from class: hj.b
        @Override // kotlin.jvm.functions.Function0
        public final Object invoke() {
            com.roblox.client.ossearch.c j10;
            j10 = com.roblox.client.ossearch.c.j();
            return j10;
        }
    });

    /* renamed from: a, reason: collision with root package name and from kotlin metadata */
    public final int maxEntries;

    /* renamed from: b, reason: from kotlin metadata */
    @NotNull
    public final File cacheDir;

    /* renamed from: c, reason: collision with root package name and from kotlin metadata */
    @NotNull
    public final b lru;

    @Metadata(d1 = {"\u0000\u001c\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0010\u000e\n\u0002\b\u0003\b\u0086\u0003\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003R\u001b\u0010\t\u001a\u00020\u00048FX\u0086\u0084\u0002¢\u0006\f\n\u0004\b\u0005\u0010\u0006\u001a\u0004\b\u0007\u0010\bR\u0014\u0010\u000b\u001a\u00020\n8\u0002X\u0082T¢\u0006\u0006\n\u0004\b\u000b\u0010\f¨\u0006\r"}, d2 = {"Lcom/roblox/client/ossearch/c$a;", BuildConfig.FLAVOR, "<init>", "()V", "Lcom/roblox/client/ossearch/c;", "instance$delegate", "Lzt/h;", xe.a.f36648e, "()Lcom/roblox/client/ossearch/c;", "instance", BuildConfig.FLAVOR, "TAG", "Ljava/lang/String;", "NativeShell_googleProdRelease"}, k = 1, mv = {2, 2, 0}, xi = 48)
    /* renamed from: com.roblox.client.ossearch.c$a, reason: from kotlin metadata */
    public static final class Companion {
        public /* synthetic */ Companion(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }

        @NotNull
        public final c a() {
            return (c) c.f9059e.getValue();
        }

        public Companion() {
        }
    }

    @Metadata(d1 = {"\u0000#\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\u000e\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010&\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0003*\u0001\u0000\b\n\u0018\u00002\u001e\u0012\u0004\u0012\u00020\u0002\u0012\u0004\u0012\u00020\u00030\u0001j\u000e\u0012\u0004\u0012\u00020\u0002\u0012\u0004\u0012\u00020\u0003`\u0004J#\u0010\b\u001a\u00020\u00072\u0012\u0010\u0006\u001a\u000e\u0012\u0004\u0012\u00020\u0002\u0012\u0004\u0012\u00020\u00030\u0005H\u0014¢\u0006\u0004\b\b\u0010\t¨\u0006\n"}, d2 = {"com/roblox/client/ossearch/c$b", "Ljava/util/LinkedHashMap;", BuildConfig.FLAVOR, "Ljava/io/File;", "Lkotlin/collections/LinkedHashMap;", BuildConfig.FLAVOR, "eldest", BuildConfig.FLAVOR, "removeEldestEntry", "(Ljava/util/Map$Entry;)Z", "NativeShell_googleProdRelease"}, k = 1, mv = {2, 2, 0}, xi = 48)
    public static final class b extends LinkedHashMap<String, File> {
        public b(int i10) {
            super(i10, 0.75f, true);
        }

        public /* bridge */ boolean a(String str) {
            return super.containsKey(str);
        }

        public /* bridge */ boolean b(File file) {
            return super.containsValue(file);
        }

        public /* bridge */ File c(String str) {
            return (File) super.get(str);
        }

        @Override // java.util.HashMap, java.util.AbstractMap, java.util.Map
        public final /* bridge */ boolean containsKey(Object obj) {
            if (obj instanceof String) {
                return a((String) obj);
            }
            return false;
        }

        @Override // java.util.LinkedHashMap, java.util.HashMap, java.util.AbstractMap, java.util.Map
        public final /* bridge */ boolean containsValue(Object obj) {
            if (obj instanceof File) {
                return b((File) obj);
            }
            return false;
        }

        public /* bridge */ Set<Map.Entry<String, File>> e() {
            return super.entrySet();
        }

        @Override // java.util.LinkedHashMap, java.util.HashMap, java.util.AbstractMap, java.util.Map
        public final /* bridge */ Set<Map.Entry<String, File>> entrySet() {
            return e();
        }

        public /* bridge */ Set<String> f() {
            return super.keySet();
        }

        @Override // java.util.LinkedHashMap, java.util.HashMap, java.util.AbstractMap, java.util.Map
        public final /* bridge */ /* synthetic */ Object get(Object obj) {
            if (obj instanceof String) {
                return c((String) obj);
            }
            return null;
        }

        @Override // java.util.LinkedHashMap, java.util.HashMap, java.util.Map
        public final /* bridge */ /* synthetic */ Object getOrDefault(Object obj, Object obj2) {
            return !(obj instanceof String) ? obj2 : i((String) obj, (File) obj2);
        }

        public /* bridge */ File i(String str, File file) {
            return (File) super.getOrDefault(str, file);
        }

        public /* bridge */ int k() {
            return super.size();
        }

        @Override // java.util.LinkedHashMap, java.util.HashMap, java.util.AbstractMap, java.util.Map
        public final /* bridge */ Set<String> keySet() {
            return f();
        }

        public /* bridge */ Collection<File> l() {
            return super.values();
        }

        public /* bridge */ File o(String str) {
            return (File) super.remove(str);
        }

        public /* bridge */ boolean p(String str, File file) {
            return super.remove(str, file);
        }

        @Override // java.util.HashMap, java.util.AbstractMap, java.util.Map
        public final /* bridge */ /* synthetic */ Object remove(Object obj) {
            if (obj instanceof String) {
                return o((String) obj);
            }
            return null;
        }

        @Override // java.util.LinkedHashMap
        public boolean removeEldestEntry(Map.Entry<String, File> eldest) {
            Intrinsics.checkNotNullParameter(eldest, "eldest");
            if (size() <= c.this.maxEntries) {
                return false;
            }
            if (eldest.getValue().delete()) {
                return true;
            }
            q.k("ShortcutThumbnailCache", "Failed to delete evicted thumbnail: " + ((Object) eldest.getKey()));
            return true;
        }

        @Override // java.util.HashMap, java.util.AbstractMap, java.util.Map
        public final /* bridge */ int size() {
            return k();
        }

        @Override // java.util.LinkedHashMap, java.util.HashMap, java.util.AbstractMap, java.util.Map
        public final /* bridge */ Collection<File> values() {
            return l();
        }

        @Override // java.util.HashMap, java.util.Map
        public final /* bridge */ boolean remove(Object obj, Object obj2) {
            if ((obj instanceof String) && (obj2 instanceof File)) {
                return p((String) obj, (File) obj2);
            }
            return false;
        }
    }

    @Metadata(k = 3, mv = {2, 2, 0}, xi = 48)
    /* renamed from: com.roblox.client.ossearch.c$c, reason: collision with other inner class name */
    public static final class C0149c<T> implements Comparator {
        /* JADX WARN: Multi-variable type inference failed */
        @Override // java.util.Comparator
        public final int compare(T t8, T t10) {
            return cu.a.a(Long.valueOf(((File) t8).lastModified()), Long.valueOf(((File) t10).lastModified()));
        }
    }

    public c(@NotNull Context context) {
        List<File> f02;
        Intrinsics.checkNotNullParameter(context, "context");
        int max = Math.max(hj.a.a(context), 0);
        this.maxEntries = max;
        File file = new File(context.getCacheDir(), "ossearch_thumbnails");
        file.mkdirs();
        this.cacheDir = file;
        this.lru = new b(max);
        File[] listFiles = file.listFiles();
        if (listFiles == null || (f02 = m.f0(listFiles, new C0149c())) == null) {
            return;
        }
        for (File file2 : f02) {
            b bVar = this.lru;
            Intrinsics.checkNotNull(file2);
            bVar.put(k.q(file2), file2);
        }
    }

    public static final Unit g(String str, File file) {
        Intrinsics.checkNotNullParameter(str, "<unused var>");
        Intrinsics.checkNotNullParameter(file, "file");
        file.delete();
        return Unit.f21504a;
    }

    public static final void h(Function2 function2, Object obj, Object obj2) {
        function2.invoke(obj, obj2);
    }

    public static final c j() {
        Context f10 = RobloxApplication.f();
        Intrinsics.checkNotNullExpressionValue(f10, "getAppContext(...)");
        return new c(f10);
    }

    public final synchronized void f() {
        b bVar = this.lru;
        final Function2 function2 = new Function2() { // from class: hj.c
            @Override // kotlin.jvm.functions.Function2
            public final Object invoke(Object obj, Object obj2) {
                Unit g10;
                g10 = com.roblox.client.ossearch.c.g((String) obj, (File) obj2);
                return g10;
            }
        };
        bVar.forEach(new BiConsumer() { // from class: hj.d
            @Override // java.util.function.BiConsumer
            public final void accept(Object obj, Object obj2) {
                com.roblox.client.ossearch.c.h(Function2.this, obj, obj2);
            }
        });
        this.lru.clear();
    }

    @Nullable
    public final synchronized Bitmap i(@NotNull String thumbnailId) {
        Intrinsics.checkNotNullParameter(thumbnailId, "thumbnailId");
        File file = (File) this.lru.get(thumbnailId);
        if (file == null) {
            q.b("ShortcutThumbnailCache", "Cache miss for thumbnail: " + thumbnailId);
            return null;
        }
        q.b("ShortcutThumbnailCache", "Cache hit for thumbnail: " + thumbnailId);
        return BitmapFactory.decodeFile(file.getAbsolutePath());
    }

    public final synchronized boolean k(@NotNull String thumbnailId, @NotNull Bitmap bitmap) {
        Object b10;
        try {
            Intrinsics.checkNotNullParameter(thumbnailId, "thumbnailId");
            Intrinsics.checkNotNullParameter(bitmap, "bitmap");
            File l10 = l(thumbnailId);
            try {
                n.Companion companion = n.INSTANCE;
                FileOutputStream fileOutputStream = new FileOutputStream(l10);
                try {
                    bitmap.compress(Bitmap.CompressFormat.PNG, 100, fileOutputStream);
                    lu.c.a(fileOutputStream, null);
                    this.lru.put(thumbnailId, l10);
                    b10 = n.b(Unit.f21504a);
                } finally {
                }
            } catch (Throwable th2) {
                n.Companion companion2 = n.INSTANCE;
                b10 = n.b(o.a(th2));
            }
            Throwable e10 = n.e(b10);
            if (e10 != null) {
                q.e("ShortcutThumbnailCache", "Failed to cache thumbnail with id " + thumbnailId + ". Error: " + e10.getMessage());
            }
        } catch (Throwable th3) {
            throw th3;
        }
        return n.h(b10);
    }

    public final File l(String str) {
        return new File(this.cacheDir, str + ".png");
    }


    // --- восстановлено из DEX (com/roblox/client/ossearch/c$a) ---
    public static class a {
        public a() { }
        public a(kotlin.jvm.internal.DefaultConstructorMarker p0) { }
        public com.roblox.client.ossearch.c a() { throw new UnsupportedOperationException("stub"); }
    }
}
