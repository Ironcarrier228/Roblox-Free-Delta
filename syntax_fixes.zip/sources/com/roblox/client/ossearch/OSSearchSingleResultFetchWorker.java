package com.roblox.client.ossearch;

import android.content.Context;
import androidx.work.CoroutineWorker;
import androidx.work.WorkerParameters;
import androidx.work.b;
import androidx.work.c;
import av.g1;
import av.l0;
import com.github.luben.zstd.BuildConfig;
import com.roblox.client.shortcuts.PinShortcutHandler;
import com.roblox.platform.http.postbody.notifications.SearchResultRequestItem;
import com.roblox.platform.http.postbody.notifications.SingleOSSearchResultPostBody;
import com.roblox.platform.http.returntypes.ossearch.SearchResultIdentifier;
import gu.f;
import gu.m;
import kotlin.Metadata;
import kotlin.Pair;
import kotlin.Unit;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import m2.e;
import ok.q;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import y5.j;
import y5.p0;
import y5.x;
import y5.z;
import zt.o;
import zt.s;

@Metadata(d1 = {"\u0000.\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u000b\u0018\u0000 \u00182\u00020\u0001:\u0001\u000fB\u0017\u0012\u0006\u0010\u0003\u001a\u00020\u0002\u0012\u0006\u0010\u0005\u001a\u00020\u0004¢\u0006\u0004\b\u0006\u0010\u0007J\u0010\u0010\t\u001a\u00020\bH\u0096@¢\u0006\u0004\b\t\u0010\nJ\u0011\u0010\f\u001a\u0004\u0018\u00010\u000bH\u0002¢\u0006\u0004\b\f\u0010\rR(\u0010\u0017\u001a\u00020\u000e8\u0000@\u0000X\u0081\u000e¢\u0006\u0018\n\u0004\b\u000f\u0010\u0010\u0012\u0004\b\u0015\u0010\u0016\u001a\u0004\b\u0011\u0010\u0012\"\u0004\b\u0013\u0010\u0014¨\u0006\u0019"}, d2 = {"Lcom/roblox/client/ossearch/OSSearchSingleResultFetchWorker;", "Landroidx/work/CoroutineWorker;", "Landroid/content/Context;", "appContext", "Landroidx/work/WorkerParameters;", "params", "<init>", "(Landroid/content/Context;Landroidx/work/WorkerParameters;)V", "Landroidx/work/c$a;", "doWork", "(Leu/b;)Ljava/lang/Object;", "Lcom/roblox/platform/http/postbody/notifications/SingleOSSearchResultPostBody;", "c", "()Lcom/roblox/platform/http/postbody/notifications/SingleOSSearchResultPostBody;", "Lav/l0;", xe.a.f36648e, "Lav/l0;", "d", "()Lav/l0;", "setIoDispatcher$NativeShell_googleProdRelease", "(Lav/l0;)V", "getIoDispatcher$NativeShell_googleProdRelease$annotations", "()V", "ioDispatcher", k6.b.f21144e, "NativeShell_googleProdRelease"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* loaded from: classes2.dex */
public final class OSSearchSingleResultFetchWorker extends CoroutineWorker {

    /* renamed from: b, reason: from kotlin metadata */
    @NotNull
    public static final Companion INSTANCE = new Companion(null);

    /* renamed from: a, reason: collision with root package name and from kotlin metadata */
    @NotNull
    public l0 ioDispatcher;

    @Metadata(d1 = {"\u0000(\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\t\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0004\n\u0002\u0010\u000e\n\u0002\b\u0004\b\u0086\u0003\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\u001f\u0010\t\u001a\u00020\b2\u0006\u0010\u0005\u001a\u00020\u00042\u0006\u0010\u0007\u001a\u00020\u0006H\u0007¢\u0006\u0004\b\t\u0010\nJ\u0015\u0010\u000b\u001a\u00020\b2\u0006\u0010\u0005\u001a\u00020\u0004¢\u0006\u0004\b\u000b\u0010\fR\u0014\u0010\u000e\u001a\u00020\r8\u0002X\u0082T¢\u0006\u0006\n\u0004\b\u000e\u0010\u000fR\u0014\u0010\u0010\u001a\u00020\r8\u0002X\u0082T¢\u0006\u0006\n\u0004\b\u0010\u0010\u000f¨\u0006\u0011"}, d2 = {"Lcom/roblox/client/ossearch/OSSearchSingleResultFetchWorker$a;", BuildConfig.FLAVOR, "<init>", "()V", "Landroid/content/Context;", "context", BuildConfig.FLAVOR, PinShortcutHandler.EXTRA_PLACE_ID, BuildConfig.FLAVOR, k6.b.f21144e, "(Landroid/content/Context;J)V", xe.a.f36648e, "(Landroid/content/Context;)V", BuildConfig.FLAVOR, "WORK_NAME", "Ljava/lang/String;", "TAG", "NativeShell_googleProdRelease"}, k = 1, mv = {2, 2, 0}, xi = 48)
    /* renamed from: com.roblox.client.ossearch.OSSearchSingleResultFetchWorker$a, reason: from kotlin metadata */
    public static final class Companion {
        public /* synthetic */ Companion(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }

        public final void a(@NotNull Context context) {
            Intrinsics.checkNotNullParameter(context, "context");
            p0.Companion companion = p0.INSTANCE;
            Context applicationContext = context.getApplicationContext();
            Intrinsics.checkNotNullExpressionValue(applicationContext, "getApplicationContext(...)");
            companion.a(applicationContext).b("fetch_unique_search_result");
        }

        public final void b(@NotNull Context context, long placeId) {
            Intrinsics.checkNotNullParameter(context, "context");
            q.h("OSSearchSingleResultFetchWorker", "Scheduling immediate OS search index sync");
            p0.Companion companion = p0.INSTANCE;
            Context applicationContext = context.getApplicationContext();
            Intrinsics.checkNotNullExpressionValue(applicationContext, "getApplicationContext(...)");
            p0 a10 = companion.a(applicationContext);
            j jVar = j.f37496d;
            z.a aVar = new z.a(OSSearchSingleResultFetchWorker.class);
            Pair[] pairArr = {s.a("place_id", Long.valueOf(placeId))};
            b.a aVar2 = new b.a();
            Pair pair = pairArr[0];
            aVar2.b((String) pair.c(), pair.d());
            a10.g("fetch_unique_search_result", jVar, aVar.o(aVar2.a()).k(new y5.d(x.b, false, false, true, 6, null)).b());
        }

        public Companion() {
        }
    }

    @Metadata(k = 3, mv = {2, 2, 0}, xi = 48)
    @f(c = "com.roblox.client.ossearch.OSSearchSingleResultFetchWorker", f = "OSSearchSingleResultFetchWorker.kt", l = {33, 36}, m = "doWork", v = 1)
    public static final class b extends gu.d {

        /* renamed from: t, reason: collision with root package name */
        public Object f9034t;

        /* renamed from: u, reason: collision with root package name */
        public /* synthetic */ Object f9035u;

        /* renamed from: w, reason: collision with root package name */
        public int f9037w;

        public b(eu.b<? super b> bVar) {
            super(bVar);
        }

        @Override // gu.a
        @Nullable
        public final Object invokeSuspend(@NotNull Object obj) {
            this.f9035u = obj;
            this.f9037w |= Integer.MIN_VALUE;
            return OSSearchSingleResultFetchWorker.this.doWork(this);
        }
    }

    @Metadata(d1 = {"\u0000\u0010\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\u0010\u0003\u001a\u00070\u0001¢\u0006\u0002\b\u0002*\u00020\u0000H\n¢\u0006\u0004\b\u0003\u0010\u0004"}, d2 = {"Lav/p0;", "Landroidx/work/c$a;", "Lkotlin/jvm/internal/EnhancedNullability;", "<anonymous>", "(Lav/p0;)Landroidx/work/c$a;"}, k = 3, mv = {2, 2, 0})
    @f(c = "com.roblox.client.ossearch.OSSearchSingleResultFetchWorker$doWork$2", f = "OSSearchSingleResultFetchWorker.kt", l = {43, 45, 47}, m = "invokeSuspend", v = 1)
    public static final class c extends m implements Function2<av.p0, eu.b<? super c.a>, Object> {
        public Object A;
        public Object B;
        public Object C;
        public Object D;
        public int E;
        public int F;
        public /* synthetic */ Object G;
        public final /* synthetic */ com.roblox.client.ossearch.c I;

        /* renamed from: t, reason: collision with root package name */
        public Object f9038t;

        /* renamed from: u, reason: collision with root package name */
        public Object f9039u;

        /* renamed from: v, reason: collision with root package name */
        public Object f9040v;

        /* renamed from: w, reason: collision with root package name */
        public Object f9041w;

        /* renamed from: x, reason: collision with root package name */
        public Object f9042x;

        /* renamed from: y, reason: collision with root package name */
        public Object f9043y;

        /* renamed from: z, reason: collision with root package name */
        public Object f9044z;

        @Metadata(d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0010\u000b\n\u0002\b\u0002\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\n¢\u0006\u0004\b\u0002\u0010\u0003"}, d2 = {"Lav/p0;", BuildConfig.FLAVOR, "<anonymous>", "(Lav/p0;)Z"}, k = 3, mv = {2, 2, 0})
        @f(c = "com.roblox.client.ossearch.OSSearchSingleResultFetchWorker$doWork$2$1$1", f = "OSSearchSingleResultFetchWorker.kt", l = {}, m = "invokeSuspend", v = 1)
        public static final class a extends m implements Function2<av.p0, eu.b<? super Boolean>, Object> {

            /* renamed from: t, reason: collision with root package name */
            public int f9045t;

            /* renamed from: u, reason: collision with root package name */
            public final /* synthetic */ OSSearchSingleResultFetchWorker f9046u;

            /* renamed from: v, reason: collision with root package name */
            public final /* synthetic */ m2.c f9047v;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            public a(OSSearchSingleResultFetchWorker oSSearchSingleResultFetchWorker, m2.c cVar, eu.b<? super a> bVar) {
                super(2, bVar);
                this.f9046u = oSSearchSingleResultFetchWorker;
                this.f9047v = cVar;
            }

            @Override // gu.a
            public final eu.b<Unit> create(Object obj, eu.b<?> bVar) {
                return new a(this.f9046u, this.f9047v, bVar);
            }

            @Override // kotlin.jvm.functions.Function2
            public final Object invoke(av.p0 p0Var, eu.b<? super Boolean> bVar) {
                return ((a) create(p0Var, bVar)).invokeSuspend(Unit.f21504a);
            }

            @Override // gu.a
            public final Object invokeSuspend(Object obj) {
                fu.c.e();
                if (this.f9045t != 0) {
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                o.b(obj);
                return gu.b.a(e.h(this.f9046u.getApplicationContext(), this.f9047v));
            }
        }

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public c(com.roblox.client.ossearch.c cVar, eu.b<? super c> bVar) {
            super(2, bVar);
            this.I = cVar;
        }

        @Override // gu.a
        public final eu.b<Unit> create(Object obj, eu.b<?> bVar) {
            c cVar = OSSearchSingleResultFetchWorker.this.new c(this.I, bVar);
            cVar.G = obj;
            return cVar;
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(av.p0 p0Var, eu.b<? super c.a> bVar) {
            return ((c) create(p0Var, bVar)).invokeSuspend(Unit.f21504a);
        }

        /* JADX WARN: Multi-variable type inference failed */
        /* JADX WARN: Removed duplicated region for block: B:113:0x033d  */
        /* JADX WARN: Removed duplicated region for block: B:13:0x013f A[Catch: all -> 0x005b, TryCatch #2 {all -> 0x005b, blocks: (B:8:0x0048, B:10:0x01e8, B:11:0x0139, B:13:0x013f, B:19:0x018d, B:22:0x01fd, B:144:0x00f1), top: B:2:0x0012 }] */
        /* JADX WARN: Removed duplicated region for block: B:21:0x01e1  */
        /* JADX WARN: Removed duplicated region for block: B:22:0x01fd A[Catch: all -> 0x005b, TRY_LEAVE, TryCatch #2 {all -> 0x005b, blocks: (B:8:0x0048, B:10:0x01e8, B:11:0x0139, B:13:0x013f, B:19:0x018d, B:22:0x01fd, B:144:0x00f1), top: B:2:0x0012 }] */
        /* JADX WARN: Removed duplicated region for block: B:25:0x0214  */
        /* JADX WARN: Type inference failed for: r5v0 */
        /* JADX WARN: Type inference failed for: r5v1 */
        /* JADX WARN: Type inference failed for: r5v11, types: [java.lang.Object] */
        /* JADX WARN: Type inference failed for: r5v18 */
        /* JADX WARN: Type inference failed for: r5v2 */
        /* JADX WARN: Type inference failed for: r5v24 */
        /* JADX WARN: Type inference failed for: r5v7 */
        /* JADX WARN: Type inference failed for: r5v9 */
        /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:21:0x01e1 -> B:10:0x01e8). Please report as a decompilation issue!!! */
        @Override // gu.a
        /*
            Code decompiled incorrectly, please refer to instructions dump.
            To view partially-correct add '--show-bad-code' argument
        */
        public final java.lang.Object invokeSuspend(java.lang.Object r27) {
            /*
                Method dump skipped, instructions count: 867
                To view this dump add '--comments-level debug' option
            */
            throw new UnsupportedOperationException("Method not decompiled: com.roblox.client.ossearch.OSSearchSingleResultFetchWorker.c.invokeSuspend(java.lang.Object):java.lang.Object");
        }
    }

    @Metadata(d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\n¢\u0006\u0004\b\u0002\u0010\u0003"}, d2 = {"Lav/p0;", "Lcom/roblox/client/ossearch/c;", "<anonymous>", "(Lav/p0;)Lcom/roblox/client/ossearch/c;"}, k = 3, mv = {2, 2, 0})
    @f(c = "com.roblox.client.ossearch.OSSearchSingleResultFetchWorker$doWork$thumbnailCache$1", f = "OSSearchSingleResultFetchWorker.kt", l = {}, m = "invokeSuspend", v = 1)
    public static final class d extends m implements Function2<av.p0, eu.b<? super com.roblox.client.ossearch.c>, Object> {

        /* renamed from: t, reason: collision with root package name */
        public int f9048t;

        public d(eu.b<? super d> bVar) {
            super(2, bVar);
        }

        @Override // gu.a
        public final eu.b<Unit> create(Object obj, eu.b<?> bVar) {
            return new d(bVar);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(av.p0 p0Var, eu.b<? super com.roblox.client.ossearch.c> bVar) {
            return ((d) create(p0Var, bVar)).invokeSuspend(Unit.f21504a);
        }

        @Override // gu.a
        public final Object invokeSuspend(Object obj) {
            fu.c.e();
            if (this.f9048t != 0) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            o.b(obj);
            return com.roblox.client.ossearch.c.INSTANCE.a();
        }
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public OSSearchSingleResultFetchWorker(@NotNull Context appContext, @NotNull WorkerParameters params) {
        super(appContext, params);
        Intrinsics.checkNotNullParameter(appContext, "appContext");
        Intrinsics.checkNotNullParameter(params, "params");
        this.ioDispatcher = g1.b();
    }

    public final SingleOSSearchResultPostBody c() {
        Long valueOf = Long.valueOf(getInputData().f("place_id", -1L));
        if (valueOf.longValue() <= 0) {
            valueOf = null;
        }
        if (valueOf != null) {
            return new SingleOSSearchResultPostBody(kotlin.collections.o.d(new SearchResultRequestItem(new SearchResultIdentifier(valueOf))));
        }
        return null;
    }

    @NotNull
    /* renamed from: d, reason: from getter */
    public final l0 getIoDispatcher() {
        return this.ioDispatcher;
    }

    /* JADX WARN: Code restructure failed: missing block: B:18:0x006a, code lost:
    
        if (r7 != r1) goto L22;
     */
    /* JADX WARN: Code restructure failed: missing block: B:19:0x006c, code lost:
    
        return r1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:21:0x0054, code lost:
    
        if (r7 == r1) goto L21;
     */
    /* JADX WARN: Removed duplicated region for block: B:20:0x003d  */
    /* JADX WARN: Removed duplicated region for block: B:8:0x0025  */
    @Override // androidx.work.CoroutineWorker
    @org.jetbrains.annotations.Nullable
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public java.lang.Object doWork(@org.jetbrains.annotations.NotNull eu.b<? super androidx.work.c.a> r7) {
        /*
            r6 = this;
            boolean r0 = r7 instanceof com.roblox.client.ossearch.OSSearchSingleResultFetchWorker.b
            if (r0 == 0) goto L13
            r0 = r7
            com.roblox.client.ossearch.OSSearchSingleResultFetchWorker$b r0 = (com.roblox.client.ossearch.OSSearchSingleResultFetchWorker.b) r0
            int r1 = r0.f9037w
            r2 = -2147483648(0xffffffff80000000, float:-0.0)
            r3 = r1 & r2
            if (r3 == 0) goto L13
            int r1 = r1 - r2
            r0.f9037w = r1
            goto L18
        L13:
            com.roblox.client.ossearch.OSSearchSingleResultFetchWorker$b r0 = new com.roblox.client.ossearch.OSSearchSingleResultFetchWorker$b
            r0.<init>(r7)
        L18:
            java.lang.Object r7 = r0.f9035u
            java.lang.Object r1 = fu.c.e()
            int r2 = r0.f9037w
            r3 = 0
            r4 = 2
            r5 = 1
            if (r2 == 0) goto L3d
            if (r2 == r5) goto L39
            if (r2 != r4) goto L31
            java.lang.Object r0 = r0.f9034t
            com.roblox.client.ossearch.c r0 = (com.roblox.client.ossearch.c) r0
            zt.o.b(r7)
            goto L6d
        L31:
            java.lang.IllegalStateException r7 = new java.lang.IllegalStateException
            java.lang.String r0 = "call to 'resume' before 'invoke' with coroutine"
            r7.<init>(r0)
            throw r7
        L39:
            zt.o.b(r7)
            goto L57
        L3d:
            zt.o.b(r7)
            java.lang.String r7 = "OSSearchSingleResultFetchWorker"
            java.lang.String r2 = "Starting OS search result fetch"
            ok.q.h(r7, r2)
            av.l0 r7 = r6.ioDispatcher
            com.roblox.client.ossearch.OSSearchSingleResultFetchWorker$d r2 = new com.roblox.client.ossearch.OSSearchSingleResultFetchWorker$d
            r2.<init>(r3)
            r0.f9037w = r5
            java.lang.Object r7 = av.i.g(r7, r2, r0)
            if (r7 != r1) goto L57
            goto L6c
        L57:
            com.roblox.client.ossearch.c r7 = (com.roblox.client.ossearch.c) r7
            com.roblox.client.ossearch.OSSearchSingleResultFetchWorker$c r2 = new com.roblox.client.ossearch.OSSearchSingleResultFetchWorker$c
            r2.<init>(r7, r3)
            java.lang.Object r7 = gu.l.a(r7)
            r0.f9034t = r7
            r0.f9037w = r4
            java.lang.Object r7 = av.q0.g(r2, r0)
            if (r7 != r1) goto L6d
        L6c:
            return r1
        L6d:
            java.lang.String r0 = "coroutineScope(...)"
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r7, r0)
            return r7
        */
        throw new UnsupportedOperationException("Method not decompiled: com.roblox.client.ossearch.OSSearchSingleResultFetchWorker.doWork(eu.b):java.lang.Object");
    }


    // --- восстановлено из DEX (com/roblox/client/ossearch/OSSearchSingleResultFetchWorker$c$a) ---
    public static class a extends gu.m implements kotlin.jvm.functions.Function2 {
        int t;
        com.roblox.client.ossearch.OSSearchSingleResultFetchWorker u;
        m2.c v;
        public a(com.roblox.client.ossearch.OSSearchSingleResultFetchWorker p0, m2.c p1, eu.b p2) { }
        public eu.b create(java.lang.Object p0, eu.b p1) { throw new UnsupportedOperationException("stub"); }
        public java.lang.Object invoke(av.p0 p0, eu.b p1) { throw new UnsupportedOperationException("stub"); }
        public java.lang.Object invoke(java.lang.Object p0, java.lang.Object p1) { throw new UnsupportedOperationException("stub"); }
        public java.lang.Object invokeSuspend(java.lang.Object p0) { throw new UnsupportedOperationException("stub"); }
    }
}
