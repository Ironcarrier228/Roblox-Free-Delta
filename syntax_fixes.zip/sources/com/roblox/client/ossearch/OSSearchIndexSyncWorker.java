package com.roblox.client.ossearch;

import android.content.Context;
import android.graphics.Bitmap;
import androidx.work.CoroutineWorker;
import androidx.work.WorkerParameters;
import androidx.work.c;
import av.g1;
import av.l0;
import com.appsflyer.share.attribution.RequestError;
import com.github.luben.zstd.BuildConfig;
import com.google.mlkit.vision.common.InputImage;
import com.roblox.platform.http.returntypes.ossearch.SearchIndexItem;
import com.roblox.platform.http.returntypes.ossearch.SearchIndexItemsResult;
import gu.m;
import hj.ThumbnailResult;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import kotlin.Metadata;
import kotlin.Pair;
import kotlin.Unit;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.k;
import ok.q;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import y5.g0;
import y5.i;
import y5.j;
import y5.p0;
import y5.x;
import y5.z;
import zt.o;
import zt.s;

@Metadata(d1 = {"\u00002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\t\n\u0002\u0018\u0002\n\u0002\u0010\t\n\u0002\b\b\u0018\u0000 \u000e2\u00020\u0001:\u0001\fB\u0017\u0012\u0006\u0010\u0003\u001a\u00020\u0002\u0012\u0006\u0010\u0005\u001a\u00020\u0004¢\u0006\u0004\b\u0006\u0010\u0007J\u0010\u0010\t\u001a\u00020\bH\u0096@¢\u0006\u0004\b\t\u0010\nR(\u0010\u0014\u001a\u00020\u000b8\u0000@\u0000X\u0081\u000e¢\u0006\u0018\n\u0004\b\f\u0010\r\u0012\u0004\b\u0012\u0010\u0013\u001a\u0004\b\u000e\u0010\u000f\"\u0004\b\u0010\u0010\u0011R.\u0010\u001d\u001a\b\u0012\u0004\u0012\u00020\u00160\u00158\u0000@\u0000X\u0081\u000e¢\u0006\u0018\n\u0004\b\u0017\u0010\u0018\u0012\u0004\b\u001c\u0010\u0013\u001a\u0004\b\u0017\u0010\u0019\"\u0004\b\u001a\u0010\u001b¨\u0006\u001e"}, d2 = {"Lcom/roblox/client/ossearch/OSSearchIndexSyncWorker;", "Landroidx/work/CoroutineWorker;", "Landroid/content/Context;", "appContext", "Landroidx/work/WorkerParameters;", "params", "<init>", "(Landroid/content/Context;Landroidx/work/WorkerParameters;)V", "Landroidx/work/c$a;", "doWork", "(Leu/b;)Ljava/lang/Object;", "Lav/l0;", xe.a.f36648e, "Lav/l0;", "c", "()Lav/l0;", "setIoDispatcher$NativeShell_googleProdRelease", "(Lav/l0;)V", "getIoDispatcher$NativeShell_googleProdRelease$annotations", "()V", "ioDispatcher", "Lkotlin/Function0;", BuildConfig.FLAVOR, k6.b.f21144e, "Lkotlin/jvm/functions/Function0;", "()Lkotlin/jvm/functions/Function0;", "setClock$NativeShell_googleProdRelease", "(Lkotlin/jvm/functions/Function0;)V", "getClock$NativeShell_googleProdRelease$annotations", "clock", "NativeShell_googleProdRelease"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* loaded from: classes2.dex */
public final class OSSearchIndexSyncWorker extends CoroutineWorker {

    /* renamed from: c, reason: collision with root package name and from kotlin metadata */
    @NotNull
    public static final Companion INSTANCE = new Companion(null);

    /* renamed from: a, reason: collision with root package name and from kotlin metadata */
    @NotNull
    public l0 ioDispatcher;

    /* renamed from: b, reason: from kotlin metadata */
    @NotNull
    public Function0<Long> clock;

    @Metadata(d1 = {"\u0000\"\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0005\n\u0002\u0010\u000e\n\u0002\b\u0005\b\u0086\u0003\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\u0015\u0010\u0007\u001a\u00020\u00062\u0006\u0010\u0005\u001a\u00020\u0004¢\u0006\u0004\b\u0007\u0010\bJ\u0015\u0010\t\u001a\u00020\u00062\u0006\u0010\u0005\u001a\u00020\u0004¢\u0006\u0004\b\t\u0010\bJ\u0015\u0010\n\u001a\u00020\u00062\u0006\u0010\u0005\u001a\u00020\u0004¢\u0006\u0004\b\n\u0010\bJ\u0015\u0010\u000b\u001a\u00020\u00062\u0006\u0010\u0005\u001a\u00020\u0004¢\u0006\u0004\b\u000b\u0010\bR\u0014\u0010\r\u001a\u00020\f8\u0002X\u0082T¢\u0006\u0006\n\u0004\b\r\u0010\u000eR\u0014\u0010\u000f\u001a\u00020\f8\u0002X\u0082T¢\u0006\u0006\n\u0004\b\u000f\u0010\u000eR\u0014\u0010\u0010\u001a\u00020\f8\u0002X\u0082T¢\u0006\u0006\n\u0004\b\u0010\u0010\u000e¨\u0006\u0011"}, d2 = {"Lcom/roblox/client/ossearch/OSSearchIndexSyncWorker$a;", BuildConfig.FLAVOR, "<init>", "()V", "Landroid/content/Context;", "context", BuildConfig.FLAVOR, "c", "(Landroid/content/Context;)V", "d", k6.b.f21144e, xe.a.f36648e, BuildConfig.FLAVOR, "PERIODIC_SYNC_WORK_NAME", "Ljava/lang/String;", "IMMEDIATE_SYNC_WORK_NAME", "TAG", "NativeShell_googleProdRelease"}, k = 1, mv = {2, 2, 0}, xi = 48)
    /* renamed from: com.roblox.client.ossearch.OSSearchIndexSyncWorker$a, reason: from kotlin metadata */
    public static final class Companion {
        public /* synthetic */ Companion(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }

        public final void a(@NotNull Context context) {
            Intrinsics.checkNotNullParameter(context, "context");
            p0.Companion companion = p0.INSTANCE;
            Context applicationContext = context.getApplicationContext();
            Intrinsics.checkNotNullExpressionValue(applicationContext, "getApplicationContext(...)");
            companion.a(applicationContext).b("fetch_search_results");
        }

        public final void b(@NotNull Context context) {
            Intrinsics.checkNotNullParameter(context, "context");
            p0.Companion companion = p0.INSTANCE;
            Context applicationContext = context.getApplicationContext();
            Intrinsics.checkNotNullExpressionValue(applicationContext, "getApplicationContext(...)");
            companion.a(applicationContext).b("periodic_fetch_search_results");
        }

        public final void c(@NotNull Context context) {
            Intrinsics.checkNotNullParameter(context, "context");
            q.h("OSSearchIndexSyncWorker", "Scheduling immediate OS search index sync");
            p0.Companion companion = p0.INSTANCE;
            Context applicationContext = context.getApplicationContext();
            Intrinsics.checkNotNullExpressionValue(applicationContext, "getApplicationContext(...)");
            companion.a(applicationContext).g("fetch_search_results", j.b, new z.a(OSSearchIndexSyncWorker.class).k(new y5.d(x.b, false, true, true, 2, null)).b());
        }

        public final void d(@NotNull Context context) {
            Intrinsics.checkNotNullParameter(context, "context");
            q.h("OSSearchIndexSyncWorker", "Scheduling periodic OS search index sync");
            Duration ofDays = Duration.ofDays(1L);
            p0.Companion companion = p0.INSTANCE;
            Context applicationContext = context.getApplicationContext();
            Intrinsics.checkNotNullExpressionValue(applicationContext, "getApplicationContext(...)");
            p0 a10 = companion.a(applicationContext);
            i iVar = i.b;
            Intrinsics.checkNotNull(ofDays);
            a10.e("periodic_fetch_search_results", iVar, new g0.a(OSSearchIndexSyncWorker.class, ofDays).k(new y5.d(x.b, false, true, true, 2, null)).b());
        }

        public Companion() {
        }
    }

    @Metadata(k = 3, mv = {2, 2, 0}, xi = 48)
    public static final /* synthetic */ class b extends k implements Function0<Long> {

        /* renamed from: a, reason: collision with root package name */
        public static final b f9005a = new b();

        public b() {
            super(0, System.class, "currentTimeMillis", "currentTimeMillis()J", 0);
        }

        @Override // kotlin.jvm.functions.Function0
        /* renamed from: d, reason: merged with bridge method [inline-methods] */
        public final Long invoke() {
            return Long.valueOf(System.currentTimeMillis());
        }
    }

    @Metadata(k = 3, mv = {2, 2, 0}, xi = 48)
    @gu.f(c = "com.roblox.client.ossearch.OSSearchIndexSyncWorker", f = "OSSearchIndexSyncWorker.kt", l = {InputImage.IMAGE_FORMAT_YUV_420_888, 43, 46}, m = "doWork", v = 1)
    public static final class c extends gu.d {

        /* renamed from: t, reason: collision with root package name */
        public long f9006t;

        /* renamed from: u, reason: collision with root package name */
        public Object f9007u;

        /* renamed from: v, reason: collision with root package name */
        public /* synthetic */ Object f9008v;

        /* renamed from: x, reason: collision with root package name */
        public int f9010x;

        public c(eu.b<? super c> bVar) {
            super(bVar);
        }

        @Override // gu.a
        @Nullable
        public final Object invokeSuspend(@NotNull Object obj) {
            this.f9008v = obj;
            this.f9010x |= Integer.MIN_VALUE;
            return OSSearchIndexSyncWorker.this.doWork(this);
        }
    }

    @Metadata(d1 = {"\u0000\u0010\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\u0010\u0003\u001a\u00070\u0001¢\u0006\u0002\b\u0002*\u00020\u0000H\n¢\u0006\u0004\b\u0003\u0010\u0004"}, d2 = {"Lav/p0;", "Landroidx/work/c$a;", "Lkotlin/jvm/internal/EnhancedNullability;", "<anonymous>", "(Lav/p0;)Landroidx/work/c$a;"}, k = 3, mv = {2, 2, 0})
    @gu.f(c = "com.roblox.client.ossearch.OSSearchIndexSyncWorker$doWork$2", f = "OSSearchIndexSyncWorker.kt", l = {49, RequestError.RESPONSE_CODE_FAILURE, 53, 67, 68}, m = "invokeSuspend", v = 1)
    public static final class d extends m implements Function2<av.p0, eu.b<? super c.a>, Object> {
        public /* synthetic */ Object A;
        public final /* synthetic */ com.roblox.client.ossearch.c C;

        /* renamed from: t, reason: collision with root package name */
        public Object f9011t;

        /* renamed from: u, reason: collision with root package name */
        public Object f9012u;

        /* renamed from: v, reason: collision with root package name */
        public Object f9013v;

        /* renamed from: w, reason: collision with root package name */
        public Object f9014w;

        /* renamed from: x, reason: collision with root package name */
        public int f9015x;

        /* renamed from: y, reason: collision with root package name */
        public int f9016y;

        /* renamed from: z, reason: collision with root package name */
        public int f9017z;

        @Metadata(d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0002\b\u0002\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\n¢\u0006\u0004\b\u0002\u0010\u0003"}, d2 = {"Lav/p0;", BuildConfig.FLAVOR, "<anonymous>", "(Lav/p0;)V"}, k = 3, mv = {2, 2, 0})
        @gu.f(c = "com.roblox.client.ossearch.OSSearchIndexSyncWorker$doWork$2$1$1", f = "OSSearchIndexSyncWorker.kt", l = {}, m = "invokeSuspend", v = 1)
        public static final class a extends m implements Function2<av.p0, eu.b<? super Unit>, Object> {

            /* renamed from: t, reason: collision with root package name */
            public int f9018t;

            /* renamed from: u, reason: collision with root package name */
            public final /* synthetic */ OSSearchIndexSyncWorker f9019u;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            public a(OSSearchIndexSyncWorker oSSearchIndexSyncWorker, eu.b<? super a> bVar) {
                super(2, bVar);
                this.f9019u = oSSearchIndexSyncWorker;
            }

            @Override // gu.a
            public final eu.b<Unit> create(Object obj, eu.b<?> bVar) {
                return new a(this.f9019u, bVar);
            }

            @Override // kotlin.jvm.functions.Function2
            public final Object invoke(av.p0 p0Var, eu.b<? super Unit> bVar) {
                return ((a) create(p0Var, bVar)).invokeSuspend(Unit.f21504a);
            }

            @Override // gu.a
            public final Object invokeSuspend(Object obj) {
                fu.c.e();
                if (this.f9018t != 0) {
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                o.b(obj);
                m2.e.i(this.f9019u.getApplicationContext());
                return Unit.f21504a;
            }
        }

        @Metadata(d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0002\b\u0002\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\n¢\u0006\u0004\b\u0002\u0010\u0003"}, d2 = {"Lav/p0;", BuildConfig.FLAVOR, "<anonymous>", "(Lav/p0;)V"}, k = 3, mv = {2, 2, 0})
        @gu.f(c = "com.roblox.client.ossearch.OSSearchIndexSyncWorker$doWork$2$1$2", f = "OSSearchIndexSyncWorker.kt", l = {}, m = "invokeSuspend", v = 1)
        public static final class b extends m implements Function2<av.p0, eu.b<? super Unit>, Object> {

            /* renamed from: t, reason: collision with root package name */
            public int f9020t;

            /* renamed from: u, reason: collision with root package name */
            public final /* synthetic */ OSSearchIndexSyncWorker f9021u;

            /* renamed from: v, reason: collision with root package name */
            public final /* synthetic */ List<Pair<m2.c, ThumbnailResult>> f9022v;

            /* renamed from: w, reason: collision with root package name */
            public final /* synthetic */ SearchIndexItemsResult f9023w;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            /* JADX WARN: Multi-variable type inference failed */
            public b(OSSearchIndexSyncWorker oSSearchIndexSyncWorker, List<? extends Pair<? extends m2.c, ThumbnailResult>> list, SearchIndexItemsResult searchIndexItemsResult, eu.b<? super b> bVar) {
                super(2, bVar);
                this.f9021u = oSSearchIndexSyncWorker;
                this.f9022v = list;
                this.f9023w = searchIndexItemsResult;
            }

            @Override // gu.a
            public final eu.b<Unit> create(Object obj, eu.b<?> bVar) {
                return new b(this.f9021u, this.f9022v, this.f9023w, bVar);
            }

            @Override // kotlin.jvm.functions.Function2
            public final Object invoke(av.p0 p0Var, eu.b<? super Unit> bVar) {
                return ((b) create(p0Var, bVar)).invokeSuspend(Unit.f21504a);
            }

            @Override // gu.a
            public final Object invokeSuspend(Object obj) {
                fu.c.e();
                if (this.f9020t != 0) {
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                o.b(obj);
                Context applicationContext = this.f9021u.getApplicationContext();
                List<Pair<m2.c, ThumbnailResult>> list = this.f9022v;
                ArrayList arrayList = new ArrayList(kotlin.collections.q.u(list, 10));
                Iterator<T> it = list.iterator();
                while (it.hasNext()) {
                    arrayList.add((m2.c) ((Pair) it.next()).c());
                }
                m2.e.m(applicationContext, arrayList);
                com.roblox.client.ossearch.b bVar = com.roblox.client.ossearch.b.f9055a;
                Context applicationContext2 = this.f9021u.getApplicationContext();
                Intrinsics.checkNotNullExpressionValue(applicationContext2, "getApplicationContext(...)");
                bVar.d(applicationContext2, this.f9021u.b().invoke().longValue() + (this.f9023w.getRefreshIntervalSeconds() * 1000));
                return Unit.f21504a;
            }
        }

        @Metadata(d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0010\b\n\u0002\b\u0002\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\n¢\u0006\u0004\b\u0002\u0010\u0003"}, d2 = {"Lav/p0;", BuildConfig.FLAVOR, "<anonymous>", "(Lav/p0;)I"}, k = 3, mv = {2, 2, 0})
        @gu.f(c = "com.roblox.client.ossearch.OSSearchIndexSyncWorker$doWork$2$1$availableShortcuts$1", f = "OSSearchIndexSyncWorker.kt", l = {}, m = "invokeSuspend", v = 1)
        public static final class c extends m implements Function2<av.p0, eu.b<? super Integer>, Object> {

            /* renamed from: t, reason: collision with root package name */
            public int f9024t;

            /* renamed from: u, reason: collision with root package name */
            public final /* synthetic */ OSSearchIndexSyncWorker f9025u;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            public c(OSSearchIndexSyncWorker oSSearchIndexSyncWorker, eu.b<? super c> bVar) {
                super(2, bVar);
                this.f9025u = oSSearchIndexSyncWorker;
            }

            @Override // gu.a
            public final eu.b<Unit> create(Object obj, eu.b<?> bVar) {
                return new c(this.f9025u, bVar);
            }

            @Override // kotlin.jvm.functions.Function2
            public final Object invoke(av.p0 p0Var, eu.b<? super Integer> bVar) {
                return ((c) create(p0Var, bVar)).invokeSuspend(Unit.f21504a);
            }

            @Override // gu.a
            public final Object invokeSuspend(Object obj) {
                fu.c.e();
                if (this.f9024t != 0) {
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                o.b(obj);
                Context applicationContext = this.f9025u.getApplicationContext();
                Intrinsics.checkNotNullExpressionValue(applicationContext, "getApplicationContext(...)");
                return gu.b.c(hj.a.a(applicationContext));
            }
        }

        @Metadata(d1 = {"\u0000\u0014\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\u0010\u0004\u001a\u000e\u0012\u0004\u0012\u00020\u0002\u0012\u0004\u0012\u00020\u00030\u0001*\u00020\u0000H\n¢\u0006\u0004\b\u0004\u0010\u0005"}, d2 = {"Lav/p0;", "Lkotlin/Pair;", "Lm2/c;", "Lhj/e;", "<anonymous>", "(Lav/p0;)Lkotlin/Pair;"}, k = 3, mv = {2, 2, 0})
        @gu.f(c = "com.roblox.client.ossearch.OSSearchIndexSyncWorker$doWork$2$1$indexResults$1$1", f = "OSSearchIndexSyncWorker.kt", l = {60}, m = "invokeSuspend", v = 1)
        /* renamed from: com.roblox.client.ossearch.OSSearchIndexSyncWorker$d$d, reason: collision with other inner class name */
        public static final class C0147d extends m implements Function2<av.p0, eu.b<? super Pair<? extends m2.c, ? extends ThumbnailResult>>, Object> {

            /* renamed from: t, reason: collision with root package name */
            public int f9026t;

            /* renamed from: u, reason: collision with root package name */
            public final /* synthetic */ SearchIndexItem f9027u;

            /* renamed from: v, reason: collision with root package name */
            public final /* synthetic */ com.roblox.client.ossearch.c f9028v;

            /* renamed from: w, reason: collision with root package name */
            public final /* synthetic */ OSSearchIndexSyncWorker f9029w;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            public C0147d(SearchIndexItem searchIndexItem, com.roblox.client.ossearch.c cVar, OSSearchIndexSyncWorker oSSearchIndexSyncWorker, eu.b<? super C0147d> bVar) {
                super(2, bVar);
                this.f9027u = searchIndexItem;
                this.f9028v = cVar;
                this.f9029w = oSSearchIndexSyncWorker;
            }

            @Override // gu.a
            public final eu.b<Unit> create(Object obj, eu.b<?> bVar) {
                return new C0147d(this.f9027u, this.f9028v, this.f9029w, bVar);
            }

            /* renamed from: invoke, reason: avoid collision after fix types in other method */
            public final Object invoke2(av.p0 p0Var, eu.b<? super Pair<? extends m2.c, ThumbnailResult>> bVar) {
                return ((C0147d) create(p0Var, bVar)).invokeSuspend(Unit.f21504a);
            }

            @Override // gu.a
            public final Object invokeSuspend(Object obj) {
                Object e10 = fu.c.e();
                int i10 = this.f9026t;
                if (i10 == 0) {
                    o.b(obj);
                    SearchIndexItem searchIndexItem = this.f9027u;
                    com.roblox.client.ossearch.c cVar = this.f9028v;
                    l0 ioDispatcher = this.f9029w.getIoDispatcher();
                    Context applicationContext = this.f9029w.getApplicationContext();
                    Intrinsics.checkNotNullExpressionValue(applicationContext, "getApplicationContext(...)");
                    this.f9026t = 1;
                    obj = hj.a.c(searchIndexItem, cVar, ioDispatcher, applicationContext, this);
                    if (obj == e10) {
                        return e10;
                    }
                } else {
                    if (i10 != 1) {
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                    o.b(obj);
                }
                ThumbnailResult thumbnailResult = (ThumbnailResult) obj;
                SearchIndexItem searchIndexItem2 = this.f9027u;
                Bitmap bitmap = thumbnailResult.getBitmap();
                Context applicationContext2 = this.f9029w.getApplicationContext();
                Intrinsics.checkNotNullExpressionValue(applicationContext2, "getApplicationContext(...)");
                return s.a(hj.a.d(searchIndexItem2, bitmap, applicationContext2), thumbnailResult);
            }

            @Override // kotlin.jvm.functions.Function2
            public /* bridge */ /* synthetic */ Object invoke(av.p0 p0Var, eu.b<? super Pair<? extends m2.c, ? extends ThumbnailResult>> bVar) {
                return invoke2(p0Var, (eu.b<? super Pair<? extends m2.c, ThumbnailResult>>) bVar);
            }
        }

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public d(com.roblox.client.ossearch.c cVar, eu.b<? super d> bVar) {
            super(2, bVar);
            this.C = cVar;
        }

        @Override // gu.a
        public final eu.b<Unit> create(Object obj, eu.b<?> bVar) {
            d dVar = OSSearchIndexSyncWorker.this.new d(this.C, bVar);
            dVar.A = obj;
            return dVar;
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(av.p0 p0Var, eu.b<? super c.a> bVar) {
            return ((d) create(p0Var, bVar)).invokeSuspend(Unit.f21504a);
        }

        /* JADX WARN: Removed duplicated region for block: B:102:0x031a  */
        /* JADX WARN: Removed duplicated region for block: B:117:0x01b5  */
        /* JADX WARN: Removed duplicated region for block: B:124:0x0144 A[Catch: all -> 0x0030, LOOP:4: B:122:0x013e->B:124:0x0144, LOOP_END, TryCatch #0 {all -> 0x0030, blocks: (B:10:0x002b, B:11:0x01b7, B:112:0x004b, B:114:0x018c, B:119:0x0064, B:121:0x011d, B:122:0x013e, B:124:0x0144, B:126:0x0167, B:131:0x0081, B:132:0x00f8, B:137:0x0094, B:139:0x00cf, B:144:0x00a9), top: B:2:0x0013 }] */
        /* JADX WARN: Removed duplicated region for block: B:128:0x0186  */
        /* JADX WARN: Removed duplicated region for block: B:129:0x0187  */
        /* JADX WARN: Removed duplicated region for block: B:134:0x0119  */
        /* JADX WARN: Removed duplicated region for block: B:135:0x011b  */
        /* JADX WARN: Removed duplicated region for block: B:14:0x01d2  */
        @Override // gu.a
        /*
            Code decompiled incorrectly, please refer to instructions dump.
            To view partially-correct add '--show-bad-code' argument
        */
        public final java.lang.Object invokeSuspend(java.lang.Object r26) {
            /*
                Method dump skipped, instructions count: 842
                To view this dump add '--comments-level debug' option
            */
            throw new UnsupportedOperationException("Method not decompiled: com.roblox.client.ossearch.OSSearchIndexSyncWorker.d.invokeSuspend(java.lang.Object):java.lang.Object");
        }
    }

    @Metadata(d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0010\t\n\u0002\b\u0002\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\n¢\u0006\u0004\b\u0002\u0010\u0003"}, d2 = {"Lav/p0;", BuildConfig.FLAVOR, "<anonymous>", "(Lav/p0;)J"}, k = 3, mv = {2, 2, 0})
    @gu.f(c = "com.roblox.client.ossearch.OSSearchIndexSyncWorker$doWork$nextAllowedSync$1", f = "OSSearchIndexSyncWorker.kt", l = {}, m = "invokeSuspend", v = 1)
    public static final class e extends m implements Function2<av.p0, eu.b<? super Long>, Object> {

        /* renamed from: t, reason: collision with root package name */
        public int f9030t;

        public e(eu.b<? super e> bVar) {
            super(2, bVar);
        }

        @Override // gu.a
        public final eu.b<Unit> create(Object obj, eu.b<?> bVar) {
            return OSSearchIndexSyncWorker.this.new e(bVar);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(av.p0 p0Var, eu.b<? super Long> bVar) {
            return ((e) create(p0Var, bVar)).invokeSuspend(Unit.f21504a);
        }

        @Override // gu.a
        public final Object invokeSuspend(Object obj) {
            fu.c.e();
            if (this.f9030t != 0) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            o.b(obj);
            com.roblox.client.ossearch.b bVar = com.roblox.client.ossearch.b.f9055a;
            Context applicationContext = OSSearchIndexSyncWorker.this.getApplicationContext();
            Intrinsics.checkNotNullExpressionValue(applicationContext, "getApplicationContext(...)");
            return gu.b.d(bVar.c(applicationContext));
        }
    }

    @Metadata(d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\n¢\u0006\u0004\b\u0002\u0010\u0003"}, d2 = {"Lav/p0;", "Lcom/roblox/client/ossearch/c;", "<anonymous>", "(Lav/p0;)Lcom/roblox/client/ossearch/c;"}, k = 3, mv = {2, 2, 0})
    @gu.f(c = "com.roblox.client.ossearch.OSSearchIndexSyncWorker$doWork$thumbnailCache$1", f = "OSSearchIndexSyncWorker.kt", l = {}, m = "invokeSuspend", v = 1)
    public static final class f extends m implements Function2<av.p0, eu.b<? super com.roblox.client.ossearch.c>, Object> {

        /* renamed from: t, reason: collision with root package name */
        public int f9032t;

        public f(eu.b<? super f> bVar) {
            super(2, bVar);
        }

        @Override // gu.a
        public final eu.b<Unit> create(Object obj, eu.b<?> bVar) {
            return new f(bVar);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(av.p0 p0Var, eu.b<? super com.roblox.client.ossearch.c> bVar) {
            return ((f) create(p0Var, bVar)).invokeSuspend(Unit.f21504a);
        }

        @Override // gu.a
        public final Object invokeSuspend(Object obj) {
            fu.c.e();
            if (this.f9032t != 0) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            o.b(obj);
            return com.roblox.client.ossearch.c.INSTANCE.a();
        }
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public OSSearchIndexSyncWorker(@NotNull Context appContext, @NotNull WorkerParameters params) {
        super(appContext, params);
        Intrinsics.checkNotNullParameter(appContext, "appContext");
        Intrinsics.checkNotNullParameter(params, "params");
        this.ioDispatcher = g1.b();
        this.clock = b.f9005a;
    }

    @NotNull
    public final Function0<Long> b() {
        return this.clock;
    }

    @NotNull
    /* renamed from: c, reason: from getter */
    public final l0 getIoDispatcher() {
        return this.ioDispatcher;
    }

    /* JADX WARN: Code restructure failed: missing block: B:19:0x00ae, code lost:
    
        if (r12 != r1) goto L32;
     */
    /* JADX WARN: Code restructure failed: missing block: B:30:0x0057, code lost:
    
        if (r12 == r1) goto L31;
     */
    /* JADX WARN: Removed duplicated region for block: B:24:0x0072  */
    /* JADX WARN: Removed duplicated region for block: B:26:0x0081  */
    /* JADX WARN: Removed duplicated region for block: B:29:0x0047  */
    /* JADX WARN: Removed duplicated region for block: B:8:0x0026  */
    @Override // androidx.work.CoroutineWorker
    @org.jetbrains.annotations.Nullable
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public java.lang.Object doWork(@org.jetbrains.annotations.NotNull eu.b<? super androidx.work.c.a> r12) {
        /*
            r11 = this;
            boolean r0 = r12 instanceof com.roblox.client.ossearch.OSSearchIndexSyncWorker.c
            if (r0 == 0) goto L13
            r0 = r12
            com.roblox.client.ossearch.OSSearchIndexSyncWorker$c r0 = (com.roblox.client.ossearch.OSSearchIndexSyncWorker.c) r0
            int r1 = r0.f9010x
            r2 = -2147483648(0xffffffff80000000, float:-0.0)
            r3 = r1 & r2
            if (r3 == 0) goto L13
            int r1 = r1 - r2
            r0.f9010x = r1
            goto L18
        L13:
            com.roblox.client.ossearch.OSSearchIndexSyncWorker$c r0 = new com.roblox.client.ossearch.OSSearchIndexSyncWorker$c
            r0.<init>(r12)
        L18:
            java.lang.Object r12 = r0.f9008v
            java.lang.Object r1 = fu.c.e()
            int r2 = r0.f9010x
            r3 = 3
            r4 = 2
            r5 = 1
            r6 = 0
            if (r2 == 0) goto L47
            if (r2 == r5) goto L43
            if (r2 == r4) goto L3d
            if (r2 != r3) goto L35
            java.lang.Object r0 = r0.f9007u
            com.roblox.client.ossearch.c r0 = (com.roblox.client.ossearch.c) r0
            zt.o.b(r12)
            goto Lb1
        L35:
            java.lang.IllegalStateException r12 = new java.lang.IllegalStateException
            java.lang.String r0 = "call to 'resume' before 'invoke' with coroutine"
            r12.<init>(r0)
            throw r12
        L3d:
            long r4 = r0.f9006t
            zt.o.b(r12)
            goto L99
        L43:
            zt.o.b(r12)
            goto L5a
        L47:
            zt.o.b(r12)
            av.l0 r12 = r11.ioDispatcher
            com.roblox.client.ossearch.OSSearchIndexSyncWorker$e r2 = new com.roblox.client.ossearch.OSSearchIndexSyncWorker$e
            r2.<init>(r6)
            r0.f9010x = r5
            java.lang.Object r12 = av.i.g(r12, r2, r0)
            if (r12 != r1) goto L5a
            goto Lb0
        L5a:
            java.lang.Number r12 = (java.lang.Number) r12
            long r7 = r12.longValue()
            kotlin.jvm.functions.Function0<java.lang.Long> r12 = r11.clock
            java.lang.Object r12 = r12.invoke()
            java.lang.Number r12 = (java.lang.Number) r12
            long r9 = r12.longValue()
            int r12 = (r9 > r7 ? 1 : (r9 == r7 ? 0 : -1))
            java.lang.String r2 = "OSSearchIndexSyncWorker"
            if (r12 >= 0) goto L81
            java.lang.String r12 = "Skipping OS search sync, not yet due"
            ok.q.h(r2, r12)
            androidx.work.c$a r12 = androidx.work.c.a.d()
            java.lang.String r0 = "success(...)"
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r12, r0)
            return r12
        L81:
            java.lang.String r12 = "Starting OS search index sync"
            ok.q.h(r2, r12)
            av.l0 r12 = r11.ioDispatcher
            com.roblox.client.ossearch.OSSearchIndexSyncWorker$f r2 = new com.roblox.client.ossearch.OSSearchIndexSyncWorker$f
            r2.<init>(r6)
            r0.f9006t = r7
            r0.f9010x = r4
            java.lang.Object r12 = av.i.g(r12, r2, r0)
            if (r12 != r1) goto L98
            goto Lb0
        L98:
            r4 = r7
        L99:
            com.roblox.client.ossearch.c r12 = (com.roblox.client.ossearch.c) r12
            com.roblox.client.ossearch.OSSearchIndexSyncWorker$d r2 = new com.roblox.client.ossearch.OSSearchIndexSyncWorker$d
            r2.<init>(r12, r6)
            java.lang.Object r12 = gu.l.a(r12)
            r0.f9007u = r12
            r0.f9006t = r4
            r0.f9010x = r3
            java.lang.Object r12 = av.q0.g(r2, r0)
            if (r12 != r1) goto Lb1
        Lb0:
            return r1
        Lb1:
            java.lang.String r0 = "coroutineScope(...)"
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r12, r0)
            return r12
        */
        throw new UnsupportedOperationException("Method not decompiled: com.roblox.client.ossearch.OSSearchIndexSyncWorker.doWork(eu.b):java.lang.Object");
    }


    // --- восстановлено из DEX (com/roblox/client/ossearch/OSSearchIndexSyncWorker$d$a) ---
    public static class a extends gu.m implements kotlin.jvm.functions.Function2 {
        int t;
        com.roblox.client.ossearch.OSSearchIndexSyncWorker u;
        public a(com.roblox.client.ossearch.OSSearchIndexSyncWorker p0, eu.b p1) { }
        public eu.b create(java.lang.Object p0, eu.b p1) { throw new UnsupportedOperationException("stub"); }
        public java.lang.Object invoke(av.p0 p0, eu.b p1) { throw new UnsupportedOperationException("stub"); }
        public java.lang.Object invoke(java.lang.Object p0, java.lang.Object p1) { throw new UnsupportedOperationException("stub"); }
        public java.lang.Object invokeSuspend(java.lang.Object p0) { throw new UnsupportedOperationException("stub"); }
    }

    // --- восстановлено из DEX (com/roblox/client/ossearch/OSSearchIndexSyncWorker$d$b) ---
    public static class b extends gu.m implements kotlin.jvm.functions.Function2 {
        int t;
        com.roblox.client.ossearch.OSSearchIndexSyncWorker u;
        java.util.List v;
        com.roblox.platform.http.returntypes.ossearch.SearchIndexItemsResult w;
        public b(com.roblox.client.ossearch.OSSearchIndexSyncWorker p0, java.util.List p1, com.roblox.platform.http.returntypes.ossearch.SearchIndexItemsResult p2, eu.b p3) { }
        public eu.b create(java.lang.Object p0, eu.b p1) { throw new UnsupportedOperationException("stub"); }
        public java.lang.Object invoke(av.p0 p0, eu.b p1) { throw new UnsupportedOperationException("stub"); }
        public java.lang.Object invoke(java.lang.Object p0, java.lang.Object p1) { throw new UnsupportedOperationException("stub"); }
        public java.lang.Object invokeSuspend(java.lang.Object p0) { throw new UnsupportedOperationException("stub"); }
    }

    // --- восстановлено из DEX (com/roblox/client/ossearch/OSSearchIndexSyncWorker$d$c) ---
    public static class c extends gu.m implements kotlin.jvm.functions.Function2 {
        int t;
        com.roblox.client.ossearch.OSSearchIndexSyncWorker u;
        public c(com.roblox.client.ossearch.OSSearchIndexSyncWorker p0, eu.b p1) { }
        public eu.b create(java.lang.Object p0, eu.b p1) { throw new UnsupportedOperationException("stub"); }
        public java.lang.Object invoke(av.p0 p0, eu.b p1) { throw new UnsupportedOperationException("stub"); }
        public java.lang.Object invoke(java.lang.Object p0, java.lang.Object p1) { throw new UnsupportedOperationException("stub"); }
        public java.lang.Object invokeSuspend(java.lang.Object p0) { throw new UnsupportedOperationException("stub"); }
    }

    // --- восстановлено из DEX (com/roblox/client/ossearch/OSSearchIndexSyncWorker$d$d) ---
    public static class d extends gu.m implements kotlin.jvm.functions.Function2 {
        int t;
        com.roblox.platform.http.returntypes.ossearch.SearchIndexItem u;
        com.roblox.client.ossearch.c v;
        com.roblox.client.ossearch.OSSearchIndexSyncWorker w;
        public d(com.roblox.platform.http.returntypes.ossearch.SearchIndexItem p0, com.roblox.client.ossearch.c p1, com.roblox.client.ossearch.OSSearchIndexSyncWorker p2, eu.b p3) { }
        public eu.b create(java.lang.Object p0, eu.b p1) { throw new UnsupportedOperationException("stub"); }
        public java.lang.Object invoke(av.p0 p0, eu.b p1) { throw new UnsupportedOperationException("stub"); }
        public java.lang.Object invoke(java.lang.Object p0, java.lang.Object p1) { throw new UnsupportedOperationException("stub"); }
        public java.lang.Object invokeSuspend(java.lang.Object p0) { throw new UnsupportedOperationException("stub"); }
    }
}
