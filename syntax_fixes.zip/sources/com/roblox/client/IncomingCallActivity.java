package com.roblox.client;

import android.app.KeyguardManager;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.core.view.WindowInsetsCompat;
import androidx.core.view.o0;
import androidx.core.view.y;
import bh.m0;
import bh.n0;
import bi.h;
import c7.ImageViewTarget;

import e.u0;
import e.x;
import l6.d0;
import lm.g;
import mw.j;
import org.greenrobot.eventbus.ThreadMode;
import wi.f;
import y6.ImageRequest;

/* loaded from: classes2.dex */
public class IncomingCallActivity extends j.b implements g.a {
    public long E;
    public String F;
    public ImageView G;
    public TextView H;

    public static /* synthetic */ WindowInsetsCompat F1(int i10, View view, WindowInsetsCompat windowInsetsCompat) {
        view.setPadding(view.getPaddingLeft(), view.getPaddingTop(), view.getPaddingRight(), i10 + windowInsetsCompat.getInsets(WindowInsetsCompat.Type.systemBars()).bottom);
        return windowInsetsCompat;
    }

    public static Intent H1(Context context, Intent intent, Intent intent2, long j10, String str, boolean z10) {
        return new Intent(context, (Class<?>) IncomingCallActivity.class).putExtra("EXTRA_ACCEPT_INTENT", intent).putExtra("EXTRA_IS_ACCEPT_ENABLED", z10).putExtra("EXTRA_DECLINE_INTENT", intent2).putExtra("EXTRA_CALLER_ID", j10).putExtra("EXTRA_CALLER_COMBINED_NAME", str);
    }

    @Override // lm.g.a
    public void C(String str, boolean z10) {
    }

    public final /* synthetic */ void I1(Intent intent, View view) {
        if (intent != null) {
            sendBroadcast(intent);
        }
        finish();
    }

    public final /* synthetic */ void J1(Intent intent, boolean z10, View view) {
        if (intent != null) {
            if (z10) {
                startActivity(intent);
                ((KeyguardManager) getSystemService("keyguard")).requestDismissKeyguard(this, null);
            } else {
                sendBroadcast(intent);
            }
        }
        finish();
    }

    public final void K1(ImageView imageView, String str) {
        d0.a(this).d(new ImageRequest.a(this).c(str).v(new ImageViewTarget(imageView)).b());
    }

    @Override // lm.g.a
    public void U(String str) {
        finish();
    }

    @Override // lm.g.a
    public void m0(String str) {
    }

    @Override // lm.g.a
    public void o(String str, String str2, String str3, String str4, String str5, String str6) {
    }

    @j(threadMode = ThreadMode.MAIN)
    public void onAvatarHeadshotsRetrievedEvent(yh.b bVar) {
        if (bVar.a().contains(Long.valueOf(this.E))) {
            K1(this.G, mh.b.b().d(this.E).a());
        }
    }

    @Override // f4.v, e.p, k2.g, android.app.Activity
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        x.b(this, u0.a(0, 0), u0.a(0, 0));
        setContentView(n0.f4184c);
        if (h.a().x0()) {
            View findViewById = findViewById(m0.M);
            final int paddingBottom = findViewById.getPaddingBottom();
            o0.A0(findViewById, new y() { // from class: bh.a0
                @Override // androidx.core.view.y
                public final WindowInsetsCompat J(View view, WindowInsetsCompat windowInsetsCompat) {
                    return IncomingCallActivity.F1(paddingBottom, view, windowInsetsCompat);
                }
            });
        }
        this.E = getIntent().getLongExtra("EXTRA_CALLER_ID", 0L);
        this.F = getIntent().getStringExtra("EXTRA_CALLER_COMBINED_NAME");
        final Intent intent = (Intent) getIntent().getParcelableExtra("EXTRA_ACCEPT_INTENT");
        final boolean booleanExtra = getIntent().getBooleanExtra("EXTRA_IS_ACCEPT_ENABLED", true);
        final Intent intent2 = (Intent) getIntent().getParcelableExtra("EXTRA_DECLINE_INTENT");
        findViewById(m0.J).setOnClickListener(new View.OnClickListener() { // from class: bh.b0
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                IncomingCallActivity.this.I1(intent2, view);
            }
        });
        findViewById(m0.I).setOnClickListener(new View.OnClickListener() { // from class: bh.c0
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                IncomingCallActivity.this.J1(intent, booleanExtra, view);
            }
        });
        ImageView imageView = (ImageView) findViewById(m0.K);
        this.G = imageView;
        imageView.setClipToOutline(true);
        TextView textView = (TextView) findViewById(m0.N);
        this.H = textView;
        textView.setText(this.F);
        if (Build.VERSION.SDK_INT >= 27) {
            setShowWhenLocked(true);
            setTurnScreenOn(true);
        } else {
            getWindow().addFlags(6815873);
        }
        mw.c.d().n(this);
        g.x().g(this);
        if (this.E > 0) {
            mh.a d10 = mh.b.b().d(this.E);
            if (d10 == null) {
                f.b(this.E);
            } else if (d10.a() == null) {
                f.a(this.E);
            } else {
                K1(this.G, d10.a());
            }
        }
    }

    @Override // j.b, f4.v, android.app.Activity
    public void onDestroy() {
        super.onDestroy();
        if (Build.VERSION.SDK_INT >= 27) {
            setShowWhenLocked(false);
            setTurnScreenOn(false);
        } else {
            getWindow().clearFlags(6815873);
        }
        this.G = null;
        this.H = null;
        mw.c.d().p(this);
        g.x().w(this);
    }

    @Override // lm.g.a
    public void p(String str, String str2, String str3, String str4, String str5, String str6) {
    }

    @Override // lm.g.a
    public void u(String str, String str2) {
        finish();
    }
}
