package com.roblox.client.pushnotification.v2.richpushnotifications;

import androidx.annotation.Keep;
import com.github.luben.zstd.BuildConfig;
import k6.b;
import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import lg.c;
import lg.f;
import lg.g;
import ok.q;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import xe.a;

@Keep
@Metadata(d1 = {"\u00000\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\n\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0003\n\u0002\u0010\u000b\n\u0002\b\u000f\b\u0087\b\u0018\u0000 $2\u00020\u0001:\u0001%B%\u0012\b\u0010\u0003\u001a\u0004\u0018\u00010\u0002\u0012\b\u0010\u0004\u001a\u0004\u0018\u00010\u0002\u0012\b\u0010\u0006\u001a\u0004\u0018\u00010\u0005¢\u0006\u0004\b\u0007\u0010\bJ\u0012\u0010\t\u001a\u0004\u0018\u00010\u0002HÆ\u0003¢\u0006\u0004\b\t\u0010\nJ\u0012\u0010\u000b\u001a\u0004\u0018\u00010\u0002HÆ\u0003¢\u0006\u0004\b\u000b\u0010\nJ\u0012\u0010\f\u001a\u0004\u0018\u00010\u0005HÆ\u0003¢\u0006\u0004\b\f\u0010\rJ4\u0010\u000e\u001a\u00020\u00002\n\b\u0002\u0010\u0003\u001a\u0004\u0018\u00010\u00022\n\b\u0002\u0010\u0004\u001a\u0004\u0018\u00010\u00022\n\b\u0002\u0010\u0006\u001a\u0004\u0018\u00010\u0005HÆ\u0001¢\u0006\u0004\b\u000e\u0010\u000fJ\u0010\u0010\u0011\u001a\u00020\u0010HÖ\u0001¢\u0006\u0004\b\u0011\u0010\u0012J\u0010\u0010\u0014\u001a\u00020\u0013HÖ\u0001¢\u0006\u0004\b\u0014\u0010\u0015J\u001a\u0010\u0018\u001a\u00020\u00172\b\u0010\u0016\u001a\u0004\u0018\u00010\u0001HÖ\u0003¢\u0006\u0004\b\u0018\u0010\u0019R$\u0010\u0003\u001a\u0004\u0018\u00010\u00028\u0006@\u0006X\u0086\u000e¢\u0006\u0012\n\u0004\b\u0003\u0010\u001a\u001a\u0004\b\u001b\u0010\n\"\u0004\b\u001c\u0010\u001dR$\u0010\u0004\u001a\u0004\u0018\u00010\u00028\u0006@\u0006X\u0086\u000e¢\u0006\u0012\n\u0004\b\u0004\u0010\u001a\u001a\u0004\b\u001e\u0010\n\"\u0004\b\u001f\u0010\u001dR$\u0010\u0006\u001a\u0004\u0018\u00010\u00058\u0006@\u0006X\u0086\u000e¢\u0006\u0012\n\u0004\b\u0006\u0010 \u001a\u0004\b!\u0010\r\"\u0004\b\"\u0010#¨\u0006&"}, d2 = {"Lcom/roblox/client/pushnotification/v2/richpushnotifications/RichPushNotificationMedia;", BuildConfig.FLAVOR, "Lcom/roblox/client/pushnotification/v2/richpushnotifications/PushNotificationImageConfig;", "primaryImage", "secondaryImage", "Lcom/roblox/client/pushnotification/v2/richpushnotifications/Options;", "options", "<init>", "(Lcom/roblox/client/pushnotification/v2/richpushnotifications/PushNotificationImageConfig;Lcom/roblox/client/pushnotification/v2/richpushnotifications/PushNotificationImageConfig;Lcom/roblox/client/pushnotification/v2/richpushnotifications/Options;)V", "component1", "()Lcom/roblox/client/pushnotification/v2/richpushnotifications/PushNotificationImageConfig;", "component2", "component3", "()Lcom/roblox/client/pushnotification/v2/richpushnotifications/Options;", "copy", "(Lcom/roblox/client/pushnotification/v2/richpushnotifications/PushNotificationImageConfig;Lcom/roblox/client/pushnotification/v2/richpushnotifications/PushNotificationImageConfig;Lcom/roblox/client/pushnotification/v2/richpushnotifications/Options;)Lcom/roblox/client/pushnotification/v2/richpushnotifications/RichPushNotificationMedia;", BuildConfig.FLAVOR, "toString", "()Ljava/lang/String;", BuildConfig.FLAVOR, "hashCode", "()I", "other", BuildConfig.FLAVOR, "equals", "(Ljava/lang/Object;)Z", "Lcom/roblox/client/pushnotification/v2/richpushnotifications/PushNotificationImageConfig;", "getPrimaryImage", "setPrimaryImage", "(Lcom/roblox/client/pushnotification/v2/richpushnotifications/PushNotificationImageConfig;)V", "getSecondaryImage", "setSecondaryImage", "Lcom/roblox/client/pushnotification/v2/richpushnotifications/Options;", "getOptions", "setOptions", "(Lcom/roblox/client/pushnotification/v2/richpushnotifications/Options;)V", "Companion", a.f36648e, "NativeShell_googleProdRelease"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* loaded from: classes2.dex */
public final /* data */ class RichPushNotificationMedia {

    /* renamed from: Companion, reason: from kotlin metadata */
    @NotNull
    public static final Companion INSTANCE = new Companion(null);

    /* renamed from: default, reason: not valid java name */
    @NotNull
    private static final RichPushNotificationMedia f0default = new RichPushNotificationMedia(null, null, new Options(false));
    private static final f gson = new g().g(c.f22077a).f().b();

    @Nullable
    private Options options;

    @Nullable
    private PushNotificationImageConfig primaryImage;

    @Nullable
    private PushNotificationImageConfig secondaryImage;

    @Metadata(d1 = {"\u0000\"\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\b\u0004\b\u0086\u0003\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\u0017\u0010\u0007\u001a\u00020\u00062\b\u0010\u0005\u001a\u0004\u0018\u00010\u0004¢\u0006\u0004\b\u0007\u0010\bJ\r\u0010\t\u001a\u00020\u0006¢\u0006\u0004\b\t\u0010\nR\u0014\u0010\u000b\u001a\u00020\u00068\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b\u000b\u0010\fR\u001c\u0010\u000f\u001a\n \u000e*\u0004\u0018\u00010\r0\r8\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b\u000f\u0010\u0010¨\u0006\u0011"}, d2 = {"Lcom/roblox/client/pushnotification/v2/richpushnotifications/RichPushNotificationMedia$a;", BuildConfig.FLAVOR, "<init>", "()V", BuildConfig.FLAVOR, "jsonString", "Lcom/roblox/client/pushnotification/v2/richpushnotifications/RichPushNotificationMedia;", a.f36648e, "(Ljava/lang/String;)Lcom/roblox/client/pushnotification/v2/richpushnotifications/RichPushNotificationMedia;", b.f21144e, "()Lcom/roblox/client/pushnotification/v2/richpushnotifications/RichPushNotificationMedia;", "default", "Lcom/roblox/client/pushnotification/v2/richpushnotifications/RichPushNotificationMedia;", "Llg/f;", "kotlin.jvm.PlatformType", "gson", "Llg/f;", "NativeShell_googleProdRelease"}, k = 1, mv = {2, 2, 0}, xi = 48)
    /* renamed from: com.roblox.client.pushnotification.v2.richpushnotifications.RichPushNotificationMedia$a, reason: from kotlin metadata */
    public static final class Companion {
        public /* synthetic */ Companion(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }

        @NotNull
        public final RichPushNotificationMedia a(@Nullable String jsonString) {
            q.b("RichPushNotificationMedia", "Parsing string for push notification media: " + jsonString);
            if (jsonString == null || jsonString.length() == 0) {
                return b();
            }
            Object h10 = RichPushNotificationMedia.gson.h(jsonString, RichPushNotificationMedia.class);
            Intrinsics.checkNotNullExpressionValue(h10, "fromJson(...)");
            return (RichPushNotificationMedia) h10;
        }

        @NotNull
        public final RichPushNotificationMedia b() {
            return RichPushNotificationMedia.f0default;
        }

        public Companion() {
        }
    }

    public RichPushNotificationMedia(@Nullable PushNotificationImageConfig pushNotificationImageConfig, @Nullable PushNotificationImageConfig pushNotificationImageConfig2, @Nullable Options options) {
        this.primaryImage = pushNotificationImageConfig;
        this.secondaryImage = pushNotificationImageConfig2;
        this.options = options;
    }

    public static /* synthetic */ RichPushNotificationMedia copy$default(RichPushNotificationMedia richPushNotificationMedia, PushNotificationImageConfig pushNotificationImageConfig, PushNotificationImageConfig pushNotificationImageConfig2, Options options, int i10, Object obj) {
        if ((i10 & 1) != 0) {
            pushNotificationImageConfig = richPushNotificationMedia.primaryImage;
        }
        if ((i10 & 2) != 0) {
            pushNotificationImageConfig2 = richPushNotificationMedia.secondaryImage;
        }
        if ((i10 & 4) != 0) {
            options = richPushNotificationMedia.options;
        }
        return richPushNotificationMedia.copy(pushNotificationImageConfig, pushNotificationImageConfig2, options);
    }

    @Nullable
    /* renamed from: component1, reason: from getter */
    public final PushNotificationImageConfig getPrimaryImage() {
        return this.primaryImage;
    }

    @Nullable
    /* renamed from: component2, reason: from getter */
    public final PushNotificationImageConfig getSecondaryImage() {
        return this.secondaryImage;
    }

    @Nullable
    /* renamed from: component3, reason: from getter */
    public final Options getOptions() {
        return this.options;
    }

    @NotNull
    public final RichPushNotificationMedia copy(@Nullable PushNotificationImageConfig primaryImage, @Nullable PushNotificationImageConfig secondaryImage, @Nullable Options options) {
        return new RichPushNotificationMedia(primaryImage, secondaryImage, options);
    }

    public boolean equals(@Nullable Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof RichPushNotificationMedia)) {
            return false;
        }
        RichPushNotificationMedia richPushNotificationMedia = (RichPushNotificationMedia) other;
        return Intrinsics.c(this.primaryImage, richPushNotificationMedia.primaryImage) && Intrinsics.c(this.secondaryImage, richPushNotificationMedia.secondaryImage) && Intrinsics.c(this.options, richPushNotificationMedia.options);
    }

    @Nullable
    public final Options getOptions() {
        return this.options;
    }

    @Nullable
    public final PushNotificationImageConfig getPrimaryImage() {
        return this.primaryImage;
    }

    @Nullable
    public final PushNotificationImageConfig getSecondaryImage() {
        return this.secondaryImage;
    }

    public int hashCode() {
        PushNotificationImageConfig pushNotificationImageConfig = this.primaryImage;
        int hashCode = (pushNotificationImageConfig == null ? 0 : pushNotificationImageConfig.hashCode()) * 31;
        PushNotificationImageConfig pushNotificationImageConfig2 = this.secondaryImage;
        int hashCode2 = (hashCode + (pushNotificationImageConfig2 == null ? 0 : pushNotificationImageConfig2.hashCode())) * 31;
        Options options = this.options;
        return hashCode2 + (options != null ? options.hashCode() : 0);
    }

    public final void setOptions(@Nullable Options options) {
        this.options = options;
    }

    public final void setPrimaryImage(@Nullable PushNotificationImageConfig pushNotificationImageConfig) {
        this.primaryImage = pushNotificationImageConfig;
    }

    public final void setSecondaryImage(@Nullable PushNotificationImageConfig pushNotificationImageConfig) {
        this.secondaryImage = pushNotificationImageConfig;
    }

    @NotNull
    public String toString() {
        return "RichPushNotificationMedia(primaryImage=" + this.primaryImage + ", secondaryImage=" + this.secondaryImage + ", options=" + this.options + ")";
    }


    // --- восстановлено из DEX (com/roblox/client/pushnotification/v2/richpushnotifications/RichPushNotificationMedia$a) ---
    public static class a {
        public a() { }
        public a(kotlin.jvm.internal.DefaultConstructorMarker p0) { }
        public com.roblox.client.pushnotification.v2.richpushnotifications.RichPushNotificationMedia a(java.lang.String p0) { throw new UnsupportedOperationException("stub"); }
        public com.roblox.client.pushnotification.v2.richpushnotifications.RichPushNotificationMedia b() { throw new UnsupportedOperationException("stub"); }
    }
}
