package com.roblox.client.pushnotification.actions;

import android.content.Context;
import android.net.Uri;
import androidx.work.CoroutineWorker;
import androidx.work.WorkerParameters;
import androidx.work.b;
import androidx.work.c;
import bh.a1;
import cl.g;
import com.github.luben.zstd.BuildConfig;
import gu.f;
import gu.m;
import java.time.Duration;
import kotlin.Metadata;
import kotlin.Pair;
import kotlin.Unit;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import mv.b0;
import mv.f0;
import mv.g0;
import mv.h0;
import ok.q;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import y5.d;
import y5.j;
import y5.p0;
import y5.x;
import y5.z;
import zt.n;
import zt.o;
import zt.s;

@Metadata(d1 = {"\u0000\u001e\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0006\u0018\u0000 \r2\u00020\u0001:\u0001\u000bB\u0017\u0012\u0006\u0010\u0003\u001a\u00020\u0002\u0012\u0006\u0010\u0005\u001a\u00020\u0004¢\u0006\u0004\b\u0006\u0010\u0007J\u0010\u0010\t\u001a\u00020\bH\u0096@¢\u0006\u0004\b\t\u0010\nR\u0014\u0010\u0005\u001a\u00020\u00048\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b\u000b\u0010\f¨\u0006\u000e"}, d2 = {"Lcom/roblox/client/pushnotification/actions/NotificationActionEndpointWorker;", "Landroidx/work/CoroutineWorker;", "Landroid/content/Context;", "appContext", "Landroidx/work/WorkerParameters;", "params", "<init>", "(Landroid/content/Context;Landroidx/work/WorkerParameters;)V", "Landroidx/work/c$a;", "doWork", "(Leu/b;)Ljava/lang/Object;", xe.a.f36648e, "Landroidx/work/WorkerParameters;", k6.b.f21144e, "NativeShell_googleProdRelease"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* loaded from: classes2.dex */
public final class NotificationActionEndpointWorker extends CoroutineWorker {

    /* renamed from: b, reason: from kotlin metadata */
    @NotNull
    public static final Companion INSTANCE = new Companion(null);

    /* renamed from: a, reason: collision with root package name and from kotlin metadata */
    @NotNull
    public final WorkerParameters params;

    @Metadata(d1 = {"\u0000\"\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0004\n\u0002\u0010\u0002\n\u0002\b\b\b\u0086\u0003\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J7\u0010\f\u001a\u00020\u000b2\u0006\u0010\u0005\u001a\u00020\u00042\u0006\u0010\u0007\u001a\u00020\u00062\u0006\u0010\b\u001a\u00020\u00062\u0006\u0010\t\u001a\u00020\u00062\u0006\u0010\n\u001a\u00020\u0006H\u0007¢\u0006\u0004\b\f\u0010\rR\u0014\u0010\u000e\u001a\u00020\u00068\u0006X\u0086T¢\u0006\u0006\n\u0004\b\u000e\u0010\u000fR\u0014\u0010\u0010\u001a\u00020\u00068\u0006X\u0086T¢\u0006\u0006\n\u0004\b\u0010\u0010\u000fR\u0014\u0010\u0011\u001a\u00020\u00068\u0006X\u0086T¢\u0006\u0006\n\u0004\b\u0011\u0010\u000fR\u0014\u0010\u0012\u001a\u00020\u00068\u0006X\u0086T¢\u0006\u0006\n\u0004\b\u0012\u0010\u000f¨\u0006\u0013"}, d2 = {"Lcom/roblox/client/pushnotification/actions/NotificationActionEndpointWorker$a;", BuildConfig.FLAVOR, "<init>", "()V", "Landroid/content/Context;", "context", BuildConfig.FLAVOR, "actionId", "notificationId", "actionUrl", "actionBody", BuildConfig.FLAVOR, xe.a.f36648e, "(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V", "HTTPS_PROTOCOL", "Ljava/lang/String;", "DATA_ACTION_URL", "DATA_ACTION_BODY", "WORK_NAME_PREFIX", "NativeShell_googleProdRelease"}, k = 1, mv = {2, 2, 0}, xi = 48)
    /* renamed from: com.roblox.client.pushnotification.actions.NotificationActionEndpointWorker$a, reason: from kotlin metadata */
    public static final class Companion {
        public /* synthetic */ Companion(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }

        public final void a(@NotNull Context context, @NotNull String actionId, @NotNull String notificationId, @NotNull String actionUrl, @NotNull String actionBody) {
            Intrinsics.checkNotNullParameter(context, "context");
            Intrinsics.checkNotNullParameter(actionId, "actionId");
            Intrinsics.checkNotNullParameter(notificationId, "notificationId");
            Intrinsics.checkNotNullParameter(actionUrl, "actionUrl");
            Intrinsics.checkNotNullParameter(actionBody, "actionBody");
            Pair[] pairArr = {s.a("action-url", actionUrl), s.a("action-body", actionBody)};
            b.a aVar = new b.a();
            for (int i10 = 0; i10 < 2; i10++) {
                Pair pair = pairArr[i10];
                aVar.b((String) pair.c(), pair.d());
            }
            androidx.work.b a10 = aVar.a();
            p0 a11 = p0.INSTANCE.a(context);
            String str = "notification-action-" + actionId + "-" + notificationId;
            j jVar = j.b;
            z.a k10 = new z.a(NotificationActionEndpointWorker.class).o(a10).k(new d(x.b, false, false, false, 14, null));
            y5.a aVar2 = y5.a.f37445a;
            Duration ofSeconds = Duration.ofSeconds(5L);
            Intrinsics.checkNotNullExpressionValue(ofSeconds, "ofSeconds(...)");
            a11.g(str, jVar, k10.j(aVar2, ofSeconds).b());
        }

        public Companion() {
        }
    }

    @Metadata(k = 3, mv = {2, 2, 0}, xi = 48)
    @f(c = "com.roblox.client.pushnotification.actions.NotificationActionEndpointWorker", f = "NotificationActionEndpointWorker.kt", l = {39}, m = "doWork", v = 1)
    public static final class b extends gu.d {

        /* renamed from: t, reason: collision with root package name */
        public /* synthetic */ Object f9127t;

        /* renamed from: v, reason: collision with root package name */
        public int f9129v;

        public b(eu.b<? super b> bVar) {
            super(bVar);
        }

        @Override // gu.a
        @Nullable
        public final Object invokeSuspend(@NotNull Object obj) {
            this.f9127t = obj;
            this.f9129v |= Integer.MIN_VALUE;
            return NotificationActionEndpointWorker.this.doWork(this);
        }
    }

    @Metadata(d1 = {"\u0000\u0010\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\u0010\u0003\u001a\u00070\u0001¢\u0006\u0002\b\u0002*\u00020\u0000H\n¢\u0006\u0004\b\u0003\u0010\u0004"}, d2 = {"Lav/p0;", "Landroidx/work/c$a;", "Lkotlin/jvm/internal/EnhancedNullability;", "<anonymous>", "(Lav/p0;)Landroidx/work/c$a;"}, k = 3, mv = {2, 2, 0})
    @f(c = "com.roblox.client.pushnotification.actions.NotificationActionEndpointWorker$doWork$2", f = "NotificationActionEndpointWorker.kt", l = {}, m = "invokeSuspend", v = 1)
    public static final class c extends m implements Function2<av.p0, eu.b<? super c.a>, Object> {

        /* renamed from: t, reason: collision with root package name */
        public int f9130t;

        /* renamed from: u, reason: collision with root package name */
        public /* synthetic */ Object f9131u;

        public c(eu.b<? super c> bVar) {
            super(2, bVar);
        }

        @Override // gu.a
        public final eu.b<Unit> create(Object obj, eu.b<?> bVar) {
            c cVar = NotificationActionEndpointWorker.this.new c(bVar);
            cVar.f9131u = obj;
            return cVar;
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(av.p0 p0Var, eu.b<? super c.a> bVar) {
            return ((c) create(p0Var, bVar)).invokeSuspend(Unit.f21504a);
        }

        @Override // gu.a
        public final Object invokeSuspend(Object obj) {
            Object b;
            androidx.work.b d10;
            String g10;
            fu.c.e();
            if (this.f9130t != 0) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            o.b(obj);
            NotificationActionEndpointWorker notificationActionEndpointWorker = NotificationActionEndpointWorker.this;
            try {
                n.Companion companion = n.INSTANCE;
                d10 = notificationActionEndpointWorker.params.d();
                g10 = d10.g("action-url");
            } catch (Throwable th2) {
                n.Companion companion2 = n.INSTANCE;
                b = n.b(o.a(th2));
            }
            if (g10 == null) {
                return c.a.a();
            }
            String g11 = d10.g("action-body");
            if (g11 == null) {
                g11 = BuildConfig.FLAVOR;
            }
            Uri parse = Uri.parse(g10);
            String O = a1.O();
            Intrinsics.checkNotNull(O);
            if (!sj.a.a(parse, O)) {
                q.d("NotificationActionEndpointWorker: URL rejected by domain check. host=" + parse.getHost() + " appDomain=" + O);
                return c.a.a();
            }
            q.a("NotificationActionEndpointWorker: calling " + g10);
            h0 j10 = g.b().a(new f0.a().t(g10).p(g0.INSTANCE.c(g11, b0.INSTANCE.a("application/json"))).b()).j();
            try {
                q.a("NotificationActionEndpointWorker: response " + j10.getCode() + " for " + g10);
                int code = j10.getCode();
                c.a a10 = (200 > code || code >= 300) ? (500 > code || code >= 600) ? c.a.a() : c.a.c() : c.a.d();
                lu.c.a(j10, null);
                b = n.b(a10);
                return n.e(b) == null ? (c.a) b : c.a.c();
            } finally {
            }
        }
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public NotificationActionEndpointWorker(@NotNull Context appContext, @NotNull WorkerParameters params) {
        super(appContext, params);
        Intrinsics.checkNotNullParameter(appContext, "appContext");
        Intrinsics.checkNotNullParameter(params, "params");
        this.params = params;
    }

    /* JADX WARN: Removed duplicated region for block: B:15:0x0031  */
    /* JADX WARN: Removed duplicated region for block: B:8:0x0023  */
    @Override // androidx.work.CoroutineWorker
    @org.jetbrains.annotations.Nullable
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public java.lang.Object doWork(@org.jetbrains.annotations.NotNull eu.b<? super androidx.work.c.a> r6) {
        /*
            r5 = this;
            boolean r0 = r6 instanceof com.roblox.client.pushnotification.actions.NotificationActionEndpointWorker.b
            if (r0 == 0) goto L13
            r0 = r6
            com.roblox.client.pushnotification.actions.NotificationActionEndpointWorker$b r0 = (com.roblox.client.pushnotification.actions.NotificationActionEndpointWorker.b) r0
            int r1 = r0.f9129v
            r2 = -2147483648(0xffffffff80000000, float:-0.0)
            r3 = r1 & r2
            if (r3 == 0) goto L13
            int r1 = r1 - r2
            r0.f9129v = r1
            goto L18
        L13:
            com.roblox.client.pushnotification.actions.NotificationActionEndpointWorker$b r0 = new com.roblox.client.pushnotification.actions.NotificationActionEndpointWorker$b
            r0.<init>(r6)
        L18:
            java.lang.Object r6 = r0.f9127t
            java.lang.Object r1 = fu.c.e()
            int r2 = r0.f9129v
            r3 = 1
            if (r2 == 0) goto L31
            if (r2 != r3) goto L29
            zt.o.b(r6)
            goto L47
        L29:
            java.lang.IllegalStateException r6 = new java.lang.IllegalStateException
            java.lang.String r0 = "call to 'resume' before 'invoke' with coroutine"
            r6.<init>(r0)
            throw r6
        L31:
            zt.o.b(r6)
            av.l0 r6 = av.g1.b()
            com.roblox.client.pushnotification.actions.NotificationActionEndpointWorker$c r2 = new com.roblox.client.pushnotification.actions.NotificationActionEndpointWorker$c
            r4 = 0
            r2.<init>(r4)
            r0.f9129v = r3
            java.lang.Object r6 = av.i.g(r6, r2, r0)
            if (r6 != r1) goto L47
            return r1
        L47:
            java.lang.String r0 = "withContext(...)"
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r6, r0)
            return r6
        */
        throw new UnsupportedOperationException("Method not decompiled: com.roblox.client.pushnotification.actions.NotificationActionEndpointWorker.doWork(eu.b):java.lang.Object");
    }


    // --- восстановлено из DEX (com/roblox/client/pushnotification/actions/NotificationActionEndpointWorker$a) ---
    public static class a {
        public a() { }
        public a(kotlin.jvm.internal.DefaultConstructorMarker p0) { }
        public void a(android.content.Context p0, java.lang.String p1, java.lang.String p2, java.lang.String p3, java.lang.String p4) { throw new UnsupportedOperationException("stub"); }
    }
}
