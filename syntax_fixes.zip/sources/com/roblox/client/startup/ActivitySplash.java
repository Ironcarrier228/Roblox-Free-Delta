package com.roblox.client.startup;

import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.ColorDrawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.SystemClock;
import android.text.TextUtils;
import android.widget.Toast;
import bh.a1;
import bh.m0;
import bh.q0;
import bh.t0;
import bh.y;
import bi.h;
import com.github.luben.zstd.BuildConfig;
import com.roblox.client.components.LoadingBar;
import com.roblox.client.datastructures.NameValuePair;

import com.roblox.client.startup.c;
import com.roblox.engine.jni.NativeReportingInterface;
import com.roblox.protocols.systemdialog.PlatformSystemDialogHandler;
import com.roblox.universalapp.logging.LoggingProtocol;
import di.m;
import dj.g;
import ik.k0;
import ik.n0;
import ik.s2;
import java.util.List;
import java.util.concurrent.Executors;
import ok.q;
import ok.x;
import rj.r;
import rj.u;
import rj.w;
import xm.a;

/* loaded from: classes2.dex */
public class ActivitySplash extends com.roblox.client.a implements n0, c.b {

    /* renamed from: e0, reason: collision with root package name */
    public static boolean f9286e0 = true;

    /* renamed from: f0, reason: collision with root package name */
    public static boolean f9287f0;
    public LoadingBar S;
    public Runnable T;
    public long U;
    public Intent X;
    public boolean Y;
    public boolean Z;

    /* renamed from: a0, reason: collision with root package name */
    public StartedForEnum f9288a0;

    /* renamed from: b0, reason: collision with root package name */
    public boolean f9289b0;

    /* renamed from: c0, reason: collision with root package name */
    public boolean f9290c0;
    public Handler V = new Handler();
    public boolean W = false;

    /* renamed from: d0, reason: collision with root package name */
    public am.d f9291d0 = null;

    public class a implements Runnable {
        public a() {
        }

        @Override // java.lang.Runnable
        public void run() {
            ActivitySplash.this.T = null;
            ActivitySplash.this.S.setVisibility(0);
        }
    }

    private void A2(int i10) {
        LoggingProtocol.g("retry_during_splash");
        c.y2(this, i10);
    }

    private void B2() {
        q.h("rbx.splash", "startup:");
        C2(true);
        k0.s(this).O();
    }

    private void C2(boolean z10) {
        if (a1.q0()) {
            q.b("rbx.splash", "updateLoadingView is disabled to disable loading screen for full VR experience.");
            return;
        }
        LoadingBar loadingBar = this.S;
        if (loadingBar == null) {
            return;
        }
        if (!z10) {
            p2();
            this.S.setVisibility(8);
            return;
        }
        if (!f9286e0) {
            loadingBar.setVisibility(0);
            return;
        }
        f9286e0 = false;
        long elapsedRealtime = SystemClock.elapsedRealtime() - this.U;
        if (elapsedRealtime >= 5000) {
            this.S.setVisibility(0);
            return;
        }
        this.V = new Handler();
        a aVar = new a();
        this.T = aVar;
        this.V.postDelayed(aVar, 5000 - elapsedRealtime);
    }

    public static Intent o2(Context context, StartedForEnum startedForEnum) {
        Intent intent = new Intent(context, (Class<?>) ActivitySplash.class);
        q.h("rbx.splash", "buildIntent for: " + startedForEnum);
        intent.putExtra("STARTED_FOR_INTENT_KEY", startedForEnum);
        return intent;
    }

    private void q2() {
        c.v2(this);
    }

    public static boolean r2() {
        return f9287f0;
    }

    @Override // ik.n0
    public void F() {
        g.b().i(this.W);
        z2();
        if (J1()) {
            if (h.a().q0() && this.f9291d0 != null) {
                Executors.newSingleThreadExecutor().submit(new Runnable() { // from class: ik.c
                    @Override // java.lang.Runnable
                    public final void run() {
                        ActivitySplash.this.v2();
                    }
                });
                return;
            }
            q.h("rbx.splash", "updateViewAppSettingsLoaded: (NEW_STARTUP) launch the Main activity now...");
            this.f9290c0 = true;
            k0.s(this).S(this);
            w2(this.f9289b0);
            finish();
        }
    }

    @Override // ik.n0
    public void I() {
        if (a1.q0()) {
            x.a(this, q0.S);
            finish();
        } else {
            C2(false);
            if (J1()) {
                A2(q0.S);
            }
        }
    }

    @Override // com.roblox.client.startup.c.b
    public void M() {
        q2();
        B2();
    }

    @Override // ik.n0
    public void N() {
    }

    @Override // com.roblox.client.a
    public boolean P1() {
        return true;
    }

    @Override // com.roblox.client.a
    public ui.c Q1() {
        return new ui.d();
    }

    @Override // com.roblox.client.startup.c.b
    public void i() {
        q2();
        B2();
    }

    @Override // ik.n0
    public void i0() {
    }

    @Override // ik.n0
    public void k0() {
        if (J1()) {
            if (!h.a().q0() || this.f9291d0 == null) {
                w2(false);
            } else {
                Executors.newSingleThreadExecutor().submit(new Runnable() { // from class: ik.a
                    @Override // java.lang.Runnable
                    public final void run() {
                        ActivitySplash.this.t2();
                    }
                });
            }
        }
    }

    @Override // com.roblox.client.a, com.roblox.client.b, f4.v, e.p, k2.g, android.app.Activity
    public void onCreate(Bundle bundle) {
        StartedForEnum y22 = y2(getIntent());
        if (h.a().Q1()) {
            q.h("rbx.splash", "GameActivity = ON. Start new GameActivity...");
            super.onCreate(bundle);
            Intent i22 = MainGameActivity.i2(this, y22);
            Bundle extras = getIntent().getExtras();
            if (extras != null) {
                i22.putExtras(extras);
            }
            startActivity(i22);
            finish();
            return;
        }
        if (r2()) {
            q.h("rbx.splash", "Process reuse detected.");
            LoggingProtocol.g("process_reuse");
        }
        LoggingProtocol.g("splash_activity_oncreate");
        super.onCreate(bundle);
        if (h.a().q0()) {
            q.h("rbx.splash", "Attach platform emergency observer.");
            if (this.f9291d0 == null) {
                this.f9291d0 = new am.d();
            }
            PlatformSystemDialogHandler platformSystemDialogHandler = PlatformSystemDialogHandler.INSTANCE;
            platformSystemDialogHandler.attachObserver(this.f9291d0);
            platformSystemDialogHandler.setActivity(this);
        }
        xm.a.c(this);
        xm.a.j().a(a.EnumC0756a.SPLASH, bundle);
        this.U = SystemClock.elapsedRealtime();
        this.X = getIntent();
        this.f9288a0 = y22;
        NativeReportingInterface.initAppShellReporter();
        q.b("rbx.splash", "Started for: " + this.f9288a0);
        StartedForEnum startedForEnum = this.f9288a0;
        this.Y = startedForEnum == StartedForEnum.SHELL_PROCESS_RESTART_FOR_RESULT || startedForEnum == StartedForEnum.AFTER_LOGIN_FOR_RESULT;
        this.Z = startedForEnum == StartedForEnum.AFTER_SIGN_UP;
        this.f9289b0 = startedForEnum == StartedForEnum.PROTOCOL_LAUNCH;
        q.h("rbx.splash", "onCreate: startedForResult=" + this.Y + ", appRestarted=" + (startedForEnum == StartedForEnum.APP_RESTART));
        if (s2.b()) {
            getWindow().setBackgroundDrawable(new ColorDrawable(-16777216));
        } else {
            setContentView(bh.n0.f4186e);
            this.S = (LoadingBar) findViewById(m0.W);
        }
        if (wh.b.a()) {
            String G = a1.G();
            if (!TextUtils.isEmpty(G)) {
                Toast.makeText(this, "Using " + G, 1).show();
            }
        }
        ti.a.h();
        this.W = R1();
        if (bundle == null) {
            dj.b.f().c(this);
        }
        if (wh.b.a() && a1.x0()) {
            q.k("rbx.splash", "Alert: needs restart");
            O1();
        } else {
            k0.s(this).M(this.f9288a0);
            k0.s(this).N(this);
        }
    }

    @Override // com.roblox.client.a, com.roblox.client.b, j.b, f4.v, android.app.Activity
    public void onDestroy() {
        super.onDestroy();
        if (this.f9291d0 != null) {
            q.h("rbx.splash", "Detach platform emergency observer.");
            PlatformSystemDialogHandler.INSTANCE.detachObserver(this.f9291d0);
            this.f9291d0 = null;
        }
        q.h("rbx.splash", "onDestroy: unset the activity from InitHelper.");
        k0.s(this).S(this);
    }

    @Override // com.roblox.client.b, e.p, android.app.Activity
    public void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        q.h("rbx.splash", "onNewIntent: intent=" + intent);
        this.X = intent;
        this.f9288a0 = y2(intent);
        x2();
    }

    @Override // com.roblox.client.a, com.roblox.client.b, f4.v, android.app.Activity
    public void onPause() {
        super.onPause();
        LoggingProtocol.g("splash_activity_onpause");
        if (h.a().S3()) {
            if (isFinishing()) {
                q.b("rbx.splash", "ActivitySplash is paused due to finish()");
            } else {
                q.k("rbx.splash", "ActivitySplash is paused due to the app being put into the background.");
                LoggingProtocol.g("startup_interrupted");
            }
        }
        q.b("rbx.splash", "onPause: isFinishing = " + isFinishing());
        p2();
        if (this.f9290c0) {
            return;
        }
        xm.a.j().b(a.EnumC0756a.SPLASH);
    }

    @Override // com.roblox.client.a, com.roblox.client.b, f4.v, android.app.Activity
    public void onResume() {
        super.onResume();
        q.b("rbx.splash", "onResume:");
        q2();
        B2();
    }

    @Override // com.roblox.client.a, com.roblox.client.b, j.b, f4.v, android.app.Activity
    public void onStart() {
        super.onStart();
        f9287f0 = true;
        xm.a.j().h();
        t0.v("splash");
    }

    public final void p2() {
        Runnable runnable = this.T;
        if (runnable != null) {
            this.V.removeCallbacks(runnable);
            this.T = null;
        }
    }

    public final /* synthetic */ void s2() {
        q.h("rbx.splash", "navigateToMainScreen: launch the Main activity now...");
        w2(false);
    }

    public final /* synthetic */ void t2() {
        q.h("rbx.splash", "navigateToMainScreen: check for platform emergency...");
        this.f9291d0.g(new Runnable() { // from class: ik.b
            @Override // java.lang.Runnable
            public final void run() {
                ActivitySplash.this.s2();
            }
        });
    }

    public final /* synthetic */ void u2() {
        q.h("rbx.splash", "updateViewAppSettingsLoaded: (NEW_STARTUP) launch the Main activity now...");
        this.f9290c0 = true;
        k0.s(this).S(this);
        w2(this.f9289b0);
        finish();
    }

    public final /* synthetic */ void v2() {
        q.h("rbx.splash", "updateViewAppSettingsLoaded: (NEW_STARTUP) check for platform emergency...");
        this.f9291d0.g(new Runnable() { // from class: ik.d
            @Override // java.lang.Runnable
            public final void run() {
                ActivitySplash.this.u2();
            }
        });
    }

    public final void w2(boolean z10) {
        x2();
        if (isFinishing()) {
            q.h("rbx.splash", "isFinishing");
            return;
        }
        q.h("rbx.splash", "launchMainActivity");
        Intent i10 = y.h().i(this);
        if (z10) {
            t0.b(this, "protocolLaunch");
        }
        if (this.Z) {
            i10.putExtra("loginAfterSignup", true);
        }
        if (this.X.getExtras() != null) {
            i10.putExtras(this.X.getExtras());
        }
        if (h.a().c4()) {
            LoggingProtocol.g("main_activity_launch_begin");
        }
        xm.a.j().e();
        startActivity(i10);
        overridePendingTransition(0, 0);
        finish();
    }

    public final void x2() {
        if (this.f9288a0 != StartedForEnum.LOADED_FROM_PUSH_NOTIFICATION) {
            return;
        }
        Bundle extras = this.X.getExtras();
        if (extras != null) {
            r.k().G(extras);
        }
        String string = extras.getString("EXTRA_NOTIFICATION_TYPE", BuildConfig.FLAVOR);
        String string2 = extras.getString("EXTRA_NOTIFICATION_VERSION", BuildConfig.FLAVOR);
        String string3 = extras.getString("EXTRA_NOTIFICATION_ID", BuildConfig.FLAVOR);
        List<NameValuePair> a10 = w.a(this.X);
        if (string2.isEmpty()) {
            if (string == "ChatNewMessage") {
                u.c().i(extras.getString("EXTRA_CATEGORY", BuildConfig.FLAVOR));
            } else {
                u.c().d(string).clear();
                vj.h.g(this.X, this);
            }
        }
        t0.r("clicked", new rj.x().a(this, "GcmPlatform"), string, string3, ok.w.a(this), true, string2, "startup", a10);
        com.roblox.client.pushnotification.actions.a.a(this, this.X, true);
    }

    public final StartedForEnum y2(Intent intent) {
        Bundle extras = intent.getExtras();
        if (extras != null) {
            extras.setClassLoader(StartedForEnum.class.getClassLoader());
            try {
                StartedForEnum startedForEnum = Build.VERSION.SDK_INT >= 33 ? (StartedForEnum) intent.getSerializableExtra("STARTED_FOR_INTENT_KEY", StartedForEnum.class) : (StartedForEnum) intent.getSerializableExtra("STARTED_FOR_INTENT_KEY");
                if (startedForEnum != null) {
                    return startedForEnum;
                }
            } catch (RuntimeException e10) {
                q.h("rbx.splash", "readStartedForEnum: Exception caught: " + e10);
            }
        }
        return StartedForEnum.SYSTEM;
    }

    public final void z2() {
        m b = m.b();
        b.d(h.a().e2());
        b.c(a1.e0());
    }
}
