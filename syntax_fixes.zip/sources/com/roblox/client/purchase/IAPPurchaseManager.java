package com.roblox.client.purchase;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import android.view.WindowManager;
import android.widget.TextView;
import androidx.annotation.Keep;
import androidx.appcompat.app.a;
import bh.q0;
import bh.y;
import bi.h;
import com.github.luben.zstd.BuildConfig;

import com.roblox.engine.jni.NativeGLInterface;
import com.roblox.engine.jni.autovalue.NativePurchaseContext;
import com.roblox.engine.jni.autovalue.PreparePaymentParams;
import com.roblox.engine.jni.autovalue.ProcessPaymentParams;
import ei.s0;
import java.util.HashMap;
import mj.j;
import mj.l;
import mj.o;
import mj.p;
import nj.a0;
import nj.m;
import ok.q;
import ok.t;
import pj.ValidatePurchaseResponsePayload;

/* loaded from: classes2.dex */
public class IAPPurchaseManager {

    /* renamed from: h, reason: collision with root package name */
    public static mj.a f9070h = null;

    /* renamed from: i, reason: collision with root package name */
    public static boolean f9071i = false;

    /* renamed from: j, reason: collision with root package name */
    public static ProgressDialog f9072j = null;

    /* renamed from: k, reason: collision with root package name */
    public static Activity f9073k = null;

    /* renamed from: l, reason: collision with root package name */
    public static String f9074l = "buyRobuxPage";

    /* renamed from: m, reason: collision with root package name */
    public static String f9075m = "buyUpsell";

    /* renamed from: n, reason: collision with root package name */
    public static String f9076n = "buyDevSub";

    /* renamed from: c, reason: collision with root package name */
    public final boolean f9078c;

    /* renamed from: d, reason: collision with root package name */
    public mj.a f9079d;

    /* renamed from: e, reason: collision with root package name */
    public Handler f9080e;

    /* renamed from: a, reason: collision with root package name */
    public long f9077a = 0;
    public String b = BuildConfig.FLAVOR;

    /* renamed from: f, reason: collision with root package name */
    public s0 f9081f = new f();

    /* renamed from: g, reason: collision with root package name */
    public s0 f9082g = new f();

    public class a implements Runnable {
        public a() {
        }

        @Override // java.lang.Runnable
        public void run() {
            IAPPurchaseManager.this.r(q0.A1);
        }
    }

    public class b implements Runnable {
        public b() {
        }

        @Override // java.lang.Runnable
        public void run() {
            IAPPurchaseManager.this.r(q0.A1);
        }
    }

    public class c implements Runnable {
        public c() {
        }

        @Override // java.lang.Runnable
        public void run() {
            IAPPurchaseManager.this.r(q0.B1);
        }
    }

    public class d implements Runnable {
        public d() {
        }

        @Override // java.lang.Runnable
        public void run() {
            IAPPurchaseManager.this.r(q0.A1);
        }
    }

    public class e implements Runnable {

        /* renamed from: a, reason: collision with root package name */
        public final /* synthetic */ p f9087a;
        public final /* synthetic */ CharSequence b;

        /* renamed from: c, reason: collision with root package name */
        public final /* synthetic */ Activity f9088c;

        public e(p pVar, CharSequence charSequence, Activity activity) {
            this.f9087a = pVar;
            this.b = charSequence;
            this.f9088c = activity;
        }

        @Override // java.lang.Runnable
        public void run() {
            if (this.f9087a.f()) {
                IAPPurchaseManager.t(this.b, this.f9088c);
                return;
            }
            if (IAPPurchaseManager.f9071i) {
                IAPPurchaseManager.f9070h.V(this.b.toString());
                return;
            }
            if (!h.a().k1()) {
                IAPPurchaseManager.f9070h.q0().V(this.b.toString());
                return;
            }
            com.roblox.client.b q02 = IAPPurchaseManager.f9070h.q0();
            if (q02 instanceof com.roblox.client.a) {
                ((com.roblox.client.a) q02).V(this.b.toString());
            } else {
                q.h("rbx.purchaseflow", "PaymentsProtocol: paymentsProtocolPurchaseFinished stored_mActivityInterface.getRobloxActivity() is null.");
                dj.g.b().q("Payments-Protocol-Purchase-Finished-Null-Activity");
            }
        }
    }

    public class f implements s0 {

        public class a implements Runnable {

            /* renamed from: a, reason: collision with root package name */
            public final /* synthetic */ p f9090a;
            public final /* synthetic */ CharSequence b;

            public a(p pVar, CharSequence charSequence) {
                this.f9090a = pVar;
                this.b = charSequence;
            }

            @Override // java.lang.Runnable
            public void run() {
                if (this.f9090a.f()) {
                    IAPPurchaseManager.this.s(this.b);
                } else {
                    IAPPurchaseManager.this.q(this.b.toString());
                }
            }
        }

        public f() {
        }

        @Override // ei.s0
        public void a(boolean z10, long j10, String str, String str2) {
            IAPPurchaseManager.this.x(z10, j10, str, str2);
        }

        @Override // mj.o
        public void b() {
        }

        @Override // mj.o
        public void c() {
        }

        @Override // mj.o
        public void d() {
        }

        @Override // mj.o
        public void e(p pVar) {
            Activity e02 = IAPPurchaseManager.this.f9078c ? IAPPurchaseManager.this.f9079d.e0() : IAPPurchaseManager.this.f9079d.q0();
            if (e02 == null) {
                return;
            }
            IAPPurchaseManager.this.E(new a(pVar, pVar.d() ? IAPPurchaseManager.this.v(q0.C1) : pVar.c(e02)));
        }
    }

    public class g implements o {

        /* renamed from: a, reason: collision with root package name */
        public final long f9092a;
        public final String b;

        /* renamed from: c, reason: collision with root package name */
        public final String f9093c;

        public g(long j10, String str, String str2) {
            this.f9092a = j10;
            this.b = str;
            this.f9093c = str2;
        }

        @Override // mj.o
        public void b() {
        }

        @Override // mj.o
        public void c() {
        }

        @Override // mj.o
        public void d() {
        }

        /* JADX WARN: Multi-variable type inference failed */
        @Override // mj.o
        public void e(final p pVar) {
            String str;
            if (!(pVar instanceof j) || (str = ((j) pVar).b()) == null) {
                str = BuildConfig.FLAVOR;
            }
            String str2 = str;
            if (IAPPurchaseManager.f9074l.equals(this.f9093c)) {
                final Activity e02 = IAPPurchaseManager.this.f9078c ? IAPPurchaseManager.this.f9079d.e0() : IAPPurchaseManager.this.f9079d.q0();
                if (e02 != null) {
                    IAPPurchaseManager.this.E(new Runnable() { // from class: mj.i
                        @Override // java.lang.Runnable
                        public final void run() {
                            IAPPurchaseManager.g.this.g(e02, pVar);
                        }
                    });
                }
            } else {
                IAPPurchaseManager.this.f9081f.e(pVar);
            }
            IAPPurchaseManager.this.x(pVar.d(), this.f9092a, this.b, str2);
        }

        public final /* synthetic */ void g(Activity activity, p pVar) {
            l.c(activity, pVar, this.b);
        }
    }

    public IAPPurchaseManager(mj.a aVar, boolean z10) {
        this.f9079d = aVar;
        this.f9078c = z10;
        f9070h = aVar;
        f9071i = z10;
        this.f9080e = new Handler(Looper.getMainLooper());
    }

    public static void M(Context context, boolean z10) {
        if (!t.g()) {
            if (t.i()) {
                String k10 = nk.c.c().k();
                long j10 = nk.c.c().j();
                q.h("rbx.purchaseflow", "tryGrantPendingPurchases: username = " + k10 + ", userId = " + j10);
                if (TextUtils.isEmpty(k10)) {
                    return;
                }
                if (h.a().L5()) {
                    qj.b.a(context);
                    throw null;
                }
                if (j10 > 0) {
                    qj.a.a(context);
                    throw null;
                }
                qj.a.a(context);
                throw null;
            }
            return;
        }
        String k11 = nk.c.c().k();
        long j11 = nk.c.c().j();
        if (TextUtils.isEmpty(k11)) {
            return;
        }
        q.h("rbx.purchaseflow", "tryGrantPendingPurchases: username = " + k11 + ", userId = " + j11);
        if (h.a().L1()) {
            q.h("rbx.purchaseflow", "PaymentsProtocol: tryGrantPendingPurchases");
            if (j11 > 0) {
                a0.R(context).K(j11, z10);
                return;
            } else {
                a0.R(context).L(z10);
                return;
            }
        }
        if (h.a().t3() && h.a().q()) {
            m.F0(context).m1(j11, k11, z10);
        } else if (j11 > 0) {
            m.F0(context).A0(j11, k11, z10);
        } else {
            m.F0(context).B0(k11, z10);
        }
    }

    public static /* synthetic */ void d(boolean z10) {
        Activity activity = f9073k;
        if (activity == null || activity.isFinishing() || f9073k.isDestroyed()) {
            return;
        }
        if (f9072j == null) {
            Activity activity2 = f9073k;
            f9072j = u(activity2, null, activity2.getString(q0.P));
        }
        if (z10) {
            q.h("rbx.purchaseflow", "PaymentsProtocol: paymentsProtocolSetProgressBarDisplay show.");
            f9072j.show();
        } else {
            q.h("rbx.purchaseflow", "PaymentsProtocol: paymentsProtocolSetProgressBarDisplay hide.");
            f9072j.dismiss();
        }
    }

    @Keep
    public static String getPlatformPaymentMethod() {
        return t.g() ? "GooglePlayStore" : (t.i() && h.a().L5()) ? "MilkyWayStore" : BuildConfig.FLAVOR;
    }

    @Keep
    public static String getPlatformPaymentProviderType() {
        return t.g() ? "GooglePlayStore" : (t.i() && h.a().L5()) ? "MilkyWayStore" : BuildConfig.FLAVOR;
    }

    @Keep
    public static boolean invokeStore(String str, String str2) {
        q.h("rbx.purchaseflow", "PaymentsProtocol: invokeStore attempt.");
        if (t.g()) {
            Activity e02 = f9071i ? f9070h.e0() : f9070h.q0();
            m.F0(e02).a(str, nk.c.c().j(), nk.c.c().k(), str2, e02);
            return false;
        }
        if (!t.i()) {
            return false;
        }
        qj.b.a(f9071i ? f9070h.e0() : f9070h.q0());
        nk.c.c().j();
        nk.c.c().k();
        throw null;
    }

    @Keep
    public static void invokeStoreV2(String str, long j10, String str2) {
        q.h("rbx.purchaseflow", "PaymentsProtocolV2: invokeStoreV2 attempt:" + str + ", " + j10 + ", " + str2);
        if (t.g()) {
            Activity e02 = f9071i ? f9070h.e0() : f9070h.q0();
            a0.R(e02).Q(e02, new ValidatePurchaseResponsePayload(Long.valueOf(j10), str2, null), null, null);
        }
    }

    public static native void nativeBeginPaymentsProtocolPurchase(String str);

    public static native HashMap<String, String> nativeBeginPaymentsProtocolPurchaseV2(PreparePaymentParams preparePaymentParams);

    public static native void nativeFinishPaymentsProtocolPurchase(String str, int i10, String str2);

    public static native void nativeFinishPaymentsProtocolPurchaseV2(ProcessPaymentParams processPaymentParams);

    public static native void nativeInvokeStore(String str, long j10, String str2);

    public static native void nativePerformSubscriptionPurchase(String str, String str2, String str3, String str4);

    public static native void nativeSetMetricsPurchaseType(String str);

    public static native void nativeSetPaymentSessionId(String str);

    public static native void nativeSetPaymentsProtocolIsInApp(boolean z10);

    public static native void nativeSetProviderCurrencyCode(String str);

    public static native void nativeSetPurchaseTokenAndPackageNamePaymentsProtocol(String str, String str2);

    public static native void nativeSetUserId(long j10);

    @Keep
    public static boolean paymentsProtocolConcludeTransaction(String str, long j10, long j11) {
        q.h("rbx.purchaseflow", "PaymentsProtocol: paymentsProtocolConcludeTransaction attempt.");
        if (t.g()) {
            m.F0(f9071i ? f9070h.e0() : f9070h.q0()).h(str, j10, nk.c.c().j());
            return true;
        }
        if (!t.i()) {
            return false;
        }
        qj.b.a(f9071i ? f9070h.e0() : f9070h.q0());
        nk.c.c().j();
        throw null;
    }

    @Keep
    public static void paymentsProtocolHandlePreparePaymentErrorCode(int i10) {
        if (h.a().O2()) {
            if (t.g()) {
                m.F0(f9071i ? f9070h.e0() : f9070h.q0()).n(i10);
            } else if (t.i()) {
                qj.b.a(f9071i ? f9070h.e0() : f9070h.q0());
                throw null;
            }
        }
    }

    @Keep
    public static void paymentsProtocolProcessPaymentCallback(long[] jArr, int i10, String str, String str2) {
        q.h("rbx.purchaseflow", "PaymentsProtocolV2: paymentsProtocolProcessPaymentCallback attempt.");
        if (t.g()) {
            a0.R(f9071i ? f9070h.e0() : f9070h.q0()).q0(jArr, i10, str, str2);
        }
    }

    @Keep
    public static void paymentsProtocolPurchaseFinished(p pVar) {
        q.h("rbx.purchaseflow", "PaymentsProtocol: paymentsProtocolPurchaseFinished attempt.");
        Activity e02 = f9071i ? f9070h.e0() : f9070h.q0();
        if (e02 == null) {
            return;
        }
        new Handler(Looper.getMainLooper()).post(new e(pVar, pVar.c(e02), e02));
    }

    @Keep
    public static void paymentsProtocolSetProgressBarDisplay(final boolean z10) {
        if (h.a().p5()) {
            q.h("rbx.purchaseflow", "PaymentsProtocol: paymentsProtocolSetProgressBarDisplay attempt.");
            if (z10 || f9073k != null) {
                if (f9073k == null) {
                    q.h("rbx.purchaseflow", "PaymentsProtocol: initializing mPaymentsProtocolActivity");
                    f9073k = f9070h.q0();
                }
                Activity activity = f9073k;
                if (activity != null) {
                    activity.runOnUiThread(new Runnable() { // from class: mj.b
                        @Override // java.lang.Runnable
                        public final void run() {
                            IAPPurchaseManager.d(z10);
                        }
                    });
                }
            }
        }
    }

    @Keep
    public static boolean setCheckoutSessionId(String str) {
        if (t.g()) {
            return m.F0(f9071i ? f9070h.e0() : f9070h.q0()).m(str);
        }
        if (!t.i() || !h.a().L5()) {
            return false;
        }
        qj.b.a(f9071i ? f9070h.e0() : f9070h.q0());
        throw null;
    }

    public static void t(CharSequence charSequence, Activity activity) {
        androidx.appcompat.app.a a10 = new androidx.appcompat.app.a.C0021a(activity).a();
        TextView textView = new TextView(activity);
        String string = activity.getString(q0.W);
        int indexOf = charSequence.toString().indexOf(string);
        pk.b.b(textView, charSequence.toString(), new pk.c(activity, null, string, indexOf, indexOf + string.length()));
        textView.setTextSize(20.0f);
        textView.setEllipsize(null);
        a10.w(textView, 150, 100, 150, 100);
        a10.setCanceledOnTouchOutside(true);
        try {
            a10.show();
        } catch (WindowManager.BadTokenException unused) {
        }
    }

    public static ProgressDialog u(Context context, String str, String str2) {
        ProgressDialog progressDialog = new ProgressDialog(context);
        progressDialog.setTitle(str);
        progressDialog.setMessage(str2);
        progressDialog.setIndeterminate(true);
        progressDialog.setCancelable(true);
        progressDialog.setCanceledOnTouchOutside(false);
        progressDialog.setOnCancelListener(null);
        return progressDialog;
    }

    public final /* synthetic */ void A() {
        r(q0.F1);
    }

    public final /* synthetic */ void B() {
        r(q0.A1);
    }

    public final /* synthetic */ void C() {
        r(q0.F1);
    }

    public final /* synthetic */ void D() {
        r(q0.A1);
    }

    public void E(Runnable runnable) {
        this.f9080e.post(runnable);
    }

    public void F(long j10, String str) {
        J(j10, str, BuildConfig.FLAVOR);
    }

    public void G(long j10, String str, String str2) {
        K(j10, str, str2, BuildConfig.FLAVOR);
    }

    public void H(long j10, String str, NativePurchaseContext nativePurchaseContext) {
        String paymentSessionId = nativePurchaseContext.paymentSessionId();
        if (paymentSessionId == null) {
            paymentSessionId = BuildConfig.FLAVOR;
        }
        L(j10, str, paymentSessionId, nativePurchaseContext.purchaseType(), nativePurchaseContext.isInApp());
    }

    public void I(long j10, String str, String str2) {
        q.h("rbx.purchaseflow", "promptNativePurchaseWithPayload: userId = " + j10 + ", roblox-native-productId = " + str);
        this.f9077a = j10;
        if (t.j()) {
            q.e("rbx.purchaseflow", "Luobu purchasing not enabled");
            w(false, j10, str);
            return;
        }
        Activity e02 = this.f9078c ? this.f9079d.e0() : this.f9079d.q0();
        if (t.i()) {
            if (!h.a().L5()) {
                qj.a.a(e02);
                throw null;
            }
            E(new c());
            w(false, j10, str);
            return;
        }
        if (h.a().L1()) {
            q.h("rbx.purchaseflow", "PaymentsProtocolV2: promptNativePurchaseWithPayload.");
            if (a0.R(e02).d(j10, str, str2, e02, true, this.f9081f)) {
                return;
            }
            E(new Runnable() { // from class: mj.g
                @Override // java.lang.Runnable
                public final void run() {
                    IAPPurchaseManager.this.y();
                }
            });
            w(false, j10, str);
            return;
        }
        if (!h.a().t3()) {
            if (m.F0(e02).d(j10, str, str2, e02, true, this.f9081f)) {
                return;
            }
            E(new d());
            w(false, j10, str);
            return;
        }
        q.h("rbx.purchaseflow", "PaymentsProtocol: promptNativePurchaseWithPayload.");
        nativeSetMetricsPurchaseType(f9076n);
        m F0 = m.F0(e02);
        F0.k(false);
        if (h.a().V()) {
            F0.j(this.f9081f);
        }
        nativeSetPaymentsProtocolIsInApp(false);
        nativeSetPaymentSessionId(BuildConfig.FLAVOR);
        nativeSetUserId(j10);
        F0.g(str, j10, nk.c.c().k(), e02, str2);
    }

    public void J(long j10, String str, String str2) {
        L(j10, str, str2, f9075m, false);
    }

    public void K(long j10, String str, String str2, String str3) {
        q.h("rbx.purchaseflow", "promptNativePurchase: player = " + j10 + ", productId = " + str);
        this.f9077a = j10;
        this.b = str;
        if (t.j()) {
            Activity e02 = this.f9078c ? this.f9079d.e0() : this.f9079d.q0();
            if (e02 == null || e02.isFinishing()) {
                return;
            }
            y.h().j(e02).b(e02, str, j10, this.f9081f);
            return;
        }
        if (t.i()) {
            Activity e03 = this.f9078c ? this.f9079d.e0() : this.f9079d.q0();
            if (!h.a().L5()) {
                qj.a.a(e03);
                throw null;
            }
            nativeSetMetricsPurchaseType(f9075m);
            qj.b.a(e03);
            throw null;
        }
        Activity e04 = this.f9078c ? this.f9079d.e0() : this.f9079d.q0();
        if (h.a().L1()) {
            q.h("rbx.purchaseflow", "PaymentsProtocolV2: promptNativePurchase.");
            if (a0.R(e04).b(str2, str, e04, j10, this.f9081f)) {
                return;
            }
            E(new Runnable() { // from class: mj.h
                @Override // java.lang.Runnable
                public final void run() {
                    IAPPurchaseManager.this.z();
                }
            });
            w(false, j10, str);
            return;
        }
        if (!h.a().t3()) {
            if (m.F0(e04).b(str2, str, e04, j10, this.f9081f)) {
                return;
            }
            E(new a());
            w(false, j10, str);
            return;
        }
        nativeSetMetricsPurchaseType(f9075m);
        m F0 = m.F0(e04);
        F0.i(null);
        F0.k(false);
        if (h.a().V()) {
            F0.j(this.f9081f);
        }
        nativeSetPaymentsProtocolIsInApp(false);
        if (h.a().P1()) {
            nativeSetPaymentSessionId(str3);
        } else {
            nativeSetPaymentSessionId(BuildConfig.FLAVOR);
        }
        nativeSetProviderCurrencyCode(F0.e(str));
        nativeBeginPaymentsProtocolPurchase(str);
    }

    public final void L(long j10, String str, String str2, String str3, boolean z10) {
        q.h("rbx.purchaseflow", "promptNativePurchase: userId = " + j10 + ", productId = " + str);
        this.f9077a = j10;
        this.b = str;
        if (t.j()) {
            Activity e02 = this.f9078c ? this.f9079d.e0() : this.f9079d.q0();
            if (e02 == null || e02.isFinishing()) {
                return;
            }
            if (h.a().E4() && z10) {
                y.h().j(e02).a(e02, str, new g(j10, str, str3));
                return;
            } else {
                y.h().j(e02).b(e02, str, j10, this.f9081f);
                return;
            }
        }
        if (t.i()) {
            Activity e03 = this.f9078c ? this.f9079d.e0() : this.f9079d.q0();
            if (h.a().L5()) {
                nativeSetMetricsPurchaseType(f9075m);
                qj.b.a(e03);
                throw null;
            }
            qj.a.a(e03);
            if (!h.a().E4() || !z10) {
                Long.toString(j10);
                throw null;
            }
            E(new Runnable() { // from class: mj.c
                @Override // java.lang.Runnable
                public final void run() {
                    IAPPurchaseManager.this.A();
                }
            });
            w(false, j10, str);
            return;
        }
        Activity e04 = this.f9078c ? this.f9079d.e0() : this.f9079d.q0();
        if (h.a().L1()) {
            q.h("rbx.purchaseflow", "PaymentsProtocolV2: promptNativePurchase.");
            if (a0.R(e04).b(Long.toString(j10), str, e04, j10, this.f9081f)) {
                return;
            }
            E(new Runnable() { // from class: mj.d
                @Override // java.lang.Runnable
                public final void run() {
                    IAPPurchaseManager.this.B();
                }
            });
            w(false, j10, str);
            return;
        }
        if (!h.a().t3()) {
            m F0 = m.F0(e04);
            if (!h.a().E4() || !z10) {
                if (F0.b(Long.toString(j10), str, e04, j10, this.f9081f)) {
                    return;
                }
                E(new b());
                w(false, j10, str);
                return;
            }
            if (F0 == null) {
                E(new Runnable() { // from class: mj.e
                    @Override // java.lang.Runnable
                    public final void run() {
                        IAPPurchaseManager.this.C();
                    }
                });
                w(false, j10, str);
                return;
            } else {
                if (F0.l(nk.c.c().k(), str, e04, new g(j10, str, str3), false, str2)) {
                    return;
                }
                E(new Runnable() { // from class: mj.f
                    @Override // java.lang.Runnable
                    public final void run() {
                        IAPPurchaseManager.this.D();
                    }
                });
                w(false, j10, str);
                return;
            }
        }
        if (h.a().E4()) {
            nativeSetMetricsPurchaseType(str3);
        } else {
            nativeSetMetricsPurchaseType(f9075m);
        }
        m F02 = m.F0(e04);
        F02.i(null);
        if (h.a().E4()) {
            F02.k(z10);
        } else {
            F02.k(false);
        }
        if (h.a().V()) {
            F02.j(this.f9081f);
        }
        if (h.a().E4()) {
            nativeSetPaymentsProtocolIsInApp(z10);
        } else {
            nativeSetPaymentsProtocolIsInApp(false);
        }
        if (h.a().P1()) {
            nativeSetPaymentSessionId(str2);
        } else {
            nativeSetPaymentSessionId(BuildConfig.FLAVOR);
        }
        nativeSetProviderCurrencyCode(F02.e(str));
        nativeBeginPaymentsProtocolPurchase(str);
    }

    public final void q(String str) {
        if (this.f9078c) {
            this.f9079d.V(str);
        } else {
            this.f9079d.q0().V(str);
        }
    }

    public final void r(int i10) {
        if (this.f9078c) {
            this.f9079d.T(i10);
        } else {
            this.f9079d.q0().T(i10);
        }
    }

    public void s(CharSequence charSequence) {
        Activity e02 = this.f9078c ? this.f9079d.e0() : this.f9079d.q0();
        if (e02 == null) {
            return;
        }
        t(charSequence, e02);
    }

    public String v(int i10) {
        return this.f9078c ? this.f9079d.e0().getString(i10) : this.f9079d.q0().getString(i10);
    }

    public final void w(boolean z10, long j10, String str) {
        x(z10, j10, str, BuildConfig.FLAVOR);
    }

    public final void x(boolean z10, long j10, String str, String str2) {
        q.h("rbx.purchaseflow", "In-App purchase finished: success = " + z10 + ", player=" + j10 + ", productId=" + str + ", checkoutSessionId=" + str2);
        if (this.f9077a == 0) {
            q.h("rbx.purchaseflow", "AppShellFragment.inAppPurchaseFinished: userId == 0.");
            return;
        }
        q.h("rbx.purchaseflow", "Native call. Success=" + z10 + ", player=" + j10 + ", productId=" + str + ", checkoutSessionId" + str2);
        if (h.a().u1()) {
            if (str2 == null) {
                str2 = BuildConfig.FLAVOR;
            }
            NativeGLInterface.nativeInGamePurchaseFinishedV2(z10, j10, str, str2);
        } else {
            NativeGLInterface.nativeInGamePurchaseFinished(z10, j10, str);
        }
        this.b = BuildConfig.FLAVOR;
        this.f9077a = 0L;
    }

    public final /* synthetic */ void y() {
        r(q0.A1);
    }

    public final /* synthetic */ void z() {
        r(q0.A1);
    }


    // --- восстановлено из DEX (com/roblox/client/purchase/IAPPurchaseManager$f$a) ---
    public static class a implements java.lang.Runnable {
        mj.p a;
        java.lang.CharSequence b;
        com.roblox.client.purchase.IAPPurchaseManager.f c;
        public a(com.roblox.client.purchase.IAPPurchaseManager.f p0, mj.p p1, java.lang.CharSequence p2) { }
        public void run() { throw new UnsupportedOperationException("stub"); }
    }
}
