package com.roblox.client.appsflyer;

import android.content.Context;
import android.content.SharedPreferences;
import androidx.annotation.NonNull;
import bh.a1;
import bh.t0;
import bi.h;
import com.appsflyer.AppsFlyerLib;
import com.appsflyer.sdk_base.referrer.Payload;
import com.appsflyer.share.AFInAppEventParameterName;
import com.appsflyer.share.AFInAppEventType;
import com.appsflyer.share.AppsFlyerConsent;
import com.appsflyer.share.AppsFlyerConversionListener;
import com.appsflyer.share.SessionReadyListener;
import com.appsflyer.share.deeplink.DeepLinkListener;
import com.appsflyer.share.deeplink.DeepLinkResult;
import com.github.luben.zstd.BuildConfig;
import com.roblox.client.datastructures.NameValuePair;
import com.roblox.protocols.telemetrybindingsplatforminterface.generated.TelemetryBackend;
import com.roblox.universalapp.messagebus.MessageBus;
import com.roblox.universalapp.messagebus.MessageBusHelper;
import dj.g;
import eh.a0;
import eh.c0;
import fn.c;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.TimeZone;
import java.util.UUID;
import java.util.concurrent.TimeUnit;
import java.util.function.BooleanSupplier;
import java.util.regex.Pattern;
import mi.k;
import mv.f;
import mv.f0;
import mv.h0;
import mv.i0;
import ob.ze;
import ok.b0;
import ok.q;
import org.json.JSONException;
import org.json.JSONObject;
import ym.g;

/* loaded from: classes2.dex */
public class a extends dj.d {

    /* renamed from: o, reason: collision with root package name */
    public static final Pattern f8838o = Pattern.compile("[A-Za-z0-9_-]+");
    public Context b;

    /* renamed from: c, reason: collision with root package name */
    public boolean f8839c = false;

    /* renamed from: d, reason: collision with root package name */
    public final Object f8840d = new Object();

    /* renamed from: e, reason: collision with root package name */
    public boolean f8841e = false;

    /* renamed from: f, reason: collision with root package name */
    public boolean f8842f = false;

    /* renamed from: g, reason: collision with root package name */
    public boolean f8843g = false;

    /* renamed from: h, reason: collision with root package name */
    public boolean f8844h = false;

    /* renamed from: i, reason: collision with root package name */
    public boolean f8845i = false;

    /* renamed from: j, reason: collision with root package name */
    public boolean f8846j = false;

    /* renamed from: k, reason: collision with root package name */
    public final Object f8847k = new Object();

    /* renamed from: l, reason: collision with root package name */
    public volatile boolean f8848l = false;

    /* renamed from: m, reason: collision with root package name */
    public boolean f8849m = false;

    /* renamed from: n, reason: collision with root package name */
    public String f8850n = null;

    /* renamed from: com.roblox.client.appsflyer.a$a, reason: collision with other inner class name */
    public class C0139a implements AppsFlyerConversionListener {
        public C0139a() {
        }

        @Override // com.appsflyer.share.AppsFlyerConversionListener
        public void onConversionDataFail(String str) {
        }

        @Override // com.appsflyer.share.AppsFlyerConversionListener
        public void onConversionDataSuccess(Map<String, Object> map) {
            a.this.T(map);
        }
    }

    public class b implements DeepLinkListener {
        public b() {
        }

        @Override // com.appsflyer.share.deeplink.DeepLinkListener
        public void onDeepLinking(DeepLinkResult deepLinkResult) {
            a.this.V(deepLinkResult);
        }
    }

    public class c implements f {

        /* renamed from: a, reason: collision with root package name */
        public final /* synthetic */ Context f8853a;

        public c(Context context) {
            this.f8853a = context;
        }

        @Override // mv.f
        public void onFailure(@NonNull mv.e eVar, @NonNull IOException iOException) {
            a.this.m0(this.f8853a, null);
        }

        @Override // mv.f
        public void onResponse(@NonNull mv.e eVar, @NonNull h0 h0Var) {
            a.this.m0(this.f8853a, a.w0(h0Var));
        }
    }

    public static final class d {

        /* renamed from: a, reason: collision with root package name */
        public final boolean f8854a;
        public final boolean b;

        public d(boolean z10, boolean z11) {
            this.f8854a = z10;
            this.b = z11;
        }

        public boolean a() {
            return this.f8854a && !this.b;
        }
    }

    public static class e {

        /* renamed from: a, reason: collision with root package name */
        public static final a f8855a = new a();
    }

    public a() {
        q.h("AppsFlyerManager", "[AppsFlyerManager]: Constructor called.");
    }

    public static Boolean C(JSONObject jSONObject) {
        if (jSONObject == null || !jSONObject.has("consented")) {
            return null;
        }
        return Boolean.valueOf(jSONObject.optBoolean("consented"));
    }

    public static f0 F() {
        return new f0.a().t(a1.e()).e().b();
    }

    public static void H0(Context context, String str, long j10) {
        SharedPreferences.Editor edit = Q(context).edit();
        edit.putLong(str, j10);
        edit.apply();
    }

    public static String J0(Map<String, Object> map) {
        String O0 = O0(map, "af_ad");
        return W0(map) ? M(O0, O0(map, "adgroup")) : O0;
    }

    public static String K0(Map<String, Object> map) {
        return M(O0(map, "af_adset"), O0(map, "adset"));
    }

    public static String L0(String str, String str2, String str3, String str4) {
        return M(str, str2, str3, str4);
    }

    public static String M(String... strArr) {
        for (String str : strArr) {
            if (str != null && !str.isEmpty()) {
                return str;
            }
        }
        return null;
    }

    public static String M0(Map<String, Object> map) {
        return L0(U0(map, "af_ad"), U0(map, "af_adset"), U0(map, "adgroup"), U0(map, "adset"));
    }

    public static String N0(Map<String, Object> map) {
        return M(O0(map, "af_c_id"), O0(map, Payload.CAMPAIGN_ID));
    }

    public static a O() {
        return e.f8855a;
    }

    public static String O0(Map<String, Object> map, String str) {
        Object obj = map.get(str);
        if (obj == null) {
            return null;
        }
        return b0.c(obj);
    }

    public static long P(Context context, String str, long j10) {
        return Q(context).getLong(str, j10);
    }

    public static SharedPreferences Q(Context context) {
        return context.getSharedPreferences("APPS_FLYER_SHARED_PREFS", 0);
    }

    public static String R(long j10) {
        return "signupReportedTimeInSeconds_" + j10;
    }

    public static String U0(Map<String, Object> map, String str) {
        Object obj = map.get(str);
        if (obj instanceof String) {
            return (String) obj;
        }
        return null;
    }

    public static String V0(Object obj) {
        if (obj == null) {
            return BuildConfig.FLAVOR;
        }
        String obj2 = obj.toString();
        try {
            Locale locale = Locale.US;
            SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", locale);
            simpleDateFormat.setTimeZone(TimeZone.getTimeZone("UTC"));
            SimpleDateFormat simpleDateFormat2 = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", locale);
            simpleDateFormat2.setTimeZone(TimeZone.getTimeZone("UTC"));
            return simpleDateFormat2.format(simpleDateFormat.parse(obj2));
        } catch (Exception unused) {
            return obj2;
        }
    }

    public static boolean W0(Map<String, Object> map) {
        return (map.containsKey("af_ad") || map.containsKey("af_adset")) ? false : true;
    }

    public static boolean X(long j10, long j11, long j12) {
        return j10 != 0 && j11 - j10 <= j12;
    }

    public static String h0(String str, String str2) {
        if (str == null || str2 == null || !str.contains("://navigation/crossdevice") || !f8838o.matcher(str2).matches() || str.indexOf(35) >= 0) {
            return str;
        }
        int indexOf = str.indexOf(63);
        String str3 = BuildConfig.FLAVOR;
        String substring = indexOf < 0 ? BuildConfig.FLAVOR : str.substring(indexOf + 1);
        if (substring.startsWith("code=") || substring.contains("&code=")) {
            return str;
        }
        if (indexOf < 0) {
            str3 = "?";
        } else if (!substring.isEmpty() && !substring.endsWith("&")) {
            str3 = "&";
        }
        return str + str3 + "code=" + str2;
    }

    public static String j0() {
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US);
        simpleDateFormat.setTimeZone(TimeZone.getTimeZone("UTC"));
        return simpleDateFormat.format(new Date());
    }

    public static boolean o(boolean z10, Boolean bool) {
        return z10 || !Boolean.FALSE.equals(bool);
    }

    public static JSONObject o0(String str) {
        if (str == null) {
            return null;
        }
        try {
            return new JSONObject(str);
        } catch (JSONException unused) {
            return null;
        }
    }

    public static d p0(String str, boolean z10) {
        boolean z11;
        if (str != null && !str.isEmpty()) {
            try {
                JSONObject jSONObject = new JSONObject(str);
                Object opt = jSONObject.opt("isAdConsentRequired");
                if (!(opt instanceof Boolean)) {
                    return null;
                }
                if (z10 && jSONObject.has("isAttributionBlocked")) {
                    Object obj = jSONObject.get("isAttributionBlocked");
                    if (!(obj instanceof Boolean)) {
                        return null;
                    }
                    z11 = ((Boolean) obj).booleanValue();
                } else {
                    z11 = false;
                }
                return new d(((Boolean) opt).booleanValue(), z11);
            } catch (JSONException unused) {
            }
        }
        return null;
    }

    public static String u0(String str, String str2) {
        int indexOf;
        if (str == null || (indexOf = str.indexOf(63)) < 0) {
            return null;
        }
        int indexOf2 = str.indexOf(35, indexOf);
        int i10 = indexOf + 1;
        if (indexOf2 < 0) {
            indexOf2 = str.length();
        }
        for (String str3 : str.substring(i10, indexOf2).split("&")) {
            int indexOf3 = str3.indexOf(61);
            if (indexOf3 > 0 && str3.substring(0, indexOf3).equals(str2)) {
                try {
                    return URLDecoder.decode(str3.substring(indexOf3 + 1), "UTF-8");
                } catch (UnsupportedEncodingException | IllegalArgumentException unused) {
                    return null;
                }
            }
        }
        return null;
    }

    public static d w0(h0 h0Var) {
        try {
            i0 body = h0Var.getBody();
            try {
                if (!h0Var.getIsSuccessful() || body == null) {
                    if (body != null) {
                        body.close();
                    }
                    return null;
                }
                d p02 = p0(body.h(), h.a().K1());
                body.close();
                return p02;
            } finally {
            }
        } catch (IOException unused) {
            return null;
        }
    }

    public final void A(Context context) {
        synchronized (this.f8840d) {
            Q(context).edit().remove("delayedStartConsentTs").remove("delayedStartConsentApplySharingFilter").remove("delayedStartConsentDma").apply();
        }
    }

    public final void A0(String str) {
        Set a10;
        a10 = ze.a(new Object[]{TelemetryBackend.COUNTER});
        fn.c.b(new fn.c.a(str, a10).j(2026, 7, 30).d());
    }

    public final long B() {
        return h.a().F4() * 1000;
    }

    public final void B0(String str) {
        g.b().q(str);
    }

    public final void C0(String str, List<NameValuePair> list) {
        t0.i(str, "appsFlyer", list);
    }

    public final void D(String str) {
        AppsFlyerLib.getInstance().start();
        if (str != null) {
            A0(str);
        }
        q0();
    }

    public final d D0() {
        try {
            h0 j10 = k.a().b().a(F()).j();
            try {
                d w02 = w0(j10);
                if (j10 != null) {
                    j10.close();
                }
                return w02;
            } finally {
            }
        } catch (IOException unused) {
            return null;
        }
    }

    public final void E(Context context) {
        G0(context, "enableTracking", true);
        U(true);
    }

    public final void E0(Context context) {
        d v02;
        d v03;
        if (!h.a().K1()) {
            synchronized (this.f8840d) {
                try {
                    v02 = v0(context);
                    if (v02 != null && v02.a()) {
                        e0(context);
                    }
                } finally {
                }
            }
            if (v02 == null) {
                I(context);
                return;
            } else {
                A0("Android-AppsFlyer-Eligibility-CacheHit");
                s(context, v02.f8854a, true);
                return;
            }
        }
        synchronized (this.f8840d) {
            try {
                v03 = v0(context);
                if (v03 != null) {
                    if (v03.a()) {
                        e0(context);
                    }
                    this.f8841e = false;
                    if (v03.b) {
                        this.f8842f = true;
                    }
                }
            } finally {
            }
        }
        if (v03 == null) {
            I(context);
        } else {
            A0("Android-AppsFlyer-Eligibility-CacheHit");
            r(context, v03);
        }
    }

    public final void F0() {
        JSONObject jSONObject;
        if (this.f12481a == null) {
            return;
        }
        synchronized (this.f8840d) {
            try {
                if (this.f8844h) {
                    return;
                }
                this.f8844h = true;
                String dataString = this.f12481a.getDataString();
                String M = M(u0(dataString, "deep_link_value"), u0(dataString, "af_dp"));
                if (M == null) {
                    return;
                }
                if (h.a().u2() && h.a().Y5()) {
                    M = h0(M, u0(dataString, "code"));
                }
                if (h.a().g1()) {
                    jSONObject = ym.g.G().j(M, "android_appsflyer_udl", false);
                } else {
                    ym.g.G().h(M, "android_appsflyer_udl", false);
                    jSONObject = null;
                }
                if (h.a().Y5()) {
                    M = h0(M, u0(dataString, "code"));
                    if (jSONObject != null) {
                        ym.g.G().L(jSONObject, M);
                    }
                }
                ym.g.G().n(M, null, null);
            } catch (Throwable th2) {
                throw th2;
            }
        }
    }

    public final long G() {
        return h.a().S5() * 1000;
    }

    public final void G0(Context context, String str, boolean z10) {
        SharedPreferences.Editor edit = Q(context).edit();
        edit.putBoolean(str, z10);
        edit.apply();
    }

    public final void H() {
        if (!h.a().D5() || nk.c.c().n()) {
            return;
        }
        AppsFlyerLib.getInstance().setDisableAdvertisingIdentifiers(false);
    }

    public final void I(Context context) {
        k.a().b().a(F()).b0(new c(context));
    }

    public final void I0(Context context, long j10) {
        Context applicationContext = context.getApplicationContext();
        long currentTimeMillis = j10 - System.currentTimeMillis();
        if (currentTimeMillis <= 0) {
            J(applicationContext);
        } else {
            ConsentBackstopWorker.INSTANCE.b(applicationContext, currentTimeMillis);
        }
    }

    public void J(Context context) {
        T0(context, null);
    }

    public void K() {
        if (this.b == null) {
            return;
        }
        synchronized (this.f8840d) {
            try {
                if (this.f8839c) {
                    return;
                }
                long j10 = Q(this.b).getLong("delayedStartBackstopDeadline", 0L);
                if (j10 == 0 || System.currentTimeMillis() < j10) {
                    return;
                }
                L(this.b);
            } catch (Throwable th2) {
                throw th2;
            }
        }
    }

    public void L(Context context) {
        synchronized (this.f8840d) {
            try {
                if (this.f8839c) {
                    return;
                }
                boolean z10 = Q(context).getBoolean("delayedStartBackstopEligibilityResolved", true);
                if (z10) {
                    A0("Android-AppsFlyer-Eligibility-Recheck-Skipped");
                    J(context);
                    return;
                }
                A0("Android-AppsFlyer-Eligibility-Recheck-Attempted");
                d D0 = D0();
                if (D0 != null) {
                    synchronized (this.f8840d) {
                        try {
                            boolean z11 = this.f8841e;
                            this.f8841e = false;
                            if (D0.b) {
                                this.f8842f = true;
                                w(context, D0);
                            } else if (z11) {
                                i0(context, D0.f8854a);
                            }
                        } finally {
                        }
                    }
                }
                if (D0 == null || !D0.b) {
                    l0(context, D0 == null ? null : Boolean.valueOf(D0.f8854a));
                } else {
                    A0("Android-AppsFlyer-Eligibility-Recheck-Blocked");
                    p(context);
                }
            } finally {
            }
        }
    }

    public final boolean N(Context context, String str, boolean z10) {
        return Q(context).getBoolean(str, z10);
    }

    public void P0(Context context, boolean z10) {
        G0(context, "disableDeeplinkTracking", !z10);
        a0.C(context);
        synchronized (this.f8840d) {
            try {
                if (this.f8839c) {
                    if (z10 && AppsFlyerLib.getInstance().isStopped()) {
                        r0(context, null, false);
                    } else if (!z10 && !AppsFlyerLib.getInstance().isStopped()) {
                        AppsFlyerLib.getInstance().stop(true, context);
                    }
                }
            } catch (Throwable th2) {
                throw th2;
            }
        }
    }

    public final boolean Q0() {
        synchronized (this.f8840d) {
            try {
                if (!this.f8843g) {
                    return false;
                }
                if (!h.a().w0()) {
                    return false;
                }
                A0("Android-AppsFlyer-DeferredRoute-Skip-ConsentHeld");
                return true;
            } catch (Throwable th2) {
                throw th2;
            }
        }
    }

    public final void R0(Context context, String str) {
        synchronized (this.f8840d) {
            if (!this.f8839c && !a0()) {
                boolean b02 = b0(context);
                this.f8839c = true;
                r0(context, str, b02);
            }
        }
    }

    public void S(Map<String, String> map) {
        JSONObject jSONObject;
        String str = map.get("af_dp");
        if (str != null) {
            if (h.a().u2() && h.a().Y5()) {
                str = h0(str, map.get("code"));
            }
            if (h.a().g1()) {
                jSONObject = ym.g.G().j(str, "android_appsflyer_re_engagement", false);
            } else {
                ym.g.G().h(str, "android_appsflyer_re_engagement", false);
                jSONObject = null;
            }
            String str2 = map.get("link");
            String L0 = L0(map.get("af_ad"), map.get("af_adset"), map.get("adgroup"), map.get("adset"));
            if (h.a().Y5()) {
                str = h0(str, map.get("code"));
                if (jSONObject != null) {
                    ym.g.G().L(jSONObject, str);
                }
            }
            if (str2 != null) {
                ym.g.G().n(str, str2, L0);
            } else {
                q.e("AppsFlyerManager", "Received null attribution URL. This should never happen.");
                ym.g.G().n(str, null, L0);
            }
        }
    }

    public final void S0(Context context) {
        if (b0(context)) {
            q0();
        } else {
            R0(context, "Android-AppsFlyer-Start-AtInit");
        }
    }

    public void T(Map<String, Object> map) {
        String M0;
        JSONObject jSONObject;
        q.h("AppsFlyerManager", "media-source: " + ((String) map.get("media_source")));
        boolean equals = Boolean.TRUE.equals(map.get("is_first_launch"));
        if (equals) {
            s0(map);
        }
        if (equals && map.containsKey("af_dp")) {
            if (!Q0() && y("Android-AppsFlyer-DeferredRoute-Skip-Gcd")) {
                boolean Y5 = h.a().Y5();
                HashMap hashMap = new HashMap();
                for (Map.Entry<String, Object> entry : map.entrySet()) {
                    Object value = entry.getValue();
                    hashMap.put(entry.getKey(), (value == null && Y5 && "code".equals(entry.getKey())) ? null : String.valueOf(value));
                }
                String str = hashMap.get("af_dp");
                if (str != null) {
                    if (h.a().g1()) {
                        ym.g.G().j(str, "android_appsflyer_gcd", false);
                    } else {
                        ym.g.G().h(str, "android_appsflyer_gcd", true);
                    }
                }
                S(hashMap);
                return;
            }
            return;
        }
        if (!equals || !(map.get("deep_link_value") instanceof String) || ((String) map.get("deep_link_value")).isEmpty()) {
            if (!equals || !h.a().S() || (M0 = M0(map)) == null || Q0()) {
                return;
            }
            t0(M0);
            return;
        }
        String str2 = (String) map.get("deep_link_value");
        if (!Q0() && y("Android-AppsFlyer-DeferredRoute-Skip-Gcd")) {
            if (h.a().u2() && h.a().Y5()) {
                Object obj = map.get("code");
                str2 = h0(str2, obj instanceof String ? (String) obj : null);
            }
            if (h.a().g1()) {
                jSONObject = ym.g.G().j(str2, "android_appsflyer_gcd", false);
            } else {
                ym.g.G().h(str2, "android_appsflyer_gcd", true);
                jSONObject = null;
            }
            String M02 = M0(map);
            if (h.a().Y5()) {
                Object obj2 = map.get("code");
                str2 = h0(str2, obj2 instanceof String ? (String) obj2 : null);
                if (jSONObject != null) {
                    ym.g.G().L(jSONObject, str2);
                }
            }
            ym.g.G().n(str2, null, M02);
        }
    }

    public final void T0(Context context, Boolean bool) {
        boolean z10;
        synchronized (this.f8840d) {
            try {
                if (!this.f8839c && !a0() && !W(context)) {
                    if (bool != null) {
                        boolean z11 = Q(context).getBoolean("delayedStartBackstopEligibilityResolved", true);
                        if (!z11) {
                            x(context, bool.booleanValue());
                        }
                        z10 = o(z11, bool);
                    } else {
                        z10 = true;
                    }
                    if (z10) {
                        AppsFlyerLib.getInstance().setSharingFilterForPartners("all");
                        v(context, true, null);
                    }
                    if (z10) {
                        a0.y(context);
                    } else {
                        i0(context, false);
                    }
                    boolean b02 = b0(context);
                    this.f8839c = true;
                    r0(context, z10 ? "Android-AppsFlyer-Start-Backstop" : "Android-AppsFlyer-Start-BackstopGeoResolved", b02);
                    z(context);
                }
            } finally {
            }
        }
    }

    public final void U(boolean z10) {
        if (z10) {
            AppsFlyerLib.getInstance().anonymizeUser(false);
        }
    }

    public void V(DeepLinkResult deepLinkResult) {
        String deepLinkValue;
        JSONObject jSONObject;
        if (deepLinkResult.getStatus() != DeepLinkResult.Status.FOUND || deepLinkResult.getDeepLink() == null || (deepLinkValue = deepLinkResult.getDeepLink().getDeepLinkValue()) == null || deepLinkValue.isEmpty()) {
            return;
        }
        Boolean isDeferred = deepLinkResult.getDeepLink().isDeferred();
        if (!Boolean.TRUE.equals(isDeferred) || (!Q0() && y("Android-AppsFlyer-DeferredRoute-Skip-Udl"))) {
            if (h.a().u2() && h.a().Y5()) {
                deepLinkValue = h0(deepLinkValue, deepLinkResult.getDeepLink().getStringValue("code"));
            }
            if (h.a().g1()) {
                jSONObject = ym.g.G().j(deepLinkValue, "android_appsflyer_udl", false);
            } else {
                if (isDeferred != null) {
                    ym.g.G().h(deepLinkValue, "android_appsflyer_udl", isDeferred.booleanValue());
                } else {
                    ym.g.G().g(deepLinkValue, "android_appsflyer_udl");
                }
                jSONObject = null;
            }
            String L0 = L0(deepLinkResult.getDeepLink().getStringValue("af_ad"), deepLinkResult.getDeepLink().getStringValue("af_adset"), deepLinkResult.getDeepLink().getStringValue("adgroup"), deepLinkResult.getDeepLink().getStringValue("adset"));
            if (h.a().Y5()) {
                deepLinkValue = h0(deepLinkValue, deepLinkResult.getDeepLink().getStringValue("code"));
                if (jSONObject != null) {
                    ym.g.G().L(jSONObject, deepLinkValue);
                }
            }
            ym.g.G().n(deepLinkValue, null, L0);
        }
    }

    public final boolean W(Context context) {
        d v02 = v0(context);
        return v02 != null && v02.b;
    }

    public final boolean Y() {
        return (nk.c.c().n() || wh.b.a()) ? false : true;
    }

    public final boolean Z() {
        boolean a02;
        synchronized (this.f8840d) {
            a02 = a0();
        }
        return a02;
    }

    @Override // dj.d
    public void a(Context context) {
        boolean a10 = wh.b.a();
        StringBuilder sb2 = new StringBuilder();
        sb2.append("init: initEnabled=");
        sb2.append(!a10);
        q.h("AppsFlyerManager", sb2.toString());
        if (a10) {
            return;
        }
        AppsFlyerLib appsFlyerLib = AppsFlyerLib.getInstance();
        appsFlyerLib.setMinTimeBetweenSessions(90);
        appsFlyerLib.setOneLinkCustomDomain("roblox.onelink.me", "ro.blox.com", "go.roblox.com");
        U(N(context, "enableTracking", true));
        C0139a c0139a = new C0139a();
        appsFlyerLib.setCollectAndroidID(false);
        if (h.a().D5()) {
            appsFlyerLib.setDisableAdvertisingIdentifiers(true);
        }
        appsFlyerLib.init("Quwp4RGsFwE6rVnyTFm6jQ", c0139a, context);
        appsFlyerLib.registerSessionReadyListener(new SessionReadyListener() { // from class: hh.a
            @Override // com.appsflyer.share.SessionReadyListener
            public final void onSessionReady() {
                com.roblox.client.appsflyer.a.this.n0();
            }
        });
        appsFlyerLib.subscribeForDeepLink(new b());
        boolean K1 = h.a().K1();
        synchronized (this.f8840d) {
            if (K1) {
                try {
                    this.f8841e = true;
                } catch (Throwable th2) {
                    throw th2;
                }
            }
            this.b = context;
        }
        a0.G(new BooleanSupplier() { // from class: hh.b
            @Override // java.util.function.BooleanSupplier
            public final boolean getAsBoolean() {
                boolean c02;
                c02 = com.roblox.client.appsflyer.a.this.c0();
                return c02;
            }
        });
        ym.g.G().x(new g.h() { // from class: hh.c
            @Override // ym.g.h
            public final void a(JSONObject jSONObject) {
                com.roblox.client.appsflyer.a.this.k0(jSONObject);
            }
        });
        E0(context);
        if (h.a().p4()) {
            ym.g.G().y(new g.i() { // from class: hh.d
                @Override // ym.g.i
                public final void a(boolean z10) {
                    com.roblox.client.appsflyer.a.this.d0(z10);
                }
            });
        }
        ym.g.G().F(appsFlyerLib.getAppsFlyerUID(context));
    }

    public final boolean a0() {
        return this.f8841e || this.f8842f;
    }

    @Override // dj.d
    public void b() {
        if (h.a().D5()) {
            AppsFlyerLib.getInstance().setDisableAdvertisingIdentifiers(true);
        }
        Context context = this.b;
        if (context == null) {
            return;
        }
        synchronized (this.f8840d) {
            try {
                if (a0.r()) {
                    A(context);
                }
                a0.B(context);
            } catch (Throwable th2) {
                throw th2;
            }
        }
    }

    public final boolean b0(Context context) {
        return h.a().L4() && N(context, "disableDeeplinkTracking", false);
    }

    @Override // dj.d
    public void c(Context context) {
        boolean Y = Y();
        q.h("AppsFlyerManager", "first play: enabled=" + Y);
        if (Y) {
            String str = "firstPlayReported_" + nk.c.c().j();
            if (N(context, str, false)) {
                return;
            }
            G0(context, str, true);
            if (!h.a().T3()) {
                AppsFlyerLib.getInstance().logEvent(this.b, AFInAppEventType.LEVEL_ACHIEVED, null);
            }
            C0("firstPlayReported", null);
            B0("Android-AppsFlyer-FirstPlay");
        }
    }

    public final /* synthetic */ boolean c0() {
        return b0(this.b);
    }

    @Override // dj.d
    public void d(Context context) {
        boolean Y = Y();
        q.h("AppsFlyerManager", "login: enabled=" + Y);
        if (!Y) {
            n(context);
            return;
        }
        H();
        C0("loginReported", null);
        B0("Android-AppsFlyer-Login");
        z0(context);
        E(context);
    }

    public final /* synthetic */ void d0(boolean z10) {
        P0(this.b, z10);
    }

    @Override // dj.d
    public void e(Context context, long j10) {
        boolean Y = Y();
        q.h("AppsFlyerManager", "playtime: enabled=" + Y);
        if (Y) {
            String str = "experiencePlaytimeReported_" + nk.c.c().j();
            if (N(context, str, false) || j10 < TimeUnit.MILLISECONDS.convert(15L, TimeUnit.MINUTES)) {
                return;
            }
            if (!h.a().P5()) {
                AppsFlyerLib.getInstance().logEvent(this.b, String.format(Locale.ENGLISH, "af_experience_playtime_%dmin", 15), null);
            }
            C0("experiencePlaytimeReported", null);
            B0("Android-AppsFlyer-ExperiencePlaytime");
            G0(context, str, true);
        }
    }

    public final void e0(Context context) {
        SharedPreferences Q = Q(context);
        if (Q.getLong("delayedStartBackstopDeadline", 0L) != 0) {
            Q.edit().putBoolean("delayedStartBackstopEligibilityResolved", true).apply();
        }
    }

    @Override // dj.d
    public void f(@NonNull String str, String str2, String str3, long j10, boolean z10) {
        boolean Y = Y();
        q.h("AppsFlyerManager", "Purchase. enabled=" + Y + ". Price: " + str2 + ".");
        if (Y) {
            y0(str, str2, str3);
        }
    }

    public final boolean f0(Context context) {
        SharedPreferences Q = Q(context);
        if (!X(Q.getLong("delayedStartConsentTs", 0L), System.currentTimeMillis(), G())) {
            return false;
        }
        boolean z10 = Q.getBoolean("delayedStartConsentApplySharingFilter", true);
        JSONObject o02 = o0(Q.getString("delayedStartConsentDma", null));
        i0(context, true);
        synchronized (this.f8840d) {
            try {
                if (this.f8839c) {
                    return true;
                }
                if (a0()) {
                    return false;
                }
                q(AppsFlyerLib.getInstance(), o02, z10);
                boolean b02 = b0(context);
                this.f8839c = true;
                z(context);
                r0(context, "Android-AppsFlyer-Start-CachedConsent", b02);
                return true;
            } catch (Throwable th2) {
                throw th2;
            }
        }
    }

    @Override // dj.d
    public void g(Context context) {
        boolean Y = Y();
        q.h("AppsFlyerManager", "signup: enabled=" + Y);
        if (!Y) {
            n(context);
            return;
        }
        H();
        C0("signUpReported", null);
        B0("Android-AppsFlyer-Registration");
        H0(context, R(nk.c.c().j()), TimeUnit.SECONDS.convert(System.currentTimeMillis(), TimeUnit.MILLISECONDS));
        E(context);
    }

    public boolean g0(Context context) {
        if (!a0.r() || h.a().j2() || b0(context) || !c0.e(x0(context))) {
            return false;
        }
        JSONObject o02 = o0(Q(context).getString("delayedStartConsentDma", null));
        synchronized (this.f8840d) {
            if (!this.f8839c && !a0()) {
                q(AppsFlyerLib.getInstance(), o02, true);
                boolean b02 = b0(context);
                this.f8839c = true;
                z(context);
                r0(context, "Android-AppsFlyer-Start-CachedConsent", b02);
                return true;
            }
            return false;
        }
    }

    @Override // dj.d
    public void i(String str) {
        AppsFlyerLib.getInstance().setCustomerUserId(str);
    }

    public final void i0(Context context, boolean z10) {
        if (Z()) {
            return;
        }
        a0.A(context, z10, x0(context));
    }

    /* JADX WARN: Removed duplicated region for block: B:15:0x0043 A[Catch: all -> 0x003c, TryCatch #0 {all -> 0x003c, blocks: (B:4:0x0007, B:7:0x0022, B:9:0x0033, B:13:0x003f, B:15:0x0043, B:17:0x004a, B:18:0x0052, B:26:0x001e), top: B:3:0x0007 }] */
    /* JADX WARN: Removed duplicated region for block: B:17:0x004a A[Catch: all -> 0x003c, TryCatch #0 {all -> 0x003c, blocks: (B:4:0x0007, B:7:0x0022, B:9:0x0033, B:13:0x003f, B:15:0x0043, B:17:0x004a, B:18:0x0052, B:26:0x001e), top: B:3:0x0007 }] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public void k0(org.json.JSONObject r7) {
        /*
            r6 = this;
            com.appsflyer.AppsFlyerLib r0 = com.appsflyer.AppsFlyerLib.getInstance()
            java.lang.Object r1 = r6.f8840d
            monitor-enter(r1)
            java.lang.String r2 = "dmaConsent"
            org.json.JSONObject r2 = r7.optJSONObject(r2)     // Catch: java.lang.Throwable -> L3c
            java.lang.String r3 = "applySharingFilter"
            r4 = 1
            boolean r3 = r7.optBoolean(r3, r4)     // Catch: java.lang.Throwable -> L3c
            java.lang.String r5 = "applySharingFilter"
            boolean r7 = r7.isNull(r5)     // Catch: java.lang.Throwable -> L3c
            if (r7 == 0) goto L1e
            r7 = 0
            goto L22
        L1e:
            java.lang.Boolean r7 = java.lang.Boolean.valueOf(r3)     // Catch: java.lang.Throwable -> L3c
        L22:
            java.lang.Boolean r5 = C(r2)     // Catch: java.lang.Throwable -> L3c
            r6.q(r0, r2, r3)     // Catch: java.lang.Throwable -> L3c
            android.content.Context r0 = r6.b     // Catch: java.lang.Throwable -> L3c
            r6.v(r0, r3, r2)     // Catch: java.lang.Throwable -> L3c
            boolean r0 = r6.f8839c     // Catch: java.lang.Throwable -> L3c
            r2 = 0
            if (r0 != 0) goto L3e
            boolean r0 = r6.a0()     // Catch: java.lang.Throwable -> L3c
            if (r0 == 0) goto L3a
            goto L3e
        L3a:
            r0 = r2
            goto L3f
        L3c:
            r7 = move-exception
            goto L63
        L3e:
            r0 = r4
        L3f:
            boolean r3 = r6.f8842f     // Catch: java.lang.Throwable -> L3c
            if (r3 != 0) goto L48
            android.content.Context r3 = r6.b     // Catch: java.lang.Throwable -> L3c
            eh.a0.z(r3, r7, r5)     // Catch: java.lang.Throwable -> L3c
        L48:
            if (r0 != 0) goto L52
            android.content.Context r7 = r6.b     // Catch: java.lang.Throwable -> L3c
            boolean r2 = r6.b0(r7)     // Catch: java.lang.Throwable -> L3c
            r6.f8839c = r4     // Catch: java.lang.Throwable -> L3c
        L52:
            monitor-exit(r1)     // Catch: java.lang.Throwable -> L3c
            if (r0 == 0) goto L56
            return
        L56:
            android.content.Context r7 = r6.b
            r6.z(r7)
            android.content.Context r7 = r6.b
            java.lang.String r0 = "Android-AppsFlyer-Start-Attribution"
            r6.r0(r7, r0, r2)
            return
        L63:
            monitor-exit(r1)     // Catch: java.lang.Throwable -> L3c
            throw r7
        */
        throw new UnsupportedOperationException("Method not decompiled: com.roblox.client.appsflyer.a.k0(org.json.JSONObject):void");
    }

    public void l0(Context context, Boolean bool) {
        if (bool == null) {
            A0("Android-AppsFlyer-Eligibility-Recheck-Unresolved");
        } else {
            A0(bool.booleanValue() ? "Android-AppsFlyer-Eligibility-Recheck-Flagged" : "Android-AppsFlyer-Eligibility-Recheck-NotFlagged");
        }
        if (Boolean.TRUE.equals(bool) && h.a().K1() && f0(context)) {
            return;
        }
        T0(context, bool);
    }

    public final void m0(Context context, d dVar) {
        if (dVar == null) {
            A0("Android-AppsFlyer-Eligibility-Unresolved");
            s(context, true, false);
            if (Z()) {
                F0();
                return;
            }
            return;
        }
        synchronized (this.f8840d) {
            try {
                this.f8841e = false;
                this.f8842f |= dVar.b;
                w(context, dVar);
                if (dVar.a()) {
                    e0(context);
                }
            } catch (Throwable th2) {
                throw th2;
            }
        }
        if (dVar.b) {
            A0("Android-AppsFlyer-Eligibility-Blocked");
        } else {
            A0(dVar.f8854a ? "Android-AppsFlyer-Eligibility-Flagged" : "Android-AppsFlyer-Eligibility-NotFlagged");
        }
        r(context, dVar);
    }

    public final void n(Context context) {
        AppsFlyerLib.getInstance().anonymizeUser(true);
        G0(context, "enableTracking", false);
    }

    public void n0() {
        synchronized (this.f8840d) {
            try {
                this.f8848l = true;
                if (this.f8849m) {
                    String str = this.f8850n;
                    this.f8849m = false;
                    this.f8850n = null;
                    D(str);
                }
            } catch (Throwable th2) {
                throw th2;
            }
        }
    }

    public void p(Context context) {
        synchronized (this.f8840d) {
            this.f8842f = true;
        }
        a0.x(context);
        if (Q(context).getLong("delayedStartBackstopDeadline", 0L) != 0) {
            z(context);
        }
        F0();
    }

    public final void q(AppsFlyerLib appsFlyerLib, JSONObject jSONObject, boolean z10) {
        if (jSONObject != null) {
            Boolean valueOf = jSONObject.has("consented") ? Boolean.valueOf(jSONObject.optBoolean("consented")) : null;
            appsFlyerLib.setConsentData(new AppsFlyerConsent(jSONObject.has("isSubjectToGdpr") ? Boolean.valueOf(jSONObject.optBoolean("isSubjectToGdpr")) : null, valueOf, valueOf, valueOf));
        }
        if (z10) {
            appsFlyerLib.setSharingFilterForPartners("all");
            A0("Android-AppsFlyer-Sharing-Filter-Applied");
        } else {
            appsFlyerLib.setSharingFilterForPartners(BuildConfig.FLAVOR);
            A0("Android-AppsFlyer-Sharing-Filter-Cleared");
        }
    }

    public final void q0() {
        if (this.f12481a == null) {
            return;
        }
        synchronized (this.f8840d) {
            try {
                if (this.f8844h) {
                    return;
                }
                this.f8844h = true;
                String dataString = this.f12481a.getDataString();
                if (dataString != null) {
                    AppsFlyerLib.getInstance().performDeepLinking(dataString, false);
                }
            } catch (Throwable th2) {
                throw th2;
            }
        }
    }

    public final void r(Context context, d dVar) {
        if (dVar.b) {
            p(context);
        } else {
            s(context, dVar.f8854a, true);
        }
    }

    public final void r0(Context context, String str, boolean z10) {
        if (z10) {
            AppsFlyerLib.getInstance().stop(true, context);
            return;
        }
        synchronized (this.f8840d) {
            try {
                if (this.f8848l) {
                    D(str);
                } else {
                    this.f8849m = true;
                    this.f8850n = str;
                }
            } catch (Throwable th2) {
                throw th2;
            }
        }
    }

    public void s(Context context, boolean z10, boolean z11) {
        if (z10) {
            if (f0(context)) {
                return;
            }
            i0(context, true);
            t(context, z11);
            return;
        }
        i0(context, false);
        if (!g0(context)) {
            S0(context);
        }
        if (Q(context).getLong("delayedStartBackstopDeadline", 0L) != 0) {
            z(context);
        }
    }

    public void s0(Map<String, Object> map) {
        boolean equals = "Organic".equals(map.get("af_status"));
        long j10 = a1.f4037u;
        if (j10 == 0) {
            B0("Android-AppsFlyer-AttributionContext-Skip-BtidNotReady");
            return;
        }
        try {
            JSONObject jSONObject = new JSONObject();
            jSONObject.put("body", u(j10, map).toString());
            MessageBus.getInstance().publish(MessageBusHelper.INSTANCE.getMessageId("Linking", "recordAttributionContext"), jSONObject);
            B0(equals ? "Android-AppsFlyer-AttributionContext-Published-Organic" : "Android-AppsFlyer-AttributionContext-Published");
        } catch (Exception e10) {
            q.e("AppsFlyerManager", "Failed to publish recordAttributionContext: " + e10.getMessage());
            B0("Android-AppsFlyer-AttributionContext-Skip-JsonError");
        }
    }

    public final void t(Context context, boolean z10) {
        synchronized (this.f8840d) {
            try {
                if (this.f8839c) {
                    return;
                }
                SharedPreferences Q = Q(context);
                long j10 = Q.getLong("delayedStartBackstopDeadline", 0L);
                if (j10 == 0) {
                    j10 = System.currentTimeMillis() + B();
                    Q.edit().putLong("delayedStartBackstopDeadline", j10).putBoolean("delayedStartBackstopEligibilityResolved", z10).apply();
                } else if (z10) {
                    Q.edit().putBoolean("delayedStartBackstopEligibilityResolved", true).apply();
                }
                if (j10 > System.currentTimeMillis()) {
                    this.f8843g = true;
                }
                I0(context, j10);
            } catch (Throwable th2) {
                throw th2;
            }
        }
    }

    public void t0(String str) {
        if (str == null || str.isEmpty()) {
            return;
        }
        synchronized (this.f8847k) {
            try {
                if (this.f8846j) {
                    A0("Android-AppsFlyer-DDR-Publish-Skip-Duplicate");
                    return;
                }
                this.f8846j = true;
                try {
                    JSONObject jSONObject = new JSONObject();
                    jSONObject.put("attributionAdName", str);
                    MessageBus.getInstance().publish(MessageBusHelper.INSTANCE.getMessageId("Linking", "resolveAttributionAdName"), jSONObject);
                } catch (JSONException e10) {
                    q.e("AppsFlyerManager", "Failed to publish resolveAttributionAdName: " + e10.getMessage());
                }
            } catch (Throwable th2) {
                throw th2;
            }
        }
    }

    public JSONObject u(long j10, Map<String, Object> map) {
        JSONObject jSONObject = new JSONObject();
        jSONObject.put("btid", String.valueOf(j10));
        jSONObject.put("afAd", b0.c(J0(map)));
        jSONObject.put("afAdset", b0.c(K0(map)));
        jSONObject.put("mediaSource", b0.c(map.get("media_source")));
        jSONObject.put("country", b0.c(map.get("country_code")));
        jSONObject.put("campaign", b0.c(map.get("campaign")));
        jSONObject.put("campaignId", b0.c(N0(map)));
        jSONObject.put("isRetargeting", Boolean.parseBoolean(String.valueOf(map.get("is_retargeting"))));
        jSONObject.put("retargetingConversionType", b0.c(map.get("retargeting_conversion_type")));
        jSONObject.put("siteId", b0.c(map.get("af_siteid")));
        jSONObject.put("channel", b0.c(map.get(AFInAppEventParameterName.AF_CHANNEL)));
        jSONObject.put("appsflyerId", b0.c(AppsFlyerLib.getInstance().getAppsFlyerUID(this.b)));
        jSONObject.put("deepLinkValue", b0.c(map.get("deep_link_value")));
        jSONObject.put("afDp", b0.c(map.get("af_dp")));
        jSONObject.put("installTime", V0(map.get("install_time")));
        jSONObject.put("platform", "ANDROID");
        jSONObject.put("requestId", UUID.randomUUID().toString());
        jSONObject.put("clientTime", j0());
        return jSONObject;
    }

    public final void v(Context context, boolean z10, JSONObject jSONObject) {
        SharedPreferences.Editor edit = Q(context).edit();
        edit.putBoolean("delayedStartConsentApplySharingFilter", z10);
        if (jSONObject != null) {
            edit.putString("delayedStartConsentDma", jSONObject.toString());
        } else {
            edit.remove("delayedStartConsentDma");
        }
        edit.putLong("delayedStartConsentTs", System.currentTimeMillis());
        edit.putLong("delayedStartFreshnessTtlMs", G());
        edit.apply();
    }

    public final d v0(Context context) {
        SharedPreferences Q = Q(context);
        long j10 = Q.getLong("delayedStartEligibilityTs", 0L);
        d dVar = null;
        if (j10 != 0 && System.currentTimeMillis() - j10 <= G()) {
            boolean N = N(context, "delayedStartFlagged", true);
            boolean K1 = h.a().K1();
            if (K1 && !Q.getBoolean("delayedStartEligibilityBlockAware", false)) {
                return null;
            }
            dVar = new d(N, K1 && Q.getBoolean("delayedStartAttributionBlocked", false));
        }
        return dVar;
    }

    public final void w(Context context, d dVar) {
        Q(context).edit().putBoolean("delayedStartFlagged", dVar.f8854a).putBoolean("delayedStartEligibilityBlockAware", h.a().K1()).putBoolean("delayedStartAttributionBlocked", dVar.b).putLong("delayedStartEligibilityTs", System.currentTimeMillis()).putLong("delayedStartFreshnessTtlMs", G()).apply();
    }

    public final void x(Context context, boolean z10) {
        w(context, new d(z10, false));
    }

    public final eh.b0 x0(Context context) {
        return eh.a.d(Q(context), System.currentTimeMillis(), G());
    }

    public boolean y(String str) {
        synchronized (this.f8847k) {
            try {
                if (this.f8845i) {
                    A0(str);
                    return false;
                }
                this.f8845i = true;
                A0("Android-AppsFlyer-DeferredRoute");
                return true;
            } catch (Throwable th2) {
                throw th2;
            }
        }
    }

    public final void y0(String str, String str2, String str3) {
        ArrayList arrayList = new ArrayList();
        arrayList.add(new NameValuePair("productId", str));
        arrayList.add(new NameValuePair("price", str2));
        arrayList.add(new NameValuePair("currencyCode", str3));
        C0("purchaseReported", arrayList);
        B0("Android-AppsFlyer-Purchase");
    }

    public final void z(Context context) {
        synchronized (this.f8840d) {
            Q(context).edit().remove("delayedStartBackstopDeadline").remove("delayedStartBackstopEligibilityResolved").apply();
        }
        ConsentBackstopWorker.INSTANCE.a(context);
    }

    public final void z0(Context context) {
        boolean Y = Y();
        q.h("AppsFlyerManager", "Login retention: enabled=" + Y);
        if (Y) {
            TimeUnit timeUnit = TimeUnit.SECONDS;
            long convert = timeUnit.convert(System.currentTimeMillis(), TimeUnit.MILLISECONDS);
            long j10 = nk.c.c().j();
            long P = P(context, R(j10), 0L);
            if (P > 0) {
                long convert2 = TimeUnit.DAYS.convert(convert - P, timeUnit);
                if (convert2 < 1 || convert2 > 3) {
                    return;
                }
                Locale locale = Locale.ENGLISH;
                String format = String.format(locale, "af_retention_d%d", Long.valueOf(convert2));
                String format2 = String.format(locale, "Android-AppsFlyer-AppRetention-D%d", Long.valueOf(convert2));
                String format3 = String.format(locale, "appRetentionReportedD%d", Long.valueOf(convert2));
                String str = format3 + "_" + j10;
                if (N(context, str, false)) {
                    return;
                }
                G0(context, str, true);
                if (!h.a().c6()) {
                    AppsFlyerLib.getInstance().logEvent(this.b, format, null);
                }
                C0(format3, null);
                B0(format2);
            }
        }
    }
}
