package com.roblox.protocols.calling;

import android.content.Context;
import android.graphics.Bitmap;
import androidx.annotation.Keep;
import av.d2;
import av.g1;
import av.g3;
import av.h2;
import av.k;
import av.p0;
import av.q0;
import av.w0;
import av.z2;
import com.github.luben.zstd.BuildConfig;

import com.roblox.protocols.callingplatforminterface.generated.CallingState;
import com.roblox.protocols.callingplatforminterface.generated.CallingStatus;
import com.roblox.protocols.callingplatforminterface.generated.ICallingCoreListener;
import com.roblox.protocols.callingplatforminterface.generated.IPlatformCalling;
import gu.l;
import gu.m;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.StringsKt;
import ok.q;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import pu.n;
import rj.b0;
import ul.ActiveCall;
import ul.h0;
import ul.j;
import zt.h;
import zt.i;
import zt.n;
import zt.o;

@Keep
@Metadata(d1 = {"\u0000\u0084\u0001\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0003\n\u0002\u0010\u000e\n\u0002\b\n\n\u0002\u0010\b\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0011\n\u0002\u0010\t\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\n\n\u0002\u0018\u0002\n\u0002\b\t\n\u0002\u0018\u0002\n\u0002\b\u0013\bÇ\u0002\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\u000f\u0010\u0005\u001a\u00020\u0004H\u0007¢\u0006\u0004\b\u0005\u0010\u0006J\u0017\u0010\n\u001a\u00020\t2\u0006\u0010\b\u001a\u00020\u0007H\u0007¢\u0006\u0004\b\n\u0010\u000bJ\u0017\u0010\f\u001a\u00020\t2\u0006\u0010\b\u001a\u00020\u0007H\u0007¢\u0006\u0004\b\f\u0010\u000bJ+\u0010\u0010\u001a\u00020\t2\u0006\u0010\b\u001a\u00020\u00072\b\u0010\u000e\u001a\u0004\u0018\u00010\r2\b\u0010\u000f\u001a\u0004\u0018\u00010\rH\u0007¢\u0006\u0004\b\u0010\u0010\u0011J\u001f\u0010\u0013\u001a\u00020\t2\u0006\u0010\b\u001a\u00020\u00072\u0006\u0010\u0012\u001a\u00020\rH\u0002¢\u0006\u0004\b\u0013\u0010\u0014J\u0017\u0010\u0015\u001a\u00020\t2\u0006\u0010\u0012\u001a\u00020\rH\u0002¢\u0006\u0004\b\u0015\u0010\u0016J\u0017\u0010\u0017\u001a\u00020\t2\u0006\u0010\u0012\u001a\u00020\rH\u0002¢\u0006\u0004\b\u0017\u0010\u0016J\u001f\u0010\u001a\u001a\u00020\t2\u0006\u0010\u0012\u001a\u00020\r2\u0006\u0010\u0019\u001a\u00020\u0018H\u0002¢\u0006\u0004\b\u001a\u0010\u001bJ\u0017\u0010\u001c\u001a\u00020\t2\u0006\u0010\b\u001a\u00020\u0007H\u0002¢\u0006\u0004\b\u001c\u0010\u000bJ\u001f\u0010\u001d\u001a\u00020\t2\u0006\u0010\b\u001a\u00020\u00072\u0006\u0010\u0012\u001a\u00020\rH\u0002¢\u0006\u0004\b\u001d\u0010\u0014J\u001d\u0010 \u001a\u00020\t2\f\u0010\u001f\u001a\b\u0012\u0004\u0012\u00020\t0\u001eH\u0002¢\u0006\u0004\b \u0010!J:\u0010+\u001a\u0004\u0018\u00010&2\u0006\u0010#\u001a\u00020\"2\u001e\u0010(\u001a\u001a\b\u0001\u0012\f\u0012\n\u0012\u0006\u0012\u0004\u0018\u00010&0%\u0012\u0006\u0012\u0004\u0018\u00010'0$H\u0081@¢\u0006\u0004\b)\u0010*J\u001f\u00100\u001a\u00020\t2\u0006\u0010\b\u001a\u00020\u00072\u0006\u0010-\u001a\u00020,H\u0001¢\u0006\u0004\b.\u0010/J\u0017\u00103\u001a\u00020\t2\u0006\u00102\u001a\u000201H\u0016¢\u0006\u0004\b3\u00104J\u0017\u00105\u001a\u00020\t2\u0006\u0010\u0012\u001a\u00020\rH\u0016¢\u0006\u0004\b5\u0010\u0016J!\u00109\u001a\u00020\t2\u0006\u0010\u0012\u001a\u00020\r2\b\u00106\u001a\u0004\u0018\u00010&H\u0001¢\u0006\u0004\b7\u00108J\u0017\u0010;\u001a\u00020\t2\u0006\u0010\u0012\u001a\u00020\rH\u0000¢\u0006\u0004\b:\u0010\u0016J\u0017\u0010=\u001a\u00020\t2\u0006\u0010\u0012\u001a\u00020\rH\u0000¢\u0006\u0004\b<\u0010\u0016J\u000f\u0010?\u001a\u00020\tH\u0001¢\u0006\u0004\b>\u0010\u0003R\u0014\u0010@\u001a\u00020\r8\u0002X\u0082T¢\u0006\u0006\n\u0004\b@\u0010AR\u0014\u0010B\u001a\u00020\r8\u0002X\u0082T¢\u0006\u0006\n\u0004\bB\u0010AR\u001a\u0010D\u001a\u00020C8\u0000X\u0081T¢\u0006\f\n\u0004\bD\u0010E\u0012\u0004\bF\u0010\u0003R\u0018\u0010G\u001a\u0004\u0018\u00010\u00078\u0002@\u0002X\u0082\u000e¢\u0006\u0006\n\u0004\bG\u0010HR\u0018\u0010J\u001a\u0004\u0018\u00010I8\u0002@\u0002X\u0082\u000e¢\u0006\u0006\n\u0004\bJ\u0010KR\u001b\u0010P\u001a\u00020\"8BX\u0082\u0084\u0002¢\u0006\f\n\u0004\bL\u0010M\u001a\u0004\bN\u0010OR\u001b\u0010S\u001a\u00020\"8BX\u0082\u0084\u0002¢\u0006\f\n\u0004\bQ\u0010M\u001a\u0004\bR\u0010OR\u0018\u0010U\u001a\u0004\u0018\u00010T8\u0002@\u0002X\u0082\u000e¢\u0006\u0006\n\u0004\bU\u0010VR6\u0010W\u001a\u0010\u0012\u0004\u0012\u00020\u0001\u0012\u0006\u0012\u0004\u0018\u00010I0$8\u0000@\u0000X\u0081\u000e¢\u0006\u0018\n\u0004\bW\u0010X\u0012\u0004\b]\u0010\u0003\u001a\u0004\bY\u0010Z\"\u0004\b[\u0010\\RN\u0010_\u001a(\u0012\u0004\u0012\u00020\u0007\u0012\u0004\u0012\u00020C\u0012\u0012\u0012\u0010\u0012\u0006\u0012\u0004\u0018\u00010&\u0012\u0004\u0012\u00020\t0$\u0012\u0004\u0012\u00020\t0^8\u0000@\u0000X\u0081\u000e¢\u0006\u0018\n\u0004\b_\u0010`\u0012\u0004\be\u0010\u0003\u001a\u0004\ba\u0010b\"\u0004\bc\u0010dR.\u0010f\u001a\b\u0012\u0004\u0012\u00020\u00040\u001e8\u0000@\u0000X\u0081\u000e¢\u0006\u0018\n\u0004\bf\u0010g\u0012\u0004\bk\u0010\u0003\u001a\u0004\bh\u0010i\"\u0004\bj\u0010!R\"\u0010l\u001a\u00020\u00048\u0006@\u0006X\u0086\u000e¢\u0006\u0012\n\u0004\bl\u0010m\u001a\u0004\bn\u0010\u0006\"\u0004\bo\u0010p¨\u0006q"}, d2 = {"Lcom/roblox/protocols/calling/CallingHandler;", "Lcom/roblox/protocols/callingplatforminterface/generated/IPlatformCalling;", "<init>", "()V", BuildConfig.FLAVOR, "isCallingEnabled", "()Z", "Landroid/content/Context;", "context", BuildConfig.FLAVOR, "setup", "(Landroid/content/Context;)V", "setupAsync", BuildConfig.FLAVOR, "callData", "callerName", "onIncomingCallPush", "(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V", "callId", "ring", "(Landroid/content/Context;Ljava/lang/String;)V", "alertIfReady", "(Ljava/lang/String;)V", "startOngoingCall", BuildConfig.FLAVOR, "cause", "endCall", "(Ljava/lang/String;I)V", "followCalls", "loadAvatar", "Lkotlin/Function0;", "block", "onMainThread", "(Lkotlin/jvm/functions/Function0;)V", "Lav/p0;", "scope", "Lkotlin/Function1;", "Leu/b;", "Landroid/graphics/Bitmap;", BuildConfig.FLAVOR, "load", "loadAvatarWithTimeout$NativeShell_googleProdRelease", "(Lav/p0;Lkotlin/jvm/functions/Function1;Leu/b;)Ljava/lang/Object;", "loadAvatarWithTimeout", "Lcom/roblox/protocols/calling/a;", "call", "forwardIncomingCallToEngine$NativeShell_googleProdRelease", "(Landroid/content/Context;Lcom/roblox/protocols/calling/a;)V", "forwardIncomingCallToEngine", "Lcom/roblox/protocols/callingplatforminterface/generated/CallingState;", "state", "onCallingStateChange", "(Lcom/roblox/protocols/callingplatforminterface/generated/CallingState;)V", "onCallingRemoved", "avatar", "onAvatarLoaded$NativeShell_googleProdRelease", "(Ljava/lang/String;Landroid/graphics/Bitmap;)V", "onAvatarLoaded", "answerCall$NativeShell_googleProdRelease", "answerCall", "declineCall$NativeShell_googleProdRelease", "declineCall", "resetForTest$NativeShell_googleProdRelease", "resetForTest", "TAG", "Ljava/lang/String;", "END_REASON_USER", BuildConfig.FLAVOR, "AVATAR_TIMEOUT_MS", "J", "getAVATAR_TIMEOUT_MS$NativeShell_googleProdRelease$annotations", "appContext", "Landroid/content/Context;", "Lcom/roblox/protocols/callingplatforminterface/generated/ICallingCoreListener;", "coreListener", "Lcom/roblox/protocols/callingplatforminterface/generated/ICallingCoreListener;", "mainScope$delegate", "Lzt/h;", "getMainScope", "()Lav/p0;", "mainScope", "ioScope$delegate", "getIoScope", "ioScope", "Lav/d2;", "surfaces", "Lav/d2;", "coreListenerFactory", "Lkotlin/jvm/functions/Function1;", "getCoreListenerFactory$NativeShell_googleProdRelease", "()Lkotlin/jvm/functions/Function1;", "setCoreListenerFactory$NativeShell_googleProdRelease", "(Lkotlin/jvm/functions/Function1;)V", "getCoreListenerFactory$NativeShell_googleProdRelease$annotations", "Lkotlin/Function3;", "fetchAvatar", "Lpu/n;", "getFetchAvatar$NativeShell_googleProdRelease", "()Lpu/n;", "setFetchAvatar$NativeShell_googleProdRelease", "(Lpu/n;)V", "getFetchAvatar$NativeShell_googleProdRelease$annotations", "engineFlagsLoaded", "Lkotlin/jvm/functions/Function0;", "getEngineFlagsLoaded$NativeShell_googleProdRelease", "()Lkotlin/jvm/functions/Function0;", "setEngineFlagsLoaded$NativeShell_googleProdRelease", "getEngineFlagsLoaded$NativeShell_googleProdRelease$annotations", "debugForceCallingEnabled", "Z", "getDebugForceCallingEnabled", "setDebugForceCallingEnabled", "(Z)V", "NativeShell_googleProdRelease"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* loaded from: classes2.dex */
public final class CallingHandler extends IPlatformCalling {
    public static final long AVATAR_TIMEOUT_MS = 2000;

    @NotNull
    private static final String END_REASON_USER = "NativeEndAction";

    @NotNull
    private static final String TAG = "CallingHandler";

    @Nullable
    private static volatile Context appContext;

    @Nullable
    private static volatile ICallingCoreListener coreListener;

    @Nullable
    private static d2 surfaces;

    @NotNull
    public static final CallingHandler INSTANCE = new CallingHandler();

    /* renamed from: mainScope$delegate, reason: from kotlin metadata */
    @NotNull
    private static final h mainScope = i.a(new Function0() { // from class: ul.o
        @Override // kotlin.jvm.functions.Function0
        public final Object invoke() {
            p0 mainScope_delegate$lambda$0;
            mainScope_delegate$lambda$0 = CallingHandler.mainScope_delegate$lambda$0();
            return mainScope_delegate$lambda$0;
        }
    });

    /* renamed from: ioScope$delegate, reason: from kotlin metadata */
    @NotNull
    private static final h ioScope = i.a(new Function0() { // from class: ul.p
        @Override // kotlin.jvm.functions.Function0
        public final Object invoke() {
            p0 ioScope_delegate$lambda$0;
            ioScope_delegate$lambda$0 = CallingHandler.ioScope_delegate$lambda$0();
            return ioScope_delegate$lambda$0;
        }
    });

    @NotNull
    private static Function1<? super IPlatformCalling, ? extends ICallingCoreListener> coreListenerFactory = new Function1() { // from class: ul.q
        @Override // kotlin.jvm.functions.Function1
        public final Object invoke(Object obj) {
            ICallingCoreListener coreListenerFactory$lambda$0;
            coreListenerFactory$lambda$0 = CallingHandler.coreListenerFactory$lambda$0((IPlatformCalling) obj);
            return coreListenerFactory$lambda$0;
        }
    };

    @NotNull
    private static n<? super Context, ? super Long, ? super Function1<? super Bitmap, Unit>, Unit> fetchAvatar = new n() { // from class: ul.r
        @Override // pu.n
        public final Object invoke(Object obj, Object obj2, Object obj3) {
            Unit fetchAvatar$lambda$0;
            fetchAvatar$lambda$0 = CallingHandler.fetchAvatar$lambda$0((Context) obj, ((Long) obj2).longValue(), (Function1) obj3);
            return fetchAvatar$lambda$0;
        }
    };

    @NotNull
    private static Function0<Boolean> engineFlagsLoaded = new Function0() { // from class: ul.s
        @Override // kotlin.jvm.functions.Function0
        public final Object invoke() {
            boolean m10;
            m10 = com.roblox.client.startup.a.m();
            return Boolean.valueOf(m10);
        }
    };
    private static volatile boolean debugForceCallingEnabled = true;

    @Metadata(k = 3, mv = {2, 2, 0}, xi = 48)
    public static final /* synthetic */ class a {

        /* renamed from: a, reason: collision with root package name */
        public static final /* synthetic */ int[] f9675a;

        static {
            int[] iArr = new int[CallingStatus.values().length];
            try {
                iArr[CallingStatus.RINGING.ordinal()] = 1;
            } catch (NoSuchFieldError unused) {
            }
            try {
                iArr[CallingStatus.CONNECTING.ordinal()] = 2;
            } catch (NoSuchFieldError unused2) {
            }
            try {
                iArr[CallingStatus.CONNECTED.ordinal()] = 3;
            } catch (NoSuchFieldError unused3) {
            }
            try {
                iArr[CallingStatus.MISSED.ordinal()] = 4;
            } catch (NoSuchFieldError unused4) {
            }
            try {
                iArr[CallingStatus.DECLINED.ordinal()] = 5;
            } catch (NoSuchFieldError unused5) {
            }
            try {
                iArr[CallingStatus.CANCELED.ordinal()] = 6;
            } catch (NoSuchFieldError unused6) {
            }
            try {
                iArr[CallingStatus.ENDED.ordinal()] = 7;
            } catch (NoSuchFieldError unused7) {
            }
            try {
                iArr[CallingStatus.SUPPRESSED.ordinal()] = 8;
            } catch (NoSuchFieldError unused8) {
            }
            try {
                iArr[CallingStatus.FAILED.ordinal()] = 9;
            } catch (NoSuchFieldError unused9) {
            }
            try {
                iArr[CallingStatus.ANSWERED_ELSEWHERE.ordinal()] = 10;
            } catch (NoSuchFieldError unused10) {
            }
            try {
                iArr[CallingStatus.DIALING_ELSEWHERE.ordinal()] = 11;
            } catch (NoSuchFieldError unused11) {
            }
            try {
                iArr[CallingStatus.DECLINED_ELSEWHERE.ordinal()] = 12;
            } catch (NoSuchFieldError unused12) {
            }
            try {
                iArr[CallingStatus.MISSED_ELSEWHERE.ordinal()] = 13;
            } catch (NoSuchFieldError unused13) {
            }
            try {
                iArr[CallingStatus.CANCELED_ELSEWHERE.ordinal()] = 14;
            } catch (NoSuchFieldError unused14) {
            }
            f9675a = iArr;
        }
    }

    @Metadata(d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0002\b\u0002\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\n¢\u0006\u0004\b\u0002\u0010\u0003"}, d2 = {"Lav/p0;", BuildConfig.FLAVOR, "<anonymous>", "(Lav/p0;)V"}, k = 3, mv = {2, 2, 0})
    @gu.f(c = "com.roblox.protocols.calling.CallingHandler$fetchAvatar$1$1", f = "CallingHandler.kt", l = {61}, m = "invokeSuspend", v = 1)
    public static final class b extends m implements Function2<p0, eu.b<? super Unit>, Object> {

        /* renamed from: t, reason: collision with root package name */
        public Object f9676t;

        /* renamed from: u, reason: collision with root package name */
        public int f9677u;

        /* renamed from: v, reason: collision with root package name */
        public final /* synthetic */ Function1<Bitmap, Unit> f9678v;

        /* renamed from: w, reason: collision with root package name */
        public final /* synthetic */ Context f9679w;

        /* renamed from: x, reason: collision with root package name */
        public final /* synthetic */ long f9680x;

        @Metadata(d1 = {"\u0000\u0006\n\u0000\n\u0002\u0018\u0002\u0010\u0000\u001a\u0004\u0018\u00010\u0001H\n"}, d2 = {"<anonymous>", "Landroid/graphics/Bitmap;"}, k = 3, mv = {2, 2, 0}, xi = 48)
        @gu.f(c = "com.roblox.protocols.calling.CallingHandler$fetchAvatar$1$1$1", f = "CallingHandler.kt", l = {61}, m = "invokeSuspend", v = 1)
        public static final class a extends m implements Function1<eu.b<? super Bitmap>, Object> {

            /* renamed from: t, reason: collision with root package name */
            public int f9681t;

            /* renamed from: u, reason: collision with root package name */
            public final /* synthetic */ Context f9682u;

            /* renamed from: v, reason: collision with root package name */
            public final /* synthetic */ long f9683v;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            public a(Context context, long j10, eu.b<? super a> bVar) {
                super(1, bVar);
                this.f9682u = context;
                this.f9683v = j10;
            }

            @Override // gu.a
            public final eu.b<Unit> create(eu.b<?> bVar) {
                return new a(this.f9682u, this.f9683v, bVar);
            }

            @Override // gu.a
            public final Object invokeSuspend(Object obj) {
                Object e10 = fu.c.e();
                int i10 = this.f9681t;
                if (i10 != 0) {
                    if (i10 != 1) {
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                    o.b(obj);
                    return obj;
                }
                o.b(obj);
                b0 b0Var = b0.f30737a;
                Context context = this.f9682u;
                long j10 = this.f9683v;
                this.f9681t = 1;
                Object d10 = b0Var.d(context, j10, this);
                return d10 == e10 ? e10 : d10;
            }

            @Override // kotlin.jvm.functions.Function1
            /* renamed from: m, reason: merged with bridge method [inline-methods] */
            public final Object invoke(eu.b<? super Bitmap> bVar) {
                return ((a) create(bVar)).invokeSuspend(Unit.f21504a);
            }
        }

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        /* JADX WARN: Multi-variable type inference failed */
        public b(Function1<? super Bitmap, Unit> function1, Context context, long j10, eu.b<? super b> bVar) {
            super(2, bVar);
            this.f9678v = function1;
            this.f9679w = context;
            this.f9680x = j10;
        }

        @Override // gu.a
        public final eu.b<Unit> create(Object obj, eu.b<?> bVar) {
            return new b(this.f9678v, this.f9679w, this.f9680x, bVar);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(p0 p0Var, eu.b<? super Unit> bVar) {
            return ((b) create(p0Var, bVar)).invokeSuspend(Unit.f21504a);
        }

        @Override // gu.a
        public final Object invokeSuspend(Object obj) {
            Function1 function1;
            Object e10 = fu.c.e();
            int i10 = this.f9677u;
            if (i10 == 0) {
                o.b(obj);
                Function1<Bitmap, Unit> function12 = this.f9678v;
                CallingHandler callingHandler = CallingHandler.INSTANCE;
                p0 ioScope = callingHandler.getIoScope();
                a aVar = new a(this.f9679w, this.f9680x, null);
                this.f9676t = function12;
                this.f9677u = 1;
                Object loadAvatarWithTimeout$NativeShell_googleProdRelease = callingHandler.loadAvatarWithTimeout$NativeShell_googleProdRelease(ioScope, aVar, this);
                if (loadAvatarWithTimeout$NativeShell_googleProdRelease == e10) {
                    return e10;
                }
                function1 = function12;
                obj = loadAvatarWithTimeout$NativeShell_googleProdRelease;
            } else {
                if (i10 != 1) {
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                function1 = (Function1) this.f9676t;
                o.b(obj);
            }
            function1.invoke(obj);
            return Unit.f21504a;
        }
    }

    @Metadata(d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0002\b\u0002\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\n¢\u0006\u0004\b\u0002\u0010\u0003"}, d2 = {"Lav/p0;", BuildConfig.FLAVOR, "<anonymous>", "(Lav/p0;)V"}, k = 3, mv = {2, 2, 0})
    @gu.f(c = "com.roblox.protocols.calling.CallingHandler$followCalls$1", f = "CallingHandler.kt", l = {230}, m = "invokeSuspend", v = 1)
    public static final class c extends m implements Function2<p0, eu.b<? super Unit>, Object> {

        /* renamed from: t, reason: collision with root package name */
        public int f9684t;

        /* renamed from: u, reason: collision with root package name */
        public final /* synthetic */ Context f9685u;

        @Metadata(k = 3, mv = {2, 2, 0}, xi = 48)
        public static final class a<T> implements dv.i {

            /* renamed from: a, reason: collision with root package name */
            public final /* synthetic */ Context f9686a;

            public a(Context context) {
                this.f9686a = context;
            }

            @Override // dv.i
            /* renamed from: b, reason: merged with bridge method [inline-methods] */
            public final Object emit(ActiveCall activeCall, eu.b<? super Unit> bVar) {
                ul.i.f33539a.j(this.f9686a, activeCall);
                if (activeCall.m()) {
                    ul.d.f33493a.e(activeCall.getCallId());
                }
                return Unit.f21504a;
            }
        }

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public c(Context context, eu.b<? super c> bVar) {
            super(2, bVar);
            this.f9685u = context;
        }

        @Override // gu.a
        public final eu.b<Unit> create(Object obj, eu.b<?> bVar) {
            return new c(this.f9685u, bVar);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(p0 p0Var, eu.b<? super Unit> bVar) {
            return ((c) create(p0Var, bVar)).invokeSuspend(Unit.f21504a);
        }

        @Override // gu.a
        public final Object invokeSuspend(Object obj) {
            Object e10 = fu.c.e();
            int i10 = this.f9684t;
            if (i10 == 0) {
                o.b(obj);
                dv.h<ActiveCall> h10 = ul.d.f33493a.h();
                a aVar = new a(this.f9685u);
                this.f9684t = 1;
                if (h10.collect(aVar, this) == e10) {
                    return e10;
                }
            } else {
                if (i10 != 1) {
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                o.b(obj);
            }
            return Unit.f21504a;
        }
    }

    @Metadata(d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\u0010\u0002\u001a\u0004\u0018\u00010\u0001*\u00020\u0000H\n¢\u0006\u0004\b\u0002\u0010\u0003"}, d2 = {"Lav/p0;", "Landroid/graphics/Bitmap;", "<anonymous>", "(Lav/p0;)Landroid/graphics/Bitmap;"}, k = 3, mv = {2, 2, 0})
    @gu.f(c = "com.roblox.protocols.calling.CallingHandler$loadAvatarWithTimeout$2", f = "CallingHandler.kt", l = {71}, m = "invokeSuspend", v = 1)
    public static final class d extends m implements Function2<p0, eu.b<? super Bitmap>, Object> {

        /* renamed from: t, reason: collision with root package name */
        public int f9687t;

        /* renamed from: u, reason: collision with root package name */
        public final /* synthetic */ w0<Bitmap> f9688u;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public d(w0<Bitmap> w0Var, eu.b<? super d> bVar) {
            super(2, bVar);
            this.f9688u = w0Var;
        }

        @Override // gu.a
        public final eu.b<Unit> create(Object obj, eu.b<?> bVar) {
            return new d(this.f9688u, bVar);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(p0 p0Var, eu.b<? super Bitmap> bVar) {
            return ((d) create(p0Var, bVar)).invokeSuspend(Unit.f21504a);
        }

        @Override // gu.a
        public final Object invokeSuspend(Object obj) {
            Object e10 = fu.c.e();
            int i10 = this.f9687t;
            if (i10 != 0) {
                if (i10 != 1) {
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                o.b(obj);
                return obj;
            }
            o.b(obj);
            w0<Bitmap> w0Var = this.f9688u;
            this.f9687t = 1;
            Object y10 = w0Var.y(this);
            return y10 == e10 ? e10 : y10;
        }
    }

    @Metadata(d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\u0010\u0002\u001a\u0004\u0018\u00010\u0001*\u00020\u0000H\n¢\u0006\u0004\b\u0002\u0010\u0003"}, d2 = {"Lav/p0;", "Landroid/graphics/Bitmap;", "<anonymous>", "(Lav/p0;)Landroid/graphics/Bitmap;"}, k = 3, mv = {2, 2, 0})
    @gu.f(c = "com.roblox.protocols.calling.CallingHandler$loadAvatarWithTimeout$avatar$1", f = "CallingHandler.kt", l = {70}, m = "invokeSuspend", v = 1)
    public static final class e extends m implements Function2<p0, eu.b<? super Bitmap>, Object> {

        /* renamed from: t, reason: collision with root package name */
        public Object f9689t;

        /* renamed from: u, reason: collision with root package name */
        public int f9690u;

        /* renamed from: v, reason: collision with root package name */
        public int f9691v;

        /* renamed from: w, reason: collision with root package name */
        public /* synthetic */ Object f9692w;

        /* renamed from: x, reason: collision with root package name */
        public final /* synthetic */ Function1<eu.b<? super Bitmap>, Object> f9693x;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        /* JADX WARN: Multi-variable type inference failed */
        public e(Function1<? super eu.b<? super Bitmap>, ? extends Object> function1, eu.b<? super e> bVar) {
            super(2, bVar);
            this.f9693x = function1;
        }

        @Override // gu.a
        public final eu.b<Unit> create(Object obj, eu.b<?> bVar) {
            e eVar = new e(this.f9693x, bVar);
            eVar.f9692w = obj;
            return eVar;
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(p0 p0Var, eu.b<? super Bitmap> bVar) {
            return ((e) create(p0Var, bVar)).invokeSuspend(Unit.f21504a);
        }

        @Override // gu.a
        public final Object invokeSuspend(Object obj) {
            Object b;
            p0 p0Var = (p0) this.f9692w;
            Object e10 = fu.c.e();
            int i10 = this.f9691v;
            try {
                if (i10 == 0) {
                    o.b(obj);
                    Function1<eu.b<? super Bitmap>, Object> function1 = this.f9693x;
                    n.Companion companion = zt.n.INSTANCE;
                    this.f9692w = l.a(p0Var);
                    this.f9689t = l.a(p0Var);
                    this.f9690u = 0;
                    this.f9691v = 1;
                    obj = function1.invoke(this);
                    if (obj == e10) {
                        return e10;
                    }
                } else {
                    if (i10 != 1) {
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                    o.b(obj);
                }
                b = zt.n.b((Bitmap) obj);
            } catch (Throwable th2) {
                n.Companion companion2 = zt.n.INSTANCE;
                b = zt.n.b(o.a(th2));
            }
            if (zt.n.g(b)) {
                return null;
            }
            return b;
        }
    }

    @Metadata(d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0002\b\u0002\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\n¢\u0006\u0004\b\u0002\u0010\u0003"}, d2 = {"Lav/p0;", BuildConfig.FLAVOR, "<anonymous>", "(Lav/p0;)V"}, k = 3, mv = {2, 2, 0})
    @gu.f(c = "com.roblox.protocols.calling.CallingHandler$onMainThread$1", f = "CallingHandler.kt", l = {}, m = "invokeSuspend", v = 1)
    public static final class f extends m implements Function2<p0, eu.b<? super Unit>, Object> {

        /* renamed from: t, reason: collision with root package name */
        public int f9694t;

        /* renamed from: u, reason: collision with root package name */
        public final /* synthetic */ Function0<Unit> f9695u;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public f(Function0<Unit> function0, eu.b<? super f> bVar) {
            super(2, bVar);
            this.f9695u = function0;
        }

        @Override // gu.a
        public final eu.b<Unit> create(Object obj, eu.b<?> bVar) {
            return new f(this.f9695u, bVar);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(p0 p0Var, eu.b<? super Unit> bVar) {
            return ((f) create(p0Var, bVar)).invokeSuspend(Unit.f21504a);
        }

        @Override // gu.a
        public final Object invokeSuspend(Object obj) {
            fu.c.e();
            if (this.f9694t != 0) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            o.b(obj);
            this.f9695u.invoke();
            return Unit.f21504a;
        }
    }

    @Metadata(d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0002\b\u0002\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\n¢\u0006\u0004\b\u0002\u0010\u0003"}, d2 = {"Lav/p0;", BuildConfig.FLAVOR, "<anonymous>", "(Lav/p0;)V"}, k = 3, mv = {2, 2, 0})
    @gu.f(c = "com.roblox.protocols.calling.CallingHandler$setupAsync$1", f = "CallingHandler.kt", l = {}, m = "invokeSuspend", v = 1)
    public static final class g extends m implements Function2<p0, eu.b<? super Unit>, Object> {

        /* renamed from: t, reason: collision with root package name */
        public int f9696t;

        /* renamed from: u, reason: collision with root package name */
        public final /* synthetic */ Context f9697u;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public g(Context context, eu.b<? super g> bVar) {
            super(2, bVar);
            this.f9697u = context;
        }

        @Override // gu.a
        public final eu.b<Unit> create(Object obj, eu.b<?> bVar) {
            return new g(this.f9697u, bVar);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(p0 p0Var, eu.b<? super Unit> bVar) {
            return ((g) create(p0Var, bVar)).invokeSuspend(Unit.f21504a);
        }

        @Override // gu.a
        public final Object invokeSuspend(Object obj) {
            fu.c.e();
            if (this.f9696t != 0) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            o.b(obj);
            Context context = this.f9697u;
            Intrinsics.checkNotNull(context);
            CallingHandler.setup(context);
            return Unit.f21504a;
        }
    }

    private CallingHandler() {
    }

    private final void alertIfReady(String callId) {
        ul.d.f33493a.m(callId, new Function1() { // from class: ul.z
            @Override // kotlin.jvm.functions.Function1
            public final Object invoke(Object obj) {
                boolean alertIfReady$lambda$0;
                alertIfReady$lambda$0 = CallingHandler.alertIfReady$lambda$0((ActiveCall) obj);
                return Boolean.valueOf(alertIfReady$lambda$0);
            }
        }, new Function1() { // from class: ul.a0
            @Override // kotlin.jvm.functions.Function1
            public final Object invoke(Object obj) {
                ActiveCall alertIfReady$lambda$1;
                alertIfReady$lambda$1 = CallingHandler.alertIfReady$lambda$1((ActiveCall) obj);
                return alertIfReady$lambda$1;
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final boolean alertIfReady$lambda$0(ActiveCall it) {
        Intrinsics.checkNotNullParameter(it, "it");
        return it.l(h0.b) && it.getAvatarLoad() == ul.e.f33524c;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final ActiveCall alertIfReady$lambda$1(ActiveCall it) {
        Intrinsics.checkNotNullParameter(it, "it");
        return ActiveCall.b(it, null, 0, 0, null, null, null, h0.f33536c, null, null, 447, null);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final ICallingCoreListener coreListenerFactory$lambda$0(IPlatformCalling it) {
        Intrinsics.checkNotNullParameter(it, "it");
        return ICallingCoreListener.setPlatformImpl(it);
    }

    private final void endCall(String callId, final int cause) {
        ul.d.f33493a.f(callId, new Function1() { // from class: ul.y
            @Override // kotlin.jvm.functions.Function1
            public final Object invoke(Object obj) {
                ActiveCall endCall$lambda$0;
                endCall$lambda$0 = CallingHandler.endCall$lambda$0(cause, (ActiveCall) obj);
                return endCall$lambda$0;
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final ActiveCall endCall$lambda$0(int i10, ActiveCall it) {
        Intrinsics.checkNotNullParameter(it, "it");
        return ActiveCall.b(it, null, 0, 0, null, null, (i10 != 5 || it.getPhase() == j.b) ? j.f33545d : j.f33544c, null, null, null, 479, null);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit fetchAvatar$lambda$0(Context context, long j10, Function1 onResult) {
        Intrinsics.checkNotNullParameter(context, "context");
        Intrinsics.checkNotNullParameter(onResult, "onResult");
        k.d(INSTANCE.getIoScope(), null, null, new b(onResult, context, j10, null), 3, null);
        return Unit.f21504a;
    }

    private final void followCalls(Context context) {
        d2 d10;
        d2 d2Var = surfaces;
        if (d2Var == null || !d2Var.b()) {
            d10 = k.d(getMainScope(), null, null, new c(context, null), 3, null);
            surfaces = d10;
        }
    }

    public static /* synthetic */ void getAVATAR_TIMEOUT_MS$NativeShell_googleProdRelease$annotations() {
    }

    public static /* synthetic */ void getCoreListenerFactory$NativeShell_googleProdRelease$annotations() {
    }

    public static /* synthetic */ void getEngineFlagsLoaded$NativeShell_googleProdRelease$annotations() {
    }

    public static /* synthetic */ void getFetchAvatar$NativeShell_googleProdRelease$annotations() {
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final p0 getIoScope() {
        return (p0) ioScope.getValue();
    }

    private final p0 getMainScope() {
        return (p0) mainScope.getValue();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final p0 ioScope_delegate$lambda$0() {
        return q0.a(z2.b(null, 1, null).plus(g1.b()));
    }

    @Keep
    public static final boolean isCallingEnabled() {
        return false;
    }

    private final void loadAvatar(Context context, final String callId) {
        Long callerUserId;
        ActiveCall m10 = ul.d.f33493a.m(callId, new Function1() { // from class: ul.b0
            @Override // kotlin.jvm.functions.Function1
            public final Object invoke(Object obj) {
                boolean loadAvatar$lambda$0;
                loadAvatar$lambda$0 = CallingHandler.loadAvatar$lambda$0((ActiveCall) obj);
                return Boolean.valueOf(loadAvatar$lambda$0);
            }
        }, new Function1() { // from class: ul.c0
            @Override // kotlin.jvm.functions.Function1
            public final Object invoke(Object obj) {
                ActiveCall loadAvatar$lambda$1;
                loadAvatar$lambda$1 = CallingHandler.loadAvatar$lambda$1((ActiveCall) obj);
                return loadAvatar$lambda$1;
            }
        });
        if (m10 == null || (callerUserId = m10.getCallerUserId()) == null) {
            return;
        }
        fetchAvatar.invoke(context, callerUserId, new Function1() { // from class: ul.d0
            @Override // kotlin.jvm.functions.Function1
            public final Object invoke(Object obj) {
                Unit loadAvatar$lambda$2;
                loadAvatar$lambda$2 = CallingHandler.loadAvatar$lambda$2(callId, (Bitmap) obj);
                return loadAvatar$lambda$2;
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final boolean loadAvatar$lambda$0(ActiveCall it) {
        Intrinsics.checkNotNullParameter(it, "it");
        return it.getAvatarLoad() == ul.e.f33523a;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final ActiveCall loadAvatar$lambda$1(ActiveCall it) {
        Intrinsics.checkNotNullParameter(it, "it");
        return ActiveCall.b(it, null, 0, 0, null, null, null, null, null, it.getCallerUserId() != null ? ul.e.b : ul.e.f33524c, 255, null);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit loadAvatar$lambda$2(final String str, final Bitmap bitmap) {
        INSTANCE.onMainThread(new Function0() { // from class: ul.u
            @Override // kotlin.jvm.functions.Function0
            public final Object invoke() {
                Unit loadAvatar$lambda$2$0;
                loadAvatar$lambda$2$0 = CallingHandler.loadAvatar$lambda$2$0(str, bitmap);
                return loadAvatar$lambda$2$0;
            }
        });
        return Unit.f21504a;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit loadAvatar$lambda$2$0(String str, Bitmap bitmap) {
        INSTANCE.onAvatarLoaded$NativeShell_googleProdRelease(str, bitmap);
        return Unit.f21504a;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final p0 mainScope_delegate$lambda$0() {
        return q0.a(z2.b(null, 1, null).plus(g1.c().getImmediate()));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final ActiveCall onAvatarLoaded$lambda$0(Bitmap bitmap, ActiveCall it) {
        Intrinsics.checkNotNullParameter(it, "it");
        return ActiveCall.b(it, null, 0, 0, null, null, null, null, bitmap, ul.e.f33524c, 127, null);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit onCallingRemoved$lambda$0(String str) {
        INSTANCE.endCall(str, 2);
        return Unit.f21504a;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit onCallingStateChange$lambda$0(CallingState callingState) {
        Context context = appContext;
        if (context == null) {
            return Unit.f21504a;
        }
        String callId = callingState.getCallId();
        CallingStatus status = callingState.getStatus();
        switch (status == null ? -1 : a.f9675a[status.ordinal()]) {
            case 1:
                CallingHandler callingHandler = INSTANCE;
                ul.d dVar = ul.d.f33493a;
                Intrinsics.checkNotNull(callId);
                callingHandler.ring(context, dVar.i(callId).getCallId());
                break;
            case 2:
            case 3:
                CallingHandler callingHandler2 = INSTANCE;
                ul.d dVar2 = ul.d.f33493a;
                Intrinsics.checkNotNull(callId);
                callingHandler2.startOngoingCall(dVar2.i(callId).getCallId());
                break;
            case 4:
                CallingHandler callingHandler3 = INSTANCE;
                Intrinsics.checkNotNull(callId);
                callingHandler3.endCall(callId, 5);
                break;
            case 5:
                CallingHandler callingHandler4 = INSTANCE;
                Intrinsics.checkNotNull(callId);
                callingHandler4.endCall(callId, 6);
                break;
            case 6:
                CallingHandler callingHandler5 = INSTANCE;
                Intrinsics.checkNotNull(callId);
                callingHandler5.endCall(callId, 4);
                break;
            case 7:
            case 8:
            case 9:
                CallingHandler callingHandler6 = INSTANCE;
                Intrinsics.checkNotNull(callId);
                callingHandler6.endCall(callId, 3);
                break;
            case 10:
            case 11:
                CallingHandler callingHandler7 = INSTANCE;
                Intrinsics.checkNotNull(callId);
                callingHandler7.endCall(callId, 11);
                break;
            case 12:
                CallingHandler callingHandler8 = INSTANCE;
                Intrinsics.checkNotNull(callId);
                callingHandler8.endCall(callId, 6);
                break;
            case 13:
            case 14:
                CallingHandler callingHandler9 = INSTANCE;
                Intrinsics.checkNotNull(callId);
                callingHandler9.endCall(callId, 4);
                break;
        }
        return Unit.f21504a;
    }

    public static final void onIncomingCallPush(@NotNull Context context, @Nullable String callData, @Nullable String callerName) {
        Intrinsics.checkNotNullParameter(context, "context");
        if (!isCallingEnabled()) {
            q.h(TAG, "calling is off; dropping call push");
            return;
        }
        IncomingCall b10 = callData != null ? IncomingCall.INSTANCE.b(StringsKt.n1(callData).toString(), callerName) : null;
        if (b10 == null) {
            q.e(TAG, "call push has no callId; dropping");
        } else if (engineFlagsLoaded.invoke().booleanValue()) {
            INSTANCE.forwardIncomingCallToEngine$NativeShell_googleProdRelease(context, b10);
        } else {
            q.k(TAG, "engine flags not loaded; dropping call push");
        }
    }

    private final void onMainThread(Function0<Unit> block) {
        k.d(getMainScope(), null, null, new f(block, null), 3, null);
    }

    private final void ring(Context context, String callId) {
        if (ul.d.f33493a.m(callId, new Function1() { // from class: ul.m
            @Override // kotlin.jvm.functions.Function1
            public final Object invoke(Object obj) {
                boolean ring$lambda$0;
                ring$lambda$0 = CallingHandler.ring$lambda$0((ActiveCall) obj);
                return Boolean.valueOf(ring$lambda$0);
            }
        }, new Function1() { // from class: ul.n
            @Override // kotlin.jvm.functions.Function1
            public final Object invoke(Object obj) {
                ActiveCall ring$lambda$1;
                ring$lambda$1 = CallingHandler.ring$lambda$1((ActiveCall) obj);
                return ring$lambda$1;
            }
        }) == null) {
            return;
        }
        loadAvatar(context, callId);
        alertIfReady(callId);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final boolean ring$lambda$0(ActiveCall it) {
        Intrinsics.checkNotNullParameter(it, "it");
        return it.l(h0.f33535a);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final ActiveCall ring$lambda$1(ActiveCall it) {
        Intrinsics.checkNotNullParameter(it, "it");
        return ActiveCall.b(it, null, 0, 0, null, null, null, h0.b, null, null, 447, null);
    }

    public static final synchronized void setup(@NotNull Context context) {
        synchronized (CallingHandler.class) {
            Intrinsics.checkNotNullParameter(context, "context");
            if (isCallingEnabled()) {
                appContext = context.getApplicationContext();
                ul.i.f33539a.d(context);
                CallingHandler callingHandler = INSTANCE;
                Context applicationContext = context.getApplicationContext();
                Intrinsics.checkNotNullExpressionValue(applicationContext, "getApplicationContext(...)");
                callingHandler.followCalls(applicationContext);
                if (coreListener == null) {
                    coreListener = coreListenerFactory.invoke(callingHandler);
                }
            }
        }
    }

    public static final void setupAsync(@NotNull Context context) {
        Intrinsics.checkNotNullParameter(context, "context");
        k.d(INSTANCE.getIoScope(), null, null, new g(context.getApplicationContext(), null), 3, null);
    }

    private final void startOngoingCall(String callId) {
        ul.d.f33493a.m(callId, new Function1() { // from class: ul.v
            @Override // kotlin.jvm.functions.Function1
            public final Object invoke(Object obj) {
                boolean startOngoingCall$lambda$0;
                startOngoingCall$lambda$0 = CallingHandler.startOngoingCall$lambda$0((ActiveCall) obj);
                return Boolean.valueOf(startOngoingCall$lambda$0);
            }
        }, new Function1() { // from class: ul.w
            @Override // kotlin.jvm.functions.Function1
            public final Object invoke(Object obj) {
                ActiveCall startOngoingCall$lambda$1;
                startOngoingCall$lambda$1 = CallingHandler.startOngoingCall$lambda$1((ActiveCall) obj);
                return startOngoingCall$lambda$1;
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final boolean startOngoingCall$lambda$0(ActiveCall it) {
        Intrinsics.checkNotNullParameter(it, "it");
        return it.getPhase() == j.f33543a;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final ActiveCall startOngoingCall$lambda$1(ActiveCall it) {
        Intrinsics.checkNotNullParameter(it, "it");
        return ActiveCall.b(it, null, 0, 0, null, null, j.b, null, null, null, 479, null);
    }

    public final void answerCall$NativeShell_googleProdRelease(@NotNull String callId) {
        Intrinsics.checkNotNullParameter(callId, "callId");
        ICallingCoreListener iCallingCoreListener = coreListener;
        if (iCallingCoreListener == null) {
            return;
        }
        iCallingCoreListener.answerIncomingCall(callId);
        startOngoingCall(callId);
    }

    public final void declineCall$NativeShell_googleProdRelease(@NotNull String callId) {
        Intrinsics.checkNotNullParameter(callId, "callId");
        ICallingCoreListener iCallingCoreListener = coreListener;
        if (iCallingCoreListener != null) {
            iCallingCoreListener.endCall(callId, END_REASON_USER);
        }
    }

    public final void forwardIncomingCallToEngine$NativeShell_googleProdRelease(@NotNull Context context, @NotNull IncomingCall call) {
        Intrinsics.checkNotNullParameter(context, "context");
        Intrinsics.checkNotNullParameter(call, "call");
        setup(context);
        ICallingCoreListener iCallingCoreListener = coreListener;
        if (iCallingCoreListener == null) {
            return;
        }
        ul.d dVar = ul.d.f33493a;
        ActiveCall b10 = dVar.b(dVar.j(call.getCallId(), call.getCallerUserId(), call.getCallerName()));
        if (b10 == null) {
            q.h(TAG, "duplicate push for live call " + call.getCallId() + "; dropping");
            return;
        }
        try {
            iCallingCoreListener.receiveIncomingCall(call.getCallData());
        } catch (RuntimeException e10) {
            q.e(TAG, "engine didn't take call " + call.getCallId() + ": " + e10.getMessage());
            ul.d.f33493a.d(b10);
        }
    }

    @NotNull
    public final Function1<IPlatformCalling, ICallingCoreListener> getCoreListenerFactory$NativeShell_googleProdRelease() {
        return coreListenerFactory;
    }

    public final boolean getDebugForceCallingEnabled() {
        return debugForceCallingEnabled;
    }

    @NotNull
    public final Function0<Boolean> getEngineFlagsLoaded$NativeShell_googleProdRelease() {
        return engineFlagsLoaded;
    }

    @NotNull
    public final pu.n<Context, Long, Function1<? super Bitmap, Unit>, Unit> getFetchAvatar$NativeShell_googleProdRelease() {
        return fetchAvatar;
    }

    @Nullable
    public final Object loadAvatarWithTimeout$NativeShell_googleProdRelease(@NotNull p0 p0Var, @NotNull Function1<? super eu.b<? super Bitmap>, ? extends Object> function1, @NotNull eu.b<? super Bitmap> bVar) {
        w0 b10;
        b10 = k.b(p0Var, null, null, new e(function1, null), 3, null);
        return g3.e(AVATAR_TIMEOUT_MS, new d(b10, null), bVar);
    }

    public final void onAvatarLoaded$NativeShell_googleProdRelease(@NotNull String callId, @Nullable final Bitmap avatar) {
        Intrinsics.checkNotNullParameter(callId, "callId");
        if (ul.d.n(ul.d.f33493a, callId, null, new Function1() { // from class: ul.l
            @Override // kotlin.jvm.functions.Function1
            public final Object invoke(Object obj) {
                ActiveCall onAvatarLoaded$lambda$0;
                onAvatarLoaded$lambda$0 = CallingHandler.onAvatarLoaded$lambda$0(avatar, (ActiveCall) obj);
                return onAvatarLoaded$lambda$0;
            }
        }, 2, null) == null) {
            return;
        }
        alertIfReady(callId);
    }

    @Override // com.roblox.protocols.callingplatforminterface.generated.IPlatformCalling
    public void onCallingRemoved(@NotNull final String callId) {
        Intrinsics.checkNotNullParameter(callId, "callId");
        onMainThread(new Function0() { // from class: ul.x
            @Override // kotlin.jvm.functions.Function0
            public final Object invoke() {
                Unit onCallingRemoved$lambda$0;
                onCallingRemoved$lambda$0 = CallingHandler.onCallingRemoved$lambda$0(callId);
                return onCallingRemoved$lambda$0;
            }
        });
    }

    @Override // com.roblox.protocols.callingplatforminterface.generated.IPlatformCalling
    public void onCallingStateChange(@NotNull final CallingState state) {
        Intrinsics.checkNotNullParameter(state, "state");
        onMainThread(new Function0() { // from class: ul.t
            @Override // kotlin.jvm.functions.Function0
            public final Object invoke() {
                Unit onCallingStateChange$lambda$0;
                onCallingStateChange$lambda$0 = CallingHandler.onCallingStateChange$lambda$0(CallingState.this);
                return onCallingStateChange$lambda$0;
            }
        });
    }

    public final void resetForTest$NativeShell_googleProdRelease() {
        appContext = null;
        coreListener = null;
        h2.f(getMainScope().getCoroutineContext(), null, 1, null);
        surfaces = null;
        ul.d.f33493a.c();
        ul.i.f33539a.i();
        debugForceCallingEnabled = true;
    }

    public final void setCoreListenerFactory$NativeShell_googleProdRelease(@NotNull Function1<? super IPlatformCalling, ? extends ICallingCoreListener> function1) {
        Intrinsics.checkNotNullParameter(function1, "<set-?>");
        coreListenerFactory = function1;
    }

    public final void setDebugForceCallingEnabled(boolean z10) {
        debugForceCallingEnabled = z10;
    }

    public final void setEngineFlagsLoaded$NativeShell_googleProdRelease(@NotNull Function0<Boolean> function0) {
        Intrinsics.checkNotNullParameter(function0, "<set-?>");
        engineFlagsLoaded = function0;
    }

    public final void setFetchAvatar$NativeShell_googleProdRelease(@NotNull pu.n<? super Context, ? super Long, ? super Function1<? super Bitmap, Unit>, Unit> nVar) {
        Intrinsics.checkNotNullParameter(nVar, "<set-?>");
        fetchAvatar = nVar;
    }


    // --- восстановлено из DEX (com/roblox/protocols/calling/CallingHandler$b$a) ---
    public static class a extends gu.m implements kotlin.jvm.functions.Function1 {
        int t;
        android.content.Context u;
        long v;
        public a(android.content.Context p0, long p1, eu.b p2) { }
        public eu.b create(eu.b p0) { throw new UnsupportedOperationException("stub"); }
        public java.lang.Object invoke(java.lang.Object p0) { throw new UnsupportedOperationException("stub"); }
        public java.lang.Object invokeSuspend(java.lang.Object p0) { throw new UnsupportedOperationException("stub"); }
        public java.lang.Object m(eu.b p0) { throw new UnsupportedOperationException("stub"); }
    }

    // --- восстановлено из DEX (com/roblox/protocols/calling/CallingHandler$c$a) ---
    public static class a implements dv.i {
        android.content.Context a;
        public a(android.content.Context p0) { }
        public java.lang.Object b(ul.a p0, eu.b p1) { throw new UnsupportedOperationException("stub"); }
        public java.lang.Object emit(java.lang.Object p0, eu.b p1) { throw new UnsupportedOperationException("stub"); }
    }
}
