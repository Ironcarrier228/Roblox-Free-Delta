package com.roblox.protocols.mediapicker;

import android.app.Activity;
import android.database.Cursor;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.provider.DocumentsContract;
import android.provider.MediaStore;
import android.util.Log;
import com.github.luben.zstd.BuildConfig;

import com.roblox.universalapp.messagebus.MessageBus;
import com.roblox.universalapp.messagebus.RequestHandler;
import com.roblox.universalapp.messagebus.RequestHandlerAsync;
import com.roblox.universalapp.messagebus.Response;
import com.roblox.universalapp.messagebus.ResponseCallback;
import e.p;
import g.j;
import h.f;
import java.lang.ref.WeakReference;
import java.util.HashMap;
import org.json.JSONException;
import org.json.JSONObject;

/* loaded from: classes2.dex */
public class MediaPickerProtocol {

    /* renamed from: f, reason: collision with root package name */
    public static final HashMap<String, f.h> f9720f = new a();

    /* renamed from: a, reason: collision with root package name */
    public ResponseCallback f9721a;
    public String b;

    /* renamed from: c, reason: collision with root package name */
    public WeakReference<Activity> f9722c;

    /* renamed from: d, reason: collision with root package name */
    public g.d<j> f9723d;

    /* renamed from: e, reason: collision with root package name */
    public zl.f f9724e;

    public class a extends HashMap<String, f.h> {
        public a() {
            put(MediaPickerProtocol.getAssetTypeImages(), f.d.f17999a);
            put(MediaPickerProtocol.getAssetTypeVideos(), f.g.f18000a);
        }
    }

    public class b implements RequestHandler {
        public b() {
        }

        @Override // com.roblox.universalapp.messagebus.RequestHandler
        public Response run(JSONObject jSONObject) {
            Response response = new Response();
            JSONObject jSONObject2 = new JSONObject();
            try {
                jSONObject2.put(MediaPickerProtocol.getAvailableParamName(), true);
                response.params = jSONObject2;
                return response;
            } catch (JSONException e10) {
                Log.e("MediaPickerProtocol", "Indicating available on Android failed with error: " + e10.getMessage());
                return null;
            }
        }
    }

    public static class c {

        /* renamed from: a, reason: collision with root package name */
        public static final MediaPickerProtocol f9726a = new MediaPickerProtocol();
    }

    public class d implements RequestHandlerAsync {
        public d() {
        }

        @Override // com.roblox.universalapp.messagebus.RequestHandlerAsync
        public void run(JSONObject jSONObject, ResponseCallback responseCallback) {
            MediaPickerProtocol.this.f9721a = responseCallback;
            if (MediaPickerProtocol.this.f9722c == null || MediaPickerProtocol.this.f9722c.get() == null) {
                Log.e("MediaPickerProtocol", "No Activity found while checking permissions");
                return;
            }
            try {
                MediaPickerProtocol.this.b = jSONObject.getString(MediaPickerProtocol.getAssetTypeParamName());
                if (!f.c()) {
                    MediaPickerProtocol.this.f9724e.a();
                } else {
                    Log.i("MediaPickerProtocol", "Permissions already granted for photo album");
                    MediaPickerProtocol.this.n();
                }
            } catch (JSONException unused) {
                Log.e("MediaPickerProtocol", "Error parsing asset type.");
            }
        }
    }

    public MediaPickerProtocol() {
        MessageBus.getInstance().setRequestHandler(getProtocolName(), getPickMediaId(), new d());
        MessageBus.getInstance().setRequestHandler(getProtocolName(), getIsAvailableId(), new b());
    }

    private static native String getAssetFilePathParamName();

    public static native String getAssetTypeImages();

    /* JADX INFO: Access modifiers changed from: private */
    public static native String getAssetTypeParamName();

    public static native String getAssetTypeVideos();

    /* JADX INFO: Access modifiers changed from: private */
    public static native String getAvailableParamName();

    private static native String getErrorParamName();

    private static native String getIsAvailableId();

    private static native String getPermissionsParamName();

    private static native String getPickMediaId();

    private static native String getProtocolName();

    public static native String getSourceTypeCamera();

    public static native void initializeMediaPickerProtocol();

    public static synchronized MediaPickerProtocol o() {
        MediaPickerProtocol mediaPickerProtocol;
        synchronized (MediaPickerProtocol.class) {
            mediaPickerProtocol = c.f9726a;
        }
        return mediaPickerProtocol;
    }

    public static native void onMediaPickerResponse(long j10, byte[] bArr, String str);

    public final String i(Uri uri) {
        Cursor query;
        int columnIndex;
        WeakReference<Activity> weakReference = this.f9722c;
        String str = null;
        if (weakReference == null || weakReference.get() == null) {
            Log.e("MediaPickerProtocol", "No Activity found while checking permissions");
            return null;
        }
        Activity activity = this.f9722c.get();
        if (f.c()) {
            query = activity.getContentResolver().query(uri, null, null, null, null);
        } else {
            String[] split = DocumentsContract.getDocumentId(uri).split(":");
            String str2 = split[0];
            String str3 = split[1];
            query = "image".equals(str2) ? activity.getContentResolver().query(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, null, "_id=?", new String[]{str3}, null) : "video".equals(str2) ? activity.getContentResolver().query(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, null, "_id=?", new String[]{str3}, null) : null;
        }
        if (query == null) {
            Log.e("MediaPickerProtocol", "Picked URI is invalid");
            return null;
        }
        if (query.moveToFirst() && (columnIndex = query.getColumnIndex("_data")) != -1) {
            str = query.getString(columnIndex);
        }
        query.close();
        return str;
    }

    public void j(Uri uri) {
        if (uri == null) {
            Log.d("MediaPickerProtocol", "No media selected");
            Response response = new Response();
            response.telemetryResponseCode = 1;
            try {
                response.params.put(getAssetTypeParamName(), this.b);
                response.params.put(getAssetFilePathParamName(), BuildConfig.FLAVOR);
                response.params.put(getErrorParamName(), BuildConfig.FLAVOR);
                response.params.put(getPermissionsParamName(), true);
            } catch (JSONException unused) {
                Log.e("MediaPickerProtocol", "Exception while writing response for pick media request");
            }
            this.f9721a.run(response);
            return;
        }
        String i10 = i(uri);
        Log.d("MediaPickerProtocol", "Selected file path: " + i10);
        Response response2 = new Response();
        try {
            response2.params.put(getAssetTypeParamName(), this.b);
            response2.params.put(getAssetFilePathParamName(), i10);
            response2.params.put(getErrorParamName(), BuildConfig.FLAVOR);
            response2.params.put(getPermissionsParamName(), true);
        } catch (JSONException unused2) {
            Log.e("MediaPickerProtocol", "Exception while handling pick media request");
        }
        this.f9721a.run(response2);
    }

    public final /* synthetic */ void k(f.h hVar) {
        this.f9723d.b(new j.a().d(hVar).a());
    }

    public void l(p pVar) {
        this.f9722c = new WeakReference<>(pVar);
        this.f9723d = pVar.h(new f(), new g.b() { // from class: zl.a
            @Override // g.b
            public final void a(Object obj) {
                MediaPickerProtocol.this.j((Uri) obj);
            }
        });
    }

    public void m(p pVar, zl.f fVar) {
        this.f9722c = new WeakReference<>(pVar);
        this.f9724e = fVar;
        initializeMediaPickerProtocol();
    }

    public final void n() {
        final f.h hVar = f9720f.get(this.b);
        if (hVar == null) {
            Log.e("MediaPickerProtocol", "Media Type must be either IMAGES or VIDEOS");
        } else {
            new Handler(Looper.getMainLooper()).post(new Runnable() { // from class: zl.b
                @Override // java.lang.Runnable
                public final void run() {
                    MediaPickerProtocol.this.k(hVar);
                }
            });
        }
    }
}
