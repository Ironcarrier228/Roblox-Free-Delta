package com.android.billingclient.api;

import android.text.TextUtils;
import androidx.annotation.NonNull;
import com.appsflyer.sdk_base.referrer.Payload;
import com.withpersona.sdk2.inquiry.network.dto.ui.components.Title;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import org.json.JSONArray;
import org.json.JSONObject;

/* loaded from: classes.dex */
public final class e {

    /* renamed from: a, reason: collision with root package name */
    public final String f5632a;
    public final JSONObject b;

    /* renamed from: c, reason: collision with root package name */
    public final String f5633c;

    /* renamed from: d, reason: collision with root package name */
    public final String f5634d;

    /* renamed from: e, reason: collision with root package name */
    public final String f5635e;

    /* renamed from: f, reason: collision with root package name */
    public final String f5636f;

    /* renamed from: g, reason: collision with root package name */
    public final String f5637g;

    /* renamed from: h, reason: collision with root package name */
    public final String f5638h;

    /* renamed from: i, reason: collision with root package name */
    public final String f5639i;

    /* renamed from: j, reason: collision with root package name */
    public final List f5640j;

    /* renamed from: k, reason: collision with root package name */
    public final List f5641k;

    public static final class a {

        /* renamed from: a, reason: collision with root package name */
        public final int f5642a;
        public final int b;

        public a(JSONObject jSONObject) {
            this.f5642a = jSONObject.getInt("commitmentPaymentsCount");
            this.b = jSONObject.optInt("subsequentCommitmentPaymentsCount");
        }
    }

    public static final class b {

        /* renamed from: a, reason: collision with root package name */
        public final String f5643a;
        public final long b;

        /* renamed from: c, reason: collision with root package name */
        public final String f5644c;

        /* renamed from: d, reason: collision with root package name */
        public final String f5645d;

        /* renamed from: e, reason: collision with root package name */
        public final String f5646e;

        /* renamed from: f, reason: collision with root package name */
        public final String f5647f;

        /* renamed from: g, reason: collision with root package name */
        public final List f5648g;

        /* renamed from: h, reason: collision with root package name */
        public final Long f5649h;

        /* renamed from: i, reason: collision with root package name */
        public final a f5650i;

        /* renamed from: j, reason: collision with root package name */
        public final C0117e f5651j;

        /* renamed from: k, reason: collision with root package name */
        public final C0116b f5652k;

        /* renamed from: l, reason: collision with root package name */
        public final String f5653l;

        /* renamed from: m, reason: collision with root package name */
        public final c f5654m;

        /* renamed from: n, reason: collision with root package name */
        public final d f5655n;

        /* renamed from: o, reason: collision with root package name */
        public final i f5656o;

        public static final class a {

            /* renamed from: a, reason: collision with root package name */
            public final Integer f5657a;
            public final C0115a b;

            /* renamed from: com.android.billingclient.api.e$b$a$a, reason: collision with other inner class name */
            public static final class C0115a {

                /* renamed from: a, reason: collision with root package name */
                public final String f5658a;
                public final long b;

                /* renamed from: c, reason: collision with root package name */
                public final String f5659c;

                public C0115a(JSONObject jSONObject) {
                    this.f5658a = jSONObject.optString("formattedDiscountAmount");
                    this.b = jSONObject.optLong("discountAmountMicros");
                    this.f5659c = jSONObject.optString("discountAmountCurrencyCode");
                }
            }

            public a(JSONObject jSONObject) {
                this.f5657a = jSONObject.has("percentageDiscount") ? Integer.valueOf(jSONObject.optInt("percentageDiscount")) : null;
                JSONObject optJSONObject = jSONObject.optJSONObject("discountAmount");
                this.b = optJSONObject != null ? new C0115a(optJSONObject) : null;
            }
        }

        /* renamed from: com.android.billingclient.api.e$b$b, reason: collision with other inner class name */
        public static final class C0116b {

            /* renamed from: a, reason: collision with root package name */
            public final int f5660a;
            public final int b;

            public C0116b(JSONObject jSONObject) {
                this.f5660a = jSONObject.getInt("maximumQuantity");
                this.b = jSONObject.getInt("remainingQuantity");
            }
        }

        public static final class c {

            /* renamed from: a, reason: collision with root package name */
            public final long f5661a;
            public final long b;

            public c(JSONObject jSONObject) {
                this.f5661a = jSONObject.getLong("preorderReleaseTimeMillis");
                this.b = jSONObject.getLong("preorderPresaleEndTimeMillis");
            }
        }

        public static final class d {

            /* renamed from: a, reason: collision with root package name */
            public final String f5662a;
            public final String b;

            public d(JSONObject jSONObject) {
                this.f5662a = jSONObject.getString("rentalPeriod");
                String optString = jSONObject.optString("rentalExpirationPeriod");
                this.b = true == optString.isEmpty() ? null : optString;
            }
        }

        /* renamed from: com.android.billingclient.api.e$b$e, reason: collision with other inner class name */
        public static final class C0117e {

            /* renamed from: a, reason: collision with root package name */
            public final Long f5663a;
            public final Long b;

            public C0117e(JSONObject jSONObject) {
                this.f5663a = jSONObject.has("startTimeMillis") ? Long.valueOf(jSONObject.optLong("startTimeMillis")) : null;
                this.b = jSONObject.has("endTimeMillis") ? Long.valueOf(jSONObject.optLong("endTimeMillis")) : null;
            }
        }

        public b(JSONObject jSONObject) {
            this.f5643a = jSONObject.optString("formattedPrice");
            this.b = jSONObject.optLong("priceAmountMicros");
            this.f5644c = jSONObject.optString("priceCurrencyCode");
            String optString = jSONObject.optString("offerIdToken");
            this.f5645d = true == optString.isEmpty() ? null : optString;
            String optString2 = jSONObject.optString("offerId");
            this.f5646e = true == optString2.isEmpty() ? null : optString2;
            String optString3 = jSONObject.optString("purchaseOptionId");
            this.f5647f = true == optString3.isEmpty() ? null : optString3;
            jSONObject.optInt("offerType");
            JSONArray optJSONArray = jSONObject.optJSONArray("offerTags");
            this.f5648g = new ArrayList();
            if (optJSONArray != null) {
                for (int i10 = 0; i10 < optJSONArray.length(); i10++) {
                    this.f5648g.add(optJSONArray.getString(i10));
                }
            }
            this.f5649h = jSONObject.has("fullPriceMicros") ? Long.valueOf(jSONObject.optLong("fullPriceMicros")) : null;
            JSONObject optJSONObject = jSONObject.optJSONObject("discountDisplayInfo");
            this.f5650i = optJSONObject == null ? null : new a(optJSONObject);
            JSONObject optJSONObject2 = jSONObject.optJSONObject("validTimeWindow");
            this.f5651j = optJSONObject2 == null ? null : new C0117e(optJSONObject2);
            JSONObject optJSONObject3 = jSONObject.optJSONObject("limitedQuantityInfo");
            this.f5652k = optJSONObject3 == null ? null : new C0116b(optJSONObject3);
            this.f5653l = jSONObject.optString("serializedDocid");
            JSONObject optJSONObject4 = jSONObject.optJSONObject("preorderDetails");
            this.f5654m = optJSONObject4 == null ? null : new c(optJSONObject4);
            JSONObject optJSONObject5 = jSONObject.optJSONObject("rentalDetails");
            this.f5655n = optJSONObject5 == null ? null : new d(optJSONObject5);
            JSONObject optJSONObject6 = jSONObject.optJSONObject("autoPayDetails");
            this.f5656o = optJSONObject6 != null ? new i(optJSONObject6) : null;
            JSONArray optJSONArray2 = jSONObject.optJSONArray("pricingPhases");
            if (optJSONArray2 == null) {
                return;
            }
            new d(optJSONArray2);
        }

        @NonNull
        public String a() {
            return this.f5643a;
        }

        public String b() {
            return this.f5645d;
        }

        public long c() {
            return this.b;
        }

        @NonNull
        public String d() {
            return this.f5644c;
        }

        public final i e() {
            return this.f5656o;
        }

        public final String f() {
            return this.f5653l;
        }
    }

    public static final class c {

        /* renamed from: a, reason: collision with root package name */
        public final String f5664a;
        public final long b;

        /* renamed from: c, reason: collision with root package name */
        public final String f5665c;

        /* renamed from: d, reason: collision with root package name */
        public final String f5666d;

        /* renamed from: e, reason: collision with root package name */
        public final int f5667e;

        /* renamed from: f, reason: collision with root package name */
        public final int f5668f;

        public c(JSONObject jSONObject) {
            this.f5666d = jSONObject.optString("billingPeriod");
            this.f5665c = jSONObject.optString("priceCurrencyCode");
            this.f5664a = jSONObject.optString("formattedPrice");
            this.b = jSONObject.optLong("priceAmountMicros");
            this.f5668f = jSONObject.optInt("recurrenceMode");
            this.f5667e = jSONObject.optInt("billingCycleCount");
        }

        @NonNull
        public String a() {
            return this.f5664a;
        }

        public long b() {
            return this.b;
        }

        @NonNull
        public String c() {
            return this.f5665c;
        }
    }

    public static class d {

        /* renamed from: a, reason: collision with root package name */
        public final List f5669a;

        public d(JSONArray jSONArray) {
            ArrayList arrayList = new ArrayList();
            if (jSONArray != null) {
                for (int i10 = 0; i10 < jSONArray.length(); i10++) {
                    JSONObject optJSONObject = jSONArray.optJSONObject(i10);
                    if (optJSONObject != null) {
                        arrayList.add(new c(optJSONObject));
                    }
                }
            }
            this.f5669a = arrayList;
        }

        @NonNull
        public List<c> a() {
            return this.f5669a;
        }
    }

    /* renamed from: com.android.billingclient.api.e$e, reason: collision with other inner class name */
    public static final class C0118e {

        /* renamed from: a, reason: collision with root package name */
        public final String f5670a;
        public final String b;

        /* renamed from: c, reason: collision with root package name */
        public final String f5671c;

        /* renamed from: d, reason: collision with root package name */
        public final d f5672d;

        /* renamed from: e, reason: collision with root package name */
        public final List f5673e;

        /* renamed from: f, reason: collision with root package name */
        public final a f5674f;

        public C0118e(JSONObject jSONObject) {
            this.f5670a = jSONObject.optString("basePlanId");
            String optString = jSONObject.optString("offerId");
            this.b = true == optString.isEmpty() ? null : optString;
            this.f5671c = jSONObject.getString("offerIdToken");
            this.f5672d = new d(jSONObject.getJSONArray("pricingPhases"));
            JSONObject optJSONObject = jSONObject.optJSONObject("installmentPlanDetails");
            this.f5674f = optJSONObject != null ? new a(optJSONObject) : null;
            JSONObject optJSONObject2 = jSONObject.optJSONObject("transitionPlanDetails");
            if (optJSONObject2 != null) {
                optJSONObject2.getString("productId");
                optJSONObject2.optString(Title.type);
                optJSONObject2.optString("name");
                optJSONObject2.optString("description");
                optJSONObject2.optString("basePlanId");
                JSONObject optJSONObject3 = optJSONObject2.optJSONObject("pricingPhase");
                if (optJSONObject3 != null) {
                    new c(optJSONObject3);
                }
            }
            ArrayList arrayList = new ArrayList();
            JSONArray optJSONArray = jSONObject.optJSONArray("offerTags");
            if (optJSONArray != null) {
                for (int i10 = 0; i10 < optJSONArray.length(); i10++) {
                    arrayList.add(optJSONArray.getString(i10));
                }
            }
            this.f5673e = arrayList;
        }

        public String a() {
            return this.b;
        }

        @NonNull
        public String b() {
            return this.f5671c;
        }

        @NonNull
        public d c() {
            return this.f5672d;
        }
    }

    public e(String str) {
        this.f5632a = str;
        JSONObject jSONObject = new JSONObject(str);
        this.b = jSONObject;
        String optString = jSONObject.optString("productId");
        this.f5633c = optString;
        String optString2 = jSONObject.optString(Payload.TYPE);
        this.f5634d = optString2;
        if (TextUtils.isEmpty(optString)) {
            throw new IllegalArgumentException("Product id cannot be empty.");
        }
        if (TextUtils.isEmpty(optString2)) {
            throw new IllegalArgumentException("Product type cannot be empty.");
        }
        this.f5635e = jSONObject.optString(Title.type);
        this.f5636f = jSONObject.optString("name");
        this.f5637g = jSONObject.optString("description");
        jSONObject.optString("packageDisplayName");
        jSONObject.optString("iconUrl");
        this.f5638h = jSONObject.optString("skuDetailsToken");
        this.f5639i = jSONObject.optString("serializedDocid");
        JSONArray optJSONArray = jSONObject.optJSONArray("subscriptionOfferDetails");
        if (optJSONArray != null) {
            ArrayList arrayList = new ArrayList();
            for (int i10 = 0; i10 < optJSONArray.length(); i10++) {
                arrayList.add(new C0118e(optJSONArray.getJSONObject(i10)));
            }
            this.f5640j = arrayList;
        } else {
            this.f5640j = (optString2.equals("subs") || optString2.equals("play_pass_subs")) ? new ArrayList() : null;
        }
        JSONObject optJSONObject = this.b.optJSONObject("oneTimePurchaseOfferDetails");
        JSONArray optJSONArray2 = this.b.optJSONArray("oneTimePurchaseOfferDetailsList");
        ArrayList arrayList2 = new ArrayList();
        if (optJSONArray2 != null) {
            for (int i11 = 0; i11 < optJSONArray2.length(); i11++) {
                arrayList2.add(new b(optJSONArray2.getJSONObject(i11)));
            }
            this.f5641k = arrayList2;
            return;
        }
        if (optJSONObject == null) {
            this.f5641k = null;
        } else {
            arrayList2.add(new b(optJSONObject));
            this.f5641k = arrayList2;
        }
    }

    @NonNull
    public String a() {
        return this.f5637g;
    }

    public b b() {
        List list = this.f5641k;
        if (list == null || list.isEmpty()) {
            return null;
        }
        return (b) list.get(0);
    }

    public List<b> c() {
        return this.f5641k;
    }

    @NonNull
    public String d() {
        return this.f5633c;
    }

    @NonNull
    public String e() {
        return this.f5634d;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj instanceof e) {
            return TextUtils.equals(this.f5632a, ((e) obj).f5632a);
        }
        return false;
    }

    public List<C0118e> f() {
        return this.f5640j;
    }

    @NonNull
    public final String g() {
        return this.b.optString("packageName");
    }

    public final String h() {
        return this.f5638h;
    }

    public int hashCode() {
        return this.f5632a.hashCode();
    }

    public final String i(String str) {
        List<b> list;
        if (!TextUtils.isEmpty(str) && (list = this.f5641k) != null && !list.isEmpty()) {
            for (b bVar : list) {
                if (!TextUtils.isEmpty(bVar.f()) && Objects.equals(bVar.b(), str)) {
                    return bVar.f();
                }
            }
        }
        return this.f5639i;
    }

    @NonNull
    public String toString() {
        List list = this.f5640j;
        return "ProductDetails{jsonString='" + this.f5632a + "', parsedJson=" + this.b.toString() + ", productId='" + this.f5633c + "', productType='" + this.f5634d + "', title='" + this.f5635e + "', productDetailsToken='" + this.f5638h + "', subscriptionOfferDetails=" + String.valueOf(list) + "}";
    }


    // --- восстановлено из DEX (com/android/billingclient/api/e$b$a) ---
    public static class a {
        java.lang.Integer a;
        com.android.billingclient.api.e.b.a.a b;
        public a(org.json.JSONObject p0) { }
    }

    // --- восстановлено из DEX (com/android/billingclient/api/e$b$a$a) ---
    public static class a {
        java.lang.String a;
        long b;
        java.lang.String c;
        public a(org.json.JSONObject p0) { }
    }

    // --- восстановлено из DEX (com/android/billingclient/api/e$b$b) ---
    public static class b {
        int a;
        int b;
        public b(org.json.JSONObject p0) { }
    }

    // --- восстановлено из DEX (com/android/billingclient/api/e$b$c) ---
    public static class c {
        long a;
        long b;
        public c(org.json.JSONObject p0) { }
    }

    // --- восстановлено из DEX (com/android/billingclient/api/e$b$d) ---
    public static class d {
        java.lang.String a;
        java.lang.String b;
        public d(org.json.JSONObject p0) { }
    }

    // --- восстановлено из DEX (com/android/billingclient/api/e$b$e) ---
    public static class e {
        java.lang.Long a;
        java.lang.Long b;
        public e(org.json.JSONObject p0) { }
    }
}
