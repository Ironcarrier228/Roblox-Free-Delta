package com.android.billingclient.api;

import android.app.PendingIntent;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.os.ResultReceiver;
import androidx.annotation.NonNull;

import com.google.android.apps.common.proguard.UsedByReflection;
import com.google.android.gms.internal.play_billing.m0;
import com.google.android.gms.internal.play_billing.s7;
import e.p;
import g.i;

@UsedByReflection("PlatformActivityProxy")
/* loaded from: classes.dex */
public class ProxyBillingActivityV2 extends p {
    public g.d A;
    public g.d B;
    public g.d C;
    public ResultReceiver D;
    public ResultReceiver E;
    public ResultReceiver F;
    public ResultReceiver G;
    public ResultReceiver H;
    public ResultReceiver I;

    /* renamed from: x, reason: collision with root package name */
    public g.d f5574x;

    /* renamed from: y, reason: collision with root package name */
    public g.d f5575y;

    /* renamed from: z, reason: collision with root package name */
    public g.d f5576z;

    public static final k2.c m1() {
        int i10 = Build.VERSION.SDK_INT;
        if (i10 >= 36) {
            return k2.c.a().b(3);
        }
        if (i10 >= 34) {
            return k2.c.a().b(1);
        }
        return null;
    }

    public final void g1(g.a aVar) {
        Intent data = aVar.getData();
        int c10 = m0.h(data, "ProxyBillingActivityV2").c();
        ResultReceiver resultReceiver = this.D;
        if (resultReceiver != null) {
            resultReceiver.send(c10, data == null ? null : data.getExtras());
        }
        if (aVar.getResultCode() != -1 || c10 != 0) {
            m0.m("ProxyBillingActivityV2", "Alternative billing only dialog finished with resultCode " + aVar.getResultCode() + " and billing's responseCode: " + c10);
        }
        finish();
    }

    public final void h1(g.a aVar) {
        Intent data = aVar.getData();
        int c10 = m0.h(data, "ProxyBillingActivityV2").c();
        ResultReceiver resultReceiver = this.H;
        if (resultReceiver != null) {
            resultReceiver.send(c10, data == null ? null : data.getExtras());
        }
        if (aVar.getResultCode() != -1 || c10 != 0) {
            m0.m("ProxyBillingActivityV2", "Billing program info dialog finished with resultCode " + aVar.getResultCode() + " and billing's responseCode: " + c10);
        }
        finish();
    }

    public final void i1(g.a aVar) {
        Intent data = aVar.getData();
        int c10 = m0.h(data, "ProxyBillingActivityV2").c();
        ResultReceiver resultReceiver = this.E;
        if (resultReceiver != null) {
            resultReceiver.send(c10, data == null ? null : data.getExtras());
        }
        if (aVar.getResultCode() != -1 || c10 != 0) {
            m0.m("ProxyBillingActivityV2", String.format("External offer dialog finished with resultCode: %s and billing's responseCode: %s", Integer.valueOf(aVar.getResultCode()), Integer.valueOf(c10)));
        }
        finish();
    }

    public final void j1(g.a aVar) {
        Intent data = aVar.getData();
        Bundle extras = data == null ? null : data.getExtras();
        if (aVar.getResultCode() != -1) {
            if (extras == null) {
                extras = new Bundle();
            }
            m0.m("ProxyBillingActivityV2", String.format("External offer flow finished with resultCode: %s", Integer.valueOf(aVar.getResultCode())));
            extras.putInt("INTERNAL_LOG_ERROR_REASON", s7.ERROR_IN_ACTIVITY_RESULT.zza());
            extras.putString("INTERNAL_LOG_ERROR_ADDITIONAL_DETAILS", String.format("External offer flow finished with error resultCode: %s", Integer.valueOf(aVar.getResultCode())));
        }
        int c10 = m0.h(data, "ProxyBillingActivityV2").c();
        ResultReceiver resultReceiver = this.F;
        if (resultReceiver != null) {
            resultReceiver.send(c10, extras);
        } else {
            m0.m("ProxyBillingActivityV2", "External offer flow result receiver is null");
        }
        if (c10 != 0) {
            m0.m("ProxyBillingActivityV2", String.format("External offer flow finished with billing responseCode: %s", Integer.valueOf(c10)));
        }
        finish();
    }

    public final void k1(g.a aVar) {
        Intent data = aVar.getData();
        Bundle extras = data == null ? null : data.getExtras();
        if (aVar.getResultCode() != -1) {
            if (extras == null) {
                extras = new Bundle();
            }
            m0.m("ProxyBillingActivityV2", String.format("Launch external link flow finished with resultCode: %s", Integer.valueOf(aVar.getResultCode())));
            extras.putInt("INTERNAL_LOG_ERROR_REASON", s7.ERROR_IN_ACTIVITY_RESULT.zza());
            extras.putString("INTERNAL_LOG_ERROR_ADDITIONAL_DETAILS", String.format("Launch external link flow finished with error resultCode: %s", Integer.valueOf(aVar.getResultCode())));
        }
        int c10 = m0.h(data, "ProxyBillingActivityV2").c();
        ResultReceiver resultReceiver = this.G;
        if (resultReceiver != null) {
            resultReceiver.send(c10, extras);
        } else {
            m0.m("ProxyBillingActivityV2", "Launch external link flow result receiver is null");
        }
        if (c10 != 0) {
            m0.m("ProxyBillingActivityV2", String.format("Launch external link flow finished with billing responseCode: %s", Integer.valueOf(c10)));
        }
        finish();
    }

    public final void l1(g.a aVar) {
        Intent data = aVar.getData();
        int c10 = m0.h(data, "ProxyBillingActivityV2").c();
        ResultReceiver resultReceiver = this.I;
        if (resultReceiver != null) {
            resultReceiver.send(c10, data == null ? null : data.getExtras());
        }
        if (aVar.getResultCode() != -1 || c10 != 0) {
            m0.m("ProxyBillingActivityV2", String.format("Subscription management action finished with resultCode: %s and billing's responseCode: %s", Integer.valueOf(aVar.getResultCode()), Integer.valueOf(c10)));
        }
        finish();
    }

    @Override // e.p, k2.g, android.app.Activity
    public final void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.f5574x = h(new h.j(), new g.b() { // from class: w7.r1
            @Override // g.b
            public final void a(Object obj) {
                ProxyBillingActivityV2.this.g1((g.a) obj);
            }
        });
        this.f5575y = h(new h.j(), new g.b() { // from class: w7.s1
            @Override // g.b
            public final void a(Object obj) {
                ProxyBillingActivityV2.this.i1((g.a) obj);
            }
        });
        this.f5576z = h(new h.j(), new g.b() { // from class: w7.t1
            @Override // g.b
            public final void a(Object obj) {
                ProxyBillingActivityV2.this.j1((g.a) obj);
            }
        });
        this.A = h(new h.j(), new g.b() { // from class: w7.u1
            @Override // g.b
            public final void a(Object obj) {
                ProxyBillingActivityV2.this.k1((g.a) obj);
            }
        });
        this.B = h(new h.j(), new g.b() { // from class: w7.v1
            @Override // g.b
            public final void a(Object obj) {
                ProxyBillingActivityV2.this.h1((g.a) obj);
            }
        });
        this.C = h(new h.j(), new g.b() { // from class: w7.w1
            @Override // g.b
            public final void a(Object obj) {
                ProxyBillingActivityV2.this.l1((g.a) obj);
            }
        });
        if (bundle != null) {
            if (bundle.containsKey("alternative_billing_only_dialog_result_receiver")) {
                this.D = (ResultReceiver) bundle.getParcelable("alternative_billing_only_dialog_result_receiver");
            }
            if (bundle.containsKey("external_payment_dialog_result_receiver")) {
                this.E = (ResultReceiver) bundle.getParcelable("external_payment_dialog_result_receiver");
            }
            if (bundle.containsKey("external_offer_flow_result_receiver")) {
                this.F = (ResultReceiver) bundle.getParcelable("external_offer_flow_result_receiver");
            }
            if (bundle.containsKey("launch_external_link_result_receiver")) {
                this.G = (ResultReceiver) bundle.getParcelable("launch_external_link_result_receiver");
            }
            if (bundle.containsKey("billing_program_information_dialog_result_receiver")) {
                this.H = (ResultReceiver) bundle.getParcelable("billing_program_information_dialog_result_receiver");
            }
            if (bundle.containsKey("subscription_management_action_result_receiver")) {
                this.I = (ResultReceiver) bundle.getParcelable("subscription_management_action_result_receiver");
                return;
            }
            return;
        }
        m0.l("ProxyBillingActivityV2", "Launching Play Store billing dialog");
        if (getIntent().hasExtra("ALTERNATIVE_BILLING_ONLY_DIALOG_INTENT")) {
            PendingIntent pendingIntent = (PendingIntent) getIntent().getParcelableExtra("ALTERNATIVE_BILLING_ONLY_DIALOG_INTENT");
            this.D = (ResultReceiver) getIntent().getParcelableExtra("alternative_billing_only_dialog_result_receiver");
            this.f5574x.c(new i.a(pendingIntent).a(), m1());
            return;
        }
        if (getIntent().hasExtra("external_payment_dialog_pending_intent")) {
            PendingIntent pendingIntent2 = (PendingIntent) getIntent().getParcelableExtra("external_payment_dialog_pending_intent");
            this.E = (ResultReceiver) getIntent().getParcelableExtra("external_payment_dialog_result_receiver");
            this.f5575y.c(new i.a(pendingIntent2).a(), m1());
            return;
        }
        if (getIntent().hasExtra("external_offer_flow_pending_intent")) {
            PendingIntent pendingIntent3 = (PendingIntent) getIntent().getParcelableExtra("external_offer_flow_pending_intent");
            this.F = (ResultReceiver) getIntent().getParcelableExtra("external_offer_flow_result_receiver");
            this.f5576z.c(new i.a(pendingIntent3).a(), m1());
            return;
        }
        if (getIntent().hasExtra("launch_external_link_flow_pending_intent")) {
            PendingIntent pendingIntent4 = (PendingIntent) getIntent().getParcelableExtra("launch_external_link_flow_pending_intent");
            this.G = (ResultReceiver) getIntent().getParcelableExtra("launch_external_link_result_receiver");
            this.A.c(new i.a(pendingIntent4).a(), m1());
        } else if (getIntent().hasExtra("billing_program_information_dialog_pending_intent")) {
            PendingIntent pendingIntent5 = (PendingIntent) getIntent().getParcelableExtra("billing_program_information_dialog_pending_intent");
            this.H = (ResultReceiver) getIntent().getParcelableExtra("billing_program_information_dialog_result_receiver");
            this.B.c(new i.a(pendingIntent5).a(), m1());
        } else if (getIntent().hasExtra("SUBSCRIPTION_MANAGEMENT_INTENT")) {
            PendingIntent pendingIntent6 = (PendingIntent) getIntent().getParcelableExtra("SUBSCRIPTION_MANAGEMENT_INTENT");
            this.I = (ResultReceiver) getIntent().getParcelableExtra("subscription_management_action_result_receiver");
            this.C.c(new i.a(pendingIntent6).a(), m1());
        }
    }

    @Override // e.p, k2.g, android.app.Activity
    public final void onSaveInstanceState(@NonNull Bundle bundle) {
        super.onSaveInstanceState(bundle);
        ResultReceiver resultReceiver = this.D;
        if (resultReceiver != null) {
            bundle.putParcelable("alternative_billing_only_dialog_result_receiver", resultReceiver);
        }
        ResultReceiver resultReceiver2 = this.E;
        if (resultReceiver2 != null) {
            bundle.putParcelable("external_payment_dialog_result_receiver", resultReceiver2);
        }
        ResultReceiver resultReceiver3 = this.F;
        if (resultReceiver3 != null) {
            bundle.putParcelable("external_offer_flow_result_receiver", resultReceiver3);
        }
        ResultReceiver resultReceiver4 = this.G;
        if (resultReceiver4 != null) {
            bundle.putParcelable("launch_external_link_result_receiver", resultReceiver4);
        }
        ResultReceiver resultReceiver5 = this.H;
        if (resultReceiver5 != null) {
            bundle.putParcelable("billing_program_information_dialog_result_receiver", resultReceiver5);
        }
        ResultReceiver resultReceiver6 = this.I;
        if (resultReceiver6 != null) {
            bundle.putParcelable("subscription_management_action_result_receiver", resultReceiver6);
        }
    }
}
