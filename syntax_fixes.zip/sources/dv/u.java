package dv;

import com.github.luben.zstd.BuildConfig;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.functions.Function2;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(d1 = {"\u0000*\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\u0010\u0003\n\u0002\b\b\u001aM\u0010\b\u001a\b\u0012\u0004\u0012\u00028\u00000\u0001\"\u0004\b\u0000\u0010\u0000*\b\u0012\u0004\u0012\u00028\u00000\u00012(\u0010\u0007\u001a$\b\u0001\u0012\n\u0012\b\u0012\u0004\u0012\u00028\u00000\u0003\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00050\u0004\u0012\u0006\u0012\u0004\u0018\u00010\u00060\u0002¢\u0006\u0004\b\b\u0010\t\u001aU\u0010\f\u001a\b\u0012\u0004\u0012\u00028\u00000\u0001\"\u0004\b\u0000\u0010\u0000*\b\u0012\u0004\u0012\u00028\u00000\u000120\u0010\u0007\u001a,\b\u0001\u0012\n\u0012\b\u0012\u0004\u0012\u00028\u00000\u0003\u0012\u0006\u0012\u0004\u0018\u00010\u000b\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00050\u0004\u0012\u0006\u0012\u0004\u0018\u00010\u00060\n¢\u0006\u0004\b\f\u0010\r\u001a\u0017\u0010\u000e\u001a\u00020\u0005*\u0006\u0012\u0002\b\u00030\u0003H\u0000¢\u0006\u0004\b\u000e\u0010\u000f\u001a\\\u0010\u0011\u001a\u00020\u0005\"\u0004\b\u0000\u0010\u0000*\b\u0012\u0004\u0012\u00028\u00000\u000320\u0010\u0007\u001a,\b\u0001\u0012\n\u0012\b\u0012\u0004\u0012\u00028\u00000\u0003\u0012\u0006\u0012\u0004\u0018\u00010\u000b\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00050\u0004\u0012\u0006\u0012\u0004\u0018\u00010\u00060\n2\b\u0010\u0010\u001a\u0004\u0018\u00010\u000bH\u0082@¢\u0006\u0004\b\u0011\u0010\u0012¨\u0006\u0013"}, d2 = {"T", "Ldv/h;", "Lkotlin/Function2;", "Ldv/i;", "Leu/b;", BuildConfig.FLAVOR, BuildConfig.FLAVOR, "action", "e", "(Ldv/h;Lkotlin/jvm/functions/Function2;)Ldv/h;", "Lkotlin/Function3;", BuildConfig.FLAVOR, "d", "(Ldv/h;Lpu/n;)Ldv/h;", k6.b.f21144e, "(Ldv/i;)V", "cause", "c", "(Ldv/i;Lpu/n;Ljava/lang/Throwable;Leu/b;)Ljava/lang/Object;", "kotlinx-coroutines-core"}, k = 5, mv = {2, 1, 0}, xi = 48, xs = "kotlinx/coroutines/flow/FlowKt")
/* loaded from: classes2.dex */
public final /* synthetic */ class u {

    @Metadata(k = 3, mv = {2, 1, 0}, xi = 48)
    @gu.f(c = "kotlinx.coroutines.flow.FlowKt__EmittersKt", f = "Emitters.kt", l = {212}, m = "invokeSafely$FlowKt__EmittersKt")
    public static final class a<T> extends gu.d {

        /* renamed from: t, reason: collision with root package name */
        public Object f12843t;

        /* renamed from: u, reason: collision with root package name */
        public /* synthetic */ Object f12844u;

        /* renamed from: v, reason: collision with root package name */
        public int f12845v;

        public a(eu.b<? super a> bVar) {
            super(bVar);
        }

        @Override // gu.a
        @Nullable
        public final Object invokeSuspend(@NotNull Object obj) {
            this.f12844u = obj;
            this.f12845v |= Integer.MIN_VALUE;
            return u.c(null, null, null, this);
        }
    }

    /* JADX INFO: Add missing generic type declarations: [T] */
    @Metadata(d1 = {"\u0000\u0017\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0003*\u0001\u0000\b\n\u0018\u00002\b\u0012\u0004\u0012\u00028\u00000\u0001J\u001e\u0010\u0005\u001a\u00020\u00042\f\u0010\u0003\u001a\b\u0012\u0004\u0012\u00028\u00000\u0002H\u0096@¢\u0006\u0004\b\u0005\u0010\u0006¨\u0006\u0007"}, d2 = {"dv/u$b", "Ldv/h;", "Ldv/i;", "collector", BuildConfig.FLAVOR, "collect", "(Ldv/i;Leu/b;)Ljava/lang/Object;", "kotlinx-coroutines-core"}, k = 1, mv = {2, 1, 0}, xi = 48)
    public static final class b<T> implements h<T> {

        /* renamed from: a, reason: collision with root package name */
        public final /* synthetic */ h f12846a;
        public final /* synthetic */ pu.n b;

        @Metadata(k = 3, mv = {2, 1, 0}, xi = 48)
        @gu.f(c = "kotlinx.coroutines.flow.FlowKt__EmittersKt$onCompletion$$inlined$unsafeFlow$1", f = "Emitters.kt", l = {110, 117, 124}, m = "collect")
        public static final class a extends gu.d {

            /* renamed from: t, reason: collision with root package name */
            public /* synthetic */ Object f12847t;

            /* renamed from: u, reason: collision with root package name */
            public int f12848u;

            /* renamed from: w, reason: collision with root package name */
            public Object f12850w;

            /* renamed from: x, reason: collision with root package name */
            public Object f12851x;

            public a(eu.b bVar) {
                super(bVar);
            }

            @Override // gu.a
            public final Object invokeSuspend(Object obj) {
                this.f12847t = obj;
                this.f12848u |= Integer.MIN_VALUE;
                return b.this.collect(null, this);
            }
        }

        public b(h hVar, pu.n nVar) {
            this.f12846a = hVar;
            this.b = nVar;
        }

        /* JADX WARN: Removed duplicated region for block: B:32:0x0088  */
        /* JADX WARN: Removed duplicated region for block: B:33:0x00ac A[RETURN] */
        /* JADX WARN: Removed duplicated region for block: B:41:? A[RETURN, SYNTHETIC] */
        /* JADX WARN: Removed duplicated region for block: B:42:0x0055  */
        /* JADX WARN: Removed duplicated region for block: B:8:0x0026  */
        @Override // dv.h
        /*
            Code decompiled incorrectly, please refer to instructions dump.
            To view partially-correct add '--show-bad-code' argument
        */
        public java.lang.Object collect(dv.i<? super T> r9, eu.b<? super kotlin.Unit> r10) {
            /*
                r8 = this;
                boolean r0 = r10 instanceof dv.u.b.a
                if (r0 == 0) goto L13
                r0 = r10
                dv.u$b$a r0 = (dv.u.b.a) r0
                int r1 = r0.f12848u
                r2 = -2147483648(0xffffffff80000000, float:-0.0)
                r3 = r1 & r2
                if (r3 == 0) goto L13
                int r1 = r1 - r2
                r0.f12848u = r1
                goto L18
            L13:
                dv.u$b$a r0 = new dv.u$b$a
                r0.<init>(r10)
            L18:
                java.lang.Object r10 = r0.f12847t
                java.lang.Object r1 = fu.c.e()
                int r2 = r0.f12848u
                r3 = 3
                r4 = 2
                r5 = 1
                r6 = 0
                if (r2 == 0) goto L55
                if (r2 == r5) goto L47
                if (r2 == r4) goto L3e
                if (r2 != r3) goto L36
                java.lang.Object r9 = r0.f12850w
                ev.v r9 = (kotlin.v) r9
                zt.o.b(r10)     // Catch: java.lang.Throwable -> L34
                goto L89
            L34:
                r10 = move-exception
                goto L93
            L36:
                java.lang.IllegalStateException r9 = new java.lang.IllegalStateException
                java.lang.String r10 = "call to 'resume' before 'invoke' with coroutine"
                r9.<init>(r10)
                throw r9
            L3e:
                java.lang.Object r9 = r0.f12850w
                java.lang.Throwable r9 = (java.lang.Throwable) r9
                zt.o.b(r10)
                goto Lad
            L47:
                java.lang.Object r9 = r0.f12851x
                dv.i r9 = (dv.i) r9
                java.lang.Object r2 = r0.f12850w
                dv.u$b r2 = (dv.u.b) r2
                zt.o.b(r10)     // Catch: java.lang.Throwable -> L53
                goto L68
            L53:
                r9 = move-exception
                goto L99
            L55:
                zt.o.b(r10)
                dv.h r10 = r8.f12846a     // Catch: java.lang.Throwable -> L97
                r0.f12850w = r8     // Catch: java.lang.Throwable -> L97
                r0.f12851x = r9     // Catch: java.lang.Throwable -> L97
                r0.f12848u = r5     // Catch: java.lang.Throwable -> L97
                java.lang.Object r10 = r10.collect(r9, r0)     // Catch: java.lang.Throwable -> L97
                if (r10 != r1) goto L67
                goto Lac
            L67:
                r2 = r8
            L68:
                ev.v r10 = new ev.v
                kotlin.coroutines.CoroutineContext r4 = r0.getContext()
                r10.<init>(r9, r4)
                pu.n r9 = r2.b     // Catch: java.lang.Throwable -> L8f
                r0.f12850w = r10     // Catch: java.lang.Throwable -> L8f
                r0.f12851x = r6     // Catch: java.lang.Throwable -> L8f
                r0.f12848u = r3     // Catch: java.lang.Throwable -> L8f
                r2 = 6
                kotlin.jvm.internal.l.c(r2)     // Catch: java.lang.Throwable -> L8f
                java.lang.Object r9 = r9.invoke(r10, r6, r0)     // Catch: java.lang.Throwable -> L8f
                r0 = 7
                kotlin.jvm.internal.l.c(r0)     // Catch: java.lang.Throwable -> L8f
                if (r9 != r1) goto L88
                goto Lac
            L88:
                r9 = r10
            L89:
                r9.releaseIntercepted()
                kotlin.Unit r9 = kotlin.Unit.f21504a
                return r9
            L8f:
                r9 = move-exception
                r7 = r10
                r10 = r9
                r9 = r7
            L93:
                r9.releaseIntercepted()
                throw r10
            L97:
                r9 = move-exception
                r2 = r8
            L99:
                dv.u0 r10 = new dv.u0
                r10.<init>(r9)
                pu.n r2 = r2.b
                r0.f12850w = r9
                r0.f12851x = r6
                r0.f12848u = r4
                java.lang.Object r10 = dv.u.a(r10, r2, r9, r0)
                if (r10 != r1) goto Lad
            Lac:
                return r1
            Lad:
                throw r9
            */
            throw new UnsupportedOperationException("Method not decompiled: dv.u.b.collect(dv.i, eu.b):java.lang.Object");
        }
    }

    /* JADX INFO: Add missing generic type declarations: [T] */
    @Metadata(d1 = {"\u0000\u0017\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0003*\u0001\u0000\b\n\u0018\u00002\b\u0012\u0004\u0012\u00028\u00000\u0001J\u001e\u0010\u0005\u001a\u00020\u00042\f\u0010\u0003\u001a\b\u0012\u0004\u0012\u00028\u00000\u0002H\u0096@¢\u0006\u0004\b\u0005\u0010\u0006¨\u0006\u0007"}, d2 = {"dv/u$c", "Ldv/h;", "Ldv/i;", "collector", BuildConfig.FLAVOR, "collect", "(Ldv/i;Leu/b;)Ljava/lang/Object;", "kotlinx-coroutines-core"}, k = 1, mv = {2, 1, 0}, xi = 48)
    public static final class c<T> implements h<T> {

        /* renamed from: a, reason: collision with root package name */
        public final /* synthetic */ Function2 f12852a;
        public final /* synthetic */ h b;

        @Metadata(k = 3, mv = {2, 1, 0}, xi = 48)
        @gu.f(c = "kotlinx.coroutines.flow.FlowKt__EmittersKt$onStart$$inlined$unsafeFlow$1", f = "Emitters.kt", l = {112, 116}, m = "collect")
        public static final class a extends gu.d {

            /* renamed from: t, reason: collision with root package name */
            public /* synthetic */ Object f12853t;

            /* renamed from: u, reason: collision with root package name */
            public int f12854u;

            /* renamed from: w, reason: collision with root package name */
            public Object f12856w;

            /* renamed from: x, reason: collision with root package name */
            public Object f12857x;

            /* renamed from: y, reason: collision with root package name */
            public Object f12858y;

            public a(eu.b bVar) {
                super(bVar);
            }

            @Override // gu.a
            public final Object invokeSuspend(Object obj) {
                this.f12853t = obj;
                this.f12854u |= Integer.MIN_VALUE;
                return c.this.collect(null, this);
            }
        }

        public c(Function2 function2, h hVar) {
            this.f12852a = function2;
            this.b = hVar;
        }

        /* JADX WARN: Code restructure failed: missing block: B:20:0x0080, code lost:
        
            if (r7.collect(r2, r0) != r1) goto L28;
         */
        /* JADX WARN: Removed duplicated region for block: B:26:0x0046  */
        /* JADX WARN: Removed duplicated region for block: B:8:0x0024  */
        @Override // dv.h
        /*
            Code decompiled incorrectly, please refer to instructions dump.
            To view partially-correct add '--show-bad-code' argument
        */
        public java.lang.Object collect(dv.i<? super T> r7, eu.b<? super kotlin.Unit> r8) {
            /*
                r6 = this;
                boolean r0 = r8 instanceof dv.u.c.a
                if (r0 == 0) goto L13
                r0 = r8
                dv.u$c$a r0 = (dv.u.c.a) r0
                int r1 = r0.f12854u
                r2 = -2147483648(0xffffffff80000000, float:-0.0)
                r3 = r1 & r2
                if (r3 == 0) goto L13
                int r1 = r1 - r2
                r0.f12854u = r1
                goto L18
            L13:
                dv.u$c$a r0 = new dv.u$c$a
                r0.<init>(r8)
            L18:
                java.lang.Object r8 = r0.f12853t
                java.lang.Object r1 = fu.c.e()
                int r2 = r0.f12854u
                r3 = 2
                r4 = 1
                if (r2 == 0) goto L46
                if (r2 == r4) goto L34
                if (r2 != r3) goto L2c
                zt.o.b(r8)
                goto L83
            L2c:
                java.lang.IllegalStateException r7 = new java.lang.IllegalStateException
                java.lang.String r8 = "call to 'resume' before 'invoke' with coroutine"
                r7.<init>(r8)
                throw r7
            L34:
                java.lang.Object r7 = r0.f12858y
                ev.v r7 = (kotlin.v) r7
                java.lang.Object r2 = r0.f12857x
                dv.i r2 = (dv.i) r2
                java.lang.Object r4 = r0.f12856w
                dv.u$c r4 = (dv.u.c) r4
                zt.o.b(r8)     // Catch: java.lang.Throwable -> L44
                goto L6e
            L44:
                r8 = move-exception
                goto L8a
            L46:
                zt.o.b(r8)
                ev.v r8 = new ev.v
                kotlin.coroutines.CoroutineContext r2 = r0.getContext()
                r8.<init>(r7, r2)
                kotlin.jvm.functions.Function2 r2 = r6.f12852a     // Catch: java.lang.Throwable -> L86
                r0.f12856w = r6     // Catch: java.lang.Throwable -> L86
                r0.f12857x = r7     // Catch: java.lang.Throwable -> L86
                r0.f12858y = r8     // Catch: java.lang.Throwable -> L86
                r0.f12854u = r4     // Catch: java.lang.Throwable -> L86
                r4 = 6
                kotlin.jvm.internal.l.c(r4)     // Catch: java.lang.Throwable -> L86
                java.lang.Object r2 = r2.invoke(r8, r0)     // Catch: java.lang.Throwable -> L86
                r4 = 7
                kotlin.jvm.internal.l.c(r4)     // Catch: java.lang.Throwable -> L86
                if (r2 != r1) goto L6b
                goto L82
            L6b:
                r4 = r6
                r2 = r7
                r7 = r8
            L6e:
                r7.releaseIntercepted()
                dv.h r7 = r4.b
                r8 = 0
                r0.f12856w = r8
                r0.f12857x = r8
                r0.f12858y = r8
                r0.f12854u = r3
                java.lang.Object r7 = r7.collect(r2, r0)
                if (r7 != r1) goto L83
            L82:
                return r1
            L83:
                kotlin.Unit r7 = kotlin.Unit.f21504a
                return r7
            L86:
                r7 = move-exception
                r5 = r8
                r8 = r7
                r7 = r5
            L8a:
                r7.releaseIntercepted()
                throw r8
            */
            throw new UnsupportedOperationException("Method not decompiled: dv.u.c.collect(dv.i, eu.b):java.lang.Object");
        }
    }

    public static final void b(@NotNull i<?> iVar) {
        if (iVar instanceof u0) {
            throw ((u0) iVar).e;
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:18:0x0038  */
    /* JADX WARN: Removed duplicated region for block: B:9:0x0023  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public static final <T> java.lang.Object c(dv.i<? super T> r4, pu.n<? super dv.i<? super T>, ? super java.lang.Throwable, ? super eu.b<? super kotlin.Unit>, ? extends java.lang.Object> r5, java.lang.Throwable r6, eu.b<? super kotlin.Unit> r7) {
        /*
            boolean r0 = r7 instanceof dv.u.a
            if (r0 == 0) goto L13
            r0 = r7
            dv.u$a r0 = (dv.u.a) r0
            int r1 = r0.f12845v
            r2 = -2147483648(0xffffffff80000000, float:-0.0)
            r3 = r1 & r2
            if (r3 == 0) goto L13
            int r1 = r1 - r2
            r0.f12845v = r1
            goto L18
        L13:
            dv.u$a r0 = new dv.u$a
            r0.<init>(r7)
        L18:
            java.lang.Object r7 = r0.f12844u
            java.lang.Object r1 = fu.c.e()
            int r2 = r0.f12845v
            r3 = 1
            if (r2 == 0) goto L38
            if (r2 != r3) goto L30
            java.lang.Object r4 = r0.f12843t
            r6 = r4
            java.lang.Throwable r6 = (java.lang.Throwable) r6
            zt.o.b(r7)     // Catch: java.lang.Throwable -> L2e
            goto L46
        L2e:
            r4 = move-exception
            goto L49
        L30:
            java.lang.IllegalStateException r4 = new java.lang.IllegalStateException
            java.lang.String r5 = "call to 'resume' before 'invoke' with coroutine"
            r4.<init>(r5)
            throw r4
        L38:
            zt.o.b(r7)
            r0.f12843t = r6     // Catch: java.lang.Throwable -> L2e
            r0.f12845v = r3     // Catch: java.lang.Throwable -> L2e
            java.lang.Object r4 = r5.invoke(r4, r6, r0)     // Catch: java.lang.Throwable -> L2e
            if (r4 != r1) goto L46
            return r1
        L46:
            kotlin.Unit r4 = kotlin.Unit.f21504a
            return r4
        L49:
            if (r6 == 0) goto L50
            if (r6 == r4) goto L50
            zt.a.a(r4, r6)
        L50:
            throw r4
        */
        throw new UnsupportedOperationException("Method not decompiled: dv.u.c(dv.i, pu.n, java.lang.Throwable, eu.b):java.lang.Object");
    }

    @NotNull
    public static final <T> h<T> d(@NotNull h<? extends T> hVar, @NotNull pu.n<? super i<? super T>, ? super Throwable, ? super eu.b<? super Unit>, ? extends Object> nVar) {
        return new b(hVar, nVar);
    }

    @NotNull
    public static final <T> h<T> e(@NotNull h<? extends T> hVar, @NotNull Function2<? super i<? super T>, ? super eu.b<? super Unit>, ? extends Object> function2) {
        return new c(function2, hVar);
    }


    // --- восстановлено из DEX (dv/u$b$a) ---
    public static class a extends gu.d {
        java.lang.Object t;
        int u;
        dv.u.b v;
        java.lang.Object w;
        java.lang.Object x;
        public a(dv.u.b p0, eu.b p1) { }
        public java.lang.Object invokeSuspend(java.lang.Object p0) { throw new UnsupportedOperationException("stub"); }
    }

    // --- восстановлено из DEX (dv/u$c$a) ---
    public static class a extends gu.d {
        java.lang.Object t;
        int u;
        dv.u.c v;
        java.lang.Object w;
        java.lang.Object x;
        java.lang.Object y;
        public a(dv.u.c p0, eu.b p1) { }
        public java.lang.Object invokeSuspend(java.lang.Object p0) { throw new UnsupportedOperationException("stub"); }
    }
}
