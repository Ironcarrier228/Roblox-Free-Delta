package dv;

import av.g2;
import com.github.luben.zstd.BuildConfig;
import com.google.mlkit.vision.common.InputImage;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.functions.Function2;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(d1 = {"\u0000:\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\b\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u000b\n\u0002\u0010\u0000\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0004\u001a+\u0010\u0004\u001a\b\u0012\u0004\u0012\u00028\u00000\u0001\"\u0004\b\u0000\u0010\u0000*\b\u0012\u0004\u0012\u00028\u00000\u00012\u0006\u0010\u0003\u001a\u00020\u0002¢\u0006\u0004\b\u0004\u0010\u0005\u001aG\u0010\u000b\u001a\b\u0012\u0004\u0012\u00028\u00000\u0001\"\u0004\b\u0000\u0010\u0000*\b\u0012\u0004\u0012\u00028\u00000\u00012\"\u0010\n\u001a\u001e\b\u0001\u0012\u0004\u0012\u00028\u0000\u0012\n\u0012\b\u0012\u0004\u0012\u00020\b0\u0007\u0012\u0006\u0012\u0004\u0018\u00010\t0\u0006¢\u0006\u0004\b\u000b\u0010\f\u001a+\u0010\r\u001a\b\u0012\u0004\u0012\u00028\u00000\u0001\"\u0004\b\u0000\u0010\u0000*\b\u0012\u0004\u0012\u00028\u00000\u00012\u0006\u0010\u0003\u001a\u00020\u0002¢\u0006\u0004\b\r\u0010\u0005\u001a0\u0010\u0012\u001a\u00020\u0011\"\u0004\b\u0000\u0010\u0000*\b\u0012\u0004\u0012\u00028\u00000\u000e2\u0006\u0010\u000f\u001a\u00028\u00002\u0006\u0010\u0010\u001a\u00020\tH\u0082@¢\u0006\u0004\b\u0012\u0010\u0013\u001aG\u0010\u0014\u001a\b\u0012\u0004\u0012\u00028\u00000\u0001\"\u0004\b\u0000\u0010\u0000*\b\u0012\u0004\u0012\u00028\u00000\u00012\"\u0010\n\u001a\u001e\b\u0001\u0012\u0004\u0012\u00028\u0000\u0012\n\u0012\b\u0012\u0004\u0012\u00020\b0\u0007\u0012\u0006\u0012\u0004\u0018\u00010\t0\u0006¢\u0006\u0004\b\u0014\u0010\f\u001a[\u0010\u0018\u001a\b\u0012\u0004\u0012\u00028\u00010\u0001\"\u0004\b\u0000\u0010\u0000\"\u0004\b\u0001\u0010\u0015*\b\u0012\u0004\u0012\u00028\u00000\u000120\b\u0001\u0010\u0017\u001a*\b\u0001\u0012\n\u0012\b\u0012\u0004\u0012\u00028\u00010\u000e\u0012\u0004\u0012\u00028\u0000\u0012\n\u0012\b\u0012\u0004\u0012\u00020\b0\u0007\u0012\u0006\u0012\u0004\u0018\u00010\t0\u0016¢\u0006\u0004\b\u0018\u0010\u0019¨\u0006\u001a"}, d2 = {"T", "Ldv/h;", BuildConfig.FLAVOR, "count", k6.b.f21144e, "(Ldv/h;I)Ldv/h;", "Lkotlin/Function2;", "Leu/b;", BuildConfig.FLAVOR, BuildConfig.FLAVOR, "predicate", "c", "(Ldv/h;Lkotlin/jvm/functions/Function2;)Ldv/h;", "e", "Ldv/i;", "value", "ownershipMarker", BuildConfig.FLAVOR, "d", "(Ldv/i;Ljava/lang/Object;Ljava/lang/Object;Leu/b;)Ljava/lang/Object;", "f", "R", "Lkotlin/Function3;", "transform", "g", "(Ldv/h;Lpu/n;)Ldv/h;", "kotlinx-coroutines-core"}, k = 5, mv = {2, 1, 0}, xi = 48, xs = "kotlinx/coroutines/flow/FlowKt")
/* loaded from: classes2.dex */
public final /* synthetic */ class w {

    /* JADX INFO: Add missing generic type declarations: [T] */
    @Metadata(d1 = {"\u0000\u0017\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0003*\u0001\u0000\b\n\u0018\u00002\b\u0012\u0004\u0012\u00028\u00000\u0001J\u001e\u0010\u0005\u001a\u00020\u00042\f\u0010\u0003\u001a\b\u0012\u0004\u0012\u00028\u00000\u0002H\u0096@¢\u0006\u0004\b\u0005\u0010\u0006¨\u0006\u0007"}, d2 = {"dv/w$a", "Ldv/h;", "Ldv/i;", "collector", BuildConfig.FLAVOR, "collect", "(Ldv/i;Leu/b;)Ljava/lang/Object;", "kotlinx-coroutines-core"}, k = 1, mv = {2, 1, 0}, xi = 48)
    public static final class a<T> implements dv.h<T> {

        /* renamed from: a, reason: collision with root package name */
        public final /* synthetic */ dv.h f12882a;
        public final /* synthetic */ int b;

        public a(dv.h hVar, int i10) {
            this.f12882a = hVar;
            this.b = i10;
        }

        @Override // dv.h
        public Object collect(dv.i<? super T> iVar, eu.b<? super Unit> bVar) {
            Object collect = this.f12882a.collect(new b(new kotlin.jvm.internal.a0(), this.b, iVar), bVar);
            return collect == fu.c.e() ? collect : Unit.f21504a;
        }
    }

    @Metadata(k = 3, mv = {2, 1, 0}, xi = 48)
    public static final class b<T> implements dv.i {

        /* renamed from: a, reason: collision with root package name */
        public final /* synthetic */ kotlin.jvm.internal.a0 f12883a;
        public final /* synthetic */ int b;

        /* renamed from: c, reason: collision with root package name */
        public final /* synthetic */ dv.i<T> f12884c;

        @Metadata(k = 3, mv = {2, 1, 0}, xi = 48)
        @gu.f(c = "kotlinx.coroutines.flow.FlowKt__LimitKt$drop$2$1", f = "Limit.kt", l = {22}, m = "emit")
        public static final class a extends gu.d {

            /* renamed from: t, reason: collision with root package name */
            public /* synthetic */ Object f12885t;

            /* renamed from: u, reason: collision with root package name */
            public final /* synthetic */ b<T> f12886u;

            /* renamed from: v, reason: collision with root package name */
            public int f12887v;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            /* JADX WARN: Multi-variable type inference failed */
            public a(b<? super T> bVar, eu.b<? super a> bVar2) {
                super(bVar2);
                this.f12886u = bVar;
            }

            @Override // gu.a
            public final Object invokeSuspend(Object obj) {
                this.f12885t = obj;
                this.f12887v |= Integer.MIN_VALUE;
                return this.f12886u.emit(null, this);
            }
        }

        /* JADX WARN: Multi-variable type inference failed */
        public b(kotlin.jvm.internal.a0 a0Var, int i10, dv.i<? super T> iVar) {
            this.f12883a = a0Var;
            this.b = i10;
            this.f12884c = iVar;
        }

        /* JADX WARN: Removed duplicated region for block: B:15:0x0031  */
        /* JADX WARN: Removed duplicated region for block: B:8:0x0023  */
        @Override // dv.i
        /*
            Code decompiled incorrectly, please refer to instructions dump.
            To view partially-correct add '--show-bad-code' argument
        */
        public final java.lang.Object emit(T r6, eu.b<? super kotlin.Unit> r7) {
            /*
                r5 = this;
                boolean r0 = r7 instanceof dv.w.b.a
                if (r0 == 0) goto L13
                r0 = r7
                dv.w$b$a r0 = (dv.w.b.a) r0
                int r1 = r0.f12887v
                r2 = -2147483648(0xffffffff80000000, float:-0.0)
                r3 = r1 & r2
                if (r3 == 0) goto L13
                int r1 = r1 - r2
                r0.f12887v = r1
                goto L18
            L13:
                dv.w$b$a r0 = new dv.w$b$a
                r0.<init>(r5, r7)
            L18:
                java.lang.Object r7 = r0.f12885t
                java.lang.Object r1 = fu.c.e()
                int r2 = r0.f12887v
                r3 = 1
                if (r2 == 0) goto L31
                if (r2 != r3) goto L29
                zt.o.b(r7)
                goto L47
            L29:
                java.lang.IllegalStateException r6 = new java.lang.IllegalStateException
                java.lang.String r7 = "call to 'resume' before 'invoke' with coroutine"
                r6.<init>(r7)
                throw r6
            L31:
                zt.o.b(r7)
                kotlin.jvm.internal.a0 r7 = r5.f12883a
                int r2 = r7.f21570a
                int r4 = r5.b
                if (r2 < r4) goto L4a
                dv.i<T> r7 = r5.f12884c
                r0.f12887v = r3
                java.lang.Object r6 = r7.emit(r6, r0)
                if (r6 != r1) goto L47
                return r1
            L47:
                kotlin.Unit r6 = kotlin.Unit.f21504a
                return r6
            L4a:
                int r2 = r2 + r3
                r7.f21570a = r2
                kotlin.Unit r6 = kotlin.Unit.f21504a
                return r6
            */
            throw new UnsupportedOperationException("Method not decompiled: dv.w.b.emit(java.lang.Object, eu.b):java.lang.Object");
        }
    }

    /* JADX INFO: Add missing generic type declarations: [T] */
    @Metadata(d1 = {"\u0000\u0017\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0003*\u0001\u0000\b\n\u0018\u00002\b\u0012\u0004\u0012\u00028\u00000\u0001J\u001e\u0010\u0005\u001a\u00020\u00042\f\u0010\u0003\u001a\b\u0012\u0004\u0012\u00028\u00000\u0002H\u0096@¢\u0006\u0004\b\u0005\u0010\u0006¨\u0006\u0007"}, d2 = {"dv/w$c", "Ldv/h;", "Ldv/i;", "collector", BuildConfig.FLAVOR, "collect", "(Ldv/i;Leu/b;)Ljava/lang/Object;", "kotlinx-coroutines-core"}, k = 1, mv = {2, 1, 0}, xi = 48)
    public static final class c<T> implements dv.h<T> {

        /* renamed from: a, reason: collision with root package name */
        public final /* synthetic */ dv.h f12888a;
        public final /* synthetic */ Function2 b;

        public c(dv.h hVar, Function2 function2) {
            this.f12888a = hVar;
            this.b = function2;
        }

        @Override // dv.h
        public Object collect(dv.i<? super T> iVar, eu.b<? super Unit> bVar) {
            Object collect = this.f12888a.collect(new d(new kotlin.jvm.internal.y(), iVar, this.b), bVar);
            return collect == fu.c.e() ? collect : Unit.f21504a;
        }
    }

    @Metadata(k = 3, mv = {2, 1, 0}, xi = 48)
    public static final class d<T> implements dv.i {

        /* renamed from: a, reason: collision with root package name */
        public final /* synthetic */ kotlin.jvm.internal.y f12889a;
        public final /* synthetic */ dv.i<T> b;

        /* renamed from: c, reason: collision with root package name */
        public final /* synthetic */ Function2<T, eu.b<? super Boolean>, Object> f12890c;

        @Metadata(k = 3, mv = {2, 1, 0}, xi = 48)
        @gu.f(c = "kotlinx.coroutines.flow.FlowKt__LimitKt$dropWhile$1$1", f = "Limit.kt", l = {34, InputImage.IMAGE_FORMAT_YUV_420_888, 37}, m = "emit")
        public static final class a extends gu.d {

            /* renamed from: t, reason: collision with root package name */
            public Object f12891t;

            /* renamed from: u, reason: collision with root package name */
            public Object f12892u;

            /* renamed from: v, reason: collision with root package name */
            public /* synthetic */ Object f12893v;

            /* renamed from: w, reason: collision with root package name */
            public final /* synthetic */ d<T> f12894w;

            /* renamed from: x, reason: collision with root package name */
            public int f12895x;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            /* JADX WARN: Multi-variable type inference failed */
            public a(d<? super T> dVar, eu.b<? super a> bVar) {
                super(bVar);
                this.f12894w = dVar;
            }

            @Override // gu.a
            public final Object invokeSuspend(Object obj) {
                this.f12893v = obj;
                this.f12895x |= Integer.MIN_VALUE;
                return this.f12894w.emit(null, this);
            }
        }

        /* JADX WARN: Multi-variable type inference failed */
        public d(kotlin.jvm.internal.y yVar, dv.i<? super T> iVar, Function2<? super T, ? super eu.b<? super Boolean>, ? extends Object> function2) {
            this.f12889a = yVar;
            this.b = iVar;
            this.f12890c = function2;
        }

        /* JADX WARN: Code restructure failed: missing block: B:21:0x0085, code lost:
        
            if (r8.emit(r7, r0) == r1) goto L33;
         */
        /* JADX WARN: Code restructure failed: missing block: B:31:0x0056, code lost:
        
            if (r8.emit(r7, r0) == r1) goto L33;
         */
        /* JADX WARN: Removed duplicated region for block: B:20:0x0074  */
        /* JADX WARN: Removed duplicated region for block: B:23:0x008b  */
        /* JADX WARN: Removed duplicated region for block: B:28:0x0045  */
        /* JADX WARN: Removed duplicated region for block: B:8:0x0025  */
        @Override // dv.i
        /*
            Code decompiled incorrectly, please refer to instructions dump.
            To view partially-correct add '--show-bad-code' argument
        */
        public final java.lang.Object emit(T r7, eu.b<? super kotlin.Unit> r8) {
            /*
                r6 = this;
                boolean r0 = r8 instanceof dv.w.d.a
                if (r0 == 0) goto L13
                r0 = r8
                dv.w$d$a r0 = (dv.w.d.a) r0
                int r1 = r0.f12895x
                r2 = -2147483648(0xffffffff80000000, float:-0.0)
                r3 = r1 & r2
                if (r3 == 0) goto L13
                int r1 = r1 - r2
                r0.f12895x = r1
                goto L18
            L13:
                dv.w$d$a r0 = new dv.w$d$a
                r0.<init>(r6, r8)
            L18:
                java.lang.Object r8 = r0.f12893v
                java.lang.Object r1 = fu.c.e()
                int r2 = r0.f12895x
                r3 = 3
                r4 = 2
                r5 = 1
                if (r2 == 0) goto L45
                if (r2 == r5) goto L41
                if (r2 == r4) goto L37
                if (r2 != r3) goto L2f
                zt.o.b(r8)
                goto L88
            L2f:
                java.lang.IllegalStateException r7 = new java.lang.IllegalStateException
                java.lang.String r8 = "call to 'resume' before 'invoke' with coroutine"
                r7.<init>(r8)
                throw r7
            L37:
                java.lang.Object r7 = r0.f12892u
                java.lang.Object r2 = r0.f12891t
                dv.w$d r2 = (dv.w.d) r2
                zt.o.b(r8)
                goto L6c
            L41:
                zt.o.b(r8)
                goto L59
            L45:
                zt.o.b(r8)
                kotlin.jvm.internal.y r8 = r6.f12889a
                boolean r8 = r8.f21589a
                if (r8 == 0) goto L5c
                dv.i<T> r8 = r6.b
                r0.f12895x = r5
                java.lang.Object r7 = r8.emit(r7, r0)
                if (r7 != r1) goto L59
                goto L87
            L59:
                kotlin.Unit r7 = kotlin.Unit.f21504a
                return r7
            L5c:
                kotlin.jvm.functions.Function2<T, eu.b<? super java.lang.Boolean>, java.lang.Object> r8 = r6.f12890c
                r0.f12891t = r6
                r0.f12892u = r7
                r0.f12895x = r4
                java.lang.Object r8 = r8.invoke(r7, r0)
                if (r8 != r1) goto L6b
                goto L87
            L6b:
                r2 = r6
            L6c:
                java.lang.Boolean r8 = (java.lang.Boolean) r8
                boolean r8 = r8.booleanValue()
                if (r8 != 0) goto L8b
                kotlin.jvm.internal.y r8 = r2.f12889a
                r8.f21589a = r5
                dv.i<T> r8 = r2.b
                r2 = 0
                r0.f12891t = r2
                r0.f12892u = r2
                r0.f12895x = r3
                java.lang.Object r7 = r8.emit(r7, r0)
                if (r7 != r1) goto L88
            L87:
                return r1
            L88:
                kotlin.Unit r7 = kotlin.Unit.f21504a
                return r7
            L8b:
                kotlin.Unit r7 = kotlin.Unit.f21504a
                return r7
            */
            throw new UnsupportedOperationException("Method not decompiled: dv.w.d.emit(java.lang.Object, eu.b):java.lang.Object");
        }
    }

    @Metadata(k = 3, mv = {2, 1, 0}, xi = 48)
    @gu.f(c = "kotlinx.coroutines.flow.FlowKt__LimitKt", f = "Limit.kt", l = {71}, m = "emitAbort$FlowKt__LimitKt")
    public static final class e<T> extends gu.d {

        /* renamed from: t, reason: collision with root package name */
        public Object f12896t;

        /* renamed from: u, reason: collision with root package name */
        public /* synthetic */ Object f12897u;

        /* renamed from: v, reason: collision with root package name */
        public int f12898v;

        public e(eu.b<? super e> bVar) {
            super(bVar);
        }

        @Override // gu.a
        @Nullable
        public final Object invokeSuspend(@NotNull Object obj) {
            this.f12897u = obj;
            this.f12898v |= Integer.MIN_VALUE;
            return w.d(null, null, null, this);
        }
    }

    /* JADX INFO: Add missing generic type declarations: [T] */
    @Metadata(d1 = {"\u0000\u0017\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0003*\u0001\u0000\b\n\u0018\u00002\b\u0012\u0004\u0012\u00028\u00000\u0001J\u001e\u0010\u0005\u001a\u00020\u00042\f\u0010\u0003\u001a\b\u0012\u0004\u0012\u00028\u00000\u0002H\u0096@¢\u0006\u0004\b\u0005\u0010\u0006¨\u0006\u0007"}, d2 = {"dv/w$f", "Ldv/h;", "Ldv/i;", "collector", BuildConfig.FLAVOR, "collect", "(Ldv/i;Leu/b;)Ljava/lang/Object;", "kotlinx-coroutines-core"}, k = 1, mv = {2, 1, 0}, xi = 48)
    public static final class f<T> implements dv.h<T> {

        /* renamed from: a, reason: collision with root package name */
        public final /* synthetic */ dv.h f12899a;
        public final /* synthetic */ int b;

        @Metadata(k = 3, mv = {2, 1, 0}, xi = 48)
        @gu.f(c = "kotlinx.coroutines.flow.FlowKt__LimitKt$take$$inlined$unsafeFlow$1", f = "Limit.kt", l = {112}, m = "collect")
        public static final class a extends gu.d {

            /* renamed from: t, reason: collision with root package name */
            public /* synthetic */ Object f12900t;

            /* renamed from: u, reason: collision with root package name */
            public int f12901u;

            /* renamed from: w, reason: collision with root package name */
            public Object f12903w;

            public a(eu.b bVar) {
                super(bVar);
            }

            @Override // gu.a
            public final Object invokeSuspend(Object obj) {
                this.f12900t = obj;
                this.f12901u |= Integer.MIN_VALUE;
                return f.this.collect(null, this);
            }
        }

        public f(dv.h hVar, int i10) {
            this.f12899a = hVar;
            this.b = i10;
        }

        /* JADX WARN: Removed duplicated region for block: B:20:0x0035  */
        /* JADX WARN: Removed duplicated region for block: B:8:0x0023  */
        @Override // dv.h
        /*
            Code decompiled incorrectly, please refer to instructions dump.
            To view partially-correct add '--show-bad-code' argument
        */
        public java.lang.Object collect(dv.i<? super T> r9, eu.b<? super kotlin.Unit> r10) {
            /*
                r8 = this;
                boolean r0 = r10 instanceof dv.w.f.a
                if (r0 == 0) goto L13
                r0 = r10
                dv.w$f$a r0 = (dv.w.f.a) r0
                int r1 = r0.f12901u
                r2 = -2147483648(0xffffffff80000000, float:-0.0)
                r3 = r1 & r2
                if (r3 == 0) goto L13
                int r1 = r1 - r2
                r0.f12901u = r1
                goto L18
            L13:
                dv.w$f$a r0 = new dv.w$f$a
                r0.<init>(r10)
            L18:
                java.lang.Object r10 = r0.f12900t
                java.lang.Object r1 = fu.c.e()
                int r2 = r0.f12901u
                r3 = 1
                if (r2 == 0) goto L35
                if (r2 != r3) goto L2d
                java.lang.Object r9 = r0.f12903w
                zt.o.b(r10)     // Catch: kotlin.a -> L2b
                goto L5d
            L2b:
                r10 = move-exception
                goto L5a
            L2d:
                java.lang.IllegalStateException r9 = new java.lang.IllegalStateException
                java.lang.String r10 = "call to 'resume' before 'invoke' with coroutine"
                r9.<init>(r10)
                throw r9
            L35:
                zt.o.b(r10)
                java.lang.Object r10 = new java.lang.Object
                r10.<init>()
                kotlin.jvm.internal.a0 r2 = new kotlin.jvm.internal.a0
                r2.<init>()
                dv.h r4 = r8.f12899a     // Catch: kotlin.a -> L56
                dv.w$g r5 = new dv.w$g     // Catch: kotlin.a -> L56
                int r6 = r8.b     // Catch: kotlin.a -> L56
                r5.<init>(r2, r6, r9, r10)     // Catch: kotlin.a -> L56
                r0.f12903w = r10     // Catch: kotlin.a -> L56
                r0.f12901u = r3     // Catch: kotlin.a -> L56
                java.lang.Object r9 = r4.collect(r5, r0)     // Catch: kotlin.a -> L56
                if (r9 != r1) goto L5d
                return r1
            L56:
                r9 = move-exception
                r7 = r10
                r10 = r9
                r9 = r7
            L5a:
                kotlin.p.a(r10, r9)
            L5d:
                kotlin.Unit r9 = kotlin.Unit.f21504a
                return r9
            */
            throw new UnsupportedOperationException("Method not decompiled: dv.w.f.collect(dv.i, eu.b):java.lang.Object");
        }
    }

    @Metadata(k = 3, mv = {2, 1, 0}, xi = 48)
    public static final class g<T> implements dv.i {

        /* renamed from: a, reason: collision with root package name */
        public final /* synthetic */ kotlin.jvm.internal.a0 f12904a;
        public final /* synthetic */ int b;

        /* renamed from: c, reason: collision with root package name */
        public final /* synthetic */ dv.i<T> f12905c;

        /* renamed from: d, reason: collision with root package name */
        public final /* synthetic */ Object f12906d;

        @Metadata(k = 3, mv = {2, 1, 0}, xi = 48)
        @gu.f(c = "kotlinx.coroutines.flow.FlowKt__LimitKt$take$2$1", f = "Limit.kt", l = {59, 61}, m = "emit")
        public static final class a extends gu.d {

            /* renamed from: t, reason: collision with root package name */
            public /* synthetic */ Object f12907t;

            /* renamed from: u, reason: collision with root package name */
            public final /* synthetic */ g<T> f12908u;

            /* renamed from: v, reason: collision with root package name */
            public int f12909v;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            /* JADX WARN: Multi-variable type inference failed */
            public a(g<? super T> gVar, eu.b<? super a> bVar) {
                super(bVar);
                this.f12908u = gVar;
            }

            @Override // gu.a
            public final Object invokeSuspend(Object obj) {
                this.f12907t = obj;
                this.f12909v |= Integer.MIN_VALUE;
                return this.f12908u.emit(null, this);
            }
        }

        /* JADX WARN: Multi-variable type inference failed */
        public g(kotlin.jvm.internal.a0 a0Var, int i10, dv.i<? super T> iVar, Object obj) {
            this.f12904a = a0Var;
            this.b = i10;
            this.f12905c = iVar;
            this.f12906d = obj;
        }

        /* JADX WARN: Code restructure failed: missing block: B:22:0x004e, code lost:
        
            if (r7.emit(r6, r0) == r1) goto L25;
         */
        /* JADX WARN: Code restructure failed: missing block: B:25:0x005e, code lost:
        
            if (dv.w.d(r7, r6, r2, r0) == r1) goto L25;
         */
        /* JADX WARN: Removed duplicated region for block: B:19:0x0038  */
        /* JADX WARN: Removed duplicated region for block: B:8:0x0024  */
        @Override // dv.i
        /*
            Code decompiled incorrectly, please refer to instructions dump.
            To view partially-correct add '--show-bad-code' argument
        */
        public final java.lang.Object emit(T r6, eu.b<? super kotlin.Unit> r7) {
            /*
                r5 = this;
                boolean r0 = r7 instanceof dv.w.g.a
                if (r0 == 0) goto L13
                r0 = r7
                dv.w$g$a r0 = (dv.w.g.a) r0
                int r1 = r0.f12909v
                r2 = -2147483648(0xffffffff80000000, float:-0.0)
                r3 = r1 & r2
                if (r3 == 0) goto L13
                int r1 = r1 - r2
                r0.f12909v = r1
                goto L18
            L13:
                dv.w$g$a r0 = new dv.w$g$a
                r0.<init>(r5, r7)
            L18:
                java.lang.Object r7 = r0.f12907t
                java.lang.Object r1 = fu.c.e()
                int r2 = r0.f12909v
                r3 = 2
                r4 = 1
                if (r2 == 0) goto L38
                if (r2 == r4) goto L34
                if (r2 != r3) goto L2c
                zt.o.b(r7)
                goto L61
            L2c:
                java.lang.IllegalStateException r6 = new java.lang.IllegalStateException
                java.lang.String r7 = "call to 'resume' before 'invoke' with coroutine"
                r6.<init>(r7)
                throw r6
            L34:
                zt.o.b(r7)
                goto L51
            L38:
                zt.o.b(r7)
                kotlin.jvm.internal.a0 r7 = r5.f12904a
                int r2 = r7.f21570a
                int r2 = r2 + r4
                r7.f21570a = r2
                int r7 = r5.b
                if (r2 >= r7) goto L54
                dv.i<T> r7 = r5.f12905c
                r0.f12909v = r4
                java.lang.Object r6 = r7.emit(r6, r0)
                if (r6 != r1) goto L51
                goto L60
            L51:
                kotlin.Unit r6 = kotlin.Unit.f21504a
                return r6
            L54:
                dv.i<T> r7 = r5.f12905c
                java.lang.Object r2 = r5.f12906d
                r0.f12909v = r3
                java.lang.Object r6 = dv.w.a(r7, r6, r2, r0)
                if (r6 != r1) goto L61
            L60:
                return r1
            L61:
                kotlin.Unit r6 = kotlin.Unit.f21504a
                return r6
            */
            throw new UnsupportedOperationException("Method not decompiled: dv.w.g.emit(java.lang.Object, eu.b):java.lang.Object");
        }
    }

    /* JADX INFO: Add missing generic type declarations: [T] */
    @Metadata(d1 = {"\u0000\u0017\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0003*\u0001\u0000\b\n\u0018\u00002\b\u0012\u0004\u0012\u00028\u00000\u0001J\u001e\u0010\u0005\u001a\u00020\u00042\f\u0010\u0003\u001a\b\u0012\u0004\u0012\u00028\u00000\u0002H\u0096@¢\u0006\u0004\b\u0005\u0010\u0006¨\u0006\u0007"}, d2 = {"dv/w$h", "Ldv/h;", "Ldv/i;", "collector", BuildConfig.FLAVOR, "collect", "(Ldv/i;Leu/b;)Ljava/lang/Object;", "kotlinx-coroutines-core"}, k = 1, mv = {2, 1, 0}, xi = 48)
    public static final class h<T> implements dv.h<T> {

        /* renamed from: a, reason: collision with root package name */
        public final /* synthetic */ dv.h f12910a;
        public final /* synthetic */ Function2 b;

        @Metadata(k = 3, mv = {2, 1, 0}, xi = 48)
        @gu.f(c = "kotlinx.coroutines.flow.FlowKt__LimitKt$takeWhile$$inlined$unsafeFlow$1", f = "Limit.kt", l = {120}, m = "collect")
        public static final class a extends gu.d {

            /* renamed from: t, reason: collision with root package name */
            public /* synthetic */ Object f12911t;

            /* renamed from: u, reason: collision with root package name */
            public int f12912u;

            /* renamed from: w, reason: collision with root package name */
            public Object f12914w;

            public a(eu.b bVar) {
                super(bVar);
            }

            @Override // gu.a
            public final Object invokeSuspend(Object obj) {
                this.f12911t = obj;
                this.f12912u |= Integer.MIN_VALUE;
                return h.this.collect(null, this);
            }
        }

        public h(dv.h hVar, Function2 function2) {
            this.f12910a = hVar;
            this.b = function2;
        }

        /* JADX WARN: Removed duplicated region for block: B:20:0x0037  */
        /* JADX WARN: Removed duplicated region for block: B:8:0x0023  */
        @Override // dv.h
        /*
            Code decompiled incorrectly, please refer to instructions dump.
            To view partially-correct add '--show-bad-code' argument
        */
        public java.lang.Object collect(dv.i<? super T> r6, eu.b<? super kotlin.Unit> r7) {
            /*
                r5 = this;
                boolean r0 = r7 instanceof dv.w.h.a
                if (r0 == 0) goto L13
                r0 = r7
                dv.w$h$a r0 = (dv.w.h.a) r0
                int r1 = r0.f12912u
                r2 = -2147483648(0xffffffff80000000, float:-0.0)
                r3 = r1 & r2
                if (r3 == 0) goto L13
                int r1 = r1 - r2
                r0.f12912u = r1
                goto L18
            L13:
                dv.w$h$a r0 = new dv.w$h$a
                r0.<init>(r7)
            L18:
                java.lang.Object r7 = r0.f12911t
                java.lang.Object r1 = fu.c.e()
                int r2 = r0.f12912u
                r3 = 1
                if (r2 == 0) goto L37
                if (r2 != r3) goto L2f
                java.lang.Object r6 = r0.f12914w
                dv.w$i r6 = (dv.w.i) r6
                zt.o.b(r7)     // Catch: kotlin.a -> L2d
                goto L5a
            L2d:
                r7 = move-exception
                goto L50
            L2f:
                java.lang.IllegalStateException r6 = new java.lang.IllegalStateException
                java.lang.String r7 = "call to 'resume' before 'invoke' with coroutine"
                r6.<init>(r7)
                throw r6
            L37:
                zt.o.b(r7)
                dv.h r7 = r5.f12910a
                dv.w$i r2 = new dv.w$i
                kotlin.jvm.functions.Function2 r4 = r5.b
                r2.<init>(r4, r6)
                r0.f12914w = r2     // Catch: kotlin.a -> L4e
                r0.f12912u = r3     // Catch: kotlin.a -> L4e
                java.lang.Object r6 = r7.collect(r2, r0)     // Catch: kotlin.a -> L4e
                if (r6 != r1) goto L5a
                return r1
            L4e:
                r7 = move-exception
                r6 = r2
            L50:
                kotlin.p.a(r7, r6)
                kotlin.coroutines.CoroutineContext r6 = r0.getContext()
                av.g2.i(r6)
            L5a:
                kotlin.Unit r6 = kotlin.Unit.f21504a
                return r6
            */
            throw new UnsupportedOperationException("Method not decompiled: dv.w.h.collect(dv.i, eu.b):java.lang.Object");
        }
    }

    /* JADX INFO: Add missing generic type declarations: [T] */
    @Metadata(d1 = {"\u0000\u0013\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0003*\u0001\u0000\b\n\u0018\u00002\b\u0012\u0004\u0012\u00028\u00000\u0001J\u0018\u0010\u0004\u001a\u00020\u00032\u0006\u0010\u0002\u001a\u00028\u0000H\u0096@¢\u0006\u0004\b\u0004\u0010\u0005¨\u0006\u0006"}, d2 = {"dv/w$i", "Ldv/i;", "value", BuildConfig.FLAVOR, "emit", "(Ljava/lang/Object;Leu/b;)Ljava/lang/Object;", "kotlinx-coroutines-core"}, k = 1, mv = {2, 1, 0}, xi = 48)
    public static final class i<T> implements dv.i<T> {

        /* renamed from: a, reason: collision with root package name */
        public final /* synthetic */ Function2 f12915a;
        public final /* synthetic */ dv.i b;

        @Metadata(k = 3, mv = {2, 1, 0}, xi = 48)
        @gu.f(c = "kotlinx.coroutines.flow.FlowKt__LimitKt$takeWhile$lambda$6$$inlined$collectWhile$1", f = "Limit.kt", l = {132, 133}, m = "emit")
        public static final class a extends gu.d {

            /* renamed from: t, reason: collision with root package name */
            public Object f12916t;

            /* renamed from: u, reason: collision with root package name */
            public /* synthetic */ Object f12917u;

            /* renamed from: v, reason: collision with root package name */
            public int f12918v;

            /* renamed from: x, reason: collision with root package name */
            public Object f12920x;

            public a(eu.b bVar) {
                super(bVar);
            }

            @Override // gu.a
            public final Object invokeSuspend(Object obj) {
                this.f12917u = obj;
                this.f12918v |= Integer.MIN_VALUE;
                return i.this.emit(null, this);
            }
        }

        public i(Function2 function2, dv.i iVar) {
            this.f12915a = function2;
            this.b = iVar;
        }

        /* JADX WARN: Code restructure failed: missing block: B:23:0x0078, code lost:
        
            if (r2.emit(r9, r0) == r1) goto L24;
         */
        /* JADX WARN: Multi-variable type inference failed */
        /* JADX WARN: Removed duplicated region for block: B:12:0x007e  */
        /* JADX WARN: Removed duplicated region for block: B:15:0x0081  */
        /* JADX WARN: Removed duplicated region for block: B:22:0x006b  */
        /* JADX WARN: Removed duplicated region for block: B:25:0x007b  */
        /* JADX WARN: Removed duplicated region for block: B:26:0x0046  */
        /* JADX WARN: Removed duplicated region for block: B:8:0x0024  */
        @Override // dv.i
        /*
            Code decompiled incorrectly, please refer to instructions dump.
            To view partially-correct add '--show-bad-code' argument
        */
        public java.lang.Object emit(T r8, eu.b<? super kotlin.Unit> r9) {
            /*
                r7 = this;
                boolean r0 = r9 instanceof dv.w.i.a
                if (r0 == 0) goto L13
                r0 = r9
                dv.w$i$a r0 = (dv.w.i.a) r0
                int r1 = r0.f12918v
                r2 = -2147483648(0xffffffff80000000, float:-0.0)
                r3 = r1 & r2
                if (r3 == 0) goto L13
                int r1 = r1 - r2
                r0.f12918v = r1
                goto L18
            L13:
                dv.w$i$a r0 = new dv.w$i$a
                r0.<init>(r9)
            L18:
                java.lang.Object r9 = r0.f12917u
                java.lang.Object r1 = fu.c.e()
                int r2 = r0.f12918v
                r3 = 2
                r4 = 1
                if (r2 == 0) goto L46
                if (r2 == r4) goto L38
                if (r2 != r3) goto L30
                java.lang.Object r8 = r0.f12916t
                dv.w$i r8 = (dv.w.i) r8
                zt.o.b(r9)
                goto L7c
            L30:
                java.lang.IllegalStateException r8 = new java.lang.IllegalStateException
                java.lang.String r9 = "call to 'resume' before 'invoke' with coroutine"
                r8.<init>(r9)
                throw r8
            L38:
                java.lang.Object r8 = r0.f12920x
                java.lang.Object r2 = r0.f12916t
                dv.w$i r2 = (dv.w.i) r2
                zt.o.b(r9)
                r6 = r9
                r9 = r8
                r8 = r2
                r2 = r6
                goto L63
            L46:
                zt.o.b(r9)
                kotlin.jvm.functions.Function2 r9 = r7.f12915a
                r0.f12916t = r7
                r0.f12920x = r8
                r0.f12918v = r4
                r2 = 6
                kotlin.jvm.internal.l.c(r2)
                java.lang.Object r9 = r9.invoke(r8, r0)
                r2 = 7
                kotlin.jvm.internal.l.c(r2)
                if (r9 != r1) goto L60
                goto L7a
            L60:
                r2 = r9
                r9 = r8
                r8 = r7
            L63:
                java.lang.Boolean r2 = (java.lang.Boolean) r2
                boolean r2 = r2.booleanValue()
                if (r2 == 0) goto L7b
                dv.i r2 = r8.b
                r0.f12916t = r8
                r5 = 0
                r0.f12920x = r5
                r0.f12918v = r3
                java.lang.Object r9 = r2.emit(r9, r0)
                if (r9 != r1) goto L7c
            L7a:
                return r1
            L7b:
                r4 = 0
            L7c:
                if (r4 == 0) goto L81
                kotlin.Unit r8 = kotlin.Unit.f21504a
                return r8
            L81:
                ev.a r9 = new ev.a
                r9.<init>(r8)
                throw r9
            */
            throw new UnsupportedOperationException("Method not decompiled: dv.w.i.emit(java.lang.Object, eu.b):java.lang.Object");
        }
    }

    /* JADX INFO: Add missing generic type declarations: [R] */
    @Metadata(d1 = {"\u0000\u000e\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0002\b\u0002\u0010\u0003\u001a\u00020\u0002\"\u0004\b\u0000\u0010\u0000*\b\u0012\u0004\u0012\u00028\u00000\u0001H\n¢\u0006\u0004\b\u0003\u0010\u0004"}, d2 = {"R", "Ldv/i;", BuildConfig.FLAVOR, "<anonymous>", "(Ldv/i;)V"}, k = 3, mv = {2, 1, 0})
    @gu.f(c = "kotlinx.coroutines.flow.FlowKt__LimitKt$transformWhile$1", f = "Limit.kt", l = {152}, m = "invokeSuspend")
    public static final class j<R> extends gu.m implements Function2<dv.i<? super R>, eu.b<? super Unit>, Object> {

        /* renamed from: t, reason: collision with root package name */
        public int f12921t;

        /* renamed from: u, reason: collision with root package name */
        public /* synthetic */ Object f12922u;

        /* renamed from: v, reason: collision with root package name */
        public final /* synthetic */ dv.h<T> f12923v;

        /* renamed from: w, reason: collision with root package name */
        public final /* synthetic */ pu.n<dv.i<? super R>, T, eu.b<? super Boolean>, Object> f12924w;

        /* JADX INFO: Add missing generic type declarations: [T] */
        @Metadata(d1 = {"\u0000\u0013\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0003*\u0001\u0000\b\n\u0018\u00002\b\u0012\u0004\u0012\u00028\u00000\u0001J\u0018\u0010\u0004\u001a\u00020\u00032\u0006\u0010\u0002\u001a\u00028\u0000H\u0096@¢\u0006\u0004\b\u0004\u0010\u0005¨\u0006\u0006"}, d2 = {"dv/w$j$a", "Ldv/i;", "value", BuildConfig.FLAVOR, "emit", "(Ljava/lang/Object;Leu/b;)Ljava/lang/Object;", "kotlinx-coroutines-core"}, k = 1, mv = {2, 1, 0}, xi = 48)
        public static final class a<T> implements dv.i<T> {

            /* renamed from: a, reason: collision with root package name */
            public final /* synthetic */ pu.n f12925a;
            public final /* synthetic */ dv.i b;

            @Metadata(k = 3, mv = {2, 1, 0}, xi = 48)
            @gu.f(c = "kotlinx.coroutines.flow.FlowKt__LimitKt$transformWhile$1$invokeSuspend$$inlined$collectWhile$1", f = "Limit.kt", l = {132}, m = "emit")
            /* renamed from: dv.w$j$a$a, reason: collision with other inner class name */
            public static final class C0248a extends gu.d {

                /* renamed from: t, reason: collision with root package name */
                public Object f12926t;

                /* renamed from: u, reason: collision with root package name */
                public /* synthetic */ Object f12927u;

                /* renamed from: v, reason: collision with root package name */
                public int f12928v;

                public C0248a(eu.b bVar) {
                    super(bVar);
                }

                @Override // gu.a
                public final Object invokeSuspend(Object obj) {
                    this.f12927u = obj;
                    this.f12928v |= Integer.MIN_VALUE;
                    return a.this.emit(null, this);
                }
            }

            public a(pu.n nVar, dv.i iVar) {
                this.f12925a = nVar;
                this.b = iVar;
            }

            /* JADX WARN: Removed duplicated region for block: B:12:0x0058  */
            /* JADX WARN: Removed duplicated region for block: B:15:0x005b  */
            /* JADX WARN: Removed duplicated region for block: B:19:0x0035  */
            /* JADX WARN: Removed duplicated region for block: B:8:0x0023  */
            @Override // dv.i
            /*
                Code decompiled incorrectly, please refer to instructions dump.
                To view partially-correct add '--show-bad-code' argument
            */
            public java.lang.Object emit(T r5, eu.b<? super kotlin.Unit> r6) {
                /*
                    r4 = this;
                    boolean r0 = r6 instanceof dv.w.j.a.C0248a
                    if (r0 == 0) goto L13
                    r0 = r6
                    dv.w$j$a$a r0 = (dv.w.j.a.C0248a) r0
                    int r1 = r0.f12928v
                    r2 = -2147483648(0xffffffff80000000, float:-0.0)
                    r3 = r1 & r2
                    if (r3 == 0) goto L13
                    int r1 = r1 - r2
                    r0.f12928v = r1
                    goto L18
                L13:
                    dv.w$j$a$a r0 = new dv.w$j$a$a
                    r0.<init>(r6)
                L18:
                    java.lang.Object r6 = r0.f12927u
                    java.lang.Object r1 = fu.c.e()
                    int r2 = r0.f12928v
                    r3 = 1
                    if (r2 == 0) goto L35
                    if (r2 != r3) goto L2d
                    java.lang.Object r5 = r0.f12926t
                    dv.w$j$a r5 = (dv.w.j.a) r5
                    zt.o.b(r6)
                    goto L50
                L2d:
                    java.lang.IllegalStateException r5 = new java.lang.IllegalStateException
                    java.lang.String r6 = "call to 'resume' before 'invoke' with coroutine"
                    r5.<init>(r6)
                    throw r5
                L35:
                    zt.o.b(r6)
                    pu.n r6 = r4.f12925a
                    dv.i r2 = r4.b
                    r0.f12926t = r4
                    r0.f12928v = r3
                    r3 = 6
                    kotlin.jvm.internal.l.c(r3)
                    java.lang.Object r6 = r6.invoke(r2, r5, r0)
                    r5 = 7
                    kotlin.jvm.internal.l.c(r5)
                    if (r6 != r1) goto L4f
                    return r1
                L4f:
                    r5 = r4
                L50:
                    java.lang.Boolean r6 = (java.lang.Boolean) r6
                    boolean r6 = r6.booleanValue()
                    if (r6 == 0) goto L5b
                    kotlin.Unit r5 = kotlin.Unit.f21504a
                    return r5
                L5b:
                    ev.a r6 = new ev.a
                    r6.<init>(r5)
                    throw r6
                */
                throw new UnsupportedOperationException("Method not decompiled: dv.w.j.a.emit(java.lang.Object, eu.b):java.lang.Object");
            }
        }

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        /* JADX WARN: Multi-variable type inference failed */
        public j(dv.h<? extends T> hVar, pu.n<? super dv.i<? super R>, ? super T, ? super eu.b<? super Boolean>, ? extends Object> nVar, eu.b<? super j> bVar) {
            super(2, bVar);
            this.f12923v = hVar;
            this.f12924w = nVar;
        }

        @Override // gu.a
        public final eu.b<Unit> create(Object obj, eu.b<?> bVar) {
            j jVar = new j(this.f12923v, this.f12924w, bVar);
            jVar.f12922u = obj;
            return jVar;
        }

        @Override // gu.a
        public final Object invokeSuspend(Object obj) {
            a aVar;
            Object e10 = fu.c.e();
            int i10 = this.f12921t;
            if (i10 == 0) {
                zt.o.b(obj);
                dv.i iVar = (dv.i) this.f12922u;
                dv.h<T> hVar = this.f12923v;
                a aVar2 = new a(this.f12924w, iVar);
                try {
                    this.f12922u = aVar2;
                    this.f12921t = 1;
                    if (hVar.collect(aVar2, this) == e10) {
                        return e10;
                    }
                } catch (kotlin.a e11) {
                    e = e11;
                    aVar = aVar2;
                    kotlin.p.a(e, aVar);
                    g2.i(getContext());
                    return Unit.f21504a;
                }
            } else {
                if (i10 != 1) {
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                aVar = (a) this.f12922u;
                try {
                    zt.o.b(obj);
                } catch (kotlin.a e12) {
                    e = e12;
                    kotlin.p.a(e, aVar);
                    g2.i(getContext());
                    return Unit.f21504a;
                }
            }
            return Unit.f21504a;
        }

        @Override // kotlin.jvm.functions.Function2
        /* renamed from: m, reason: merged with bridge method [inline-methods] */
        public final Object invoke(dv.i<? super R> iVar, eu.b<? super Unit> bVar) {
            return ((j) create(iVar, bVar)).invokeSuspend(Unit.f21504a);
        }
    }

    @NotNull
    public static final <T> dv.h<T> b(@NotNull dv.h<? extends T> hVar, int i10) {
        if (i10 >= 0) {
            return new a(hVar, i10);
        }
        throw new IllegalArgumentException(("Drop count should be non-negative, but had " + i10).toString());
    }

    @NotNull
    public static final <T> dv.h<T> c(@NotNull dv.h<? extends T> hVar, @NotNull Function2<? super T, ? super eu.b<? super Boolean>, ? extends Object> function2) {
        return new c(hVar, function2);
    }

    /* JADX WARN: Removed duplicated region for block: B:15:0x0033  */
    /* JADX WARN: Removed duplicated region for block: B:8:0x0023  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public static final <T> java.lang.Object d(dv.i<? super T> r4, T r5, java.lang.Object r6, eu.b<? super kotlin.Unit> r7) {
        /*
            boolean r0 = r7 instanceof dv.w.e
            if (r0 == 0) goto L13
            r0 = r7
            dv.w$e r0 = (dv.w.e) r0
            int r1 = r0.f12898v
            r2 = -2147483648(0xffffffff80000000, float:-0.0)
            r3 = r1 & r2
            if (r3 == 0) goto L13
            int r1 = r1 - r2
            r0.f12898v = r1
            goto L18
        L13:
            dv.w$e r0 = new dv.w$e
            r0.<init>(r7)
        L18:
            java.lang.Object r7 = r0.f12897u
            java.lang.Object r1 = fu.c.e()
            int r2 = r0.f12898v
            r3 = 1
            if (r2 == 0) goto L33
            if (r2 == r3) goto L2d
            java.lang.IllegalStateException r4 = new java.lang.IllegalStateException
            java.lang.String r5 = "call to 'resume' before 'invoke' with coroutine"
            r4.<init>(r5)
            throw r4
        L2d:
            java.lang.Object r6 = r0.f12896t
            zt.o.b(r7)
            goto L41
        L33:
            zt.o.b(r7)
            r0.f12896t = r6
            r0.f12898v = r3
            java.lang.Object r4 = r4.emit(r5, r0)
            if (r4 != r1) goto L41
            return r1
        L41:
            ev.a r4 = new ev.a
            r4.<init>(r6)
            throw r4
        */
        throw new UnsupportedOperationException("Method not decompiled: dv.w.d(dv.i, java.lang.Object, java.lang.Object, eu.b):java.lang.Object");
    }

    @NotNull
    public static final <T> dv.h<T> e(@NotNull dv.h<? extends T> hVar, int i10) {
        if (i10 > 0) {
            return new f(hVar, i10);
        }
        throw new IllegalArgumentException(("Requested element count " + i10 + " should be positive").toString());
    }

    @NotNull
    public static final <T> dv.h<T> f(@NotNull dv.h<? extends T> hVar, @NotNull Function2<? super T, ? super eu.b<? super Boolean>, ? extends Object> function2) {
        return new h(hVar, function2);
    }

    @NotNull
    public static final <T, R> dv.h<R> g(@NotNull dv.h<? extends T> hVar, @NotNull pu.n<? super dv.i<? super R>, ? super T, ? super eu.b<? super Boolean>, ? extends Object> nVar) {
        return dv.j.w(new j(hVar, nVar, null));
    }


    // --- восстановлено из DEX (dv/w$b$a) ---
    public static class a extends gu.d {
        java.lang.Object t;
        dv.w.b u;
        int v;
        public a(dv.w.b p0, eu.b p1) { }
        public java.lang.Object invokeSuspend(java.lang.Object p0) { throw new UnsupportedOperationException("stub"); }
    }

    // --- восстановлено из DEX (dv/w$d$a) ---
    public static class a extends gu.d {
        java.lang.Object t;
        java.lang.Object u;
        java.lang.Object v;
        dv.w.d w;
        int x;
        public a(dv.w.d p0, eu.b p1) { }
        public java.lang.Object invokeSuspend(java.lang.Object p0) { throw new UnsupportedOperationException("stub"); }
    }

    // --- восстановлено из DEX (dv/w$f$a) ---
    public static class a extends gu.d {
        java.lang.Object t;
        int u;
        dv.w.f v;
        java.lang.Object w;
        public a(dv.w.f p0, eu.b p1) { }
        public java.lang.Object invokeSuspend(java.lang.Object p0) { throw new UnsupportedOperationException("stub"); }
    }

    // --- восстановлено из DEX (dv/w$g$a) ---
    public static class a extends gu.d {
        java.lang.Object t;
        dv.w.g u;
        int v;
        public a(dv.w.g p0, eu.b p1) { }
        public java.lang.Object invokeSuspend(java.lang.Object p0) { throw new UnsupportedOperationException("stub"); }
    }

    // --- восстановлено из DEX (dv/w$h$a) ---
    public static class a extends gu.d {
        java.lang.Object t;
        int u;
        dv.w.h v;
        java.lang.Object w;
        public a(dv.w.h p0, eu.b p1) { }
        public java.lang.Object invokeSuspend(java.lang.Object p0) { throw new UnsupportedOperationException("stub"); }
    }

    // --- восстановлено из DEX (dv/w$i$a) ---
    public static class a extends gu.d {
        java.lang.Object t;
        java.lang.Object u;
        int v;
        dv.w.i w;
        java.lang.Object x;
        public a(dv.w.i p0, eu.b p1) { }
        public java.lang.Object invokeSuspend(java.lang.Object p0) { throw new UnsupportedOperationException("stub"); }
    }

    // --- восстановлено из DEX (dv/w$j$a) ---
    public static class a implements dv.i {
        pu.n a;
        dv.i b;
        public a(pu.n p0, dv.i p1) { }
        public java.lang.Object emit(java.lang.Object p0, eu.b p1) { throw new UnsupportedOperationException("stub"); }
    }

    // --- восстановлено из DEX (dv/w$j$a$a) ---
    public static class a extends gu.d {
        java.lang.Object t;
        java.lang.Object u;
        int v;
        dv.w.j.a w;
        public a(dv.w.j.a p0, eu.b p1) { }
        public java.lang.Object invokeSuspend(java.lang.Object p0) { throw new UnsupportedOperationException("stub"); }
    }
}
