package dv;

import com.appsflyer.share.attribution.RequestError;
import com.github.luben.zstd.BuildConfig;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.functions.Function2;
import org.jetbrains.annotations.NotNull;

@Metadata(d1 = {"\u0000&\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0004\u001a)\u0010\u0003\u001a\b\u0012\u0004\u0012\u00028\u00000\u0002\"\b\b\u0000\u0010\u0001*\u00020\u0000*\n\u0012\u0006\u0012\u0004\u0018\u00018\u00000\u0002¢\u0006\u0004\b\u0003\u0010\u0004\u001aG\u0010\t\u001a\b\u0012\u0004\u0012\u00028\u00000\u0002\"\u0004\b\u0000\u0010\u0001*\b\u0012\u0004\u0012\u00028\u00000\u00022\"\u0010\b\u001a\u001e\b\u0001\u0012\u0004\u0012\u00028\u0000\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00070\u0006\u0012\u0006\u0012\u0004\u0018\u00010\u00000\u0005¢\u0006\u0004\b\t\u0010\n\u001a]\u0010\u000f\u001a\b\u0012\u0004\u0012\u00028\u00010\u0002\"\u0004\b\u0000\u0010\u0001\"\u0004\b\u0001\u0010\u000b*\b\u0012\u0004\u0012\u00028\u00000\u00022\u0006\u0010\f\u001a\u00028\u00012*\b\u0001\u0010\u000e\u001a$\b\u0001\u0012\u0004\u0012\u00028\u0001\u0012\u0004\u0012\u00028\u0000\u0012\n\u0012\b\u0012\u0004\u0012\u00028\u00010\u0006\u0012\u0006\u0012\u0004\u0018\u00010\u00000\r¢\u0006\u0004\b\u000f\u0010\u0010¨\u0006\u0011"}, d2 = {BuildConfig.FLAVOR, "T", "Ldv/h;", xe.a.f36648e, "(Ldv/h;)Ldv/h;", "Lkotlin/Function2;", "Leu/b;", BuildConfig.FLAVOR, "action", k6.b.f21144e, "(Ldv/h;Lkotlin/jvm/functions/Function2;)Ldv/h;", "R", "initial", "Lkotlin/Function3;", "operation", "c", "(Ldv/h;Ljava/lang/Object;Lpu/n;)Ldv/h;", "kotlinx-coroutines-core"}, k = 5, mv = {2, 1, 0}, xi = 48, xs = "kotlinx/coroutines/flow/FlowKt")
/* loaded from: classes2.dex */
public final /* synthetic */ class a0 {

    /* JADX INFO: Add missing generic type declarations: [T] */
    @Metadata(d1 = {"\u0000\u0017\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0003*\u0001\u0000\b\n\u0018\u00002\b\u0012\u0004\u0012\u00028\u00000\u0001J\u001e\u0010\u0005\u001a\u00020\u00042\f\u0010\u0003\u001a\b\u0012\u0004\u0012\u00028\u00000\u0002H\u0096@¢\u0006\u0004\b\u0005\u0010\u0006¨\u0006\u0007"}, d2 = {"kotlinx/coroutines/flow/internal/SafeCollector_commonKt$unsafeFlow$1", "Ldv/h;", "Ldv/i;", "collector", BuildConfig.FLAVOR, "collect", "(Ldv/i;Leu/b;)Ljava/lang/Object;", "kotlinx-coroutines-core"}, k = 1, mv = {2, 1, 0}, xi = 48)
    public static final class a<T> implements h<T> {

        /* renamed from: a, reason: collision with root package name */
        public final /* synthetic */ h f12695a;

        @Metadata(k = 3, mv = {2, 1, 0}, xi = 48)
        /* renamed from: dv.a0$a$a, reason: collision with other inner class name */
        public static final class C0236a<T> implements i {

            /* renamed from: a, reason: collision with root package name */
            public final /* synthetic */ i f12696a;

            @Metadata(k = 3, mv = {2, 1, 0}, xi = 48)
            @gu.f(c = "kotlinx.coroutines.flow.FlowKt__TransformKt$filterNotNull$$inlined$unsafeTransform$1$2", f = "Transform.kt", l = {RequestError.RESPONSE_CODE_FAILURE}, m = "emit")
            /* renamed from: dv.a0$a$a$a, reason: collision with other inner class name */
            public static final class C0237a extends gu.d {

                /* renamed from: t, reason: collision with root package name */
                public /* synthetic */ Object f12697t;

                /* renamed from: u, reason: collision with root package name */
                public int f12698u;

                public C0237a(eu.b bVar) {
                    super(bVar);
                }

                @Override // gu.a
                public final Object invokeSuspend(Object obj) {
                    this.f12697t = obj;
                    this.f12698u |= Integer.MIN_VALUE;
                    return C0236a.this.emit(null, this);
                }
            }

            public C0236a(i iVar) {
                this.f12696a = iVar;
            }

            /* JADX WARN: Removed duplicated region for block: B:15:0x0031  */
            /* JADX WARN: Removed duplicated region for block: B:8:0x0023  */
            @Override // dv.i
            /*
                Code decompiled incorrectly, please refer to instructions dump.
                To view partially-correct add '--show-bad-code' argument
            */
            public final java.lang.Object emit(T r5, eu.b<? super kotlin.Unit> r6) {
                /*
                    r4 = this;
                    boolean r0 = r6 instanceof dv.a0.a.C0236a.C0237a
                    if (r0 == 0) goto L13
                    r0 = r6
                    dv.a0$a$a$a r0 = (dv.a0.a.C0236a.C0237a) r0
                    int r1 = r0.f12698u
                    r2 = -2147483648(0xffffffff80000000, float:-0.0)
                    r3 = r1 & r2
                    if (r3 == 0) goto L13
                    int r1 = r1 - r2
                    r0.f12698u = r1
                    goto L18
                L13:
                    dv.a0$a$a$a r0 = new dv.a0$a$a$a
                    r0.<init>(r6)
                L18:
                    java.lang.Object r6 = r0.f12697t
                    java.lang.Object r1 = fu.c.e()
                    int r2 = r0.f12698u
                    r3 = 1
                    if (r2 == 0) goto L31
                    if (r2 != r3) goto L29
                    zt.o.b(r6)
                    goto L41
                L29:
                    java.lang.IllegalStateException r5 = new java.lang.IllegalStateException
                    java.lang.String r6 = "call to 'resume' before 'invoke' with coroutine"
                    r5.<init>(r6)
                    throw r5
                L31:
                    zt.o.b(r6)
                    dv.i r6 = r4.f12696a
                    if (r5 == 0) goto L41
                    r0.f12698u = r3
                    java.lang.Object r5 = r6.emit(r5, r0)
                    if (r5 != r1) goto L41
                    return r1
                L41:
                    kotlin.Unit r5 = kotlin.Unit.f21504a
                    return r5
                */
                throw new UnsupportedOperationException("Method not decompiled: dv.a0.a.C0236a.emit(java.lang.Object, eu.b):java.lang.Object");
            }
        }

        public a(h hVar) {
            this.f12695a = hVar;
        }

        @Override // dv.h
        public Object collect(i iVar, eu.b bVar) {
            Object collect = this.f12695a.collect(new C0236a(iVar), bVar);
            return collect == fu.c.e() ? collect : Unit.f21504a;
        }
    }

    /* JADX INFO: Add missing generic type declarations: [T] */
    @Metadata(d1 = {"\u0000\u0017\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0003*\u0001\u0000\b\n\u0018\u00002\b\u0012\u0004\u0012\u00028\u00000\u0001J\u001e\u0010\u0005\u001a\u00020\u00042\f\u0010\u0003\u001a\b\u0012\u0004\u0012\u00028\u00000\u0002H\u0096@¢\u0006\u0004\b\u0005\u0010\u0006¨\u0006\u0007"}, d2 = {"kotlinx/coroutines/flow/internal/SafeCollector_commonKt$unsafeFlow$1", "Ldv/h;", "Ldv/i;", "collector", BuildConfig.FLAVOR, "collect", "(Ldv/i;Leu/b;)Ljava/lang/Object;", "kotlinx-coroutines-core"}, k = 1, mv = {2, 1, 0}, xi = 48)
    public static final class b<T> implements h<T> {

        /* renamed from: a, reason: collision with root package name */
        public final /* synthetic */ h f12700a;
        public final /* synthetic */ Function2 b;

        @Metadata(k = 3, mv = {2, 1, 0}, xi = 48)
        public static final class a<T> implements i {

            /* renamed from: a, reason: collision with root package name */
            public final /* synthetic */ i f12701a;
            public final /* synthetic */ Function2 b;

            @Metadata(k = 3, mv = {2, 1, 0}, xi = 48)
            @gu.f(c = "kotlinx.coroutines.flow.FlowKt__TransformKt$onEach$$inlined$unsafeTransform$1$2", f = "Transform.kt", l = {RequestError.RESPONSE_CODE_FAILURE, 51}, m = "emit")
            /* renamed from: dv.a0$b$a$a, reason: collision with other inner class name */
            public static final class C0238a extends gu.d {

                /* renamed from: t, reason: collision with root package name */
                public /* synthetic */ Object f12702t;

                /* renamed from: u, reason: collision with root package name */
                public int f12703u;

                /* renamed from: w, reason: collision with root package name */
                public Object f12705w;

                /* renamed from: x, reason: collision with root package name */
                public Object f12706x;

                public C0238a(eu.b bVar) {
                    super(bVar);
                }

                @Override // gu.a
                public final Object invokeSuspend(Object obj) {
                    this.f12702t = obj;
                    this.f12703u |= Integer.MIN_VALUE;
                    return a.this.emit(null, this);
                }
            }

            public a(i iVar, Function2 function2) {
                this.f12701a = iVar;
                this.b = function2;
            }

            /* JADX WARN: Code restructure failed: missing block: B:18:0x0067, code lost:
            
                if (r6.emit(r2, r0) != r1) goto L23;
             */
            /* JADX WARN: Multi-variable type inference failed */
            /* JADX WARN: Removed duplicated region for block: B:20:0x003e  */
            /* JADX WARN: Removed duplicated region for block: B:8:0x0024  */
            @Override // dv.i
            /*
                Code decompiled incorrectly, please refer to instructions dump.
                To view partially-correct add '--show-bad-code' argument
            */
            public final java.lang.Object emit(T r6, eu.b<? super kotlin.Unit> r7) {
                /*
                    r5 = this;
                    boolean r0 = r7 instanceof dv.a0.b.a.C0238a
                    if (r0 == 0) goto L13
                    r0 = r7
                    dv.a0$b$a$a r0 = (dv.a0.b.a.C0238a) r0
                    int r1 = r0.f12703u
                    r2 = -2147483648(0xffffffff80000000, float:-0.0)
                    r3 = r1 & r2
                    if (r3 == 0) goto L13
                    int r1 = r1 - r2
                    r0.f12703u = r1
                    goto L18
                L13:
                    dv.a0$b$a$a r0 = new dv.a0$b$a$a
                    r0.<init>(r7)
                L18:
                    java.lang.Object r7 = r0.f12702t
                    java.lang.Object r1 = fu.c.e()
                    int r2 = r0.f12703u
                    r3 = 2
                    r4 = 1
                    if (r2 == 0) goto L3e
                    if (r2 == r4) goto L34
                    if (r2 != r3) goto L2c
                    zt.o.b(r7)
                    goto L6a
                L2c:
                    java.lang.IllegalStateException r6 = new java.lang.IllegalStateException
                    java.lang.String r7 = "call to 'resume' before 'invoke' with coroutine"
                    r6.<init>(r7)
                    throw r6
                L34:
                    java.lang.Object r6 = r0.f12706x
                    dv.i r6 = (dv.i) r6
                    java.lang.Object r2 = r0.f12705w
                    zt.o.b(r7)
                    goto L5c
                L3e:
                    zt.o.b(r7)
                    dv.i r7 = r5.f12701a
                    kotlin.jvm.functions.Function2 r2 = r5.b
                    r0.f12705w = r6
                    r0.f12706x = r7
                    r0.f12703u = r4
                    r4 = 6
                    kotlin.jvm.internal.l.c(r4)
                    java.lang.Object r2 = r2.invoke(r6, r0)
                    r4 = 7
                    kotlin.jvm.internal.l.c(r4)
                    if (r2 != r1) goto L5a
                    goto L69
                L5a:
                    r2 = r6
                    r6 = r7
                L5c:
                    r7 = 0
                    r0.f12705w = r7
                    r0.f12706x = r7
                    r0.f12703u = r3
                    java.lang.Object r6 = r6.emit(r2, r0)
                    if (r6 != r1) goto L6a
                L69:
                    return r1
                L6a:
                    kotlin.Unit r6 = kotlin.Unit.f21504a
                    return r6
                */
                throw new UnsupportedOperationException("Method not decompiled: dv.a0.b.a.emit(java.lang.Object, eu.b):java.lang.Object");
            }
        }

        public b(h hVar, Function2 function2) {
            this.f12700a = hVar;
            this.b = function2;
        }

        @Override // dv.h
        public Object collect(i iVar, eu.b bVar) {
            Object collect = this.f12700a.collect(new a(iVar, this.b), bVar);
            return collect == fu.c.e() ? collect : Unit.f21504a;
        }
    }

    /* JADX INFO: Add missing generic type declarations: [R] */
    @Metadata(d1 = {"\u0000\u0017\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0003*\u0001\u0000\b\n\u0018\u00002\b\u0012\u0004\u0012\u00028\u00000\u0001J\u001e\u0010\u0005\u001a\u00020\u00042\f\u0010\u0003\u001a\b\u0012\u0004\u0012\u00028\u00000\u0002H\u0096@¢\u0006\u0004\b\u0005\u0010\u0006¨\u0006\u0007"}, d2 = {"dv/a0$c", "Ldv/h;", "Ldv/i;", "collector", BuildConfig.FLAVOR, "collect", "(Ldv/i;Leu/b;)Ljava/lang/Object;", "kotlinx-coroutines-core"}, k = 1, mv = {2, 1, 0}, xi = 48)
    public static final class c<R> implements h<R> {

        /* renamed from: a, reason: collision with root package name */
        public final /* synthetic */ Object f12707a;
        public final /* synthetic */ h b;

        /* renamed from: c, reason: collision with root package name */
        public final /* synthetic */ pu.n f12708c;

        @Metadata(k = 3, mv = {2, 1, 0}, xi = 48)
        @gu.f(c = "kotlinx.coroutines.flow.FlowKt__TransformKt$runningFold$$inlined$unsafeFlow$1", f = "Transform.kt", l = {110, 111}, m = "collect")
        public static final class a extends gu.d {

            /* renamed from: t, reason: collision with root package name */
            public /* synthetic */ Object f12709t;

            /* renamed from: u, reason: collision with root package name */
            public int f12710u;

            /* renamed from: w, reason: collision with root package name */
            public Object f12712w;

            /* renamed from: x, reason: collision with root package name */
            public Object f12713x;

            /* renamed from: y, reason: collision with root package name */
            public Object f12714y;

            public a(eu.b bVar) {
                super(bVar);
            }

            @Override // gu.a
            public final Object invokeSuspend(Object obj) {
                this.f12709t = obj;
                this.f12710u |= Integer.MIN_VALUE;
                return c.this.collect(null, this);
            }
        }

        public c(Object obj, h hVar, pu.n nVar) {
            this.f12707a = obj;
            this.b = hVar;
            this.f12708c = nVar;
        }

        /* JADX WARN: Code restructure failed: missing block: B:18:0x0078, code lost:
        
            if (r8.collect(r5, r0) != r1) goto L23;
         */
        /* JADX WARN: Removed duplicated region for block: B:20:0x0044  */
        /* JADX WARN: Removed duplicated region for block: B:8:0x0024  */
        /* JADX WARN: Type inference failed for: r2v1, types: [T, java.lang.Object] */
        @Override // dv.h
        /*
            Code decompiled incorrectly, please refer to instructions dump.
            To view partially-correct add '--show-bad-code' argument
        */
        public java.lang.Object collect(dv.i<? super R> r7, eu.b<? super kotlin.Unit> r8) {
            /*
                r6 = this;
                boolean r0 = r8 instanceof dv.a0.c.a
                if (r0 == 0) goto L13
                r0 = r8
                dv.a0$c$a r0 = (dv.a0.c.a) r0
                int r1 = r0.f12710u
                r2 = -2147483648(0xffffffff80000000, float:-0.0)
                r3 = r1 & r2
                if (r3 == 0) goto L13
                int r1 = r1 - r2
                r0.f12710u = r1
                goto L18
            L13:
                dv.a0$c$a r0 = new dv.a0$c$a
                r0.<init>(r8)
            L18:
                java.lang.Object r8 = r0.f12709t
                java.lang.Object r1 = fu.c.e()
                int r2 = r0.f12710u
                r3 = 2
                r4 = 1
                if (r2 == 0) goto L44
                if (r2 == r4) goto L34
                if (r2 != r3) goto L2c
                zt.o.b(r8)
                goto L7b
            L2c:
                java.lang.IllegalStateException r7 = new java.lang.IllegalStateException
                java.lang.String r8 = "call to 'resume' before 'invoke' with coroutine"
                r7.<init>(r8)
                throw r7
            L34:
                java.lang.Object r7 = r0.f12714y
                kotlin.jvm.internal.c0 r7 = (kotlin.jvm.internal.c0) r7
                java.lang.Object r2 = r0.f12713x
                dv.i r2 = (dv.i) r2
                java.lang.Object r4 = r0.f12712w
                dv.a0$c r4 = (dv.a0.c) r4
                zt.o.b(r8)
                goto L62
            L44:
                zt.o.b(r8)
                kotlin.jvm.internal.c0 r8 = new kotlin.jvm.internal.c0
                r8.<init>()
                java.lang.Object r2 = r6.f12707a
                r8.f21573a = r2
                r0.f12712w = r6
                r0.f12713x = r7
                r0.f12714y = r8
                r0.f12710u = r4
                java.lang.Object r2 = r7.emit(r2, r0)
                if (r2 != r1) goto L5f
                goto L7a
            L5f:
                r4 = r6
                r2 = r7
                r7 = r8
            L62:
                dv.h r8 = r4.b
                dv.a0$d r5 = new dv.a0$d
                pu.n r4 = r4.f12708c
                r5.<init>(r7, r4, r2)
                r7 = 0
                r0.f12712w = r7
                r0.f12713x = r7
                r0.f12714y = r7
                r0.f12710u = r3
                java.lang.Object r7 = r8.collect(r5, r0)
                if (r7 != r1) goto L7b
            L7a:
                return r1
            L7b:
                kotlin.Unit r7 = kotlin.Unit.f21504a
                return r7
            */
            throw new UnsupportedOperationException("Method not decompiled: dv.a0.c.collect(dv.i, eu.b):java.lang.Object");
        }
    }

    @Metadata(k = 3, mv = {2, 1, 0}, xi = 48)
    public static final class d<T> implements i {

        /* renamed from: a, reason: collision with root package name */
        public final /* synthetic */ kotlin.jvm.internal.c0<R> f12715a;
        public final /* synthetic */ pu.n<R, T, eu.b<? super R>, Object> b;

        /* renamed from: c, reason: collision with root package name */
        public final /* synthetic */ i<R> f12716c;

        @Metadata(k = 3, mv = {2, 1, 0}, xi = 48)
        @gu.f(c = "kotlinx.coroutines.flow.FlowKt__TransformKt$runningFold$1$1", f = "Transform.kt", l = {105, 106}, m = "emit")
        public static final class a extends gu.d {

            /* renamed from: t, reason: collision with root package name */
            public Object f12717t;

            /* renamed from: u, reason: collision with root package name */
            public Object f12718u;

            /* renamed from: v, reason: collision with root package name */
            public /* synthetic */ Object f12719v;

            /* renamed from: w, reason: collision with root package name */
            public final /* synthetic */ d<T> f12720w;

            /* renamed from: x, reason: collision with root package name */
            public int f12721x;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            /* JADX WARN: Multi-variable type inference failed */
            public a(d<? super T> dVar, eu.b<? super a> bVar) {
                super(bVar);
                this.f12720w = dVar;
            }

            @Override // gu.a
            public final Object invokeSuspend(Object obj) {
                this.f12719v = obj;
                this.f12721x |= Integer.MIN_VALUE;
                return this.f12720w.emit(null, this);
            }
        }

        /* JADX WARN: Multi-variable type inference failed */
        public d(kotlin.jvm.internal.c0<R> c0Var, pu.n<? super R, ? super T, ? super eu.b<? super R>, ? extends Object> nVar, i<? super R> iVar) {
            this.f12715a = c0Var;
            this.b = nVar;
            this.f12716c = iVar;
        }

        /* JADX WARN: Code restructure failed: missing block: B:18:0x006d, code lost:
        
            if (r7.emit(r8, r0) != r1) goto L23;
         */
        /* JADX WARN: Removed duplicated region for block: B:20:0x0040  */
        /* JADX WARN: Removed duplicated region for block: B:8:0x0024  */
        @Override // dv.i
        /*
            Code decompiled incorrectly, please refer to instructions dump.
            To view partially-correct add '--show-bad-code' argument
        */
        public final java.lang.Object emit(T r7, eu.b<? super kotlin.Unit> r8) {
            /*
                r6 = this;
                boolean r0 = r8 instanceof dv.a0.d.a
                if (r0 == 0) goto L13
                r0 = r8
                dv.a0$d$a r0 = (dv.a0.d.a) r0
                int r1 = r0.f12721x
                r2 = -2147483648(0xffffffff80000000, float:-0.0)
                r3 = r1 & r2
                if (r3 == 0) goto L13
                int r1 = r1 - r2
                r0.f12721x = r1
                goto L18
            L13:
                dv.a0$d$a r0 = new dv.a0$d$a
                r0.<init>(r6, r8)
            L18:
                java.lang.Object r8 = r0.f12719v
                java.lang.Object r1 = fu.c.e()
                int r2 = r0.f12721x
                r3 = 2
                r4 = 1
                if (r2 == 0) goto L40
                if (r2 == r4) goto L34
                if (r2 != r3) goto L2c
                zt.o.b(r8)
                goto L70
            L2c:
                java.lang.IllegalStateException r7 = new java.lang.IllegalStateException
                java.lang.String r8 = "call to 'resume' before 'invoke' with coroutine"
                r7.<init>(r8)
                throw r7
            L34:
                java.lang.Object r7 = r0.f12718u
                kotlin.jvm.internal.c0 r7 = (kotlin.jvm.internal.c0) r7
                java.lang.Object r2 = r0.f12717t
                dv.a0$d r2 = (dv.a0.d) r2
                zt.o.b(r8)
                goto L5a
            L40:
                zt.o.b(r8)
                kotlin.jvm.internal.c0<R> r8 = r6.f12715a
                pu.n<R, T, eu.b<? super R>, java.lang.Object> r2 = r6.b
                T r5 = r8.f21573a
                r0.f12717t = r6
                r0.f12718u = r8
                r0.f12721x = r4
                java.lang.Object r7 = r2.invoke(r5, r7, r0)
                if (r7 != r1) goto L56
                goto L6f
            L56:
                r2 = r8
                r8 = r7
                r7 = r2
                r2 = r6
            L5a:
                r7.f21573a = r8
                dv.i<R> r7 = r2.f12716c
                kotlin.jvm.internal.c0<R> r8 = r2.f12715a
                T r8 = r8.f21573a
                r2 = 0
                r0.f12717t = r2
                r0.f12718u = r2
                r0.f12721x = r3
                java.lang.Object r7 = r7.emit(r8, r0)
                if (r7 != r1) goto L70
            L6f:
                return r1
            L70:
                kotlin.Unit r7 = kotlin.Unit.f21504a
                return r7
            */
            throw new UnsupportedOperationException("Method not decompiled: dv.a0.d.emit(java.lang.Object, eu.b):java.lang.Object");
        }
    }

    @NotNull
    public static final <T> h<T> a(@NotNull h<? extends T> hVar) {
        return new a(hVar);
    }

    @NotNull
    public static final <T> h<T> b(@NotNull h<? extends T> hVar, @NotNull Function2<? super T, ? super eu.b<? super Unit>, ? extends Object> function2) {
        return new b(hVar, function2);
    }

    @NotNull
    public static final <T, R> h<R> c(@NotNull h<? extends T> hVar, R r10, @NotNull pu.n<? super R, ? super T, ? super eu.b<? super R>, ? extends Object> nVar) {
        return new c(r10, hVar, nVar);
    }


    // --- восстановлено из DEX (dv/a0$a$a) ---
    public static class a implements dv.i {
        dv.i a;
        public a(dv.i p0) { }
        public java.lang.Object emit(java.lang.Object p0, eu.b p1) { throw new UnsupportedOperationException("stub"); }
    }

    // --- восстановлено из DEX (dv/a0$a$a$a) ---
    public static class a extends gu.d {
        java.lang.Object t;
        int u;
        dv.a0.a.a v;
        public a(dv.a0.a.a p0, eu.b p1) { }
        public java.lang.Object invokeSuspend(java.lang.Object p0) { throw new UnsupportedOperationException("stub"); }
    }

    // --- восстановлено из DEX (dv/a0$b$a) ---
    public static class a implements dv.i {
        dv.i a;
        kotlin.jvm.functions.Function2 b;
        public a(dv.i p0, kotlin.jvm.functions.Function2 p1) { }
        public java.lang.Object emit(java.lang.Object p0, eu.b p1) { throw new UnsupportedOperationException("stub"); }
    }

    // --- восстановлено из DEX (dv/a0$b$a$a) ---
    public static class a extends gu.d {
        java.lang.Object t;
        int u;
        dv.a0.b.a v;
        java.lang.Object w;
        java.lang.Object x;
        public a(dv.a0.b.a p0, eu.b p1) { }
        public java.lang.Object invokeSuspend(java.lang.Object p0) { throw new UnsupportedOperationException("stub"); }
    }

    // --- восстановлено из DEX (dv/a0$c$a) ---
    public static class a extends gu.d {
        java.lang.Object t;
        int u;
        dv.a0.c v;
        java.lang.Object w;
        java.lang.Object x;
        java.lang.Object y;
        public a(dv.a0.c p0, eu.b p1) { }
        public java.lang.Object invokeSuspend(java.lang.Object p0) { throw new UnsupportedOperationException("stub"); }
    }

    // --- восстановлено из DEX (dv/a0$d$a) ---
    public static class a extends gu.d {
        java.lang.Object t;
        java.lang.Object u;
        java.lang.Object v;
        dv.a0.d w;
        int x;
        public a(dv.a0.d p0, eu.b p1) { }
        public java.lang.Object invokeSuspend(java.lang.Object p0) { throw new UnsupportedOperationException("stub"); }
    }
}
