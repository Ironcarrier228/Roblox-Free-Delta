package dv;

import av.d2;
import com.github.luben.zstd.BuildConfig;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.coroutines.CoroutineContext;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;

@Metadata(d1 = {"\u0000P\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\u001a=\u0010\t\u001a\b\u0012\u0004\u0012\u00028\u00000\b\"\u0004\b\u0000\u0010\u0000*\b\u0012\u0004\u0012\u00028\u00000\u00012\u0006\u0010\u0003\u001a\u00020\u00022\u0006\u0010\u0005\u001a\u00020\u00042\b\b\u0002\u0010\u0007\u001a\u00020\u0006¢\u0006\u0004\b\t\u0010\n\u001a-\u0010\f\u001a\b\u0012\u0004\u0012\u00028\u00000\u000b\"\u0004\b\u0000\u0010\u0000*\b\u0012\u0004\u0012\u00028\u00000\u00012\u0006\u0010\u0007\u001a\u00020\u0006H\u0002¢\u0006\u0004\b\f\u0010\r\u001aM\u0010\u0015\u001a\u00020\u0014\"\u0004\b\u0000\u0010\u0000*\u00020\u00022\u0006\u0010\u000f\u001a\u00020\u000e2\f\u0010\u0010\u001a\b\u0012\u0004\u0012\u00028\u00000\u00012\f\u0010\u0012\u001a\b\u0012\u0004\u0012\u00028\u00000\u00112\u0006\u0010\u0005\u001a\u00020\u00042\u0006\u0010\u0013\u001a\u00028\u0000H\u0002¢\u0006\u0004\b\u0015\u0010\u0016\u001a;\u0010\u0018\u001a\b\u0012\u0004\u0012\u00028\u00000\u0017\"\u0004\b\u0000\u0010\u0000*\b\u0012\u0004\u0012\u00028\u00000\u00012\u0006\u0010\u0003\u001a\u00020\u00022\u0006\u0010\u0005\u001a\u00020\u00042\u0006\u0010\u0013\u001a\u00028\u0000¢\u0006\u0004\b\u0018\u0010\u0019\u001a#\u0010\u001b\u001a\b\u0012\u0004\u0012\u00028\u00000\u0017\"\u0004\b\u0000\u0010\u0000*\b\u0012\u0004\u0012\u00028\u00000\u001a¢\u0006\u0004\b\u001b\u0010\u001c¨\u0006\u001d"}, d2 = {"T", "Ldv/h;", "Lav/p0;", "scope", "Ldv/m0;", "started", BuildConfig.FLAVOR, "replay", "Ldv/g0;", "d", "(Ldv/h;Lav/p0;Ldv/m0;I)Ldv/g0;", "Ldv/l0;", k6.b.f21144e, "(Ldv/h;I)Ldv/l0;", "Lkotlin/coroutines/CoroutineContext;", "context", "upstream", "Ldv/b0;", "shared", "initialValue", "Lav/d2;", "c", "(Lav/p0;Lkotlin/coroutines/CoroutineContext;Ldv/h;Ldv/b0;Ldv/m0;Ljava/lang/Object;)Lav/d2;", "Ldv/p0;", "f", "(Ldv/h;Lav/p0;Ldv/m0;Ljava/lang/Object;)Ldv/p0;", "Ldv/c0;", xe.a.f36648e, "(Ldv/c0;)Ldv/p0;", "kotlinx-coroutines-core"}, k = 5, mv = {2, 1, 0}, xi = 48, xs = "kotlinx/coroutines/flow/FlowKt")
/* loaded from: classes2.dex */
public final /* synthetic */ class z {

    @Metadata(d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0002\b\u0002\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\n¢\u0006\u0004\b\u0002\u0010\u0003"}, d2 = {"Lav/p0;", BuildConfig.FLAVOR, "<anonymous>", "(Lav/p0;)V"}, k = 3, mv = {2, 1, 0})
    @gu.f(c = "kotlinx.coroutines.flow.FlowKt__ShareKt$launchSharing$1", f = "Share.kt", l = {210, 214, 215, 221}, m = "invokeSuspend")
    public static final class a extends gu.m implements Function2<av.p0, eu.b<? super Unit>, Object> {

        /* renamed from: t, reason: collision with root package name */
        public int f12955t;

        /* renamed from: u, reason: collision with root package name */
        public final /* synthetic */ m0 f12956u;

        /* renamed from: v, reason: collision with root package name */
        public final /* synthetic */ h<T> f12957v;

        /* renamed from: w, reason: collision with root package name */
        public final /* synthetic */ b0<T> f12958w;

        /* renamed from: x, reason: collision with root package name */
        public final /* synthetic */ T f12959x;

        @Metadata(d1 = {"\u0000\f\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\b\u0010\u0000\u001a\u00020\u00012\u0006\u0010\u0002\u001a\u00020\u0003H\n"}, d2 = {"<anonymous>", BuildConfig.FLAVOR, "it", BuildConfig.FLAVOR}, k = 3, mv = {2, 1, 0}, xi = 48)
        @gu.f(c = "kotlinx.coroutines.flow.FlowKt__ShareKt$launchSharing$1$1", f = "Share.kt", l = {}, m = "invokeSuspend")
        /* renamed from: dv.z$a$a, reason: collision with other inner class name */
        public static final class C0249a extends gu.m implements Function2<Integer, eu.b<? super Boolean>, Object> {

            /* renamed from: t, reason: collision with root package name */
            public int f12960t;

            /* renamed from: u, reason: collision with root package name */
            public /* synthetic */ int f12961u;

            public C0249a(eu.b<? super C0249a> bVar) {
                super(2, bVar);
            }

            @Override // gu.a
            public final eu.b<Unit> create(Object obj, eu.b<?> bVar) {
                C0249a c0249a = new C0249a(bVar);
                c0249a.f12961u = ((Number) obj).intValue();
                return c0249a;
            }

            @Override // kotlin.jvm.functions.Function2
            public /* bridge */ /* synthetic */ Object invoke(Integer num, eu.b<? super Boolean> bVar) {
                return m(num.intValue(), bVar);
            }

            @Override // gu.a
            public final Object invokeSuspend(Object obj) {
                fu.c.e();
                if (this.f12960t != 0) {
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                zt.o.b(obj);
                return gu.b.a(this.f12961u > 0);
            }

            public final Object m(int i10, eu.b<? super Boolean> bVar) {
                return ((C0249a) create(Integer.valueOf(i10), bVar)).invokeSuspend(Unit.f21504a);
            }
        }

        @Metadata(d1 = {"\u0000\u000e\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0002\u0010\u0003\u001a\u00020\u00022\u0006\u0010\u0001\u001a\u00020\u0000H\n¢\u0006\u0004\b\u0003\u0010\u0004"}, d2 = {"Ldv/k0;", "it", BuildConfig.FLAVOR, "<anonymous>", "(Ldv/k0;)V"}, k = 3, mv = {2, 1, 0})
        @gu.f(c = "kotlinx.coroutines.flow.FlowKt__ShareKt$launchSharing$1$2", f = "Share.kt", l = {223}, m = "invokeSuspend")
        public static final class b extends gu.m implements Function2<k0, eu.b<? super Unit>, Object> {

            /* renamed from: t, reason: collision with root package name */
            public int f12962t;

            /* renamed from: u, reason: collision with root package name */
            public /* synthetic */ Object f12963u;

            /* renamed from: v, reason: collision with root package name */
            public final /* synthetic */ h<T> f12964v;

            /* renamed from: w, reason: collision with root package name */
            public final /* synthetic */ b0<T> f12965w;

            /* renamed from: x, reason: collision with root package name */
            public final /* synthetic */ T f12966x;

            @Metadata(k = 3, mv = {2, 1, 0}, xi = 48)
            /* renamed from: dv.z$a$b$a, reason: collision with other inner class name */
            public /* synthetic */ class C0250a {

                /* renamed from: a, reason: collision with root package name */
                public static final /* synthetic */ int[] f12967a;

                static {
                    int[] iArr = new int[k0.values().length];
                    try {
                        iArr[k0.f12768a.ordinal()] = 1;
                    } catch (NoSuchFieldError unused) {
                    }
                    try {
                        iArr[k0.b.ordinal()] = 2;
                    } catch (NoSuchFieldError unused2) {
                    }
                    try {
                        iArr[k0.f12769c.ordinal()] = 3;
                    } catch (NoSuchFieldError unused3) {
                    }
                    f12967a = iArr;
                }
            }

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            /* JADX WARN: Multi-variable type inference failed */
            public b(h<? extends T> hVar, b0<T> b0Var, T t8, eu.b<? super b> bVar) {
                super(2, bVar);
                this.f12964v = hVar;
                this.f12965w = b0Var;
                this.f12966x = t8;
            }

            @Override // gu.a
            public final eu.b<Unit> create(Object obj, eu.b<?> bVar) {
                b bVar2 = new b(this.f12964v, this.f12965w, this.f12966x, bVar);
                bVar2.f12963u = obj;
                return bVar2;
            }

            @Override // gu.a
            public final Object invokeSuspend(Object obj) {
                Object e10 = fu.c.e();
                int i10 = this.f12962t;
                if (i10 == 0) {
                    zt.o.b(obj);
                    int i11 = C0250a.f12967a[((k0) this.f12963u).ordinal()];
                    if (i11 == 1) {
                        h<T> hVar = this.f12964v;
                        i iVar = this.f12965w;
                        this.f12962t = 1;
                        if (hVar.collect(iVar, this) == e10) {
                            return e10;
                        }
                    } else if (i11 != 2) {
                        if (i11 != 3) {
                            throw new zt.l();
                        }
                        T t8 = this.f12966x;
                        if (t8 == i0.f12765a) {
                            this.f12965w.k();
                        } else {
                            gu.b.a(this.f12965w.a(t8));
                        }
                    }
                } else {
                    if (i10 != 1) {
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                    zt.o.b(obj);
                }
                return Unit.f21504a;
            }

            @Override // kotlin.jvm.functions.Function2
            /* renamed from: m, reason: merged with bridge method [inline-methods] */
            public final Object invoke(k0 k0Var, eu.b<? super Unit> bVar) {
                return ((b) create(k0Var, bVar)).invokeSuspend(Unit.f21504a);
            }
        }

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        /* JADX WARN: Multi-variable type inference failed */
        public a(m0 m0Var, h<? extends T> hVar, b0<T> b0Var, T t8, eu.b<? super a> bVar) {
            super(2, bVar);
            this.f12956u = m0Var;
            this.f12957v = hVar;
            this.f12958w = b0Var;
            this.f12959x = t8;
        }

        @Override // gu.a
        public final eu.b<Unit> create(Object obj, eu.b<?> bVar) {
            return new a(this.f12956u, this.f12957v, this.f12958w, this.f12959x, bVar);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(av.p0 p0Var, eu.b<? super Unit> bVar) {
            return ((a) create(p0Var, bVar)).invokeSuspend(Unit.f21504a);
        }

        /* JADX WARN: Code restructure failed: missing block: B:12:0x0066, code lost:
        
            if (r8.collect(r1, r7) == r0) goto L28;
         */
        /* JADX WARN: Code restructure failed: missing block: B:20:0x003c, code lost:
        
            if (r8.collect(r1, r7) == r0) goto L28;
         */
        /* JADX WARN: Code restructure failed: missing block: B:24:0x0059, code lost:
        
            if (dv.j.u(r8, r1, r7) == r0) goto L28;
         */
        /* JADX WARN: Code restructure failed: missing block: B:26:0x008a, code lost:
        
            if (dv.j.j(r8, r1, r7) == r0) goto L28;
         */
        @Override // gu.a
        /*
            Code decompiled incorrectly, please refer to instructions dump.
            To view partially-correct add '--show-bad-code' argument
        */
        public final java.lang.Object invokeSuspend(java.lang.Object r8) {
            /*
                r7 = this;
                java.lang.Object r0 = fu.c.e()
                int r1 = r7.f12955t
                r2 = 4
                r3 = 3
                r4 = 2
                r5 = 1
                if (r1 == 0) goto L25
                if (r1 == r5) goto L21
                if (r1 == r4) goto L1d
                if (r1 == r3) goto L21
                if (r1 != r2) goto L15
                goto L21
            L15:
                java.lang.IllegalStateException r8 = new java.lang.IllegalStateException
                java.lang.String r0 = "call to 'resume' before 'invoke' with coroutine"
                r8.<init>(r0)
                throw r8
            L1d:
                zt.o.b(r8)
                goto L5c
            L21:
                zt.o.b(r8)
                goto L8d
            L25:
                zt.o.b(r8)
                dv.m0 r8 = r7.f12956u
                dv.m0$a r1 = dv.m0.INSTANCE
                dv.m0 r6 = r1.a()
                if (r8 != r6) goto L3f
                dv.h<T> r8 = r7.f12957v
                dv.b0<T> r1 = r7.f12958w
                r7.f12955t = r5
                java.lang.Object r8 = r8.collect(r1, r7)
                if (r8 != r0) goto L8d
                goto L8c
            L3f:
                dv.m0 r8 = r7.f12956u
                dv.m0 r1 = r1.b()
                r5 = 0
                if (r8 != r1) goto L69
                dv.b0<T> r8 = r7.f12958w
                dv.p0 r8 = r8.f()
                dv.z$a$a r1 = new dv.z$a$a
                r1.<init>(r5)
                r7.f12955t = r4
                java.lang.Object r8 = dv.j.u(r8, r1, r7)
                if (r8 != r0) goto L5c
                goto L8c
            L5c:
                dv.h<T> r8 = r7.f12957v
                dv.b0<T> r1 = r7.f12958w
                r7.f12955t = r3
                java.lang.Object r8 = r8.collect(r1, r7)
                if (r8 != r0) goto L8d
                goto L8c
            L69:
                dv.m0 r8 = r7.f12956u
                dv.b0<T> r1 = r7.f12958w
                dv.p0 r1 = r1.f()
                dv.h r8 = r8.a(r1)
                dv.h r8 = dv.j.m(r8)
                dv.z$a$b r1 = new dv.z$a$b
                dv.h<T> r3 = r7.f12957v
                dv.b0<T> r4 = r7.f12958w
                T r6 = r7.f12959x
                r1.<init>(r3, r4, r6, r5)
                r7.f12955t = r2
                java.lang.Object r8 = dv.j.j(r8, r1, r7)
                if (r8 != r0) goto L8d
            L8c:
                return r0
            L8d:
                kotlin.Unit r8 = kotlin.Unit.f21504a
                return r8
            */
            throw new UnsupportedOperationException("Method not decompiled: dv.z.a.invokeSuspend(java.lang.Object):java.lang.Object");
        }
    }

    @NotNull
    public static final <T> p0<T> a(@NotNull c0<T> c0Var) {
        return new e0(c0Var, null);
    }

    /* JADX WARN: Code restructure failed: missing block: B:16:0x002d, code lost:
    
        if (r3 == 0) goto L15;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public static final <T> dv.l0<T> b(dv.h<? extends T> r7, int r8) {
        /*
            cv.g$b r0 = cv.g.INSTANCE
            int r0 = r0.a()
            int r0 = kotlin.ranges.d.c(r8, r0)
            int r0 = r0 - r8
            boolean r1 = r7 instanceof kotlin.e
            if (r1 == 0) goto L3c
            r1 = r7
            ev.e r1 = (kotlin.e) r1
            dv.h r2 = r1.i()
            if (r2 == 0) goto L3c
            dv.l0 r7 = new dv.l0
            int r3 = r1.capacity
            r4 = -3
            if (r3 == r4) goto L26
            r4 = -2
            if (r3 == r4) goto L26
            if (r3 == 0) goto L26
            r0 = r3
            goto L34
        L26:
            cv.a r4 = r1.onBufferOverflow
            cv.a r5 = cv.a.f11531a
            r6 = 0
            if (r4 != r5) goto L31
            if (r3 != 0) goto L34
        L2f:
            r0 = r6
            goto L34
        L31:
            if (r8 != 0) goto L2f
            r0 = 1
        L34:
            cv.a r8 = r1.onBufferOverflow
            kotlin.coroutines.CoroutineContext r1 = r1.context
            r7.<init>(r2, r0, r8, r1)
            return r7
        L3c:
            dv.l0 r8 = new dv.l0
            cv.a r1 = cv.a.f11531a
            kotlin.coroutines.e r2 = kotlin.coroutines.e.f21546a
            r8.<init>(r7, r0, r1, r2)
            return r8
        */
        throw new UnsupportedOperationException("Method not decompiled: dv.z.b(dv.h, int):dv.l0");
    }

    public static final <T> d2 c(av.p0 p0Var, CoroutineContext coroutineContext, h<? extends T> hVar, b0<T> b0Var, m0 m0Var, T t8) {
        return av.i.c(p0Var, coroutineContext, Intrinsics.c(m0Var, m0.INSTANCE.a()) ? av.r0.f3475a : av.r0.f3477d, new a(m0Var, hVar, b0Var, t8, null));
    }

    @NotNull
    public static final <T> g0<T> d(@NotNull h<? extends T> hVar, @NotNull av.p0 p0Var, @NotNull m0 m0Var, int i10) {
        l0 b = b(hVar, i10);
        b0 a10 = i0.a(i10, b.extraBufferCapacity, b.onBufferOverflow);
        return new d0(a10, c(p0Var, b.context, b.upstream, a10, m0Var, i0.f12765a));
    }

    public static /* synthetic */ g0 e(h hVar, av.p0 p0Var, m0 m0Var, int i10, int i11, Object obj) {
        if ((i11 & 4) != 0) {
            i10 = 0;
        }
        return j.K(hVar, p0Var, m0Var, i10);
    }

    @NotNull
    public static final <T> p0<T> f(@NotNull h<? extends T> hVar, @NotNull av.p0 p0Var, @NotNull m0 m0Var, T t8) {
        l0 b = b(hVar, 1);
        c0 a10 = r0.a(t8);
        return new e0(a10, c(p0Var, b.context, b.upstream, a10, m0Var, t8));
    }


    // --- восстановлено из DEX (dv/z$a$a) ---
    public static class a extends gu.m implements kotlin.jvm.functions.Function2 {
        int t;
        int u;
        public a(eu.b p0) { }
        public eu.b create(java.lang.Object p0, eu.b p1) { throw new UnsupportedOperationException("stub"); }
        public java.lang.Object invoke(java.lang.Object p0, java.lang.Object p1) { throw new UnsupportedOperationException("stub"); }
        public java.lang.Object invokeSuspend(java.lang.Object p0) { throw new UnsupportedOperationException("stub"); }
        public java.lang.Object m(int p0, eu.b p1) { throw new UnsupportedOperationException("stub"); }
    }

    // --- восстановлено из DEX (dv/z$a$b) ---
    public static class b extends gu.m implements kotlin.jvm.functions.Function2 {
        int t;
        java.lang.Object u;
        dv.h v;
        dv.b0 w;
        java.lang.Object x;
        public b(dv.h p0, dv.b0 p1, java.lang.Object p2, eu.b p3) { }
        public eu.b create(java.lang.Object p0, eu.b p1) { throw new UnsupportedOperationException("stub"); }
        public java.lang.Object invoke(java.lang.Object p0, java.lang.Object p1) { throw new UnsupportedOperationException("stub"); }
        public java.lang.Object invokeSuspend(java.lang.Object p0) { throw new UnsupportedOperationException("stub"); }
        public java.lang.Object m(dv.k0 p0, eu.b p1) { throw new UnsupportedOperationException("stub"); }
    }

    // --- восстановлено из DEX (dv/z$a$b$a) ---
    public static class a {
        int[] a;
    }
}
