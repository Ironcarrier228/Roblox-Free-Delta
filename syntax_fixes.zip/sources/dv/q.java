package dv;

import av.e3;
import com.github.luben.zstd.BuildConfig;
import com.google.mlkit.common.MlKitException;
import com.withpersona.sdk2.inquiry.network.core.HttpStatusCode;
import cv.k;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.functions.Function2;
import org.jetbrains.annotations.NotNull;

@Metadata(d1 = {"\u0000\u001e\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\t\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0004\u001a-\u0010\u0004\u001a\b\u0012\u0004\u0012\u00028\u00000\u0001\"\u0004\b\u0000\u0010\u0000*\b\u0012\u0004\u0012\u00028\u00000\u00012\u0006\u0010\u0003\u001a\u00020\u0002H\u0007¢\u0006\u0004\b\u0004\u0010\u0005\u001a9\u0010\b\u001a\b\u0012\u0004\u0012\u00028\u00000\u0001\"\u0004\b\u0000\u0010\u0000*\b\u0012\u0004\u0012\u00028\u00000\u00012\u0012\u0010\u0007\u001a\u000e\u0012\u0004\u0012\u00028\u0000\u0012\u0004\u0012\u00020\u00020\u0006H\u0002¢\u0006\u0004\b\b\u0010\t\u001a-\u0010\f\u001a\b\u0012\u0004\u0012\u00028\u00000\u0001\"\u0004\b\u0000\u0010\u0000*\b\u0012\u0004\u0012\u00028\u00000\u00012\u0006\u0010\u000b\u001a\u00020\nH\u0007¢\u0006\u0004\b\f\u0010\u0005\u001a-\u0010\r\u001a\b\u0012\u0004\u0012\u00028\u00000\u0001\"\u0004\b\u0000\u0010\u0000*\b\u0012\u0004\u0012\u00028\u00000\u00012\u0006\u0010\u000b\u001a\u00020\nH\u0002¢\u0006\u0004\b\r\u0010\u0005¨\u0006\u000e"}, d2 = {"T", "Ldv/h;", BuildConfig.FLAVOR, "timeoutMillis", k6.b.f21144e, "(Ldv/h;J)Ldv/h;", "Lkotlin/Function1;", "timeoutMillisSelector", "d", "(Ldv/h;Lkotlin/jvm/functions/Function1;)Ldv/h;", "Lkotlin/time/a;", "timeout", "e", "f", "kotlinx-coroutines-core"}, k = 5, mv = {2, 1, 0}, xi = 48, xs = "kotlinx/coroutines/flow/FlowKt")
/* loaded from: classes2.dex */
public final /* synthetic */ class q {

    /* JADX INFO: Add missing generic type declarations: [T] */
    @Metadata(d1 = {"\u0000\u0014\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0002\u0010\u0005\u001a\u00020\u0004\"\u0004\b\u0000\u0010\u0000*\u00020\u00012\f\u0010\u0003\u001a\b\u0012\u0004\u0012\u00028\u00000\u0002H\n¢\u0006\u0004\b\u0005\u0010\u0006"}, d2 = {"T", "Lav/p0;", "Ldv/i;", "downstream", BuildConfig.FLAVOR, "<anonymous>", "(Lav/p0;Ldv/i;)V"}, k = 3, mv = {2, 1, 0})
    @gu.f(c = "kotlinx.coroutines.flow.FlowKt__DelayKt$debounceInternal$1", f = "Delay.kt", l = {215, 415}, m = "invokeSuspend")
    public static final class a<T> extends gu.m implements pu.n<av.p0, i<? super T>, eu.b<? super Unit>, Object> {

        /* renamed from: t, reason: collision with root package name */
        public Object f12798t;

        /* renamed from: u, reason: collision with root package name */
        public Object f12799u;

        /* renamed from: v, reason: collision with root package name */
        public int f12800v;

        /* renamed from: w, reason: collision with root package name */
        public /* synthetic */ Object f12801w;

        /* renamed from: x, reason: collision with root package name */
        public /* synthetic */ Object f12802x;

        /* renamed from: y, reason: collision with root package name */
        public final /* synthetic */ Function1<T, Long> f12803y;

        /* renamed from: z, reason: collision with root package name */
        public final /* synthetic */ h<T> f12804z;

        @Metadata(d1 = {"\u0000\u0006\n\u0000\n\u0002\u0010\u0002\u0010\u0000\u001a\u00020\u0001H\n"}, d2 = {"<anonymous>", BuildConfig.FLAVOR}, k = 3, mv = {2, 1, 0}, xi = 48)
        @gu.f(c = "kotlinx.coroutines.flow.FlowKt__DelayKt$debounceInternal$1$3$1", f = "Delay.kt", l = {226}, m = "invokeSuspend")
        /* renamed from: dv.q$a$a, reason: collision with other inner class name */
        public static final class C0243a extends gu.m implements Function1<eu.b<? super Unit>, Object> {

            /* renamed from: t, reason: collision with root package name */
            public int f12805t;

            /* renamed from: u, reason: collision with root package name */
            public final /* synthetic */ i<T> f12806u;

            /* renamed from: v, reason: collision with root package name */
            public final /* synthetic */ kotlin.jvm.internal.c0<Object> f12807v;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            /* JADX WARN: Multi-variable type inference failed */
            public C0243a(i<? super T> iVar, kotlin.jvm.internal.c0<Object> c0Var, eu.b<? super C0243a> bVar) {
                super(1, bVar);
                this.f12806u = iVar;
                this.f12807v = c0Var;
            }

            @Override // gu.a
            public final eu.b<Unit> create(eu.b<?> bVar) {
                return new C0243a(this.f12806u, this.f12807v, bVar);
            }

            @Override // gu.a
            public final Object invokeSuspend(Object obj) {
                Object e10 = fu.c.e();
                int i10 = this.f12805t;
                if (i10 == 0) {
                    zt.o.b(obj);
                    i<T> iVar = this.f12806u;
                    gv.e0 e0Var = kotlin.t.f14750a;
                    T t8 = this.f12807v.f21573a;
                    if (t8 == e0Var) {
                        t8 = null;
                    }
                    this.f12805t = 1;
                    if (iVar.emit(t8, this) == e10) {
                        return e10;
                    }
                } else {
                    if (i10 != 1) {
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                    zt.o.b(obj);
                }
                this.f12807v.f21573a = null;
                return Unit.f21504a;
            }

            @Override // kotlin.jvm.functions.Function1
            /* renamed from: m, reason: merged with bridge method [inline-methods] */
            public final Object invoke(eu.b<? super Unit> bVar) {
                return ((C0243a) create(bVar)).invokeSuspend(Unit.f21504a);
            }
        }

        @Metadata(d1 = {"\u0000\u0012\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0002\u0010\u0004\u001a\u00020\u00032\f\u0010\u0002\u001a\b\u0012\u0004\u0012\u00020\u00010\u0000H\n¢\u0006\u0004\b\u0004\u0010\u0005"}, d2 = {"Lcv/k;", BuildConfig.FLAVOR, "value", BuildConfig.FLAVOR, "<anonymous>", "(Lcv/k;)V"}, k = 3, mv = {2, 1, 0})
        @gu.f(c = "kotlinx.coroutines.flow.FlowKt__DelayKt$debounceInternal$1$3$2", f = "Delay.kt", l = {236}, m = "invokeSuspend")
        public static final class b extends gu.m implements Function2<cv.k<? extends Object>, eu.b<? super Unit>, Object> {

            /* renamed from: t, reason: collision with root package name */
            public Object f12808t;

            /* renamed from: u, reason: collision with root package name */
            public int f12809u;

            /* renamed from: v, reason: collision with root package name */
            public /* synthetic */ Object f12810v;

            /* renamed from: w, reason: collision with root package name */
            public final /* synthetic */ kotlin.jvm.internal.c0<Object> f12811w;

            /* renamed from: x, reason: collision with root package name */
            public final /* synthetic */ i<T> f12812x;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            /* JADX WARN: Multi-variable type inference failed */
            public b(kotlin.jvm.internal.c0<Object> c0Var, i<? super T> iVar, eu.b<? super b> bVar) {
                super(2, bVar);
                this.f12811w = c0Var;
                this.f12812x = iVar;
            }

            @Override // gu.a
            public final eu.b<Unit> create(Object obj, eu.b<?> bVar) {
                b bVar2 = new b(this.f12811w, this.f12812x, bVar);
                bVar2.f12810v = obj;
                return bVar2;
            }

            @Override // kotlin.jvm.functions.Function2
            public /* bridge */ /* synthetic */ Object invoke(cv.k<? extends Object> kVar, eu.b<? super Unit> bVar) {
                return m(kVar.getHolder(), bVar);
            }

            /* JADX WARN: Multi-variable type inference failed */
            @Override // gu.a
            public final Object invokeSuspend(Object obj) {
                kotlin.jvm.internal.c0<Object> c0Var;
                kotlin.jvm.internal.c0<Object> c0Var2;
                Object e10 = fu.c.e();
                int i10 = this.f12809u;
                if (i10 == 0) {
                    zt.o.b(obj);
                    T t8 = (T) ((cv.k) this.f12810v).getHolder();
                    c0Var = this.f12811w;
                    boolean z10 = t8 instanceof k.c;
                    if (!z10) {
                        c0Var.f21573a = t8;
                    }
                    i<T> iVar = this.f12812x;
                    if (z10) {
                        Throwable e11 = cv.k.e(t8);
                        if (e11 != null) {
                            throw e11;
                        }
                        Object obj2 = c0Var.f21573a;
                        if (obj2 != null) {
                            if (obj2 == kotlin.t.f14750a) {
                                obj2 = null;
                            }
                            this.f12810v = t8;
                            this.f12808t = c0Var;
                            this.f12809u = 1;
                            if (iVar.emit(obj2, this) == e10) {
                                return e10;
                            }
                            c0Var2 = c0Var;
                        }
                        c0Var.f21573a = (T) kotlin.t.f14751c;
                    }
                    return Unit.f21504a;
                }
                if (i10 != 1) {
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                c0Var2 = (kotlin.jvm.internal.c0) this.f12808t;
                zt.o.b(obj);
                c0Var = c0Var2;
                c0Var.f21573a = (T) kotlin.t.f14751c;
                return Unit.f21504a;
            }

            public final Object m(Object obj, eu.b<? super Unit> bVar) {
                return ((b) create(cv.k.b(obj), bVar)).invokeSuspend(Unit.f21504a);
            }
        }

        @Metadata(d1 = {"\u0000\u0010\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\u0010\u0002\n\u0002\b\u0002\u0010\u0003\u001a\u00020\u0002*\b\u0012\u0004\u0012\u00020\u00010\u0000H\n¢\u0006\u0004\b\u0003\u0010\u0004"}, d2 = {"Lcv/v;", BuildConfig.FLAVOR, BuildConfig.FLAVOR, "<anonymous>", "(Lcv/v;)V"}, k = 3, mv = {2, 1, 0})
        @gu.f(c = "kotlinx.coroutines.flow.FlowKt__DelayKt$debounceInternal$1$values$1", f = "Delay.kt", l = {MlKitException.CODE_SCANNER_TASK_IN_PROGRESS}, m = "invokeSuspend")
        public static final class c extends gu.m implements Function2<cv.v<? super Object>, eu.b<? super Unit>, Object> {

            /* renamed from: t, reason: collision with root package name */
            public int f12813t;

            /* renamed from: u, reason: collision with root package name */
            public /* synthetic */ Object f12814u;

            /* renamed from: v, reason: collision with root package name */
            public final /* synthetic */ h<T> f12815v;

            @Metadata(k = 3, mv = {2, 1, 0}, xi = 48)
            /* renamed from: dv.q$a$c$a, reason: collision with other inner class name */
            public static final class C0244a<T> implements i {

                /* renamed from: a, reason: collision with root package name */
                public final /* synthetic */ cv.v<Object> f12816a;

                @Metadata(k = 3, mv = {2, 1, 0}, xi = 48)
                @gu.f(c = "kotlinx.coroutines.flow.FlowKt__DelayKt$debounceInternal$1$values$1$1", f = "Delay.kt", l = {MlKitException.CODE_SCANNER_TASK_IN_PROGRESS}, m = "emit")
                /* renamed from: dv.q$a$c$a$a, reason: collision with other inner class name */
                public static final class C0245a extends gu.d {

                    /* renamed from: t, reason: collision with root package name */
                    public /* synthetic */ Object f12817t;

                    /* renamed from: u, reason: collision with root package name */
                    public final /* synthetic */ C0244a<T> f12818u;

                    /* renamed from: v, reason: collision with root package name */
                    public int f12819v;

                    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                    /* JADX WARN: Multi-variable type inference failed */
                    public C0245a(C0244a<? super T> c0244a, eu.b<? super C0245a> bVar) {
                        super(bVar);
                        this.f12818u = c0244a;
                    }

                    @Override // gu.a
                    public final Object invokeSuspend(Object obj) {
                        this.f12817t = obj;
                        this.f12819v |= Integer.MIN_VALUE;
                        return this.f12818u.emit(null, this);
                    }
                }

                public C0244a(cv.v<Object> vVar) {
                    this.f12816a = vVar;
                }

                /* JADX WARN: Removed duplicated region for block: B:15:0x0031  */
                /* JADX WARN: Removed duplicated region for block: B:8:0x0023  */
                @Override // dv.i
                /*
                    Code decompiled incorrectly, please refer to instructions dump.
                    To view partially-correct add '--show-bad-code' argument
                */
                public final java.lang.Object emit(T r5, eu.b<? super kotlin.Unit> r6) {
                    /*
                        r4 = this;
                        boolean r0 = r6 instanceof dv.q.a.c.C0244a.C0245a
                        if (r0 == 0) goto L13
                        r0 = r6
                        dv.q$a$c$a$a r0 = (dv.q.a.c.C0244a.C0245a) r0
                        int r1 = r0.f12819v
                        r2 = -2147483648(0xffffffff80000000, float:-0.0)
                        r3 = r1 & r2
                        if (r3 == 0) goto L13
                        int r1 = r1 - r2
                        r0.f12819v = r1
                        goto L18
                    L13:
                        dv.q$a$c$a$a r0 = new dv.q$a$c$a$a
                        r0.<init>(r4, r6)
                    L18:
                        java.lang.Object r6 = r0.f12817t
                        java.lang.Object r1 = fu.c.e()
                        int r2 = r0.f12819v
                        r3 = 1
                        if (r2 == 0) goto L31
                        if (r2 != r3) goto L29
                        zt.o.b(r6)
                        goto L43
                    L29:
                        java.lang.IllegalStateException r5 = new java.lang.IllegalStateException
                        java.lang.String r6 = "call to 'resume' before 'invoke' with coroutine"
                        r5.<init>(r6)
                        throw r5
                    L31:
                        zt.o.b(r6)
                        cv.v<java.lang.Object> r6 = r4.f12816a
                        if (r5 != 0) goto L3a
                        gv.e0 r5 = kotlin.t.f14750a
                    L3a:
                        r0.f12819v = r3
                        java.lang.Object r5 = r6.m(r5, r0)
                        if (r5 != r1) goto L43
                        return r1
                    L43:
                        kotlin.Unit r5 = kotlin.Unit.f21504a
                        return r5
                    */
                    throw new UnsupportedOperationException("Method not decompiled: dv.q.a.c.C0244a.emit(java.lang.Object, eu.b):java.lang.Object");
                }
            }

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            /* JADX WARN: Multi-variable type inference failed */
            public c(h<? extends T> hVar, eu.b<? super c> bVar) {
                super(2, bVar);
                this.f12815v = hVar;
            }

            @Override // gu.a
            public final eu.b<Unit> create(Object obj, eu.b<?> bVar) {
                c cVar = new c(this.f12815v, bVar);
                cVar.f12814u = obj;
                return cVar;
            }

            @Override // gu.a
            public final Object invokeSuspend(Object obj) {
                Object e10 = fu.c.e();
                int i10 = this.f12813t;
                if (i10 == 0) {
                    zt.o.b(obj);
                    cv.v vVar = (cv.v) this.f12814u;
                    h<T> hVar = this.f12815v;
                    C0244a c0244a = new C0244a(vVar);
                    this.f12813t = 1;
                    if (hVar.collect(c0244a, this) == e10) {
                        return e10;
                    }
                } else {
                    if (i10 != 1) {
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                    zt.o.b(obj);
                }
                return Unit.f21504a;
            }

            @Override // kotlin.jvm.functions.Function2
            /* renamed from: m, reason: merged with bridge method [inline-methods] */
            public final Object invoke(cv.v<Object> vVar, eu.b<? super Unit> bVar) {
                return ((c) create(vVar, bVar)).invokeSuspend(Unit.f21504a);
            }
        }

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        /* JADX WARN: Multi-variable type inference failed */
        public a(Function1<? super T, Long> function1, h<? extends T> hVar, eu.b<? super a> bVar) {
            super(3, bVar);
            this.f12803y = function1;
            this.f12804z = hVar;
        }

        /* JADX WARN: Code restructure failed: missing block: B:22:0x009f, code lost:
        
            if (r7.emit(r15, r14) == r0) goto L38;
         */
        /* JADX WARN: Code restructure failed: missing block: B:24:0x00e4, code lost:
        
            return r0;
         */
        /* JADX WARN: Code restructure failed: missing block: B:33:0x00e2, code lost:
        
            if (r7.o(r14) != r0) goto L7;
         */
        /* JADX WARN: Removed duplicated region for block: B:31:0x00be  */
        /* JADX WARN: Removed duplicated region for block: B:34:0x00e5  */
        /* JADX WARN: Removed duplicated region for block: B:9:0x0066  */
        /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:33:0x00e2 -> B:6:0x001e). Please report as a decompilation issue!!! */
        @Override // gu.a
        /*
            Code decompiled incorrectly, please refer to instructions dump.
            To view partially-correct add '--show-bad-code' argument
        */
        public final java.lang.Object invokeSuspend(java.lang.Object r15) {
            /*
                Method dump skipped, instructions count: 232
                To view this dump add '--comments-level debug' option
            */
            throw new UnsupportedOperationException("Method not decompiled: dv.q.a.invokeSuspend(java.lang.Object):java.lang.Object");
        }

        @Override // pu.n
        /* renamed from: m, reason: merged with bridge method [inline-methods] */
        public final Object invoke(av.p0 p0Var, i<? super T> iVar, eu.b<? super Unit> bVar) {
            a aVar = new a(this.f12803y, this.f12804z, bVar);
            aVar.f12801w = p0Var;
            aVar.f12802x = iVar;
            return aVar.invokeSuspend(Unit.f21504a);
        }
    }

    /* JADX INFO: Add missing generic type declarations: [T] */
    @Metadata(d1 = {"\u0000\u0014\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0002\u0010\u0005\u001a\u00020\u0004\"\u0004\b\u0000\u0010\u0000*\u00020\u00012\f\u0010\u0003\u001a\b\u0012\u0004\u0012\u00028\u00000\u0002H\n¢\u0006\u0004\b\u0005\u0010\u0006"}, d2 = {"T", "Lav/p0;", "Ldv/i;", "downStream", BuildConfig.FLAVOR, "<anonymous>", "(Lav/p0;Ldv/i;)V"}, k = 3, mv = {2, 1, 0})
    @gu.f(c = "kotlinx.coroutines.flow.FlowKt__DelayKt$timeoutInternal$1", f = "Delay.kt", l = {HttpStatusCode.PAYLOAD_TOO_LARGE_413}, m = "invokeSuspend")
    public static final class b<T> extends gu.m implements pu.n<av.p0, i<? super T>, eu.b<? super Unit>, Object> {

        /* renamed from: t, reason: collision with root package name */
        public long f12820t;

        /* renamed from: u, reason: collision with root package name */
        public int f12821u;

        /* renamed from: v, reason: collision with root package name */
        public /* synthetic */ Object f12822v;

        /* renamed from: w, reason: collision with root package name */
        public /* synthetic */ Object f12823w;

        /* renamed from: x, reason: collision with root package name */
        public final /* synthetic */ long f12824x;

        /* renamed from: y, reason: collision with root package name */
        public final /* synthetic */ h<T> f12825y;

        @Metadata(d1 = {"\u0000\u0010\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0002\u0010\u0004\u001a\u00020\u0003\"\u0004\b\u0000\u0010\u00002\f\u0010\u0002\u001a\b\u0012\u0004\u0012\u00028\u00000\u0001H\n¢\u0006\u0004\b\u0004\u0010\u0005"}, d2 = {"T", "Lcv/k;", "value", BuildConfig.FLAVOR, "<anonymous>", "(Lcv/k;)Z"}, k = 3, mv = {2, 1, 0})
        @gu.f(c = "kotlinx.coroutines.flow.FlowKt__DelayKt$timeoutInternal$1$1$1", f = "Delay.kt", l = {395}, m = "invokeSuspend")
        public static final class a extends gu.m implements Function2<cv.k<? extends T>, eu.b<? super Boolean>, Object> {

            /* renamed from: t, reason: collision with root package name */
            public int f12826t;

            /* renamed from: u, reason: collision with root package name */
            public /* synthetic */ Object f12827u;

            /* renamed from: v, reason: collision with root package name */
            public final /* synthetic */ i<T> f12828v;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            /* JADX WARN: Multi-variable type inference failed */
            public a(i<? super T> iVar, eu.b<? super a> bVar) {
                super(2, bVar);
                this.f12828v = iVar;
            }

            @Override // gu.a
            public final eu.b<Unit> create(Object obj, eu.b<?> bVar) {
                a aVar = new a(this.f12828v, bVar);
                aVar.f12827u = obj;
                return aVar;
            }

            @Override // kotlin.jvm.functions.Function2
            public /* bridge */ /* synthetic */ Object invoke(Object obj, eu.b<? super Boolean> bVar) {
                return m(((cv.k) obj).getHolder(), bVar);
            }

            /* JADX WARN: Multi-variable type inference failed */
            /* JADX WARN: Removed duplicated region for block: B:14:0x0049  */
            /* JADX WARN: Removed duplicated region for block: B:8:0x003c  */
            @Override // gu.a
            /*
                Code decompiled incorrectly, please refer to instructions dump.
                To view partially-correct add '--show-bad-code' argument
            */
            public final java.lang.Object invokeSuspend(java.lang.Object r5) {
                /*
                    r4 = this;
                    java.lang.Object r0 = fu.c.e()
                    int r1 = r4.f12826t
                    r2 = 1
                    if (r1 == 0) goto L19
                    if (r1 != r2) goto L11
                    java.lang.Object r0 = r4.f12827u
                    zt.o.b(r5)
                    goto L36
                L11:
                    java.lang.IllegalStateException r5 = new java.lang.IllegalStateException
                    java.lang.String r0 = "call to 'resume' before 'invoke' with coroutine"
                    r5.<init>(r0)
                    throw r5
                L19:
                    zt.o.b(r5)
                    java.lang.Object r5 = r4.f12827u
                    cv.k r5 = (cv.k) r5
                    java.lang.Object r5 = r5.getHolder()
                    dv.i<T> r1 = r4.f12828v
                    boolean r3 = r5 instanceof cv.k.c
                    if (r3 != 0) goto L37
                    r4.f12827u = r5
                    r4.f12826t = r2
                    java.lang.Object r1 = r1.emit(r5, r4)
                    if (r1 != r0) goto L35
                    return r0
                L35:
                    r0 = r5
                L36:
                    r5 = r0
                L37:
                    boolean r0 = r5 instanceof cv.k.Closed
                    if (r0 == 0) goto L49
                    java.lang.Throwable r5 = cv.k.e(r5)
                    if (r5 != 0) goto L48
                    r5 = 0
                    java.lang.Boolean r5 = gu.b.a(r5)
                    return r5
                L48:
                    throw r5
                L49:
                    java.lang.Boolean r5 = gu.b.a(r2)
                    return r5
                */
                throw new UnsupportedOperationException("Method not decompiled: dv.q.b.a.invokeSuspend(java.lang.Object):java.lang.Object");
            }

            public final Object m(Object obj, eu.b<? super Boolean> bVar) {
                return ((a) create(cv.k.b(obj), bVar)).invokeSuspend(Unit.f21504a);
            }
        }

        @Metadata(d1 = {"\u0000\u0006\n\u0000\n\u0002\u0010\u0001\u0010\u0000\u001a\u00020\u0001H\n"}, d2 = {"<anonymous>", BuildConfig.FLAVOR}, k = 3, mv = {2, 1, 0}, xi = 48)
        @gu.f(c = "kotlinx.coroutines.flow.FlowKt__DelayKt$timeoutInternal$1$1$2", f = "Delay.kt", l = {}, m = "invokeSuspend")
        /* renamed from: dv.q$b$b, reason: collision with other inner class name */
        public static final class C0246b extends gu.m implements Function1<eu.b<?>, Object> {

            /* renamed from: t, reason: collision with root package name */
            public int f12829t;

            /* renamed from: u, reason: collision with root package name */
            public final /* synthetic */ long f12830u;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            public C0246b(long j10, eu.b<? super C0246b> bVar) {
                super(1, bVar);
                this.f12830u = j10;
            }

            @Override // gu.a
            public final eu.b<Unit> create(eu.b<?> bVar) {
                return new C0246b(this.f12830u, bVar);
            }

            @Override // gu.a
            public final Object invokeSuspend(Object obj) {
                fu.c.e();
                if (this.f12829t != 0) {
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                zt.o.b(obj);
                throw new e3("Timed out waiting for " + ((Object) kotlin.time.a.R(this.f12830u)));
            }

            @Override // kotlin.jvm.functions.Function1
            /* renamed from: m, reason: merged with bridge method [inline-methods] */
            public final Object invoke(eu.b<?> bVar) {
                return ((C0246b) create(bVar)).invokeSuspend(Unit.f21504a);
            }
        }

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        /* JADX WARN: Multi-variable type inference failed */
        public b(long j10, h<? extends T> hVar, eu.b<? super b> bVar) {
            super(3, bVar);
            this.f12824x = j10;
            this.f12825y = hVar;
        }

        /*  JADX ERROR: JadxOverflowException in pass: RegionMakerVisitor
            jadx.core.utils.exceptions.JadxOverflowException: Regions count limit reached
            	at jadx.core.utils.ErrorsCounter.addError(ErrorsCounter.java:59)
            	at jadx.core.utils.ErrorsCounter.error(ErrorsCounter.java:31)
            	at jadx.core.dex.attributes.nodes.NotificationAttrNode.addError(NotificationAttrNode.java:19)
            */
        /* JADX WARN: Removed duplicated region for block: B:11:0x007f  */
        /* JADX WARN: Removed duplicated region for block: B:9:0x0076 A[RETURN] */
        /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:8:0x0074 -> B:5:0x0077). Please report as a decompilation issue!!! */
        @Override // gu.a
        /*
            Code decompiled incorrectly, please refer to instructions dump.
            To view partially-correct add '--show-bad-code' argument
        */
        public final java.lang.Object invokeSuspend(java.lang.Object r10) {
            /*
                r9 = this;
                java.lang.Object r0 = fu.c.e()
                int r1 = r9.f12821u
                r2 = 1
                r3 = 0
                if (r1 == 0) goto L22
                if (r1 != r2) goto L1a
                long r4 = r9.f12820t
                java.lang.Object r1 = r9.f12823w
                cv.x r1 = (cv.x) r1
                java.lang.Object r6 = r9.f12822v
                dv.i r6 = (dv.i) r6
                zt.o.b(r10)
                goto L77
            L1a:
                java.lang.IllegalStateException r10 = new java.lang.IllegalStateException
                java.lang.String r0 = "call to 'resume' before 'invoke' with coroutine"
                r10.<init>(r0)
                throw r10
            L22:
                zt.o.b(r10)
                java.lang.Object r10 = r9.f12822v
                av.p0 r10 = (av.p0) r10
                java.lang.Object r1 = r9.f12823w
                dv.i r1 = (dv.i) r1
                long r4 = r9.f12824x
                kotlin.time.a$a r6 = kotlin.time.a.INSTANCE
                long r6 = r6.b()
                int r4 = kotlin.time.a.k(r4, r6)
                if (r4 <= 0) goto L82
                dv.h<T> r4 = r9.f12825y
                r5 = 0
                r6 = 2
                dv.h r4 = dv.j.c(r4, r5, r3, r6, r3)
                cv.x r10 = dv.j.G(r4, r10)
                long r4 = r9.f12824x
                r6 = r1
                r1 = r10
            L4b:
                jv.k r10 = new jv.k
                kotlin.coroutines.CoroutineContext r7 = r9.getContext()
                r10.<init>(r7)
                jv.h r7 = r1.B()
                dv.q$b$a r8 = new dv.q$b$a
                r8.<init>(r6, r3)
                r10.b(r7, r8)
                dv.q$b$b r7 = new dv.q$b$b
                r7.<init>(r4, r3)
                jv.c.b(r10, r4, r7)
                r9.f12822v = r6
                r9.f12823w = r1
                r9.f12820t = r4
                r9.f12821u = r2
                java.lang.Object r10 = r10.o(r9)
                if (r10 != r0) goto L77
                return r0
            L77:
                java.lang.Boolean r10 = (java.lang.Boolean) r10
                boolean r10 = r10.booleanValue()
                if (r10 != 0) goto L4b
                kotlin.Unit r10 = kotlin.Unit.f21504a
                return r10
            L82:
                av.e3 r10 = new av.e3
                java.lang.String r0 = "Timed out immediately"
                r10.<init>(r0)
                throw r10
            */
            throw new UnsupportedOperationException("Method not decompiled: dv.q.b.invokeSuspend(java.lang.Object):java.lang.Object");
        }

        @Override // pu.n
        /* renamed from: m, reason: merged with bridge method [inline-methods] */
        public final Object invoke(av.p0 p0Var, i<? super T> iVar, eu.b<? super Unit> bVar) {
            b bVar2 = new b(this.f12824x, this.f12825y, bVar);
            bVar2.f12822v = p0Var;
            bVar2.f12823w = iVar;
            return bVar2.invokeSuspend(Unit.f21504a);
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    @NotNull
    public static final <T> h<T> b(@NotNull h<? extends T> hVar, final long j10) {
        if (j10 >= 0) {
            return j10 == 0 ? hVar : d(hVar, new Function1() { // from class: dv.p
                @Override // kotlin.jvm.functions.Function1
                public final Object invoke(Object obj) {
                    long c10;
                    c10 = q.c(j10, obj);
                    return Long.valueOf(c10);
                }
            });
        }
        throw new IllegalArgumentException("Debounce timeout should not be negative");
    }

    public static final long c(long j10, Object obj) {
        return j10;
    }

    public static final <T> h<T> d(h<? extends T> hVar, Function1<? super T, Long> function1) {
        return kotlin.o.b(new a(function1, hVar, null));
    }

    @NotNull
    public static final <T> h<T> e(@NotNull h<? extends T> hVar, long j10) {
        return f(hVar, j10);
    }

    public static final <T> h<T> f(h<? extends T> hVar, long j10) {
        return kotlin.o.b(new b(j10, hVar, null));
    }


    // --- восстановлено из DEX (dv/q$a$a) ---
    public static class a extends gu.m implements kotlin.jvm.functions.Function1 {
        int t;
        dv.i u;
        kotlin.jvm.internal.c0 v;
        public a(dv.i p0, kotlin.jvm.internal.c0 p1, eu.b p2) { }
        public eu.b create(eu.b p0) { throw new UnsupportedOperationException("stub"); }
        public java.lang.Object invoke(java.lang.Object p0) { throw new UnsupportedOperationException("stub"); }
        public java.lang.Object invokeSuspend(java.lang.Object p0) { throw new UnsupportedOperationException("stub"); }
        public java.lang.Object m(eu.b p0) { throw new UnsupportedOperationException("stub"); }
    }

    // --- восстановлено из DEX (dv/q$a$b) ---
    public static class b extends gu.m implements kotlin.jvm.functions.Function2 {
        java.lang.Object t;
        int u;
        java.lang.Object v;
        kotlin.jvm.internal.c0 w;
        dv.i x;
        public b(kotlin.jvm.internal.c0 p0, dv.i p1, eu.b p2) { }
        public eu.b create(java.lang.Object p0, eu.b p1) { throw new UnsupportedOperationException("stub"); }
        public java.lang.Object invoke(java.lang.Object p0, java.lang.Object p1) { throw new UnsupportedOperationException("stub"); }
        public java.lang.Object invokeSuspend(java.lang.Object p0) { throw new UnsupportedOperationException("stub"); }
        public java.lang.Object m(java.lang.Object p0, eu.b p1) { throw new UnsupportedOperationException("stub"); }
    }

    // --- восстановлено из DEX (dv/q$a$c) ---
    public static class c extends gu.m implements kotlin.jvm.functions.Function2 {
        int t;
        java.lang.Object u;
        dv.h v;
        public c(dv.h p0, eu.b p1) { }
        public eu.b create(java.lang.Object p0, eu.b p1) { throw new UnsupportedOperationException("stub"); }
        public java.lang.Object invoke(java.lang.Object p0, java.lang.Object p1) { throw new UnsupportedOperationException("stub"); }
        public java.lang.Object invokeSuspend(java.lang.Object p0) { throw new UnsupportedOperationException("stub"); }
        public java.lang.Object m(cv.v p0, eu.b p1) { throw new UnsupportedOperationException("stub"); }
    }

    // --- восстановлено из DEX (dv/q$a$c$a) ---
    public static class a implements dv.i {
        cv.v a;
        public a(cv.v p0) { }
        public java.lang.Object emit(java.lang.Object p0, eu.b p1) { throw new UnsupportedOperationException("stub"); }
    }

    // --- восстановлено из DEX (dv/q$a$c$a$a) ---
    public static class a extends gu.d {
        java.lang.Object t;
        dv.q.a.c.a u;
        int v;
        public a(dv.q.a.c.a p0, eu.b p1) { }
        public java.lang.Object invokeSuspend(java.lang.Object p0) { throw new UnsupportedOperationException("stub"); }
    }

    // --- восстановлено из DEX (dv/q$b$a) ---
    public static class a extends gu.m implements kotlin.jvm.functions.Function2 {
        int t;
        java.lang.Object u;
        dv.i v;
        public a(dv.i p0, eu.b p1) { }
        public eu.b create(java.lang.Object p0, eu.b p1) { throw new UnsupportedOperationException("stub"); }
        public java.lang.Object invoke(java.lang.Object p0, java.lang.Object p1) { throw new UnsupportedOperationException("stub"); }
        public java.lang.Object invokeSuspend(java.lang.Object p0) { throw new UnsupportedOperationException("stub"); }
        public java.lang.Object m(java.lang.Object p0, eu.b p1) { throw new UnsupportedOperationException("stub"); }
    }

    // --- восстановлено из DEX (dv/q$b$b) ---
    public static class b extends gu.m implements kotlin.jvm.functions.Function1 {
        int t;
        long u;
        public b(long p0, eu.b p1) { }
        public eu.b create(eu.b p0) { throw new UnsupportedOperationException("stub"); }
        public java.lang.Object invoke(java.lang.Object p0) { throw new UnsupportedOperationException("stub"); }
        public java.lang.Object invokeSuspend(java.lang.Object p0) { throw new UnsupportedOperationException("stub"); }
        public java.lang.Object m(eu.b p0) { throw new UnsupportedOperationException("stub"); }
    }
}
