package dv;

import com.github.luben.zstd.BuildConfig;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.functions.Function2;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(d1 = {"\u00000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\u000b\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\b\t\b\u0002\u0018\u0000*\u0004\b\u0000\u0010\u00012\b\u0012\u0004\u0012\u00028\u00000\u0002BI\u0012\f\u0010\u0003\u001a\b\u0012\u0004\u0012\u00028\u00000\u0002\u0012\u0014\u0010\u0006\u001a\u0010\u0012\u0004\u0012\u00028\u0000\u0012\u0006\u0012\u0004\u0018\u00010\u00050\u0004\u0012\u001c\u0010\t\u001a\u0018\u0012\u0006\u0012\u0004\u0018\u00010\u0005\u0012\u0006\u0012\u0004\u0018\u00010\u0005\u0012\u0004\u0012\u00020\b0\u0007¢\u0006\u0004\b\n\u0010\u000bJ\u001e\u0010\u000f\u001a\u00020\u000e2\f\u0010\r\u001a\b\u0012\u0004\u0012\u00028\u00000\fH\u0096@¢\u0006\u0004\b\u000f\u0010\u0010R\u001a\u0010\u0003\u001a\b\u0012\u0004\u0012\u00028\u00000\u00028\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b\u0011\u0010\u0012R\"\u0010\u0006\u001a\u0010\u0012\u0004\u0012\u00028\u0000\u0012\u0006\u0012\u0004\u0018\u00010\u00050\u00048\u0006X\u0087\u0004¢\u0006\u0006\n\u0004\b\u0013\u0010\u0014R*\u0010\t\u001a\u0018\u0012\u0006\u0012\u0004\u0018\u00010\u0005\u0012\u0006\u0012\u0004\u0018\u00010\u0005\u0012\u0004\u0012\u00020\b0\u00078\u0006X\u0087\u0004¢\u0006\u0006\n\u0004\b\u0015\u0010\u0016¨\u0006\u0017"}, d2 = {"Ldv/g;", "T", "Ldv/h;", "upstream", "Lkotlin/Function1;", BuildConfig.FLAVOR, "keySelector", "Lkotlin/Function2;", BuildConfig.FLAVOR, "areEquivalent", "<init>", "(Ldv/h;Lkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function2;)V", "Ldv/i;", "collector", BuildConfig.FLAVOR, "collect", "(Ldv/i;Leu/b;)Ljava/lang/Object;", xe.a.f36648e, "Ldv/h;", k6.b.f21144e, "Lkotlin/jvm/functions/Function1;", "c", "Lkotlin/jvm/functions/Function2;", "kotlinx-coroutines-core"}, k = 1, mv = {2, 1, 0}, xi = 48)
/* loaded from: classes2.dex */
public final class g<T> implements h<T> {

    /* renamed from: a, reason: collision with root package name and from kotlin metadata */
    @NotNull
    public final h<T> upstream;

    /* renamed from: b, reason: from kotlin metadata */
    @NotNull
    public final Function1<T, Object> keySelector;

    /* renamed from: c, reason: collision with root package name and from kotlin metadata */
    @NotNull
    public final Function2<Object, Object, Boolean> areEquivalent;

    @Metadata(k = 3, mv = {2, 1, 0}, xi = 48)
    public static final class a<T> implements i {

        /* renamed from: a, reason: collision with root package name */
        public final /* synthetic */ g<T> f12741a;
        public final /* synthetic */ kotlin.jvm.internal.c0<Object> b;

        /* renamed from: c, reason: collision with root package name */
        public final /* synthetic */ i<T> f12742c;

        @Metadata(k = 3, mv = {2, 1, 0}, xi = 48)
        @gu.f(c = "kotlinx.coroutines.flow.DistinctFlowImpl$collect$2", f = "Distinct.kt", l = {73}, m = "emit")
        /* renamed from: dv.g$a$a, reason: collision with other inner class name */
        public static final class C0240a extends gu.d {

            /* renamed from: t, reason: collision with root package name */
            public /* synthetic */ Object f12743t;

            /* renamed from: u, reason: collision with root package name */
            public final /* synthetic */ a<T> f12744u;

            /* renamed from: v, reason: collision with root package name */
            public int f12745v;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            /* JADX WARN: Multi-variable type inference failed */
            public C0240a(a<? super T> aVar, eu.b<? super C0240a> bVar) {
                super(bVar);
                this.f12744u = aVar;
            }

            @Override // gu.a
            public final Object invokeSuspend(Object obj) {
                this.f12743t = obj;
                this.f12745v |= Integer.MIN_VALUE;
                return this.f12744u.emit(null, this);
            }
        }

        /* JADX WARN: Multi-variable type inference failed */
        public a(g<T> gVar, kotlin.jvm.internal.c0<Object> c0Var, i<? super T> iVar) {
            this.f12741a = gVar;
            this.b = c0Var;
            this.f12742c = iVar;
        }

        /* JADX WARN: Removed duplicated region for block: B:15:0x0031  */
        /* JADX WARN: Removed duplicated region for block: B:8:0x0023  */
        @Override // dv.i
        /*
            Code decompiled incorrectly, please refer to instructions dump.
            To view partially-correct add '--show-bad-code' argument
        */
        public final java.lang.Object emit(T r6, eu.b<? super kotlin.Unit> r7) {
            /*
                r5 = this;
                boolean r0 = r7 instanceof dv.g.a.C0240a
                if (r0 == 0) goto L13
                r0 = r7
                dv.g$a$a r0 = (dv.g.a.C0240a) r0
                int r1 = r0.f12745v
                r2 = -2147483648(0xffffffff80000000, float:-0.0)
                r3 = r1 & r2
                if (r3 == 0) goto L13
                int r1 = r1 - r2
                r0.f12745v = r1
                goto L18
            L13:
                dv.g$a$a r0 = new dv.g$a$a
                r0.<init>(r5, r7)
            L18:
                java.lang.Object r7 = r0.f12743t
                java.lang.Object r1 = fu.c.e()
                int r2 = r0.f12745v
                r3 = 1
                if (r2 == 0) goto L31
                if (r2 != r3) goto L29
                zt.o.b(r7)
                goto L67
            L29:
                java.lang.IllegalStateException r6 = new java.lang.IllegalStateException
                java.lang.String r7 = "call to 'resume' before 'invoke' with coroutine"
                r6.<init>(r7)
                throw r6
            L31:
                zt.o.b(r7)
                dv.g<T> r7 = r5.f12741a
                kotlin.jvm.functions.Function1<T, java.lang.Object> r7 = r7.keySelector
                java.lang.Object r7 = r7.invoke(r6)
                kotlin.jvm.internal.c0<java.lang.Object> r2 = r5.b
                T r2 = r2.f21573a
                gv.e0 r4 = kotlin.t.f14750a
                if (r2 == r4) goto L58
                dv.g<T> r4 = r5.f12741a
                kotlin.jvm.functions.Function2<java.lang.Object, java.lang.Object, java.lang.Boolean> r4 = r4.areEquivalent
                java.lang.Object r2 = r4.invoke(r2, r7)
                java.lang.Boolean r2 = (java.lang.Boolean) r2
                boolean r2 = r2.booleanValue()
                if (r2 != 0) goto L55
                goto L58
            L55:
                kotlin.Unit r6 = kotlin.Unit.f21504a
                return r6
            L58:
                kotlin.jvm.internal.c0<java.lang.Object> r2 = r5.b
                r2.f21573a = r7
                dv.i<T> r7 = r5.f12742c
                r0.f12745v = r3
                java.lang.Object r6 = r7.emit(r6, r0)
                if (r6 != r1) goto L67
                return r1
            L67:
                kotlin.Unit r6 = kotlin.Unit.f21504a
                return r6
            */
            throw new UnsupportedOperationException("Method not decompiled: dv.g.a.emit(java.lang.Object, eu.b):java.lang.Object");
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    public g(@NotNull h<? extends T> hVar, @NotNull Function1<? super T, ? extends Object> function1, @NotNull Function2<Object, Object, Boolean> function2) {
        this.upstream = hVar;
        this.keySelector = function1;
        this.areEquivalent = function2;
    }

    @Override // dv.h
    @Nullable
    public Object collect(@NotNull i<? super T> iVar, @NotNull eu.b<? super Unit> bVar) {
        kotlin.jvm.internal.c0 c0Var = new kotlin.jvm.internal.c0();
        c0Var.f21573a = (T) kotlin.t.f14750a;
        Object collect = this.upstream.collect(new a(this, c0Var, iVar), bVar);
        return collect == fu.c.e() ? collect : Unit.f21504a;
    }


    // --- восстановлено из DEX (dv/g$a$a) ---
    public static class a extends gu.d {
        java.lang.Object t;
        dv.g.a u;
        int v;
        public a(dv.g.a p0, eu.b p1) { }
        public java.lang.Object invokeSuspend(java.lang.Object p0) { throw new UnsupportedOperationException("stub"); }
    }
}
