package e4;

import android.R;

/* loaded from: classes.dex */
public final class c {
    public static int b = 0;

    /* renamed from: c, reason: collision with root package name */
    public static int f13178c = 1;

    /* renamed from: d, reason: collision with root package name */
    public static int f13179d = 2;

    /* renamed from: f, reason: collision with root package name */
    public static int f13181f = 0;

    /* renamed from: g, reason: collision with root package name */
    public static int f13182g = 1;

    /* renamed from: a, reason: collision with root package name */
    public static int[] f13177a = {android.R.attr.name, android.R.attr.id, android.R.attr.tag};

    /* renamed from: e, reason: collision with root package name */
    public static int[] f13180e = {android.R.attr.name, android.R.attr.tag};
}
