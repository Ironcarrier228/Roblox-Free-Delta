package d;

import android.app.Notification;
import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.Parcelable;

/* loaded from: classes.dex */
public interface a extends IInterface {

    /* renamed from: n, reason: collision with root package name */
    public static final String f11606n = "android$support$v4$app$INotificationSideChannel".replace('$', '.');

    /* renamed from: d.a$a, reason: collision with other inner class name */
    public static abstract class AbstractBinderC0206a extends Binder implements a {

        /* renamed from: d.a$a$a, reason: collision with other inner class name */
        public static class C0207a implements a {

            /* renamed from: a, reason: collision with root package name */
            public IBinder f11607a;

            public C0207a(IBinder iBinder) {
                this.f11607a = iBinder;
            }

            @Override // android.os.IInterface
            public IBinder asBinder() {
                return this.f11607a;
            }

            @Override // d.a
            public void g2(String str, int i10, String str2, Notification notification) {
                Parcel obtain = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken(a.f11606n);
                    obtain.writeString(str);
                    obtain.writeInt(i10);
                    obtain.writeString(str2);
                    b.b(obtain, notification, 0);
                    this.f11607a.transact(1, obtain, null, 1);
                } finally {
                    obtain.recycle();
                }
            }
        }

        public static a r2(IBinder iBinder) {
            if (iBinder == null) {
                return null;
            }
            IInterface queryLocalInterface = iBinder.queryLocalInterface(a.f11606n);
            return (queryLocalInterface == null || !(queryLocalInterface instanceof a)) ? new C0207a(iBinder) : (a) queryLocalInterface;
        }
    }

    public static class b {
        public static <T extends Parcelable> void b(Parcel parcel, T t8, int i10) {
            if (t8 == null) {
                parcel.writeInt(0);
            } else {
                parcel.writeInt(1);
                t8.writeToParcel(parcel, i10);
            }
        }
    }

    void g2(String str, int i10, String str2, Notification notification);


    // --- восстановлено из DEX (d/a$a$a) ---
    public static class a implements d.a {
        android.os.IBinder a;
        public a(android.os.IBinder p0) { }
        public android.os.IBinder asBinder() { throw new UnsupportedOperationException("stub"); }
        public void g2(java.lang.String p0, int p1, java.lang.String p2, android.app.Notification p3) { throw new UnsupportedOperationException("stub"); }
    }
}
