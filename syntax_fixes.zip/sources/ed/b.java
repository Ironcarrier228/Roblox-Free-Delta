package ed;

import android.R;
import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import androidx.annotation.NonNull;
import bd.o;
import jc.k;

/* loaded from: classes2.dex */
public abstract class b {

    /* renamed from: a, reason: collision with root package name */
    public int f13319a;
    public int b;

    /* renamed from: c, reason: collision with root package name */
    @NonNull
    public int[] f13320c = new int[0];

    /* renamed from: d, reason: collision with root package name */
    public int f13321d;

    /* renamed from: e, reason: collision with root package name */
    public int f13322e;

    /* renamed from: f, reason: collision with root package name */
    public int f13323f;

    /* renamed from: g, reason: collision with root package name */
    public int f13324g;

    public b(@NonNull Context context, AttributeSet attributeSet, int i10, int i11) {
        int dimensionPixelSize = context.getResources().getDimensionPixelSize(jc.d.f20329f0);
        TypedArray i12 = o.i(context, attributeSet, k.f20672x, i10, i11, new int[0]);
        this.f13319a = fd.c.c(context, i12, k.G, dimensionPixelSize);
        this.b = Math.min(fd.c.c(context, i12, k.F, 0), this.f13319a / 2);
        this.f13322e = i12.getInt(k.C, 0);
        this.f13323f = i12.getInt(k.f20680y, 0);
        this.f13324g = i12.getDimensionPixelSize(k.A, 0);
        c(context, i12);
        d(context, i12);
        i12.recycle();
    }

    public boolean a() {
        return this.f13323f != 0;
    }

    public boolean b() {
        return this.f13322e != 0;
    }

    public final void c(@NonNull Context context, @NonNull TypedArray typedArray) {
        if (!typedArray.hasValue(k.f20689z)) {
            this.f13320c = new int[]{vc.a.b(context, jc.b.f20295l, -1)};
            return;
        }
        if (typedArray.peekValue(k.f20689z).type != 1) {
            this.f13320c = new int[]{typedArray.getColor(k.f20689z, -1)};
            return;
        }
        int[] intArray = context.getResources().getIntArray(typedArray.getResourceId(k.f20689z, -1));
        this.f13320c = intArray;
        if (intArray.length == 0) {
            throw new IllegalArgumentException("indicatorColors cannot be empty when indicatorColor is not used.");
        }
    }

    public final void d(@NonNull Context context, @NonNull TypedArray typedArray) {
        if (typedArray.hasValue(k.E)) {
            this.f13321d = typedArray.getColor(k.E, -1);
            return;
        }
        this.f13321d = this.f13320c[0];
        TypedArray obtainStyledAttributes = context.getTheme().obtainStyledAttributes(new int[]{android.R.attr.disabledAlpha});
        float f10 = obtainStyledAttributes.getFloat(0, 0.2f);
        obtainStyledAttributes.recycle();
        this.f13321d = vc.a.a(this.f13321d, (int) (f10 * 255.0f));
    }

    public void e() {
        if (this.f13324g < 0) {
            throw new IllegalArgumentException("indicatorTrackGapSize must be >= 0.");
        }
    }
}
