package cf;

import com.github.luben.zstd.BuildConfig;
import com.google.crypto.tink.shaded.protobuf.a;
import com.google.crypto.tink.shaded.protobuf.a0;
import com.google.crypto.tink.shaded.protobuf.s0;
import com.google.crypto.tink.shaded.protobuf.y;

/* loaded from: classes2.dex */
public final class k0 extends com.google.crypto.tink.shaded.protobuf.y<k0, b> implements com.google.crypto.tink.shaded.protobuf.t0 {
    private static final k0 DEFAULT_INSTANCE;
    public static final int KEY_INFO_FIELD_NUMBER = 2;
    private static volatile com.google.crypto.tink.shaded.protobuf.a1<k0> PARSER = null;
    public static final int PRIMARY_KEY_ID_FIELD_NUMBER = 1;
    private a0.i<c> keyInfo_ = com.google.crypto.tink.shaded.protobuf.y.A();
    private int primaryKeyId_;

    public static /* synthetic */ class a {

        /* renamed from: a, reason: collision with root package name */
        public static final /* synthetic */ int[] f5072a;

        static {
            int[] iArr = new int[y.f.values().length];
            f5072a = iArr;
            try {
                iArr[y.f.NEW_MUTABLE_INSTANCE.ordinal()] = 1;
            } catch (NoSuchFieldError unused) {
            }
            try {
                f5072a[y.f.NEW_BUILDER.ordinal()] = 2;
            } catch (NoSuchFieldError unused2) {
            }
            try {
                f5072a[y.f.BUILD_MESSAGE_INFO.ordinal()] = 3;
            } catch (NoSuchFieldError unused3) {
            }
            try {
                f5072a[y.f.GET_DEFAULT_INSTANCE.ordinal()] = 4;
            } catch (NoSuchFieldError unused4) {
            }
            try {
                f5072a[y.f.GET_PARSER.ordinal()] = 5;
            } catch (NoSuchFieldError unused5) {
            }
            try {
                f5072a[y.f.GET_MEMOIZED_IS_INITIALIZED.ordinal()] = 6;
            } catch (NoSuchFieldError unused6) {
            }
            try {
                f5072a[y.f.SET_MEMOIZED_IS_INITIALIZED.ordinal()] = 7;
            } catch (NoSuchFieldError unused7) {
            }
        }
    }

    public static final class b extends y.a<k0, b> implements com.google.crypto.tink.shaded.protobuf.t0 {
        public /* synthetic */ b(a aVar) {
            this();
        }

        public b D(c cVar) {
            t();
            ((k0) this.b).c0(cVar);
            return this;
        }

        public b F(int i10) {
            t();
            ((k0) this.b).f0(i10);
            return this;
        }

        @Override // com.google.crypto.tink.shaded.protobuf.y.a, com.google.crypto.tink.shaded.protobuf.s0.a
        public /* bridge */ /* synthetic */ s0.a K(com.google.crypto.tink.shaded.protobuf.i iVar, com.google.crypto.tink.shaded.protobuf.p pVar) {
            return super.K(iVar, pVar);
        }

        @Override // com.google.crypto.tink.shaded.protobuf.a.AbstractC0133a, com.google.crypto.tink.shaded.protobuf.s0.a
        public /* bridge */ /* synthetic */ s0.a N(com.google.crypto.tink.shaded.protobuf.s0 s0Var) {
            return super.N(s0Var);
        }

        @Override // com.google.crypto.tink.shaded.protobuf.y.a, com.google.crypto.tink.shaded.protobuf.s0.a
        public /* bridge */ /* synthetic */ com.google.crypto.tink.shaded.protobuf.s0 build() {
            return super.build();
        }

        @Override // com.google.crypto.tink.shaded.protobuf.y.a
        public /* bridge */ /* synthetic */ Object clone() {
            return super.clone();
        }

        @Override // com.google.crypto.tink.shaded.protobuf.y.a, com.google.crypto.tink.shaded.protobuf.s0.a
        public /* bridge */ /* synthetic */ com.google.crypto.tink.shaded.protobuf.s0 d() {
            return super.d();
        }

        @Override // com.google.crypto.tink.shaded.protobuf.y.a, com.google.crypto.tink.shaded.protobuf.t0
        public /* bridge */ /* synthetic */ com.google.crypto.tink.shaded.protobuf.s0 f() {
            return super.f();
        }

        @Override // com.google.crypto.tink.shaded.protobuf.y.a, com.google.crypto.tink.shaded.protobuf.a.AbstractC0133a
        public /* bridge */ /* synthetic */ a.AbstractC0133a l(com.google.crypto.tink.shaded.protobuf.a aVar) {
            return super.l((com.google.crypto.tink.shaded.protobuf.y) aVar);
        }

        public b() {
            super(k0.DEFAULT_INSTANCE);
        }
    }

    public static final class c extends com.google.crypto.tink.shaded.protobuf.y<c, a> implements com.google.crypto.tink.shaded.protobuf.t0 {
        private static final c DEFAULT_INSTANCE;
        public static final int KEY_ID_FIELD_NUMBER = 3;
        public static final int OUTPUT_PREFIX_TYPE_FIELD_NUMBER = 4;
        private static volatile com.google.crypto.tink.shaded.protobuf.a1<c> PARSER = null;
        public static final int STATUS_FIELD_NUMBER = 2;
        public static final int TYPE_URL_FIELD_NUMBER = 1;
        private int keyId_;
        private int outputPrefixType_;
        private int status_;
        private String typeUrl_ = BuildConfig.FLAVOR;

        public static final class a extends y.a<c, a> implements com.google.crypto.tink.shaded.protobuf.t0 {
            public /* synthetic */ a(a aVar) {
                this();
            }

            public a D(int i10) {
                t();
                ((c) this.b).f0(i10);
                return this;
            }

            public a F(p0 p0Var) {
                t();
                ((c) this.b).g0(p0Var);
                return this;
            }

            public a G(g0 g0Var) {
                t();
                ((c) this.b).h0(g0Var);
                return this;
            }

            public a H(String str) {
                t();
                ((c) this.b).i0(str);
                return this;
            }

            @Override // com.google.crypto.tink.shaded.protobuf.y.a, com.google.crypto.tink.shaded.protobuf.s0.a
            public /* bridge */ /* synthetic */ s0.a K(com.google.crypto.tink.shaded.protobuf.i iVar, com.google.crypto.tink.shaded.protobuf.p pVar) {
                return super.K(iVar, pVar);
            }

            @Override // com.google.crypto.tink.shaded.protobuf.a.AbstractC0133a, com.google.crypto.tink.shaded.protobuf.s0.a
            public /* bridge */ /* synthetic */ s0.a N(com.google.crypto.tink.shaded.protobuf.s0 s0Var) {
                return super.N(s0Var);
            }

            @Override // com.google.crypto.tink.shaded.protobuf.y.a, com.google.crypto.tink.shaded.protobuf.s0.a
            public /* bridge */ /* synthetic */ com.google.crypto.tink.shaded.protobuf.s0 build() {
                return super.build();
            }

            @Override // com.google.crypto.tink.shaded.protobuf.y.a
            public /* bridge */ /* synthetic */ Object clone() {
                return super.clone();
            }

            @Override // com.google.crypto.tink.shaded.protobuf.y.a, com.google.crypto.tink.shaded.protobuf.s0.a
            public /* bridge */ /* synthetic */ com.google.crypto.tink.shaded.protobuf.s0 d() {
                return super.d();
            }

            @Override // com.google.crypto.tink.shaded.protobuf.y.a, com.google.crypto.tink.shaded.protobuf.t0
            public /* bridge */ /* synthetic */ com.google.crypto.tink.shaded.protobuf.s0 f() {
                return super.f();
            }

            @Override // com.google.crypto.tink.shaded.protobuf.y.a, com.google.crypto.tink.shaded.protobuf.a.AbstractC0133a
            public /* bridge */ /* synthetic */ a.AbstractC0133a l(com.google.crypto.tink.shaded.protobuf.a aVar) {
                return super.l((com.google.crypto.tink.shaded.protobuf.y) aVar);
            }

            public a() {
                super(c.DEFAULT_INSTANCE);
            }
        }

        static {
            c cVar = new c();
            DEFAULT_INSTANCE = cVar;
            com.google.crypto.tink.shaded.protobuf.y.W(c.class, cVar);
        }

        public static a e0() {
            return DEFAULT_INSTANCE.v();
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void f0(int i10) {
            this.keyId_ = i10;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void g0(p0 p0Var) {
            this.outputPrefixType_ = p0Var.getNumber();
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void h0(g0 g0Var) {
            this.status_ = g0Var.getNumber();
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void i0(String str) {
            str.getClass();
            this.typeUrl_ = str;
        }

        @Override // com.google.crypto.tink.shaded.protobuf.y, com.google.crypto.tink.shaded.protobuf.s0
        public /* bridge */ /* synthetic */ s0.a a() {
            return super.a();
        }

        @Override // com.google.crypto.tink.shaded.protobuf.y, com.google.crypto.tink.shaded.protobuf.s0
        public /* bridge */ /* synthetic */ s0.a e() {
            return super.e();
        }

        @Override // com.google.crypto.tink.shaded.protobuf.y, com.google.crypto.tink.shaded.protobuf.t0
        public /* bridge */ /* synthetic */ com.google.crypto.tink.shaded.protobuf.s0 f() {
            return super.f();
        }

        @Override // com.google.crypto.tink.shaded.protobuf.y
        public final Object z(y.f fVar, Object obj, Object obj2) {
            com.google.crypto.tink.shaded.protobuf.a1 a1Var;
            a aVar = null;
            switch (a.f5072a[fVar.ordinal()]) {
                case 1:
                    return new c();
                case 2:
                    return new a(aVar);
                case 3:
                    return com.google.crypto.tink.shaded.protobuf.y.O(DEFAULT_INSTANCE, "\u0000\u0004\u0000\u0000\u0001\u0004\u0004\u0000\u0000\u0000\u0001Ȉ\u0002\f\u0003\u000b\u0004\f", new Object[]{"typeUrl_", "status_", "keyId_", "outputPrefixType_"});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    com.google.crypto.tink.shaded.protobuf.a1<c> a1Var2 = PARSER;
                    if (a1Var2 != null) {
                        return a1Var2;
                    }
                    synchronized (c.class) {
                        try {
                            a1Var = PARSER;
                            if (a1Var == null) {
                                a1Var = new y.b(DEFAULT_INSTANCE);
                                PARSER = a1Var;
                            }
                        } catch (Throwable th2) {
                            throw th2;
                        }
                    }
                    return a1Var;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }
    }

    static {
        k0 k0Var = new k0();
        DEFAULT_INSTANCE = k0Var;
        com.google.crypto.tink.shaded.protobuf.y.W(k0.class, k0Var);
    }

    public static b e0() {
        return DEFAULT_INSTANCE.v();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void f0(int i10) {
        this.primaryKeyId_ = i10;
    }

    @Override // com.google.crypto.tink.shaded.protobuf.y, com.google.crypto.tink.shaded.protobuf.s0
    public /* bridge */ /* synthetic */ s0.a a() {
        return super.a();
    }

    public final void c0(c cVar) {
        cVar.getClass();
        d0();
        this.keyInfo_.add(cVar);
    }

    public final void d0() {
        a0.i<c> iVar = this.keyInfo_;
        if (iVar.o()) {
            return;
        }
        this.keyInfo_ = com.google.crypto.tink.shaded.protobuf.y.L(iVar);
    }

    @Override // com.google.crypto.tink.shaded.protobuf.y, com.google.crypto.tink.shaded.protobuf.s0
    public /* bridge */ /* synthetic */ s0.a e() {
        return super.e();
    }

    @Override // com.google.crypto.tink.shaded.protobuf.y, com.google.crypto.tink.shaded.protobuf.t0
    public /* bridge */ /* synthetic */ com.google.crypto.tink.shaded.protobuf.s0 f() {
        return super.f();
    }

    @Override // com.google.crypto.tink.shaded.protobuf.y
    public final Object z(y.f fVar, Object obj, Object obj2) {
        com.google.crypto.tink.shaded.protobuf.a1 a1Var;
        a aVar = null;
        switch (a.f5072a[fVar.ordinal()]) {
            case 1:
                return new k0();
            case 2:
                return new b(aVar);
            case 3:
                return com.google.crypto.tink.shaded.protobuf.y.O(DEFAULT_INSTANCE, "\u0000\u0002\u0000\u0000\u0001\u0002\u0002\u0000\u0001\u0000\u0001\u000b\u0002\u001b", new Object[]{"primaryKeyId_", "keyInfo_", c.class});
            case 4:
                return DEFAULT_INSTANCE;
            case 5:
                com.google.crypto.tink.shaded.protobuf.a1<k0> a1Var2 = PARSER;
                if (a1Var2 != null) {
                    return a1Var2;
                }
                synchronized (k0.class) {
                    try {
                        a1Var = PARSER;
                        if (a1Var == null) {
                            a1Var = new y.b(DEFAULT_INSTANCE);
                            PARSER = a1Var;
                        }
                    } catch (Throwable th2) {
                        throw th2;
                    }
                }
                return a1Var;
            case 6:
                return (byte) 1;
            case 7:
                return null;
            default:
                throw new UnsupportedOperationException();
        }
    }


    // --- восстановлено из DEX (cf/k0$c$a) ---
    public static class a extends com.google.crypto.tink.shaded.protobuf.y.a implements com.google.crypto.tink.shaded.protobuf.t0 {
        public a() { }
        public a(cf.k0.a p0) { }
        public cf.k0.c.a D(int p0) { throw new UnsupportedOperationException("stub"); }
        public cf.k0.c.a F(cf.p0 p0) { throw new UnsupportedOperationException("stub"); }
        public cf.k0.c.a G(cf.g0 p0) { throw new UnsupportedOperationException("stub"); }
        public cf.k0.c.a H(java.lang.String p0) { throw new UnsupportedOperationException("stub"); }
        public com.google.crypto.tink.shaded.protobuf.s0.a K(com.google.crypto.tink.shaded.protobuf.i p0, com.google.crypto.tink.shaded.protobuf.p p1) { throw new UnsupportedOperationException("stub"); }
        public com.google.crypto.tink.shaded.protobuf.s0.a N(com.google.crypto.tink.shaded.protobuf.s0 p0) { throw new UnsupportedOperationException("stub"); }
        public com.google.crypto.tink.shaded.protobuf.s0 build() { throw new UnsupportedOperationException("stub"); }
        public java.lang.Object clone() { throw new UnsupportedOperationException("stub"); }
        public com.google.crypto.tink.shaded.protobuf.s0 d() { throw new UnsupportedOperationException("stub"); }
        public com.google.crypto.tink.shaded.protobuf.s0 f() { throw new UnsupportedOperationException("stub"); }
        public com.google.crypto.tink.shaded.protobuf.a.a l(com.google.crypto.tink.shaded.protobuf.a p0) { throw new UnsupportedOperationException("stub"); }
    }
}
