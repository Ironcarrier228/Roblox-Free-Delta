package cf;

import com.google.crypto.tink.shaded.protobuf.a0;

/* loaded from: classes2.dex */
public enum v implements a0.c {
    UNKNOWN_ENCODING(0),
    IEEE_P1363(1),
    DER(2),
    UNRECOGNIZED(-1);


    /* renamed from: f, reason: collision with root package name */
    public static final a0.d<v> f5103f = new a0.d<v>() { // from class: cf.v.a
        @Override // com.google.crypto.tink.shaded.protobuf.a0.d
        /* renamed from: b, reason: merged with bridge method [inline-methods] */
        public v a(int i10) {
            return v.a(i10);
        }
    };

    /* renamed from: a, reason: collision with root package name */
    public final int f5105a;

    v(int i10) {
        this.f5105a = i10;
    }

    public static v a(int i10) {
        if (i10 == 0) {
            return UNKNOWN_ENCODING;
        }
        if (i10 == 1) {
            return IEEE_P1363;
        }
        if (i10 != 2) {
            return null;
        }
        return DER;
    }

    @Override // com.google.crypto.tink.shaded.protobuf.a0.c
    public final int getNumber() {
        if (this != UNRECOGNIZED) {
            return this.f5105a;
        }
        throw new IllegalArgumentException("Can't get the number of an unknown enum value.");
    }


    // --- восстановлено из DEX (cf/v$a) ---
    public static class a implements com.google.crypto.tink.shaded.protobuf.a0.d {
        public a() { }
        public com.google.crypto.tink.shaded.protobuf.a0.c a(int p0) { throw new UnsupportedOperationException("stub"); }
        public cf.v b(int p0) { throw new UnsupportedOperationException("stub"); }
    }
}
