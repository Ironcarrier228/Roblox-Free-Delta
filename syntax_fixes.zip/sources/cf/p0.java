package cf;

import com.google.crypto.tink.shaded.protobuf.a0;

/* loaded from: classes2.dex */
public enum p0 implements a0.c {
    UNKNOWN_PREFIX(0),
    TINK(1),
    LEGACY(2),
    RAW(3),
    CRUNCHY(4),
    UNRECOGNIZED(-1);


    /* renamed from: h, reason: collision with root package name */
    public static final a0.d<p0> f5087h = new a0.d<p0>() { // from class: cf.p0.a
        @Override // com.google.crypto.tink.shaded.protobuf.a0.d
        /* renamed from: b, reason: merged with bridge method [inline-methods] */
        public p0 a(int i10) {
            return p0.a(i10);
        }
    };

    /* renamed from: a, reason: collision with root package name */
    public final int f5089a;

    p0(int i10) {
        this.f5089a = i10;
    }

    public static p0 a(int i10) {
        if (i10 == 0) {
            return UNKNOWN_PREFIX;
        }
        if (i10 == 1) {
            return TINK;
        }
        if (i10 == 2) {
            return LEGACY;
        }
        if (i10 == 3) {
            return RAW;
        }
        if (i10 != 4) {
            return null;
        }
        return CRUNCHY;
    }

    @Override // com.google.crypto.tink.shaded.protobuf.a0.c
    public final int getNumber() {
        if (this != UNRECOGNIZED) {
            return this.f5089a;
        }
        throw new IllegalArgumentException("Can't get the number of an unknown enum value.");
    }


    // --- восстановлено из DEX (cf/p0$a) ---
    public static class a implements com.google.crypto.tink.shaded.protobuf.a0.d {
        public a() { }
        public com.google.crypto.tink.shaded.protobuf.a0.c a(int p0) { throw new UnsupportedOperationException("stub"); }
        public cf.p0 b(int p0) { throw new UnsupportedOperationException("stub"); }
    }
}
