package av;

import java.io.Closeable;
import java.util.concurrent.Executor;
import kotlin.Metadata;
import kotlin.coroutines.CoroutineContext;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.DefaultConstructorMarker;
import org.jetbrains.annotations.NotNull;

@Metadata(d1 = {"\u0000 \n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0006\b&\u0018\u0000 \u000b2\u00020\u00012\u00020\u00022\u00060\u0003j\u0002`\u0004:\u0001\fB\u0007¢\u0006\u0004\b\u0005\u0010\u0006R\u0014\u0010\n\u001a\u00020\u00078&X¦\u0004¢\u0006\u0006\u001a\u0004\b\b\u0010\t¨\u0006\r"}, d2 = {"Lav/t1;", "Lav/l0;", "Ljava/io/Closeable;", "Ljava/lang/AutoCloseable;", "Lkotlin/AutoCloseable;", "<init>", "()V", "Ljava/util/concurrent/Executor;", "Y", "()Ljava/util/concurrent/Executor;", "executor", "c", xe.a.f36648e, "kotlinx-coroutines-core"}, k = 1, mv = {2, 1, 0}, xi = 48)
/* loaded from: classes2.dex */
public abstract class t1 extends l0 implements Closeable, AutoCloseable {

    /* renamed from: c, reason: collision with root package name and from kotlin metadata */
    @NotNull
    public static final Companion INSTANCE = new Companion(null);

    @Metadata(d1 = {"\u0000\u0014\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\b\u0087\u0003\u0018\u00002\u000e\u0012\u0004\u0012\u00020\u0002\u0012\u0004\u0012\u00020\u00030\u0001B\t\b\u0002¢\u0006\u0004\b\u0004\u0010\u0005¨\u0006\u0006"}, d2 = {"Lav/t1$a;", "Lkotlin/coroutines/b;", "Lav/l0;", "Lav/t1;", "<init>", "()V", "kotlinx-coroutines-core"}, k = 1, mv = {2, 1, 0}, xi = 48)
    /* renamed from: av.t1$a, reason: from kotlin metadata */
    public static final class Companion extends kotlin.coroutines.b<l0, t1> {
        public /* synthetic */ Companion(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }

        public static final t1 d(CoroutineContext.Element element) {
            if (element instanceof t1) {
                return (t1) element;
            }
            return null;
        }

        public Companion() {
            super(l0.INSTANCE, new Function1() { // from class: av.s1
                @Override // kotlin.jvm.functions.Function1
                public final Object invoke(Object obj) {
                    t1 d10;
                    d10 = t1.Companion.d((CoroutineContext.Element) obj);
                    return d10;
                }
            });
        }
    }

    @NotNull
    /* renamed from: Y */
    public abstract Executor getExecutor();


    // --- восстановлено из DEX (av/t1$a) ---
    public static class a extends kotlin.coroutines.b {
        public a() { }
        public a(kotlin.jvm.internal.DefaultConstructorMarker p0) { }
        public av.t1 c(kotlin.coroutines.CoroutineContext.Element p0) { throw new UnsupportedOperationException("stub"); }
        public av.t1 d(kotlin.coroutines.CoroutineContext.Element p0) { throw new UnsupportedOperationException("stub"); }
    }
}
