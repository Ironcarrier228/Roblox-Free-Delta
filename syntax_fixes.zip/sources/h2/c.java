package h2;

import android.R;

/* loaded from: classes.dex */
public final class c {

    /* renamed from: c, reason: collision with root package name */
    public static int f18028c = 0;

    /* renamed from: d, reason: collision with root package name */
    public static int f18029d = 1;

    /* renamed from: f, reason: collision with root package name */
    public static int f18031f = 0;

    /* renamed from: g, reason: collision with root package name */
    public static int f18032g = 1;

    /* renamed from: h, reason: collision with root package name */
    public static int f18033h = 2;

    /* renamed from: i, reason: collision with root package name */
    public static int f18034i = 3;

    /* renamed from: j, reason: collision with root package name */
    public static int f18035j = 4;

    /* renamed from: k, reason: collision with root package name */
    public static int f18036k = 5;

    /* renamed from: l, reason: collision with root package name */
    public static int f18037l = 6;

    /* renamed from: a, reason: collision with root package name */
    public static int[] f18027a = {R.attr.color, R.attr.alpha, R.attr.lStar, com.roblox.client.personasdk.R.attr.alpha, com.roblox.client.personasdk.R.attr.lStar};
    public static int[] b = {com.roblox.client.personasdk.R.attr.keylines, com.roblox.client.personasdk.R.attr.statusBarBackground};

    /* renamed from: e, reason: collision with root package name */
    public static int[] f18030e = {android.R.attr.layout_gravity, com.roblox.client.personasdk.R.attr.layout_anchor, com.roblox.client.personasdk.R.attr.layout_anchorGravity, com.roblox.client.personasdk.R.attr.layout_behavior, com.roblox.client.personasdk.R.attr.layout_dodgeInsetEdges, com.roblox.client.personasdk.R.attr.layout_insetEdge, com.roblox.client.personasdk.R.attr.layout_keyline};

    /* renamed from: m, reason: collision with root package name */
    public static int[] f18038m = {com.roblox.client.personasdk.R.attr.fontProviderAuthority, com.roblox.client.personasdk.R.attr.fontProviderCerts, com.roblox.client.personasdk.R.attr.fontProviderFallbackQuery, com.roblox.client.personasdk.R.attr.fontProviderFetchStrategy, com.roblox.client.personasdk.R.attr.fontProviderFetchTimeout, com.roblox.client.personasdk.R.attr.fontProviderPackage, com.roblox.client.personasdk.R.attr.fontProviderQuery, com.roblox.client.personasdk.R.attr.fontProviderSystemFontFamily};

    /* renamed from: n, reason: collision with root package name */
    public static int[] f18039n = {R.attr.font, R.attr.fontWeight, R.attr.fontStyle, R.attr.ttcIndex, R.attr.fontVariationSettings, com.roblox.client.personasdk.R.attr.font, com.roblox.client.personasdk.R.attr.fontStyle, com.roblox.client.personasdk.R.attr.fontVariationSettings, com.roblox.client.personasdk.R.attr.fontWeight, com.roblox.client.personasdk.R.attr.ttcIndex};

    /* renamed from: o, reason: collision with root package name */
    public static int[] f18040o = {android.R.attr.startColor, R.attr.endColor, android.R.attr.type, android.R.attr.centerX, android.R.attr.centerY, android.R.attr.gradientRadius, android.R.attr.tileMode, android.R.attr.centerColor, android.R.attr.startX, android.R.attr.startY, android.R.attr.endX, android.R.attr.endY};

    /* renamed from: p, reason: collision with root package name */
    public static int[] f18041p = {R.attr.color, android.R.attr.offset};
}
