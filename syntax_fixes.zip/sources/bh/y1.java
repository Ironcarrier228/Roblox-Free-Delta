package bh;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Message;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.webkit.PermissionRequest;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.appcompat.app.a;
import androidx.core.graphics.Insets;
import androidx.core.view.WindowInsetsCompat;

import com.roblox.client.components.RobloxToolbar;
import com.roblox.engine.jni.NativeGLInterface;
import com.roblox.protocols.webview.DomainAllowListChecker;
import eh.v0;
import n5.d;
import org.greenrobot.eventbus.ThreadMode;
import wl.AndroidColorToken;

/* loaded from: classes2.dex */
public class y1 extends f4.q implements n5.d.j {

    /* renamed from: m0, reason: collision with root package name */
    public String f4399m0;

    /* renamed from: n0, reason: collision with root package name */
    public ProgressDialog f4400n0;

    /* renamed from: o0, reason: collision with root package name */
    public FrameLayout f4401o0;

    /* renamed from: p0, reason: collision with root package name */
    public boolean f4402p0;

    /* renamed from: q0, reason: collision with root package name */
    public ValueCallback<Uri[]> f4403q0;

    /* renamed from: t0, reason: collision with root package name */
    public ImageView f4406t0;

    /* renamed from: f0, reason: collision with root package name */
    public TextView f4392f0 = null;

    /* renamed from: g0, reason: collision with root package name */
    public qi.b f4393g0 = null;

    /* renamed from: h0, reason: collision with root package name */
    public n5.d f4394h0 = null;

    /* renamed from: i0, reason: collision with root package name */
    public String f4395i0 = null;

    /* renamed from: j0, reason: collision with root package name */
    public int f4396j0 = 0;

    /* renamed from: k0, reason: collision with root package name */
    public int f4397k0 = 0;

    /* renamed from: l0, reason: collision with root package name */
    public String f4398l0 = null;

    /* renamed from: r0, reason: collision with root package name */
    public boolean f4404r0 = false;

    /* renamed from: s0, reason: collision with root package name */
    public boolean f4405s0 = false;

    /* renamed from: u0, reason: collision with root package name */
    public boolean f4407u0 = false;

    /* renamed from: v0, reason: collision with root package name */
    public boolean f4408v0 = true;

    /* renamed from: w0, reason: collision with root package name */
    public wl.c f4409w0 = wl.b.tokens;

    /* renamed from: x0, reason: collision with root package name */
    public String f4410x0 = null;

    /* renamed from: y0, reason: collision with root package name */
    public final mj.o f4411y0 = new b();

    /* renamed from: z0, reason: collision with root package name */
    public final mj.o f4412z0 = new c();
    public final mj.o A0 = new d();
    public final mj.o B0 = new e();

    public class a extends WebChromeClient {
        public a() {
        }

        @Override // android.webkit.WebChromeClient
        public boolean onCreateWindow(WebView webView, boolean z10, boolean z11, Message message) {
            if (!z11) {
                return super.onCreateWindow(webView, z10, z11, message);
            }
            ((WebView.WebViewTransport) message.obj).setWebView(new WebView(webView.getContext()));
            message.sendToTarget();
            return true;
        }

        @Override // android.webkit.WebChromeClient
        public void onPermissionRequest(PermissionRequest permissionRequest) {
            for (String str : permissionRequest.getResources()) {
                if (str.equals("android.webkit.resource.VIDEO_CAPTURE")) {
                    if (l2.b.a(y1.this.p(), y.h().k().k(bn.o.CAMERA)) != 0) {
                        ok.q.h("rbx.web", "No permission granted for camera");
                        permissionRequest.deny();
                    } else {
                        ok.q.h("rbx.web", "Permission granted for camera");
                        permissionRequest.grant(new String[]{str});
                    }
                }
            }
        }

        @Override // android.webkit.WebChromeClient
        public void onProgressChanged(WebView webView, int i10) {
            super.onProgressChanged(webView, i10);
            y1.this.Y2(webView, i10);
        }

        @Override // android.webkit.WebChromeClient
        public boolean onShowFileChooser(WebView webView, ValueCallback<Uri[]> valueCallback, WebChromeClient.FileChooserParams fileChooserParams) {
            y1.this.f4403q0 = valueCallback;
            Intent intent = new Intent("android.intent.action.GET_CONTENT");
            intent.setType("image/*");
            y1.this.startActivityForResult(Intent.createChooser(intent, "Select Picture"), 20123);
            return true;
        }
    }

    public class b implements mj.o {
        public b() {
        }

        @Override // mj.o
        public void b() {
            y1.this.d3();
        }

        @Override // mj.o
        public void c() {
            y1.this.d3();
        }

        @Override // mj.o
        public void d() {
            y1.this.I2();
        }

        @Override // mj.o
        public void e(mj.p pVar) {
            y1.this.x2(pVar);
        }
    }

    public class c implements mj.o {
        public c() {
        }

        @Override // mj.o
        public void b() {
            y1.this.d3();
        }

        @Override // mj.o
        public void c() {
            y1.this.d3();
        }

        @Override // mj.o
        public void d() {
            y1.this.I2();
        }

        @Override // mj.o
        public void e(mj.p pVar) {
            y1.this.x2(pVar);
        }
    }

    public class d implements mj.o {
        public d() {
        }

        @Override // mj.o
        public void b() {
        }

        @Override // mj.o
        public void c() {
        }

        @Override // mj.o
        public void d() {
        }

        @Override // mj.o
        public void e(mj.p pVar) {
            ok.q.h("rbx.amazon.purchaseflow", "onPurchaseFinishedListener: Result=" + pVar + ".");
            y1.this.x2(pVar);
        }
    }

    public class e implements mj.o {
        public e() {
        }

        @Override // mj.o
        public void b() {
        }

        @Override // mj.o
        public void c() {
            y1.this.d3();
        }

        @Override // mj.o
        public void d() {
        }

        @Override // mj.o
        public void e(mj.p pVar) {
            y1.this.x2(pVar);
        }
    }

    public static /* synthetic */ class f {

        /* renamed from: a, reason: collision with root package name */
        public static final /* synthetic */ int[] f4418a;

        static {
            int[] iArr = new int[DomainAllowListChecker.a.values().length];
            f4418a = iArr;
            try {
                iArr[DomainAllowListChecker.a.b.ordinal()] = 1;
            } catch (NoSuchFieldError unused) {
            }
            try {
                f4418a[DomainAllowListChecker.a.f9747c.ordinal()] = 2;
            } catch (NoSuchFieldError unused2) {
            }
            try {
                f4418a[DomainAllowListChecker.a.f9748d.ordinal()] = 3;
            } catch (NoSuchFieldError unused3) {
            }
            try {
                f4418a[DomainAllowListChecker.a.f9746a.ordinal()] = 4;
            } catch (NoSuchFieldError unused4) {
            }
        }
    }

    public class g {
        public g() {
        }
    }

    public interface h {
    }

    public class i extends WebViewClient {

        /* renamed from: a, reason: collision with root package name */
        public String f4420a = null;

        public class a implements mi.m {
            public a() {
            }

            @Override // mi.m
            public void a(mi.j jVar) {
            }
        }

        public i() {
        }

        /* JADX WARN: Can't wrap try/catch for region: R(8:88|(2:89|90)|91|92|93|94|95|(2:97|98)) */
        /* JADX WARN: Code restructure failed: missing block: B:102:0x025e, code lost:
        
            ok.q.h("rbx.purchaseflow", "NullPointerException thrown while parsing paymentSession parameter for purchase url");
         */
        /* JADX WARN: Code restructure failed: missing block: B:103:0x025a, code lost:
        
            ok.q.h("rbx.purchaseflow", "UnsupportedOperationException thrown while parsing paymentSession parameter for purchase url");
         */
        /* JADX WARN: Removed duplicated region for block: B:97:0x0270 A[EXC_TOP_SPLITTER, SYNTHETIC] */
        /*
            Code decompiled incorrectly, please refer to instructions dump.
            To view partially-correct add '--show-bad-code' argument
        */
        public final boolean d(final android.webkit.WebView r15, final java.lang.String r16, boolean r17, boolean r18) {
            /*
                Method dump skipped, instructions count: 716
                To view this dump add '--comments-level debug' option
            */
            throw new UnsupportedOperationException("Method not decompiled: bh.y1.i.d(android.webkit.WebView, java.lang.String, boolean, boolean):boolean");
        }

        public final /* synthetic */ void e() {
            try {
                y1.this.D2().T(q0.A1);
            } catch (u0 unused) {
                y1.U2();
            }
        }

        public final /* synthetic */ void f(f4.v vVar, String str, WebView webView) {
            if (vVar.isFinishing() || vVar.isDestroyed()) {
                return;
            }
            y1.this.f4392f0.setText(str);
            webView.loadUrl(str);
        }

        public final /* synthetic */ void g(String str, final String str2, final f4.v vVar, final WebView webView, boolean z10) {
            if (!z10) {
                if (str != null) {
                    ym.g.G().o(str, "success", "handled_in_webview");
                }
                if (DomainAllowListChecker.f9745a.enableDomainAllowListChecker()) {
                    y1.this.a3(str2);
                    return;
                } else {
                    vVar.runOnUiThread(new Runnable() { // from class: bh.b2
                        @Override // java.lang.Runnable
                        public final void run() {
                            y1.i.this.f(vVar, str2, webView);
                        }
                    });
                    return;
                }
            }
            ym.g G = ym.g.G();
            if (str == null) {
                str = G.k(str2, "android_webview");
            }
            if (str == null || str.isEmpty()) {
                mw.c.d().j(y1.this.new g());
                ym.g.G().h(str2, "android_webview", false);
                ym.g.G().m(str2);
            } else {
                G.A(str2, "android_webview", false);
                mw.c.d().j(y1.this.new g());
                G.l(str);
            }
        }

        @Override // android.webkit.WebViewClient
        public void onLoadResource(WebView webView, String str) {
            super.onLoadResource(webView, str);
            dl.h.j().n(a1.g());
        }

        @Override // android.webkit.WebViewClient
        public void onPageFinished(WebView webView, String str) {
            y1.this.f4394h0.setRefreshing(false);
            ok.q.h("rbx.web", "onPageFinished. url=" + str);
            y1.this.X2(str);
            if (bi.h.a().W1()) {
                dl.h.j().n(a1.g());
            }
            if (bi.h.a().p2() && !webView.hasFocus()) {
                webView.requestFocus();
            }
            if (DomainAllowListChecker.f9745a.enableDomainAllowListChecker()) {
                this.f4420a = null;
            }
            if (di.m.b().a(str)) {
                y1.this.f4393g0.reload();
            }
        }

        @Override // android.webkit.WebViewClient
        public void onPageStarted(WebView webView, String str, Bitmap bitmap) {
            ok.q.h("rbx.web", "-> " + str);
            y1.this.W2(str);
            y1.this.f4394h0.setRefreshing(true);
        }

        @Override // android.webkit.WebViewClient
        public boolean shouldOverrideUrlLoading(WebView webView, WebResourceRequest webResourceRequest) {
            if (!DomainAllowListChecker.f9745a.enableDomainAllowListChecker()) {
                return d(webView, webResourceRequest.getUrl().toString(), webResourceRequest.hasGesture(), webResourceRequest.isForMainFrame());
            }
            String uri = webResourceRequest.getUrl().toString();
            if (!uri.equals(this.f4420a) || webResourceRequest.hasGesture()) {
                this.f4420a = uri;
                return d(webView, uri, webResourceRequest.hasGesture(), webResourceRequest.isForMainFrame());
            }
            ok.q.h("rbx.web", "Skipping duplicate shouldOverrideUrlLoading call for URL: " + uri);
            return true;
        }
    }

    private void C2(final String str, boolean z10) {
        final f4.v p8 = p();
        if (p8 == null || p8.isFinishing() || p8.isDestroyed()) {
            return;
        }
        p8.runOnUiThread(new Runnable() { // from class: bh.t1
            @Override // java.lang.Runnable
            public final void run() {
                y1.this.N2(p8, str);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public boolean H2(String str) {
        Intent intent = str.startsWith("mailto:") ? new Intent("android.intent.action.SENDTO", Uri.parse(str)) : str.startsWith("tel:") ? new Intent("android.intent.action.DIAL", Uri.parse(str)) : null;
        if (intent == null) {
            return false;
        }
        if (ok.t.a(v(), intent)) {
            X1(intent);
            return true;
        }
        try {
            D2().K1(q0.U, 1);
        } catch (u0 unused) {
            U2();
        }
        return true;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void I2() {
        final f4.v p8 = p();
        if (p8 != null) {
            p8.runOnUiThread(new Runnable() { // from class: bh.r1
                @Override // java.lang.Runnable
                public final void run() {
                    y1.this.O2(p8);
                }
            });
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void K2(f4.v vVar, DialogInterface dialogInterface) {
        if (TextUtils.isEmpty(this.f4393g0.getUrl())) {
            vVar.onBackPressed();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void L2(final f4.v vVar, final String str) {
        new androidx.appcompat.app.a.C0021a(vVar).d(false).p(q0.f4274s0).g(q0.f4271r0).i(q0.f4270r, null).m(q0.f4273s, new DialogInterface.OnClickListener() { // from class: bh.v1
            @Override // android.content.DialogInterface.OnClickListener
            public final void onClick(DialogInterface dialogInterface, int i10) {
                new ym.a("rbx.web").e(f4.v.this, str, r1);
            }
        }).k(new DialogInterface.OnDismissListener() { // from class: bh.w1
            @Override // android.content.DialogInterface.OnDismissListener
            public final void onDismiss(DialogInterface dialogInterface) {
                y1.this.K2(vVar, dialogInterface);
            }
        }).r();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void M2(f4.v vVar, mj.p pVar) {
        if (vVar == null || vVar.isFinishing() || vVar.isDestroyed()) {
            return;
        }
        I2();
        e3(pVar);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void N2(f4.v vVar, String str) {
        if (vVar.isFinishing() || vVar.isDestroyed()) {
            return;
        }
        this.f4392f0.setText(str);
        this.f4393g0.loadUrl(str);
    }

    public static void U2() {
        ok.q.k("roblox.app", "The activity containing this fragment must be of type RobloxActivity!");
    }

    /* JADX INFO: Access modifiers changed from: private */
    public boolean V2(String str) {
        hk.b bVar = new hk.b("rbx.web");
        if (!bVar.b(str)) {
            return false;
        }
        bVar.a(p(), str, str);
        return true;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void a3(final String str) {
        DomainAllowListChecker domainAllowListChecker = DomainAllowListChecker.f9745a;
        if (domainAllowListChecker.isKnownTrustedDomain(str, this.f4410x0)) {
            C2(str, false);
        } else {
            domainAllowListChecker.checkDomainAllowList(str, this.f4410x0, new DomainAllowListChecker.Callback() { // from class: bh.s1
                @Override // com.roblox.protocols.webview.DomainAllowListChecker.Callback
                public final void onResult(DomainAllowListChecker.a aVar) {
                    y1.this.P2(str, aVar);
                }
            });
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void c3(String str, boolean z10) {
        if (str.contains("sponsored")) {
            this.f4393g0.getSettings().setBuiltInZoomControls(z10);
        } else {
            this.f4393g0.getSettings().setBuiltInZoomControls(!z10);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void d3() {
        final f4.v p8 = p();
        if (p8 != null) {
            p8.runOnUiThread(new Runnable() { // from class: bh.x1
                @Override // java.lang.Runnable
                public final void run() {
                    y1.this.S2(p8);
                }
            });
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    private void e3(mj.p pVar) {
        boolean z10;
        f4.v p8 = p();
        if (p8 == null) {
            return;
        }
        if (bi.h.a().r5()) {
            z10 = bi.h.a().Q0().contains(((mj.j) pVar).a());
        } else {
            z10 = false;
        }
        ok.q.b("rbx.web", "isBonusItemEnabled = " + z10);
        CharSequence c10 = pVar.c(p8);
        if (pVar.f()) {
            y2(c10);
            return;
        }
        try {
            if (!z10) {
                D2().V(c10.toString());
                return;
            }
            D2().F1(d0(q0.D1), d0(q0.E1));
        } catch (u0 unused) {
            U2();
        }
    }

    public static /* bridge */ /* synthetic */ h o2(y1 y1Var) {
        y1Var.getClass();
        return null;
    }

    private void w2(final String str) {
        final f4.v p8 = p();
        if (p8 == null || p8.isFinishing() || p8.isDestroyed()) {
            return;
        }
        p8.runOnUiThread(new Runnable() { // from class: bh.u1
            @Override // java.lang.Runnable
            public final void run() {
                y1.this.L2(p8, str);
            }
        });
    }

    private synchronized void y2(CharSequence charSequence) {
        f4.v p8 = p();
        if (p8 == null) {
            return;
        }
        androidx.appcompat.app.a a10 = new androidx.appcompat.app.a.C0021a(p8).a();
        TextView textView = new TextView(p8);
        String string = p8.getString(q0.W);
        int indexOf = charSequence.toString().indexOf(string);
        pk.b.b(textView, charSequence.toString(), new pk.c(p8, null, string, indexOf, indexOf + string.length()));
        textView.setTextSize(20.0f);
        textView.setEllipsize(null);
        a10.w(textView, 150, 100, 150, 100);
        a10.setCanceledOnTouchOutside(true);
        try {
            a10.show();
        } catch (WindowManager.BadTokenException unused) {
        }
    }

    private ProgressDialog z2(Context context, String str, String str2) {
        ProgressDialog progressDialog = new ProgressDialog(context);
        progressDialog.setTitle(str);
        progressDialog.setMessage(str2);
        progressDialog.setIndeterminate(true);
        progressDialog.setCancelable(true);
        progressDialog.setCanceledOnTouchOutside(false);
        progressDialog.setOnCancelListener(null);
        return progressDialog;
    }

    @Override // f4.q
    public void A0(int i10, int i11, Intent intent) {
        if (i10 == 20123) {
            if (i11 == -1) {
                this.f4403q0.onReceiveValue(new Uri[]{intent.getData()});
            } else {
                ok.q.h("rbx.web", "Result of file chooser invalid.");
                this.f4403q0.onReceiveValue(null);
            }
        }
    }

    public qi.b A2() {
        qi.b aVar = this.f4404r0 ? new qi.a(v()) : new qi.b(v());
        if (bi.h.a().W1()) {
            dl.e.A(a1.O());
        }
        return aVar;
    }

    public void B2() {
        if (p() != null) {
            p().l1().a1();
        }
    }

    @NonNull
    public com.roblox.client.a D2() {
        f4.v p8 = p();
        if (p8 instanceof com.roblox.client.a) {
            return (com.roblox.client.a) p8;
        }
        throw new u0();
    }

    public boolean E2(String str, boolean z10) {
        Bundle t8 = t();
        return t8 != null ? t8.getBoolean(str, z10) : z10;
    }

    @Override // f4.q
    public void F0(Bundle bundle) {
        super.F0(bundle);
        bl.b.a().n(this);
        Bundle t8 = t();
        if (t8 != null) {
            String string = t8.getString("DEFAULT_URL", null);
            ok.q.b("rbx.web", "onCreate: default-URL = " + string + ".");
            if (string != null) {
                this.f4398l0 = string;
                if (this.f4395i0 == null) {
                    this.f4395i0 = string;
                    if (DomainAllowListChecker.f9745a.enableDomainAllowListChecker()) {
                        this.f4410x0 = string;
                    }
                }
            }
            this.f4399m0 = t8.getString("WEB_VIEW_TAG", null);
            this.f4404r0 = t8.getBoolean("USE_APP_HYBRID");
        }
    }

    public String F2() {
        return "undefinedWebContext";
    }

    public boolean G2() {
        qi.b bVar = this.f4393g0;
        if (bVar == null || !bVar.canGoBack()) {
            return false;
        }
        c3(this.f4393g0.getUrl(), false);
        this.f4393g0.goBack();
        return true;
    }

    @Override // f4.q
    public View J0(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        boolean z10 = bi.h.a().I0() && E2("hideNativeHeader", false);
        this.f4405s0 = z10;
        View inflate = layoutInflater.inflate(z10 ? n0.f4195n : n0.f4194m, viewGroup, false);
        if (bi.h.a().K3() && !this.f4405s0) {
            ui.g.b(inflate);
        }
        ViewGroup viewGroup2 = (ViewGroup) inflate.findViewById(m0.f4151l0);
        this.f4392f0 = (TextView) inflate.findViewById(m0.f4175x0);
        i iVar = new i();
        this.f4393g0 = A2();
        if (bi.h.a().q2()) {
            this.f4393g0.setCommandListener(new x());
        }
        viewGroup2.addView(this.f4393g0, new ViewGroup.LayoutParams(-1, -1));
        this.f4393g0.setTag(this.f4399m0);
        this.f4393g0.setWebViewClient(iVar);
        this.f4393g0.getSettings().setSupportMultipleWindows(true);
        this.f4393g0.setWebChromeClient(new a());
        this.f4393g0.getSettings().setJavaScriptEnabled(true);
        this.f4393g0.getSettings().setDomStorageEnabled(true);
        this.f4393g0.getSettings().setUserAgentString(a1.a1());
        this.f4393g0.getSettings().setCacheMode(-1);
        this.f4393g0.setHorizontalScrollBarEnabled(false);
        this.f4393g0.setVerticalScrollBarEnabled(false);
        if (wh.b.a()) {
            WebView.setWebContentsDebuggingEnabled(true);
        }
        if (this.f4395i0 != null) {
            if (DomainAllowListChecker.f9745a.enableDomainAllowListChecker()) {
                a3(this.f4395i0);
            } else {
                this.f4393g0.loadUrl(this.f4395i0);
            }
            this.f4395i0 = null;
        }
        n5.d dVar = (n5.d) inflate.findViewById(m0.f4151l0);
        this.f4394h0 = dVar;
        dVar.setOnRefreshListener(this);
        n5.d dVar2 = this.f4394h0;
        int i10 = j0.b;
        int i11 = j0.f4092o;
        dVar2.setColorSchemeResources(i10, i10, i11, i11);
        this.f4401o0 = (FrameLayout) inflate.findViewById(m0.f4153m0);
        Bundle t8 = t();
        if (t8 != null) {
            this.f4396j0 = t8.getInt("dialogHeight", 0);
            this.f4397k0 = t8.getInt("dialogWidth", 0);
            if (!t8.getBoolean("enablePullToRefresh", true)) {
                this.f4394h0.setEnabled(false);
            }
            this.f4402p0 = t8.getBoolean("USING_LOGIN_WEB_URL", false);
            this.f4408v0 = t8.getBoolean("VISIBLE", true);
            this.f4407u0 = t8.getBoolean("BACK_NAVIGATION_DISABLED", false);
        }
        try {
            D2().N1();
        } catch (u0 unused) {
            U2();
        }
        this.f4393g0.h();
        if (this.f4405s0) {
            b3(inflate);
        }
        return inflate;
    }

    public boolean J2() {
        return this.f4407u0;
    }

    @Override // f4.q
    public void K0() {
        bl.b.a().p(this);
        super.K0();
    }

    @Override // f4.q
    public void M0() {
        super.M0();
        this.f4393g0.i();
    }

    public final /* synthetic */ void O2(f4.v vVar) {
        ProgressDialog progressDialog;
        if (vVar == null || vVar.isFinishing() || vVar.isDestroyed() || (progressDialog = this.f4400n0) == null || !progressDialog.isShowing()) {
            return;
        }
        this.f4400n0.dismiss();
    }

    @Override // f4.q
    public void P0(boolean z10) {
        super.P0(z10);
        if (z10 || !di.m.b().a(this.f4393g0.getUrl())) {
            return;
        }
        this.f4393g0.reload();
    }

    public final /* synthetic */ void P2(String str, DomainAllowListChecker.a aVar) {
        int i10 = f.f4418a[aVar.ordinal()];
        if (i10 == 1) {
            C2(str, false);
            return;
        }
        if (i10 == 2) {
            C2(str, true);
        } else if (i10 == 3 || i10 == 4) {
            w2(str);
        }
    }

    public final /* synthetic */ void Q2(View view) {
        B2();
    }

    public final /* synthetic */ WindowInsetsCompat R2(int i10, View view, WindowInsetsCompat windowInsetsCompat) {
        Insets insets = windowInsetsCompat.getInsets(WindowInsetsCompat.Type.systemBars());
        FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) this.f4406t0.getLayoutParams();
        layoutParams.topMargin = i10 + insets.top;
        this.f4406t0.setLayoutParams(layoutParams);
        return windowInsetsCompat;
    }

    public final /* synthetic */ void S2(f4.v vVar) {
        if (vVar == null || vVar.isFinishing() || vVar.isDestroyed()) {
            return;
        }
        if (this.f4400n0 == null) {
            this.f4400n0 = z2(vVar, null, d0(q0.P));
        }
        this.f4400n0.show();
    }

    public void T2(String str) {
        eh.v0.w(g3(), str);
        if (this.f4393g0 == null) {
            this.f4395i0 = str;
        } else if (DomainAllowListChecker.f9745a.enableDomainAllowListChecker()) {
            a3(str);
        } else {
            this.f4393g0.loadUrl(str);
        }
        if (DomainAllowListChecker.f9745a.enableDomainAllowListChecker()) {
            this.f4410x0 = str;
        }
    }

    @Override // f4.q
    public void V0() {
        super.V0();
        qi.b bVar = this.f4393g0;
        if (bVar != null) {
            bVar.onPause();
        }
    }

    public void W2(String str) {
    }

    public void X2(String str) {
    }

    public void Y2(WebView webView, int i10) {
    }

    public final int Z2(cm.a aVar) {
        boolean z10 = aVar == cm.a.f5519d;
        AndroidColorToken b10 = this.f4409w0.b("Surface.Surface_0");
        return androidx.core.graphics.c.l(b10 != null ? z10 ? b10.getDark() : b10.getLight() : z10 ? l2.b.c(v(), j0.f4084g) : l2.b.c(v(), j0.f4092o), 235);
    }

    @Override // f4.q
    public void a1() {
        super.a1();
        qi.b bVar = this.f4393g0;
        if (bVar != null) {
            bVar.onResume();
        }
    }

    public void b3(View view) {
        ImageView imageView = (ImageView) view.findViewById(m0.D);
        this.f4406t0 = imageView;
        if (!this.f4405s0 || imageView == null) {
            return;
        }
        imageView.setVisibility(0);
        this.f4406t0.setImageResource(new RobloxToolbar.c().a(nk.c.c().g()));
        this.f4406t0.setOnClickListener(new View.OnClickListener() { // from class: bh.p1
            @Override // android.view.View.OnClickListener
            public final void onClick(View view2) {
                y1.this.Q2(view2);
            }
        });
        f3(nk.c.c().g());
        final int i10 = (int) (S().getDisplayMetrics().density * 10.0f);
        androidx.core.view.o0.A0(view, new androidx.core.view.y() { // from class: bh.q1
            @Override // androidx.core.view.y
            public final WindowInsetsCompat J(View view2, WindowInsetsCompat windowInsetsCompat) {
                WindowInsetsCompat R2;
                R2 = y1.this.R2(i10, view2, windowInsetsCompat);
                return R2;
            }
        });
    }

    @Override // f4.q
    public void c1() {
        super.c1();
    }

    @Override // f4.q
    public void d1() {
        super.d1();
    }

    @Override // n5.d.j
    public void e() {
        if (p() != null) {
            if (((com.roblox.client.a) p()).N1()) {
                this.f4394h0.setRefreshing(false);
            } else {
                this.f4393g0.reload();
            }
        }
    }

    public void f3(cm.a aVar) {
        if (this.f4406t0 == null) {
            return;
        }
        int Z2 = Z2(aVar);
        GradientDrawable gradientDrawable = new GradientDrawable();
        gradientDrawable.setShape(1);
        gradientDrawable.setColor(Z2);
        this.f4406t0.setBackground(gradientDrawable);
    }

    public v0.b g3() {
        return v0.b.f13638d;
    }

    @mw.j(threadMode = ThreadMode.MAIN)
    public void onEmitRbHybridEvent(bl.a aVar) {
        if (this.f4393g0 != null) {
            throw null;
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    public void x2(final mj.p pVar) {
        if (bi.h.a().u1() && (pVar instanceof mj.j)) {
            mj.j jVar = (mj.j) pVar;
            String b10 = jVar.b();
            if (!b10.isEmpty()) {
                NativeGLInterface.nativeMarketplacePurchaseFinished(pVar.d(), jVar.a().toString(), b10);
            }
        }
        final f4.v p8 = p();
        if (p8 != null) {
            p8.runOnUiThread(new Runnable() { // from class: bh.o1
                @Override // java.lang.Runnable
                public final void run() {
                    y1.this.M2(p8, pVar);
                }
            });
        }
    }
}
