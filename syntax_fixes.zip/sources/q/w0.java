package q;

import android.R;
import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.TypedArray;
import android.graphics.Color;
import android.util.Log;
import android.util.TypedValue;
import android.view.View;
import androidx.annotation.NonNull;

/* loaded from: classes.dex */
public class w0 {

    /* renamed from: a, reason: collision with root package name */
    public static final ThreadLocal<TypedValue> f29672a = new ThreadLocal<>();
    public static final int[] b = {-16842910};

    /* renamed from: c, reason: collision with root package name */
    public static final int[] f29673c = {android.R.attr.state_focused};

    /* renamed from: d, reason: collision with root package name */
    public static final int[] f29674d = {android.R.attr.state_activated};

    /* renamed from: e, reason: collision with root package name */
    public static final int[] f29675e = {android.R.attr.state_pressed};

    /* renamed from: f, reason: collision with root package name */
    public static final int[] f29676f = {android.R.attr.state_checked};

    /* renamed from: g, reason: collision with root package name */
    public static final int[] f29677g = {android.R.attr.state_selected};

    /* renamed from: h, reason: collision with root package name */
    public static final int[] f29678h = {-16842919, -16842908};

    /* renamed from: i, reason: collision with root package name */
    public static final int[] f29679i = new int[0];

    /* renamed from: j, reason: collision with root package name */
    public static final int[] f29680j = new int[1];

    public static void a(@NonNull View view, @NonNull Context context) {
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(i.j.A0);
        try {
            if (!obtainStyledAttributes.hasValue(i.j.F0)) {
                Log.e("ThemeUtils", "View " + view.getClass() + " is an AppCompat widget that can only be used with a Theme.AppCompat theme (or descendant).");
            }
        } finally {
            obtainStyledAttributes.recycle();
        }
    }

    public static int b(@NonNull Context context, int i10) {
        ColorStateList e10 = e(context, i10);
        if (e10 != null && e10.isStateful()) {
            return e10.getColorForState(b, e10.getDefaultColor());
        }
        TypedValue f10 = f();
        context.getTheme().resolveAttribute(android.R.attr.disabledAlpha, f10, true);
        return d(context, i10, f10.getFloat());
    }

    public static int c(@NonNull Context context, int i10) {
        int[] iArr = f29680j;
        iArr[0] = i10;
        b1 u8 = b1.u(context, null, iArr);
        try {
            return u8.b(0, 0);
        } finally {
            u8.x();
        }
    }

    public static int d(@NonNull Context context, int i10, float f10) {
        return androidx.core.graphics.c.l(c(context, i10), Math.round(Color.alpha(r0) * f10));
    }

    public static ColorStateList e(@NonNull Context context, int i10) {
        int[] iArr = f29680j;
        iArr[0] = i10;
        b1 u8 = b1.u(context, null, iArr);
        try {
            return u8.c(0);
        } finally {
            u8.x();
        }
    }

    public static TypedValue f() {
        ThreadLocal<TypedValue> threadLocal = f29672a;
        TypedValue typedValue = threadLocal.get();
        if (typedValue != null) {
            return typedValue;
        }
        TypedValue typedValue2 = new TypedValue();
        threadLocal.set(typedValue2);
        return typedValue2;
    }
}
