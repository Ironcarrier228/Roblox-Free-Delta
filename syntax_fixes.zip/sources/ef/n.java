package ef;

import cf.f0;
import cf.h0;
import cf.p0;
import df.i;
import java.security.GeneralSecurityException;
import ye.f0;
import ye.g0;
import ye.l0;
import ye.m;
import ye.m0;

import ye.s0;

/* loaded from: classes2.dex */
public final class n {

    /* renamed from: a, reason: collision with root package name */
    public static final gf.a f13414a;
    public static final gf.a b;

    /* renamed from: c, reason: collision with root package name */
    public static final ye.g0<df.i, m0> f13415c;

    /* renamed from: d, reason: collision with root package name */
    public static final ye.f0<m0> f13416d;

    /* renamed from: e, reason: collision with root package name */
    public static final ye.n<df.o, l0> f13417e;

    /* renamed from: f, reason: collision with root package name */
    public static final ye.m<l0> f13418f;

    /* renamed from: g, reason: collision with root package name */
    public static final ye.n<df.j, l0> f13419g;

    /* renamed from: h, reason: collision with root package name */
    public static final ye.m<l0> f13420h;

    /* renamed from: i, reason: collision with root package name */
    public static final ye.h<p0, i.a> f13421i;

    static {
        gf.a h10 = s0.h("type.googleapis.com/google.crypto.tink.Ed25519PrivateKey");
        f13414a = h10;
        gf.a h11 = s0.h("type.googleapis.com/google.crypto.tink.Ed25519PublicKey");
        b = h11;
        f13415c = ye.g0.a(new g0.b() { // from class: ef.h
            @Override // ye.g0.b
            public final ye.p0 a(re.x xVar) {
                m0 m10;
                m10 = n.m((df.i) xVar);
                return m10;
            }
        }, df.i.class, m0.class);
        f13416d = ye.f0.a(new f0.b() { // from class: ef.i
            @Override // ye.f0.b
            public final re.x a(ye.p0 p0Var) {
                df.i h12;
                h12 = n.h((m0) p0Var);
                return h12;
            }
        }, h10, m0.class);
        f13417e = ye.n.a(new n.b() { // from class: ef.j
            @Override // ye.n.b
            public final ye.p0 a(re.l lVar, re.d0 d0Var) {
                l0 o10;
                o10 = n.o((df.o) lVar, d0Var);
                return o10;
            }
        }, df.o.class, l0.class);
        f13418f = ye.m.a(new m.b() { // from class: ef.k
            @Override // ye.m.b
            public final re.l a(ye.p0 p0Var, re.d0 d0Var) {
                df.o j10;
                j10 = n.j((l0) p0Var, d0Var);
                return j10;
            }
        }, h11, l0.class);
        f13419g = ye.n.a(new n.b() { // from class: ef.l
            @Override // ye.n.b
            public final ye.p0 a(re.l lVar, re.d0 d0Var) {
                l0 n10;
                n10 = n.n((df.j) lVar, d0Var);
                return n10;
            }
        }, df.j.class, l0.class);
        f13420h = ye.m.a(new m.b() { // from class: ef.m
            @Override // ye.m.b
            public final re.l a(ye.p0 p0Var, re.d0 d0Var) {
                df.j i10;
                i10 = n.i((l0) p0Var, d0Var);
                return i10;
            }
        }, h10, l0.class);
        f13421i = ye.h.a().a(p0.RAW, i.a.f12288e).a(p0.TINK, i.a.b).a(p0.CRUNCHY, i.a.f12286c).a(p0.LEGACY, i.a.f12287d).b();
    }

    public static cf.y g(df.o oVar) {
        return cf.y.e0().D(com.google.crypto.tink.shaded.protobuf.h.e(oVar.f().d())).build();
    }

    public static df.i h(m0 m0Var) {
        if (!m0Var.d().f0().equals("type.googleapis.com/google.crypto.tink.Ed25519PrivateKey")) {
            throw new IllegalArgumentException("Wrong type URL in call to Ed25519ProtoSerialization.parseParameters: " + m0Var.d().f0());
        }
        try {
            if (cf.w.c0(m0Var.d().g0(), com.google.crypto.tink.shaded.protobuf.p.b()).b0() == 0) {
                return df.i.b(f13421i.b(m0Var.d().e0()));
            }
            throw new GeneralSecurityException("Only version 0 keys are accepted");
        } catch (com.google.crypto.tink.shaded.protobuf.b0 e10) {
            throw new GeneralSecurityException("Parsing Ed25519Parameters failed: ", e10);
        }
    }

    public static df.j i(l0 l0Var, re.d0 d0Var) {
        if (!l0Var.f().equals("type.googleapis.com/google.crypto.tink.Ed25519PrivateKey")) {
            throw new IllegalArgumentException("Wrong type URL in call to Ed25519ProtoSerialization.parsePrivateKey: " + l0Var.f());
        }
        try {
            cf.x g02 = cf.x.g0(l0Var.g(), com.google.crypto.tink.shaded.protobuf.p.b());
            if (g02.e0() != 0) {
                throw new GeneralSecurityException("Only version 0 keys are accepted");
            }
            cf.y d02 = g02.d0();
            if (d02.d0() == 0) {
                return df.j.d(df.o.c(f13421i.b(l0Var.e()), gf.a.a(d02.c0().v()), l0Var.c()), gf.c.a(g02.c0().v(), re.d0.b(d0Var)));
            }
            throw new GeneralSecurityException("Only version 0 keys are accepted");
        } catch (com.google.crypto.tink.shaded.protobuf.b0 unused) {
            throw new GeneralSecurityException("Parsing Ed25519PrivateKey failed");
        }
    }

    public static df.o j(l0 l0Var, re.d0 d0Var) {
        if (!l0Var.f().equals("type.googleapis.com/google.crypto.tink.Ed25519PublicKey")) {
            throw new IllegalArgumentException("Wrong type URL in call to Ed25519ProtoSerialization.parsePublicKey: " + l0Var.f());
        }
        try {
            cf.y f02 = cf.y.f0(l0Var.g(), com.google.crypto.tink.shaded.protobuf.p.b());
            if (f02.d0() == 0) {
                return df.o.c(f13421i.b(l0Var.e()), gf.a.a(f02.c0().v()), l0Var.c());
            }
            throw new GeneralSecurityException("Only version 0 keys are accepted");
        } catch (com.google.crypto.tink.shaded.protobuf.b0 unused) {
            throw new GeneralSecurityException("Parsing Ed25519PublicKey failed");
        }
    }

    public static void k() {
        l(ye.d0.c());
    }

    public static void l(ye.d0 d0Var) {
        d0Var.m(f13415c);
        d0Var.l(f13416d);
        d0Var.k(f13417e);
        d0Var.j(f13418f);
        d0Var.k(f13419g);
        d0Var.j(f13420h);
    }

    public static m0 m(df.i iVar) {
        return m0.c(h0.h0().F("type.googleapis.com/google.crypto.tink.Ed25519PrivateKey").G(cf.w.a0().b()).D(f13421i.c(iVar.c())).build());
    }

    public static l0 n(df.j jVar, re.d0 d0Var) {
        return l0.b("type.googleapis.com/google.crypto.tink.Ed25519PrivateKey", cf.x.f0().F(g(jVar.c())).D(com.google.crypto.tink.shaded.protobuf.h.e(jVar.f().d(re.d0.b(d0Var)))).build().b(), f0.c.ASYMMETRIC_PRIVATE, f13421i.c(jVar.e().c()), jVar.a());
    }

    public static l0 o(df.o oVar, re.d0 d0Var) {
        return l0.b("type.googleapis.com/google.crypto.tink.Ed25519PublicKey", g(oVar).b(), f0.c.ASYMMETRIC_PUBLIC, f13421i.c(oVar.e().c()), oVar.a());
    }
}
