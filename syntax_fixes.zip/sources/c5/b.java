package c5;

import android.os.SystemClock;
import av.d2;
import av.p0;
import av.z0;
import com.github.luben.zstd.BuildConfig;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import zt.o;

@Metadata(d1 = {"\u0000f\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\u0010\t\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\b\n\u0002\u0018\u0002\n\u0002\b\u0011\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0007\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0006\b\u0000\u0018\u0000 \r2\u00020\u0001:\u0002%#B!\u0012\u0006\u0010\u0003\u001a\u00020\u0002\u0012\u0006\u0010\u0005\u001a\u00020\u0004\u0012\b\b\u0002\u0010\u0007\u001a\u00020\u0006¢\u0006\u0004\b\b\u0010\tJ\u0015\u0010\r\u001a\u00020\f2\u0006\u0010\u000b\u001a\u00020\n¢\u0006\u0004\b\r\u0010\u000eJ\u0015\u0010\u0011\u001a\u00020\f2\u0006\u0010\u0010\u001a\u00020\u000f¢\u0006\u0004\b\u0011\u0010\u0012J'\u0010\u0017\u001a\u00028\u0000\"\u0004\b\u0000\u0010\u00132\u0012\u0010\u0016\u001a\u000e\u0012\u0004\u0012\u00020\u0015\u0012\u0004\u0012\u00028\u00000\u0014¢\u0006\u0004\b\u0017\u0010\u0018J\r\u0010\u0019\u001a\u00020\u0015¢\u0006\u0004\b\u0019\u0010\u001aJ\r\u0010\u001b\u001a\u00020\f¢\u0006\u0004\b\u001b\u0010\u001cJ\r\u0010\u001d\u001a\u00020\f¢\u0006\u0004\b\u001d\u0010\u001cJ\u001b\u0010 \u001a\u00020\f2\f\u0010\u001f\u001a\b\u0012\u0004\u0012\u00020\f0\u001e¢\u0006\u0004\b \u0010!J\u000f\u0010\"\u001a\u00020\fH\u0002¢\u0006\u0004\b\"\u0010\u001cR\u0014\u0010\u0007\u001a\u00020\u00068\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b#\u0010$R\u0016\u0010\u000b\u001a\u00020\n8\u0002@\u0002X\u0082.¢\u0006\u0006\n\u0004\b%\u0010&R\u0016\u0010\u0010\u001a\u00020\u000f8\u0002@\u0002X\u0082.¢\u0006\u0006\n\u0004\b'\u0010(R\u001e\u0010+\u001a\n\u0012\u0004\u0012\u00020\f\u0018\u00010\u001e8\u0002@\u0002X\u0082\u000e¢\u0006\u0006\n\u0004\b)\u0010*R\u0014\u0010-\u001a\u00020\u00018\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b\"\u0010,R\u0014\u0010/\u001a\u00020\u00028\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b\u001d\u0010.R\u0014\u00102\u001a\u0002008\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b\u001b\u00101R\u0016\u00105\u001a\u0002038\u0002@\u0002X\u0082\u000e¢\u0006\u0006\n\u0004\b\u0017\u00104R$\u0010:\u001a\u0004\u0018\u00010\u00158\u0000@\u0000X\u0081\u000e¢\u0006\u0012\n\u0004\b6\u00107\u001a\u0004\b6\u0010\u001a\"\u0004\b8\u00109R\u0016\u0010=\u001a\u00020;8\u0002@\u0002X\u0082\u000e¢\u0006\u0006\n\u0004\b\u0019\u0010<R\u0018\u0010@\u001a\u0004\u0018\u00010>8\u0002@\u0002X\u0082\u000e¢\u0006\u0006\n\u0004\b\u0011\u0010?R\u0011\u0010C\u001a\u00020;8F¢\u0006\u0006\u001a\u0004\bA\u0010B¨\u0006D"}, d2 = {"Lc5/b;", BuildConfig.FLAVOR, BuildConfig.FLAVOR, "timeoutAmount", "Ljava/util/concurrent/TimeUnit;", "timeUnit", "Lc5/b$b;", "watch", "<init>", "(JLjava/util/concurrent/TimeUnit;Lc5/b$b;)V", "Lh5/d;", "delegateOpenHelper", BuildConfig.FLAVOR, "l", "(Lh5/d;)V", "Lav/p0;", "coroutineScope", "k", "(Lav/p0;)V", "V", "Lkotlin/Function1;", "Lh5/c;", "block", "h", "(Lkotlin/jvm/functions/Function1;)Ljava/lang/Object;", "j", "()Lh5/c;", "g", "()V", "f", "Lkotlin/Function0;", "onAutoClose", "n", "(Lkotlin/jvm/functions/Function0;)V", "e", xe.a.f36648e, "Lc5/b$b;", k6.b.f21144e, "Lh5/d;", "c", "Lav/p0;", "d", "Lkotlin/jvm/functions/Function0;", "onAutoCloseCallback", "Ljava/lang/Object;", "lock", "J", "autoCloseTimeoutInMs", "Ljava/util/concurrent/atomic/AtomicInteger;", "Ljava/util/concurrent/atomic/AtomicInteger;", "referenceCount", "Ljava/util/concurrent/atomic/AtomicLong;", "Ljava/util/concurrent/atomic/AtomicLong;", "lastDecrementRefCountTimeStamp", "i", "Lh5/c;", "setDelegateDatabase$room_runtime", "(Lh5/c;)V", "delegateDatabase", BuildConfig.FLAVOR, "Z", "manuallyClosed", "Lav/d2;", "Lav/d2;", "autoCloseJob", "m", "()Z", "isActive", "room-runtime"}, k = 1, mv = {2, 1, 0}, xi = 48)
/* loaded from: classes.dex */
public final class b {

    /* renamed from: a, reason: collision with root package name and from kotlin metadata */
    @NotNull
    public final InterfaceC0092b watch;

    /* renamed from: b, reason: from kotlin metadata */
    public h5.d delegateOpenHelper;

    /* renamed from: c, reason: collision with root package name and from kotlin metadata */
    public p0 coroutineScope;

    /* renamed from: d, reason: collision with root package name and from kotlin metadata */
    @Nullable
    public Function0<Unit> onAutoCloseCallback;

    /* renamed from: e, reason: collision with root package name and from kotlin metadata */
    @NotNull
    public final Object lock;

    /* renamed from: f, reason: collision with root package name and from kotlin metadata */
    public final long autoCloseTimeoutInMs;

    /* renamed from: g, reason: collision with root package name and from kotlin metadata */
    @NotNull
    public final AtomicInteger referenceCount;

    /* renamed from: h, reason: collision with root package name and from kotlin metadata */
    @NotNull
    public AtomicLong lastDecrementRefCountTimeStamp;

    /* renamed from: i, reason: collision with root package name and from kotlin metadata */
    @Nullable
    public h5.c delegateDatabase;

    /* renamed from: j, reason: collision with root package name and from kotlin metadata */
    public boolean manuallyClosed;

    /* renamed from: k, reason: collision with root package name and from kotlin metadata */
    @Nullable
    public d2 autoCloseJob;

    @Metadata(d1 = {"\u0000\u0010\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\u0010\t\n\u0002\b\u0003\bæ\u0080\u0001\u0018\u00002\u00020\u0001J\u000f\u0010\u0003\u001a\u00020\u0002H&¢\u0006\u0004\b\u0003\u0010\u0004ø\u0001\u0000\u0082\u0002\u0006\n\u0004\b!0\u0001¨\u0006\u0005À\u0006\u0001"}, d2 = {"Lc5/b$b;", BuildConfig.FLAVOR, BuildConfig.FLAVOR, xe.a.f36648e, "()J", "room-runtime"}, k = 1, mv = {2, 1, 0}, xi = 48)
    /* renamed from: c5.b$b, reason: collision with other inner class name */
    public interface InterfaceC0092b {
        long a();
    }

    @Metadata(d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0002\b\u0002\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\n¢\u0006\u0004\b\u0002\u0010\u0003"}, d2 = {"Lav/p0;", BuildConfig.FLAVOR, "<anonymous>", "(Lav/p0;)V"}, k = 3, mv = {2, 1, 0})
    @gu.f(c = "androidx.room.support.AutoCloser$decrementCountAndScheduleClose$2", f = "AutoCloser.android.kt", l = {167}, m = "invokeSuspend")
    public static final class c extends gu.m implements Function2<p0, eu.b<? super Unit>, Object> {

        /* renamed from: t, reason: collision with root package name */
        public int f4801t;

        public c(eu.b<? super c> bVar) {
            super(2, bVar);
        }

        @Override // gu.a
        public final eu.b<Unit> create(Object obj, eu.b<?> bVar) {
            return b.this.new c(bVar);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(p0 p0Var, eu.b<? super Unit> bVar) {
            return ((c) create(p0Var, bVar)).invokeSuspend(Unit.f21504a);
        }

        @Override // gu.a
        public final Object invokeSuspend(Object obj) {
            Object e10 = fu.c.e();
            int i10 = this.f4801t;
            if (i10 == 0) {
                o.b(obj);
                long j10 = b.this.autoCloseTimeoutInMs;
                this.f4801t = 1;
                if (z0.b(j10, this) == e10) {
                    return e10;
                }
            } else {
                if (i10 != 1) {
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                o.b(obj);
            }
            b.this.e();
            return Unit.f21504a;
        }
    }

    public b(long j10, @NotNull TimeUnit timeUnit, @NotNull InterfaceC0092b watch) {
        Intrinsics.checkNotNullParameter(timeUnit, "timeUnit");
        Intrinsics.checkNotNullParameter(watch, "watch");
        this.watch = watch;
        this.lock = new Object();
        this.autoCloseTimeoutInMs = timeUnit.toMillis(j10);
        this.referenceCount = new AtomicInteger(0);
        this.lastDecrementRefCountTimeStamp = new AtomicLong(watch.a());
    }

    public static final long b() {
        return SystemClock.uptimeMillis();
    }

    public final void e() {
        synchronized (this.lock) {
            try {
                if (this.watch.a() - this.lastDecrementRefCountTimeStamp.get() < this.autoCloseTimeoutInMs) {
                    return;
                }
                if (this.referenceCount.get() != 0) {
                    return;
                }
                Function0<Unit> function0 = this.onAutoCloseCallback;
                if (function0 == null) {
                    throw new IllegalStateException("onAutoCloseCallback is null but it should  have been set before use. Please file a bug against Room at: https://issuetracker.google.com/issues/new?component=413107&template=1096568");
                }
                function0.invoke();
                h5.c cVar = this.delegateDatabase;
                if (cVar != null && cVar.isOpen()) {
                    cVar.close();
                }
                this.delegateDatabase = null;
                Unit unit = Unit.f21504a;
            } catch (Throwable th2) {
                throw th2;
            }
        }
    }

    public final void f() {
        synchronized (this.lock) {
            try {
                this.manuallyClosed = true;
                d2 d2Var = this.autoCloseJob;
                if (d2Var != null) {
                    d2.a.a(d2Var, null, 1, null);
                }
                this.autoCloseJob = null;
                h5.c cVar = this.delegateDatabase;
                if (cVar != null) {
                    cVar.close();
                }
                this.delegateDatabase = null;
                Unit unit = Unit.f21504a;
            } catch (Throwable th2) {
                throw th2;
            }
        }
    }

    public final void g() {
        p0 p0Var;
        d2 d10;
        int decrementAndGet = this.referenceCount.decrementAndGet();
        if (decrementAndGet < 0) {
            throw new IllegalStateException("Unbalanced reference count.");
        }
        this.lastDecrementRefCountTimeStamp.set(this.watch.a());
        if (decrementAndGet == 0) {
            p0 p0Var2 = this.coroutineScope;
            if (p0Var2 == null) {
                Intrinsics.u("coroutineScope");
                p0Var = null;
            } else {
                p0Var = p0Var2;
            }
            d10 = av.k.d(p0Var, null, null, new c(null), 3, null);
            this.autoCloseJob = d10;
        }
    }

    public final <V> V h(@NotNull Function1<? super h5.c, ? extends V> block) {
        Intrinsics.checkNotNullParameter(block, "block");
        try {
            return block.invoke(j());
        } finally {
            g();
        }
    }

    @Nullable
    /* renamed from: i, reason: from getter */
    public final h5.c getDelegateDatabase() {
        return this.delegateDatabase;
    }

    @NotNull
    public final h5.c j() {
        d2 d2Var = this.autoCloseJob;
        h5.d dVar = null;
        if (d2Var != null) {
            d2.a.a(d2Var, null, 1, null);
        }
        this.autoCloseJob = null;
        this.referenceCount.incrementAndGet();
        if (this.manuallyClosed) {
            throw new IllegalStateException("Attempting to open already closed database.");
        }
        synchronized (this.lock) {
            h5.c cVar = this.delegateDatabase;
            if (cVar != null && cVar.isOpen()) {
                return cVar;
            }
            h5.d dVar2 = this.delegateOpenHelper;
            if (dVar2 == null) {
                Intrinsics.u("delegateOpenHelper");
            } else {
                dVar = dVar2;
            }
            h5.c w22 = dVar.w2();
            this.delegateDatabase = w22;
            return w22;
        }
    }

    public final void k(@NotNull p0 coroutineScope) {
        Intrinsics.checkNotNullParameter(coroutineScope, "coroutineScope");
        this.coroutineScope = coroutineScope;
    }

    public final void l(@NotNull h5.d delegateOpenHelper) {
        Intrinsics.checkNotNullParameter(delegateOpenHelper, "delegateOpenHelper");
        if (delegateOpenHelper instanceof g) {
            throw new IllegalArgumentException("Failed requirement.");
        }
        this.delegateOpenHelper = delegateOpenHelper;
    }

    public final boolean m() {
        return !this.manuallyClosed;
    }

    public final void n(@NotNull Function0<Unit> onAutoClose) {
        Intrinsics.checkNotNullParameter(onAutoClose, "onAutoClose");
        this.onAutoCloseCallback = onAutoClose;
    }

    public /* synthetic */ b(long j10, TimeUnit timeUnit, InterfaceC0092b interfaceC0092b, int i10, DefaultConstructorMarker defaultConstructorMarker) {
        this(j10, timeUnit, (i10 & 4) != 0 ? new InterfaceC0092b() { // from class: c5.a
            @Override // c5.b.InterfaceC0092b
            public final long a() {
                long b;
                b = b.b();
                return b;
            }
        } : interfaceC0092b);
    }


    // --- восстановлено из DEX (c5/b$a) ---
    public static class a {
        public a() { }
        public a(kotlin.jvm.internal.DefaultConstructorMarker p0) { }
    }
}
