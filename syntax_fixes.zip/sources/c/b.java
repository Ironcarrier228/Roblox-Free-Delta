package c;

import android.net.Uri;
import android.os.Binder;
import android.os.Bundle;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.Parcelable;

/* loaded from: classes.dex */
public interface b extends IInterface {

    /* renamed from: m, reason: collision with root package name */
    public static final String f4604m = "android$support$customtabs$ICustomTabsService".replace('$', '.');

    public static abstract class a extends Binder implements b {

        /* renamed from: c.b$a$a, reason: collision with other inner class name */
        public static class C0089a implements b {

            /* renamed from: a, reason: collision with root package name */
            public IBinder f4605a;

            public C0089a(IBinder iBinder) {
                this.f4605a = iBinder;
            }

            @Override // c.b
            public int B0(c.a aVar, String str, Bundle bundle) {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken(b.f4604m);
                    obtain.writeStrongInterface(aVar);
                    obtain.writeString(str);
                    C0090b.b(obtain, bundle, 0);
                    this.f4605a.transact(8, obtain, obtain2, 0);
                    obtain2.readException();
                    return obtain2.readInt();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            @Override // c.b
            public boolean K(c.a aVar) {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken(b.f4604m);
                    obtain.writeStrongInterface(aVar);
                    this.f4605a.transact(3, obtain, obtain2, 0);
                    obtain2.readException();
                    return obtain2.readInt() != 0;
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            @Override // android.os.IInterface
            public IBinder asBinder() {
                return this.f4605a;
            }

            @Override // c.b
            public boolean m(c.a aVar, Bundle bundle) {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken(b.f4604m);
                    obtain.writeStrongInterface(aVar);
                    C0090b.b(obtain, bundle, 0);
                    this.f4605a.transact(10, obtain, obtain2, 0);
                    obtain2.readException();
                    return obtain2.readInt() != 0;
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            @Override // c.b
            public boolean m2(c.a aVar, Uri uri, Bundle bundle) {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken(b.f4604m);
                    obtain.writeStrongInterface(aVar);
                    C0090b.b(obtain, uri, 0);
                    C0090b.b(obtain, bundle, 0);
                    this.f4605a.transact(11, obtain, obtain2, 0);
                    obtain2.readException();
                    return obtain2.readInt() != 0;
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            @Override // c.b
            public boolean p1(long j10) {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken(b.f4604m);
                    obtain.writeLong(j10);
                    this.f4605a.transact(2, obtain, obtain2, 0);
                    obtain2.readException();
                    return obtain2.readInt() != 0;
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            @Override // c.b
            public boolean r1(c.a aVar, Uri uri) {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken(b.f4604m);
                    obtain.writeStrongInterface(aVar);
                    C0090b.b(obtain, uri, 0);
                    this.f4605a.transact(7, obtain, obtain2, 0);
                    obtain2.readException();
                    return obtain2.readInt() != 0;
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }
        }

        public static b r2(IBinder iBinder) {
            if (iBinder == null) {
                return null;
            }
            IInterface queryLocalInterface = iBinder.queryLocalInterface(b.f4604m);
            return (queryLocalInterface == null || !(queryLocalInterface instanceof b)) ? new C0089a(iBinder) : (b) queryLocalInterface;
        }
    }

    /* renamed from: c.b$b, reason: collision with other inner class name */
    public static class C0090b {
        public static <T extends Parcelable> void b(Parcel parcel, T t8, int i10) {
            if (t8 == null) {
                parcel.writeInt(0);
            } else {
                parcel.writeInt(1);
                t8.writeToParcel(parcel, i10);
            }
        }
    }

    int B0(c.a aVar, String str, Bundle bundle);

    boolean K(c.a aVar);

    boolean m(c.a aVar, Bundle bundle);

    boolean m2(c.a aVar, Uri uri, Bundle bundle);

    boolean p1(long j10);

    boolean r1(c.a aVar, Uri uri);


    // --- восстановлено из DEX (c/b$a$a) ---
    public static class a implements c.b {
        android.os.IBinder a;
        public a(android.os.IBinder p0) { }
        public int B0(c.a p0, java.lang.String p1, android.os.Bundle p2) { throw new UnsupportedOperationException("stub"); }
        public boolean K(c.a p0) { throw new UnsupportedOperationException("stub"); }
        public android.os.IBinder asBinder() { throw new UnsupportedOperationException("stub"); }
        public boolean m(c.a p0, android.os.Bundle p1) { throw new UnsupportedOperationException("stub"); }
        public boolean m2(c.a p0, android.net.Uri p1, android.os.Bundle p2) { throw new UnsupportedOperationException("stub"); }
        public boolean p1(long p0) { throw new UnsupportedOperationException("stub"); }
        public boolean r1(c.a p0, android.net.Uri p1) { throw new UnsupportedOperationException("stub"); }
    }
}
