package ar;

import android.view.l0;
import com.github.luben.zstd.BuildConfig;
import java.util.ArrayList;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;

@Metadata(d1 = {"\u00002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0010\u000b\n\u0002\b\u0005\u0018\u0000 \u00172\u00020\u0001:\u0001\rB\u000f\u0012\u0006\u0010\u0003\u001a\u00020\u0002¢\u0006\u0004\b\u0004\u0010\u0005J\u0017\u0010\t\u001a\u00020\b2\u0006\u0010\u0007\u001a\u00020\u0006H\u0016¢\u0006\u0004\b\t\u0010\nJ\u001f\u0010\r\u001a\u0012\u0012\u0004\u0012\u00020\u00060\u000bj\b\u0012\u0004\u0012\u00020\u0006`\fH\u0016¢\u0006\u0004\b\r\u0010\u000eR\u0014\u0010\u0003\u001a\u00020\u00028\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b\r\u0010\u000fR$\u0010\u0012\u001a\u0012\u0012\u0004\u0012\u00020\u00060\u000bj\b\u0012\u0004\u0012\u00020\u0006`\f8\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b\u0010\u0010\u0011R\u001a\u0010\u0016\u001a\u00020\u00138\u0016X\u0096D¢\u0006\f\n\u0004\b\t\u0010\u0014\u001a\u0004\b\u0010\u0010\u0015¨\u0006\u0018"}, d2 = {"Lar/e;", "Lar/a;", "Landroidx/lifecycle/l0;", "savedStateHandle", "<init>", "(Landroidx/lifecycle/l0;)V", "Lar/f;", "stepData", BuildConfig.FLAVOR, "c", "(Lar/f;)V", "Ljava/util/ArrayList;", "Lkotlin/collections/ArrayList;", xe.a.f36648e, "()Ljava/util/ArrayList;", "Landroidx/lifecycle/l0;", k6.b.f21144e, "Ljava/util/ArrayList;", "collectedData", BuildConfig.FLAVOR, "Z", "()Z", "isActive", "d", "shared_release"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* loaded from: classes3.dex */
public final class e implements a {

    /* renamed from: a, reason: collision with root package name and from kotlin metadata */
    @NotNull
    public final l0 savedStateHandle;

    /* renamed from: b, reason: from kotlin metadata */
    @NotNull
    public final ArrayList<f> collectedData;

    /* renamed from: c, reason: collision with root package name and from kotlin metadata */
    public final boolean isActive;

    public e(@NotNull l0 savedStateHandle) {
        Intrinsics.checkNotNullParameter(savedStateHandle, "savedStateHandle");
        this.savedStateHandle = savedStateHandle;
        ArrayList<f> arrayList = (ArrayList) savedStateHandle.b("com.withpersona.sdk2.inquiry.shared.data_collection.RealDataCollector.collectedData");
        this.collectedData = arrayList == null ? new ArrayList<>() : arrayList;
        this.isActive = true;
    }

    @NotNull
    public ArrayList<f> a() {
        return new ArrayList<>(this.collectedData);
    }

    @Override // ar.a
    /* renamed from: b, reason: from getter */
    public boolean getIsActive() {
        return this.isActive;
    }

    @Override // ar.a
    public void c(@NotNull f stepData) {
        Intrinsics.checkNotNullParameter(stepData, "stepData");
        this.collectedData.add(stepData);
        this.savedStateHandle.i("com.withpersona.sdk2.inquiry.shared.data_collection.RealDataCollector.collectedData", this.collectedData);
    }


    // --- восстановлено из DEX (ar/e$a) ---
    public static class a {
        public a() { }
        public a(kotlin.jvm.internal.DefaultConstructorMarker p0) { }
    }
}
