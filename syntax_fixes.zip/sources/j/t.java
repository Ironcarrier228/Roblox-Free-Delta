package j;

import android.R;
import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.res.Configuration;
import android.content.res.TypedArray;
import android.util.TypedValue;
import android.view.ContextThemeWrapper;
import android.view.KeyCharacterMap;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.Interpolator;
import androidx.annotation.NonNull;
import androidx.appcompat.view.menu.e;
import androidx.appcompat.widget.ActionBarContainer;
import androidx.appcompat.widget.ActionBarContextView;
import androidx.appcompat.widget.ActionBarOverlayLayout;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.a1;
import androidx.core.view.b1;
import androidx.core.view.o0;
import androidx.core.view.y0;
import androidx.core.view.z0;
import j.a;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import o.b;
import q.g0;

/* loaded from: classes.dex */
public class t extends j.a implements ActionBarOverlayLayout.d {
    public static final Interpolator E = new AccelerateInterpolator();
    public static final Interpolator F = new DecelerateInterpolator();
    public boolean A;

    /* renamed from: a, reason: collision with root package name */
    public Context f19943a;
    public Context b;

    /* renamed from: c, reason: collision with root package name */
    public Activity f19944c;

    /* renamed from: d, reason: collision with root package name */
    public ActionBarOverlayLayout f19945d;

    /* renamed from: e, reason: collision with root package name */
    public ActionBarContainer f19946e;

    /* renamed from: f, reason: collision with root package name */
    public g0 f19947f;

    /* renamed from: g, reason: collision with root package name */
    public ActionBarContextView f19948g;

    /* renamed from: h, reason: collision with root package name */
    public View f19949h;

    /* renamed from: i, reason: collision with root package name */
    public androidx.appcompat.widget.c f19950i;

    /* renamed from: l, reason: collision with root package name */
    public boolean f19953l;

    /* renamed from: m, reason: collision with root package name */
    public d f19954m;

    /* renamed from: n, reason: collision with root package name */
    public o.b f19955n;

    /* renamed from: o, reason: collision with root package name */
    public b.a f19956o;

    /* renamed from: p, reason: collision with root package name */
    public boolean f19957p;

    /* renamed from: r, reason: collision with root package name */
    public boolean f19959r;

    /* renamed from: u, reason: collision with root package name */
    public boolean f19962u;

    /* renamed from: v, reason: collision with root package name */
    public boolean f19963v;

    /* renamed from: w, reason: collision with root package name */
    public boolean f19964w;

    /* renamed from: y, reason: collision with root package name */
    public o.h f19966y;

    /* renamed from: z, reason: collision with root package name */
    public boolean f19967z;

    /* renamed from: j, reason: collision with root package name */
    public ArrayList<Object> f19951j = new ArrayList<>();

    /* renamed from: k, reason: collision with root package name */
    public int f19952k = -1;

    /* renamed from: q, reason: collision with root package name */
    public ArrayList<a.b> f19958q = new ArrayList<>();

    /* renamed from: s, reason: collision with root package name */
    public int f19960s = 0;

    /* renamed from: t, reason: collision with root package name */
    public boolean f19961t = true;

    /* renamed from: x, reason: collision with root package name */
    public boolean f19965x = true;
    public final z0 B = new a();
    public final z0 C = new b();
    public final b1 D = new c();

    public class a extends a1 {
        public a() {
        }

        @Override // androidx.core.view.z0
        public void b(View view) {
            View view2;
            t tVar = t.this;
            if (tVar.f19961t && (view2 = tVar.f19949h) != null) {
                view2.setTranslationY(0.0f);
                t.this.f19946e.setTranslationY(0.0f);
            }
            t.this.f19946e.setVisibility(8);
            t.this.f19946e.setTransitioning(false);
            t tVar2 = t.this;
            tVar2.f19966y = null;
            tVar2.x();
            ActionBarOverlayLayout actionBarOverlayLayout = t.this.f19945d;
            if (actionBarOverlayLayout != null) {
                o0.j0(actionBarOverlayLayout);
            }
        }
    }

    public class b extends a1 {
        public b() {
        }

        @Override // androidx.core.view.z0
        public void b(View view) {
            t tVar = t.this;
            tVar.f19966y = null;
            tVar.f19946e.requestLayout();
        }
    }

    public class c implements b1 {
        public c() {
        }

        @Override // androidx.core.view.b1
        public void a(View view) {
            ((View) t.this.f19946e.getParent()).invalidate();
        }
    }

    public class d extends o.b implements e.a {

        /* renamed from: c, reason: collision with root package name */
        public final Context f19971c;

        /* renamed from: d, reason: collision with root package name */
        public final androidx.appcompat.view.menu.e f19972d;

        /* renamed from: e, reason: collision with root package name */
        public b.a f19973e;

        /* renamed from: f, reason: collision with root package name */
        public WeakReference<View> f19974f;

        public d(Context context, b.a aVar) {
            this.f19971c = context;
            this.f19973e = aVar;
            androidx.appcompat.view.menu.e T = new androidx.appcompat.view.menu.e(context).T(1);
            this.f19972d = T;
            T.S(this);
        }

        @Override // androidx.appcompat.view.menu.e.a
        public boolean a(@NonNull androidx.appcompat.view.menu.e eVar, @NonNull MenuItem menuItem) {
            b.a aVar = this.f19973e;
            if (aVar != null) {
                return aVar.c(this, menuItem);
            }
            return false;
        }

        @Override // androidx.appcompat.view.menu.e.a
        public void b(@NonNull androidx.appcompat.view.menu.e eVar) {
            if (this.f19973e == null) {
                return;
            }
            k();
            t.this.f19948g.l();
        }

        @Override // o.b
        public void c() {
            t tVar = t.this;
            if (tVar.f19954m != this) {
                return;
            }
            if (t.w(tVar.f19962u, tVar.f19963v, false)) {
                this.f19973e.b(this);
            } else {
                t tVar2 = t.this;
                tVar2.f19955n = this;
                tVar2.f19956o = this.f19973e;
            }
            this.f19973e = null;
            t.this.v(false);
            t.this.f19948g.g();
            t tVar3 = t.this;
            tVar3.f19945d.setHideOnContentScrollEnabled(tVar3.A);
            t.this.f19954m = null;
        }

        @Override // o.b
        public View d() {
            WeakReference<View> weakReference = this.f19974f;
            if (weakReference != null) {
                return weakReference.get();
            }
            return null;
        }

        @Override // o.b
        public Menu e() {
            return this.f19972d;
        }

        @Override // o.b
        public MenuInflater f() {
            return new o.g(this.f19971c);
        }

        @Override // o.b
        public CharSequence g() {
            return t.this.f19948g.getSubtitle();
        }

        @Override // o.b
        public CharSequence i() {
            return t.this.f19948g.getTitle();
        }

        @Override // o.b
        public void k() {
            if (t.this.f19954m != this) {
                return;
            }
            this.f19972d.e0();
            try {
                this.f19973e.d(this, this.f19972d);
            } finally {
                this.f19972d.d0();
            }
        }

        @Override // o.b
        public boolean l() {
            return t.this.f19948g.j();
        }

        @Override // o.b
        public void m(View view) {
            t.this.f19948g.setCustomView(view);
            this.f19974f = new WeakReference<>(view);
        }

        @Override // o.b
        public void n(int i10) {
            o(t.this.f19943a.getResources().getString(i10));
        }

        @Override // o.b
        public void o(CharSequence charSequence) {
            t.this.f19948g.setSubtitle(charSequence);
        }

        @Override // o.b
        public void q(int i10) {
            r(t.this.f19943a.getResources().getString(i10));
        }

        @Override // o.b
        public void r(CharSequence charSequence) {
            t.this.f19948g.setTitle(charSequence);
        }

        @Override // o.b
        public void s(boolean z10) {
            super.s(z10);
            t.this.f19948g.setTitleOptional(z10);
        }

        public boolean t() {
            this.f19972d.e0();
            try {
                return this.f19973e.a(this, this.f19972d);
            } finally {
                this.f19972d.d0();
            }
        }
    }

    public t(Activity activity, boolean z10) {
        this.f19944c = activity;
        View decorView = activity.getWindow().getDecorView();
        D(decorView);
        if (z10) {
            return;
        }
        this.f19949h = decorView.findViewById(android.R.id.content);
    }

    public static boolean w(boolean z10, boolean z11, boolean z12) {
        if (z12) {
            return true;
        }
        return (z10 || z11) ? false : true;
    }

    /* JADX WARN: Multi-variable type inference failed */
    public final g0 A(View view) {
        if (view instanceof g0) {
            return (g0) view;
        }
        if (view instanceof Toolbar) {
            return ((Toolbar) view).getWrapper();
        }
        StringBuilder sb2 = new StringBuilder();
        sb2.append("Can't make a decor toolbar out of ");
        sb2.append(view != 0 ? view.getClass().getSimpleName() : "null");
        throw new IllegalStateException(sb2.toString());
    }

    public int B() {
        return this.f19947f.j();
    }

    public final void C() {
        if (this.f19964w) {
            this.f19964w = false;
            ActionBarOverlayLayout actionBarOverlayLayout = this.f19945d;
            if (actionBarOverlayLayout != null) {
                actionBarOverlayLayout.setShowingForActionMode(false);
            }
            M(false);
        }
    }

    public final void D(View view) {
        ActionBarOverlayLayout actionBarOverlayLayout = (ActionBarOverlayLayout) view.findViewById(i.f.f18810q);
        this.f19945d = actionBarOverlayLayout;
        if (actionBarOverlayLayout != null) {
            actionBarOverlayLayout.setActionBarVisibilityCallback(this);
        }
        this.f19947f = A(view.findViewById(i.f.f18795a));
        this.f19948g = (ActionBarContextView) view.findViewById(i.f.f18799f);
        ActionBarContainer actionBarContainer = (ActionBarContainer) view.findViewById(i.f.f18796c);
        this.f19946e = actionBarContainer;
        g0 g0Var = this.f19947f;
        if (g0Var == null || this.f19948g == null || actionBarContainer == null) {
            throw new IllegalStateException(getClass().getSimpleName() + " can only be used with a compatible window decor layout");
        }
        this.f19943a = g0Var.getContext();
        boolean z10 = (this.f19947f.s() & 4) != 0;
        if (z10) {
            this.f19953l = true;
        }
        o.a b10 = o.a.b(this.f19943a);
        J(b10.a() || z10);
        H(b10.g());
        TypedArray obtainStyledAttributes = this.f19943a.obtainStyledAttributes(null, i.j.f18859a, i.a.f18728c, 0);
        if (obtainStyledAttributes.getBoolean(i.j.f18908k, false)) {
            I(true);
        }
        int dimensionPixelSize = obtainStyledAttributes.getDimensionPixelSize(i.j.f18898i, 0);
        if (dimensionPixelSize != 0) {
            G(dimensionPixelSize);
        }
        obtainStyledAttributes.recycle();
    }

    public void E(boolean z10) {
        F(z10 ? 4 : 0, 4);
    }

    public void F(int i10, int i11) {
        int s8 = this.f19947f.s();
        if ((i11 & 4) != 0) {
            this.f19953l = true;
        }
        this.f19947f.i((i10 & i11) | ((~i11) & s8));
    }

    public void G(float f10) {
        o0.u0(this.f19946e, f10);
    }

    public final void H(boolean z10) {
        this.f19959r = z10;
        if (z10) {
            this.f19946e.setTabContainer(null);
            this.f19947f.p(this.f19950i);
        } else {
            this.f19947f.p(null);
            this.f19946e.setTabContainer(this.f19950i);
        }
        boolean z11 = B() == 2;
        androidx.appcompat.widget.c cVar = this.f19950i;
        if (cVar != null) {
            if (z11) {
                cVar.setVisibility(0);
                ActionBarOverlayLayout actionBarOverlayLayout = this.f19945d;
                if (actionBarOverlayLayout != null) {
                    o0.j0(actionBarOverlayLayout);
                }
            } else {
                cVar.setVisibility(8);
            }
        }
        this.f19947f.n(!this.f19959r && z11);
        this.f19945d.setHasNonEmbeddedTabs(!this.f19959r && z11);
    }

    public void I(boolean z10) {
        if (z10 && !this.f19945d.x()) {
            throw new IllegalStateException("Action bar must be in overlay mode (Window.FEATURE_OVERLAY_ACTION_BAR) to enable hide on content scroll");
        }
        this.A = z10;
        this.f19945d.setHideOnContentScrollEnabled(z10);
    }

    public void J(boolean z10) {
        this.f19947f.l(z10);
    }

    public final boolean K() {
        return this.f19946e.isLaidOut();
    }

    public final void L() {
        if (this.f19964w) {
            return;
        }
        this.f19964w = true;
        ActionBarOverlayLayout actionBarOverlayLayout = this.f19945d;
        if (actionBarOverlayLayout != null) {
            actionBarOverlayLayout.setShowingForActionMode(true);
        }
        M(false);
    }

    public final void M(boolean z10) {
        if (w(this.f19962u, this.f19963v, this.f19964w)) {
            if (this.f19965x) {
                return;
            }
            this.f19965x = true;
            z(z10);
            return;
        }
        if (this.f19965x) {
            this.f19965x = false;
            y(z10);
        }
    }

    @Override // androidx.appcompat.widget.ActionBarOverlayLayout.d
    public void a() {
        if (this.f19963v) {
            this.f19963v = false;
            M(true);
        }
    }

    @Override // androidx.appcompat.widget.ActionBarOverlayLayout.d
    public void b() {
    }

    @Override // androidx.appcompat.widget.ActionBarOverlayLayout.d
    public void c(boolean z10) {
        this.f19961t = z10;
    }

    @Override // androidx.appcompat.widget.ActionBarOverlayLayout.d
    public void d() {
        if (this.f19963v) {
            return;
        }
        this.f19963v = true;
        M(true);
    }

    @Override // androidx.appcompat.widget.ActionBarOverlayLayout.d
    public void e() {
        o.h hVar = this.f19966y;
        if (hVar != null) {
            hVar.a();
            this.f19966y = null;
        }
    }

    @Override // j.a
    public boolean g() {
        g0 g0Var = this.f19947f;
        if (g0Var == null || !g0Var.h()) {
            return false;
        }
        this.f19947f.collapseActionView();
        return true;
    }

    @Override // j.a
    public void h(boolean z10) {
        if (z10 == this.f19957p) {
            return;
        }
        this.f19957p = z10;
        int size = this.f19958q.size();
        for (int i10 = 0; i10 < size; i10++) {
            this.f19958q.get(i10).onMenuVisibilityChanged(z10);
        }
    }

    @Override // j.a
    public int i() {
        return this.f19947f.s();
    }

    @Override // j.a
    public Context j() {
        if (this.b == null) {
            TypedValue typedValue = new TypedValue();
            this.f19943a.getTheme().resolveAttribute(i.a.f18732g, typedValue, true);
            int i10 = typedValue.resourceId;
            if (i10 != 0) {
                this.b = new ContextThemeWrapper(this.f19943a, i10);
            } else {
                this.b = this.f19943a;
            }
        }
        return this.b;
    }

    @Override // j.a
    public void k() {
        if (this.f19962u) {
            return;
        }
        this.f19962u = true;
        M(false);
    }

    @Override // j.a
    public void m(Configuration configuration) {
        H(o.a.b(this.f19943a).g());
    }

    @Override // j.a
    public boolean o(int i10, KeyEvent keyEvent) {
        Menu e10;
        d dVar = this.f19954m;
        if (dVar == null || (e10 = dVar.e()) == null) {
            return false;
        }
        e10.setQwertyMode(KeyCharacterMap.load(keyEvent != null ? keyEvent.getDeviceId() : -1).getKeyboardType() != 1);
        return e10.performShortcut(i10, keyEvent, 0);
    }

    @Override // androidx.appcompat.widget.ActionBarOverlayLayout.d
    public void onWindowVisibilityChanged(int i10) {
        this.f19960s = i10;
    }

    @Override // j.a
    public void r(boolean z10) {
        if (this.f19953l) {
            return;
        }
        E(z10);
    }

    @Override // j.a
    public void s(boolean z10) {
        o.h hVar;
        this.f19967z = z10;
        if (z10 || (hVar = this.f19966y) == null) {
            return;
        }
        hVar.a();
    }

    @Override // j.a
    public void t(CharSequence charSequence) {
        this.f19947f.setWindowTitle(charSequence);
    }

    @Override // j.a
    public o.b u(b.a aVar) {
        d dVar = this.f19954m;
        if (dVar != null) {
            dVar.c();
        }
        this.f19945d.setHideOnContentScrollEnabled(false);
        this.f19948g.k();
        d dVar2 = new d(this.f19948g.getContext(), aVar);
        if (!dVar2.t()) {
            return null;
        }
        this.f19954m = dVar2;
        dVar2.k();
        this.f19948g.h(dVar2);
        v(true);
        return dVar2;
    }

    public void v(boolean z10) {
        y0 k10;
        y0 f10;
        if (z10) {
            L();
        } else {
            C();
        }
        if (!K()) {
            if (z10) {
                this.f19947f.r(4);
                this.f19948g.setVisibility(0);
                return;
            } else {
                this.f19947f.r(0);
                this.f19948g.setVisibility(8);
                return;
            }
        }
        if (z10) {
            f10 = this.f19947f.k(4, 100L);
            k10 = this.f19948g.f(0, 200L);
        } else {
            k10 = this.f19947f.k(0, 200L);
            f10 = this.f19948g.f(8, 100L);
        }
        o.h hVar = new o.h();
        hVar.d(f10, k10);
        hVar.h();
    }

    public void x() {
        b.a aVar = this.f19956o;
        if (aVar != null) {
            aVar.b(this.f19955n);
            this.f19955n = null;
            this.f19956o = null;
        }
    }

    public void y(boolean z10) {
        View view;
        o.h hVar = this.f19966y;
        if (hVar != null) {
            hVar.a();
        }
        if (this.f19960s != 0 || (!this.f19967z && !z10)) {
            this.B.b(null);
            return;
        }
        this.f19946e.setAlpha(1.0f);
        this.f19946e.setTransitioning(true);
        o.h hVar2 = new o.h();
        float f10 = -this.f19946e.getHeight();
        if (z10) {
            this.f19946e.getLocationInWindow(new int[]{0, 0});
            f10 -= r5[1];
        }
        y0 l10 = o0.e(this.f19946e).l(f10);
        l10.j(this.D);
        hVar2.c(l10);
        if (this.f19961t && (view = this.f19949h) != null) {
            hVar2.c(o0.e(view).l(f10));
        }
        hVar2.f(E);
        hVar2.e(250L);
        hVar2.g(this.B);
        this.f19966y = hVar2;
        hVar2.h();
    }

    public void z(boolean z10) {
        View view;
        View view2;
        o.h hVar = this.f19966y;
        if (hVar != null) {
            hVar.a();
        }
        this.f19946e.setVisibility(0);
        if (this.f19960s == 0 && (this.f19967z || z10)) {
            this.f19946e.setTranslationY(0.0f);
            float f10 = -this.f19946e.getHeight();
            if (z10) {
                this.f19946e.getLocationInWindow(new int[]{0, 0});
                f10 -= r5[1];
            }
            this.f19946e.setTranslationY(f10);
            o.h hVar2 = new o.h();
            y0 l10 = o0.e(this.f19946e).l(0.0f);
            l10.j(this.D);
            hVar2.c(l10);
            if (this.f19961t && (view2 = this.f19949h) != null) {
                view2.setTranslationY(f10);
                hVar2.c(o0.e(this.f19949h).l(0.0f));
            }
            hVar2.f(F);
            hVar2.e(250L);
            hVar2.g(this.C);
            this.f19966y = hVar2;
            hVar2.h();
        } else {
            this.f19946e.setAlpha(1.0f);
            this.f19946e.setTranslationY(0.0f);
            if (this.f19961t && (view = this.f19949h) != null) {
                view.setTranslationY(0.0f);
            }
            this.C.b(null);
        }
        ActionBarOverlayLayout actionBarOverlayLayout = this.f19945d;
        if (actionBarOverlayLayout != null) {
            o0.j0(actionBarOverlayLayout);
        }
    }

    public t(Dialog dialog) {
        D(dialog.getWindow().getDecorView());
    }
}
