package ta;

import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import androidx.annotation.NonNull;

/* loaded from: classes.dex */
public final class n implements Parcelable.Creator<m> {
    public static void c(m mVar, Parcel parcel, int i10) {
        int a10 = p9.c.a(parcel);
        p9.c.v(parcel, 1, mVar.getType(), false);
        p9.c.f(parcel, 2, mVar.getData(), false);
        p9.c.b(parcel, a10);
    }

    @Override // android.os.Parcelable.Creator
    @NonNull
    /* renamed from: a, reason: merged with bridge method [inline-methods] */
    public m createFromParcel(@NonNull Parcel parcel) {
        int D = p9.b.D(parcel);
        String str = null;
        Bundle bundle = null;
        while (parcel.dataPosition() < D) {
            int u8 = p9.b.u(parcel);
            int n10 = p9.b.n(u8);
            if (n10 == 1) {
                str = p9.b.h(parcel, u8);
            } else if (n10 != 2) {
                p9.b.C(parcel, u8);
            } else {
                bundle = p9.b.b(parcel, u8);
            }
        }
        p9.b.m(parcel, D);
        return new m(str, bundle);
    }

    @Override // android.os.Parcelable.Creator
    @NonNull
    /* renamed from: b, reason: merged with bridge method [inline-methods] */
    public m[] newArray(int i10) {
        return new m[i10];
    }
}
