package ta;

import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import androidx.annotation.NonNull;

/* loaded from: classes.dex */
public final class p implements Parcelable.Creator<o> {
    public static void c(o oVar, Parcel parcel, int i10) {
        int a10 = p9.c.a(parcel);
        p9.c.v(parcel, 1, oVar.getType(), false);
        p9.c.f(parcel, 2, oVar.getData(), false);
        p9.c.b(parcel, a10);
    }

    @Override // android.os.Parcelable.Creator
    @NonNull
    /* renamed from: a, reason: merged with bridge method [inline-methods] */
    public o createFromParcel(@NonNull Parcel parcel) {
        int D = p9.b.D(parcel);
        String str = null;
        Bundle bundle = null;
        while (parcel.dataPosition() < D) {
            int u8 = p9.b.u(parcel);
            int n10 = p9.b.n(u8);
            if (n10 == 1) {
                str = p9.b.h(parcel, u8);
            } else if (n10 != 2) {
                p9.b.C(parcel, u8);
            } else {
                bundle = p9.b.b(parcel, u8);
            }
        }
        p9.b.m(parcel, D);
        return new o(str, bundle);
    }

    @Override // android.os.Parcelable.Creator
    @NonNull
    /* renamed from: b, reason: merged with bridge method [inline-methods] */
    public o[] newArray(int i10) {
        return new o[i10];
    }
}
