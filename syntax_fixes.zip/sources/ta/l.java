package ta;

import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.ResultReceiver;
import androidx.annotation.NonNull;

/* loaded from: classes.dex */
public final class l implements Parcelable.Creator<k> {
    public static void c(k kVar, Parcel parcel, int i10) {
        int a10 = p9.c.a(parcel);
        p9.c.v(parcel, 1, kVar.getType(), false);
        p9.c.f(parcel, 2, kVar.getCredentialData(), false);
        p9.c.f(parcel, 3, kVar.getCandidateQueryData(), false);
        p9.c.v(parcel, 4, kVar.getOrigin(), false);
        p9.c.v(parcel, 5, kVar.getRequestJson(), false);
        p9.c.t(parcel, 6, kVar.getResultReceiver(), i10, false);
        p9.c.b(parcel, a10);
    }

    @Override // android.os.Parcelable.Creator
    @NonNull
    /* renamed from: a, reason: merged with bridge method [inline-methods] */
    public k createFromParcel(@NonNull Parcel parcel) {
        int D = p9.b.D(parcel);
        String str = null;
        Bundle bundle = null;
        Bundle bundle2 = null;
        String str2 = null;
        String str3 = null;
        ResultReceiver resultReceiver = null;
        while (parcel.dataPosition() < D) {
            int u8 = p9.b.u(parcel);
            switch (p9.b.n(u8)) {
                case 1:
                    str = p9.b.h(parcel, u8);
                    break;
                case 2:
                    bundle = p9.b.b(parcel, u8);
                    break;
                case 3:
                    bundle2 = p9.b.b(parcel, u8);
                    break;
                case 4:
                    str2 = p9.b.h(parcel, u8);
                    break;
                case 5:
                    str3 = p9.b.h(parcel, u8);
                    break;
                case 6:
                    resultReceiver = (ResultReceiver) p9.b.g(parcel, u8, ResultReceiver.CREATOR);
                    break;
                default:
                    p9.b.C(parcel, u8);
                    break;
            }
        }
        p9.b.m(parcel, D);
        return new k(str, bundle, bundle2, str2, str3, resultReceiver);
    }

    @Override // android.os.Parcelable.Creator
    @NonNull
    /* renamed from: b, reason: merged with bridge method [inline-methods] */
    public k[] newArray(int i10) {
        return new k[i10];
    }
}
