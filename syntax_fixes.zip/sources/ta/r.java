package ta;

import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import androidx.annotation.NonNull;
import com.github.luben.zstd.BuildConfig;

/* loaded from: classes.dex */
public final class r implements Parcelable.Creator<q> {
    public static void c(q qVar, Parcel parcel, int i10) {
        int a10 = p9.c.a(parcel);
        p9.c.v(parcel, 1, qVar.getType(), false);
        p9.c.f(parcel, 2, qVar.getCredentialRetrievalData(), false);
        p9.c.f(parcel, 3, qVar.getCandidateQueryData(), false);
        p9.c.v(parcel, 4, qVar.getRequestMatcher(), false);
        p9.c.v(parcel, 5, qVar.getRequestType(), false);
        p9.c.v(parcel, 6, qVar.getProtocolType(), false);
        p9.c.b(parcel, a10);
    }

    @Override // android.os.Parcelable.Creator
    @NonNull
    /* renamed from: a, reason: merged with bridge method [inline-methods] */
    public q createFromParcel(@NonNull Parcel parcel) {
        int D = p9.b.D(parcel);
        String str = BuildConfig.FLAVOR;
        String str2 = str;
        String str3 = str2;
        Bundle bundle = null;
        Bundle bundle2 = null;
        String str4 = null;
        while (parcel.dataPosition() < D) {
            int u8 = p9.b.u(parcel);
            switch (p9.b.n(u8)) {
                case 1:
                    str = p9.b.h(parcel, u8);
                    break;
                case 2:
                    bundle = p9.b.b(parcel, u8);
                    break;
                case 3:
                    bundle2 = p9.b.b(parcel, u8);
                    break;
                case 4:
                    str4 = p9.b.h(parcel, u8);
                    break;
                case 5:
                    str2 = p9.b.h(parcel, u8);
                    break;
                case 6:
                    str3 = p9.b.h(parcel, u8);
                    break;
                default:
                    p9.b.C(parcel, u8);
                    break;
            }
        }
        p9.b.m(parcel, D);
        return new q(str, bundle, bundle2, str4, str2, str3);
    }

    @Override // android.os.Parcelable.Creator
    @NonNull
    /* renamed from: b, reason: merged with bridge method [inline-methods] */
    public q[] newArray(int i10) {
        return new q[i10];
    }
}
