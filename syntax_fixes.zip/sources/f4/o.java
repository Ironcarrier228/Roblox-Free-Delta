package f4;

import android.R;
import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.C0795e1;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import androidx.annotation.NonNull;

/* loaded from: classes.dex */
public class o extends q implements DialogInterface.OnCancelListener, DialogInterface.OnDismissListener {

    /* renamed from: f0, reason: collision with root package name */
    public Handler f15445f0;

    /* renamed from: o0, reason: collision with root package name */
    public boolean f15454o0;

    /* renamed from: q0, reason: collision with root package name */
    public Dialog f15456q0;

    /* renamed from: r0, reason: collision with root package name */
    public boolean f15457r0;

    /* renamed from: s0, reason: collision with root package name */
    public boolean f15458s0;

    /* renamed from: t0, reason: collision with root package name */
    public boolean f15459t0;

    /* renamed from: g0, reason: collision with root package name */
    public Runnable f15446g0 = new a();

    /* renamed from: h0, reason: collision with root package name */
    public DialogInterface.OnCancelListener f15447h0 = new b();

    /* renamed from: i0, reason: collision with root package name */
    public DialogInterface.OnDismissListener f15448i0 = new c();

    /* renamed from: j0, reason: collision with root package name */
    public int f15449j0 = 0;

    /* renamed from: k0, reason: collision with root package name */
    public int f15450k0 = 0;

    /* renamed from: l0, reason: collision with root package name */
    public boolean f15451l0 = true;

    /* renamed from: m0, reason: collision with root package name */
    public boolean f15452m0 = true;

    /* renamed from: n0, reason: collision with root package name */
    public int f15453n0 = -1;

    /* renamed from: p0, reason: collision with root package name */
    public android.view.e0<android.view.s> f15455p0 = new d();

    /* renamed from: u0, reason: collision with root package name */
    public boolean f15460u0 = false;

    public class a implements Runnable {
        public a() {
        }

        @Override // java.lang.Runnable
        public void run() {
            o.this.f15448i0.onDismiss(o.this.f15456q0);
        }
    }

    public class b implements DialogInterface.OnCancelListener {
        public b() {
        }

        @Override // android.content.DialogInterface.OnCancelListener
        public void onCancel(DialogInterface dialogInterface) {
            if (o.this.f15456q0 != null) {
                o oVar = o.this;
                oVar.onCancel(oVar.f15456q0);
            }
        }
    }

    public class c implements DialogInterface.OnDismissListener {
        public c() {
        }

        @Override // android.content.DialogInterface.OnDismissListener
        public void onDismiss(DialogInterface dialogInterface) {
            if (o.this.f15456q0 != null) {
                o oVar = o.this;
                oVar.onDismiss(oVar.f15456q0);
            }
        }
    }

    public class d implements android.view.e0<android.view.s> {
        public d() {
        }

        @Override // android.view.e0
        /* renamed from: b, reason: merged with bridge method [inline-methods] */
        public void a(android.view.s sVar) {
            if (sVar == null || !o.this.f15452m0) {
                return;
            }
            View J1 = o.this.J1();
            if (J1.getParent() != null) {
                throw new IllegalStateException("DialogFragment can not be attached to a container view");
            }
            if (o.this.f15456q0 != null) {
                if (k0.N0(3)) {
                    Log.d("FragmentManager", "DialogFragment " + this + " setting the content view on " + o.this.f15456q0);
                }
                o.this.f15456q0.setContentView(J1);
            }
        }
    }

    public class e extends x {

        /* renamed from: a, reason: collision with root package name */
        public final /* synthetic */ x f15465a;

        public e(x xVar) {
            this.f15465a = xVar;
        }

        @Override // f4.x
        public View d(int i10) {
            return this.f15465a.e() ? this.f15465a.d(i10) : o.this.l2(i10);
        }

        @Override // f4.x
        public boolean e() {
            return this.f15465a.e() || o.this.m2();
        }
    }

    @Override // f4.q
    public void C0(@NonNull Context context) {
        super.C0(context);
        l0().j(this.f15455p0);
        if (this.f15459t0) {
            return;
        }
        this.f15458s0 = false;
    }

    @Override // f4.q
    public void F0(Bundle bundle) {
        super.F0(bundle);
        this.f15445f0 = new Handler();
        this.f15452m0 = this.A == 0;
        if (bundle != null) {
            this.f15449j0 = bundle.getInt("android:style", 0);
            this.f15450k0 = bundle.getInt("android:theme", 0);
            this.f15451l0 = bundle.getBoolean("android:cancelable", true);
            this.f15452m0 = bundle.getBoolean("android:showsDialog", this.f15452m0);
            this.f15453n0 = bundle.getInt("android:backStackId", -1);
        }
    }

    @Override // f4.q
    public void M0() {
        super.M0();
        Dialog dialog = this.f15456q0;
        if (dialog != null) {
            this.f15457r0 = true;
            dialog.setOnDismissListener(null);
            this.f15456q0.dismiss();
            if (!this.f15458s0) {
                onDismiss(this.f15456q0);
            }
            this.f15456q0 = null;
            this.f15460u0 = false;
        }
    }

    @Override // f4.q
    public void N0() {
        super.N0();
        if (!this.f15459t0 && !this.f15458s0) {
            this.f15458s0 = true;
        }
        l0().n(this.f15455p0);
    }

    @Override // f4.q
    @NonNull
    public LayoutInflater O0(Bundle bundle) {
        LayoutInflater O0 = super.O0(bundle);
        if (this.f15452m0 && !this.f15454o0) {
            n2(bundle);
            if (k0.N0(2)) {
                Log.d("FragmentManager", "get layout inflater for DialogFragment " + this + " from dialog context");
            }
            Dialog dialog = this.f15456q0;
            if (dialog != null) {
                return O0.cloneInContext(dialog.getContext());
            }
        } else if (k0.N0(2)) {
            String str = "getting layout inflater for DialogFragment " + this;
            if (!this.f15452m0) {
                Log.d("FragmentManager", "mShowsDialog = false: " + str);
                return O0;
            }
            Log.d("FragmentManager", "mCreatingDialog = true: " + str);
        }
        return O0;
    }

    @Override // f4.q
    public void b1(@NonNull Bundle bundle) {
        super.b1(bundle);
        Dialog dialog = this.f15456q0;
        if (dialog != null) {
            Bundle onSaveInstanceState = dialog.onSaveInstanceState();
            onSaveInstanceState.putBoolean("android:dialogShowing", false);
            bundle.putBundle("android:savedDialogState", onSaveInstanceState);
        }
        int i10 = this.f15449j0;
        if (i10 != 0) {
            bundle.putInt("android:style", i10);
        }
        int i11 = this.f15450k0;
        if (i11 != 0) {
            bundle.putInt("android:theme", i11);
        }
        boolean z10 = this.f15451l0;
        if (!z10) {
            bundle.putBoolean("android:cancelable", z10);
        }
        boolean z11 = this.f15452m0;
        if (!z11) {
            bundle.putBoolean("android:showsDialog", z11);
        }
        int i12 = this.f15453n0;
        if (i12 != -1) {
            bundle.putInt("android:backStackId", i12);
        }
    }

    @Override // f4.q
    public void c1() {
        super.c1();
        Dialog dialog = this.f15456q0;
        if (dialog != null) {
            this.f15457r0 = false;
            dialog.show();
            View decorView = this.f15456q0.getWindow().getDecorView();
            android.view.View.b(decorView, this);
            C0795e1.a(decorView, this);
            e5.m.b(decorView, this);
        }
    }

    @Override // f4.q
    public void d1() {
        super.d1();
        Dialog dialog = this.f15456q0;
        if (dialog != null) {
            dialog.hide();
        }
    }

    public void e2() {
        g2(false, false, false);
    }

    @Override // f4.q
    public void f1(Bundle bundle) {
        Bundle bundle2;
        super.f1(bundle);
        if (this.f15456q0 == null || bundle == null || (bundle2 = bundle.getBundle("android:savedDialogState")) == null) {
            return;
        }
        this.f15456q0.onRestoreInstanceState(bundle2);
    }

    public void f2() {
        g2(true, false, false);
    }

    public final void g2(boolean z10, boolean z11, boolean z12) {
        if (this.f15458s0) {
            return;
        }
        this.f15458s0 = true;
        this.f15459t0 = false;
        Dialog dialog = this.f15456q0;
        if (dialog != null) {
            dialog.setOnDismissListener(null);
            this.f15456q0.dismiss();
            if (!z11) {
                if (Looper.myLooper() == this.f15445f0.getLooper()) {
                    onDismiss(this.f15456q0);
                } else {
                    this.f15445f0.post(this.f15446g0);
                }
            }
        }
        this.f15457r0 = true;
        if (this.f15453n0 >= 0) {
            if (z12) {
                L().e1(this.f15453n0, 1);
            } else {
                L().b1(this.f15453n0, 1, z10);
            }
            this.f15453n0 = -1;
            return;
        }
        t0 r10 = L().r();
        r10.s(true);
        r10.m(this);
        if (z12) {
            r10.i();
        } else if (z10) {
            r10.h();
        } else {
            r10.g();
        }
    }

    public Dialog h2() {
        return this.f15456q0;
    }

    public boolean i2() {
        return this.f15452m0;
    }

    public int j2() {
        return this.f15450k0;
    }

    @Override // f4.q
    @NonNull
    public x k() {
        return new e(super.k());
    }

    @NonNull
    public Dialog k2(Bundle bundle) {
        if (k0.N0(3)) {
            Log.d("FragmentManager", "onCreateDialog called for DialogFragment " + this);
        }
        return new e.w(I1(), j2());
    }

    public View l2(int i10) {
        Dialog dialog = this.f15456q0;
        if (dialog != null) {
            return dialog.findViewById(i10);
        }
        return null;
    }

    @Override // f4.q
    public void m1(@NonNull LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        Bundle bundle2;
        super.m1(layoutInflater, viewGroup, bundle);
        if (this.K != null || this.f15456q0 == null || bundle == null || (bundle2 = bundle.getBundle("android:savedDialogState")) == null) {
            return;
        }
        this.f15456q0.onRestoreInstanceState(bundle2);
    }

    public boolean m2() {
        return this.f15460u0;
    }

    public final void n2(Bundle bundle) {
        if (this.f15452m0 && !this.f15460u0) {
            try {
                this.f15454o0 = true;
                Dialog k22 = k2(bundle);
                this.f15456q0 = k22;
                if (this.f15452m0) {
                    s2(k22, this.f15449j0);
                    Context v8 = v();
                    if (v8 instanceof Activity) {
                        this.f15456q0.setOwnerActivity((Activity) v8);
                    }
                    this.f15456q0.setCancelable(this.f15451l0);
                    this.f15456q0.setOnCancelListener(this.f15447h0);
                    this.f15456q0.setOnDismissListener(this.f15448i0);
                    this.f15460u0 = true;
                } else {
                    this.f15456q0 = null;
                }
                this.f15454o0 = false;
            } catch (Throwable th2) {
                this.f15454o0 = false;
                throw th2;
            }
        }
    }

    @NonNull
    public final Dialog o2() {
        Dialog h22 = h2();
        if (h22 != null) {
            return h22;
        }
        throw new IllegalStateException("DialogFragment " + this + " does not have a Dialog.");
    }

    public void onCancel(@NonNull DialogInterface dialogInterface) {
    }

    public void onDismiss(@NonNull DialogInterface dialogInterface) {
        if (this.f15457r0) {
            return;
        }
        if (k0.N0(3)) {
            Log.d("FragmentManager", "onDismiss called for DialogFragment " + this);
        }
        g2(true, true, false);
    }

    public void p2(boolean z10) {
        this.f15451l0 = z10;
        Dialog dialog = this.f15456q0;
        if (dialog != null) {
            dialog.setCancelable(z10);
        }
    }

    public void q2(boolean z10) {
        this.f15452m0 = z10;
    }

    public void r2(int i10, int i11) {
        if (k0.N0(2)) {
            Log.d("FragmentManager", "Setting style and theme for DialogFragment " + this + " to " + i10 + ", " + i11);
        }
        this.f15449j0 = i10;
        if (i10 == 2 || i10 == 3) {
            this.f15450k0 = android.R.style.Theme.Panel;
        }
        if (i11 != 0) {
            this.f15450k0 = i11;
        }
    }

    public void s2(@NonNull Dialog dialog, int i10) {
        if (i10 != 1 && i10 != 2) {
            if (i10 != 3) {
                return;
            }
            Window window = dialog.getWindow();
            if (window != null) {
                window.addFlags(24);
            }
        }
        dialog.requestWindowFeature(1);
    }

    public void t2(@NonNull k0 k0Var, String str) {
        this.f15458s0 = false;
        this.f15459t0 = true;
        t0 r10 = k0Var.r();
        r10.s(true);
        r10.d(this, str);
        r10.g();
    }

    @Override // f4.q
    @Deprecated
    public void z0(Bundle bundle) {
        super.z0(bundle);
    }
}
