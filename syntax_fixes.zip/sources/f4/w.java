package f4;

import android.R;
import android.animation.Animator;
import android.animation.AnimatorInflater;
import android.animation.AnimatorSet;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationSet;
import android.view.animation.AnimationUtils;
import android.view.animation.Transformation;
import androidx.annotation.NonNull;

/* loaded from: classes.dex */
public class w {
    public static int a(q qVar, boolean z10, boolean z11) {
        return z11 ? z10 ? qVar.N() : qVar.O() : z10 ? qVar.x() : qVar.B();
    }

    @SuppressLint({"ResourceType"})
    public static a b(@NonNull Context context, @NonNull q qVar, boolean z10, boolean z11) {
        int I = qVar.I();
        int a10 = a(qVar, z10, z11);
        qVar.N1(0, 0, 0, 0);
        ViewGroup viewGroup = qVar.J;
        if (viewGroup != null && viewGroup.getTag(e4.b.f13176c) != null) {
            qVar.J.setTag(e4.b.f13176c, null);
        }
        ViewGroup viewGroup2 = qVar.J;
        if (viewGroup2 != null && viewGroup2.getLayoutTransition() != null) {
            return null;
        }
        Animation G0 = qVar.G0(I, z10, a10);
        if (G0 != null) {
            return new a(G0);
        }
        Animator H0 = qVar.H0(I, z10, a10);
        if (H0 != null) {
            return new a(H0);
        }
        if (a10 == 0 && I != 0) {
            a10 = d(context, I, z10);
        }
        if (a10 != 0) {
            boolean equals = "anim".equals(context.getResources().getResourceTypeName(a10));
            if (equals) {
                try {
                    Animation loadAnimation = AnimationUtils.loadAnimation(context, a10);
                    if (loadAnimation != null) {
                        return new a(loadAnimation);
                    }
                } catch (Resources.NotFoundException e10) {
                    throw e10;
                } catch (RuntimeException unused) {
                }
            }
            try {
                Animator loadAnimator = AnimatorInflater.loadAnimator(context, a10);
                if (loadAnimator != null) {
                    return new a(loadAnimator);
                }
            } catch (RuntimeException e11) {
                if (equals) {
                    throw e11;
                }
                Animation loadAnimation2 = AnimationUtils.loadAnimation(context, a10);
                if (loadAnimation2 != null) {
                    return new a(loadAnimation2);
                }
            }
        }
        return null;
    }

    public static int c(@NonNull Context context, int i10) {
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(android.R.style.Animation.Activity, new int[]{i10});
        int resourceId = obtainStyledAttributes.getResourceId(0, -1);
        obtainStyledAttributes.recycle();
        return resourceId;
    }

    public static int d(@NonNull Context context, int i10, boolean z10) {
        if (i10 == 4097) {
            return z10 ? e4.a.f13173e : e4.a.f13174f;
        }
        if (i10 == 8194) {
            return z10 ? e4.a.f13170a : e4.a.b;
        }
        if (i10 == 8197) {
            return z10 ? c(context, android.R.attr.activityCloseEnterAnimation) : c(context, android.R.attr.activityCloseExitAnimation);
        }
        if (i10 == 4099) {
            return z10 ? e4.a.f13171c : e4.a.f13172d;
        }
        if (i10 != 4100) {
            return -1;
        }
        return z10 ? c(context, android.R.attr.activityOpenEnterAnimation) : c(context, android.R.attr.activityOpenExitAnimation);
    }

    public static class a {

        /* renamed from: a, reason: collision with root package name */
        public final Animation f15601a;
        public final AnimatorSet b;

        public a(Animation animation) {
            this.f15601a = animation;
            this.b = null;
            if (animation == null) {
                throw new IllegalStateException("Animation cannot be null");
            }
        }

        public a(Animator animator) {
            this.f15601a = null;
            AnimatorSet animatorSet = new AnimatorSet();
            this.b = animatorSet;
            animatorSet.play(animator);
            if (animator == null) {
                throw new IllegalStateException("Animator cannot be null");
            }
        }
    }

    public static class b extends AnimationSet implements Runnable {

        /* renamed from: a, reason: collision with root package name */
        public final ViewGroup f15602a;
        public final View b;

        /* renamed from: c, reason: collision with root package name */
        public boolean f15603c;

        /* renamed from: d, reason: collision with root package name */
        public boolean f15604d;

        /* renamed from: e, reason: collision with root package name */
        public boolean f15605e;

        public b(@NonNull Animation animation, @NonNull ViewGroup viewGroup, @NonNull View view) {
            super(false);
            this.f15605e = true;
            this.f15602a = viewGroup;
            this.b = view;
            addAnimation(animation);
            viewGroup.post(this);
        }

        @Override // android.view.animation.AnimationSet, android.view.animation.Animation
        public boolean getTransformation(long j10, @NonNull Transformation transformation) {
            this.f15605e = true;
            if (this.f15603c) {
                return !this.f15604d;
            }
            if (!super.getTransformation(j10, transformation)) {
                this.f15603c = true;
                androidx.core.view.b0.a(this.f15602a, this);
            }
            return true;
        }

        @Override // java.lang.Runnable
        public void run() {
            if (this.f15603c || !this.f15605e) {
                this.f15602a.endViewTransition(this.b);
                this.f15604d = true;
            } else {
                this.f15605e = false;
                this.f15602a.post(this);
            }
        }

        @Override // android.view.animation.Animation
        public boolean getTransformation(long j10, @NonNull Transformation transformation, float f10) {
            this.f15605e = true;
            if (this.f15603c) {
                return !this.f15604d;
            }
            if (!super.getTransformation(j10, transformation, f10)) {
                this.f15603c = true;
                androidx.core.view.b0.a(this.f15602a, this);
            }
            return true;
        }
    }
}
