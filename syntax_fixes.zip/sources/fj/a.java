package fj;

import android.R;
import android.view.View;
import f4.v;

/* loaded from: classes2.dex */
public abstract class a {

    /* renamed from: a, reason: collision with root package name */
    public v f16120a;

    public a(v vVar) {
        this.f16120a = vVar;
    }

    public boolean a() {
        v vVar = this.f16120a;
        if (vVar == null) {
            return false;
        }
        return ((vVar instanceof com.roblox.client.a) && ((com.roblox.client.a) vVar).N1()) ? false : true;
    }

    public int b() {
        View findViewById = this.f16120a.findViewById(android.R.id.content);
        vk.b b = vk.b.b(findViewById.getRootView(), this.f16120a.getWindowManager(), findViewById, ((com.roblox.client.a) this.f16120a).G1().d());
        return (b.b - b.f34411g) - b.f34407c;
    }
}
