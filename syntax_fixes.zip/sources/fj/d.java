package fj;

import android.R;
import android.content.Intent;
import android.content.res.Resources;
import android.graphics.Point;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.r;
import android.widget.ImageView;
import android.widget.TextView;
import bh.a1;
import bh.e0;
import bh.e2;
import bh.g0;
import bh.j0;
import bh.k0;
import bh.l0;
import bh.m0;
import bh.o0;
import bh.q0;
import com.roblox.client.NotificationStreamActivity;
import com.roblox.engine.jni.NativeGLInterface;
import com.roblox.platform.util.DeviceUtils;
import f4.q;
import f4.v;

/* loaded from: classes2.dex */
public class d {

    /* renamed from: a, reason: collision with root package name */
    public final String f16123a;
    public v b;

    /* renamed from: c, reason: collision with root package name */
    public lk.c f16124c;

    /* renamed from: d, reason: collision with root package name */
    public int f16125d;

    /* renamed from: e, reason: collision with root package name */
    public int f16126e;

    /* renamed from: f, reason: collision with root package name */
    public MenuItem f16127f;

    /* renamed from: g, reason: collision with root package name */
    public TextView f16128g;

    public class a implements View.OnClickListener {
        public a() {
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            d.this.e();
        }
    }

    public static /* synthetic */ class b {

        /* renamed from: a, reason: collision with root package name */
        public static final /* synthetic */ int[] f16130a;

        static {
            int[] iArr = new int[cm.a.values().length];
            f16130a = iArr;
            try {
                iArr[cm.a.f5518c.ordinal()] = 1;
            } catch (NoSuchFieldError unused) {
            }
            try {
                f16130a[cm.a.f5519d.ordinal()] = 2;
            } catch (NoSuchFieldError unused2) {
            }
        }
    }

    public d(q qVar) {
        this(qVar, new lk.f());
    }

    public final int a() {
        if (b.f16130a[this.f16124c.getTheme().ordinal()] != 1) {
            return this.f16126e;
        }
        return -1;
    }

    public final int b() {
        return b.f16130a[this.f16124c.getTheme().ordinal()] != 1 ? l0.f4111k : l0.f4112l;
    }

    public final int c() {
        return b.f16130a[this.f16124c.getTheme().ordinal()] != 1 ? l0.f4123w : l0.f4124x;
    }

    public MenuItem d(Menu menu, MenuInflater menuInflater) {
        menuInflater.inflate(o0.f4212a, menu);
        MenuItem findItem = menu.findItem(m0.f4129a);
        this.f16127f = findItem;
        View actionView = findItem.getActionView();
        ImageView imageView = (ImageView) actionView.findViewById(m0.Y);
        TextView textView = (TextView) actionView.findViewById(m0.Z);
        this.f16128g = textView;
        h(textView, this.f16125d);
        imageView.setOnClickListener(new a());
        imageView.setImageResource(c());
        this.f16128g.setBackgroundResource(b());
        this.f16128g.setTextColor(a());
        return this.f16127f;
    }

    public void e() {
        f(null);
    }

    public void f(r rVar) {
        if (this.b == null) {
            return;
        }
        nk.c.c().s(0);
        this.f16125d = 0;
        TextView textView = this.f16128g;
        if (textView != null) {
            textView.setVisibility(8);
        }
        cl.g.d().g().clearStreamUnread().L(new el.a());
        if (!a1.p0()) {
            i(rVar);
            return;
        }
        Intent intent = new Intent(this.b, (Class<?>) NotificationStreamActivity.class);
        if (rVar != null) {
            intent.putExtra("SEND_DATA_MODEL_FOCUS_EVENTS_EXTRA", true);
        }
        this.b.startActivityForResult(intent, 20110);
        if (NativeGLInterface.nativeUserGameSettingsGetReducedMotion()) {
            this.b.overridePendingTransition(0, 0);
        } else {
            this.b.overridePendingTransition(g0.b, android.R.anim.fade_out);
        }
    }

    public final void g(int i10) {
        this.f16125d = i10;
        h((TextView) this.f16127f.getActionView().findViewById(m0.Z), this.f16125d);
    }

    public final void h(TextView textView, int i10) {
        if (i10 <= 0) {
            textView.setVisibility(8);
            return;
        }
        textView.setVisibility(0);
        if (i10 > 99) {
            textView.setText(textView.getContext().getString(q0.Q));
        } else {
            textView.setText(yi.e.a(i10));
        }
    }

    public final void i(r rVar) {
        Point screenSize = DeviceUtils.getScreenSize(this.b);
        int dimensionPixelSize = this.b.getResources().getDimensionPixelSize(k0.f4096c);
        int dimensionPixelSize2 = this.b.getResources().getDimensionPixelSize(k0.b);
        int e10 = (int) e2.e(this.b, 80);
        int e11 = (int) e2.e(this.b, 420);
        int i10 = ((screenSize.y - dimensionPixelSize2) - dimensionPixelSize) - e10;
        int e12 = (int) e2.e(this.b, 15);
        e0 e0Var = new e0();
        e0Var.r2(2, 0);
        Bundle bundle = new Bundle();
        bundle.putInt("dialogWidth", e11);
        bundle.putInt("dialogHeight", i10);
        bundle.putInt("dialogGravity", 53);
        bundle.putInt("dialogOffsetY", dimensionPixelSize);
        bundle.putInt("dialogOffsetX", e12);
        bundle.putString("DEFAULT_URL", a1.y0());
        e0Var.O1(bundle);
        if (rVar != null) {
            e0Var.a().a(rVar);
        }
        e0Var.t2(this.b.l1(), "NOTIFICATION_STREAM_TAG");
    }

    public void j() {
        q n02 = this.b.l1().n0("NOTIFICATION_STREAM_TAG");
        if (n02 != null && n02.x0()) {
            nk.c.c().s(0);
        }
        g(nk.c.c().e());
    }

    public d(q qVar, lk.c cVar) {
        this.f16123a = "NOTIFICATION_STREAM_TAG";
        this.f16125d = -1;
        v p8 = qVar.p();
        this.b = p8;
        this.f16124c = cVar;
        Resources resources = p8.getResources();
        this.f16126e = resources != null ? resources.getColor(j0.f4086i) : -12303292;
    }
}
