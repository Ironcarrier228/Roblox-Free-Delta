package n0;

import android.util.Pair;
import android.util.Size;
import java.util.ArrayList;
import java.util.List;
import n0.n1;

/* loaded from: classes.dex */
public abstract class i2 extends l3 {

    /* renamed from: m, reason: collision with root package name */
    public static final n1.a<Integer> f24980m = n1.a.a("camerax.core.imageOutput.targetAspectRatio", g0.d.class);

    /* renamed from: n, reason: collision with root package name */
    public static final n1.a<Integer> f24981n;

    /* renamed from: o, reason: collision with root package name */
    public static final n1.a<Integer> f24982o;

    /* renamed from: p, reason: collision with root package name */
    public static final n1.a<Integer> f24983p;

    /* renamed from: q, reason: collision with root package name */
    public static final n1.a<Size> f24984q;

    /* renamed from: r, reason: collision with root package name */
    public static final n1.a<Size> f24985r;

    /* renamed from: s, reason: collision with root package name */
    public static final n1.a<Size> f24986s;

    /* renamed from: t, reason: collision with root package name */
    public static final n1.a<List<Pair<Integer, Size[]>>> f24987t;

    /* renamed from: u, reason: collision with root package name */
    public static final n1.a<a1.c> f24988u;

    /* renamed from: v, reason: collision with root package name */
    public static final n1.a<List<Size>> f24989v;

    public interface a<B> {
        B b(a1.c cVar);

        B c(int i10);

        B d(Size size);
    }

    static {
        Class cls = Integer.TYPE;
        f24981n = n1.a.a("camerax.core.imageOutput.targetRotation", cls);
        f24982o = n1.a.a("camerax.core.imageOutput.appTargetRotation", cls);
        f24983p = n1.a.a("camerax.core.imageOutput.mirrorMode", cls);
        f24984q = n1.a.a("camerax.core.imageOutput.targetResolution", Size.class);
        f24985r = n1.a.a("camerax.core.imageOutput.defaultResolution", Size.class);
        f24986s = n1.a.a("camerax.core.imageOutput.maxResolution", Size.class);
        f24987t = n1.a.a("camerax.core.imageOutput.supportedResolutions", List.class);
        f24988u = n1.a.a("camerax.core.imageOutput.resolutionSelector", a1.c.class);
        f24989v = n1.a.a("camerax.core.imageOutput.customOrderedResolutions", List.class);
    }

    static void Y(i2 i2Var) {
        boolean A = i2Var.A();
        boolean z10 = i2Var.V(null) != null;
        if (A && z10) {
            throw new IllegalArgumentException("Cannot use both setTargetResolution and setTargetAspectRatio on the same config.");
        }
        if (i2Var.q(null) != null) {
            if (A || z10) {
                throw new IllegalArgumentException("Cannot use setTargetResolution or setTargetAspectRatio with setResolutionSelector on the same config.");
            }
        }
    }

    default boolean A() {
        return a(f24980m);
    }

    default int C() {
        return ((Integer) e(f24980m)).intValue();
    }

    default int J(int i10) {
        return ((Integer) h(f24981n, Integer.valueOf(i10))).intValue();
    }

    default List<Size> N(List<Size> list) {
        List list2 = (List) h(f24989v, list);
        if (list2 != null) {
            return new ArrayList(list2);
        }
        return null;
    }

    default Size R(Size size) {
        return (Size) h(f24985r, size);
    }

    default Size V(Size size) {
        return (Size) h(f24984q, size);
    }

    default int g0(int i10) {
        return ((Integer) h(f24983p, Integer.valueOf(i10))).intValue();
    }

    default Size i(Size size) {
        return (Size) h(f24986s, size);
    }

    default List<Pair<Integer, Size[]>> l(List<Pair<Integer, Size[]>> list) {
        return (List) h(f24987t, list);
    }

    default a1.c m() {
        return (a1.c) e(f24988u);
    }

    default a1.c q(a1.c cVar) {
        return (a1.c) h(f24988u, cVar);
    }

    default int t(int i10) {
        return ((Integer) h(f24982o, Integer.valueOf(i10))).intValue();
    }
}
