package n0;

import n0.n1;

/* loaded from: classes.dex */
public abstract class h2 extends l3 {

    /* renamed from: j, reason: collision with root package name */
    public static final n1.a<Integer> f24966j;

    /* renamed from: k, reason: collision with root package name */
    public static final n1.a<Integer> f24967k;

    /* renamed from: l, reason: collision with root package name */
    public static final n1.a<g0.k0> f24968l;

    static {
        Class cls = Integer.TYPE;
        f24966j = n1.a.a("camerax.core.imageInput.inputFormat", cls);
        f24967k = n1.a.a("camerax.core.imageInput.secondaryInputFormat", cls);
        f24968l = n1.a.a("camerax.core.imageInput.inputDynamicRange", g0.k0.class);
    }

    default g0.k0 M() {
        return (g0.k0) x2.g.g((g0.k0) h(f24968l, g0.k0.f16864c));
    }

    default boolean Q() {
        return a(f24968l);
    }

    default int Z() {
        return ((Integer) h(f24967k, 0)).intValue();
    }

    default int p() {
        return ((Integer) e(f24966j)).intValue();
    }
}
