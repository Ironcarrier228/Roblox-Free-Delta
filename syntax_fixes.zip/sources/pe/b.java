package pe;

import java.lang.reflect.Field;
import java.security.AccessController;
import java.security.PrivilegedActionException;
import java.security.PrivilegedExceptionAction;
import java.util.Locale;
import java.util.Objects;
import java.util.concurrent.CancellationException;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Executor;
import java.util.concurrent.Future;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
import java.util.concurrent.locks.LockSupport;
import java.util.logging.Level;
import java.util.logging.Logger;
import sun.misc.Unsafe;

/* loaded from: classes2.dex */
public abstract class b<V> extends qe.a implements x<V> {

    /* renamed from: d, reason: collision with root package name */
    public static final boolean f29036d;

    /* renamed from: e, reason: collision with root package name */
    public static final Logger f29037e;

    /* renamed from: f, reason: collision with root package name */
    public static final AbstractC0560b f29038f;

    /* renamed from: g, reason: collision with root package name */
    public static final Object f29039g;

    /* renamed from: a, reason: collision with root package name */
    public volatile Object f29040a;
    public volatile e b;

    /* renamed from: c, reason: collision with root package name */
    public volatile l f29041c;

    /* renamed from: pe.b$b, reason: collision with other inner class name */
    public static abstract class AbstractC0560b {
        public AbstractC0560b() {
        }

        public abstract boolean a(b<?> bVar, e eVar, e eVar2);

        public abstract boolean b(b<?> bVar, Object obj, Object obj2);

        public abstract boolean c(b<?> bVar, l lVar, l lVar2);

        public abstract e d(b<?> bVar, e eVar);

        public abstract l e(b<?> bVar, l lVar);

        public abstract void f(l lVar, l lVar2);

        public abstract void g(l lVar, Thread thread);
    }

    public static final class c {

        /* renamed from: c, reason: collision with root package name */
        public static final c f29042c;

        /* renamed from: d, reason: collision with root package name */
        public static final c f29043d;

        /* renamed from: a, reason: collision with root package name */
        public final boolean f29044a;
        public final Throwable b;

        static {
            if (b.f29036d) {
                f29043d = null;
                f29042c = null;
            } else {
                f29043d = new c(false, null);
                f29042c = new c(true, null);
            }
        }

        public c(boolean z10, Throwable th2) {
            this.f29044a = z10;
            this.b = th2;
        }
    }

    public static final class d {
        public static final d b = new d(new a("Failure occurred while trying to finish a future."));

        /* renamed from: a, reason: collision with root package name */
        public final Throwable f29045a;

        public class a extends Throwable {
            public a(String str) {
                super(str);
            }

            @Override // java.lang.Throwable
            public synchronized Throwable fillInStackTrace() {
                return this;
            }
        }

        public d(Throwable th2) {
            this.f29045a = (Throwable) je.n.l(th2);
        }
    }

    public static final class f extends AbstractC0560b {

        /* renamed from: a, reason: collision with root package name */
        public final AtomicReferenceFieldUpdater<l, Thread> f29049a;
        public final AtomicReferenceFieldUpdater<l, l> b;

        /* renamed from: c, reason: collision with root package name */
        public final AtomicReferenceFieldUpdater<b, l> f29050c;

        /* renamed from: d, reason: collision with root package name */
        public final AtomicReferenceFieldUpdater<b, e> f29051d;

        /* renamed from: e, reason: collision with root package name */
        public final AtomicReferenceFieldUpdater<b, Object> f29052e;

        public f(AtomicReferenceFieldUpdater<l, Thread> atomicReferenceFieldUpdater, AtomicReferenceFieldUpdater<l, l> atomicReferenceFieldUpdater2, AtomicReferenceFieldUpdater<b, l> atomicReferenceFieldUpdater3, AtomicReferenceFieldUpdater<b, e> atomicReferenceFieldUpdater4, AtomicReferenceFieldUpdater<b, Object> atomicReferenceFieldUpdater5) {
            super();
            this.f29049a = atomicReferenceFieldUpdater;
            this.b = atomicReferenceFieldUpdater2;
            this.f29050c = atomicReferenceFieldUpdater3;
            this.f29051d = atomicReferenceFieldUpdater4;
            this.f29052e = atomicReferenceFieldUpdater5;
        }

        @Override // pe.b.AbstractC0560b
        public boolean a(b<?> bVar, e eVar, e eVar2) {
            return y1.b.a(this.f29051d, bVar, eVar, eVar2);
        }

        @Override // pe.b.AbstractC0560b
        public boolean b(b<?> bVar, Object obj, Object obj2) {
            return y1.b.a(this.f29052e, bVar, obj, obj2);
        }

        @Override // pe.b.AbstractC0560b
        public boolean c(b<?> bVar, l lVar, l lVar2) {
            return y1.b.a(this.f29050c, bVar, lVar, lVar2);
        }

        @Override // pe.b.AbstractC0560b
        public e d(b<?> bVar, e eVar) {
            return this.f29051d.getAndSet(bVar, eVar);
        }

        @Override // pe.b.AbstractC0560b
        public l e(b<?> bVar, l lVar) {
            return this.f29050c.getAndSet(bVar, lVar);
        }

        @Override // pe.b.AbstractC0560b
        public void f(l lVar, l lVar2) {
            this.b.lazySet(lVar, lVar2);
        }

        @Override // pe.b.AbstractC0560b
        public void g(l lVar, Thread thread) {
            this.f29049a.lazySet(lVar, thread);
        }
    }

    public static final class g<V> implements Runnable {

        /* renamed from: a, reason: collision with root package name */
        public final b<V> f29053a;
        public final x<? extends V> b;

        public g(b<V> bVar, x<? extends V> xVar) {
            this.f29053a = bVar;
            this.b = xVar;
        }

        @Override // java.lang.Runnable
        public void run() {
            if (this.f29053a.f29040a != this) {
                return;
            }
            if (b.f29038f.b(this.f29053a, this, b.w(this.b))) {
                b.t(this.f29053a);
            }
        }
    }

    public static final class h extends AbstractC0560b {
        public h() {
            super();
        }

        @Override // pe.b.AbstractC0560b
        public boolean a(b<?> bVar, e eVar, e eVar2) {
            synchronized (bVar) {
                try {
                    if (bVar.b != eVar) {
                        return false;
                    }
                    bVar.b = eVar2;
                    return true;
                } catch (Throwable th2) {
                    throw th2;
                }
            }
        }

        @Override // pe.b.AbstractC0560b
        public boolean b(b<?> bVar, Object obj, Object obj2) {
            synchronized (bVar) {
                try {
                    if (bVar.f29040a != obj) {
                        return false;
                    }
                    bVar.f29040a = obj2;
                    return true;
                } catch (Throwable th2) {
                    throw th2;
                }
            }
        }

        @Override // pe.b.AbstractC0560b
        public boolean c(b<?> bVar, l lVar, l lVar2) {
            synchronized (bVar) {
                try {
                    if (bVar.f29041c != lVar) {
                        return false;
                    }
                    bVar.f29041c = lVar2;
                    return true;
                } catch (Throwable th2) {
                    throw th2;
                }
            }
        }

        @Override // pe.b.AbstractC0560b
        public e d(b<?> bVar, e eVar) {
            e eVar2;
            synchronized (bVar) {
                try {
                    eVar2 = bVar.b;
                    if (eVar2 != eVar) {
                        bVar.b = eVar;
                    }
                } catch (Throwable th2) {
                    throw th2;
                }
            }
            return eVar2;
        }

        @Override // pe.b.AbstractC0560b
        public l e(b<?> bVar, l lVar) {
            l lVar2;
            synchronized (bVar) {
                try {
                    lVar2 = bVar.f29041c;
                    if (lVar2 != lVar) {
                        bVar.f29041c = lVar;
                    }
                } catch (Throwable th2) {
                    throw th2;
                }
            }
            return lVar2;
        }

        @Override // pe.b.AbstractC0560b
        public void f(l lVar, l lVar2) {
            lVar.b = lVar2;
        }

        @Override // pe.b.AbstractC0560b
        public void g(l lVar, Thread thread) {
            lVar.f29060a = thread;
        }
    }

    public interface i<V> extends x<V> {
    }

    public static abstract class j<V> extends b<V> implements i<V> {
        @Override // pe.b, pe.x
        public void a(Runnable runnable, Executor executor) {
            super.a(runnable, executor);
        }

        @Override // pe.b, java.util.concurrent.Future
        public final boolean cancel(boolean z10) {
            return super.cancel(z10);
        }

        @Override // pe.b, java.util.concurrent.Future
        public V get() {
            return (V) super.get();
        }

        @Override // pe.b, java.util.concurrent.Future
        public final boolean isCancelled() {
            return super.isCancelled();
        }

        @Override // pe.b, java.util.concurrent.Future
        public boolean isDone() {
            return super.isDone();
        }

        @Override // pe.b, java.util.concurrent.Future
        public V get(long j10, TimeUnit timeUnit) {
            return (V) super.get(j10, timeUnit);
        }
    }

    public static final class k extends AbstractC0560b {

        /* renamed from: a, reason: collision with root package name */
        public static final Unsafe f29054a;
        public static final long b;

        /* renamed from: c, reason: collision with root package name */
        public static final long f29055c;

        /* renamed from: d, reason: collision with root package name */
        public static final long f29056d;

        /* renamed from: e, reason: collision with root package name */
        public static final long f29057e;

        /* renamed from: f, reason: collision with root package name */
        public static final long f29058f;

        public class a implements PrivilegedExceptionAction<Unsafe> {
            @Override // java.security.PrivilegedExceptionAction
            /* renamed from: a, reason: merged with bridge method [inline-methods] */
            public Unsafe run() {
                for (Field field : Unsafe.class.getDeclaredFields()) {
                    field.setAccessible(true);
                    Object obj = field.get(null);
                    if (Unsafe.class.isInstance(obj)) {
                        return (Unsafe) Unsafe.class.cast(obj);
                    }
                }
                throw new NoSuchFieldError("the Unsafe");
            }
        }

        static {
            Unsafe unsafe;
            try {
                try {
                    unsafe = Unsafe.getUnsafe();
                } catch (PrivilegedActionException e10) {
                    throw new RuntimeException("Could not initialize intrinsics", e10.getCause());
                }
            } catch (SecurityException unused) {
                unsafe = (Unsafe) AccessController.doPrivileged(new a());
            }
            try {
                f29055c = unsafe.objectFieldOffset(b.class.getDeclaredField("c"));
                b = unsafe.objectFieldOffset(b.class.getDeclaredField(k6.b.f21144e));
                f29056d = unsafe.objectFieldOffset(b.class.getDeclaredField(xe.a.f36648e));
                f29057e = unsafe.objectFieldOffset(l.class.getDeclaredField(xe.a.f36648e));
                f29058f = unsafe.objectFieldOffset(l.class.getDeclaredField(k6.b.f21144e));
                f29054a = unsafe;
            } catch (Exception e11) {
                je.u.j(e11);
                throw new RuntimeException(e11);
            }
        }

        public k() {
            super();
        }

        @Override // pe.b.AbstractC0560b
        public boolean a(b<?> bVar, e eVar, e eVar2) {
            return com.google.android.gms.internal.mlkit_vision_barcode.a.a(f29054a, bVar, b, eVar, eVar2);
        }

        @Override // pe.b.AbstractC0560b
        public boolean b(b<?> bVar, Object obj, Object obj2) {
            return com.google.android.gms.internal.mlkit_vision_barcode.a.a(f29054a, bVar, f29056d, obj, obj2);
        }

        @Override // pe.b.AbstractC0560b
        public boolean c(b<?> bVar, l lVar, l lVar2) {
            return com.google.android.gms.internal.mlkit_vision_barcode.a.a(f29054a, bVar, f29055c, lVar, lVar2);
        }

        @Override // pe.b.AbstractC0560b
        public e d(b<?> bVar, e eVar) {
            e eVar2;
            do {
                eVar2 = bVar.b;
                if (eVar == eVar2) {
                    break;
                }
            } while (!a(bVar, eVar2, eVar));
            return eVar2;
        }

        @Override // pe.b.AbstractC0560b
        public l e(b<?> bVar, l lVar) {
            l lVar2;
            do {
                lVar2 = bVar.f29041c;
                if (lVar == lVar2) {
                    break;
                }
            } while (!c(bVar, lVar2, lVar));
            return lVar2;
        }

        @Override // pe.b.AbstractC0560b
        public void f(l lVar, l lVar2) {
            f29054a.putObject(lVar, f29058f, lVar2);
        }

        @Override // pe.b.AbstractC0560b
        public void g(l lVar, Thread thread) {
            f29054a.putObject(lVar, f29057e, thread);
        }
    }

    public static final class l {

        /* renamed from: c, reason: collision with root package name */
        public static final l f29059c = new l(false);

        /* renamed from: a, reason: collision with root package name */
        public volatile Thread f29060a;
        public volatile l b;

        public l(boolean z10) {
        }

        public void a(l lVar) {
            b.f29038f.f(this, lVar);
        }

        public void b() {
            Thread thread = this.f29060a;
            if (thread != null) {
                this.f29060a = null;
                LockSupport.unpark(thread);
            }
        }

        public l() {
            b.f29038f.g(this, Thread.currentThread());
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v14, types: [java.util.logging.Logger] */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r5v0, types: [pe.b$a] */
    /* JADX WARN: Type inference failed for: r5v1 */
    /* JADX WARN: Type inference failed for: r5v2, types: [java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r5v3 */
    static {
        boolean z10;
        Throwable th2;
        AbstractC0560b abstractC0560b;
        try {
            z10 = Boolean.parseBoolean(System.getProperty("guava.concurrent.generate_cancellation_cause", "false"));
        } catch (SecurityException unused) {
            z10 = false;
        }
        f29036d = z10;
        f29037e = Logger.getLogger(b.class.getName());
        var r52 = 0;
        r52 = 0;
        try {
            abstractC0560b = new k();
            th2 = null;
        } catch (Throwable th3) {
            th2 = th3;
            try {
                abstractC0560b = new f(AtomicReferenceFieldUpdater.newUpdater(l.class, Thread.class, xe.a.f36648e), AtomicReferenceFieldUpdater.newUpdater(l.class, l.class, k6.b.f21144e), AtomicReferenceFieldUpdater.newUpdater(b.class, l.class, "c"), AtomicReferenceFieldUpdater.newUpdater(b.class, e.class, k6.b.f21144e), AtomicReferenceFieldUpdater.newUpdater(b.class, Object.class, xe.a.f36648e));
            } catch (Throwable th4) {
                h hVar = new h();
                r52 = th4;
                abstractC0560b = hVar;
            }
        }
        f29038f = abstractC0560b;
        if (r52 != 0) {
            var r02 = f29037e;
            Level level = Level.SEVERE;
            r02.log(level, "UnsafeAtomicHelper is broken!", th2);
            r02.log(level, "SafeAtomicHelper is broken!", r52);
        }
        f29039g = new Object();
    }

    public static CancellationException r(String str, Throwable th2) {
        CancellationException cancellationException = new CancellationException(str);
        cancellationException.initCause(th2);
        return cancellationException;
    }

    public static void t(b<?> bVar) {
        e eVar = null;
        while (true) {
            bVar.B();
            bVar.o();
            e s8 = bVar.s(eVar);
            while (s8 != null) {
                eVar = s8.f29048c;
                Runnable runnable = s8.f29047a;
                Objects.requireNonNull(runnable);
                Runnable runnable2 = runnable;
                if (runnable2 instanceof g) {
                    g gVar = (g) runnable2;
                    bVar = gVar.f29053a;
                    if (bVar.f29040a == gVar) {
                        if (f29038f.b(bVar, gVar, w(gVar.b))) {
                            break;
                        }
                    } else {
                        continue;
                    }
                } else {
                    Executor executor = s8.b;
                    Objects.requireNonNull(executor);
                    u(runnable2, executor);
                }
                s8 = eVar;
            }
            return;
        }
    }

    public static void u(Runnable runnable, Executor executor) {
        try {
            executor.execute(runnable);
        } catch (RuntimeException e10) {
            Logger logger = f29037e;
            Level level = Level.SEVERE;
            String valueOf = String.valueOf(runnable);
            String valueOf2 = String.valueOf(executor);
            StringBuilder sb2 = new StringBuilder(valueOf.length() + 57 + valueOf2.length());
            sb2.append("RuntimeException while executing runnable ");
            sb2.append(valueOf);
            sb2.append(" with executor ");
            sb2.append(valueOf2);
            logger.log(level, sb2.toString(), (Throwable) e10);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX WARN: Multi-variable type inference failed */
    public static Object w(x<?> xVar) {
        Throwable a10;
        if (xVar instanceof i) {
            Object obj = ((b) xVar).f29040a;
            if (obj instanceof c) {
                c cVar = (c) obj;
                if (cVar.f29044a) {
                    obj = cVar.b != null ? new c(false, cVar.b) : c.f29043d;
                }
            }
            Objects.requireNonNull(obj);
            return obj;
        }
        if ((xVar instanceof qe.a) && (a10 = qe.b.a((qe.a) xVar)) != null) {
            return new d(a10);
        }
        boolean isCancelled = xVar.isCancelled();
        if ((!f29036d) && isCancelled) {
            c cVar2 = c.f29043d;
            Objects.requireNonNull(cVar2);
            return cVar2;
        }
        try {
            Object x5 = x(xVar);
            if (!isCancelled) {
                return x5 == null ? f29039g : x5;
            }
            String valueOf = String.valueOf(xVar);
            StringBuilder sb2 = new StringBuilder(valueOf.length() + 84);
            sb2.append("get() did not throw CancellationException, despite reporting isCancelled() == true: ");
            sb2.append(valueOf);
            return new c(false, new IllegalArgumentException(sb2.toString()));
        } catch (CancellationException e10) {
            if (isCancelled) {
                return new c(false, e10);
            }
            String valueOf2 = String.valueOf(xVar);
            StringBuilder sb3 = new StringBuilder(valueOf2.length() + 77);
            sb3.append("get() threw CancellationException, despite reporting isCancelled() == false: ");
            sb3.append(valueOf2);
            return new d(new IllegalArgumentException(sb3.toString(), e10));
        } catch (ExecutionException e11) {
            if (!isCancelled) {
                return new d(e11.getCause());
            }
            String valueOf3 = String.valueOf(xVar);
            StringBuilder sb4 = new StringBuilder(valueOf3.length() + 84);
            sb4.append("get() did not throw CancellationException, despite reporting isCancelled() == true: ");
            sb4.append(valueOf3);
            return new c(false, new IllegalArgumentException(sb4.toString(), e11));
        } catch (Throwable th2) {
            return new d(th2);
        }
    }

    private static <V> V x(Future<V> future) {
        V v8;
        boolean z10 = false;
        while (true) {
            try {
                v8 = future.get();
                break;
            } catch (InterruptedException unused) {
                z10 = true;
            } catch (Throwable th2) {
                if (z10) {
                    Thread.currentThread().interrupt();
                }
                throw th2;
            }
        }
        if (z10) {
            Thread.currentThread().interrupt();
        }
        return v8;
    }

    /* JADX WARN: Multi-variable type inference failed */
    public String A() {
        if (!(this instanceof ScheduledFuture)) {
            return null;
        }
        long delay = ((ScheduledFuture) this).getDelay(TimeUnit.MILLISECONDS);
        StringBuilder sb2 = new StringBuilder(41);
        sb2.append("remaining delay=[");
        sb2.append(delay);
        sb2.append(" ms]");
        return sb2.toString();
    }

    public final void B() {
        for (l e10 = f29038f.e(this, l.f29059c); e10 != null; e10 = e10.b) {
            e10.b();
        }
    }

    public final void C(l lVar) {
        lVar.f29060a = null;
        while (true) {
            l lVar2 = this.f29041c;
            if (lVar2 == l.f29059c) {
                return;
            }
            l lVar3 = null;
            while (lVar2 != null) {
                l lVar4 = lVar2.b;
                if (lVar2.f29060a != null) {
                    lVar3 = lVar2;
                } else if (lVar3 != null) {
                    lVar3.b = lVar4;
                    if (lVar3.f29060a == null) {
                        break;
                    }
                } else if (!f29038f.c(this, lVar2, lVar4)) {
                    break;
                }
                lVar2 = lVar4;
            }
            return;
        }
    }

    public boolean D(V v8) {
        if (v8 == null) {
            v8 = (V) f29039g;
        }
        if (!f29038f.b(this, null, v8)) {
            return false;
        }
        t(this);
        return true;
    }

    public boolean E(Throwable th2) {
        if (!f29038f.b(this, null, new d((Throwable) je.n.l(th2)))) {
            return false;
        }
        t(this);
        return true;
    }

    public boolean F(x<? extends V> xVar) {
        d dVar;
        je.n.l(xVar);
        Object obj = this.f29040a;
        if (obj == null) {
            if (xVar.isDone()) {
                if (!f29038f.b(this, null, w(xVar))) {
                    return false;
                }
                t(this);
                return true;
            }
            g gVar = new g(this, xVar);
            if (f29038f.b(this, null, gVar)) {
                try {
                    xVar.a(gVar, pe.l.INSTANCE);
                } catch (Throwable th2) {
                    try {
                        dVar = new d(th2);
                    } catch (Throwable unused) {
                        dVar = d.b;
                    }
                    f29038f.b(this, gVar, dVar);
                }
                return true;
            }
            obj = this.f29040a;
        }
        if (obj instanceof c) {
            xVar.cancel(((c) obj).f29044a);
        }
        return false;
    }

    public final boolean G() {
        Object obj = this.f29040a;
        return (obj instanceof c) && ((c) obj).f29044a;
    }

    @Override // pe.x
    public void a(Runnable runnable, Executor executor) {
        e eVar;
        je.n.m(runnable, "Runnable was null.");
        je.n.m(executor, "Executor was null.");
        if (!isDone() && (eVar = this.b) != e.f29046d) {
            e eVar2 = new e(runnable, executor);
            do {
                eVar2.f29048c = eVar;
                if (f29038f.a(this, eVar, eVar2)) {
                    return;
                } else {
                    eVar = this.b;
                }
            } while (eVar != e.f29046d);
        }
        u(runnable, executor);
    }

    @Override // qe.a
    public final Throwable c() {
        if (!(this instanceof i)) {
            return null;
        }
        Object obj = this.f29040a;
        if (obj instanceof d) {
            return ((d) obj).f29045a;
        }
        return null;
    }

    @Override // java.util.concurrent.Future
    public boolean cancel(boolean z10) {
        c cVar;
        Object obj = this.f29040a;
        if (!(obj == null) && !(obj instanceof g)) {
            return false;
        }
        if (f29036d) {
            cVar = new c(z10, new CancellationException("Future.cancel() was called."));
        } else {
            cVar = z10 ? c.f29042c : c.f29043d;
            Objects.requireNonNull(cVar);
        }
        b<V> bVar = this;
        boolean z11 = false;
        while (true) {
            if (f29038f.b(bVar, obj, cVar)) {
                if (z10) {
                    bVar.y();
                }
                t(bVar);
                if (!(obj instanceof g)) {
                    break;
                }
                x<? extends V> xVar = ((g) obj).b;
                if (!(xVar instanceof i)) {
                    xVar.cancel(z10);
                    break;
                }
                bVar = (b) xVar;
                obj = bVar.f29040a;
                if (!(obj == null) && !(obj instanceof g)) {
                    break;
                }
                z11 = true;
            } else {
                obj = bVar.f29040a;
                if (!(obj instanceof g)) {
                    return z11;
                }
            }
        }
        return true;
    }

    @Override // java.util.concurrent.Future
    public V get(long j10, TimeUnit timeUnit) {
        long nanos = timeUnit.toNanos(j10);
        if (Thread.interrupted()) {
            throw new InterruptedException();
        }
        Object obj = this.f29040a;
        if ((obj != null) && (!(obj instanceof g))) {
            return v(obj);
        }
        long nanoTime = nanos > 0 ? System.nanoTime() + nanos : 0L;
        if (nanos >= 1000) {
            l lVar = this.f29041c;
            if (lVar != l.f29059c) {
                l lVar2 = new l();
                do {
                    lVar2.a(lVar);
                    if (f29038f.c(this, lVar, lVar2)) {
                        do {
                            c0.a(this, nanos);
                            if (Thread.interrupted()) {
                                C(lVar2);
                                throw new InterruptedException();
                            }
                            Object obj2 = this.f29040a;
                            if ((obj2 != null) && (!(obj2 instanceof g))) {
                                return v(obj2);
                            }
                            nanos = nanoTime - System.nanoTime();
                        } while (nanos >= 1000);
                        C(lVar2);
                    } else {
                        lVar = this.f29041c;
                    }
                } while (lVar != l.f29059c);
            }
            Object obj3 = this.f29040a;
            Objects.requireNonNull(obj3);
            return v(obj3);
        }
        while (nanos > 0) {
            Object obj4 = this.f29040a;
            if ((obj4 != null) && (!(obj4 instanceof g))) {
                return v(obj4);
            }
            if (Thread.interrupted()) {
                throw new InterruptedException();
            }
            nanos = nanoTime - System.nanoTime();
        }
        String bVar = toString();
        String obj5 = timeUnit.toString();
        Locale locale = Locale.ROOT;
        String lowerCase = obj5.toLowerCase(locale);
        String lowerCase2 = timeUnit.toString().toLowerCase(locale);
        StringBuilder sb2 = new StringBuilder(String.valueOf(lowerCase2).length() + 28);
        sb2.append("Waited ");
        sb2.append(j10);
        sb2.append(" ");
        sb2.append(lowerCase2);
        String sb3 = sb2.toString();
        if (nanos + 1000 < 0) {
            String concat = String.valueOf(sb3).concat(" (plus ");
            long j11 = -nanos;
            long convert = timeUnit.convert(j11, TimeUnit.NANOSECONDS);
            long nanos2 = j11 - timeUnit.toNanos(convert);
            boolean z10 = convert == 0 || nanos2 > 1000;
            if (convert > 0) {
                String valueOf = String.valueOf(concat);
                StringBuilder sb4 = new StringBuilder(valueOf.length() + 21 + String.valueOf(lowerCase).length());
                sb4.append(valueOf);
                sb4.append(convert);
                sb4.append(" ");
                sb4.append(lowerCase);
                String sb5 = sb4.toString();
                if (z10) {
                    sb5 = String.valueOf(sb5).concat(",");
                }
                concat = String.valueOf(sb5).concat(" ");
            }
            if (z10) {
                String valueOf2 = String.valueOf(concat);
                StringBuilder sb6 = new StringBuilder(valueOf2.length() + 33);
                sb6.append(valueOf2);
                sb6.append(nanos2);
                sb6.append(" nanoseconds ");
                concat = sb6.toString();
            }
            sb3 = String.valueOf(concat).concat("delay)");
        }
        if (isDone()) {
            throw new TimeoutException(String.valueOf(sb3).concat(" but future completed as timeout expired"));
        }
        StringBuilder sb7 = new StringBuilder(String.valueOf(sb3).length() + 5 + String.valueOf(bVar).length());
        sb7.append(sb3);
        sb7.append(" for ");
        sb7.append(bVar);
        throw new TimeoutException(sb7.toString());
    }

    @Override // java.util.concurrent.Future
    public boolean isCancelled() {
        return this.f29040a instanceof c;
    }

    @Override // java.util.concurrent.Future
    public boolean isDone() {
        return (!(r0 instanceof g)) & (this.f29040a != null);
    }

    public final void m(StringBuilder sb2) {
        try {
            Object x5 = x(this);
            sb2.append("SUCCESS, result=[");
            p(sb2, x5);
            sb2.append("]");
        } catch (CancellationException unused) {
            sb2.append("CANCELLED");
        } catch (RuntimeException e10) {
            sb2.append("UNKNOWN, cause=[");
            sb2.append(e10.getClass());
            sb2.append(" thrown from get()]");
        } catch (ExecutionException e11) {
            sb2.append("FAILURE, cause=[");
            sb2.append(e11.getCause());
            sb2.append("]");
        }
    }

    public final void n(StringBuilder sb2) {
        String sb3;
        int length = sb2.length();
        sb2.append("PENDING");
        Object obj = this.f29040a;
        if (obj instanceof g) {
            sb2.append(", setFuture=[");
            q(sb2, ((g) obj).b);
            sb2.append("]");
        } else {
            try {
                sb3 = je.r.a(A());
            } catch (RuntimeException | StackOverflowError e10) {
                String valueOf = String.valueOf(e10.getClass());
                StringBuilder sb4 = new StringBuilder(valueOf.length() + 38);
                sb4.append("Exception thrown from implementation: ");
                sb4.append(valueOf);
                sb3 = sb4.toString();
            }
            if (sb3 != null) {
                sb2.append(", info=[");
                sb2.append(sb3);
                sb2.append("]");
            }
        }
        if (isDone()) {
            sb2.delete(length, sb2.length());
            m(sb2);
        }
    }

    public void o() {
    }

    public final void p(StringBuilder sb2, Object obj) {
        if (obj == null) {
            sb2.append("null");
        } else {
            if (obj == this) {
                sb2.append("this future");
                return;
            }
            sb2.append(obj.getClass().getName());
            sb2.append("@");
            sb2.append(Integer.toHexString(System.identityHashCode(obj)));
        }
    }

    public final void q(StringBuilder sb2, Object obj) {
        try {
            if (obj == this) {
                sb2.append("this future");
            } else {
                sb2.append(obj);
            }
        } catch (RuntimeException e10) {
            e = e10;
            sb2.append("Exception thrown from implementation: ");
            sb2.append(e.getClass());
        } catch (StackOverflowError e11) {
            e = e11;
            sb2.append("Exception thrown from implementation: ");
            sb2.append(e.getClass());
        }
    }

    public final e s(e eVar) {
        e eVar2 = eVar;
        e d10 = f29038f.d(this, e.f29046d);
        while (d10 != null) {
            e eVar3 = d10.f29048c;
            d10.f29048c = eVar2;
            eVar2 = d10;
            d10 = eVar3;
        }
        return eVar2;
    }

    public String toString() {
        StringBuilder sb2 = new StringBuilder();
        if (getClass().getName().startsWith("com.google.common.util.concurrent.")) {
            sb2.append(getClass().getSimpleName());
        } else {
            sb2.append(getClass().getName());
        }
        sb2.append('@');
        sb2.append(Integer.toHexString(System.identityHashCode(this)));
        sb2.append("[status=");
        if (isCancelled()) {
            sb2.append("CANCELLED");
        } else if (isDone()) {
            m(sb2);
        } else {
            n(sb2);
        }
        sb2.append("]");
        return sb2.toString();
    }

    /* JADX WARN: Multi-variable type inference failed */
    public final V v(Object obj) {
        if (obj instanceof c) {
            throw r("Task was cancelled.", ((c) obj).b);
        }
        if (obj instanceof d) {
            throw new ExecutionException(((d) obj).f29045a);
        }
        return obj == f29039g ? (V) b0.b() : obj;
    }

    public void y() {
    }

    public final void z(Future<?> future) {
        if ((future != null) && isCancelled()) {
            future.cancel(G());
        }
    }

    public static final class e {

        /* renamed from: d, reason: collision with root package name */
        public static final e f29046d = new e();

        /* renamed from: a, reason: collision with root package name */
        public final Runnable f29047a;
        public final Executor b;

        /* renamed from: c, reason: collision with root package name */
        public e f29048c;

        public e(Runnable runnable, Executor executor) {
            this.f29047a = runnable;
            this.b = executor;
        }

        public e() {
            this.f29047a = null;
            this.b = null;
        }
    }

    @Override // java.util.concurrent.Future
    public V get() {
        Object obj;
        if (!Thread.interrupted()) {
            Object obj2 = this.f29040a;
            if ((obj2 != null) & (!(obj2 instanceof g))) {
                return v(obj2);
            }
            l lVar = this.f29041c;
            if (lVar != l.f29059c) {
                l lVar2 = new l();
                do {
                    lVar2.a(lVar);
                    if (f29038f.c(this, lVar, lVar2)) {
                        do {
                            LockSupport.park(this);
                            if (!Thread.interrupted()) {
                                obj = this.f29040a;
                            } else {
                                C(lVar2);
                                throw new InterruptedException();
                            }
                        } while (!((obj != null) & (!(obj instanceof g))));
                        return v(obj);
                    }
                    lVar = this.f29041c;
                } while (lVar != l.f29059c);
            }
            Object obj3 = this.f29040a;
            Objects.requireNonNull(obj3);
            return v(obj3);
        }
        throw new InterruptedException();
    }
}
