package t5;

import android.R;

/* loaded from: classes.dex */
public final class a {

    /* renamed from: a, reason: collision with root package name */
    public static int[] f32117a = {android.R.attr.orientation};
    public static int b;
}
