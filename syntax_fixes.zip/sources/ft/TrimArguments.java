package ft;

import com.github.luben.zstd.BuildConfig;
import com.withpersona.sdk2.inquiry.network.dto.ui.components.Text;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(d1 = {"\u0000,\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\f\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0010\b\n\u0002\b\u0003\n\u0002\u0010\u000b\n\u0002\b\u000b\b\u0082\b\u0018\u00002\u00020\u0001B\u001f\u0012\u0006\u0010\u0003\u001a\u00020\u0002\u0012\u0006\u0010\u0005\u001a\u00020\u0004\u0012\u0006\u0010\u0007\u001a\u00020\u0006¢\u0006\u0004\b\b\u0010\tJ\u0010\u0010\n\u001a\u00020\u0002HÖ\u0001¢\u0006\u0004\b\n\u0010\u000bJ\u0010\u0010\r\u001a\u00020\fHÖ\u0001¢\u0006\u0004\b\r\u0010\u000eJ\u001a\u0010\u0011\u001a\u00020\u00102\b\u0010\u000f\u001a\u0004\u0018\u00010\u0001HÖ\u0003¢\u0006\u0004\b\u0011\u0010\u0012R\u0017\u0010\u0003\u001a\u00020\u00028\u0006¢\u0006\f\n\u0004\b\u0013\u0010\u0014\u001a\u0004\b\u0015\u0010\u000bR\u0017\u0010\u0005\u001a\u00020\u00048\u0006¢\u0006\f\n\u0004\b\u0016\u0010\u0017\u001a\u0004\b\u0013\u0010\u0018R\u0017\u0010\u0007\u001a\u00020\u00068\u0006¢\u0006\f\n\u0004\b\u0015\u0010\u0019\u001a\u0004\b\u0016\u0010\u001a¨\u0006\u001b"}, d2 = {"Lft/r;", BuildConfig.FLAVOR, BuildConfig.FLAVOR, Text.type, BuildConfig.FLAVOR, "char", "Lft/s;", "mode", "<init>", "(Ljava/lang/String;CLft/s;)V", "toString", "()Ljava/lang/String;", BuildConfig.FLAVOR, "hashCode", "()I", "other", BuildConfig.FLAVOR, "equals", "(Ljava/lang/Object;)Z", xe.a.f36648e, "Ljava/lang/String;", "c", k6.b.f21144e, "C", "()C", "Lft/s;", "()Lft/s;", "operations-stdlib_release"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* renamed from: ft.r, reason: from toString */
/* loaded from: classes3.dex */
public final /* data */ class TrimArguments {

    /* renamed from: a, reason: collision with root package name and from kotlin metadata and from toString */
    @NotNull
    public final String text;

    /* renamed from: b, reason: from kotlin metadata */
    public final char char_;

    /* renamed from: c, reason: collision with root package name and from kotlin metadata and from toString */
    @NotNull
    public final s mode;

    public TrimArguments(@NotNull String text, char c10, @NotNull s mode) {
        Intrinsics.checkNotNullParameter(text, "text");
        Intrinsics.checkNotNullParameter(mode, "mode");
        this.text = text;
        this.char_ = c10;
        this.mode = mode;
    }

    /* renamed from: a, reason: from getter */
    public final char getChar() {
        return this.char_;
    }

    @NotNull
    /* renamed from: b, reason: from getter */
    public final s getMode() {
        return this.mode;
    }

    @NotNull
    /* renamed from: c, reason: from getter */
    public final String getText() {
        return this.text;
    }

    public boolean equals(@Nullable Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof TrimArguments)) {
            return false;
        }
        TrimArguments trimArguments = (TrimArguments) other;
        return Intrinsics.c(this.text, trimArguments.text) && this.char_ == trimArguments.char_ && Intrinsics.c(this.mode, trimArguments.mode);
    }

    public int hashCode() {
        return (((this.text.hashCode() * 31) + Character.hashCode(this.char_)) * 31) + this.mode.hashCode();
    }

    @NotNull
    public String toString() {
        return "TrimArguments(text=" + this.text + ", char_=" + this.char_ + ", mode=" + this.mode + ")";
    }
}
