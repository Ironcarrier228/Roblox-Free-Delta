package eg;

import androidx.annotation.NonNull;
import eg.f;

/* loaded from: classes2.dex */
public final class b extends f {

    /* renamed from: a, reason: collision with root package name */
    public final String f13451a;
    public final long b;

    /* renamed from: c, reason: collision with root package name */
    public final f.b f13452c;

    /* renamed from: eg.b$b, reason: collision with other inner class name */
    public static final class C0259b extends f.a {

        /* renamed from: a, reason: collision with root package name */
        public String f13453a;
        public long b;

        /* renamed from: c, reason: collision with root package name */
        public f.b f13454c;

        /* renamed from: d, reason: collision with root package name */
        public byte f13455d;

        @Override // eg.f.a
        public f a() {
            if (this.f13455d == 1) {
                return new b(this.f13453a, this.b, this.f13454c);
            }
            throw new IllegalStateException("Missing required properties: tokenExpirationTimestamp");
        }

        @Override // eg.f.a
        public f.a b(f.b bVar) {
            this.f13454c = bVar;
            return this;
        }

        @Override // eg.f.a
        public f.a c(String str) {
            this.f13453a = str;
            return this;
        }

        @Override // eg.f.a
        public f.a d(long j10) {
            this.b = j10;
            this.f13455d = (byte) (this.f13455d | 1);
            return this;
        }
    }

    @Override // eg.f
    public f.b b() {
        return this.f13452c;
    }

    @Override // eg.f
    public String c() {
        return this.f13451a;
    }

    @Override // eg.f
    @NonNull
    public long d() {
        return this.b;
    }

    public boolean equals(Object obj) {
        f.b bVar;
        if (obj == this) {
            return true;
        }
        if (obj instanceof f) {
            f fVar = (f) obj;
            String str = this.f13451a;
            if (str != null ? str.equals(fVar.c()) : fVar.c() == null) {
                if (this.b == fVar.d() && ((bVar = this.f13452c) != null ? bVar.equals(fVar.b()) : fVar.b() == null)) {
                    return true;
                }
            }
        }
        return false;
    }

    public int hashCode() {
        String str = this.f13451a;
        int hashCode = str == null ? 0 : str.hashCode();
        long j10 = this.b;
        int i10 = (((hashCode ^ 1000003) * 1000003) ^ ((int) (j10 ^ (j10 >>> 32)))) * 1000003;
        f.b bVar = this.f13452c;
        return i10 ^ (bVar != null ? bVar.hashCode() : 0);
    }

    public String toString() {
        return "TokenResult{token=" + this.f13451a + ", tokenExpirationTimestamp=" + this.b + ", responseCode=" + this.f13452c + "}";
    }

    public b(String str, long j10, f.b bVar) {
        this.f13451a = str;
        this.b = j10;
        this.f13452c = bVar;
    }


    // --- восстановлено из DEX (eg/b$a) ---
    public static class a {
        // члены отсутствуют в DEX
    }
}
