package kq;

import com.github.luben.zstd.BuildConfig;
import java.util.Iterator;
import java.util.Set;
import kotlin.Metadata;
import kotlin.collections.CollectionsKt;
import kotlin.collections.p0;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import mv.a0;
import mv.c0;
import mv.f0;
import mv.g0;
import mv.h0;
import nn.b0;
import org.jetbrains.annotations.NotNull;
import org.json.JSONObject;

@Metadata(d1 = {"\u0000\u001a\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\b\u0007\u0018\u0000 \t2\u00020\u0001:\u0001\tB\u0007¢\u0006\u0004\b\u0002\u0010\u0003J\u0017\u0010\u0007\u001a\u00020\u00062\u0006\u0010\u0005\u001a\u00020\u0004H\u0007¢\u0006\u0004\b\u0007\u0010\b¨\u0006\n"}, d2 = {"Lkq/f;", BuildConfig.FLAVOR, "<init>", "()V", "Lkq/c;", "flags", "Lmv/a0;", k6.b.f21144e, "(Lkq/c;)Lmv/a0;", xe.a.f36648e, "sandbox_release"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* loaded from: classes3.dex */
public final class f {

    /* renamed from: a, reason: collision with root package name and from kotlin metadata */
    @NotNull
    public static final Companion INSTANCE = new Companion(null);

    @Metadata(d1 = {"\u0000\u0018\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\"\n\u0002\u0018\u0002\n\u0002\b\u0003\b\u0087\u0003\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\u0019\u0010\u0006\u001a\f\u0012\b\u0012\u0006\u0012\u0002\b\u00030\u00050\u0004H\u0007¢\u0006\u0004\b\u0006\u0010\u0007¨\u0006\b"}, d2 = {"Lkq/f$a;", BuildConfig.FLAVOR, "<init>", "()V", BuildConfig.FLAVOR, "Lnn/b0;", xe.a.f36648e, "()Ljava/util/Set;", "sandbox_release"}, k = 1, mv = {2, 2, 0}, xi = 48)
    /* renamed from: kq.f$a, reason: from kotlin metadata */
    public static final class Companion {
        public /* synthetic */ Companion(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }

        @NotNull
        public final Set<b0<?>> a() {
            return p0.c(p.INSTANCE);
        }

        public Companion() {
        }
    }

    public static final h0 c(c cVar, a0.a chain) {
        Intrinsics.checkNotNullParameter(chain, "chain");
        f0 h10 = chain.h();
        g0 body = h10.getBody();
        if ((!Intrinsics.c(CollectionsKt.o0(h10.getUrl().l()), "transition") && !Intrinsics.c(CollectionsKt.o0(h10.getUrl().l()), "government-id-classification")) || body == null || !cVar.getIsSandboxModeEnabled()) {
            return chain.a(h10);
        }
        String a10 = c.INSTANCE.a(cVar.getDebugForcedStatus());
        mv.b0 f24604c = body.getF24604c();
        String subtype = f24604c != null ? f24604c.getSubtype() : null;
        if (Intrinsics.c(subtype, "form-data")) {
            c0 c0Var = (c0) body;
            c0.a e10 = new c0.a(null, 1, null).e(c0Var.getType());
            Iterator<T> it = c0Var.j().iterator();
            while (it.hasNext()) {
                e10.c((c0.c) it.next());
            }
            return chain.a(h10.j().o(h10.getMethod(), e10.a("meta[workflowInitialVariables][debugForcedStatus]", a10).d()).b());
        }
        if (!Intrinsics.c(subtype, "json")) {
            return chain.a(h10);
        }
        ew.e eVar = new ew.e();
        body.h(eVar);
        JSONObject jSONObject = new JSONObject(eVar.V2());
        JSONObject optJSONObject = jSONObject.optJSONObject("meta");
        if (optJSONObject == null) {
            optJSONObject = new JSONObject();
        }
        optJSONObject.put("workflowInitialVariables", new JSONObject().put("debugForcedStatus", a10));
        jSONObject.put("meta", optJSONObject);
        g0.Companion companion = g0.INSTANCE;
        String jSONObject2 = jSONObject.toString();
        Intrinsics.checkNotNullExpressionValue(jSONObject2, "toString(...)");
        return chain.a(h10.j().o(h10.getMethod(), companion.c(jSONObject2, body.getF24604c())).b());
    }

    @NotNull
    public static final Set<b0<?>> d() {
        return INSTANCE.a();
    }

    @NotNull
    public final a0 b(@NotNull final c flags) {
        Intrinsics.checkNotNullParameter(flags, "flags");
        return new a0() { // from class: kq.e
            @Override // mv.a0
            public final h0 intercept(a0.a aVar) {
                h0 c10;
                c10 = f.c(c.this, aVar);
                return c10;
            }
        };
    }
}
