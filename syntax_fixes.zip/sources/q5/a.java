package q5;

import android.R;

/* loaded from: classes.dex */
public class a {

    /* renamed from: a, reason: collision with root package name */
    public static final int[] f29775a = {android.R.attr.name, R.attr.tint, R.attr.height, android.R.attr.width, R.attr.alpha, android.R.attr.autoMirrored, R.attr.tintMode, android.R.attr.viewportWidth, android.R.attr.viewportHeight};
    public static final int[] b = {android.R.attr.name, android.R.attr.pivotX, android.R.attr.pivotY, android.R.attr.scaleX, android.R.attr.scaleY, android.R.attr.rotation, android.R.attr.translateX, android.R.attr.translateY};

    /* renamed from: c, reason: collision with root package name */
    public static final int[] f29776c = {android.R.attr.name, android.R.attr.fillColor, android.R.attr.pathData, R.attr.strokeColor, R.attr.strokeWidth, android.R.attr.trimPathStart, android.R.attr.trimPathEnd, android.R.attr.trimPathOffset, android.R.attr.strokeLineCap, android.R.attr.strokeLineJoin, android.R.attr.strokeMiterLimit, android.R.attr.strokeAlpha, android.R.attr.fillAlpha, android.R.attr.fillType};

    /* renamed from: d, reason: collision with root package name */
    public static final int[] f29777d = {android.R.attr.name, android.R.attr.pathData, android.R.attr.fillType};

    /* renamed from: e, reason: collision with root package name */
    public static final int[] f29778e = {android.R.attr.drawable};

    /* renamed from: f, reason: collision with root package name */
    public static final int[] f29779f = {android.R.attr.name, android.R.attr.animation};

    /* renamed from: g, reason: collision with root package name */
    public static final int[] f29780g = {android.R.attr.interpolator, R.attr.duration, android.R.attr.startOffset, android.R.attr.repeatCount, android.R.attr.repeatMode, android.R.attr.valueFrom, android.R.attr.valueTo, android.R.attr.valueType};

    /* renamed from: h, reason: collision with root package name */
    public static final int[] f29781h = {android.R.attr.ordering};

    /* renamed from: i, reason: collision with root package name */
    public static final int[] f29782i = {android.R.attr.valueFrom, android.R.attr.valueTo, android.R.attr.valueType, android.R.attr.propertyName};

    /* renamed from: j, reason: collision with root package name */
    public static final int[] f29783j = {android.R.attr.value, android.R.attr.interpolator, android.R.attr.valueType, android.R.attr.fraction};

    /* renamed from: k, reason: collision with root package name */
    public static final int[] f29784k = {android.R.attr.propertyName, android.R.attr.pathData, android.R.attr.propertyXName, android.R.attr.propertyYName};

    /* renamed from: l, reason: collision with root package name */
    public static final int[] f29785l = {android.R.attr.controlX1, android.R.attr.controlY1, android.R.attr.controlX2, android.R.attr.controlY2, android.R.attr.pathData};
}
