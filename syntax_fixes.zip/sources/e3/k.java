package e3;

import kotlin.Metadata;

@Metadata(d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\u0018\u0000 \u00022\u00020\u0001:\u0001\u0003¨\u0006\u0004"}, d2 = {"Le3/k;", "Le3/b;", "j", xe.a.f36648e, "credentials_release"}, k = 1, mv = {2, 1, 0}, xi = 48)
/* loaded from: classes.dex */
public final class k extends b {


    // --- восстановлено из DEX (e3/k$a) ---
    public static class a {
        public a() { }
        public a(kotlin.jvm.internal.DefaultConstructorMarker p0) { }
    }
}
