package e3;

import com.github.luben.zstd.BuildConfig;
import kotlin.Metadata;
import org.jetbrains.annotations.NotNull;

@Metadata(d1 = {"\u0000\u0010\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u000e\n\u0002\b\b\b\u0007\u0018\u0000 \b2\u00020\u0001:\u0001\tR\u0017\u0010\u0007\u001a\u00020\u00028\u0006¢\u0006\f\n\u0004\b\u0003\u0010\u0004\u001a\u0004\b\u0005\u0010\u0006¨\u0006\n"}, d2 = {"Le3/e;", "Le3/b;", BuildConfig.FLAVOR, "j", "Ljava/lang/String;", "g", "()Ljava/lang/String;", "requestJson", "k", xe.a.f36648e, "credentials_release"}, k = 1, mv = {2, 1, 0}, xi = 48)
/* loaded from: classes.dex */
public final class e extends b {

    /* renamed from: j, reason: collision with root package name and from kotlin metadata */
    @NotNull
    public final String requestJson;

    @NotNull
    /* renamed from: g, reason: from getter */
    public final String getRequestJson() {
        return this.requestJson;
    }


    // --- восстановлено из DEX (e3/e$a) ---
    public static class a {
        public a() { }
        public a(kotlin.jvm.internal.DefaultConstructorMarker p0) { }
    }
}
