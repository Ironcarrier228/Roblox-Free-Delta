package deobf.unlinked.k4;

// dex: classes.dex
public final class a {

    public static int f21137a = 2131296941;
}
