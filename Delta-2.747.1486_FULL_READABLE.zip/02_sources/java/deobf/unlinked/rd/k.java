package deobf.unlinked.rd;

import android.os.Bundle;
import java.util.Objects;
import deobf.unlinked.sd.b;

// dex: classes2.dex
public final class k extends b.a {

    public final deobf.unlinked.jb.d f30656a;
    public final deobf.com.google.mlkit.common.tb.k b;

    public final /* synthetic */ l f30657c;

    public k(l lVar, deobf.com.google.mlkit.common.tb.k kVar) {
        Objects.requireNonNull(lVar);
        this.f30657c = lVar;
        this.f30656a = new deobf.unlinked.jb.d("OnCheckAgeSignalsCallback");
        this.b = kVar;
    }

    @Override // deobf.unlinked.sd.b
    public final void L0(Bundle bundle) {
        deobf.unlinked.jb.o oVar = this.f30657c.b;
        deobf.com.google.mlkit.common.tb.k kVar = this.b;
        oVar.u(kVar);
        int i10 = bundle.getInt("error.code");
        this.f30656a.a("onError(%d)", Integer.valueOf(i10));
        kVar.d(new a(i10));
    }

    @Override // deobf.unlinked.sd.b
    public final void P(Bundle bundle) {
        deobf.unlinked.jb.o oVar = this.f30657c.b;
        deobf.com.google.mlkit.common.tb.k kVar = this.b;
        oVar.u(kVar);
        this.f30656a.c("onCompleteCheckAgeSignals", new Object[0]);
        kVar.e(e.g(bundle));
    }
}
