package deobf.unlinked.rd;

import android.content.Context;
import androidx.annotation.NonNull;

// dex: classes2.dex
public class c {
    @NonNull
    public static b a(@NonNull Context context) {
        return new g(new l(context));
    }
}
