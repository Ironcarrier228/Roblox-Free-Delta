package deobf.unlinked.rd;

import java.util.Date;
import deobf.unlinked.rd.e;

// dex: classes2.dex
public final class m extends deobf.com.roblox.client.e.a {

    public Integer f30660a;
    public Integer b;

    public Integer f30661c;

    public Date f30662d;

    public String f30663e;

    @Override // deobf.unlinked.rd.e.a
    public final e a() {
        return new o(this.f30660a, this.b, this.f30661c, this.f30662d, this.f30663e, null);
    }

    @Override // deobf.unlinked.rd.e.a
    public final deobf.com.roblox.client.e.a b(Integer num) {
        this.b = num;
        return this;
    }

    @Override // deobf.unlinked.rd.e.a
    public final deobf.com.roblox.client.e.a c(Integer num) {
        this.f30661c = num;
        return this;
    }

    @Override // deobf.unlinked.rd.e.a
    public final deobf.com.roblox.client.e.a d(String str) {
        this.f30663e = str;
        return this;
    }

    @Override // deobf.unlinked.rd.e.a
    public final deobf.com.roblox.client.e.a e(Date date) {
        this.f30662d = date;
        return this;
    }

    @Override // deobf.unlinked.rd.e.a
    public final deobf.com.roblox.client.e.a f(Integer num) {
        this.f30660a = num;
        return this;
    }
}
