package deobf.unlinked.rd;

import java.util.Date;

// dex: classes2.dex
public final class o extends e {

    public final Integer f30664a;
    public final Integer b;

    public final Integer f30665c;

    public final Date f30666d;

    public final String f30667e;

    public /* synthetic */ o(Integer num, Integer num2, Integer num3, Date date, String str, n nVar) {
        this.f30664a = num;
        this.b = num2;
        this.f30665c = num3;
        this.f30666d = date;
        this.f30667e = str;
    }

    @Override // deobf.unlinked.rd.e
    public final Integer a() {
        return this.b;
    }

    @Override // deobf.unlinked.rd.e
    public final Integer b() {
        return this.f30665c;
    }

    @Override // deobf.unlinked.rd.e
    public final String d() {
        return this.f30667e;
    }

    @Override // deobf.unlinked.rd.e
    public final Date e() {
        return this.f30666d;
    }

    public final boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (obj instanceof e) {
            e eVar = (e) obj;
            Integer num = this.f30664a;
            if (num != null ? num.equals(eVar.f()) : eVar.f() == null) {
                Integer num2 = this.b;
                if (num2 != null ? num2.equals(eVar.a()) : eVar.a() == null) {
                    Integer num3 = this.f30665c;
                    if (num3 != null ? num3.equals(eVar.b()) : eVar.b() == null) {
                        Date date = this.f30666d;
                        if (date != null ? date.equals(eVar.e()) : eVar.e() == null) {
                            String str = this.f30667e;
                            if (str != null ? str.equals(eVar.d()) : eVar.d() == null) {
                                return true;
                            }
                        }
                    }
                }
            }
        }
        return false;
    }

    @Override // deobf.unlinked.rd.e
    public final Integer f() {
        return this.f30664a;
    }

    public final int hashCode() {
        Integer num = this.f30664a;
        int hashCode = num == null ? 0 : num.hashCode();
        Integer num2 = this.b;
        int hashCode2 = num2 == null ? 0 : num2.hashCode();
        int i10 = hashCode ^ 1000003;
        Integer num3 = this.f30665c;
        int hashCode3 = ((((i10 * 1000003) ^ hashCode2) * 1000003) ^ (num3 == null ? 0 : num3.hashCode())) * 1000003;
        Date date = this.f30666d;
        int hashCode4 = (hashCode3 ^ (date == null ? 0 : date.hashCode())) * 1000003;
        String str = this.f30667e;
        return hashCode4 ^ (str != null ? str.hashCode() : 0);
    }

    public final String toString() {
        return "AgeSignalsResult{userStatus=" + this.f30664a + ", ageLower=" + this.b + ", ageUpper=" + this.f30665c + ", mostRecentApprovalDate=" + String.valueOf(this.f30666d) + ", installId=" + this.f30667e + "}";
    }
}
