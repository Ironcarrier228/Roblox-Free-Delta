package deobf.unlinked.rd;

import androidx.annotation.NonNull;
import com.google.android.gms.tasks.Task;

// dex: classes2.dex
public final class g implements b {

    public final l f30653a;

    public g(l lVar) {
        this.f30653a = lVar;
    }

    @Override // deobf.unlinked.rd.b
    @NonNull
    public final Task<e> a(d dVar) {
        return this.f30653a.b(dVar);
    }
}
