package deobf.unlinked.rd;

import android.content.Context;
import com.google.android.gms.tasks.Task;
import deobf.unlinked.jb.r;

// dex: classes2.dex
public final class l {

    public static final deobf.unlinked.jb.d f30658c = new deobf.unlinked.jb.d("AgeSignalsService");

    public final Context f30659a;
    public final deobf.unlinked.jb.o b;

    /* JADX WARN: Type inference failed for: r6v0, types: [rd.i] */
    public l(Context context) {
        this.f30659a = context;
        if (r.b(context)) {
            this.b = new deobf.unlinked.jb.o(context, f30658c, "AgeSignalsService", f.f30652a, new Object() { // from class: rd.i
            }, null);
        } else {
            this.b = null;
        }
    }

    public static Task d(int i10) {
        f30658c.a("onError(%d)", Integer.valueOf(i10));
        return deobf.com.google.mlkit.common.tb.m.e(new a(i10));
    }

    public final Task b(d dVar) {
        deobf.unlinked.jb.o oVar = this.b;
        if (oVar == null) {
            return d(-2);
        }
        if (r.a(this.f30659a) < 82380000) {
            return d(-6);
        }
        deobf.com.google.mlkit.common.tb.k kVar = new deobf.com.google.mlkit.common.tb.k();
        oVar.t(new j(this, kVar, kVar, dVar), kVar);
        return kVar.a();
    }
}
