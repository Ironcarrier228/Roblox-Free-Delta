package deobf.unlinked.rd;

import androidx.annotation.NonNull;

// dex: classes2.dex
public class d {

    public static class a {
        public /* synthetic */ a(h hVar) {
        }

        @NonNull
        public d a() {
            return new d(null);
        }
    }

    public /* synthetic */ d(h hVar) {
    }

    @NonNull
    public static a a() {
        return new a(null);
    }
}
