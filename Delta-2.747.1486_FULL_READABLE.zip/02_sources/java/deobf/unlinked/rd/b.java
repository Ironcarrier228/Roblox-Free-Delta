package deobf.unlinked.rd;

import androidx.annotation.NonNull;
import com.google.android.gms.tasks.Task;

// dex: classes2.dex
public interface b {
    @NonNull
    Task<e> a(@NonNull d dVar);
}
