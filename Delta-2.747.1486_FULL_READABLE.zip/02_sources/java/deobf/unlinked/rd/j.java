package deobf.unlinked.rd;

import android.content.Context;
import android.os.Bundle;
import android.os.RemoteException;
import java.util.Objects;
import deobf.unlinked.jb.p;

// dex: classes2.dex
public final class j extends deobf.unlinked.jb.e {
    public final /* synthetic */ deobf.com.google.mlkit.common.tb.k b;

    public final /* synthetic */ d f30654c;

    public final /* synthetic */ l f30655d;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public j(l lVar, deobf.com.google.mlkit.common.tb.k kVar, deobf.com.google.mlkit.common.tb.k kVar2, d dVar) {
        super(kVar);
        this.b = kVar2;
        this.f30654c = dVar;
        Objects.requireNonNull(lVar);
        this.f30655d = lVar;
    }

    @Override // deobf.unlinked.jb.e
    public final void a(Exception exc) {
        if (exc instanceof p) {
            super.a(new a(-5));
        } else {
            super.a(exc);
        }
    }

    @Override // deobf.unlinked.jb.e
    public final void b() {
        deobf.unlinked.jb.d dVar;
        Context context;
        try {
            l lVar = this.f30655d;
            deobf.unlinked.sd.a aVar = (deobf.unlinked.sd.a) lVar.b.e();
            context = lVar.f30659a;
            String packageName = context.getPackageName();
            Bundle bundle = new Bundle();
            bundle.putInt("playcore.version.code", 3);
            aVar.R1(packageName, bundle, new k(lVar, this.b));
        } catch (RemoteException e10) {
            d dVar2 = this.f30654c;
            dVar = l.f30658c;
            dVar.b(e10, "checkAgeSignals(%s)", dVar2);
            this.b.d(new a(-100));
        }
    }
}
