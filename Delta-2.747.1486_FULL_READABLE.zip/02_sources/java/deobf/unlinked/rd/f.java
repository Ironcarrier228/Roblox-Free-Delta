package deobf.unlinked.rd;

import android.content.Intent;

// dex: classes2.dex
public final class f {

    public static final Intent f30652a = new Intent("com.google.android.finsky.ageverification.BIND").setPackage("com.android.vending");
}
