package deobf.unlinked.yn;

import android.content.Context;
import deobf.com.withpersona.sdk2.inquiry.wt.d;
import deobf.com.withpersona.sdk2.inquiry.wt.i;

// dex: classes3.dex
public final class c implements d<b> {

    public final i<Context> f37968a;

    public c(i<Context> iVar) {
        this.f37968a = iVar;
    }

    public static c a(i<Context> iVar) {
        return new c(iVar);
    }

    public static b c(Context context) {
        return new b(context);
    }

    @Override // deobf.unlinked.yt.a
    public b get() {
        return c(this.f37968a.get());
    }
}
