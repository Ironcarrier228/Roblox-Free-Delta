package deobf.unlinked.vr;

import android.content.Context;
import android.content.res.ColorStateList;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.TextView;
import androidx.core.graphics.Insets;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import deobf.com.withpersona.sdk2.inquiry.av.a0;
import deobf.com.withpersona.sdk2.inquiry.av.n;
import deobf.com.withpersona.sdk2.inquiry.av.p0;
import deobf.com.withpersona.sdk2.inquiry.av.z2;
import com.github.luben.zstd.BuildConfig;
import com.google.android.material.bottomsheet.BottomSheetBehavior;
import com.google.mlkit.vision.barcode.common.Barcode;
import com.withpersona.sdk2.inquiry.network.dto.ui.InputSelectBoxComponentStyle;
import java.util.List;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.c0;
import kotlin.jvm.internal.y;
import kotlin.text.StringsKt;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import deobf.com.withpersona.sdk2.inquiry.pm.t;
import deobf.com.withpersona.sdk2.inquiry.qr.Option;
import deobf.com.withpersona.sdk2.inquiry.qr.i2;
import deobf.com.withpersona.sdk2.inquiry.yr.h0;
import deobf.com.withpersona.sdk2.inquiry.zt.n;
import deobf.com.withpersona.sdk2.inquiry.zt.o;

@Metadata(d1 = {"\u0000R\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0002\b\u0003\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u000b\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0010\b\n\u0002\b\t\u0018\u00002\u00020\u0001B\u000f\u0012\u0006\u0010\u0003\u001a\u00020\u0002¢\u0006\u0004\b\u0004\u0010\u0005J/\u0010\r\u001a\u00020\u000b2\u0006\u0010\u0007\u001a\u00020\u00062\u0018\u0010\f\u001a\u0014\u0012\n\u0012\b\u0012\u0004\u0012\u00020\n0\t\u0012\u0004\u0012\u00020\u000b0\b¢\u0006\u0004\b\r\u0010\u000eJ\r\u0010\u0010\u001a\u00020\u000f¢\u0006\u0004\b\u0010\u0010\u0011J\u001d\u0010\u0014\u001a\u00020\u000b2\f\u0010\u0013\u001a\b\u0012\u0004\u0012\u00020\u000b0\u0012H\u0002¢\u0006\u0004\b\u0014\u0010\u0015J\u001f\u0010\u0018\u001a\u00020\u000b2\u0006\u0010\u0016\u001a\u00020\u000f2\u0006\u0010\u0017\u001a\u00020\u000fH\u0002¢\u0006\u0004\b\u0018\u0010\u0019J\u000f\u0010\u001a\u001a\u00020\u000bH\u0002¢\u0006\u0004\b\u001a\u0010\u001bR\u0014\u0010\u0003\u001a\u00020\u00028\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b\u001c\u0010\u001dR\u001f\u0010#\u001a\r\u0012\t\u0012\u00070\u001f¢\u0006\u0002\b 0\u001e8\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b!\u0010\"R\u0016\u0010&\u001a\u00020\u000f8\u0002@\u0002X\u0082\u000e¢\u0006\u0006\n\u0004\b$\u0010%R$\u0010*\u001a\u0010\u0012\u0004\u0012\u00020'\u0012\u0004\u0012\u00020\u000b\u0018\u00010\b8\u0002@\u0002X\u0082\u000e¢\u0006\u0006\n\u0004\b(\u0010)R\u001b\u0010/\u001a\u00020\u001f8BX\u0082\u0084\u0002¢\u0006\f\u001a\u0004\b+\u0010,*\u0004\b-\u0010.¨\u00060"}, d2 = {"Lvr/j;", BuildConfig.FLAVOR, "Landroid/view/ViewGroup;", "contentView", "<init>", "(Landroid/view/ViewGroup;)V", "Lqr/i2;", "component", "Lkotlin/Function1;", BuildConfig.FLAVOR, "Lqr/l4;", BuildConfig.FLAVOR, "onItemsSelectedListener", t.f29212d, "(Lqr/i2;Lkotlin/jvm/functions/Function1;)V", BuildConfig.FLAVOR, "l", "()Z", "Lkotlin/Function0;", "callback", "p", "(Lkotlin/jvm/functions/Function0;)V", "visible", "hasTitle", "q", "(ZZ)V", "r", "()V", deobf.android.view.xe.a.f36648e, "Landroid/view/ViewGroup;", "Lzt/h;", "Lur/a;", "Lkotlin/jvm/internal/EnhancedNullability;", deobf.android.view.k6.b.f21144e, "Lzt/h;", "lazyBinding", "c", "Z", "setup", BuildConfig.FLAVOR, "d", "Lkotlin/jvm/functions/Function1;", "bottomSheetStateChangeListener", "n", "()Lur/a;", "getBinding$delegate", "(Lvr/j;)Ljava/lang/Object;", "binding", "ui-step-renderer_release"}, k = 1, mv = {2, 2, 0}, xi = 48)
// dex: classes3.dex
public final class j {

    @NotNull
    public final ViewGroup contentView;

    @NotNull
    public final deobf.com.withpersona.sdk2.inquiry.zt.h<deobf.com.withpersona.sdk2.inquiry.ur.a> lazyBinding;

    public boolean setup;

    @Nullable
    public Function1<? super Integer, Unit> bottomSheetStateChangeListener;

    @Metadata(d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0002\b\u0002\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\n¢\u0006\u0004\b\u0002\u0010\u0003"}, d2 = {"Lav/p0;", BuildConfig.FLAVOR, "<anonymous>", "(Lav/p0;)V"}, k = 3, mv = {2, 2, 0})
    @deobf.com.withpersona.sdk2.inquiry.gu.f(c = "com.withpersona.sdk2.inquiry.steps.ui.inputSelect.InputSelectBottomSheetController$runAfterKeyboardShown$1", f = "InputSelectBottomSheetController.kt", l = {}, m = "invokeSuspend")
    public static final class a extends deobf.com.withpersona.sdk2.inquiry.gu.m implements Function2<p0, deobf.kotlin.eu.b<? super Unit>, Object> {

        public int f35378t;

        public /* synthetic */ Object f35379u;

        public final /* synthetic */ Function0<Unit> f35381w;

        @Metadata(d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0002\b\u0002\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\n¢\u0006\u0004\b\u0002\u0010\u0003"}, d2 = {"Lav/p0;", BuildConfig.FLAVOR, "<anonymous>", "(Lav/p0;)V"}, k = 3, mv = {2, 2, 0})
        @deobf.com.withpersona.sdk2.inquiry.gu.f(c = "com.withpersona.sdk2.inquiry.steps.ui.inputSelect.InputSelectBottomSheetController$runAfterKeyboardShown$1$1", f = "InputSelectBottomSheetController.kt", l = {296, 198}, m = "invokeSuspend")
        public static final class C0722a extends deobf.com.withpersona.sdk2.inquiry.gu.m implements Function2<p0, deobf.kotlin.eu.b<? super Unit>, Object> {

            public Object f35382t;

            public int f35383u;

            public int f35384v;

            public final /* synthetic */ a0 f35385w;

            public final /* synthetic */ j f35386x;

            public final /* synthetic */ Function0<Unit> f35387y;

            @Metadata(k = 3, mv = {2, 2, 0}, xi = 48)
            public static final class C0723a implements Function1<WindowInsetsCompat, Unit> {

                public final /* synthetic */ y f35388a;
                public final /* synthetic */ n<Unit> b;

                /* JADX WARN: Multi-variable type inference failed */
                public C0723a(y yVar, n<? super Unit> nVar) {
                    this.f35388a = yVar;
                    this.b = nVar;
                }

                public final void a(WindowInsetsCompat insets) {
                    Intrinsics.checkNotNullParameter(insets, "insets");
                    if (this.f35388a.f21589a) {
                        return;
                    }
                    Insets insets2 = insets.getInsets(WindowInsetsCompat.Type.ime());
                    Intrinsics.checkNotNullExpressionValue(insets2, "getInsets(...)");
                    if (insets2.bottom > 0) {
                        this.f35388a.f21589a = true;
                        n<Unit> nVar = this.b;
                        n.Companion companion = deobf.com.withpersona.sdk2.inquiry.zt.n.INSTANCE;
                        nVar.resumeWith(deobf.com.withpersona.sdk2.inquiry.zt.n.b(Unit.f21504a));
                    }
                }

                @Override // kotlin.jvm.functions.Function1
                public /* bridge */ /* synthetic */ Unit invoke(WindowInsetsCompat windowInsetsCompat) {
                    a(windowInsetsCompat);
                    return Unit.f21504a;
                }
            }

            @Metadata(d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0002\b\u0002\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\n¢\u0006\u0004\b\u0002\u0010\u0003"}, d2 = {"Lav/p0;", BuildConfig.FLAVOR, "<anonymous>", "(Lav/p0;)V"}, k = 3, mv = {2, 2, 0})
            @deobf.com.withpersona.sdk2.inquiry.gu.f(c = "com.withpersona.sdk2.inquiry.steps.ui.inputSelect.InputSelectBottomSheetController$runAfterKeyboardShown$1$1$2", f = "InputSelectBottomSheetController.kt", l = {}, m = "invokeSuspend")
            public static final class b extends deobf.com.withpersona.sdk2.inquiry.gu.m implements Function2<p0, deobf.kotlin.eu.b<? super Unit>, Object> {

                public int f35389t;

                public final /* synthetic */ Function0<Unit> f35390u;

                /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                public b(Function0<Unit> function0, deobf.kotlin.eu.b<? super b> bVar) {
                    super(2, bVar);
                    this.f35390u = function0;
                }

                @Override // deobf.com.withpersona.sdk2.inquiry.gu.a
                public final deobf.kotlin.eu.b<Unit> create(Object obj, deobf.kotlin.eu.b<?> bVar) {
                    return new b(this.f35390u, bVar);
                }

                @Override // kotlin.jvm.functions.Function2
                public final Object invoke(p0 p0Var, deobf.kotlin.eu.b<? super Unit> bVar) {
                    return ((b) create(p0Var, bVar)).invokeSuspend(Unit.f21504a);
                }

                @Override // deobf.com.withpersona.sdk2.inquiry.gu.a
                public final Object invokeSuspend(Object obj) {
                    deobf.kotlin.fu.c.e();
                    if (this.f35389t != 0) {
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                    deobf.com.google.android.material.o.b(obj);
                    this.f35390u.invoke();
                    return Unit.f21504a;
                }
            }

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            public C0722a(a0 a0Var, j jVar, Function0<Unit> function0, deobf.kotlin.eu.b<? super C0722a> bVar) {
                super(2, bVar);
                this.f35385w = a0Var;
                this.f35386x = jVar;
                this.f35387y = function0;
            }

            @Override // deobf.com.withpersona.sdk2.inquiry.gu.a
            public final deobf.kotlin.eu.b<Unit> create(Object obj, deobf.kotlin.eu.b<?> bVar) {
                return new C0722a(this.f35385w, this.f35386x, this.f35387y, bVar);
            }

            @Override // kotlin.jvm.functions.Function2
            public final Object invoke(p0 p0Var, deobf.kotlin.eu.b<? super Unit> bVar) {
                return ((C0722a) create(p0Var, bVar)).invokeSuspend(Unit.f21504a);
            }

            /* JADX WARN: Code restructure failed: missing block: B:13:0x0078, code lost:

                if (deobf.com.withpersona.sdk2.inquiry.av.i.g(r8, r1, r7) == r0) goto L17;
             */
            /* JADX WARN: Code restructure failed: missing block: B:14:0x007a, code lost:

                return r0;
             */
            /* JADX WARN: Code restructure failed: missing block: B:18:0x0062, code lost:

                if (r8 == r0) goto L17;
             */
            @Override // deobf.com.withpersona.sdk2.inquiry.gu.a
            public final java.lang.Object invokeSuspend(java.lang.Object r8) {
                /*
                    r7 = this;
                    java.lang.Object r0 = deobf.kotlin.fu.c.e()
                    int r1 = r7.f35384v
                    r2 = 2
                    r3 = 0
                    r4 = 1
                    if (r1 == 0) goto L23
                    if (r1 == r4) goto L1b
                    if (r1 != r2) goto L13
                    deobf.com.withpersona.sdk2.inquiry.zt.o.b(r8)
                    goto L7b
                L13:
                    java.lang.IllegalStateException r8 = new java.lang.IllegalStateException
                    java.lang.String r0 = "call to 'resume' before 'invoke' with coroutine"
                    r8.<init>(r0)
                    throw r8
                L1b:
                    java.lang.Object r1 = r7.f35382t
                    deobf.unlinked.vr.j r1 = (deobf.unlinked.vr.j) r1
                    deobf.com.withpersona.sdk2.inquiry.zt.o.b(r8)
                    goto L65
                L23:
                    deobf.com.withpersona.sdk2.inquiry.zt.o.b(r8)
                    deobf.unlinked.vr.j r8 = r7.f35386x
                    r7.f35382t = r8
                    r1 = 0
                    r7.f35383u = r1
                    r7.f35384v = r4
                    deobf.com.withpersona.sdk2.inquiry.av.p r1 = new deobf.com.withpersona.sdk2.inquiry.av.p
                    deobf.kotlin.eu.b r5 = deobf.kotlin.fu.b.c(r7)
                    r1.<init>(r5, r4)
                    r1.G()
                    kotlin.jvm.internal.y r5 = new kotlin.jvm.internal.y
                    r5.<init>()
                    deobf.com.withpersona.sdk2.inquiry.ur.a r8 = deobf.unlinked.vr.j.j(r8)
                    android.widget.FrameLayout r8 = r8.getRoot()
                    java.lang.String r6 = "getRoot(...)"
                    kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r8, r6)
                    vr.j$a$a$a r6 = new vr.j$a$a$a
                    r6.<init>(r5, r1)
                    deobf.com.withpersona.sdk2.inquiry.kr.g.g(r8, r6)
                    java.lang.Object r8 = r1.y()
                    java.lang.Object r1 = deobf.kotlin.fu.c.e()
                    if (r8 != r1) goto L62
                    deobf.com.withpersona.sdk2.inquiry.gu.h.c(r7)
                L62:
                    if (r8 != r0) goto L65
                    goto L7a
                L65:
                    deobf.com.withpersona.sdk2.inquiry.av.n2 r8 = deobf.com.withpersona.sdk2.inquiry.av.g1.c()
                    vr.j$a$a$b r1 = new vr.j$a$a$b
                    kotlin.jvm.functions.Function0<kotlin.Unit> r5 = r7.f35387y
                    r1.<init>(r5, r3)
                    r7.f35382t = r3
                    r7.f35384v = r2
                    java.lang.Object r8 = deobf.com.withpersona.sdk2.inquiry.av.i.g(r8, r1, r7)
                    if (r8 != r0) goto L7b
                L7a:
                    return r0
                L7b:
                    deobf.com.withpersona.sdk2.inquiry.av.a0 r8 = r7.f35385w
                    deobf.com.withpersona.sdk2.inquiry.av.d2.a.a(r8, r3, r4, r3)
                    kotlin.Unit r8 = kotlin.Unit.f21504a
                    return r8
                */
                throw new UnsupportedOperationException("Method not decompiled: deobf.unlinked.vr.j.a.C0722a.invokeSuspend(java.lang.Object):java.lang.Object");
            }
        }

        @Metadata(d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0002\b\u0002\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\n¢\u0006\u0004\b\u0002\u0010\u0003"}, d2 = {"Lav/p0;", BuildConfig.FLAVOR, "<anonymous>", "(Lav/p0;)V"}, k = 3, mv = {2, 2, 0})
        @deobf.com.withpersona.sdk2.inquiry.gu.f(c = "com.withpersona.sdk2.inquiry.steps.ui.inputSelect.InputSelectBottomSheetController$runAfterKeyboardShown$1$2", f = "InputSelectBottomSheetController.kt", l = {213, 216}, m = "invokeSuspend")
        public static final class b extends deobf.com.withpersona.sdk2.inquiry.gu.m implements Function2<p0, deobf.kotlin.eu.b<? super Unit>, Object> {

            public int f35391t;

            public final /* synthetic */ j f35392u;

            public final /* synthetic */ a0 f35393v;

            public final /* synthetic */ Function0<Unit> f35394w;

            @Metadata(d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0002\b\u0002\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\n¢\u0006\u0004\b\u0002\u0010\u0003"}, d2 = {"Lav/p0;", BuildConfig.FLAVOR, "<anonymous>", "(Lav/p0;)V"}, k = 3, mv = {2, 2, 0})
            @deobf.com.withpersona.sdk2.inquiry.gu.f(c = "com.withpersona.sdk2.inquiry.steps.ui.inputSelect.InputSelectBottomSheetController$runAfterKeyboardShown$1$2$1", f = "InputSelectBottomSheetController.kt", l = {}, m = "invokeSuspend")
            public static final class C0724a extends deobf.com.withpersona.sdk2.inquiry.gu.m implements Function2<p0, deobf.kotlin.eu.b<? super Unit>, Object> {

                public int f35395t;

                public final /* synthetic */ Function0<Unit> f35396u;

                /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                public C0724a(Function0<Unit> function0, deobf.kotlin.eu.b<? super C0724a> bVar) {
                    super(2, bVar);
                    this.f35396u = function0;
                }

                @Override // deobf.com.withpersona.sdk2.inquiry.gu.a
                public final deobf.kotlin.eu.b<Unit> create(Object obj, deobf.kotlin.eu.b<?> bVar) {
                    return new C0724a(this.f35396u, bVar);
                }

                @Override // kotlin.jvm.functions.Function2
                public final Object invoke(p0 p0Var, deobf.kotlin.eu.b<? super Unit> bVar) {
                    return ((C0724a) create(p0Var, bVar)).invokeSuspend(Unit.f21504a);
                }

                @Override // deobf.com.withpersona.sdk2.inquiry.gu.a
                public final Object invokeSuspend(Object obj) {
                    deobf.kotlin.fu.c.e();
                    if (this.f35395t != 0) {
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                    deobf.com.google.android.material.o.b(obj);
                    this.f35396u.invoke();
                    return Unit.f21504a;
                }
            }

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            public b(j jVar, a0 a0Var, Function0<Unit> function0, deobf.kotlin.eu.b<? super b> bVar) {
                super(2, bVar);
                this.f35392u = jVar;
                this.f35393v = a0Var;
                this.f35394w = function0;
            }

            @Override // deobf.com.withpersona.sdk2.inquiry.gu.a
            public final deobf.kotlin.eu.b<Unit> create(Object obj, deobf.kotlin.eu.b<?> bVar) {
                return new b(this.f35392u, this.f35393v, this.f35394w, bVar);
            }

            @Override // kotlin.jvm.functions.Function2
            public final Object invoke(p0 p0Var, deobf.kotlin.eu.b<? super Unit> bVar) {
                return ((b) create(p0Var, bVar)).invokeSuspend(Unit.f21504a);
            }

            /* JADX WARN: Code restructure failed: missing block: B:18:0x0049, code lost:

                if (deobf.com.withpersona.sdk2.inquiry.av.i.g(r8, r1, r7) == r0) goto L21;
             */
            @Override // deobf.com.withpersona.sdk2.inquiry.gu.a
            public final java.lang.Object invokeSuspend(java.lang.Object r8) {
                /*
                    r7 = this;
                    java.lang.Object r0 = deobf.kotlin.fu.c.e()
                    int r1 = r7.f35391t
                    r2 = 2
                    r3 = 0
                    r4 = 1
                    if (r1 == 0) goto L1b
                    if (r1 == r4) goto L1b
                    if (r1 != r2) goto L13
                    deobf.com.withpersona.sdk2.inquiry.zt.o.b(r8)
                    goto L4c
                L13:
                    java.lang.IllegalStateException r8 = new java.lang.IllegalStateException
                    java.lang.String r0 = "call to 'resume' before 'invoke' with coroutine"
                    r8.<init>(r0)
                    throw r8
                L1b:
                    deobf.com.withpersona.sdk2.inquiry.zt.o.b(r8)
                L1e:
                    deobf.unlinked.vr.j r8 = r7.f35392u
                    deobf.com.withpersona.sdk2.inquiry.ur.a r8 = deobf.unlinked.vr.j.j(r8)
                    android.widget.FrameLayout r8 = r8.getRoot()
                    androidx.core.view.WindowInsetsCompat r8 = androidx.core.view.o0.F(r8)
                    if (r8 == 0) goto L54
                    int r1 = androidx.core.view.WindowInsetsCompat.Type.ime()
                    boolean r8 = r8.isVisible(r1)
                    if (r8 != r4) goto L54
                    deobf.com.withpersona.sdk2.inquiry.av.n2 r8 = deobf.com.withpersona.sdk2.inquiry.av.g1.c()
                    vr.j$a$b$a r1 = new vr.j$a$b$a
                    kotlin.jvm.functions.Function0<kotlin.Unit> r5 = r7.f35394w
                    r1.<init>(r5, r3)
                    r7.f35391t = r2
                    java.lang.Object r8 = deobf.com.withpersona.sdk2.inquiry.av.i.g(r8, r1, r7)
                    if (r8 != r0) goto L4c
                    goto L5e
                L4c:
                    deobf.com.withpersona.sdk2.inquiry.av.a0 r8 = r7.f35393v
                    deobf.com.withpersona.sdk2.inquiry.av.d2.a.a(r8, r3, r4, r3)
                    kotlin.Unit r8 = kotlin.Unit.f21504a
                    return r8
                L54:
                    r7.f35391t = r4
                    r5 = 100
                    java.lang.Object r8 = deobf.com.withpersona.sdk2.inquiry.av.z0.b(r5, r7)
                    if (r8 != r0) goto L1e
                L5e:
                    return r0
                */
                throw new UnsupportedOperationException("Method not decompiled: deobf.unlinked.vr.j.a.b.invokeSuspend(java.lang.Object):java.lang.Object");
            }
        }

        @Metadata(d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0002\b\u0002\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\n¢\u0006\u0004\b\u0002\u0010\u0003"}, d2 = {"Lav/p0;", BuildConfig.FLAVOR, "<anonymous>", "(Lav/p0;)V"}, k = 3, mv = {2, 2, 0})
        @deobf.com.withpersona.sdk2.inquiry.gu.f(c = "com.withpersona.sdk2.inquiry.steps.ui.inputSelect.InputSelectBottomSheetController$runAfterKeyboardShown$1$3", f = "InputSelectBottomSheetController.kt", l = {223, 224}, m = "invokeSuspend")
        public static final class c extends deobf.com.withpersona.sdk2.inquiry.gu.m implements Function2<p0, deobf.kotlin.eu.b<? super Unit>, Object> {

            public int f35397t;

            public final /* synthetic */ a0 f35398u;

            public final /* synthetic */ Function0<Unit> f35399v;

            @Metadata(d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0002\b\u0002\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\n¢\u0006\u0004\b\u0002\u0010\u0003"}, d2 = {"Lav/p0;", BuildConfig.FLAVOR, "<anonymous>", "(Lav/p0;)V"}, k = 3, mv = {2, 2, 0})
            @deobf.com.withpersona.sdk2.inquiry.gu.f(c = "com.withpersona.sdk2.inquiry.steps.ui.inputSelect.InputSelectBottomSheetController$runAfterKeyboardShown$1$3$1", f = "InputSelectBottomSheetController.kt", l = {}, m = "invokeSuspend")
            public static final class C0725a extends deobf.com.withpersona.sdk2.inquiry.gu.m implements Function2<p0, deobf.kotlin.eu.b<? super Unit>, Object> {

                public int f35400t;

                public final /* synthetic */ Function0<Unit> f35401u;

                /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                public C0725a(Function0<Unit> function0, deobf.kotlin.eu.b<? super C0725a> bVar) {
                    super(2, bVar);
                    this.f35401u = function0;
                }

                @Override // deobf.com.withpersona.sdk2.inquiry.gu.a
                public final deobf.kotlin.eu.b<Unit> create(Object obj, deobf.kotlin.eu.b<?> bVar) {
                    return new C0725a(this.f35401u, bVar);
                }

                @Override // kotlin.jvm.functions.Function2
                public final Object invoke(p0 p0Var, deobf.kotlin.eu.b<? super Unit> bVar) {
                    return ((C0725a) create(p0Var, bVar)).invokeSuspend(Unit.f21504a);
                }

                @Override // deobf.com.withpersona.sdk2.inquiry.gu.a
                public final Object invokeSuspend(Object obj) {
                    deobf.kotlin.fu.c.e();
                    if (this.f35400t != 0) {
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                    deobf.com.google.android.material.o.b(obj);
                    this.f35401u.invoke();
                    return Unit.f21504a;
                }
            }

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            public c(a0 a0Var, Function0<Unit> function0, deobf.kotlin.eu.b<? super c> bVar) {
                super(2, bVar);
                this.f35398u = a0Var;
                this.f35399v = function0;
            }

            @Override // deobf.com.withpersona.sdk2.inquiry.gu.a
            public final deobf.kotlin.eu.b<Unit> create(Object obj, deobf.kotlin.eu.b<?> bVar) {
                return new c(this.f35398u, this.f35399v, bVar);
            }

            @Override // kotlin.jvm.functions.Function2
            public final Object invoke(p0 p0Var, deobf.kotlin.eu.b<? super Unit> bVar) {
                return ((c) create(p0Var, bVar)).invokeSuspend(Unit.f21504a);
            }

            /* JADX WARN: Code restructure failed: missing block: B:13:0x003e, code lost:

                if (deobf.com.withpersona.sdk2.inquiry.av.i.g(r8, r1, r7) == r0) goto L15;
             */
            /* JADX WARN: Code restructure failed: missing block: B:14:0x0040, code lost:

                return r0;
             */
            /* JADX WARN: Code restructure failed: missing block: B:16:0x002a, code lost:

                if (deobf.com.withpersona.sdk2.inquiry.av.z0.b(1000, r7) == r0) goto L15;
             */
            @Override // deobf.com.withpersona.sdk2.inquiry.gu.a
            public final java.lang.Object invokeSuspend(java.lang.Object r8) {
                /*
                    r7 = this;
                    java.lang.Object r0 = deobf.kotlin.fu.c.e()
                    int r1 = r7.f35397t
                    r2 = 2
                    r3 = 0
                    r4 = 1
                    if (r1 == 0) goto L1f
                    if (r1 == r4) goto L1b
                    if (r1 != r2) goto L13
                    deobf.com.withpersona.sdk2.inquiry.zt.o.b(r8)
                    goto L41
                L13:
                    java.lang.IllegalStateException r8 = new java.lang.IllegalStateException
                    java.lang.String r0 = "call to 'resume' before 'invoke' with coroutine"
                    r8.<init>(r0)
                    throw r8
                L1b:
                    deobf.com.withpersona.sdk2.inquiry.zt.o.b(r8)
                    goto L2d
                L1f:
                    deobf.com.withpersona.sdk2.inquiry.zt.o.b(r8)
                    r7.f35397t = r4
                    r5 = 1000(0x3e8, double:4.94E-321)
                    java.lang.Object r8 = deobf.com.withpersona.sdk2.inquiry.av.z0.b(r5, r7)
                    if (r8 != r0) goto L2d
                    goto L40
                L2d:
                    deobf.com.withpersona.sdk2.inquiry.av.n2 r8 = deobf.com.withpersona.sdk2.inquiry.av.g1.c()
                    vr.j$a$c$a r1 = new vr.j$a$c$a
                    kotlin.jvm.functions.Function0<kotlin.Unit> r5 = r7.f35399v
                    r1.<init>(r5, r3)
                    r7.f35397t = r2
                    java.lang.Object r8 = deobf.com.withpersona.sdk2.inquiry.av.i.g(r8, r1, r7)
                    if (r8 != r0) goto L41
                L40:
                    return r0
                L41:
                    deobf.com.withpersona.sdk2.inquiry.av.a0 r8 = r7.f35398u
                    deobf.com.withpersona.sdk2.inquiry.av.d2.a.a(r8, r3, r4, r3)
                    kotlin.Unit r8 = kotlin.Unit.f21504a
                    return r8
                */
                throw new UnsupportedOperationException("Method not decompiled: deobf.unlinked.vr.j.a.c.invokeSuspend(java.lang.Object):java.lang.Object");
            }
        }

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public a(Function0<Unit> function0, deobf.kotlin.eu.b<? super a> bVar) {
            super(2, bVar);
            this.f35381w = function0;
        }

        @Override // deobf.com.withpersona.sdk2.inquiry.gu.a
        public final deobf.kotlin.eu.b<Unit> create(Object obj, deobf.kotlin.eu.b<?> bVar) {
            a aVar = j.this.new a(this.f35381w, bVar);
            aVar.f35379u = obj;
            return aVar;
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(p0 p0Var, deobf.kotlin.eu.b<? super Unit> bVar) {
            return ((a) create(p0Var, bVar)).invokeSuspend(Unit.f21504a);
        }

        @Override // deobf.com.withpersona.sdk2.inquiry.gu.a
        public final Object invokeSuspend(Object obj) {
            p0 p0Var = (p0) this.f35379u;
            deobf.kotlin.fu.c.e();
            if (this.f35378t != 0) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            deobf.com.google.android.material.o.b(obj);
            a0 b10 = z2.b(null, 1, null);
            deobf.com.withpersona.sdk2.inquiry.av.k.d(p0Var, b10, null, new C0722a(b10, j.this, this.f35381w, null), 2, null);
            deobf.com.withpersona.sdk2.inquiry.av.k.d(p0Var, b10, null, new b(j.this, b10, this.f35381w, null), 2, null);
            deobf.com.withpersona.sdk2.inquiry.av.k.d(p0Var, b10, null, new c(b10, this.f35381w, null), 2, null);
            return Unit.f21504a;
        }
    }

    @Metadata(d1 = {"\u0000%\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0010\u0007\n\u0002\b\u0004*\u0001\u0000\b\n\u0018\u00002\u00020\u0001J\u001f\u0010\u0007\u001a\u00020\u00062\u0006\u0010\u0003\u001a\u00020\u00022\u0006\u0010\u0005\u001a\u00020\u0004H\u0016¢\u0006\u0004\b\u0007\u0010\bJ\u001f\u0010\u000b\u001a\u00020\u00062\u0006\u0010\u0003\u001a\u00020\u00022\u0006\u0010\n\u001a\u00020\tH\u0016¢\u0006\u0004\b\u000b\u0010\f¨\u0006\r"}, d2 = {"vr/j$b", "Lcom/google/android/material/bottomsheet/BottomSheetBehavior$g;", "Landroid/view/View;", "bottomSheet", BuildConfig.FLAVOR, "newState", BuildConfig.FLAVOR, "c", "(Landroid/view/View;I)V", BuildConfig.FLAVOR, "slideOffset", deobf.android.view.k6.b.f21144e, "(Landroid/view/View;F)V", "ui-step-renderer_release"}, k = 1, mv = {2, 2, 0}, xi = 48)
    public static final class b extends BottomSheetBehavior.g {
        public b() {
        }

        @Override // com.google.android.material.bottomsheet.BottomSheetBehavior.g
        public void b(View bottomSheet, float slideOffset) {
            Intrinsics.checkNotNullParameter(bottomSheet, "bottomSheet");
        }

        @Override // com.google.android.material.bottomsheet.BottomSheetBehavior.g
        public void c(View bottomSheet, int newState) {
            Intrinsics.checkNotNullParameter(bottomSheet, "bottomSheet");
            Function1 function1 = j.this.bottomSheetStateChangeListener;
            if (function1 != null) {
                function1.invoke(Integer.valueOf(newState));
            }
        }
    }

    @Metadata(d1 = {"\u0000'\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\r\n\u0000\n\u0002\u0010\b\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0003*\u0001\u0000\b\n\u0018\u00002\u00020\u0001J1\u0010\t\u001a\u00020\b2\b\u0010\u0003\u001a\u0004\u0018\u00010\u00022\u0006\u0010\u0005\u001a\u00020\u00042\u0006\u0010\u0006\u001a\u00020\u00042\u0006\u0010\u0007\u001a\u00020\u0004H\u0016¢\u0006\u0004\b\t\u0010\nJ1\u0010\f\u001a\u00020\b2\b\u0010\u0003\u001a\u0004\u0018\u00010\u00022\u0006\u0010\u0005\u001a\u00020\u00042\u0006\u0010\u000b\u001a\u00020\u00042\u0006\u0010\u0006\u001a\u00020\u0004H\u0016¢\u0006\u0004\b\f\u0010\nJ\u0019\u0010\u000e\u001a\u00020\b2\b\u0010\u0003\u001a\u0004\u0018\u00010\rH\u0016¢\u0006\u0004\b\u000e\u0010\u000f¨\u0006\u0010"}, d2 = {"vr/j$c", "Landroid/text/TextWatcher;", BuildConfig.FLAVOR, "s", BuildConfig.FLAVOR, "start", "count", "after", BuildConfig.FLAVOR, "beforeTextChanged", "(Ljava/lang/CharSequence;III)V", "before", "onTextChanged", "Landroid/text/Editable;", "afterTextChanged", "(Landroid/text/Editable;)V", "ui-step-renderer_release"}, k = 1, mv = {2, 2, 0}, xi = 48)
    public static final class c implements TextWatcher {

        public final /* synthetic */ m f35403a;

        public c(m mVar) {
            this.f35403a = mVar;
        }

        @Override // android.text.TextWatcher
        public void afterTextChanged(Editable s8) {
            this.f35403a.J(String.valueOf(s8));
        }

        @Override // android.text.TextWatcher
        public void beforeTextChanged(CharSequence s8, int start, int count, int after) {
        }

        @Override // android.text.TextWatcher
        public void onTextChanged(CharSequence s8, int start, int before, int count) {
        }
    }

    public j(@NotNull ViewGroup contentView) {
        Intrinsics.checkNotNullParameter(contentView, "contentView");
        this.contentView = contentView;
        this.lazyBinding = deobf.com.withpersona.sdk2.inquiry.zt.i.a(new Function0() { // from class: vr.a
            @Override // kotlin.jvm.functions.Function0
            public final Object invoke() {
                deobf.com.withpersona.sdk2.inquiry.ur.a o10;
                o10 = deobf.com.google.android.material.j.o(j.this);
                return o10;
            }
        });
    }

    public static final void m(BottomSheetBehavior bottomSheetBehavior) {
        bottomSheetBehavior.X0(5);
    }

    public static final deobf.com.withpersona.sdk2.inquiry.ur.a o(j jVar) {
        return deobf.com.withpersona.sdk2.inquiry.ur.a.c(LayoutInflater.from(jVar.contentView.getContext()), jVar.contentView, true);
    }

    public static final Unit s() {
        return Unit.f21504a;
    }

    public static final Unit u(i2 i2Var, c0 c0Var, j jVar, Option selectedItem) {
        Intrinsics.checkNotNullParameter(selectedItem, "selectedItem");
        if (!i2Var.getCanSelectMultipleValues()) {
            Function1 function1 = (Function1) c0Var.f21573a;
            if (function1 != null) {
                function1.invoke(kotlin.collections.o.d(selectedItem));
            }
            c0Var.f21573a = null;
            jVar.l();
        }
        return Unit.f21504a;
    }

    public static final void v(boolean z10, j jVar, final BottomSheetBehavior bottomSheetBehavior) {
        if (z10) {
            jVar.p(new Function0() { // from class: vr.i
                @Override // kotlin.jvm.functions.Function0
                public final Object invoke() {
                    Unit w5;
                    w5 = j.w(BottomSheetBehavior.this);
                    return w5;
                }
            });
        } else {
            bottomSheetBehavior.X0(3);
        }
    }

    public static final Unit w(BottomSheetBehavior bottomSheetBehavior) {
        bottomSheetBehavior.X0(3);
        return Unit.f21504a;
    }

    public static final Unit x(c0 c0Var, m mVar, j jVar, int i10) {
        if (i10 == 5) {
            Function1 function1 = (Function1) c0Var.f21573a;
            if (function1 != null) {
                function1.invoke(CollectionsKt.M0(mVar.F()));
            }
            c0Var.f21573a = null;
            Context context = jVar.contentView.getContext();
            Intrinsics.checkNotNullExpressionValue(context, "getContext(...)");
            deobf.com.withpersona.sdk2.inquiry.xq.g.d(context);
        }
        return Unit.f21504a;
    }

    public static final void y(BottomSheetBehavior bottomSheetBehavior, View view) {
        bottomSheetBehavior.X0(5);
    }

    public static final void z(j jVar, View view) {
        jVar.l();
    }

    public final boolean l() {
        if (!this.lazyBinding.isInitialized()) {
            return false;
        }
        final BottomSheetBehavior q02 = BottomSheetBehavior.q0(n().b);
        Intrinsics.checkNotNullExpressionValue(q02, "from(...)");
        Context context = this.contentView.getContext();
        Intrinsics.checkNotNullExpressionValue(context, "getContext(...)");
        deobf.com.withpersona.sdk2.inquiry.xq.g.d(context);
        this.contentView.postDelayed(new Runnable() { // from class: vr.b
            @Override // java.lang.Runnable
            public final void run() {
                deobf.com.google.android.material.j.m(BottomSheetBehavior.this);
            }
        }, 100L);
        return q02.v0() != 5;
    }

    public final deobf.com.withpersona.sdk2.inquiry.ur.a n() {
        return this.lazyBinding.getValue();
    }

    public final void p(Function0<Unit> callback) {
        Context context = this.contentView.getContext();
        Intrinsics.checkNotNull(context);
        deobf.com.google.android.material.j.b a10 = deobf.com.withpersona.sdk2.inquiry.xq.g.a(context);
        if (a10 == null) {
            return;
        }
        deobf.com.withpersona.sdk2.inquiry.av.k.d(android.view.t.a(a10), null, null, new a(callback, null), 3, null);
    }

    public final void q(boolean visible, boolean hasTitle) {
        if (visible) {
            n().f33849j.setVisibility(8);
            n().f33847h.setVisibility(0);
            n().f33846g.requestFocus();
            Context context = n().f33846g.getContext();
            Intrinsics.checkNotNullExpressionValue(context, "getContext(...)");
            deobf.com.withpersona.sdk2.inquiry.xq.g.j(context);
            return;
        }
        Context context2 = n().f33846g.getContext();
        Intrinsics.checkNotNullExpressionValue(context2, "getContext(...)");
        deobf.com.withpersona.sdk2.inquiry.xq.g.d(context2);
        n().f33847h.setVisibility(8);
        n().f33849j.setVisibility(0);
        n().f33846g.setText(BuildConfig.FLAVOR);
    }

    public final void r() {
        if (this.setup) {
            return;
        }
        this.setup = true;
        BottomSheetBehavior q02 = BottomSheetBehavior.q0(n().b);
        Intrinsics.checkNotNullExpressionValue(q02, "from(...)");
        q02.Z0(true);
        Function0 function0 = new Function0() { // from class: vr.h
            @Override // kotlin.jvm.functions.Function0
            public final Object invoke() {
                Unit s8;
                s8 = deobf.com.google.android.material.j.s();
                return s8;
            }
        };
        FrameLayout bottomSheet = n().b;
        Intrinsics.checkNotNullExpressionValue(bottomSheet, "bottomSheet");
        deobf.com.withpersona.sdk2.inquiry.kr.b.b(q02, function0, bottomSheet, n().f33842c, n().f33848i);
        q02.c0(new b());
    }

    /* JADX WARN: Multi-variable type inference failed */
    public final void t(@NotNull final i2 component, @NotNull Function1<? super List<Option>, Unit> onItemsSelectedListener) {
        Intrinsics.checkNotNullParameter(component, "component");
        Intrinsics.checkNotNullParameter(onItemsSelectedListener, "onItemsSelectedListener");
        r();
        final c0 c0Var = new c0();
        c0Var.f21573a = onItemsSelectedListener;
        String label = component.getLabel();
        final boolean z10 = label == null || StringsKt.p0(label);
        final BottomSheetBehavior q02 = BottomSheetBehavior.q0(n().b);
        Intrinsics.checkNotNullExpressionValue(q02, "from(...)");
        Context context = n().f33845f.getContext();
        Intrinsics.checkNotNullExpressionValue(context, "getContext(...)");
        final m mVar = new m(context, component.g(), component.getF35955a(), component.getCanSelectMultipleValues(), component.getLeadingImageTemplate(), component.l(), new Function1() { // from class: vr.c
            @Override // kotlin.jvm.functions.Function1
            public final Object invoke(Object obj) {
                Unit u8;
                u8 = j.u(i2.this, c0Var, this, (Option) obj);
                return u8;
            }
        });
        this.bottomSheetStateChangeListener = new Function1() { // from class: vr.d
            @Override // kotlin.jvm.functions.Function1
            public final Object invoke(Object obj) {
                Unit x5;
                x5 = j.x(c0.this, mVar, this, ((Integer) obj).intValue());
                return x5;
            }
        };
        q(z10, !z10);
        n().f33849j.setText(component.getLabel());
        n().f33845f.setAdapter(mVar);
        n().f33848i.setOnClickListener(new View.OnClickListener() { // from class: vr.e
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                j.y(BottomSheetBehavior.this, view);
            }
        });
        InputSelectBoxComponentStyle f35955a = component.getF35955a();
        if (f35955a != null) {
            TextView textviewInputSelectSheetTitle = n().f33849j;
            Intrinsics.checkNotNullExpressionValue(textviewInputSelectSheetTitle, "textviewInputSelectSheetTitle");
            h0.l(textviewInputSelectSheetTitle, f35955a.getTextBasedStyle(), null, 2, null);
            Integer baseBackgroundColorValue = f35955a.getBaseBackgroundColorValue();
            if (baseBackgroundColorValue != null) {
                int intValue = baseBackgroundColorValue.intValue();
                n().f33842c.setBackgroundColor(intValue);
                n().f33845f.setBackgroundColor(intValue);
            }
            Integer baseBorderColorValue = f35955a.getBaseBorderColorValue();
            if (baseBorderColorValue != null) {
                n().f33843d.setBackgroundColor(baseBorderColorValue.intValue());
            }
            Integer headerCancelButtonColor = f35955a.getHeaderCancelButtonColor();
            if (headerCancelButtonColor != null) {
                int intValue2 = headerCancelButtonColor.intValue();
                n().f33844e.setImageTintList(ColorStateList.valueOf(intValue2));
                n().f33847h.setEndIconTintList(ColorStateList.valueOf(intValue2));
            }
            Integer baseTextColor = f35955a.getBaseTextColor();
            if (baseTextColor != null) {
                int intValue3 = baseTextColor.intValue();
                ColorStateList valueOf = ColorStateList.valueOf(androidx.core.graphics.c.l(intValue3, Barcode.FORMAT_ITF));
                Intrinsics.checkNotNullExpressionValue(valueOf, "valueOf(...)");
                n().f33846g.setHintTextColor(valueOf);
                n().f33846g.setTextColor(intValue3);
            }
        }
        n().f33845f.setLayoutManager(new LinearLayoutManager(n().getRoot().getContext()));
        n().f33845f.setHasFixedSize(true);
        n().f33846g.addTextChangedListener(new c(mVar));
        n().f33844e.setOnClickListener(new View.OnClickListener() { // from class: vr.f
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                j.z(j.this, view);
            }
        });
        n().f33846g.setText(BuildConfig.FLAVOR);
        n().b.setTranslationY(0.0f);
        this.contentView.postDelayed(new Runnable() { // from class: vr.g
            @Override // java.lang.Runnable
            public final void run() {
                j.v(z10, this, q02);
            }
        }, 100L);
    }
}
