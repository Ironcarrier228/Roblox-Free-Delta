package deobf.unlinked.bb;

import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;

// dex: classes.dex
public class a implements IInterface {

    public final IBinder f3846a;
    public final String b;

    public a(IBinder iBinder, String str) {
        this.f3846a = iBinder;
        this.b = str;
    }

    @Override // android.os.IInterface
    public IBinder asBinder() {
        return this.f3846a;
    }

    public Parcel r2() {
        Parcel obtain = Parcel.obtain();
        obtain.writeInterfaceToken(this.b);
        return obtain;
    }

    public void s2(int i10, Parcel parcel) {
        Parcel obtain = Parcel.obtain();
        try {
            this.f3846a.transact(i10, parcel, obtain, 0);
            obtain.readException();
        } finally {
            parcel.recycle();
            obtain.recycle();
        }
    }
}
