package deobf.unlinked.bb;

import com.google.android.gms.common.api.Status;

// dex: classes.dex
public final class w extends f {

    public final /* synthetic */ deobf.com.google.mlkit.common.tb.k f3867a;

    public w(b bVar, deobf.com.google.mlkit.common.tb.k kVar) {
        this.f3867a = kVar;
    }

    @Override // deobf.unlinked.bb.n
    public final void z(Status status, deobf.com.withpersona.sdk2.inquiry.f9.e eVar) {
        deobf.com.google.android.gms.m9.v.a(status, eVar, this.f3867a);
    }
}
