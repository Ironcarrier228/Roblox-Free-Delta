package deobf.unlinked.bb;

import com.google.android.gms.common.api.Status;

// dex: classes.dex
public final class v extends o {

    public final /* synthetic */ deobf.com.google.mlkit.common.tb.k f3866a;

    public v(b bVar, deobf.com.google.mlkit.common.tb.k kVar) {
        this.f3866a = kVar;
    }

    @Override // deobf.unlinked.bb.p
    public final void x(Status status, int i10) {
        deobf.com.google.android.gms.m9.v.a(status, Integer.valueOf(i10), this.f3866a);
    }
}
