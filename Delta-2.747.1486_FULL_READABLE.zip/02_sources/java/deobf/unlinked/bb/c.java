package deobf.unlinked.bb;

// dex: classes.dex
public final class c {

    public static final deobf.com.google.mlkit.vision.k9.d f3850a;
    public static final deobf.com.google.mlkit.vision.k9.d b;

    public static final deobf.com.google.mlkit.vision.k9.d f3851c;

    public static final deobf.com.google.mlkit.vision.k9.d f3852d;

    public static final deobf.com.google.mlkit.vision.k9.d f3853e;

    public static final deobf.com.google.mlkit.vision.k9.d f3854f;

    public static final deobf.com.google.mlkit.vision.k9.d f3855g;

    public static final deobf.com.google.mlkit.vision.k9.d f3856h;

    public static final deobf.com.google.mlkit.vision.k9.d f3857i;

    public static final deobf.com.google.mlkit.vision.k9.d f3858j;

    public static final deobf.com.google.mlkit.vision.k9.d f3859k;

    public static final deobf.com.google.mlkit.vision.k9.d[] f3860l;

    static {
        deobf.com.google.mlkit.vision.k9.d dVar = new deobf.com.google.mlkit.vision.k9.d("auth_blockstore", 3L);
        f3850a = dVar;
        deobf.com.google.mlkit.vision.k9.d dVar2 = new deobf.com.google.mlkit.vision.k9.d("blockstore_data_transfer", 1L);
        b = dVar2;
        deobf.com.google.mlkit.vision.k9.d dVar3 = new deobf.com.google.mlkit.vision.k9.d("blockstore_notify_app_restore", 1L);
        f3851c = dVar3;
        deobf.com.google.mlkit.vision.k9.d dVar4 = new deobf.com.google.mlkit.vision.k9.d("blockstore_store_bytes_with_options", 2L);
        f3852d = dVar4;
        deobf.com.google.mlkit.vision.k9.d dVar5 = new deobf.com.google.mlkit.vision.k9.d("blockstore_is_end_to_end_encryption_available", 1L);
        f3853e = dVar5;
        deobf.com.google.mlkit.vision.k9.d dVar6 = new deobf.com.google.mlkit.vision.k9.d("blockstore_enable_cloud_backup", 1L);
        f3854f = dVar6;
        deobf.com.google.mlkit.vision.k9.d dVar7 = new deobf.com.google.mlkit.vision.k9.d("blockstore_delete_bytes", 2L);
        f3855g = dVar7;
        deobf.com.google.mlkit.vision.k9.d dVar8 = new deobf.com.google.mlkit.vision.k9.d("blockstore_retrieve_bytes_with_options", 3L);
        f3856h = dVar8;
        deobf.com.google.mlkit.vision.k9.d dVar9 = new deobf.com.google.mlkit.vision.k9.d("auth_clear_restore_credential", 1L);
        f3857i = dVar9;
        deobf.com.google.mlkit.vision.k9.d dVar10 = new deobf.com.google.mlkit.vision.k9.d("auth_create_restore_credential", 1L);
        f3858j = dVar10;
        deobf.com.google.mlkit.vision.k9.d dVar11 = new deobf.com.google.mlkit.vision.k9.d("auth_get_restore_credential", 1L);
        f3859k = dVar11;
        f3860l = new deobf.com.google.mlkit.vision.k9.d[]{dVar, dVar2, dVar3, dVar4, dVar5, dVar6, dVar7, dVar8, dVar9, dVar10, dVar11};
    }
}
