package deobf.unlinked.bb;

import android.content.Context;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Looper;
import androidx.annotation.NonNull;

// dex: classes.dex
public final class g extends deobf.com.google.android.gms.o9.i {
    public g(Context context, Looper looper, deobf.com.google.android.gms.o9.f fVar, deobf.com.google.android.gms.m9.e eVar, deobf.com.google.android.gms.m9.n nVar) {
        super(context, looper, 258, fVar, eVar, nVar);
    }

    @Override // deobf.com.google.android.gms.o9.d
    public final /* synthetic */ IInterface createServiceInterface(IBinder iBinder) {
        if (iBinder == null) {
            return null;
        }
        IInterface queryLocalInterface = iBinder.queryLocalInterface("com.google.android.gms.auth.blockstore.internal.IBlockstoreService");
        return queryLocalInterface instanceof h ? (h) queryLocalInterface : new h(iBinder);
    }

    @Override // deobf.com.google.android.gms.o9.d
    public final deobf.com.google.mlkit.vision.k9.d[] getApiFeatures() {
        return c.f3860l;
    }

    @Override // deobf.com.google.android.gms.o9.d, deobf.com.google.android.gms.l9.a.f
    public final int getMinApkVersion() {
        return 17895000;
    }

    @Override // deobf.com.google.android.gms.o9.d
    @NonNull
    public final String getServiceDescriptor() {
        return "com.google.android.gms.auth.blockstore.internal.IBlockstoreService";
    }

    @Override // deobf.com.google.android.gms.o9.d
    @NonNull
    public final String getStartServiceAction() {
        return "com.google.android.gms.auth.blockstore.service.START";
    }

    @Override // deobf.com.google.android.gms.o9.d
    public final boolean getUseDynamicLookup() {
        return true;
    }

    @Override // deobf.com.google.android.gms.o9.d
    public final boolean usesClientTelemetry() {
        return true;
    }
}
