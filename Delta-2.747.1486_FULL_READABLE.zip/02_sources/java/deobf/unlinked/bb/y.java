package deobf.unlinked.bb;

import com.google.android.gms.common.api.Status;

// dex: classes.dex
public final class y extends k {

    public final /* synthetic */ deobf.com.google.mlkit.common.tb.k f3869a;

    public y(b bVar, deobf.com.google.mlkit.common.tb.k kVar) {
        this.f3869a = kVar;
    }

    @Override // deobf.unlinked.bb.l
    public final void h(Status status, boolean z10) {
        deobf.com.google.android.gms.m9.v.a(status, Boolean.valueOf(z10), this.f3869a);
    }
}
