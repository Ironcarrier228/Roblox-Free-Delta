package deobf.unlinked.bb;

import android.os.Parcel;
import com.google.android.gms.common.api.Status;

// dex: classes.dex
public abstract class m extends d implements n {
    public m() {
        super("com.google.android.gms.auth.blockstore.internal.IRetrieveBytesCallback");
    }

    @Override // deobf.unlinked.bb.d
    public final boolean r2(int i10, Parcel parcel, Parcel parcel2, int i11) {
        if (i10 == 1) {
            Status status = (Status) deobf.com.roblox.client.e.a(parcel, Status.CREATOR);
            byte[] createByteArray = parcel.createByteArray();
            s2(parcel);
            u0(status, createByteArray);
        } else {
            if (i10 != 2) {
                return false;
            }
            Status status2 = (Status) deobf.com.roblox.client.e.a(parcel, Status.CREATOR);
            deobf.com.withpersona.sdk2.inquiry.f9.e eVar = (deobf.com.withpersona.sdk2.inquiry.f9.e) deobf.com.roblox.client.e.a(parcel, deobf.com.withpersona.sdk2.inquiry.f9.e.CREATOR);
            s2(parcel);
            z(status2, eVar);
        }
        return true;
    }
}
