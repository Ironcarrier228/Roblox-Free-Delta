package deobf.unlinked.bb;

import android.os.IInterface;
import com.google.android.gms.common.api.Status;

// dex: classes.dex
public interface j extends IInterface {
    void h(Status status, boolean z10);
}
