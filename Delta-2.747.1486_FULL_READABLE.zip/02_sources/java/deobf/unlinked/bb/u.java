package deobf.unlinked.bb;

import android.content.Context;
import android.os.Looper;
import deobf.com.google.android.gms.l9.a;

// dex: classes.dex
public final class u extends a.AbstractC0421a {
    @Override // deobf.com.google.android.gms.l9.a.AbstractC0421a
    public final /* synthetic */ a.f b(Context context, Looper looper, deobf.com.google.android.gms.o9.f fVar, Object obj, deobf.com.google.android.gms.m9.e eVar, deobf.com.google.android.gms.m9.n nVar) {
        return new g(context, looper, fVar, eVar, nVar);
    }
}
