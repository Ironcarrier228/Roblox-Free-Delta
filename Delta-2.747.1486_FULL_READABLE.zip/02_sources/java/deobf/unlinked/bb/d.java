package deobf.unlinked.bb;

import android.os.BadParcelableException;
import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;

// dex: classes.dex
public class d extends Binder implements IInterface {
    public d(String str) {
        attachInterface(this, str);
    }

    @Override // android.os.IInterface
    public IBinder asBinder() {
        return this;
    }

    @Override // android.os.Binder
    public boolean onTransact(int i10, Parcel parcel, Parcel parcel2, int i11) {
        if (t2(i10, parcel, parcel2, i11)) {
            return true;
        }
        return r2(i10, parcel, parcel2, i11);
    }

    public boolean r2(int i10, Parcel parcel, Parcel parcel2, int i11) {
        throw null;
    }

    public void s2(Parcel parcel) {
        int i10 = e.f3861a;
        int dataAvail = parcel.dataAvail();
        if (dataAvail <= 0) {
            return;
        }
        throw new BadParcelableException("Parcel data not fully consumed, unread size: " + dataAvail);
    }

    public final boolean t2(int i10, Parcel parcel, Parcel parcel2, int i11) {
        if (i10 > 16777215) {
            return super.onTransact(i10, parcel, parcel2, i11);
        }
        parcel.enforceInterface(getInterfaceDescriptor());
        return false;
    }
}
