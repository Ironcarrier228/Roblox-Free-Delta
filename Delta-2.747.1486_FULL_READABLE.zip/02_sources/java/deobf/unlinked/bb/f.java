package deobf.unlinked.bb;

import com.google.android.gms.common.api.Status;

// dex: classes.dex
public class f extends m {
    @Override // deobf.unlinked.bb.n
    public void u0(Status status, byte[] bArr) {
        throw new UnsupportedOperationException();
    }
}
