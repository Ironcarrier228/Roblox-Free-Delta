package deobf.unlinked.bb;

import com.google.android.gms.common.api.Status;

// dex: classes.dex
public final class x extends i {

    public final /* synthetic */ deobf.com.google.mlkit.common.tb.k f3868a;

    public x(b bVar, deobf.com.google.mlkit.common.tb.k kVar) {
        this.f3868a = kVar;
    }

    @Override // deobf.unlinked.bb.j
    public final void h(Status status, boolean z10) {
        deobf.com.google.android.gms.m9.v.a(status, Boolean.valueOf(z10), this.f3868a);
    }
}
