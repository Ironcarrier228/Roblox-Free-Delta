package deobf.unlinked.bb;

import android.os.IInterface;
import android.os.Parcel;
import android.os.Parcelable;

// dex: classes.dex
public final class e {

    public static final /* synthetic */ int f3861a = 0;

    static {
        e.class.getClassLoader();
    }

    public static Parcelable a(Parcel parcel, Parcelable.Creator creator) {
        if (parcel.readInt() == 0) {
            return null;
        }
        return (Parcelable) creator.createFromParcel(parcel);
    }

    public static void b(Parcel parcel, Parcelable parcelable) {
        if (parcelable == null) {
            parcel.writeInt(0);
        } else {
            parcel.writeInt(1);
            parcelable.writeToParcel(parcel, 0);
        }
    }

    public static void c(Parcel parcel, IInterface iInterface) {
        parcel.writeStrongBinder(iInterface.asBinder());
    }

    public static boolean d(Parcel parcel) {
        return parcel.readInt() != 0;
    }
}
