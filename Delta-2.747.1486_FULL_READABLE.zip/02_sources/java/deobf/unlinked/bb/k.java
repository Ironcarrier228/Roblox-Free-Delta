package deobf.unlinked.bb;

import android.os.Parcel;
import com.google.android.gms.common.api.Status;

// dex: classes.dex
public abstract class k extends d implements l {
    public k() {
        super("com.google.android.gms.auth.blockstore.internal.IIsEndToEndEncryptionAvailableCallback");
    }

    @Override // deobf.unlinked.bb.d
    public final boolean r2(int i10, Parcel parcel, Parcel parcel2, int i11) {
        if (i10 != 1) {
            return false;
        }
        Status status = (Status) deobf.com.roblox.client.e.a(parcel, Status.CREATOR);
        boolean d10 = e.d(parcel);
        s2(parcel);
        h(status, d10);
        return true;
    }
}
