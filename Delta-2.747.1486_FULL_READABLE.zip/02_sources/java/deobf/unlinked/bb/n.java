package deobf.unlinked.bb;

import android.os.IInterface;
import com.google.android.gms.common.api.Status;

// dex: classes.dex
public interface n extends IInterface {
    void u0(Status status, byte[] bArr);

    void z(Status status, deobf.com.withpersona.sdk2.inquiry.f9.e eVar);
}
