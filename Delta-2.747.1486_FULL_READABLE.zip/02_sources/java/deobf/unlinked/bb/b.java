package deobf.unlinked.bb;

import android.content.Context;
import androidx.annotation.NonNull;
import com.google.android.gms.tasks.Task;
import deobf.com.google.android.gms.l9.a;
import deobf.com.google.android.gms.l9.g;

// dex: classes.dex
public final class b extends deobf.com.google.android.gms.l9.g implements deobf.com.withpersona.sdk2.inquiry.f9.b {

    public static final a.g f3847k;

    public static final a.AbstractC0421a f3848l;

    public static final deobf.com.google.android.gms.l9.a f3849m;

    static {
        a.g gVar = new a.g();
        f3847k = gVar;
        u uVar = new u();
        f3848l = uVar;
        f3849m = new deobf.com.google.android.gms.l9.a("Blockstore.API", uVar, gVar);
    }

    public b(@NonNull Context context) {
        super(context, (deobf.com.google.android.gms.l9.a<a.d.c>) f3849m, a.d.Oo, deobf.com.roblox.protocols.mediapicker.g.a.f22010c);
    }

    @Override // deobf.com.withpersona.sdk2.inquiry.f9.b
    public final Task<Boolean> a(final deobf.com.withpersona.sdk2.inquiry.f9.c cVar) {
        deobf.com.google.android.gms.o9.s.m(cVar, "DeleteBytesRequest cannot be null");
        return D(deobf.com.google.android.gms.m9.u.c().d(c.f3855g).b(new deobf.com.google.android.gms.m9.q() { // from class: bb.q
            /* JADX WARN: Multi-variable type inference failed */
            @Override // deobf.com.google.android.gms.m9.q
            public final void accept(Object obj, Object obj2) {
                ((h) ((g) obj).getService()).t2(new x(b.this, (deobf.com.google.mlkit.common.tb.k) obj2), cVar);
            }
        }).c(false).e(1669).a());
    }

    @Override // deobf.com.withpersona.sdk2.inquiry.f9.b
    public final Task<Integer> n(final deobf.com.withpersona.sdk2.inquiry.f9.f fVar) {
        return D(deobf.com.google.android.gms.m9.u.c().d(c.f3852d, c.f3854f).b(new deobf.com.google.android.gms.m9.q() { // from class: bb.r
            /* JADX WARN: Multi-variable type inference failed */
            @Override // deobf.com.google.android.gms.m9.q
            public final void accept(Object obj, Object obj2) {
                ((h) ((g) obj).getService()).w2(new v(b.this, (deobf.com.google.mlkit.common.tb.k) obj2), fVar);
            }
        }).e(1645).c(false).a());
    }

    @Override // deobf.com.withpersona.sdk2.inquiry.f9.b
    public final Task<Boolean> r() {
        return z(deobf.com.google.android.gms.m9.u.c().d(c.f3853e).b(new deobf.com.google.android.gms.m9.q() { // from class: bb.s
            /* JADX WARN: Multi-variable type inference failed */
            @Override // deobf.com.google.android.gms.m9.q
            public final void accept(Object obj, Object obj2) {
                ((h) ((g) obj).getService()).u2(new y(b.this, (deobf.com.google.mlkit.common.tb.k) obj2));
            }
        }).c(false).e(1651).a());
    }

    @Override // deobf.com.withpersona.sdk2.inquiry.f9.b
    public final Task<deobf.com.withpersona.sdk2.inquiry.f9.e> t(final deobf.com.withpersona.sdk2.inquiry.f9.d dVar) {
        deobf.com.google.android.gms.o9.s.m(dVar, "RetrieveBytesRequest cannot be null");
        return z(deobf.com.google.android.gms.m9.u.c().d(c.f3856h).b(new deobf.com.google.android.gms.m9.q() { // from class: bb.t
            /* JADX WARN: Multi-variable type inference failed */
            @Override // deobf.com.google.android.gms.m9.q
            public final void accept(Object obj, Object obj2) {
                ((h) ((g) obj).getService()).v2(new w(b.this, (deobf.com.google.mlkit.common.tb.k) obj2), dVar);
            }
        }).c(false).e(1668).a());
    }
}
