package deobf.unlinked.bb;

import android.os.Parcel;
import com.google.android.gms.common.api.Status;

// dex: classes.dex
public abstract class o extends d implements p {
    public o() {
        super("com.google.android.gms.auth.blockstore.internal.IStoreBytesCallback");
    }

    @Override // deobf.unlinked.bb.d
    public final boolean r2(int i10, Parcel parcel, Parcel parcel2, int i11) {
        if (i10 != 1) {
            return false;
        }
        Status status = (Status) deobf.com.roblox.client.e.a(parcel, Status.CREATOR);
        int readInt = parcel.readInt();
        s2(parcel);
        x(status, readInt);
        return true;
    }
}
