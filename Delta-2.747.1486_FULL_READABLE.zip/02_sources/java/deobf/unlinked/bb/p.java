package deobf.unlinked.bb;

import android.os.IInterface;
import com.google.android.gms.common.api.Status;

// dex: classes.dex
public interface p extends IInterface {
    void x(Status status, int i10);
}
