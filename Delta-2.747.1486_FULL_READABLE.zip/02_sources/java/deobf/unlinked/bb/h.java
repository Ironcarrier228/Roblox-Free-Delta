package deobf.unlinked.bb;

import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;

// dex: classes.dex
public final class h extends a implements IInterface {
    public h(IBinder iBinder) {
        super(iBinder, "com.google.android.gms.auth.blockstore.internal.IBlockstoreService");
    }

    public final void t2(j jVar, deobf.com.withpersona.sdk2.inquiry.f9.c cVar) {
        Parcel r22 = r2();
        e.c(r22, jVar);
        e.b(r22, cVar);
        s2(13, r22);
    }

    public final void u2(l lVar) {
        Parcel r22 = r2();
        e.c(r22, lVar);
        s2(11, r22);
    }

    public final void v2(n nVar, deobf.com.withpersona.sdk2.inquiry.f9.d dVar) {
        Parcel r22 = r2();
        e.c(r22, nVar);
        e.b(r22, dVar);
        s2(12, r22);
    }

    public final void w2(p pVar, deobf.com.withpersona.sdk2.inquiry.f9.f fVar) {
        Parcel r22 = r2();
        e.c(r22, pVar);
        e.b(r22, fVar);
        s2(10, r22);
    }
}
