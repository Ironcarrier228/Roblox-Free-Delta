package deobf.unlinked.lq;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.annotation.NonNull;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.squareup.workflow1.ui.WorkflowViewStub;

// dex: classes3.dex
public final class b implements deobf.com.withpersona.sdk2.inquiry.s5.a {

    @NonNull
    public final CoordinatorLayout f22456a;

    @NonNull
    public final WorkflowViewStub b;

    @NonNull
    public final FloatingActionButton f22457c;

    public b(@NonNull CoordinatorLayout coordinatorLayout, @NonNull WorkflowViewStub workflowViewStub, @NonNull FloatingActionButton floatingActionButton) {
        this.f22456a = coordinatorLayout;
        this.b = workflowViewStub;
        this.f22457c = floatingActionButton;
    }

    @NonNull
    public static b a(@NonNull View view) {
        int i10 = deobf.unlinked.kq.a.f21726a;
        WorkflowViewStub workflowViewStub = (WorkflowViewStub) deobf.com.withpersona.sdk2.inquiry.s5.b.a(view, i10);
        if (workflowViewStub != null) {
            i10 = deobf.unlinked.kq.a.b;
            FloatingActionButton floatingActionButton = (FloatingActionButton) deobf.com.withpersona.sdk2.inquiry.s5.b.a(view, i10);
            if (floatingActionButton != null) {
                return new b((CoordinatorLayout) view, workflowViewStub, floatingActionButton);
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(i10)));
    }

    @NonNull
    public static b c(@NonNull LayoutInflater layoutInflater, ViewGroup viewGroup, boolean z10) {
        View inflate = layoutInflater.inflate(deobf.unlinked.kq.b.b, viewGroup, false);
        if (z10) {
            viewGroup.addView(inflate);
        }
        return a(inflate);
    }

    @Override // deobf.com.withpersona.sdk2.inquiry.s5.a
    @NonNull
    public CoordinatorLayout getRoot() {
        return this.f22456a;
    }
}
