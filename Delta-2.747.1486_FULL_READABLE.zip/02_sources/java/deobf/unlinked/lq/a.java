package deobf.unlinked.lq;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.materialswitch.MaterialSwitch;

// dex: classes3.dex
public final class a implements deobf.com.withpersona.sdk2.inquiry.s5.a {

    @NonNull
    public final ConstraintLayout f22454a;

    @NonNull
    public final MaterialSwitch b;

    @NonNull
    public final MaterialToolbar f22455c;

    public a(@NonNull ConstraintLayout constraintLayout, @NonNull MaterialSwitch materialSwitch, @NonNull MaterialToolbar materialToolbar) {
        this.f22454a = constraintLayout;
        this.b = materialSwitch;
        this.f22455c = materialToolbar;
    }

    @NonNull
    public static a a(@NonNull View view) {
        int i10 = deobf.unlinked.kq.a.f21727c;
        MaterialSwitch materialSwitch = (MaterialSwitch) deobf.com.withpersona.sdk2.inquiry.s5.b.a(view, i10);
        if (materialSwitch != null) {
            i10 = deobf.unlinked.kq.a.f21728d;
            MaterialToolbar materialToolbar = (MaterialToolbar) deobf.com.withpersona.sdk2.inquiry.s5.b.a(view, i10);
            if (materialToolbar != null) {
                return new a((ConstraintLayout) view, materialSwitch, materialToolbar);
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(i10)));
    }

    @NonNull
    public static a c(@NonNull LayoutInflater layoutInflater) {
        return d(layoutInflater, null, false);
    }

    @NonNull
    public static a d(@NonNull LayoutInflater layoutInflater, ViewGroup viewGroup, boolean z10) {
        View inflate = layoutInflater.inflate(deobf.unlinked.kq.b.f21729a, viewGroup, false);
        if (z10) {
            viewGroup.addView(inflate);
        }
        return a(inflate);
    }

    @Override // deobf.com.withpersona.sdk2.inquiry.s5.a
    @NonNull
    public ConstraintLayout getRoot() {
        return this.f22454a;
    }
}
