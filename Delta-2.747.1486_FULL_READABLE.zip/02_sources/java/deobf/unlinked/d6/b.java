package deobf.unlinked.d6;

import deobf.androidx.work.impl.foreground.c6.b;
import com.github.luben.zstd.BuildConfig;
import deobf.kotlin.cv.t;
import deobf.kotlin.cv.v;
import deobf.unlinked.d6.b;
import deobf.com.withpersona.sdk2.inquiry.gu.m;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;
import deobf.com.withpersona.sdk2.inquiry.zt.o;

@Metadata(d1 = {"\u00004\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\b\n\u0002\b\u0006\b&\u0018\u0000*\u0004\b\u0000\u0010\u00012\u00020\u0002B\u0015\u0012\f\u0010\u0004\u001a\b\u0012\u0004\u0012\u00028\u00000\u0003¢\u0006\u0004\b\u0005\u0010\u0006J\u0017\u0010\t\u001a\u00020\b2\u0006\u0010\u0007\u001a\u00028\u0000H\u0014¢\u0006\u0004\b\t\u0010\nJ\u001d\u0010\u000f\u001a\b\u0012\u0004\u0012\u00020\u000e0\r2\u0006\u0010\f\u001a\u00020\u000bH\u0016¢\u0006\u0004\b\u000f\u0010\u0010R\u001a\u0010\u0004\u001a\b\u0012\u0004\u0012\u00028\u00000\u00038\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b\u000f\u0010\u0011R\u001a\u0010\u0017\u001a\u00020\u00128$X¤\u0004¢\u0006\f\u0012\u0004\b\u0015\u0010\u0016\u001a\u0004\b\u0013\u0010\u0014¨\u0006\u0018"}, d2 = {"Ld6/b;", "T", "Ld6/e;", "Le6/h;", "tracker", "<init>", "(Le6/h;)V", "value", BuildConfig.FLAVOR, "e", "(Ljava/lang/Object;)Z", "Ly5/d;", "constraints", "Ldv/h;", "Lc6/b;", deobf.android.view.xe.a.f36648e, "(Ly5/d;)Ldv/h;", "Le6/h;", BuildConfig.FLAVOR, "d", "()I", "getReason$annotations", "()V", "reason", "work-runtime_release"}, k = 1, mv = {2, 1, 0}, xi = 48)
// dex: classes.dex
public abstract class b<T> implements e {

    @NotNull
    public final deobf.androidx.work.impl.e6.h<T> tracker;

    @Metadata(d1 = {"\u0000\u0010\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0002\b\u0002\u0010\u0003\u001a\u00020\u0002*\b\u0012\u0004\u0012\u00020\u00010\u0000H\n¢\u0006\u0004\b\u0003\u0010\u0004"}, d2 = {"Lcv/v;", "Lc6/b;", BuildConfig.FLAVOR, "<anonymous>", "(Lcv/v;)V"}, k = 3, mv = {2, 1, 0})
    @deobf.com.withpersona.sdk2.inquiry.gu.f(c = "androidx.work.impl.constraints.controllers.BaseConstraintController$track$1", f = "ContraintControllers.kt", l = {62}, m = "invokeSuspend")
    public static final class a extends m implements Function2<v<? super deobf.androidx.work.impl.foreground.c6.b>, deobf.kotlin.eu.b<? super Unit>, Object> {

        public int f11946t;

        public /* synthetic */ Object f11947u;

        public final /* synthetic */ b<T> f11948v;

        @Metadata(d1 = {"\u0000\u0013\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0003*\u0001\u0000\b\n\u0018\u00002\b\u0012\u0004\u0012\u00028\u00000\u0001J\u0017\u0010\u0004\u001a\u00020\u00032\u0006\u0010\u0002\u001a\u00028\u0000H\u0016¢\u0006\u0004\b\u0004\u0010\u0005¨\u0006\u0006"}, d2 = {"d6/b$a$a", "Lc6/a;", "newValue", BuildConfig.FLAVOR, deobf.android.view.xe.a.f36648e, "(Ljava/lang/Object;)V", "work-runtime_release"}, k = 1, mv = {2, 1, 0}, xi = 48)
        public static final class C0217a implements deobf.androidx.work.impl.foreground.c6.a<T> {

            public final /* synthetic */ b<T> f11949a;
            public final /* synthetic */ v<deobf.androidx.work.impl.foreground.c6.b> b;

            /* JADX WARN: Multi-variable type inference failed */
            public C0217a(b<T> bVar, v<? super deobf.androidx.work.impl.foreground.c6.b> vVar) {
                this.f11949a = bVar;
                this.b = vVar;
            }

            @Override // deobf.androidx.work.impl.foreground.c6.a
            public void a(T newValue) {
                this.b.a().v(this.f11949a.e(newValue) ? new b.ConstraintsNotMet(this.f11949a.getReason()) : b.a.f4833a);
            }
        }

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public a(b<T> bVar, deobf.kotlin.eu.b<? super a> bVar2) {
            super(2, bVar2);
            this.f11948v = bVar;
        }

        public static final Unit q(b bVar, C0217a c0217a) {
            bVar.tracker.g(c0217a);
            return Unit.f21504a;
        }

        @Override // deobf.com.withpersona.sdk2.inquiry.gu.a
        public final deobf.kotlin.eu.b<Unit> create(Object obj, deobf.kotlin.eu.b<?> bVar) {
            a aVar = new a(this.f11948v, bVar);
            aVar.f11947u = obj;
            return aVar;
        }

        @Override // deobf.com.withpersona.sdk2.inquiry.gu.a
        public final Object invokeSuspend(Object obj) {
            Object e10 = deobf.kotlin.fu.c.e();
            int i10 = this.f11946t;
            if (i10 == 0) {
                deobf.com.google.android.material.o.b(obj);
                v vVar = (v) this.f11947u;
                final C0217a c0217a = new C0217a(this.f11948v, vVar);
                this.f11948v.tracker.c(c0217a);
                final b<T> bVar = this.f11948v;
                Function0 function0 = new Function0() { // from class: d6.a
                    @Override // kotlin.jvm.functions.Function0
                    public final Object invoke() {
                        Unit q8;
                        q8 = b.a.q(b.this, c0217a);
                        return q8;
                    }
                };
                this.f11946t = 1;
                if (deobf.unlinked.t.a(vVar, function0, this) == e10) {
                    return e10;
                }
            } else {
                if (i10 != 1) {
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                deobf.com.google.android.material.o.b(obj);
            }
            return Unit.f21504a;
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(v<? super deobf.androidx.work.impl.foreground.c6.b> vVar, deobf.kotlin.eu.b<? super Unit> bVar) {
            return ((a) create(vVar, bVar)).invokeSuspend(Unit.f21504a);
        }
    }

    public b(@NotNull deobf.androidx.work.impl.e6.h<T> tracker) {
        Intrinsics.checkNotNullParameter(tracker, "tracker");
        this.tracker = tracker;
    }

    @Override // deobf.unlinked.d6.e
    @NotNull
    public deobf.kotlin.dv.h<deobf.androidx.work.impl.foreground.c6.b> a(@NotNull deobf.androidx.work.y5.d constraints) {
        Intrinsics.checkNotNullParameter(constraints, "constraints");
        return deobf.kotlin.dv.j.d(new a(this, null));
    }

    public abstract int getReason();

    public abstract boolean e(T value);
}
