package deobf.unlinked.d6;

import com.github.luben.zstd.BuildConfig;
import deobf.androidx.work.impl.g6.j0;
import kotlin.Metadata;
import org.jetbrains.annotations.NotNull;

@Metadata(d1 = {"\u0000(\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0003\bf\u0018\u00002\u00020\u0001J\u001d\u0010\u0006\u001a\b\u0012\u0004\u0012\u00020\u00050\u00042\u0006\u0010\u0003\u001a\u00020\u0002H&¢\u0006\u0004\b\u0006\u0010\u0007J\u0017\u0010\u000b\u001a\u00020\n2\u0006\u0010\t\u001a\u00020\bH&¢\u0006\u0004\b\u000b\u0010\fø\u0001\u0000\u0082\u0002\u0006\n\u0004\b!0\u0001¨\u0006\rÀ\u0006\u0001"}, d2 = {"Ld6/e;", BuildConfig.FLAVOR, "Ly5/d;", "constraints", "Ldv/h;", "Lc6/b;", deobf.android.view.xe.a.f36648e, "(Ly5/d;)Ldv/h;", "Lg6/j0;", "workSpec", BuildConfig.FLAVOR, deobf.android.view.k6.b.f21144e, "(Lg6/j0;)Z", "work-runtime_release"}, k = 1, mv = {2, 1, 0}, xi = 48)
// dex: classes.dex
public interface e {
    @NotNull
    deobf.kotlin.dv.h<deobf.androidx.work.impl.foreground.c6.b> a(@NotNull deobf.androidx.work.y5.d constraints);

    boolean b(@NotNull j0 workSpec);
}
