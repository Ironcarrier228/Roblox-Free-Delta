package deobf.unlinked.ad;

import android.annotation.TargetApi;
import android.content.res.ColorStateList;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.LinearGradient;
import android.graphics.Outline;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.drawable.Drawable;
import androidx.annotation.NonNull;
import androidx.core.graphics.c;
import deobf.com.google.android.material.id.k;
import deobf.com.google.android.material.id.l;

// dex: classes2.dex
public class a extends Drawable {

    @NonNull
    public final Paint b;

    public float f402h;

    public int f403i;

    public int f404j;

    public int f405k;

    public int f406l;

    public int f407m;

    public k f409o;

    public ColorStateList f410p;

    public final l f396a = l.k();

    public final Path f397c = new Path();

    public final Rect f398d = new Rect();

    public final RectF f399e = new RectF();

    public final RectF f400f = new RectF();

    public final b f401g = new b();

    public boolean f408n = true;

    public class b extends Drawable.ConstantState {
        public b() {
        }

        @Override // android.graphics.drawable.Drawable.ConstantState
        public int getChangingConfigurations() {
            return 0;
        }

        @Override // android.graphics.drawable.Drawable.ConstantState
        @NonNull
        public Drawable newDrawable() {
            return a.this;
        }
    }

    public a(k kVar) {
        this.f409o = kVar;
        Paint paint = new Paint(1);
        this.b = paint;
        paint.setStyle(Paint.Style.STROKE);
    }

    @NonNull
    public final Shader a() {
        copyBounds(this.f398d);
        float height = this.f402h / r1.height();
        return new LinearGradient(0.0f, r1.top, 0.0f, r1.bottom, new int[]{c.h(this.f403i, this.f407m), c.h(this.f404j, this.f407m), c.h(c.l(this.f404j, 0), this.f407m), c.h(c.l(this.f406l, 0), this.f407m), c.h(this.f406l, this.f407m), c.h(this.f405k, this.f407m)}, new float[]{0.0f, height, 0.5f, 0.5f, 1.0f - height, 1.0f}, Shader.TileMode.CLAMP);
    }

    @NonNull
    public RectF b() {
        this.f400f.set(getBounds());
        return this.f400f;
    }

    public void c(ColorStateList colorStateList) {
        if (colorStateList != null) {
            this.f407m = colorStateList.getColorForState(getState(), this.f407m);
        }
        this.f410p = colorStateList;
        this.f408n = true;
        invalidateSelf();
    }

    public void d(float f10) {
        if (this.f402h != f10) {
            this.f402h = f10;
            this.b.setStrokeWidth(f10 * 1.3333f);
            this.f408n = true;
            invalidateSelf();
        }
    }

    @Override // android.graphics.drawable.Drawable
    public void draw(@NonNull Canvas canvas) {
        if (this.f408n) {
            this.b.setShader(a());
            this.f408n = false;
        }
        float strokeWidth = this.b.getStrokeWidth() / 2.0f;
        copyBounds(this.f398d);
        this.f399e.set(this.f398d);
        float min = Math.min(this.f409o.r().a(b()), this.f399e.width() / 2.0f);
        if (this.f409o.u(b())) {
            this.f399e.inset(strokeWidth, strokeWidth);
            canvas.drawRoundRect(this.f399e, min, min, this.b);
        }
    }

    public void e(int i10, int i11, int i12, int i13) {
        this.f403i = i10;
        this.f404j = i11;
        this.f405k = i12;
        this.f406l = i13;
    }

    public void f(k kVar) {
        this.f409o = kVar;
        invalidateSelf();
    }

    @Override // android.graphics.drawable.Drawable
    public Drawable.ConstantState getConstantState() {
        return this.f401g;
    }

    @Override // android.graphics.drawable.Drawable
    public int getOpacity() {
        return this.f402h > 0.0f ? -3 : -2;
    }

    @Override // android.graphics.drawable.Drawable
    @TargetApi(21)
    public void getOutline(@NonNull Outline outline) {
        if (this.f409o.u(b())) {
            outline.setRoundRect(getBounds(), this.f409o.r().a(b()));
        } else {
            copyBounds(this.f398d);
            this.f399e.set(this.f398d);
            this.f396a.d(this.f409o, 1.0f, this.f399e, this.f397c);
            deobf.com.google.android.material.xc.c.k(outline, this.f397c);
        }
    }

    @Override // android.graphics.drawable.Drawable
    public boolean getPadding(@NonNull Rect rect) {
        if (!this.f409o.u(b())) {
            return true;
        }
        int round = Math.round(this.f402h);
        rect.set(round, round, round, round);
        return true;
    }

    @Override // android.graphics.drawable.Drawable
    public boolean isStateful() {
        ColorStateList colorStateList = this.f410p;
        return (colorStateList != null && colorStateList.isStateful()) || super.isStateful();
    }

    @Override // android.graphics.drawable.Drawable
    public void onBoundsChange(Rect rect) {
        this.f408n = true;
    }

    @Override // android.graphics.drawable.Drawable
    public boolean onStateChange(int[] iArr) {
        int colorForState;
        ColorStateList colorStateList = this.f410p;
        if (colorStateList != null && (colorForState = colorStateList.getColorForState(iArr, this.f407m)) != this.f407m) {
            this.f408n = true;
            this.f407m = colorForState;
        }
        if (this.f408n) {
            invalidateSelf();
        }
        return this.f408n;
    }

    @Override // android.graphics.drawable.Drawable
    public void setAlpha(int i10) {
        this.b.setAlpha(i10);
        invalidateSelf();
    }

    @Override // android.graphics.drawable.Drawable
    public void setColorFilter(ColorFilter colorFilter) {
        this.b.setColorFilter(colorFilter);
        invalidateSelf();
    }
}
