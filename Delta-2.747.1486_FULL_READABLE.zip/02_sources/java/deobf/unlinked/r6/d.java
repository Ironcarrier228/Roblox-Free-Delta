package deobf.unlinked.r6;

import com.github.luben.zstd.BuildConfig;
import kotlin.Metadata;
import deobf.com.roblox.client.l6.h0;
import org.jetbrains.annotations.NotNull;
import deobf.com.roblox.client.widgets.y6.Options;

@Metadata(d1 = {"\u0000\u001e\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0003\b\u0000\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001B\u0007¢\u0006\u0004\b\u0003\u0010\u0004J\u001f\u0010\t\u001a\u00020\b2\u0006\u0010\u0005\u001a\u00020\u00022\u0006\u0010\u0007\u001a\u00020\u0006H\u0016¢\u0006\u0004\b\t\u0010\n¨\u0006\u000b"}, d2 = {"Lr6/d;", "Lr6/c;", "Ll6/h0;", "<init>", "()V", "data", "Ly6/p;", "options", BuildConfig.FLAVOR, deobf.android.view.k6.b.f21144e, "(Ll6/h0;Ly6/p;)Ljava/lang/String;", "coil-core_release"}, k = 1, mv = {2, 2, 0}, xi = 48)
// dex: classes.dex
public final class d implements c<h0> {
    @Override // deobf.unlinked.r6.c
    @NotNull
    public String a(@NotNull h0 data, @NotNull Options options) {
        return data.getData();
    }
}
