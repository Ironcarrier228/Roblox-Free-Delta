package deobf.unlinked.qc;

import android.R;
import android.animation.TimeInterpolator;
import android.animation.ValueAnimator;
import android.content.res.ColorStateList;
import android.content.res.TypedArray;
import android.graphics.Rect;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.InsetDrawable;
import android.graphics.drawable.LayerDrawable;
import android.graphics.drawable.RippleDrawable;
import android.graphics.drawable.StateListDrawable;
import android.os.Build;
import android.util.AttributeSet;
import android.view.View;
import androidx.annotation.NonNull;
import androidx.core.view.o0;
import com.google.android.material.card.MaterialCardView;
import com.google.mlkit.common.MlKitException;
import deobf.com.google.android.material.dd.h;
import deobf.com.google.android.material.fd.c;
import deobf.com.google.android.material.id.d;
import deobf.com.google.android.material.id.e;
import deobf.com.google.android.material.id.g;
import deobf.com.google.android.material.id.k;
import deobf.com.google.android.material.jc.f;
import deobf.com.google.android.material.jc.j;

// dex: classes2.dex
public class b {
    public static final Drawable A;

    public static final double f29964z = Math.cos(Math.toRadians(45.0d));

    @NonNull
    public final MaterialCardView f29965a;

    @NonNull
    public final g f29966c;

    @NonNull
    public final g f29967d;

    public int f29968e;

    public int f29969f;

    public int f29970g;

    public int f29971h;

    public Drawable f29972i;

    public Drawable f29973j;

    public ColorStateList f29974k;

    public ColorStateList f29975l;

    public k f29976m;

    public ColorStateList f29977n;

    public Drawable f29978o;

    public LayerDrawable f29979p;

    public g f29980q;

    public g f29981r;

    public boolean f29983t;

    public ValueAnimator f29984u;

    public final TimeInterpolator f29985v;

    public final int f29986w;

    public final int f29987x;

    @NonNull
    public final Rect b = new Rect();

    public boolean f29982s = false;

    public float f29988y = 0.0f;

    public class a extends InsetDrawable {
        public a(Drawable drawable, int i10, int i11, int i12, int i13) {
            super(drawable, i10, i11, i12, i13);
        }

        @Override // android.graphics.drawable.Drawable
        public int getMinimumHeight() {
            return -1;
        }

        @Override // android.graphics.drawable.Drawable
        public int getMinimumWidth() {
            return -1;
        }

        @Override // android.graphics.drawable.InsetDrawable, android.graphics.drawable.DrawableWrapper, android.graphics.drawable.Drawable
        public boolean getPadding(Rect rect) {
            return false;
        }
    }

    static {
        A = Build.VERSION.SDK_INT <= 28 ? new ColorDrawable() : null;
    }

    public b(@NonNull MaterialCardView materialCardView, AttributeSet attributeSet, int i10, int i11) {
        this.f29965a = materialCardView;
        g gVar = new g(materialCardView.getContext(), attributeSet, i10, i11);
        this.f29966c = gVar;
        gVar.Q(materialCardView.getContext());
        gVar.f0(-12303292);
        k.b v8 = gVar.E().v();
        TypedArray obtainStyledAttributes = materialCardView.getContext().obtainStyledAttributes(attributeSet, deobf.com.google.android.material.jc.k.f20548j0, i10, j.f20439a);
        if (obtainStyledAttributes.hasValue(deobf.com.google.android.material.jc.k.f20557k0)) {
            v8.o(obtainStyledAttributes.getDimension(deobf.com.google.android.material.jc.k.f20557k0, 0.0f));
        }
        this.f29967d = new g();
        Y(v8.m());
        this.f29985v = deobf.com.roblox.protocols.mediapicker.h.g(materialCardView.getContext(), deobf.com.google.android.material.jc.b.Q, deobf.com.google.android.material.kc.a.f21323a);
        this.f29986w = deobf.com.roblox.protocols.mediapicker.h.f(materialCardView.getContext(), deobf.com.google.android.material.jc.b.K, MlKitException.LOW_LIGHT_AUTO_EXPOSURE_COMPUTATION_FAILURE);
        this.f29987x = deobf.com.roblox.protocols.mediapicker.h.f(materialCardView.getContext(), deobf.com.google.android.material.jc.b.J, MlKitException.LOW_LIGHT_AUTO_EXPOSURE_COMPUTATION_FAILURE);
        obtainStyledAttributes.recycle();
    }

    public static /* synthetic */ void a(b bVar, ValueAnimator valueAnimator) {
        bVar.getClass();
        float floatValue = ((Float) valueAnimator.getAnimatedValue()).floatValue();
        bVar.f29973j.setAlpha((int) (255.0f * floatValue));
        bVar.f29988y = floatValue;
    }

    public ColorStateList A() {
        return this.f29977n;
    }

    public int B() {
        return this.f29971h;
    }

    @NonNull
    public Rect C() {
        return this.b;
    }

    @NonNull
    public final Drawable D(Drawable drawable) {
        int i10;
        int i11;
        if (this.f29965a.getUseCompatPadding()) {
            i11 = (int) Math.ceil(f());
            i10 = (int) Math.ceil(e());
        } else {
            i10 = 0;
            i11 = 0;
        }
        return new a(drawable, i10, i11, i10, i11);
    }

    public boolean E() {
        return this.f29982s;
    }

    public boolean F() {
        return this.f29983t;
    }

    public final boolean G() {
        return (this.f29970g & 80) == 80;
    }

    public final boolean H() {
        return (this.f29970g & 8388613) == 8388613;
    }

    public void I(@NonNull TypedArray typedArray) {
        ColorStateList a10 = deobf.com.withpersona.sdk2.inquiry.c.a(this.f29965a.getContext(), typedArray, deobf.com.google.android.material.jc.k.J3);
        this.f29977n = a10;
        if (a10 == null) {
            this.f29977n = ColorStateList.valueOf(-1);
        }
        this.f29971h = typedArray.getDimensionPixelSize(deobf.com.google.android.material.jc.k.K3, 0);
        boolean z10 = typedArray.getBoolean(deobf.com.google.android.material.jc.k.B3, false);
        this.f29983t = z10;
        this.f29965a.setLongClickable(z10);
        this.f29975l = deobf.com.withpersona.sdk2.inquiry.c.a(this.f29965a.getContext(), typedArray, deobf.com.google.android.material.jc.k.H3);
        Q(c.d(this.f29965a.getContext(), typedArray, deobf.com.google.android.material.jc.k.D3));
        T(typedArray.getDimensionPixelSize(deobf.com.google.android.material.jc.k.G3, 0));
        S(typedArray.getDimensionPixelSize(deobf.com.google.android.material.jc.k.F3, 0));
        this.f29970g = typedArray.getInteger(deobf.com.google.android.material.jc.k.E3, 8388661);
        ColorStateList a11 = deobf.com.withpersona.sdk2.inquiry.c.a(this.f29965a.getContext(), typedArray, deobf.com.google.android.material.jc.k.I3);
        this.f29974k = a11;
        if (a11 == null) {
            this.f29974k = ColorStateList.valueOf(deobf.com.google.android.material.vc.a.d(this.f29965a, deobf.com.google.android.material.jc.b.f20289h));
        }
        M(deobf.com.withpersona.sdk2.inquiry.c.a(this.f29965a.getContext(), typedArray, deobf.com.google.android.material.jc.k.C3));
        k0();
        h0();
        l0();
        this.f29965a.setBackgroundInternal(D(this.f29966c));
        Drawable t8 = e0() ? t() : this.f29967d;
        this.f29972i = t8;
        this.f29965a.setForeground(D(t8));
    }

    public void J(int i10, int i11) {
        int i12;
        int i13;
        int i14;
        int i15;
        if (this.f29979p != null) {
            if (this.f29965a.getUseCompatPadding()) {
                i12 = (int) Math.ceil(f() * 2.0f);
                i13 = (int) Math.ceil(e() * 2.0f);
            } else {
                i12 = 0;
                i13 = 0;
            }
            int i16 = H() ? ((i10 - this.f29968e) - this.f29969f) - i13 : this.f29968e;
            int i17 = G() ? this.f29968e : ((i11 - this.f29968e) - this.f29969f) - i12;
            int i18 = H() ? this.f29968e : ((i10 - this.f29968e) - this.f29969f) - i13;
            int i19 = G() ? ((i11 - this.f29968e) - this.f29969f) - i12 : this.f29968e;
            if (o0.z(this.f29965a) == 1) {
                i15 = i18;
                i14 = i16;
            } else {
                i14 = i18;
                i15 = i16;
            }
            this.f29979p.setLayerInset(2, i15, i19, i14, i17);
        }
    }

    public void K(boolean z10) {
        this.f29982s = z10;
    }

    public void L(ColorStateList colorStateList) {
        this.f29966c.a0(colorStateList);
    }

    public void M(ColorStateList colorStateList) {
        g gVar = this.f29967d;
        if (colorStateList == null) {
            colorStateList = ColorStateList.valueOf(0);
        }
        gVar.a0(colorStateList);
    }

    public void N(boolean z10) {
        this.f29983t = z10;
    }

    public void O(boolean z10) {
        P(z10, false);
    }

    public void P(boolean z10, boolean z11) {
        Drawable drawable = this.f29973j;
        if (drawable != null) {
            if (z11) {
                b(z10);
            } else {
                drawable.setAlpha(z10 ? 255 : 0);
                this.f29988y = z10 ? 1.0f : 0.0f;
            }
        }
    }

    public void Q(Drawable drawable) {
        if (drawable != null) {
            Drawable mutate = deobf.com.google.android.material.q2.a.r(drawable).mutate();
            this.f29973j = mutate;
            deobf.com.google.android.material.q2.a.o(mutate, this.f29975l);
            O(this.f29965a.isChecked());
        } else {
            this.f29973j = A;
        }
        LayerDrawable layerDrawable = this.f29979p;
        if (layerDrawable != null) {
            layerDrawable.setDrawableByLayerId(f.D, this.f29973j);
        }
    }

    public void R(int i10) {
        this.f29970g = i10;
        J(this.f29965a.getMeasuredWidth(), this.f29965a.getMeasuredHeight());
    }

    public void S(int i10) {
        this.f29968e = i10;
    }

    public void T(int i10) {
        this.f29969f = i10;
    }

    public void U(ColorStateList colorStateList) {
        this.f29975l = colorStateList;
        Drawable drawable = this.f29973j;
        if (drawable != null) {
            deobf.com.google.android.material.q2.a.o(drawable, colorStateList);
        }
    }

    public void V(float f10) {
        Y(this.f29976m.w(f10));
        this.f29972i.invalidateSelf();
        if (d0() || c0()) {
            g0();
        }
        if (d0()) {
            j0();
        }
    }

    public void W(float f10) {
        this.f29966c.b0(f10);
        g gVar = this.f29967d;
        if (gVar != null) {
            gVar.b0(f10);
        }
        g gVar2 = this.f29981r;
        if (gVar2 != null) {
            gVar2.b0(f10);
        }
    }

    public void X(ColorStateList colorStateList) {
        this.f29974k = colorStateList;
        k0();
    }

    public void Y(@NonNull k kVar) {
        this.f29976m = kVar;
        this.f29966c.setShapeAppearanceModel(kVar);
        this.f29966c.e0(!r0.T());
        g gVar = this.f29967d;
        if (gVar != null) {
            gVar.setShapeAppearanceModel(kVar);
        }
        g gVar2 = this.f29981r;
        if (gVar2 != null) {
            gVar2.setShapeAppearanceModel(kVar);
        }
        g gVar3 = this.f29980q;
        if (gVar3 != null) {
            gVar3.setShapeAppearanceModel(kVar);
        }
    }

    public void Z(ColorStateList colorStateList) {
        if (this.f29977n == colorStateList) {
            return;
        }
        this.f29977n = colorStateList;
        l0();
    }

    public void a0(int i10) {
        if (i10 == this.f29971h) {
            return;
        }
        this.f29971h = i10;
        l0();
    }

    public void b(boolean z10) {
        float f10 = z10 ? 1.0f : 0.0f;
        float f11 = z10 ? 1.0f - this.f29988y : this.f29988y;
        ValueAnimator valueAnimator = this.f29984u;
        if (valueAnimator != null) {
            valueAnimator.cancel();
            this.f29984u = null;
        }
        ValueAnimator ofFloat = ValueAnimator.ofFloat(this.f29988y, f10);
        this.f29984u = ofFloat;
        ofFloat.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() { // from class: qc.a
            @Override // android.animation.ValueAnimator.AnimatorUpdateListener
            public final void onAnimationUpdate(ValueAnimator valueAnimator2) {
                b.a(b.this, valueAnimator2);
            }
        });
        this.f29984u.setInterpolator(this.f29985v);
        this.f29984u.setDuration((long) ((z10 ? this.f29986w : this.f29987x) * f11));
        this.f29984u.start();
    }

    public void b0(int i10, int i11, int i12, int i13) {
        this.b.set(i10, i11, i12, i13);
        g0();
    }

    public final float c() {
        return Math.max(Math.max(d(this.f29976m.q(), this.f29966c.J()), d(this.f29976m.s(), this.f29966c.K())), Math.max(d(this.f29976m.k(), this.f29966c.t()), d(this.f29976m.i(), this.f29966c.s())));
    }

    public final boolean c0() {
        return this.f29965a.getPreventCornerOverlap() && !g();
    }

    public final float d(d dVar, float f10) {
        if (dVar instanceof deobf.com.google.android.material.id.j) {
            return (float) ((1.0d - f29964z) * f10);
        }
        if (dVar instanceof e) {
            return f10 / 2.0f;
        }
        return 0.0f;
    }

    public final boolean d0() {
        return this.f29965a.getPreventCornerOverlap() && g() && this.f29965a.getUseCompatPadding();
    }

    public final float e() {
        return this.f29965a.getMaxCardElevation() + (d0() ? c() : 0.0f);
    }

    public final boolean e0() {
        if (this.f29965a.isClickable()) {
            return true;
        }
        View view = this.f29965a;
        while (view.isDuplicateParentStateEnabled() && (view.getParent() instanceof View)) {
            view = (View) view.getParent();
        }
        return view.isClickable();
    }

    public final float f() {
        return (this.f29965a.getMaxCardElevation() * 1.5f) + (d0() ? c() : 0.0f);
    }

    public void f0() {
        Drawable drawable = this.f29972i;
        Drawable t8 = e0() ? t() : this.f29967d;
        this.f29972i = t8;
        if (drawable != t8) {
            i0(t8);
        }
    }

    public final boolean g() {
        return this.f29966c.T();
    }

    public void g0() {
        int c10 = (int) (((c0() || d0()) ? c() : 0.0f) - v());
        MaterialCardView materialCardView = this.f29965a;
        Rect rect = this.b;
        materialCardView.i(rect.left + c10, rect.top + c10, rect.right + c10, rect.bottom + c10);
    }

    @NonNull
    public final Drawable h() {
        StateListDrawable stateListDrawable = new StateListDrawable();
        g j10 = j();
        this.f29980q = j10;
        j10.a0(this.f29974k);
        stateListDrawable.addState(new int[]{R.attr.state_pressed}, this.f29980q);
        return stateListDrawable;
    }

    public void h0() {
        this.f29966c.Z(this.f29965a.getCardElevation());
    }

    @NonNull
    public final Drawable i() {
        if (!deobf.com.google.android.material.gd.b.f17683a) {
            return h();
        }
        this.f29981r = j();
        return new RippleDrawable(this.f29974k, null, this.f29981r);
    }

    public final void i0(Drawable drawable) {
        if (this.f29965a.getForeground() instanceof InsetDrawable) {
            ((InsetDrawable) this.f29965a.getForeground()).setDrawable(drawable);
        } else {
            this.f29965a.setForeground(D(drawable));
        }
    }

    @NonNull
    public final g j() {
        return new g(this.f29976m);
    }

    public void j0() {
        if (!E()) {
            this.f29965a.setBackgroundInternal(D(this.f29966c));
        }
        this.f29965a.setForeground(D(this.f29972i));
    }

    public void k() {
        Drawable drawable = this.f29978o;
        if (drawable != null) {
            Rect bounds = drawable.getBounds();
            int i10 = bounds.bottom;
            this.f29978o.setBounds(bounds.left, bounds.top, bounds.right, i10 - 1);
            this.f29978o.setBounds(bounds.left, bounds.top, bounds.right, i10);
        }
    }

    public final void k0() {
        Drawable drawable;
        if (deobf.com.google.android.material.gd.b.f17683a && (drawable = this.f29978o) != null) {
            ((RippleDrawable) drawable).setColor(this.f29974k);
            return;
        }
        g gVar = this.f29980q;
        if (gVar != null) {
            gVar.a0(this.f29974k);
        }
    }

    @NonNull
    public g l() {
        return this.f29966c;
    }

    public void l0() {
        this.f29967d.h0(this.f29971h, this.f29977n);
    }

    public ColorStateList m() {
        return this.f29966c.x();
    }

    public ColorStateList n() {
        return this.f29967d.x();
    }

    public Drawable o() {
        return this.f29973j;
    }

    public int p() {
        return this.f29970g;
    }

    public int q() {
        return this.f29968e;
    }

    public int r() {
        return this.f29969f;
    }

    public ColorStateList s() {
        return this.f29975l;
    }

    @NonNull
    public final Drawable t() {
        if (this.f29978o == null) {
            this.f29978o = i();
        }
        if (this.f29979p == null) {
            LayerDrawable layerDrawable = new LayerDrawable(new Drawable[]{this.f29978o, this.f29967d, this.f29973j});
            this.f29979p = layerDrawable;
            layerDrawable.setId(2, f.D);
        }
        return this.f29979p;
    }

    public float u() {
        return this.f29966c.J();
    }

    public final float v() {
        if (this.f29965a.getPreventCornerOverlap() && this.f29965a.getUseCompatPadding()) {
            return (float) ((1.0d - f29964z) * this.f29965a.getCardViewRadius());
        }
        return 0.0f;
    }

    public float w() {
        return this.f29966c.y();
    }

    public ColorStateList x() {
        return this.f29974k;
    }

    public k y() {
        return this.f29976m;
    }

    public int z() {
        ColorStateList colorStateList = this.f29977n;
        if (colorStateList == null) {
            return -1;
        }
        return colorStateList.getDefaultColor();
    }
}
