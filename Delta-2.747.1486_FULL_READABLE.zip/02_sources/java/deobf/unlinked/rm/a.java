package deobf.unlinked.rm;

import android.util.Log;
import org.json.JSONException;
import org.json.JSONObject;

// dex: classes2.dex
public class a {

    public long f30780a;
    public final long b;

    public a(JSONObject jSONObject, long j10) {
        this.f30780a = -1L;
        this.b = j10;
        if (jSONObject == null) {
            Log.e("BackgroundExperiment", "Background experiment constructed with null JSON payload.");
            return;
        }
        try {
            this.f30780a = jSONObject.getLong("background_delay");
        } catch (JSONException e10) {
            Log.e("BackgroundExperiment", "Failed to get background delay from JSON payload. Error: " + e10.getMessage());
        }
    }

    public long a() {
        long j10 = this.f30780a;
        return j10 == -1 ? this.b : j10;
    }
}
