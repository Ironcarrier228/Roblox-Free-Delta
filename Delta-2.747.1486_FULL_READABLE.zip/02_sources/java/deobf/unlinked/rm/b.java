package deobf.unlinked.rm;

import android.util.Log;
import deobf.com.roblox.client.bi.h;
import com.roblox.universalapp.messagebus.Callback;
import com.roblox.universalapp.messagebus.Connection;
import com.roblox.universalapp.messagebus.MessageBus;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Hashtable;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

// dex: classes2.dex
public class b {

    public final MessageBus f30781a;
    public final ArrayList<Connection> b;

    public final ArrayList<String> f30782c;

    public final Hashtable<String, JSONObject> f30783d;

    public class a implements Callback {
        public a() {
        }

        @Override // com.roblox.universalapp.messagebus.Callback
        public void run(JSONObject jSONObject) {
            try {
                if (jSONObject.getString("status").equals("Initialized")) {
                    b.this.c();
                }
            } catch (JSONException e10) {
                Log.e("ExperimentProtocol", "Loading status of IXP User Layers is not returned from the MessageBus. File a bug to NFDN component. Error: " + e10.getMessage());
            }
        }
    }

    public class C0603b implements Callback {
        public C0603b() {
        }

        @Override // com.roblox.universalapp.messagebus.Callback
        public void run(JSONObject jSONObject) {
            try {
                b.this.f30783d.put(jSONObject.getString("layerName"), new JSONObject(jSONObject.getString("layerVariables")));
            } catch (JSONException e10) {
                Log.e("ExperimentProtocol", "Unable to get variables from layer. Error: " + e10.getMessage());
            }
        }
    }

    public static class c {

        public static final b f30786a = new b();
    }

    public static b i() {
        return c.f30786a;
    }

    public final void c() {
        ArrayList<String> arrayList = this.f30782c;
        int size = arrayList.size();
        int i10 = 0;
        while (i10 < size) {
            String str = arrayList.get(i10);
            i10++;
            String str2 = str;
            try {
                JSONObject jSONObject = new JSONObject();
                jSONObject.put("layerName", str2);
                this.f30781a.publish(d.GET_USER_LAYER_VARIABLES_REQUEST, jSONObject);
            } catch (JSONException e10) {
                Log.e("ExperimentProtocol", "Failed to construct getUserLayerVariables JSON due to: " + e10.getMessage());
            }
        }
    }

    public JSONObject d(String str) {
        return this.f30783d.get(str);
    }

    public final void e() {
        this.b.add(this.f30781a.subscribe(d.GET_USER_LAYER_VARIABLES_RESPONSE, new C0603b()));
    }

    public final void f() {
        this.b.add(this.f30781a.subscribe(d.USER_LAYER_LOADING_STATUS_CHANGED, new a()));
    }

    public void g() {
        ArrayList arrayList = new ArrayList();
        if (deobf.com.roblox.protocols.mediapicker.h.a().S0()) {
            arrayList.add("Backgrounding.General");
        }
        if (arrayList.isEmpty()) {
            return;
        }
        h((String[]) arrayList.toArray(new String[0]));
    }

    public final void h(String[] strArr) {
        this.f30782c.addAll(Arrays.asList(strArr));
        try {
            JSONArray jSONArray = new JSONArray(strArr);
            JSONObject jSONObject = new JSONObject();
            jSONObject.put("userLayers", jSONArray);
            this.f30781a.publish(d.REGISTER_USER_LAYER, jSONObject);
        } catch (JSONException e10) {
            Log.e("ExperimentProtocol", "Failed to construct registerUserLayers JSON due to: " + e10.getMessage());
        }
    }

    public b() {
        this.f30781a = MessageBus.getInstance();
        this.b = new ArrayList<>();
        this.f30782c = new ArrayList<>();
        this.f30783d = new Hashtable<>();
        e();
        f();
    }
}
