package deobf.unlinked.kj;

import deobf.com.roblox.client.bh.a1;

// dex: classes2.dex
public class b extends a {

    public deobf.com.roblox.client.provider.ph.c f21457a;

    public b(deobf.com.roblox.client.provider.ph.c cVar) {
        this.f21457a = cVar;
    }

    @Override // deobf.unlinked.kj.a, android.database.AbstractCursor, android.database.Cursor
    public String[] getColumnNames() {
        return new String[]{"channel_param", "default_channel_param", "base_url_param", "default_base_url_param", "settings_param", "user_agent_param", "default_user_agent_param", "dev_rpc_ip_port_override", "dev_branch", "dev_commit", "browser_tracker_id"};
    }

    @Override // deobf.unlinked.kj.a, android.database.AbstractCursor, android.database.Cursor
    public String getString(int i10) {
        if (i10 == getColumnIndex("channel_param")) {
            return this.f21457a.h();
        }
        if (i10 == getColumnIndex("default_channel_param")) {
            return this.f21457a.c();
        }
        if (i10 == getColumnIndex("base_url_param")) {
            return this.f21457a.a();
        }
        if (i10 == getColumnIndex("default_base_url_param")) {
            return this.f21457a.b();
        }
        if (i10 == getColumnIndex("settings_param")) {
            return this.f21457a.j();
        }
        if (i10 == getColumnIndex("user_agent_param")) {
            return this.f21457a.k();
        }
        if (i10 == getColumnIndex("default_user_agent_param")) {
            return this.f21457a.d();
        }
        if (i10 == getColumnIndex("dev_rpc_ip_port_override")) {
            return this.f21457a.g();
        }
        if (i10 == getColumnIndex("dev_branch")) {
            return this.f21457a.e();
        }
        if (i10 == getColumnIndex("dev_commit")) {
            return this.f21457a.f();
        }
        if (i10 == getColumnIndex("browser_tracker_id")) {
            return String.valueOf(a1.f4037u);
        }
        return null;
    }
}
