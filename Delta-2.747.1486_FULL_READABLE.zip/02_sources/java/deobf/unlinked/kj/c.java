package deobf.unlinked.kj;

import android.content.Context;
import android.content.SharedPreferences;
import deobf.com.roblox.client.bh.a1;
import com.github.luben.zstd.BuildConfig;
import deobf.com.roblox.client.ok.z;
import deobf.com.roblox.client.provider.ph.c;

// dex: classes2.dex
public class c implements deobf.com.withpersona.sdk2.inquiry.c.a {

    public deobf.unlinked.ek.a f21458a;
    public SharedPreferences b;

    public String f21459c;

    public c(Context context) {
        this.f21458a = new deobf.unlinked.ek.a(context);
        this.b = deobf.androidx.camera.camera2.z.e(context.getApplicationContext()).d("configure_dev_roblox", true);
        a1.S0(context);
        this.f21459c = a1.m(context);
    }

    @Override // deobf.com.roblox.client.provider.ph.c.a
    public void a(String str) {
        this.b.edit().putString("dev_commit", str).apply();
    }

    @Override // deobf.com.roblox.client.provider.ph.c.a
    public void b(String str) {
        if (str != null) {
            this.f21458a.k(str);
        } else {
            this.f21458a.b();
        }
    }

    @Override // deobf.com.roblox.client.provider.ph.c.a
    public void c(String str) {
        if (str != null) {
            this.b.edit().putString("BaseUrl", str).apply();
        } else {
            this.b.edit().remove("BaseUrl").apply();
        }
    }

    @Override // deobf.com.roblox.client.provider.ph.c.a
    public void d(String str) {
        this.b.edit().putString("dev_branch", str).apply();
    }

    @Override // deobf.com.roblox.client.provider.ph.c.a
    public void e(String str) {
        if (str != null) {
            this.b.edit().putString("user_agent", str).apply();
        } else {
            this.b.edit().remove("user_agent").apply();
        }
    }

    @Override // deobf.com.roblox.client.provider.ph.c.a
    public void f(String str) {
        if (str != null) {
            this.b.edit().putString("dev_rpc_ip_port_override", str).apply();
        } else {
            this.b.edit().remove("dev_rpc_ip_port_override").apply();
        }
    }

    @Override // deobf.com.roblox.client.provider.ph.c.a
    public void g(String str) {
        if (str != null) {
            this.b.edit().putString("RobloxChannel", str).apply();
        } else {
            this.b.edit().remove("RobloxChannel").apply();
        }
    }

    @Override // deobf.com.roblox.client.provider.ph.c.a
    public deobf.com.roblox.client.provider.ph.c read() {
        String j10 = this.f21458a.j();
        return new deobf.com.roblox.client.provider.ph.c(this.b.getString("RobloxChannel", null), BuildConfig.FLAVOR, this.b.getString("BaseUrl", null), "www.roblox.com", j10, this.b.getString("user_agent", null), this.f21459c, this.b.getString("dev_rpc_ip_port_override", null), this.b.getString("dev_branch", null), this.b.getString("dev_commit", null));
    }
}
