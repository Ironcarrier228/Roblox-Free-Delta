package deobf.unlinked.xs;

import com.github.luben.zstd.BuildConfig;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import kotlin.Metadata;
import kotlin.collections.CollectionsKt;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(d1 = {"\u0000\u0018\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0000\n\u0002\b\u0005\bÀ\u0002\u0018\u00002\u00020\u00012\u00020\u0002B\t\b\u0002¢\u0006\u0004\b\u0003\u0010\u0004J%\u0010\b\u001a\u0004\u0018\u00010\u00052\b\u0010\u0006\u001a\u0004\u0018\u00010\u00052\b\u0010\u0007\u001a\u0004\u0018\u00010\u0005H\u0016¢\u0006\u0004\b\b\u0010\t¨\u0006\n"}, d2 = {"Lxs/e;", "Lrs/b;", "Lat/d;", "<init>", "()V", BuildConfig.FLAVOR, "expression", "data", "l", "(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;", "core_release"}, k = 1, mv = {2, 2, 0}, xi = 48)
// dex: classes3.dex
public final class e implements deobf.unlinked.rs.b, deobf.unlinked.at.d {

    @NotNull
    public static final e f37095a = new e();

    @Override // deobf.unlinked.at.d
    public boolean b(@Nullable Object obj) {
        return super.b(obj);
    }

    @Override // deobf.unlinked.rs.b
    @Nullable
    public Object l(@Nullable Object expression, @Nullable Object data) {
        List<Object> c10 = deobf.unlinked.kt.a.c(expression);
        List<Object> list = c10;
        Object obj = null;
        if (!(list instanceof Collection) || !list.isEmpty()) {
            Iterator<T> it = list.iterator();
            while (it.hasNext()) {
                if (!(it.next() instanceof Boolean)) {
                    Iterator<T> it2 = list.iterator();
                    while (true) {
                        if (!it2.hasNext()) {
                            break;
                        }
                        Object next = it2.next();
                        if (f37095a.b(next)) {
                            obj = next;
                            break;
                        }
                    }
                    return obj == null ? CollectionsKt.o0(c10) : obj;
                }
            }
        }
        Iterator<T> it3 = list.iterator();
        while (true) {
            if (!it3.hasNext()) {
                break;
            }
            Object next2 = it3.next();
            if (f37095a.b(next2)) {
                obj = next2;
                break;
            }
        }
        return Boolean.valueOf(obj != null);
    }
}
