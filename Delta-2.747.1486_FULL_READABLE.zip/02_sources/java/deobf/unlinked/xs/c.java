package deobf.unlinked.xs;

import com.github.luben.zstd.BuildConfig;
import java.util.List;
import kotlin.Metadata;
import kotlin.collections.CollectionsKt;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(d1 = {"\u0000 \n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0000\n\u0002\b\u0004\n\u0002\u0010 \n\u0002\b\u0003\bÀ\u0002\u0018\u00002\u00020\u00012\u00020\u0002B\t\b\u0002¢\u0006\u0004\b\u0003\u0010\u0004J%\u0010\b\u001a\u0004\u0018\u00010\u00052\b\u0010\u0006\u001a\u0004\u0018\u00010\u00052\b\u0010\u0007\u001a\u0004\u0018\u00010\u0005H\u0016¢\u0006\u0004\b\b\u0010\tJ\u001d\u0010\u000b\u001a\u0004\u0018\u00010\u0005*\n\u0012\u0006\u0012\u0004\u0018\u00010\u00050\nH\u0002¢\u0006\u0004\b\u000b\u0010\f¨\u0006\r"}, d2 = {"Lxs/c;", "Lrs/b;", "Lat/d;", "<init>", "()V", BuildConfig.FLAVOR, "expression", "data", "l", "(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;", BuildConfig.FLAVOR, "e", "(Ljava/util/List;)Ljava/lang/Object;", "core_release"}, k = 1, mv = {2, 2, 0}, xi = 48)
// dex: classes3.dex
public final class c implements deobf.unlinked.rs.b, deobf.unlinked.at.d {

    @NotNull
    public static final c f37093a = new c();

    @Override // deobf.unlinked.at.d
    public boolean b(@Nullable Object obj) {
        return super.b(obj);
    }

    public final Object e(List<? extends Object> list) {
        int size = list.size();
        if (size == 0) {
            return null;
        }
        if (size == 1) {
            return CollectionsKt.firstOrNull(list);
        }
        if (size != 2) {
            return size != 3 ? b(CollectionsKt.firstOrNull(list)) ? deobf.unlinked.kt.c.b(list) : e(list.subList(2, list.size())) : b(CollectionsKt.firstOrNull(list)) ? deobf.unlinked.kt.c.b(list) : deobf.unlinked.kt.c.c(list);
        }
        if (b(CollectionsKt.firstOrNull(list))) {
            return deobf.unlinked.kt.c.b(list);
        }
        return null;
    }

    @Override // deobf.unlinked.rs.b
    @Nullable
    public Object l(@Nullable Object expression, @Nullable Object data) {
        return e(deobf.unlinked.kt.a.c(expression));
    }
}
