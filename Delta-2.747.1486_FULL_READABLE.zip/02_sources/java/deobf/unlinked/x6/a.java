package deobf.unlinked.x6;

import com.github.luben.zstd.BuildConfig;
import deobf.com.withpersona.sdk2.inquiry.gu.f;
import kotlin.Metadata;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.Intrinsics;
import deobf.com.withpersona.sdk2.inquiry.mv.e;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import deobf.unlinked.u6.NetworkRequest;
import deobf.unlinked.u6.NetworkResponse;
import deobf.unlinked.u6.i;

@Metadata(d1 = {"\u0000B\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0003\n\u0002\u0010\u000b\n\u0002\b\u0005\b\u0081@\u0018\u00002\u00020\u0001B\u000f\u0012\u0006\u0010\u0003\u001a\u00020\u0002¢\u0006\u0004\b\u0004\u0010\u0005JB\u0010\u000e\u001a\u00028\u0000\"\u0004\b\u0000\u0010\u00062\u0006\u0010\b\u001a\u00020\u00072\"\u0010\r\u001a\u001e\b\u0001\u0012\u0004\u0012\u00020\n\u0012\n\u0012\b\u0012\u0004\u0012\u00028\u00000\u000b\u0012\u0006\u0012\u0004\u0018\u00010\f0\tH\u0096@¢\u0006\u0004\b\u000e\u0010\u000fJ\u0010\u0010\u0011\u001a\u00020\u0010HÖ\u0001¢\u0006\u0004\b\u0011\u0010\u0012J\u0010\u0010\u0014\u001a\u00020\u0013HÖ\u0001¢\u0006\u0004\b\u0014\u0010\u0015J\u001a\u0010\u0018\u001a\u00020\u00172\b\u0010\u0016\u001a\u0004\u0018\u00010\fHÖ\u0003¢\u0006\u0004\b\u0018\u0010\u0019R\u0014\u0010\u0003\u001a\u00020\u00028\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b\u001a\u0010\u001b\u0088\u0001\u0003\u0092\u0001\u00020\u0002¨\u0006\u001c"}, d2 = {"Lx6/a;", "Lu6/i;", "Lmv/e$a;", "callFactory", "c", "(Lmv/e$a;)Lmv/e$a;", "T", "Lu6/o;", "request", "Lkotlin/Function2;", "Lu6/q;", "Leu/b;", BuildConfig.FLAVOR, "block", "e", "(Lmv/e$a;Lu6/o;Lkotlin/jvm/functions/Function2;Leu/b;)Ljava/lang/Object;", BuildConfig.FLAVOR, "toString", "()Ljava/lang/String;", BuildConfig.FLAVOR, "hashCode", "()I", "other", BuildConfig.FLAVOR, "equals", "(Ljava/lang/Object;)Z", deobf.android.view.xe.a.f36648e, "Lmv/e$a;", "coil-network-okhttp"}, k = 1, mv = {2, 2, 0}, xi = 48)
// dex: classes.dex
public final class a implements i {

    @NotNull
    public final deobf.com.roblox.client.e.a callFactory;

    @Metadata(k = 3, mv = {2, 2, 0}, xi = 48)
    @f(c = "coil3.network.okhttp.internal.CallFactoryNetworkClient", f = "utils.kt", l = {24, 24, 25}, m = "executeRequest-impl")
    public static final class C0748a<T> extends deobf.com.withpersona.sdk2.inquiry.gu.d {
        public int A;

        public Object f36179t;

        public Object f36180u;

        public Object f36181v;

        public Object f36182w;

        public Object f36183x;

        public int f36184y;

        public /* synthetic */ Object f36185z;

        public C0748a(deobf.kotlin.eu.b<? super C0748a> bVar) {
            super(bVar);
        }

        @Override // deobf.com.withpersona.sdk2.inquiry.gu.a
        @Nullable
        public final Object invokeSuspend(@NotNull Object obj) {
            this.f36185z = obj;
            this.A |= Integer.MIN_VALUE;
            return a.e(null, null, null, this);
        }
    }

    public /* synthetic */ a(deobf.com.roblox.client.e.a aVar) {
        this.callFactory = aVar;
    }

    public static final /* synthetic */ a b(deobf.com.roblox.client.e.a aVar) {
        return new a(aVar);
    }

    @NotNull
    public static deobf.com.roblox.client.e.a c(@NotNull deobf.com.roblox.client.e.a aVar) {
        return aVar;
    }

    public static boolean d(deobf.com.roblox.client.e.a aVar, Object obj) {
        return (obj instanceof a) && Intrinsics.c(aVar, ((a) obj).getCallFactory());
    }

    /* JADX WARN: Removed duplicated region for block: B:33:0x00e2  */
    /* JADX WARN: Removed duplicated region for block: B:40:0x00b1  */
    /* JADX WARN: Removed duplicated region for block: B:41:0x0075  */
    /* JADX WARN: Removed duplicated region for block: B:8:0x0026  */
    @org.jetbrains.annotations.Nullable
    public static <T> java.lang.Object e(deobf.com.withpersona.sdk2.inquiry.mv.e.a r8, @org.jetbrains.annotations.NotNull deobf.unlinked.u6.NetworkRequest r9, @org.jetbrains.annotations.NotNull kotlin.jvm.functions.Function2<? super deobf.unlinked.u6.NetworkResponse, ? super deobf.kotlin.eu.b<? super T>, ? extends java.lang.Object> r10, @org.jetbrains.annotations.NotNull deobf.kotlin.eu.b<? super T> r11) {
        /*
            Method dump skipped, instructions count: 241
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: deobf.unlinked.x6.a.e(mv.e$a, u6.o, kotlin.jvm.functions.Function2, deobf.kotlin.eu.b):java.lang.Object");
    }

    public static int f(deobf.com.roblox.client.e.a aVar) {
        return aVar.hashCode();
    }

    public static String g(deobf.com.roblox.client.e.a aVar) {
        return "CallFactoryNetworkClient(callFactory=" + aVar + ')';
    }

    @Override // deobf.unlinked.u6.i
    @Nullable
    public <T> Object a(@NotNull NetworkRequest networkRequest, @NotNull Function2<? super NetworkResponse, ? super deobf.kotlin.eu.b<? super T>, ? extends Object> function2, @NotNull deobf.kotlin.eu.b<? super T> bVar) {
        return e(this.callFactory, networkRequest, function2, bVar);
    }

    public boolean equals(Object other) {
        return d(this.callFactory, other);
    }

    public final /* synthetic */ deobf.com.roblox.client.e.a getCallFactory() {
        return this.callFactory;
    }

    public int hashCode() {
        return f(this.callFactory);
    }

    public String toString() {
        return g(this.callFactory);
    }
}
