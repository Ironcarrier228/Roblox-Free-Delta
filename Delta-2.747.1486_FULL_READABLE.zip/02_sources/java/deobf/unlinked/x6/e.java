package deobf.unlinked.x6;

import com.google.mlkit.vision.barcode.common.Barcode;
import deobf.com.withpersona.sdk2.inquiry.ew.g;
import deobf.com.withpersona.sdk2.inquiry.gu.f;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import kotlin.Metadata;
import kotlin.Pair;
import deobf.com.withpersona.sdk2.inquiry.mv.h0;
import deobf.com.withpersona.sdk2.inquiry.mv.i0;
import deobf.com.withpersona.sdk2.inquiry.mv.y;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import deobf.unlinked.u6.NetworkHeaders;
import deobf.unlinked.u6.NetworkResponse;
import deobf.unlinked.u6.j;

@Metadata(d1 = {"\u00000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0005\u001a\u0014\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\u0082@¢\u0006\u0004\b\u0002\u0010\u0003\u001a\u0014\u0010\u0006\u001a\u00020\u0005*\u00020\u0004H\u0082@¢\u0006\u0004\b\u0006\u0010\u0007\u001a\u0013\u0010\n\u001a\u00020\t*\u00020\bH\u0002¢\u0006\u0004\b\n\u0010\u000b\u001a\u0013\u0010\u000e\u001a\u00020\r*\u00020\fH\u0002¢\u0006\u0004\b\u000e\u0010\u000f\u001a\u0013\u0010\u0010\u001a\u00020\f*\u00020\rH\u0002¢\u0006\u0004\b\u0010\u0010\u0011¨\u0006\u0012"}, d2 = {"Lu6/o;", "Lmv/f0;", "h", "(Lu6/o;Leu/b;)Ljava/lang/Object;", "Lu6/p;", "Lew/h;", "d", "(Lu6/p;Leu/b;)Ljava/lang/Object;", "Lmv/h0;", "Lu6/q;", "g", "(Lmv/h0;)Lu6/q;", "Lu6/n;", "Lmv/y;", "e", "(Lu6/n;)Lmv/y;", "f", "(Lmv/y;)Lu6/n;", "coil-network-okhttp"}, k = 2, mv = {2, 2, 0}, xi = 48)
// dex: classes.dex
public final class e {

    @Metadata(k = 3, mv = {2, 2, 0}, xi = 48)
    @f(c = "coil3.network.okhttp.internal.UtilsKt", f = "utils.kt", l = {39}, m = "readByteString")
    public static final class a extends deobf.com.withpersona.sdk2.inquiry.gu.d {

        public Object f36187t;

        public Object f36188u;

        public /* synthetic */ Object f36189v;

        public int f36190w;

        public a(deobf.kotlin.eu.b<? super a> bVar) {
            super(bVar);
        }

        @Override // deobf.com.withpersona.sdk2.inquiry.gu.a
        @Nullable
        public final Object invokeSuspend(@NotNull Object obj) {
            this.f36189v = obj;
            this.f36190w |= Integer.MIN_VALUE;
            return e.d(null, this);
        }
    }

    @Metadata(k = 3, mv = {2, 2, 0}, xi = 48)
    @f(c = "coil3.network.okhttp.internal.UtilsKt", f = "utils.kt", l = {Barcode.FORMAT_EAN_13}, m = "toRequest")
    public static final class b extends deobf.com.withpersona.sdk2.inquiry.gu.d {

        public Object f36191t;

        public Object f36192u;

        public Object f36193v;

        public Object f36194w;

        public /* synthetic */ Object f36195x;

        public int f36196y;

        public b(deobf.kotlin.eu.b<? super b> bVar) {
            super(bVar);
        }

        @Override // deobf.com.withpersona.sdk2.inquiry.gu.a
        @Nullable
        public final Object invokeSuspend(@NotNull Object obj) {
            this.f36195x = obj;
            this.f36196y |= Integer.MIN_VALUE;
            return e.h(null, this);
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:15:0x0039  */
    /* JADX WARN: Removed duplicated region for block: B:8:0x0023  */
    public static final java.lang.Object d(deobf.unlinked.u6.p r4, deobf.kotlin.eu.b<? super deobf.com.withpersona.sdk2.inquiry.ew.h> r5) {
        /*
            boolean r0 = r5 instanceof deobf.unlinked.x6.e.a
            if (r0 == 0) goto L13
            r0 = r5
            x6.e$a r0 = (deobf.unlinked.x6.e.a) r0
            int r1 = r0.f36190w
            r2 = -2147483648(0xffffffff80000000, float:-0.0)
            r3 = r1 & r2
            if (r3 == 0) goto L13
            int r1 = r1 - r2
            r0.f36190w = r1
            goto L18
        L13:
            x6.e$a r0 = new x6.e$a
            r0.<init>(r5)
        L18:
            java.lang.Object r5 = r0.f36189v
            java.lang.Object r1 = deobf.kotlin.fu.c.e()
            int r2 = r0.f36190w
            r3 = 1
            if (r2 == 0) goto L39
            if (r2 != r3) goto L31
            java.lang.Object r4 = r0.f36188u
            deobf.com.withpersona.sdk2.inquiry.ew.e r4 = (deobf.com.withpersona.sdk2.inquiry.ew.e) r4
            java.lang.Object r0 = r0.f36187t
            deobf.unlinked.u6.p r0 = (deobf.unlinked.u6.p) r0
            deobf.com.withpersona.sdk2.inquiry.zt.o.b(r5)
            goto L53
        L31:
            java.lang.IllegalStateException r4 = new java.lang.IllegalStateException
            java.lang.String r5 = "call to 'resume' before 'invoke' with coroutine"
            r4.<init>(r5)
            throw r4
        L39:
            deobf.com.withpersona.sdk2.inquiry.zt.o.b(r5)
            deobf.com.withpersona.sdk2.inquiry.ew.e r5 = new deobf.com.withpersona.sdk2.inquiry.ew.e
            r5.<init>()
            java.lang.Object r2 = deobf.com.withpersona.sdk2.inquiry.gu.l.a(r4)
            r0.f36187t = r2
            r0.f36188u = r5
            r0.f36190w = r3
            java.lang.Object r4 = r4.D(r5, r0)
            if (r4 != r1) goto L52
            return r1
        L52:
            r4 = r5
        L53:
            deobf.com.withpersona.sdk2.inquiry.ew.h r4 = r4.J2()
            return r4
        */
        throw new UnsupportedOperationException("Method not decompiled: deobf.unlinked.x6.e.d(deobf.unlinked.u6.p, deobf.kotlin.eu.b):java.lang.Object");
    }

    public static final y e(NetworkHeaders networkHeaders) {
        deobf.androidx.camera.camera2.y.a aVar = new deobf.androidx.camera.camera2.y.a();
        for (Map.Entry<String, List<String>> entry : networkHeaders.b().entrySet()) {
            String key = entry.getKey();
            Iterator<String> it = entry.getValue().iterator();
            while (it.hasNext()) {
                aVar.e(key, it.next());
            }
        }
        return aVar.f();
    }

    public static final NetworkHeaders f(y yVar) {
        NetworkHeaders.a aVar = new NetworkHeaders.a();
        Iterator<Pair<? extends String, ? extends String>> it = yVar.iterator();
        while (it.hasNext()) {
            Pair<? extends String, ? extends String> next = it.next();
            aVar.a(next.a(), next.b());
        }
        return aVar.b();
    }

    public static final NetworkResponse g(h0 h0Var) {
        g source;
        int code = h0Var.getCode();
        long sentRequestAtMillis = h0Var.getSentRequestAtMillis();
        long receivedResponseAtMillis = h0Var.getReceivedResponseAtMillis();
        NetworkHeaders f10 = f(h0Var.getHeaders());
        i0 body = h0Var.getBody();
        return new NetworkResponse(code, sentRequestAtMillis, receivedResponseAtMillis, f10, (body == null || (source = body.getSource()) == null) ? null : deobf.com.google.android.material.j.a(source), h0Var);
    }

    /* JADX WARN: Removed duplicated region for block: B:12:0x0075  */
    /* JADX WARN: Removed duplicated region for block: B:16:0x007c  */
    /* JADX WARN: Removed duplicated region for block: B:20:0x0042  */
    /* JADX WARN: Removed duplicated region for block: B:8:0x0024  */
    public static final java.lang.Object h(deobf.unlinked.u6.NetworkRequest r6, deobf.kotlin.eu.b<? super deobf.com.withpersona.sdk2.inquiry.mv.f0> r7) {
        /*
            boolean r0 = r7 instanceof deobf.unlinked.x6.e.b
            if (r0 == 0) goto L13
            r0 = r7
            x6.e$b r0 = (deobf.unlinked.x6.e.b) r0
            int r1 = r0.f36196y
            r2 = -2147483648(0xffffffff80000000, float:-0.0)
            r3 = r1 & r2
            if (r3 == 0) goto L13
            int r1 = r1 - r2
            r0.f36196y = r1
            goto L18
        L13:
            x6.e$b r0 = new x6.e$b
            r0.<init>(r7)
        L18:
            java.lang.Object r7 = r0.f36195x
            java.lang.Object r1 = deobf.kotlin.fu.c.e()
            int r2 = r0.f36196y
            r3 = 0
            r4 = 1
            if (r2 == 0) goto L42
            if (r2 != r4) goto L3a
            java.lang.Object r6 = r0.f36194w
            java.lang.String r6 = (java.lang.String) r6
            java.lang.Object r1 = r0.f36193v
            mv.f0$a r1 = (deobf.com.withpersona.sdk2.inquiry.mv.f0.a) r1
            java.lang.Object r2 = r0.f36192u
            mv.f0$a r2 = (deobf.com.withpersona.sdk2.inquiry.mv.f0.a) r2
            java.lang.Object r0 = r0.f36191t
            u6.o r0 = (deobf.unlinked.u6.NetworkRequest) r0
            deobf.com.withpersona.sdk2.inquiry.zt.o.b(r7)
            goto L71
        L3a:
            java.lang.IllegalStateException r6 = new java.lang.IllegalStateException
            java.lang.String r7 = "call to 'resume' before 'invoke' with coroutine"
            r6.<init>(r7)
            throw r6
        L42:
            deobf.com.withpersona.sdk2.inquiry.zt.o.b(r7)
            mv.f0$a r7 = new mv.f0$a
            r7.<init>()
            java.lang.String r2 = r6.getUrl()
            deobf.unlinked.r7.t(r2)
            java.lang.String r2 = r6.getMethod()
            deobf.unlinked.u6.p r5 = r6.getBody()
            if (r5 == 0) goto L81
            r0.f36191t = r6
            r0.f36192u = r7
            r0.f36193v = r7
            r0.f36194w = r2
            r0.f36196y = r4
            java.lang.Object r0 = d(r5, r0)
            if (r0 != r1) goto L6c
            return r1
        L6c:
            r1 = r7
            r7 = r0
            r0 = r6
            r6 = r2
            r2 = r1
        L71:
            deobf.com.withpersona.sdk2.inquiry.ew.h r7 = (deobf.com.withpersona.sdk2.inquiry.ew.h) r7
            if (r7 == 0) goto L7c
            mv.g0$a r5 = deobf.com.withpersona.sdk2.inquiry.mv.g0.INSTANCE
            deobf.com.withpersona.sdk2.inquiry.mv.g0 r3 = deobf.com.withpersona.sdk2.inquiry.mv.g0.Companion.i(r5, r7, r3, r4, r3)
            goto L87
        L7c:
            r7 = r0
            r0 = r6
            r6 = r7
            r7 = r1
            goto L83
        L81:
            r0 = r2
            r2 = r7
        L83:
            r1 = r0
            r0 = r6
            r6 = r1
            r1 = r7
        L87:
            r1.o(r6, r3)
            u6.n r6 = r0.getHeaders()
            deobf.com.withpersona.sdk2.inquiry.mv.y r6 = e(r6)
            r2.n(r6)
            deobf.com.withpersona.sdk2.inquiry.mv.f0 r6 = deobf.unlinked.r2.b()
            return r6
        */
        throw new UnsupportedOperationException("Method not decompiled: deobf.unlinked.x6.e.h(u6.o, deobf.kotlin.eu.b):java.lang.Object");
    }
}
