package deobf.androidx.camera.camera2.internal.compat.quirk.b1;

import java.util.UUID;
import deobf.androidx.camera.camera2.internal.compat.quirk.n0.c3;
import deobf.androidx.camera.camera2.internal.compat.quirk.n0.i4;
import deobf.androidx.camera.camera2.internal.compat.quirk.n0.j4;
import deobf.androidx.camera.camera2.internal.compat.quirk.n0.w2;
import deobf.androidx.camera.camera2.internal.compat.quirk.n0.x2;

// dex: classes.dex
public class h implements i4.b<g, i, h> {

    public final x2 f3553a;

    public h() {
        this(x2.k0());
    }

    @Override // deobf.androidx.camera.view.g0.l0
    public w2 a() {
        return this.f3553a;
    }

    @Override // deobf.androidx.camera.camera2.internal.compat.quirk.n0.i4.b
    public i e() {
        return new i(c3.j0(this.f3553a));
    }

    public h c(deobf.unlinked.j4.b bVar) {
        a().G(i4.G, bVar);
        return this;
    }

    public h d(Class<g> cls) {
        a().G(deobf.androidx.camera.camera2.s0.q.N, cls);
        if (a().h(deobf.androidx.camera.camera2.s0.q.M, null) == null) {
            f(cls.getCanonicalName() + "-" + UUID.randomUUID());
        }
        return this;
    }

    public h f(String str) {
        a().G(deobf.androidx.camera.camera2.s0.q.M, str);
        return this;
    }

    public h(x2 x2Var) {
        this.f3553a = x2Var;
        Class cls = (Class) x2Var.h(deobf.androidx.camera.camera2.s0.q.N, null);
        if (cls == null || cls.equals(g.class)) {
            c(deobf.unlinked.j4.b.STREAM_SHARING);
            d(g.class);
            return;
        }
        throw new IllegalArgumentException("Invalid target class configuration for " + this + ": " + cls);
    }
}
