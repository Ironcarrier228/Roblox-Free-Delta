package deobf.androidx.camera.camera2.internal.compat.quirk.b1;

import deobf.androidx.camera.camera2.internal.compat.quirk.n0.a0;
import deobf.androidx.camera.camera2.internal.compat.quirk.n0.b0;
import deobf.androidx.camera.camera2.internal.compat.quirk.n0.c0;
import deobf.androidx.camera.camera2.internal.compat.quirk.n0.d0;
import deobf.androidx.camera.camera2.internal.compat.quirk.n0.e0;
import deobf.androidx.camera.camera2.internal.compat.quirk.n0.x;
import deobf.androidx.camera.camera2.internal.compat.quirk.n0.y;
import deobf.androidx.camera.camera2.internal.compat.quirk.n0.z;
import deobf.androidx.camera.camera2.internal.compat.quirk.n0.z3;

// dex: classes.dex
public class l implements e0 {

    public final e0 f3569a;
    public final z3 b;

    public final long f3570c;

    public l(z3 z3Var, e0 e0Var) {
        this(e0Var, z3Var, -1L);
    }

    @Override // deobf.androidx.camera.camera2.internal.compat.quirk.n0.e0
    public d0 b() {
        e0 e0Var = this.f3569a;
        return e0Var != null ? e0Var.b() : d0.UNKNOWN;
    }

    @Override // deobf.androidx.camera.camera2.internal.compat.quirk.n0.e0
    public z3 c() {
        return this.b;
    }

    @Override // deobf.androidx.camera.camera2.internal.compat.quirk.n0.e0
    public b0 d() {
        e0 e0Var = this.f3569a;
        return e0Var != null ? e0Var.d() : b0.UNKNOWN;
    }

    @Override // deobf.androidx.camera.camera2.internal.compat.quirk.n0.e0
    public x f() {
        e0 e0Var = this.f3569a;
        return e0Var != null ? e0Var.f() : x.UNKNOWN;
    }

    @Override // deobf.androidx.camera.camera2.internal.compat.quirk.n0.e0
    public a0 g() {
        e0 e0Var = this.f3569a;
        return e0Var != null ? e0Var.g() : a0.UNKNOWN;
    }

    @Override // deobf.androidx.camera.camera2.internal.compat.quirk.n0.e0
    public long getTimestamp() {
        e0 e0Var = this.f3569a;
        if (e0Var != null) {
            return e0Var.getTimestamp();
        }
        long j10 = this.f3570c;
        if (j10 != -1) {
            return j10;
        }
        throw new IllegalStateException("No timestamp is available.");
    }

    @Override // deobf.androidx.camera.camera2.internal.compat.quirk.n0.e0
    public c0 h() {
        e0 e0Var = this.f3569a;
        return e0Var != null ? e0Var.h() : c0.UNKNOWN;
    }

    @Override // deobf.androidx.camera.camera2.internal.compat.quirk.n0.e0
    public z i() {
        e0 e0Var = this.f3569a;
        return e0Var != null ? e0Var.i() : z.UNKNOWN;
    }

    @Override // deobf.androidx.camera.camera2.internal.compat.quirk.n0.e0
    public y j() {
        e0 e0Var = this.f3569a;
        return e0Var != null ? e0Var.j() : y.UNKNOWN;
    }

    public l(z3 z3Var, long j10) {
        this(null, z3Var, j10);
    }

    public l(e0 e0Var, z3 z3Var, long j10) {
        this.f3569a = e0Var;
        this.b = z3Var;
        this.f3570c = j10;
    }
}
