package deobf.androidx.camera.camera2.internal.compat.quirk.b1;

import java.util.List;
import deobf.androidx.camera.camera2.internal.compat.quirk.n0.c3;
import deobf.androidx.camera.camera2.internal.compat.quirk.n0.i2;
import deobf.androidx.camera.camera2.internal.compat.quirk.n0.i4;
import deobf.androidx.camera.camera2.internal.compat.quirk.n0.j4;
import deobf.androidx.camera.camera2.internal.compat.quirk.n0.n1;
import deobf.androidx.camera.camera2.s0.r;

// dex: classes.dex
public class i implements i4<g>, i2, r {
    public static final deobf.androidx.camera.video.internal.compat.quirk.n1.a<List<deobf.unlinked.j4.b>> Q = deobf.androidx.camera.video.internal.compat.quirk.n1.a.a("camerax.core.streamSharing.captureTypes", List.class);
    public final c3 P;

    public i(c3 c3Var) {
        this.P = c3Var;
    }

    public List<deobf.unlinked.j4.b> h0() {
        return (List) e(Q);
    }

    @Override // deobf.androidx.camera.camera2.internal.compat.quirk.n0.l3
    public n1 n() {
        return this.P;
    }
}
