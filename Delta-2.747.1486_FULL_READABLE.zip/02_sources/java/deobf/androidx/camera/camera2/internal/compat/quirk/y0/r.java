package deobf.androidx.camera.camera2.internal.compat.quirk.y0;

import android.graphics.Matrix;
import android.graphics.Rect;
import android.graphics.RectF;
import android.util.Size;
import deobf.androidx.camera.view.g0.j2;
import deobf.androidx.camera.view.g0.r1;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CancellationException;
import deobf.androidx.camera.camera2.internal.compat.quirk.n0.p0;
import deobf.androidx.camera.view.p0.a0;
import deobf.androidx.camera.view.p0.z;
import deobf.androidx.camera.video.internal.compat.quirk.x0.n0;
import deobf.androidx.camera.video.internal.compat.quirk.x0.r0;
import deobf.androidx.camera.video.internal.compat.quirk.x0.z0;

// dex: classes.dex
public class r {

    public final r0 f37158a;
    public final p0 b;

    public final p0 f37159c;

    public c f37160d;

    public b f37161e;

    public class a implements deobf.androidx.camera.view.r0.c<j2> {

        public final /* synthetic */ n0 f37162a;

        public a(n0 n0Var) {
            this.f37162a = n0Var;
        }

        @Override // deobf.androidx.camera.view.r0.c
        public void onSuccess(j2 j2Var) {
            deobf.androidx.camera.view.x2.g.g(j2Var);
            r.this.f37158a.d(j2Var);
        }

        @Override // deobf.androidx.camera.view.r0.c
        public void onFailure(Throwable th2) {
            if (this.f37162a.t() == 2 && (th2 instanceof CancellationException)) {
                deobf.androidx.camera.view.r1.a("DualSurfaceProcessorNode", "Downstream VideoCapture failed to provide Surface.");
                return;
            }
            r1.m("DualSurfaceProcessorNode", "Downstream node failed to provide Surface. Target: " + deobf.androidx.camera.video.internal.compat.quirk.z0.b(this.f37162a.t()), th2);
        }
    }

    public static abstract class b {
        public static b d(n0 n0Var, n0 n0Var2, List<d> list) {
            return new deobf.androidx.camera.camera2.internal.compat.quirk.y0.b(n0Var, n0Var2, list);
        }

        public abstract List<d> a();

        public abstract n0 b();

        public abstract n0 c();
    }

    public static class c extends HashMap<d, n0> {
    }

    public r(p0 p0Var, p0 p0Var2, r0 r0Var) {
        this.b = p0Var;
        this.f37159c = p0Var2;
        this.f37158a = r0Var;
    }

    public static /* synthetic */ void a(r rVar) {
        c cVar = rVar.f37160d;
        if (cVar != null) {
            Iterator<n0> it = cVar.values().iterator();
            while (it.hasNext()) {
                it.next().i();
            }
        }
    }

    public final void c(p0 p0Var, p0 p0Var2, n0 n0Var, n0 n0Var2, Map.Entry<d, n0> entry) {
        n0 value = entry.getValue();
        deobf.androidx.camera.view.r1.a("DualSurfaceProcessorNode", "     -> outputEdge = " + value);
        Size f10 = n0Var.s().f();
        Rect a10 = entry.getKey().a().a();
        if (!n0Var.u()) {
            p0Var = null;
        }
        deobf.unlinked.j2.a f11 = deobf.unlinked.j2.a.f(f10, a10, p0Var, entry.getKey().a().c(), entry.getKey().a().g());
        Size f12 = n0Var2.s().f();
        Rect a11 = entry.getKey().b().a();
        if (!n0Var2.u()) {
            p0Var2 = null;
        }
        deobf.androidx.camera.view.r0.n.j(value.j(entry.getKey().a().b(), f11, deobf.unlinked.j2.a.f(f12, a11, p0Var2, entry.getKey().b().c(), entry.getKey().b().g())), new a(value), deobf.unlinked.q0.c.e());
    }

    public void d() {
        this.f37158a.a();
        deobf.androidx.camera.camera2.z.e(new Runnable() { // from class: y0.p
            @Override // java.lang.Runnable
            public final void run() {
                r.a(r.this);
            }
        });
    }

    public final void e(p0 p0Var, p0 p0Var2, n0 n0Var, n0 n0Var2, Map<d, n0> map) {
        for (final Map.Entry<d, n0> entry : map.entrySet()) {
            final p0 p0Var3 = p0Var;
            final p0 p0Var4 = p0Var2;
            final n0 n0Var3 = n0Var;
            final n0 n0Var4 = n0Var2;
            c(p0Var3, p0Var4, n0Var3, n0Var4, entry);
            entry.getValue().e(new Runnable() { // from class: y0.q
                @Override // java.lang.Runnable
                public final void run() {
                    r.this.c(p0Var3, p0Var4, n0Var3, n0Var4, entry);
                }
            });
            p0Var = p0Var3;
            p0Var2 = p0Var4;
            n0Var = n0Var3;
            n0Var2 = n0Var4;
        }
    }

    public final void f(p0 p0Var, n0 n0Var, boolean z10) {
        this.f37158a.b(n0Var.l(p0Var, z10));
    }

    public c g(b bVar) {
        deobf.androidx.camera.camera2.z.b();
        deobf.androidx.camera.view.r1.a("DualSurfaceProcessorNode", "DualSurfaceProcessorNode Transform Processor = " + this.f37158a + "\n   primary input = " + bVar.b() + "\n   secondary input = " + bVar.c());
        Iterator<d> it = bVar.a().iterator();
        while (it.hasNext()) {
            deobf.androidx.camera.view.r1.a("SurfaceProcessorNode", "   outputConfig = " + it.next());
        }
        this.f37161e = bVar;
        this.f37160d = new c();
        n0 b10 = this.f37161e.b();
        n0 c10 = this.f37161e.c();
        for (d dVar : this.f37161e.a()) {
            this.f37160d.put(dVar, h(b10, dVar.a()));
        }
        f(this.b, b10, true);
        f(this.f37159c, c10, false);
        e(this.b, this.f37159c, b10, c10, this.f37160d);
        return this.f37160d;
    }

    public final n0 h(n0 n0Var, deobf.androidx.camera.video.internal.compat.quirk.z0.f fVar) {
        Rect a10 = fVar.a();
        int c10 = fVar.c();
        boolean g10 = fVar.g();
        Matrix matrix = new Matrix(n0Var.r());
        matrix.postConcat(deobf.androidx.camera.camera2.internal.compat.quirk.a0.e(new RectF(a10), a0.t(fVar.d()), c10, g10));
        deobf.androidx.camera.view.x2.g.a(a0.j(deobf.androidx.camera.camera2.internal.compat.quirk.a0.f(a10, c10), fVar.d()));
        Rect r10 = a0.r(fVar.d());
        return new n0(fVar.e(), fVar.b(), n0Var.s().i().f(fVar.d()).a(), matrix, false, r10, n0Var.q() - c10, -1, n0Var.w() != g10);
    }
}
