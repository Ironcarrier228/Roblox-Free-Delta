package deobf.androidx.camera.camera2.internal.compat.quirk.b1;

import java.util.UUID;
import deobf.androidx.camera.camera2.internal.compat.quirk.n0.d2;
import deobf.androidx.camera.camera2.internal.compat.quirk.n0.o0;
import deobf.androidx.camera.view.p0.a0;

// dex: classes.dex
public class q extends d2 {
    public final String b;

    public int f3575c;

    public q(o0 o0Var) {
        super(o0Var);
        this.b = "virtual-" + o0Var.e() + "-" + UUID.randomUUID().toString();
    }

    public void B(int i10) {
        this.f3575c = i10;
    }

    @Override // deobf.androidx.camera.camera2.internal.compat.quirk.n0.d2, deobf.androidx.camera.view.g0.t
    public int d() {
        return w(0);
    }

    @Override // deobf.androidx.camera.camera2.internal.compat.quirk.n0.d2, deobf.androidx.camera.camera2.internal.compat.quirk.n0.o0
    public String e() {
        return this.b;
    }

    @Override // deobf.androidx.camera.camera2.internal.compat.quirk.n0.d2, deobf.androidx.camera.view.g0.t
    public int w(int i10) {
        return deobf.androidx.camera.camera2.internal.compat.quirk.a0.w(super.w(i10) - this.f3575c);
    }
}
