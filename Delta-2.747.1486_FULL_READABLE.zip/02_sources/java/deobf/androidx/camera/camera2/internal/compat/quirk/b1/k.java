package deobf.androidx.camera.camera2.internal.compat.quirk.b1;

import android.graphics.Rect;
import android.util.Range;
import android.util.Size;
import deobf.androidx.camera.camera2.internal.compat.quirk.b1.g;
import com.google.mlkit.vision.barcode.common.Barcode;
import deobf.androidx.camera.view.g0.a2;
import deobf.androidx.camera.view.g0.f1;
import deobf.androidx.camera.view.g0.k0;
import deobf.androidx.camera.view.g0.r1;
import deobf.androidx.camera.view.g0.w2;
import java.lang.ref.WeakReference;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import deobf.androidx.camera.camera2.internal.compat.quirk.n0.e0;
import deobf.androidx.camera.camera2.internal.compat.quirk.n0.h2;
import deobf.androidx.camera.camera2.internal.compat.quirk.n0.i2;
import deobf.androidx.camera.camera2.internal.compat.quirk.n0.i4;
import deobf.androidx.camera.camera2.internal.compat.quirk.n0.j4;
import deobf.androidx.camera.camera2.internal.compat.quirk.n0.o3;
import deobf.androidx.camera.camera2.internal.compat.quirk.n0.p0;
import deobf.androidx.camera.camera2.internal.compat.quirk.n0.t3;
import deobf.androidx.camera.camera2.internal.compat.quirk.n0.u;
import deobf.androidx.camera.camera2.internal.compat.quirk.n0.u1;
import deobf.androidx.camera.view.p0.a0;
import deobf.androidx.camera.view.p0.z;
import deobf.androidx.camera.video.internal.compat.quirk.x0.n0;

// dex: classes.dex
public class k implements deobf.androidx.appcompat.widget.w2.c {

    public final Set<w2> f3557a;

    public final j4 f3560e;

    public final p0 f3561f;

    public final p0 f3562g;

    public final Set<i4<?>> f3564i;

    public final Map<w2, i4<?>> f3565j;

    public final c f3566k;

    public c f3567l;
    public final Map<w2, n0> b = new HashMap();

    public final Map<w2, j> f3558c = new HashMap();

    public final Map<w2, Boolean> f3559d = new HashMap();

    public final u f3563h = v();

    public static class a extends u {

        public final WeakReference<k> f3568a;

        public a(k kVar) {
            this.f3568a = new WeakReference<>(kVar);
        }

        @Override // deobf.androidx.camera.camera2.internal.compat.quirk.n0.u
        public void b(int i10, e0 e0Var) {
            k kVar = this.f3568a.get();
            if (kVar != null) {
                Iterator<w2> it = kVar.f3557a.iterator();
                while (it.hasNext()) {
                    k.S(e0Var, it.next().z(), i10);
                }
            }
        }
    }

    public k(p0 p0Var, p0 p0Var2, Set<w2> set, j4 j4Var, deobf.com.roblox.protocols.mediapicker.g.a aVar) {
        this.f3561f = p0Var;
        this.f3562g = p0Var2;
        this.f3560e = j4Var;
        this.f3557a = set;
        Map<w2, i4<?>> U = U(p0Var, set, j4Var);
        this.f3565j = U;
        HashSet hashSet = new HashSet(U.values());
        this.f3564i = hashSet;
        this.f3566k = new c(p0Var, hashSet);
        if (p0Var2 != null) {
            this.f3567l = new c(p0Var2, hashSet);
        }
        for (w2 w2Var : set) {
            this.f3559d.put(w2Var, Boolean.FALSE);
            this.f3558c.put(w2Var, new j(p0Var, this, aVar));
        }
    }

    public static t3 A(w2 w2Var, t3 t3Var, Map<w2, Size> map) {
        deobf.unlinked.t3.a i10 = t3Var.i();
        Size size = map.get(w2Var);
        if (size != null) {
            i10.e(size);
        }
        return i10.a();
    }

    public static u1 B(w2 w2Var) {
        List<u1> p8 = w2Var instanceof f1 ? w2Var.z().p() : w2Var.z().l().i();
        deobf.androidx.camera.view.x2.g.i(p8.size() <= 1);
        if (p8.size() == 1) {
            return p8.get(0);
        }
        return null;
    }

    public static int C(w2 w2Var) {
        if (w2Var instanceof a2) {
            return 1;
        }
        return w2Var instanceof f1 ? 4 : 2;
    }

    public static int G(Set<i4<?>> set) {
        Iterator<i4<?>> it = set.iterator();
        int i10 = 0;
        while (it.hasNext()) {
            i10 = Math.max(i10, it.next().B(0));
        }
        return i10;
    }

    public static Range<Integer> R(Set<i4<?>> set) {
        Range<Integer> range = t3.f25157a;
        Iterator<i4<?>> it = set.iterator();
        while (it.hasNext()) {
            Range<Integer> z10 = it.next().z(range);
            Objects.requireNonNull(z10);
            if (t3.f25157a.equals(range)) {
                range = z10;
            } else {
                try {
                    range = range.intersect(z10);
                } catch (IllegalArgumentException unused) {
                    deobf.androidx.camera.view.r1.a("VirtualCameraAdapter", "No intersected frame rate can be found from the target frame rate settings of the UseCases! Resolved: " + range + " <<>> " + z10);
                    return range.extend(z10);
                }
            }
        }
        return range;
    }

    public static void S(e0 e0Var, o3 o3Var, int i10) {
        Iterator<u> it = o3Var.k().iterator();
        while (it.hasNext()) {
            it.next().b(i10, new l(o3Var.l().j(), e0Var));
        }
    }

    public static Map<w2, i4<?>> U(p0 p0Var, Set<w2> set, j4 j4Var) {
        HashMap hashMap = new HashMap();
        for (w2 w2Var : set) {
            hashMap.put(w2Var, w2Var.I(p0Var.k(), null, w2Var.m(true, j4Var)));
        }
        return hashMap;
    }

    public static void w(n0 n0Var, u1 u1Var, o3 o3Var) {
        n0Var.v();
        try {
            n0Var.y(u1Var);
        } catch (deobf.androidx.cardview.widget.u1.a unused) {
            if (o3Var.d() != null) {
                o3Var.d().a(o3Var, o3.g.SESSION_ERROR_SURFACE_NEEDS_RESET);
            }
        }
    }

    public static int x(w2 w2Var) {
        if (w2Var instanceof f1) {
            return Barcode.FORMAT_QR_CODE;
        }
        return 34;
    }

    public Set<w2> D() {
        return this.f3557a;
    }

    public Map<w2, deobf.androidx.camera.video.internal.compat.quirk.z0.f> E(n0 n0Var, int i10, boolean z10, boolean z11) {
        HashMap hashMap = new HashMap();
        for (w2 w2Var : this.f3557a) {
            n0 n0Var2 = n0Var;
            deobf.androidx.camera.video.internal.compat.quirk.z0.f u8 = u(w2Var, this.f3566k, this.f3561f, n0Var2, i10, z10, z11);
            W(w2Var);
            hashMap.put(w2Var, u8);
            n0Var = n0Var2;
        }
        return hashMap;
    }

    public Map<w2, deobf.androidx.camera.camera2.internal.compat.quirk.y0.d> F(n0 n0Var, n0 n0Var2, int i10, boolean z10) {
        HashMap hashMap = new HashMap();
        for (w2 w2Var : this.f3557a) {
            n0 n0Var3 = n0Var;
            int i11 = i10;
            boolean z11 = z10;
            deobf.androidx.camera.video.internal.compat.quirk.z0.f u8 = u(w2Var, this.f3566k, this.f3561f, n0Var3, i11, z11, false);
            c cVar = this.f3567l;
            Objects.requireNonNull(cVar);
            p0 p0Var = this.f3562g;
            Objects.requireNonNull(p0Var);
            n0 n0Var4 = n0Var2;
            deobf.androidx.camera.video.internal.compat.quirk.z0.f u10 = u(w2Var, cVar, p0Var, n0Var4, i11, z11, false);
            W(w2Var);
            hashMap.put(w2Var, deobf.androidx.camera.camera2.internal.compat.quirk.y0.d.c(u8, u10));
            n0Var = n0Var3;
            n0Var2 = n0Var4;
            i10 = i11;
            z10 = z11;
        }
        return hashMap;
    }

    public u H() {
        return this.f3563h;
    }

    public final a2 I() {
        for (w2 w2Var : this.f3557a) {
            if (w2Var instanceof a2) {
                return (a2) w2Var;
            }
        }
        return null;
    }

    public Map<w2, Size> J(n0 n0Var, boolean z10) {
        HashMap hashMap = new HashMap();
        for (w2 w2Var : this.f3557a) {
            c cVar = this.f3566k;
            i4<?> i4Var = this.f3565j.get(w2Var);
            Objects.requireNonNull(i4Var);
            PreferredChildSize r10 = cVar.r(i4Var, n0Var.n(), deobf.androidx.camera.camera2.internal.compat.quirk.a0.g(n0Var.r()), z10);
            hashMap.put(w2Var, r10.getOriginalSelectedChildSize());
            deobf.androidx.camera.view.r1.a("VirtualCameraAdapter", "Selected child size: " + r10.getOriginalSelectedChildSize() + ", useCase: " + w2Var);
        }
        return hashMap;
    }

    public final n0 K(w2 w2Var) {
        n0 n0Var = this.b.get(w2Var);
        Objects.requireNonNull(n0Var);
        return n0Var;
    }

    public final boolean L(w2 w2Var) {
        Boolean bool = this.f3559d.get(w2Var);
        Objects.requireNonNull(bool);
        return bool.booleanValue();
    }

    public void M(deobf.androidx.camera.camera2.internal.compat.quirk.n0.w2 w2Var) {
        w2Var.G(i2.f24989v, this.f3566k.o(w2Var));
        w2Var.G(i4.A, Integer.valueOf(G(this.f3564i)));
        k0 d10 = deobf.androidx.camera.camera2.internal.compat.quirk.b1.a.d(this.f3564i);
        if (d10 == null) {
            throw new IllegalArgumentException("Failed to merge child dynamic ranges, can not find a dynamic range that satisfies all children.");
        }
        w2Var.G(h2.f24968l, d10);
        w2Var.G(i4.C, R(this.f3564i));
        Iterator<w2> it = this.f3557a.iterator();
        while (it.hasNext()) {
            i4<?> i4Var = this.f3565j.get(it.next());
            Objects.requireNonNull(i4Var);
            i4<?> i4Var2 = i4Var;
            if (i4Var2.x() != 0) {
                w2Var.G(i4.I, Integer.valueOf(i4Var2.x()));
            }
            if (i4Var2.E() != 0) {
                w2Var.G(i4.H, Integer.valueOf(i4Var2.E()));
            }
        }
    }

    public void N() {
        Iterator<w2> it = this.f3557a.iterator();
        while (it.hasNext()) {
            it.next().P();
        }
    }

    public void O() {
        Iterator<w2> it = this.f3557a.iterator();
        while (it.hasNext()) {
            it.next().R();
        }
    }

    public void P() {
        Iterator<w2> it = this.f3557a.iterator();
        while (it.hasNext()) {
            it.next().S();
        }
    }

    public void Q() {
        deobf.androidx.camera.camera2.z.b();
        Iterator<w2> it = this.f3557a.iterator();
        while (it.hasNext()) {
            n(it.next());
        }
    }

    public void T(Map<w2, n0> map, Map<w2, Size> map2) {
        this.b.clear();
        this.b.putAll(map);
        for (Map.Entry<w2, n0> entry : this.b.entrySet()) {
            w2 key = entry.getKey();
            n0 value = entry.getValue();
            key.b0(value.n());
            key.Z(value.r());
            key.e0(A(key, value.s(), map2), null);
            key.M();
        }
    }

    public void V() {
        for (w2 w2Var : this.f3557a) {
            j jVar = this.f3558c.get(w2Var);
            Objects.requireNonNull(jVar);
            w2Var.c0(jVar);
        }
    }

    public final void W(w2 w2Var) {
        int z10 = z(w2Var, this.f3561f);
        j jVar = this.f3558c.get(w2Var);
        Objects.requireNonNull(jVar);
        jVar.t(z10);
    }

    @Override // deobf.androidx.camera.view.g0.w2.c
    public void g(w2 w2Var) {
        deobf.androidx.camera.camera2.z.b();
        if (L(w2Var)) {
            n0 K = K(w2Var);
            u1 B = B(w2Var);
            if (B != null) {
                w(K, B, w2Var.z());
            } else {
                K.m();
            }
        }
    }

    @Override // deobf.androidx.camera.view.g0.w2.c
    public void m(w2 w2Var) {
        deobf.androidx.camera.camera2.z.b();
        if (L(w2Var)) {
            this.f3559d.put(w2Var, Boolean.FALSE);
            K(w2Var).m();
        }
    }

    @Override // deobf.androidx.camera.view.g0.w2.c
    public void n(w2 w2Var) {
        u1 B;
        deobf.androidx.camera.camera2.z.b();
        n0 K = K(w2Var);
        if (L(w2Var) && (B = B(w2Var)) != null) {
            w(K, B, w2Var.z());
        }
    }

    @Override // deobf.androidx.camera.view.g0.w2.c
    public void s(w2 w2Var) {
        deobf.androidx.camera.camera2.z.b();
        if (L(w2Var)) {
            return;
        }
        this.f3559d.put(w2Var, Boolean.TRUE);
        u1 B = B(w2Var);
        if (B != null) {
            w(K(w2Var), B, w2Var.z());
        }
    }

    public void t() {
        for (w2 w2Var : this.f3557a) {
            j jVar = this.f3558c.get(w2Var);
            Objects.requireNonNull(jVar);
            w2Var.d(jVar, null, null, w2Var.m(true, this.f3560e));
        }
    }

    public final deobf.androidx.camera.video.internal.compat.quirk.z0.f u(w2 w2Var, c cVar, p0 p0Var, n0 n0Var, int i10, boolean z10, boolean z11) {
        int w5 = p0Var.d().w(i10);
        boolean l10 = a0.l(n0Var.r());
        i4<?> i4Var = this.f3565j.get(w2Var);
        Objects.requireNonNull(i4Var);
        PreferredChildSize r10 = cVar.r(i4Var, n0Var.n(), deobf.androidx.camera.camera2.internal.compat.quirk.a0.g(n0Var.r()), z10);
        Rect cropRectBeforeScaling = r10.getCropRectBeforeScaling();
        Size childSizeToScale = r10.getChildSizeToScale();
        int w10 = deobf.androidx.camera.camera2.internal.compat.quirk.a0.w((n0Var.q() + z(w2Var, p0Var)) - w5);
        return deobf.androidx.camera.video.internal.compat.quirk.z0.f.h(C(w2Var), x(w2Var), cropRectBeforeScaling, a0.q(childSizeToScale, w10), w10, z11 ? false : w2Var.H(p0Var) ^ l10);
    }

    public u v() {
        return new a(this);
    }

    public deobf.androidx.camera.camera2.internal.compat.quirk.y0.d y(n0 n0Var, n0 n0Var2, int i10, boolean z10) {
        a2 a2Var = (a2) deobf.androidx.camera.view.x2.g.g(I());
        return deobf.androidx.camera.camera2.internal.compat.quirk.y0.d.c(u(a2Var, this.f3566k, this.f3561f, n0Var, i10, z10, false), u(a2Var, this.f3566k, this.f3562g, n0Var2, i10, z10, false));
    }

    public final int z(w2 w2Var, p0 p0Var) {
        return p0Var.d().w(((i2) w2Var.l()).J(0));
    }
}
