package deobf.androidx.camera.camera2.internal.compat.quirk.y0;

import android.graphics.SurfaceTexture;
import android.os.Handler;
import android.os.HandlerThread;
import android.view.Surface;
import deobf.androidx.camera.view.g0.i0;
import deobf.androidx.camera.view.g0.j2;
import deobf.androidx.camera.view.g0.k0;
import deobf.androidx.camera.view.g0.r1;
import deobf.androidx.camera.view.g0.v2;
import java.util.Collections;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Executor;
import java.util.concurrent.RejectedExecutionException;
import java.util.concurrent.atomic.AtomicBoolean;
import deobf.androidx.camera.video.internal.compat.quirk.x0.c0;
import deobf.androidx.camera.video.internal.compat.quirk.x0.r0;
import deobf.androidx.work.y1.c;
import deobf.androidx.camera.video.internal.compat.quirk.z0.d;

// dex: classes.dex
public class o implements r0, SurfaceTexture.OnFrameAvailableListener {

    public final c f37142a;
    public final HandlerThread b;

    public final Executor f37143c;

    public final Handler f37144d;

    public int f37145e;

    public boolean f37146f;

    public final AtomicBoolean f37147g;

    public final Map<j2, Surface> f37148h;

    public SurfaceTexture f37149i;

    public SurfaceTexture f37150j;

    public static class a {

        public static deobf.kotlin.pu.n<k0, i0, i0, r0> f37151a = new deobf.kotlin.pu.n() { // from class: y0.n
            @Override // deobf.kotlin.pu.n
            public final Object invoke(Object obj, Object obj2, Object obj3) {
                return new o((k0) obj, (i0) obj2, (i0) obj3);
            }
        };

        public static r0 a(k0 k0Var, i0 i0Var, i0 i0Var2) {
            return f37151a.invoke(k0Var, i0Var, i0Var2);
        }
    }

    public o(k0 k0Var, i0 i0Var, i0 i0Var2) {
        this(k0Var, Collections.EMPTY_MAP, i0Var, i0Var2);
    }

    public static /* synthetic */ void e(o oVar, Runnable runnable, Runnable runnable2) {
        if (oVar.f37146f) {
            runnable.run();
        } else {
            runnable2.run();
        }
    }

    public static /* synthetic */ void f() {
    }

    public static /* synthetic */ void g(o oVar, SurfaceTexture surfaceTexture, Surface surface, deobf.androidx.core.graphics.v2.g gVar) {
        oVar.getClass();
        surfaceTexture.setOnFrameAvailableListener(null);
        surfaceTexture.release();
        surface.release();
        oVar.f37145e--;
        oVar.n();
    }

    public static /* synthetic */ void h(o oVar) {
        oVar.f37146f = true;
        oVar.n();
    }

    public static /* synthetic */ void i(o oVar, j2 j2Var, deobf.unlinked.j2.b bVar) {
        oVar.getClass();
        j2Var.close();
        Surface remove = oVar.f37148h.remove(j2Var);
        if (remove != null) {
            oVar.f37142a.r(remove);
        }
    }

    public static /* synthetic */ void j(final o oVar, final j2 j2Var) {
        Surface t22 = j2Var.t2(oVar.f37143c, new deobf.androidx.camera.view.x2.a() { // from class: y0.j
            @Override // deobf.androidx.camera.view.x2.a
            public final void accept(Object obj) {
                deobf.com.google.android.material.o.i(o.this, j2Var, (deobf.unlinked.j2.b) obj);
            }
        });
        oVar.f37142a.j(t22);
        oVar.f37148h.put(j2Var, t22);
    }

    public static /* synthetic */ void k(final o oVar, v2 v2Var) {
        oVar.f37145e++;
        final SurfaceTexture surfaceTexture = new SurfaceTexture(oVar.f37142a.t(v2Var.u()));
        surfaceTexture.setDefaultBufferSize(v2Var.q().getWidth(), v2Var.q().getHeight());
        final Surface surface = new Surface(surfaceTexture);
        v2Var.w(surface, oVar.f37143c, new deobf.androidx.camera.view.x2.a() { // from class: y0.m
            @Override // deobf.androidx.camera.view.x2.a
            public final void accept(Object obj) {
                deobf.com.google.android.material.o.g(o.this, surfaceTexture, surface, (deobf.androidx.core.graphics.v2.g) obj);
            }
        });
        if (v2Var.u()) {
            oVar.f37149i = surfaceTexture;
        } else {
            oVar.f37150j = surfaceTexture;
            surfaceTexture.setOnFrameAvailableListener(oVar, oVar.f37144d);
        }
    }

    public static /* synthetic */ void l(o oVar, k0 k0Var, Map map, deobf.com.withpersona.sdk2.inquiry.c.a aVar) {
        oVar.getClass();
        try {
            oVar.f37142a.h(k0Var, map);
            aVar.c(null);
        } catch (RuntimeException e10) {
            aVar.f(e10);
        }
    }

    public static /* synthetic */ Object m(final o oVar, final k0 k0Var, final Map map, final deobf.com.withpersona.sdk2.inquiry.c.a aVar) {
        oVar.getClass();
        oVar.o(new Runnable() { // from class: y0.i
            @Override // java.lang.Runnable
            public final void run() {
                o.l(o.this, k0Var, map, aVar);
            }
        });
        return "Init GlRenderer";
    }

    private void n() {
        if (this.f37146f && this.f37145e == 0) {
            Iterator<j2> it = this.f37148h.keySet().iterator();
            while (it.hasNext()) {
                it.next().close();
            }
            this.f37148h.clear();
            this.f37142a.k();
            this.b.quit();
        }
    }

    private void o(Runnable runnable) {
        p(runnable, new Runnable() { // from class: y0.l
            @Override // java.lang.Runnable
            public final void run() {
                deobf.com.google.android.material.o.f();
            }
        });
    }

    private void p(final Runnable runnable, final Runnable runnable2) {
        try {
            this.f37143c.execute(new Runnable() { // from class: y0.k
                @Override // java.lang.Runnable
                public final void run() {
                    deobf.com.google.android.material.o.e(o.this, runnable2, runnable);
                }
            });
        } catch (RejectedExecutionException e10) {
            r1.m("DualSurfaceProcessor", "Unable to executor runnable", e10);
            runnable2.run();
        }
    }

    private void q(final k0 k0Var, final Map<d.e, c0> map) {
        try {
            deobf.androidx.work.y1.c.a(new c.InterfaceC0761c() { // from class: y0.g
                @Override // deobf.androidx.work.y1.c.InterfaceC0761c
                public final Object a(deobf.com.withpersona.sdk2.inquiry.c.a aVar) {
                    return o.m(o.this, k0Var, map, aVar);
                }
            }).get();
        } catch (InterruptedException | ExecutionException e10) {
            e = e10;
            if (e instanceof ExecutionException) {
                e = e.getCause();
            }
            if (!(e instanceof RuntimeException)) {
                throw new IllegalStateException("Failed to create DefaultSurfaceProcessor", e);
            }
            throw ((RuntimeException) e);
        }
    }

    @Override // deobf.androidx.camera.video.internal.compat.quirk.x0.r0
    public void a() {
        if (this.f37147g.getAndSet(true)) {
            return;
        }
        o(new Runnable() { // from class: y0.e
            @Override // java.lang.Runnable
            public final void run() {
                deobf.com.google.android.material.o.h(o.this);
            }
        });
    }

    @Override // deobf.androidx.camera.view.g0.k2
    public void b(final v2 v2Var) {
        if (this.f37147g.get()) {
            v2Var.z();
            return;
        }
        Runnable runnable = new Runnable() { // from class: y0.f
            @Override // java.lang.Runnable
            public final void run() {
                o.k(o.this, v2Var);
            }
        };
        Objects.requireNonNull(v2Var);
        p(runnable, new deobf.androidx.camera.video.internal.compat.quirk.x0.p(v2Var));
    }

    @Override // deobf.androidx.camera.view.g0.k2
    public void d(final j2 j2Var) {
        if (this.f37147g.get()) {
            j2Var.close();
            return;
        }
        Runnable runnable = new Runnable() { // from class: y0.h
            @Override // java.lang.Runnable
            public final void run() {
                o.j(o.this, j2Var);
            }
        };
        Objects.requireNonNull(j2Var);
        p(runnable, new deobf.androidx.camera.video.internal.compat.quirk.x0.n(j2Var));
    }

    @Override // android.graphics.SurfaceTexture.OnFrameAvailableListener
    public void onFrameAvailable(SurfaceTexture surfaceTexture) {
        SurfaceTexture surfaceTexture2;
        if (this.f37147g.get() || (surfaceTexture2 = this.f37149i) == null || this.f37150j == null) {
            return;
        }
        surfaceTexture2.updateTexImage();
        this.f37150j.updateTexImage();
        for (Map.Entry<j2, Surface> entry : this.f37148h.entrySet()) {
            Surface value = entry.getValue();
            j2 key = entry.getKey();
            if (key.getFormat() == 34) {
                try {
                    this.f37142a.v(surfaceTexture.getTimestamp(), value, key, this.f37149i, this.f37150j);
                } catch (RuntimeException e10) {
                    r1.d("DualSurfaceProcessor", "Failed to render with OpenGL.", e10);
                }
            }
        }
    }

    public o(k0 k0Var, Map<d.e, c0> map, i0 i0Var, i0 i0Var2) {
        this.f37145e = 0;
        this.f37146f = false;
        this.f37147g = new AtomicBoolean(false);
        this.f37148h = new LinkedHashMap();
        HandlerThread handlerThread = new HandlerThread("CameraX-GL Thread");
        this.b = handlerThread;
        handlerThread.start();
        Handler handler = new Handler(handlerThread.getLooper());
        this.f37144d = handler;
        this.f37143c = deobf.unlinked.q0.c.f(handler);
        this.f37142a = new c(i0Var, i0Var2);
        try {
            q(k0Var, map);
        } catch (RuntimeException e10) {
            a();
            throw e10;
        }
    }
}
