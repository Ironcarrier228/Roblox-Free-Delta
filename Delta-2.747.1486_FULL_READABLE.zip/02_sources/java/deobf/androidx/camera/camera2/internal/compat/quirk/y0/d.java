package deobf.androidx.camera.camera2.internal.compat.quirk.y0;

// dex: classes.dex
public abstract class d {
    public static d c(deobf.androidx.camera.video.internal.compat.quirk.z0.f fVar, deobf.androidx.camera.video.internal.compat.quirk.z0.f fVar2) {
        return new a(fVar, fVar2);
    }

    public abstract deobf.androidx.camera.video.internal.compat.quirk.z0.f a();

    public abstract deobf.androidx.camera.video.internal.compat.quirk.z0.f b();
}
