package deobf.androidx.camera.camera2.internal.compat.quirk.y0;

import java.util.List;
import deobf.androidx.camera.video.internal.compat.quirk.x0.n0;
import deobf.androidx.camera.camera2.internal.compat.quirk.y0.r;

// dex: classes.dex
public final class b extends r.b {

    public final n0 f37123a;
    public final n0 b;

    public final List<d> f37124c;

    public b(n0 n0Var, n0 n0Var2, List<d> list) {
        if (n0Var == null) {
            throw new NullPointerException("Null primarySurfaceEdge");
        }
        this.f37123a = n0Var;
        if (n0Var2 == null) {
            throw new NullPointerException("Null secondarySurfaceEdge");
        }
        this.b = n0Var2;
        if (list == null) {
            throw new NullPointerException("Null outConfigs");
        }
        this.f37124c = list;
    }

    @Override // deobf.androidx.camera.camera2.internal.compat.quirk.y0.r.b
    public List<d> a() {
        return this.f37124c;
    }

    @Override // deobf.androidx.camera.camera2.internal.compat.quirk.y0.r.b
    public n0 b() {
        return this.f37123a;
    }

    @Override // deobf.androidx.camera.camera2.internal.compat.quirk.y0.r.b
    public n0 c() {
        return this.b;
    }

    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (obj instanceof r.b) {
            r.b bVar = (r.b) obj;
            if (this.f37123a.equals(bVar.b()) && this.b.equals(bVar.c()) && this.f37124c.equals(bVar.a())) {
                return true;
            }
        }
        return false;
    }

    public int hashCode() {
        return ((((this.f37123a.hashCode() ^ 1000003) * 1000003) ^ this.b.hashCode()) * 1000003) ^ this.f37124c.hashCode();
    }

    public String toString() {
        return "In{primarySurfaceEdge=" + this.f37123a + ", secondarySurfaceEdge=" + this.b + ", outConfigs=" + this.f37124c + "}";
    }
}
