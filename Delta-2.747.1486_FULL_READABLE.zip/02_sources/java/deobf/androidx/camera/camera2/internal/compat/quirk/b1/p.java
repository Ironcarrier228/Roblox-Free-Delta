package deobf.androidx.camera.camera2.internal.compat.quirk.b1;

import deobf.androidx.camera.camera2.internal.compat.quirk.b1.g;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import deobf.androidx.camera.camera2.internal.compat.quirk.n0.c2;
import deobf.androidx.camera.camera2.internal.compat.quirk.n0.l0;
import deobf.androidx.camera.camera2.internal.compat.quirk.n0.l1;
import deobf.androidx.camera.view.pe.x;

// dex: classes.dex
public class p extends c2 {

    public final deobf.com.roblox.protocols.mediapicker.g.a f3574c;

    public p(l0 l0Var, deobf.com.roblox.protocols.mediapicker.g.a aVar) {
        super(l0Var);
        this.f3574c = aVar;
    }

    @Override // deobf.androidx.camera.camera2.internal.compat.quirk.n0.c2, deobf.androidx.camera.camera2.internal.compat.quirk.n0.l0
    public x<List<Void>> f(final List<l1> list, int i10, int i11) {
        deobf.androidx.camera.view.x2.g.b(list.size() == 1, "Only support one capture config.");
        final x<deobf.androidx.camera.camera2.internal.compat.quirk.m0.m> m10 = m(i10, 1);
        return deobf.androidx.camera.view.r0.n.k(Collections.singletonList(deobf.androidx.camera.view.r0.d.c(m10).g(new deobf.androidx.camera.view.r0.a() { // from class: b1.m
            @Override // deobf.androidx.camera.view.r0.a
            public final x apply(Object obj) {
                x a10;
                a10 = ((deobf.androidx.camera.camera2.internal.compat.quirk.m0.m) x.this.get()).a();
                return a10;
            }
        }, deobf.unlinked.q0.c.b()).g(new deobf.androidx.camera.view.r0.a() { // from class: b1.n
            @Override // deobf.androidx.camera.view.r0.a
            public final x apply(Object obj) {
                x a10;
                a10 = r0.f3574c.a(r0.s((l1) r1.get(0)), p.this.t((l1) list.get(0)));
                return a10;
            }
        }, deobf.unlinked.q0.c.b()).g(new deobf.androidx.camera.view.r0.a() { // from class: b1.o
            @Override // deobf.androidx.camera.view.r0.a
            public final x apply(Object obj) {
                x b;
                b = ((deobf.androidx.camera.camera2.internal.compat.quirk.m0.m) x.this.get()).b();
                return b;
            }
        }, deobf.unlinked.q0.c.b())));
    }

    public final int s(l1 l1Var) {
        Integer num = (Integer) l1Var.g().h(l1.f25025j, 100);
        Objects.requireNonNull(num);
        return num.intValue();
    }

    public final int t(l1 l1Var) {
        Integer num = (Integer) l1Var.g().h(l1.f25024i, 0);
        Objects.requireNonNull(num);
        return num.intValue();
    }
}
