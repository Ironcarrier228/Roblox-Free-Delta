package deobf.androidx.camera.camera2.internal.compat.quirk.y0;

import android.graphics.SurfaceTexture;
import android.opengl.EGL14;
import android.opengl.EGLExt;
import android.opengl.GLES20;
import android.opengl.Matrix;
import android.util.Size;
import android.view.Surface;
import deobf.androidx.camera.view.g0.i0;
import deobf.androidx.camera.view.g0.j2;
import deobf.androidx.camera.view.g0.k0;
import deobf.androidx.camera.view.g0.r1;
import java.util.Map;
import deobf.androidx.camera.video.internal.compat.quirk.x0.c0;
import deobf.androidx.camera.video.internal.compat.quirk.x0.z;
import deobf.androidx.camera.video.internal.compat.quirk.z0.d;

// dex: classes.dex
public final class c extends z {

    public int f37125n = -1;

    public int f37126o = -1;

    public final i0 f37127p;

    public final i0 f37128q;

    public c(i0 i0Var, i0 i0Var2) {
        this.f37127p = i0Var;
        this.f37128q = i0Var2;
    }

    public static float[] u(Size size, Size size2, i0 i0Var) {
        float[] l10 = deobf.androidx.camera.video.internal.compat.quirk.z0.d.l();
        float[] l11 = deobf.androidx.camera.video.internal.compat.quirk.z0.d.l();
        float[] l12 = deobf.androidx.camera.video.internal.compat.quirk.z0.d.l();
        Matrix.scaleM(l10, 0, size.getWidth() / size2.getWidth(), size.getHeight() / size2.getHeight(), 1.0f);
        if (i0Var.c().f36143a.floatValue() != 0.0f || i0Var.c().b.floatValue() != 0.0f) {
            Matrix.translateM(l11, 0, i0Var.b().f36143a.floatValue() / i0Var.c().f36143a.floatValue(), i0Var.b().b.floatValue() / i0Var.c().b.floatValue(), 0.0f);
        }
        Matrix.multiplyMM(l12, 0, l10, 0, l11, 0);
        return l12;
    }

    @Override // deobf.androidx.camera.video.internal.compat.quirk.x0.z
    public deobf.androidx.camera.video.internal.compat.quirk.z0.e h(k0 k0Var, Map<d.e, c0> map) {
        deobf.androidx.camera.video.internal.compat.quirk.z0.e h10 = super.h(k0Var, map);
        this.f37125n = deobf.androidx.camera.video.internal.compat.quirk.z0.d.p();
        this.f37126o = deobf.androidx.camera.video.internal.compat.quirk.z0.d.p();
        return h10;
    }

    @Override // deobf.androidx.camera.video.internal.compat.quirk.x0.z
    public void k() {
        super.k();
        this.f37125n = -1;
        this.f37126o = -1;
    }

    public int t(boolean z10) {
        deobf.androidx.camera.video.internal.compat.quirk.z0.d.i(this.f36128a, true);
        deobf.androidx.camera.video.internal.compat.quirk.z0.d.h(this.f36129c);
        return z10 ? this.f37125n : this.f37126o;
    }

    public void v(long j10, Surface surface, j2 j2Var, SurfaceTexture surfaceTexture, SurfaceTexture surfaceTexture2) {
        deobf.androidx.camera.video.internal.compat.quirk.z0.d.i(this.f36128a, true);
        deobf.androidx.camera.video.internal.compat.quirk.z0.d.h(this.f36129c);
        deobf.androidx.camera.video.internal.compat.quirk.z0.g f10 = f(surface);
        if (f10 == deobf.androidx.camera.video.internal.compat.quirk.z0.d.f38831l) {
            f10 = c(surface);
            if (f10 == null) {
                return;
            } else {
                this.b.put(surface, f10);
            }
        }
        deobf.androidx.camera.video.internal.compat.quirk.z0.g gVar = f10;
        if (surface != this.f36135i) {
            i(gVar.a());
            this.f36135i = surface;
        }
        GLES20.glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
        GLES20.glClear(16384);
        w(gVar, j2Var, surfaceTexture, this.f37127p, this.f37125n, true);
        w(gVar, j2Var, surfaceTexture2, this.f37128q, this.f37126o, false);
        EGLExt.eglPresentationTimeANDROID(this.f36130d, gVar.a(), j10);
        if (EGL14.eglSwapBuffers(this.f36130d, gVar.a())) {
            return;
        }
        r1.l("DualOpenGlRenderer", "Failed to swap buffers with EGL error: 0x" + Integer.toHexString(EGL14.eglGetError()));
        m(surface, false);
    }

    public final void w(deobf.androidx.camera.video.internal.compat.quirk.z0.g gVar, j2 j2Var, SurfaceTexture surfaceTexture, i0 i0Var, int i10, boolean z10) {
        s(i10);
        GLES20.glViewport(0, 0, gVar.c(), gVar.b());
        GLES20.glScissor(0, 0, gVar.c(), gVar.b());
        float[] fArr = new float[16];
        surfaceTexture.getTransformMatrix(fArr);
        float[] fArr2 = new float[16];
        j2Var.W(fArr2, fArr, z10);
        d.f fVar = (d.f) deobf.androidx.camera.view.x2.g.g(this.f36137k);
        if (fVar instanceof d.g) {
            ((d.g) fVar).h(fArr2);
        }
        fVar.e(u(new Size((int) (gVar.c() * i0Var.c().f36143a.floatValue()), (int) (gVar.b() * i0Var.c().b.floatValue())), new Size(gVar.c(), gVar.b()), i0Var));
        fVar.d(i0Var.a());
        GLES20.glEnable(3042);
        GLES20.glBlendFuncSeparate(770, 771, 1, 771);
        GLES20.glDrawArrays(5, 0, 4);
        deobf.androidx.camera.video.internal.compat.quirk.z0.d.g("glDrawArrays");
        GLES20.glDisable(3042);
    }
}
