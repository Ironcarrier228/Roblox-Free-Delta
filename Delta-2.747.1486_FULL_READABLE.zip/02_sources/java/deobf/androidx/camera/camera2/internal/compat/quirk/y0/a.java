package deobf.androidx.camera.camera2.internal.compat.quirk.y0;

// dex: classes.dex
public final class a extends d {

    public final deobf.androidx.camera.video.internal.compat.quirk.z0.f f37122a;
    public final deobf.androidx.camera.video.internal.compat.quirk.z0.f b;

    public a(deobf.androidx.camera.video.internal.compat.quirk.z0.f fVar, deobf.androidx.camera.video.internal.compat.quirk.z0.f fVar2) {
        if (fVar == null) {
            throw new NullPointerException("Null primaryOutConfig");
        }
        this.f37122a = fVar;
        if (fVar2 == null) {
            throw new NullPointerException("Null secondaryOutConfig");
        }
        this.b = fVar2;
    }

    @Override // deobf.androidx.camera.camera2.internal.compat.quirk.y0.d
    public deobf.androidx.camera.video.internal.compat.quirk.z0.f a() {
        return this.f37122a;
    }

    @Override // deobf.androidx.camera.camera2.internal.compat.quirk.y0.d
    public deobf.androidx.camera.video.internal.compat.quirk.z0.f b() {
        return this.b;
    }

    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (obj instanceof d) {
            d dVar = (d) obj;
            if (this.f37122a.equals(dVar.a()) && this.b.equals(dVar.b())) {
                return true;
            }
        }
        return false;
    }

    public int hashCode() {
        return ((this.f37122a.hashCode() ^ 1000003) * 1000003) ^ this.b.hashCode();
    }

    public String toString() {
        return "DualOutConfig{primaryOutConfig=" + this.f37122a + ", secondaryOutConfig=" + this.b + "}";
    }
}
