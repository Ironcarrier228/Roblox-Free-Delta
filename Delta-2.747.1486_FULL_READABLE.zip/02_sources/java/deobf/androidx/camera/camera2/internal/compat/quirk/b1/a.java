package deobf.androidx.camera.camera2.internal.compat.quirk.b1;

import deobf.androidx.camera.view.g0.k0;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import deobf.androidx.camera.camera2.internal.compat.quirk.n0.i4;

// dex: classes.dex
public class a {
    public static k0 a(List<k0> list) {
        if (list.isEmpty()) {
            return null;
        }
        k0 k0Var = list.get(0);
        Integer valueOf = Integer.valueOf(k0Var.b());
        Integer valueOf2 = Integer.valueOf(k0Var.a());
        for (int i10 = 1; i10 < list.size(); i10++) {
            k0 k0Var2 = list.get(i10);
            valueOf = c(valueOf, Integer.valueOf(k0Var2.b()));
            valueOf2 = b(valueOf2, Integer.valueOf(k0Var2.a()));
            if (valueOf == null || valueOf2 == null) {
                return null;
            }
        }
        return new k0(valueOf.intValue(), valueOf2.intValue());
    }

    public static Integer b(Integer num, Integer num2) {
        if (num.equals(0)) {
            return num2;
        }
        if (num2.equals(0) || num.equals(num2)) {
            return num;
        }
        return null;
    }

    public static Integer c(Integer num, Integer num2) {
        if (num.equals(0)) {
            return num2;
        }
        if (!num2.equals(0)) {
            if (num.equals(2) && !num2.equals(1)) {
                return num2;
            }
            if ((!num2.equals(2) || num.equals(1)) && !num.equals(num2)) {
                return null;
            }
        }
        return num;
    }

    public static k0 d(Set<i4<?>> set) {
        ArrayList arrayList = new ArrayList();
        Iterator<i4<?>> it = set.iterator();
        while (it.hasNext()) {
            arrayList.add(it.next().M());
        }
        return a(arrayList);
    }
}
