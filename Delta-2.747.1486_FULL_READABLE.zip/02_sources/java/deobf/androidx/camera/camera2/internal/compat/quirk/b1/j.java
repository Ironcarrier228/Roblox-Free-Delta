package deobf.androidx.camera.camera2.internal.compat.quirk.b1;

import deobf.androidx.camera.camera2.internal.compat.quirk.b1.g;
import deobf.androidx.camera.view.g0.w2;
import java.util.Collection;
import deobf.androidx.camera.camera2.internal.compat.quirk.n0.a3;
import deobf.androidx.camera.camera2.internal.compat.quirk.n0.l0;
import deobf.androidx.camera.camera2.internal.compat.quirk.n0.o0;
import deobf.androidx.camera.camera2.internal.compat.quirk.n0.p0;
import deobf.androidx.camera.view.p0.z;
import deobf.androidx.camera.view.pe.x;

// dex: classes.dex
public class j implements p0 {

    public final p0 f3554a;
    public final p b;

    public final q f3555c;

    public final deobf.androidx.appcompat.widget.w2.c f3556d;

    public j(p0 p0Var, deobf.androidx.appcompat.widget.w2.c cVar, deobf.com.roblox.protocols.mediapicker.g.a aVar) {
        this.f3554a = p0Var;
        this.f3556d = cVar;
        this.b = new p(p0Var.e(), aVar);
        this.f3555c = new q(p0Var.k());
    }

    @Override // deobf.androidx.camera.camera2.internal.compat.quirk.n0.p0
    public x<Void> a() {
        throw new UnsupportedOperationException("Operation not supported by VirtualCamera.");
    }

    @Override // deobf.androidx.camera.camera2.internal.compat.quirk.n0.p0
    public a3<deobf.androidx.camera.view.p0.a> b() {
        return this.f3554a.b();
    }

    @Override // deobf.androidx.camera.camera2.internal.compat.quirk.n0.p0
    public l0 e() {
        return this.b;
    }

    @Override // deobf.androidx.camera.view.g0.w2.c
    public void g(w2 w2Var) {
        deobf.androidx.camera.camera2.z.b();
        this.f3556d.g(w2Var);
    }

    @Override // deobf.androidx.camera.camera2.internal.compat.quirk.n0.p0
    public void i(Collection<w2> collection) {
        throw new UnsupportedOperationException("Operation not supported by VirtualCamera.");
    }

    @Override // deobf.androidx.camera.camera2.internal.compat.quirk.n0.p0
    public void j(Collection<w2> collection) {
        throw new UnsupportedOperationException("Operation not supported by VirtualCamera.");
    }

    @Override // deobf.androidx.camera.camera2.internal.compat.quirk.n0.p0
    public o0 k() {
        return this.f3555c;
    }

    @Override // deobf.androidx.camera.view.g0.w2.c
    public void m(w2 w2Var) {
        deobf.androidx.camera.camera2.z.b();
        this.f3556d.m(w2Var);
    }

    @Override // deobf.androidx.camera.view.g0.w2.c
    public void n(w2 w2Var) {
        deobf.androidx.camera.camera2.z.b();
        this.f3556d.n(w2Var);
    }

    @Override // deobf.androidx.camera.camera2.internal.compat.quirk.n0.p0
    public boolean q() {
        return false;
    }

    @Override // deobf.androidx.camera.view.g0.w2.c
    public void s(w2 w2Var) {
        deobf.androidx.camera.camera2.z.b();
        this.f3556d.s(w2Var);
    }

    public void t(int i10) {
        this.f3555c.B(i10);
    }
}
