package deobf.androidx.camera.camera2.internal.compat.quirk.b1;

import android.graphics.Rect;
import android.graphics.RectF;
import android.util.Pair;
import android.util.Rational;
import android.util.Size;
import deobf.androidx.camera.view.g0.r1;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import deobf.androidx.camera.camera2.internal.compat.quirk.n0.i2;
import deobf.androidx.camera.camera2.internal.compat.quirk.n0.i4;
import deobf.androidx.camera.camera2.internal.compat.quirk.n0.o0;
import deobf.androidx.camera.camera2.internal.compat.quirk.n0.p0;
import deobf.androidx.camera.camera2.internal.compat.quirk.n0.w2;
import deobf.androidx.camera.view.p0.a0;

// dex: classes.dex
public class c {

    public static final double f3531h = Math.sqrt(2.3703703703703702d);

    public final Size f3532a;
    public final Rational b;

    public final Rational f3533c;

    public final Set<i4<?>> f3534d;

    public final deobf.androidx.camera.camera2.s0.o f3535e;

    public final o0 f3536f;

    public final Map<i4<?>, List<Size>> f3537g;

    public static class a implements Comparator<Rational> {

        public final Rational f3538a;
        public final boolean b;

        public a(Rational rational, boolean z10) {
            this.f3538a = rational;
            this.b = z10;
        }

        @Override // java.util.Comparator
        public int compare(Rational rational, Rational rational2) {
            float c10 = c.c(rational, this.f3538a);
            float c11 = c.c(rational2, this.f3538a);
            return this.b ? Float.compare(c11, c10) : Float.compare(c10, c11);
        }
    }

    public c(p0 p0Var, Set<i4<?>> set) {
        this(a0.m(p0Var.k().h()), p0Var.k(), set);
    }

    public static boolean A(Collection<Size> collection, Size size) {
        Iterator<Size> it = collection.iterator();
        while (it.hasNext()) {
            if (!y(it.next(), size)) {
                return true;
            }
        }
        return false;
    }

    public static List<Size> E(List<Size> list) {
        return list.isEmpty() ? list : new ArrayList(new LinkedHashSet(list));
    }

    public static Rect F(Rect rect) {
        return new Rect(rect.top, rect.left, rect.bottom, rect.right);
    }

    public static void M(List<Size> list) {
        Collections.sort(list, new deobf.androidx.camera.view.p0.e(true));
    }

    public static Rational N(Size size) {
        return new Rational(size.getWidth(), size.getHeight());
    }

    public static Rational O(Size size) {
        Rational rational = deobf.androidx.camera.view.p0.a.f28584a;
        if (deobf.androidx.camera.view.p0.a.a(size, rational)) {
            return rational;
        }
        Rational rational2 = deobf.androidx.camera.view.p0.a.f28585c;
        return deobf.androidx.camera.view.p0.a.a(size, rational2) ? rational2 : N(size);
    }

    public static float c(Rational rational, Rational rational2) {
        float floatValue = rational.floatValue();
        float floatValue2 = rational2.floatValue();
        return floatValue > floatValue2 ? floatValue2 / floatValue : floatValue / floatValue2;
    }

    public static List<Size> e(List<Size> list) {
        Rational rational;
        HashMap hashMap = new HashMap();
        ArrayList arrayList = new ArrayList();
        for (Size size : list) {
            Iterator it = hashMap.keySet().iterator();
            while (true) {
                if (!it.hasNext()) {
                    rational = null;
                    break;
                }
                rational = (Rational) it.next();
                if (deobf.androidx.camera.view.p0.a.a(size, rational)) {
                    break;
                }
            }
            if (rational != null) {
                Size size2 = (Size) hashMap.get(rational);
                Objects.requireNonNull(size2);
                if (size.getHeight() <= size2.getHeight()) {
                    if (size.getWidth() <= size2.getWidth()) {
                        if (size.getWidth() == size2.getWidth() && size.getHeight() == size2.getHeight()) {
                        }
                    }
                }
            } else {
                rational = N(size);
            }
            arrayList.add(size);
            hashMap.put(rational, size);
        }
        return arrayList;
    }

    public static List<Size> f(Collection<Size> collection, List<Size> list) {
        if (collection.isEmpty() || list.isEmpty()) {
            return new ArrayList();
        }
        ArrayList arrayList = new ArrayList();
        for (Size size : list) {
            if (A(collection, size)) {
                arrayList.add(size);
            }
        }
        return arrayList;
    }

    public static List<Size> g(Rational rational, List<Size> list) {
        ArrayList arrayList = new ArrayList();
        for (Size size : list) {
            if (deobf.androidx.camera.view.p0.a.a(size, rational)) {
                arrayList.add(size);
            }
        }
        return arrayList;
    }

    public static Rational h(Size size) {
        return ((double) size.getWidth()) / ((double) size.getHeight()) > f3531h ? deobf.androidx.camera.view.p0.a.f28585c : deobf.androidx.camera.view.p0.a.f28584a;
    }

    public static Rect k(Rational rational, Size size) {
        RectF rectF;
        RectF rectF2;
        int width = size.getWidth();
        int height = size.getHeight();
        Rational N = N(size);
        if (rational.floatValue() == N.floatValue()) {
            rectF2 = new RectF(0.0f, 0.0f, width, height);
        } else {
            if (rational.floatValue() > N.floatValue()) {
                float f10 = width;
                float floatValue = f10 / rational.floatValue();
                float f11 = (height - floatValue) / 2.0f;
                rectF = new RectF(0.0f, f11, f10, floatValue + f11);
            } else {
                float f12 = height;
                float floatValue2 = rational.floatValue() * f12;
                float f13 = (width - floatValue2) / 2.0f;
                rectF = new RectF(f13, 0.0f, floatValue2 + f13, f12);
            }
            rectF2 = rectF;
        }
        Rect rect = new Rect();
        rectF2.round(rect);
        return rect;
    }

    public static Rect m(Size size, Size size2) {
        return k(N(size2), size);
    }

    public static Rational n(Rational rational) {
        Rational rational2 = deobf.androidx.camera.view.p0.a.f28584a;
        if (rational.equals(rational2)) {
            return deobf.androidx.camera.view.p0.a.f28585c;
        }
        if (rational.equals(deobf.androidx.camera.view.p0.a.f28585c)) {
            return rational2;
        }
        throw new IllegalArgumentException("Invalid sensor aspect-ratio: " + rational);
    }

    public static List<Size> p(Collection<Size> collection, List<Size> list) {
        if (collection.isEmpty() || list.isEmpty()) {
            return new ArrayList();
        }
        List<Size> E = E(list);
        ArrayList arrayList = new ArrayList();
        for (Size size : E) {
            if (z(collection, size)) {
                arrayList.add(size);
            }
        }
        if (!arrayList.isEmpty()) {
            arrayList.remove(arrayList.size() - 1);
        }
        return arrayList;
    }

    public static Rational u(Size size) {
        Rational h10 = h(size);
        deobf.androidx.camera.view.r1.a("ResolutionsMerger", "The closer aspect ratio to the sensor size (" + size + ") is " + h10 + ".");
        return h10;
    }

    public static List<Size> w(List<Pair<Integer, Size[]>> list) {
        for (Pair<Integer, Size[]> pair : list) {
            if (((Integer) pair.first).equals(34)) {
                return Arrays.asList((Size[]) pair.second);
            }
        }
        return new ArrayList();
    }

    public static boolean y(Size size, Size size2) {
        return size.getHeight() > size2.getHeight() || size.getWidth() > size2.getWidth();
    }

    public static boolean z(Collection<Size> collection, Size size) {
        Iterator<Size> it = collection.iterator();
        while (it.hasNext()) {
            if (y(it.next(), size)) {
                return false;
            }
        }
        return true;
    }

    public final boolean B(Rational rational, Size size) {
        if (this.b.equals(rational) || deobf.androidx.camera.view.p0.a.a(size, rational)) {
            return false;
        }
        return b(this.b.floatValue(), rational.floatValue(), O(size).floatValue());
    }

    public final boolean C(Size size, Size size2) {
        return B(O(size), size2);
    }

    public final boolean D() {
        Iterator<Size> it = l().iterator();
        while (it.hasNext()) {
            if (!deobf.androidx.camera.view.p0.a.a(it.next(), this.f3533c)) {
                return true;
            }
        }
        return false;
    }

    public final List<Size> G(List<Size> list, boolean z10) {
        Map<Rational, List<Size>> x5 = x(list);
        ArrayList arrayList = new ArrayList(x5.keySet());
        L(arrayList);
        ArrayList arrayList2 = new ArrayList();
        int size = arrayList.size();
        int i10 = 0;
        while (i10 < size) {
            Object obj = arrayList.get(i10);
            i10++;
            Rational rational = (Rational) obj;
            if (!rational.equals(deobf.androidx.camera.view.p0.a.f28585c) && !rational.equals(deobf.androidx.camera.view.p0.a.f28584a)) {
                List<Size> list2 = x5.get(rational);
                Objects.requireNonNull(list2);
                arrayList2.addAll(I(rational, list2, z10));
            }
        }
        return arrayList2;
    }

    public final List<Size> H(List<Size> list) {
        ArrayList arrayList = new ArrayList();
        if (D()) {
            arrayList.addAll(I(this.b, list, false));
        }
        int size = arrayList.size();
        if (K()) {
            size = 0;
        }
        arrayList.addAll(size, I(this.f3533c, list, false));
        arrayList.addAll(G(list, false));
        if (arrayList.isEmpty()) {
            r1.l("ResolutionsMerger", "Failed to find a parent resolution that does not result in double-cropping, this might due to camera not supporting 4:3 and 16:9resolutions or a strict ResolutionSelector settings. Starting resolution selection process with resolutions that might have a smaller FOV.");
            arrayList.addAll(G(list, true));
        }
        deobf.androidx.camera.view.r1.a("ResolutionsMerger", "Parent resolutions: " + arrayList);
        return arrayList;
    }

    public final List<Size> I(Rational rational, List<Size> list, boolean z10) {
        List<Size> g10 = g(rational, list);
        M(g10);
        HashSet hashSet = new HashSet(g10);
        Iterator<i4<?>> it = this.f3534d.iterator();
        while (it.hasNext()) {
            List<Size> v8 = v(it.next());
            if (!z10) {
                v8 = d(rational, v8);
            }
            if (v8.isEmpty()) {
                return new ArrayList();
            }
            g10 = f(v8, g10);
            hashSet.retainAll(p(v8, g10));
        }
        ArrayList arrayList = new ArrayList();
        for (Size size : g10) {
            if (!hashSet.contains(size)) {
                arrayList.add(size);
            }
        }
        return arrayList;
    }

    public final boolean J() {
        boolean z10;
        deobf.androidx.camera.view.a1.c q8;
        Iterator<i4<?>> it = this.f3534d.iterator();
        while (true) {
            z10 = false;
            if (!it.hasNext()) {
                break;
            }
            i4<?> next = it.next();
            if (!next.d0(false) && (next instanceof i2) && (q8 = ((i2) next).q(null)) != null) {
                z10 = true;
                if (q8.a() == 1) {
                    break;
                }
            }
        }
        return z10;
    }

    public final boolean K() {
        if (this.f3534d.isEmpty()) {
            return false;
        }
        Iterator<i4<?>> it = this.f3534d.iterator();
        while (it.hasNext()) {
            Iterator<Size> it2 = v(it.next()).iterator();
            boolean z10 = false;
            boolean z11 = false;
            while (it2.hasNext()) {
                boolean a10 = deobf.androidx.camera.view.p0.a.a(it2.next(), this.f3533c);
                if (a10) {
                    z10 = true;
                }
                if (z11 && a10) {
                    return false;
                }
                if (!a10) {
                    z11 = true;
                }
            }
            if (!z10) {
                return false;
            }
        }
        return true;
    }

    public final void L(List<Rational> list) {
        Collections.sort(list, new a(N(this.f3532a), true));
    }

    public final boolean b(float f10, float f11, float f12) {
        if (f10 != f11 && f11 != f12) {
            if (f10 > f11) {
                return f11 < f12;
            }
            if (f11 > f12) {
                return true;
            }
        }
        return false;
    }

    public final List<Size> d(Rational rational, List<Size> list) {
        ArrayList arrayList = new ArrayList();
        for (Size size : list) {
            if (!B(rational, size)) {
                arrayList.add(size);
            }
        }
        return arrayList;
    }

    public final List<Size> i() {
        return this.f3536f.j(34);
    }

    public final List<Size> j() {
        return this.f3536f.m(34);
    }

    public final Set<Size> l() {
        HashSet hashSet = new HashSet();
        Iterator<i4<?>> it = this.f3534d.iterator();
        while (it.hasNext()) {
            hashSet.addAll(v(it.next()));
        }
        return hashSet;
    }

    public List<Size> o(w2 w2Var) {
        List<Size> j10 = j();
        if (J()) {
            ArrayList arrayList = new ArrayList(j10);
            arrayList.addAll(i());
            j10 = arrayList;
        }
        List list = (List) w2Var.h(i2.f24987t, null);
        if (list != null) {
            j10 = w(list);
        }
        return H(j10);
    }

    public Size q(Size size, i4<?> i4Var) {
        List<Size> v8 = v(i4Var);
        for (Size size2 : v8) {
            if (!C(size, size2) && !y(size2, size)) {
                return size2;
            }
        }
        for (Size size3 : v8) {
            if (!y(size3, size)) {
                return size3;
            }
        }
        return size;
    }

    public PreferredChildSize r(i4<?> i4Var, Rect rect, int i10, boolean z10) {
        boolean z11;
        if (a0.i(i10)) {
            rect = F(rect);
            z11 = true;
        } else {
            z11 = false;
        }
        PreferredChildSize t8 = t(rect, i4Var, z10);
        return z11 ? new PreferredChildSize(F(t8.getCropRectBeforeScaling()), a0.o(t8.getChildSizeToScale()), t8.getOriginalSelectedChildSize()) : t8;
    }

    public Pair<Size, Size> s(Size size, i4<?> i4Var) {
        for (Size size2 : v(i4Var)) {
            Size m10 = a0.m(m(size2, size));
            if (!y(m10, size)) {
                return Pair.create(size2, m10);
            }
        }
        return Pair.create(size, size);
    }

    public final PreferredChildSize t(Rect rect, i4<?> i4Var, boolean z10) {
        Size q8;
        Size size;
        if (z10) {
            Pair<Size, Size> s8 = s(a0.m(rect), i4Var);
            q8 = (Size) s8.first;
            size = (Size) s8.second;
        } else {
            Size m10 = a0.m(rect);
            q8 = q(m10, i4Var);
            rect = m(m10, q8);
            size = q8;
        }
        return new PreferredChildSize(rect, size, q8);
    }

    public final List<Size> v(i4<?> i4Var) {
        if (!this.f3534d.contains(i4Var)) {
            throw new IllegalArgumentException("Invalid child config: " + i4Var);
        }
        if (this.f3537g.containsKey(i4Var)) {
            List<Size> list = this.f3537g.get(i4Var);
            Objects.requireNonNull(list);
            return list;
        }
        List<Size> e10 = e(this.f3535e.m(i4Var));
        this.f3537g.put(i4Var, e10);
        return e10;
    }

    public final Map<Rational, List<Size>> x(List<Size> list) {
        List list2;
        HashMap hashMap = new HashMap();
        Rational rational = deobf.androidx.camera.view.p0.a.f28584a;
        hashMap.put(rational, new ArrayList());
        Rational rational2 = deobf.androidx.camera.view.p0.a.f28585c;
        hashMap.put(rational2, new ArrayList());
        ArrayList arrayList = new ArrayList();
        arrayList.add(rational);
        arrayList.add(rational2);
        for (Size size : list) {
            if (size.getHeight() > 0) {
                int size2 = arrayList.size();
                int i10 = 0;
                while (true) {
                    if (i10 >= size2) {
                        list2 = null;
                        break;
                    }
                    Object obj = arrayList.get(i10);
                    i10++;
                    Rational rational3 = (Rational) obj;
                    if (deobf.androidx.camera.view.p0.a.a(size, rational3)) {
                        list2 = (List) hashMap.get(rational3);
                        break;
                    }
                }
                if (list2 == null) {
                    list2 = new ArrayList();
                    Rational N = N(size);
                    arrayList.add(N);
                    hashMap.put(N, list2);
                }
                list2.add(size);
            }
        }
        return hashMap;
    }

    public c(Size size, o0 o0Var, Set<i4<?>> set) {
        this(size, o0Var, set, new deobf.androidx.camera.camera2.s0.o(o0Var, size));
    }

    public c(Size size, o0 o0Var, Set<i4<?>> set, deobf.androidx.camera.camera2.s0.o oVar) {
        this.f3537g = new HashMap();
        this.f3532a = size;
        Rational u8 = u(size);
        this.b = u8;
        this.f3533c = n(u8);
        this.f3536f = o0Var;
        this.f3534d = set;
        this.f3535e = oVar;
    }
}
