package deobf.androidx.camera.video.internal.compat.quirk.i1;

import android.annotation.SuppressLint;
import com.google.mlkit.vision.barcode.common.Barcode;
import deobf.androidx.camera.view.g0.r1;
import deobf.androidx.camera.video.internal.compat.quirk.i1.p;
import java.nio.ByteBuffer;
import java.util.Queue;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Executor;
import java.util.concurrent.FutureTask;
import java.util.concurrent.atomic.AtomicBoolean;

// dex: classes.dex
public class c0 implements p {

    public final p f19005g;

    public final int f19006h;

    public final int f19007i;

    public final int f19008j;

    public int f19010l;

    public final AtomicBoolean f19000a = new AtomicBoolean(false);
    public final AtomicBoolean b = new AtomicBoolean(false);

    public final Queue<a> f19001c = new ConcurrentLinkedQueue();

    public final Executor f19002d = deobf.unlinked.q0.c.g(deobf.unlinked.q0.c.a());

    public final Object f19003e = new Object();

    public a f19004f = null;

    public final AtomicBoolean f19009k = new AtomicBoolean(false);

    public static class a {

        public final int f19011a;
        public final int b;

        public final ByteBuffer f19012c;

        public long f19013d;

        public a(ByteBuffer byteBuffer, deobf.unlinked.p.c cVar, int i10, int i11) {
            byteBuffer.rewind();
            int limit = byteBuffer.limit() - byteBuffer.position();
            if (limit == cVar.a()) {
                this.f19011a = i10;
                this.b = i11;
                this.f19012c = byteBuffer;
                this.f19013d = cVar.b();
                return;
            }
            throw new IllegalStateException("Byte buffer size is not match with packet info: " + limit + " != " + cVar.a());
        }

        public int a() {
            return this.f19012c.remaining();
        }

        public deobf.unlinked.p.c b(ByteBuffer byteBuffer) {
            int remaining;
            long j10 = this.f19013d;
            int position = this.f19012c.position();
            int position2 = byteBuffer.position();
            if (this.f19012c.remaining() > byteBuffer.remaining()) {
                remaining = byteBuffer.remaining();
                this.f19013d += t.d(t.g(remaining, this.f19011a), this.b);
                ByteBuffer duplicate = this.f19012c.duplicate();
                duplicate.position(position).limit(position + remaining);
                byteBuffer.put(duplicate).limit(position2 + remaining).position(position2);
            } else {
                remaining = this.f19012c.remaining();
                byteBuffer.put(this.f19012c).limit(position2 + remaining).position(position2);
            }
            this.f19012c.position(position + remaining);
            return deobf.unlinked.p.c.c(remaining, j10);
        }
    }

    public c0(p pVar, deobf.androidx.camera.video.internal.compat.quirk.i1.a aVar) {
        this.f19005g = pVar;
        int d10 = aVar.d();
        this.f19006h = d10;
        int e10 = aVar.e();
        this.f19007i = e10;
        deobf.androidx.camera.view.x2.g.b(((long) d10) > 0, "mBytesPerFrame must be greater than 0.");
        deobf.androidx.camera.view.x2.g.b(((long) e10) > 0, "mSampleRate must be greater than 0.");
        this.f19008j = 500;
        this.f19010l = d10 * Barcode.FORMAT_UPC_E;
    }

    public static /* synthetic */ void c(c0 c0Var) {
        c0Var.f19009k.set(false);
        c0Var.f19005g.stop();
        synchronized (c0Var.f19003e) {
            c0Var.f19004f = null;
            c0Var.f19001c.clear();
        }
    }

    public static /* synthetic */ void d(c0 c0Var) {
        c0Var.getClass();
        try {
            c0Var.f19005g.start();
            c0Var.l();
        } catch (deobf.unlinked.p.b e10) {
            throw new RuntimeException(e10);
        }
    }

    public static /* synthetic */ void e(c0 c0Var) {
        c0Var.f19009k.set(false);
        c0Var.f19005g.a();
        synchronized (c0Var.f19003e) {
            c0Var.f19004f = null;
            c0Var.f19001c.clear();
        }
    }

    private void i() {
        deobf.androidx.camera.view.x2.g.j(!this.b.get(), "AudioStream has been released.");
    }

    private void j() {
        deobf.androidx.camera.view.x2.g.j(this.f19000a.get(), "AudioStream has not been started.");
    }

    @Override // deobf.androidx.camera.video.internal.compat.quirk.i1.p
    public void a() {
        if (this.b.getAndSet(true)) {
            return;
        }
        this.f19002d.execute(new Runnable() { // from class: i1.b0
            @Override // java.lang.Runnable
            public final void run() {
                deobf.androidx.camera.camera2.internal.compat.quirk.c0.e(c0.this);
            }
        });
    }

    @Override // deobf.androidx.camera.video.internal.compat.quirk.i1.p
    public void b(final deobf.unlinked.p.a aVar, final Executor executor) {
        boolean z10 = true;
        deobf.androidx.camera.view.x2.g.j(!this.f19000a.get(), "AudioStream can not be started when setCallback.");
        i();
        if (aVar != null && executor == null) {
            z10 = false;
        }
        deobf.androidx.camera.view.x2.g.b(z10, "executor can't be null with non-null callback.");
        this.f19002d.execute(new Runnable() { // from class: i1.x
            @Override // java.lang.Runnable
            public final void run() {
                c0.this.f19005g.b(aVar, executor);
            }
        });
    }

    public final void k() {
        if (this.f19009k.get()) {
            ByteBuffer allocateDirect = ByteBuffer.allocateDirect(this.f19010l);
            a aVar = new a(allocateDirect, this.f19005g.read(allocateDirect), this.f19006h, this.f19007i);
            int i10 = this.f19008j;
            synchronized (this.f19003e) {
                try {
                    this.f19001c.offer(aVar);
                    while (this.f19001c.size() > i10) {
                        this.f19001c.poll();
                        r1.l("BufferedAudioStream", "Drop audio data due to full of queue.");
                    }
                } catch (Throwable th2) {
                    throw th2;
                }
            }
            if (this.f19009k.get()) {
                this.f19002d.execute(new Runnable() { // from class: i1.a0
                    @Override // java.lang.Runnable
                    public final void run() {
                        c0.this.k();
                    }
                });
            }
        }
    }

    public final void l() {
        if (this.f19009k.getAndSet(true)) {
            return;
        }
        k();
    }

    public final void m(int i10) {
        int i11 = this.f19010l;
        if (i11 == i10) {
            return;
        }
        int i12 = this.f19006h;
        this.f19010l = (i10 / i12) * i12;
        deobf.androidx.camera.view.r1.a("BufferedAudioStream", "Update buffer size from " + i11 + " to " + this.f19010l);
    }

    public final void n(final int i10) {
        this.f19002d.execute(new Runnable() { // from class: i1.z
            @Override // java.lang.Runnable
            public final void run() {
                c0.this.m(i10);
            }
        });
    }

    @Override // deobf.androidx.camera.video.internal.compat.quirk.i1.p
    @SuppressLint({"BanThreadSleep"})
    public deobf.unlinked.p.c read(ByteBuffer byteBuffer) {
        boolean z10;
        i();
        j();
        n(byteBuffer.remaining());
        deobf.unlinked.p.c c10 = deobf.unlinked.p.c.c(0, 0L);
        do {
            synchronized (this.f19003e) {
                try {
                    a aVar = this.f19004f;
                    this.f19004f = null;
                    if (aVar == null) {
                        aVar = this.f19001c.poll();
                    }
                    if (aVar != null) {
                        c10 = aVar.b(byteBuffer);
                        if (aVar.a() > 0) {
                            this.f19004f = aVar;
                        }
                    }
                } catch (Throwable th2) {
                    throw th2;
                }
            }
            z10 = c10.a() <= 0 && this.f19000a.get() && !this.b.get();
            if (z10) {
                try {
                    Thread.sleep(1L);
                } catch (InterruptedException e10) {
                    r1.m("BufferedAudioStream", "Interruption while waiting for audio data", e10);
                    return c10;
                }
            }
        } while (z10);
        return c10;
    }

    @Override // deobf.androidx.camera.video.internal.compat.quirk.i1.p
    public void start() {
        i();
        if (this.f19000a.getAndSet(true)) {
            return;
        }
        FutureTask futureTask = new FutureTask(new Runnable() { // from class: i1.y
            @Override // java.lang.Runnable
            public final void run() {
                c0.d(c0.this);
            }
        }, null);
        this.f19002d.execute(futureTask);
        try {
            futureTask.get();
        } catch (InterruptedException | ExecutionException e10) {
            this.f19000a.set(false);
            throw new deobf.unlinked.p.b(e10);
        }
    }

    @Override // deobf.androidx.camera.video.internal.compat.quirk.i1.p
    public void stop() {
        i();
        if (this.f19000a.getAndSet(false)) {
            this.f19002d.execute(new Runnable() { // from class: i1.w
                @Override // java.lang.Runnable
                public final void run() {
                    deobf.androidx.camera.camera2.internal.compat.quirk.c0.c(c0.this);
                }
            });
        }
    }
}
