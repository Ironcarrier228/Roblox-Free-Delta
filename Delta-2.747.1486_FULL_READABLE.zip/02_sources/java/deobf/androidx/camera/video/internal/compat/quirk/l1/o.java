package deobf.androidx.camera.video.internal.compat.quirk.l1;

import android.util.Range;
import android.util.Size;
import deobf.androidx.camera.video.internal.compat.quirk.f1.c2;
import deobf.androidx.camera.view.g0.k0;
import deobf.androidx.camera.view.g0.r1;
import deobf.androidx.camera.video.internal.compat.quirk.m1.p1;
import deobf.androidx.camera.camera2.internal.compat.quirk.n0.a2;
import deobf.androidx.camera.camera2.internal.compat.quirk.n0.a4;

// dex: classes.dex
public class o implements deobf.androidx.camera.view.x2.h<p1> {

    public final String f21860a;
    public final a4 b;

    public final c2 f21861c;

    public final Size f21862d;

    public final deobf.androidx.constraintlayout.widget.a2.c f21863e;

    public final k0 f21864f;

    public final Range<Integer> f21865g;

    public o(String str, a4 a4Var, c2 c2Var, Size size, deobf.androidx.constraintlayout.widget.a2.c cVar, k0 k0Var, Range<Integer> range) {
        this.f21860a = str;
        this.b = a4Var;
        this.f21861c = c2Var;
        this.f21862d = size;
        this.f21863e = cVar;
        this.f21864f = k0Var;
        this.f21865g = range;
    }

    @Override // deobf.androidx.camera.view.x2.h
    public p1 get() {
        CaptureEncodeRates c10 = m.c(this.f21861c, this.f21865g);
        deobf.androidx.camera.view.r1.a("VidEncVdPrflRslvr", "Resolved VIDEO frame rates: Capture frame rate = " + c10.getCaptureRate() + "fps. Encode frame rate = " + c10.getEncodeRate() + "fps.");
        Range<Integer> c11 = this.f21861c.c();
        deobf.androidx.camera.view.r1.a("VidEncVdPrflRslvr", "Using resolved VIDEO bitrate from EncoderProfiles");
        int f10 = m.f(this.f21863e.c(), this.f21864f.a(), this.f21863e.b(), c10.getEncodeRate(), this.f21863e.f(), this.f21862d.getWidth(), this.f21863e.l(), this.f21862d.getHeight(), this.f21863e.h(), c11);
        int j10 = this.f21863e.j();
        return p1.d().i(this.f21860a).h(this.b).k(this.f21862d).b(f10).c(c10.getCaptureRate()).f(c10.getEncodeRate()).j(j10).e(m.b(this.f21860a, j10)).a();
    }
}
