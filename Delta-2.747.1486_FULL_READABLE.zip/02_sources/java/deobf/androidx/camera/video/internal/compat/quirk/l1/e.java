package deobf.androidx.camera.video.internal.compat.quirk.l1;

import deobf.androidx.camera.video.internal.compat.quirk.l1.h;
import deobf.androidx.camera.video.internal.compat.quirk.l1.l;
import deobf.androidx.camera.camera2.internal.compat.quirk.n0.a2;

// dex: classes.dex
public abstract class e extends l {

    public static abstract class a extends deobf.unlinked.l.a<a> {
        public abstract e b();

        public abstract a c(deobf.androidx.constraintlayout.widget.a2.a aVar);
    }

    public static a c(String str) {
        return new deobf.com.roblox.protocols.mediapicker.h.b().d(str).a(-1);
    }

    public abstract deobf.androidx.constraintlayout.widget.a2.a d();
}
