package deobf.androidx.camera.video.internal.compat.quirk.i1;

import android.content.Context;

// dex: classes.dex
public interface q {
    p a(a aVar, Context context);
}
