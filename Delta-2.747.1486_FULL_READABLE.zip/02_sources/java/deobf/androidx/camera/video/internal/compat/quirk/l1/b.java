package deobf.androidx.camera.video.internal.compat.quirk.l1;

import android.util.Range;
import android.util.Rational;
import com.github.luben.zstd.BuildConfig;
import deobf.androidx.camera.view.g0.r1;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Locale;
import deobf.androidx.camera.camera2.internal.compat.quirk.n0.a2;
import deobf.androidx.camera.camera2.internal.compat.quirk.n0.a4;

// dex: classes.dex
public final class b {
    public static /* synthetic */ int a(int i10, Integer num, Integer num2) {
        int abs = Math.abs(num.intValue() - i10) - Math.abs(num2.intValue() - i10);
        return (int) (abs == 0 ? Math.signum(num.intValue() - num2.intValue()) : Math.signum(abs));
    }

    public static deobf.androidx.camera.video.internal.compat.quirk.m1.a b(e eVar, a4 a4Var, deobf.androidx.camera.video.internal.compat.quirk.i1.a aVar, deobf.androidx.camera.video.internal.compat.quirk.f1.a aVar2) {
        deobf.androidx.constraintlayout.widget.a2.a d10 = eVar.d();
        return (deobf.androidx.camera.video.internal.compat.quirk.m1.a) (d10 != null ? new c(eVar.a(), eVar.b(), a4Var, aVar2, aVar, d10) : new d(eVar.a(), eVar.b(), a4Var, aVar2, aVar)).get();
    }

    /* JADX WARN: Removed duplicated region for block: B:13:0x00d7  */
    public static deobf.androidx.camera.video.internal.compat.quirk.l1.e c(deobf.androidx.camera.video.internal.compat.quirk.f1.s r8, deobf.androidx.camera.video.internal.compat.quirk.h1.i r9) {
        /*
            int r0 = deobf.com.appsflyer.internal.r8.c()
            java.lang.String r0 = deobf.androidx.camera.video.internal.compat.quirk.f1.s.e(r0)
            int r1 = deobf.com.appsflyer.internal.r8.c()
            int r1 = deobf.androidx.camera.video.internal.compat.quirk.f1.s.f(r1)
            if (r9 == 0) goto Lca
            n0.a2$a r2 = r9.j()
            if (r2 == 0) goto Lca
            n0.a2$a r9 = r9.j()
            java.lang.String r2 = r9.e()
            int r3 = r9.f()
            java.lang.String r4 = "audio/none"
            boolean r4 = java.util.Objects.equals(r2, r4)
            java.lang.String r5 = ")]"
            java.lang.String r6 = "AudioConfigUtil"
            java.lang.String r7 = "(profile: "
            if (r4 == 0) goto L51
            java.lang.StringBuilder r8 = new java.lang.StringBuilder
            r8.<init>()
            java.lang.String r9 = "EncoderProfiles contains undefined AUDIO mime type so cannot be used. May rely on fallback defaults to derive settings [chosen mime type: "
            r8.append(r9)
            r8.append(r0)
            r8.append(r7)
            r8.append(r1)
            r8.append(r5)
            java.lang.String r8 = r8.toString()
            deobf.androidx.camera.view.g0.r1.a(r6, r8)
            goto Lca
        L51:
            int r8 = deobf.com.appsflyer.internal.r8.c()
            r4 = -1
            if (r8 != r4) goto L78
            java.lang.StringBuilder r8 = new java.lang.StringBuilder
            r8.<init>()
            java.lang.String r0 = "MediaSpec contains OUTPUT_FORMAT_AUTO. Using EncoderProfiles to derive AUDIO settings [mime type: "
            r8.append(r0)
            r8.append(r2)
            r8.append(r7)
            r8.append(r3)
            r8.append(r5)
            java.lang.String r8 = r8.toString()
            deobf.androidx.camera.view.g0.r1.a(r6, r8)
            r0 = r2
            r1 = r3
            goto Lcb
        L78:
            boolean r8 = java.util.Objects.equals(r0, r2)
            if (r8 == 0) goto L9f
            if (r1 != r3) goto L9f
            java.lang.StringBuilder r8 = new java.lang.StringBuilder
            r8.<init>()
            java.lang.String r0 = "MediaSpec audio mime/profile matches EncoderProfiles. Using EncoderProfiles to derive AUDIO settings [mime type: "
            r8.append(r0)
            r8.append(r2)
            r8.append(r7)
            r8.append(r1)
            r8.append(r5)
            java.lang.String r8 = r8.toString()
            deobf.androidx.camera.view.g0.r1.a(r6, r8)
            r0 = r2
            goto Lcb
        L9f:
            java.lang.StringBuilder r8 = new java.lang.StringBuilder
            r8.<init>()
            java.lang.String r9 = "MediaSpec audio mime or profile does not match EncoderProfiles, so EncoderProfiles settings cannot be used. May rely on fallback defaults to derive AUDIO settings [EncoderProfiles mime type: "
            r8.append(r9)
            r8.append(r2)
            r8.append(r7)
            r8.append(r3)
            java.lang.String r9 = "), chosen mime type: "
            r8.append(r9)
            r8.append(r0)
            r8.append(r7)
            r8.append(r1)
            r8.append(r5)
            java.lang.String r8 = r8.toString()
            deobf.androidx.camera.view.g0.r1.a(r6, r8)
        Lca:
            r9 = 0
        Lcb:
            l1.e$a r8 = deobf.androidx.camera.video.internal.compat.quirk.l1.e.c(r0)
            java.lang.Object r8 = deobf.com.appsflyer.internal.r8.a(r1)
            l1.e$a r8 = (deobf.androidx.camera.video.internal.compat.quirk.l1.e.a) r8
            if (r9 == 0) goto Lda
            deobf.com.appsflyer.internal.r8.c(r9)
        Lda:
            deobf.androidx.camera.video.internal.compat.quirk.l1.e r8 = deobf.com.appsflyer.internal.r8.b()
            return r8
        */
        throw new UnsupportedOperationException("Method not decompiled: deobf.androidx.camera.video.internal.compat.quirk.l1.b.c(deobf.androidx.camera.video.internal.compat.quirk.f1.s, deobf.androidx.camera.video.internal.compat.quirk.h1.i):deobf.androidx.camera.video.internal.compat.quirk.l1.e");
    }

    public static deobf.androidx.camera.video.internal.compat.quirk.i1.a d(e eVar, deobf.androidx.camera.video.internal.compat.quirk.f1.a aVar, Rational rational) {
        deobf.androidx.constraintlayout.widget.a2.a d10 = eVar.d();
        return (deobf.androidx.camera.video.internal.compat.quirk.i1.a) (d10 != null ? new f(aVar, d10, rational) : new g(aVar, rational)).get();
    }

    public static int e(deobf.androidx.camera.video.internal.compat.quirk.f1.a aVar) {
        int e10 = aVar.e();
        if (e10 == -1) {
            deobf.androidx.camera.view.r1.a("AudioConfigUtil", "Using default AUDIO source: 5");
            return 5;
        }
        deobf.androidx.camera.view.r1.a("AudioConfigUtil", "Using provided AUDIO source: " + e10);
        return e10;
    }

    public static int f(deobf.androidx.camera.video.internal.compat.quirk.f1.a aVar) {
        int f10 = aVar.f();
        if (f10 == -1) {
            deobf.androidx.camera.view.r1.a("AudioConfigUtil", "Using default AUDIO source format: 2");
            return 2;
        }
        deobf.androidx.camera.view.r1.a("AudioConfigUtil", "Using provided AUDIO source format: " + f10);
        return f10;
    }

    public static CaptureEncodeRates g(Range<Integer> range, int i10, int i11, int i12, Rational rational) {
        int i13;
        int c10;
        if (rational == null) {
            i13 = i(range, i11, i12, i10);
            c10 = i13;
        } else {
            Range<Integer> range2 = deobf.androidx.camera.video.internal.compat.quirk.f1.a.b;
            if (!range.equals(range2)) {
                range2 = Range.create(Integer.valueOf(k.b(range.getLower().intValue(), rational)), Integer.valueOf(k.b(range.getUpper().intValue(), rational)));
            }
            i13 = i(range2, i11, i12, k.b(i10, rational));
            c10 = k.c(i13, rational);
        }
        deobf.androidx.camera.view.r1.a("AudioConfigUtil", String.format(Locale.ENGLISH, "Resolved capture/encode sample rate %dHz/%dHz, [target sample rate range: %s, target sample rate: %d, channel count: %d, source format: %d, capture to encode sample rate ratio: %s]", Integer.valueOf(i13), Integer.valueOf(c10), range, Integer.valueOf(i10), Integer.valueOf(i11), Integer.valueOf(i12), rational));
        return new CaptureEncodeRates(i13, c10);
    }

    public static int h(int i10, int i11, int i12, int i13, int i14, Range<Integer> range) {
        int doubleValue = (int) (i10 * new Rational(i11, i12).doubleValue() * new Rational(i13, i14).doubleValue());
        String format = r1.f("AudioConfigUtil") ? String.format("Base Bitrate(%dbps) * Channel Count Ratio(%d / %d) * Sample Rate Ratio(%d / %d) = %d", Integer.valueOf(i10), Integer.valueOf(i11), Integer.valueOf(i12), Integer.valueOf(i13), Integer.valueOf(i14), Integer.valueOf(doubleValue)) : BuildConfig.FLAVOR;
        if (!deobf.androidx.camera.video.internal.compat.quirk.f1.a.f14871a.equals(range)) {
            Integer clamp = range.clamp(Integer.valueOf(doubleValue));
            doubleValue = clamp.intValue();
            if (r1.f("AudioConfigUtil")) {
                format = format + String.format("\nClamped to range %s -> %dbps", range, clamp);
            }
        }
        deobf.androidx.camera.view.r1.a("AudioConfigUtil", format);
        return doubleValue;
    }

    public static int i(Range<Integer> range, int i10, int i11, final int i12) {
        ArrayList arrayList = null;
        int i13 = 0;
        int i14 = i12;
        while (true) {
            if (!range.contains((Range<Integer>) Integer.valueOf(i14))) {
                deobf.androidx.camera.view.r1.a("AudioConfigUtil", "Sample rate " + i14 + "Hz is not in target range " + range);
            } else {
                if (deobf.androidx.camera.video.internal.compat.quirk.i1.n.o(i14, i10, i11)) {
                    return i14;
                }
                deobf.androidx.camera.view.r1.a("AudioConfigUtil", "Sample rate " + i14 + "Hz is not supported by audio source with channel count " + i10 + " and source format " + i11);
            }
            if (arrayList == null) {
                deobf.androidx.camera.view.r1.a("AudioConfigUtil", "Trying common sample rates in proximity order to target " + i12 + "Hz");
                arrayList = new ArrayList(deobf.androidx.camera.video.internal.compat.quirk.i1.a.f18995a);
                Collections.sort(arrayList, new Comparator() { // from class: l1.a
                    @Override // java.util.Comparator
                    public final int compare(Object obj, Object obj2) {
                        return b.a(i12, (Integer) obj, (Integer) obj2);
                    }
                });
            }
            if (i13 >= arrayList.size()) {
                deobf.androidx.camera.view.r1.a("AudioConfigUtil", "No sample rate found in target range or supported by audio source. Falling back to default sample rate of 44100Hz");
                return 44100;
            }
            i14 = ((Integer) arrayList.get(i13)).intValue();
            i13++;
        }
    }
}
