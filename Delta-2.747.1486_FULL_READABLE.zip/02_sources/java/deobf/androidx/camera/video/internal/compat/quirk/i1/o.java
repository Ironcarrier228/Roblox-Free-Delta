package deobf.androidx.camera.video.internal.compat.quirk.i1;

// dex: classes.dex
public class o extends Exception {
    public o(String str, Throwable th2) {
        super(str, th2);
    }
}
