package deobf.androidx.camera.video.internal.compat.quirk.i1;

import deobf.androidx.camera.video.internal.compat.quirk.i1.p;

// dex: classes.dex
public final class v extends deobf.unlinked.p.c {

    public final int f19082a;
    public final long b;

    public v(int i10, long j10) {
        this.f19082a = i10;
        this.b = j10;
    }

    @Override // deobf.androidx.camera.video.internal.compat.quirk.i1.p.c
    public int a() {
        return this.f19082a;
    }

    @Override // deobf.androidx.camera.video.internal.compat.quirk.i1.p.c
    public long b() {
        return this.b;
    }

    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (obj instanceof deobf.unlinked.p.c) {
            deobf.unlinked.p.c cVar = (deobf.unlinked.p.c) obj;
            if (this.f19082a == cVar.a() && this.b == cVar.b()) {
                return true;
            }
        }
        return false;
    }

    public int hashCode() {
        int i10 = (this.f19082a ^ 1000003) * 1000003;
        long j10 = this.b;
        return i10 ^ ((int) (j10 ^ (j10 >>> 32)));
    }

    public String toString() {
        return "PacketInfo{sizeInBytes=" + this.f19082a + ", timestampNs=" + this.b + "}";
    }
}
