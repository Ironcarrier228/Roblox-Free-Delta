package deobf.androidx.camera.video.internal.compat.quirk.i1;

import android.annotation.SuppressLint;
import com.github.luben.zstd.BuildConfig;
import deobf.androidx.camera.video.internal.compat.quirk.i1.u;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

// dex: classes.dex
public abstract class a {

    public static final List<Integer> f18995a = Collections.unmodifiableList(Arrays.asList(192000, 48000, 44100, 24000, 22050, 16000, 12000, 11025, 8000, 4800));

    public static abstract class AbstractC0357a {
        public abstract a a();

        public final a b() {
            a a10 = a();
            int c10 = a10.c();
            String str = BuildConfig.FLAVOR;
            if (c10 == -1) {
                str = BuildConfig.FLAVOR + " audioSource";
            }
            if (a10.e() <= 0) {
                str = str + " captureSampleRate";
            }
            if (a10.g() <= 0) {
                str = str + " encodeSampleRate";
            }
            if (a10.f() <= 0) {
                str = str + " channelCount";
            }
            if (a10.b() == -1) {
                str = str + " audioFormat";
            }
            if (str.isEmpty()) {
                return a10;
            }
            throw new IllegalArgumentException("Required settings missing or non-positive:" + str);
        }

        public abstract AbstractC0357a c(int i10);

        public abstract AbstractC0357a d(int i10);

        public abstract AbstractC0357a e(int i10);

        public abstract AbstractC0357a f(int i10);

        public abstract AbstractC0357a g(int i10);
    }

    @SuppressLint({"Range"})
    public static AbstractC0357a a() {
        return new u.b().d(-1).e(-1).g(-1).f(-1).c(-1);
    }

    public abstract int b();

    public abstract int c();

    public int d() {
        return t.f(b(), f());
    }

    public abstract int e();

    public abstract int f();

    public abstract int g();
}
