package deobf.androidx.camera.video.internal.compat.quirk.l1;

import deobf.androidx.camera.view.g0.r1;
import deobf.androidx.camera.camera2.internal.compat.quirk.n0.a2;
import deobf.androidx.camera.camera2.internal.compat.quirk.n0.a4;

// dex: classes.dex
public final class c implements deobf.androidx.camera.view.x2.h<deobf.androidx.camera.video.internal.compat.quirk.m1.a> {

    public final String f21832a;
    public final a4 b;

    public final int f21833c;

    public final deobf.androidx.camera.video.internal.compat.quirk.f1.a f21834d;

    public final deobf.androidx.camera.video.internal.compat.quirk.i1.a f21835e;

    public final deobf.androidx.constraintlayout.widget.a2.a f21836f;

    public c(String str, int i10, a4 a4Var, deobf.androidx.camera.video.internal.compat.quirk.f1.a aVar, deobf.androidx.camera.video.internal.compat.quirk.i1.a aVar2, deobf.androidx.constraintlayout.widget.a2.a aVar3) {
        this.f21832a = str;
        this.f21833c = i10;
        this.b = a4Var;
        this.f21834d = aVar;
        this.f21835e = aVar2;
        this.f21836f = aVar3;
    }

    @Override // deobf.androidx.camera.view.x2.h
    public deobf.androidx.camera.video.internal.compat.quirk.m1.a get() {
        deobf.androidx.camera.view.r1.a("AudioEncAdPrflRslvr", "Using resolved AUDIO bitrate from AudioProfile");
        return deobf.androidx.camera.video.internal.compat.quirk.m1.a.d().h(this.f21832a).i(this.f21833c).g(this.b).e(this.f21835e.f()).d(this.f21835e.e()).f(this.f21835e.g()).c(b.h(this.f21836f.b(), this.f21835e.f(), this.f21836f.c(), this.f21835e.g(), this.f21836f.g(), this.f21834d.b())).b();
    }
}
