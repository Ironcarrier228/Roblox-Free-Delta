package deobf.androidx.camera.video.internal.compat.quirk.l1;

import android.util.Range;
import android.util.Rational;
import deobf.androidx.camera.view.g0.r1;
import deobf.androidx.camera.camera2.internal.compat.quirk.n0.a2;

// dex: classes.dex
public final class f implements deobf.androidx.camera.view.x2.h<deobf.androidx.camera.video.internal.compat.quirk.i1.a> {

    public final deobf.androidx.camera.video.internal.compat.quirk.f1.a f21841a;
    public final deobf.androidx.constraintlayout.widget.a2.a b;

    public final Rational f21842c;

    public f(deobf.androidx.camera.video.internal.compat.quirk.f1.a aVar, deobf.androidx.constraintlayout.widget.a2.a aVar2, Rational rational) {
        this.f21841a = aVar;
        this.b = aVar2;
        this.f21842c = rational;
    }

    @Override // deobf.androidx.camera.view.x2.h
    public deobf.androidx.camera.video.internal.compat.quirk.i1.a get() {
        int e10 = b.e(this.f21841a);
        int f10 = b.f(this.f21841a);
        int c10 = this.f21841a.c();
        int c11 = this.b.c();
        if (c10 == -1) {
            deobf.androidx.camera.view.r1.a("AudioSrcAdPrflRslvr", "Resolved AUDIO channel count from AudioProfile: " + c11);
            c10 = c11;
        } else {
            deobf.androidx.camera.view.r1.a("AudioSrcAdPrflRslvr", "Media spec AUDIO channel count overrides AudioProfile [AudioProfile channel count: " + c11 + ", Resolved Channel Count: " + c10 + "]");
        }
        Range<Integer> d10 = this.f21841a.d();
        int g10 = this.b.g();
        CaptureEncodeRates g11 = b.g(d10, g10, c10, f10, this.f21842c);
        deobf.androidx.camera.view.r1.a("AudioSrcAdPrflRslvr", "Using resolved AUDIO sample rate or nearest supported from AudioProfile: Capture sample rate: " + g11.getCaptureRate() + "Hz. Encode sample rate: " + g11.getEncodeRate() + "Hz. [AudioProfile sample rate: " + g10 + "Hz]");
        return deobf.androidx.camera.video.internal.compat.quirk.i1.a.a().d(e10).c(f10).f(c10).e(g11.getCaptureRate()).g(g11.getEncodeRate()).b();
    }
}
