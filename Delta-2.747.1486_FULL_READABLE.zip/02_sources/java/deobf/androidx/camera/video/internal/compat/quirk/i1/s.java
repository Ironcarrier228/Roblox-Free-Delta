package deobf.androidx.camera.video.internal.compat.quirk.i1;

import android.annotation.SuppressLint;
import android.content.Context;
import android.media.AudioFormat;
import android.media.AudioManager;
import android.media.AudioRecord;
import android.media.AudioRecordingConfiguration;
import android.os.Build;
import androidx.camera.video.internal.compat.quirk.AudioTimestampFramePositionIncorrectQuirk;
import deobf.androidx.camera.view.g0.r1;
import deobf.androidx.camera.video.internal.compat.quirk.i1.p;
import java.nio.ByteBuffer;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.Executor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicReference;

// dex: classes.dex
public class s implements p {

    public static final long f19061m = TimeUnit.MILLISECONDS.toNanos(500);

    public AudioRecord f19062a;
    public final deobf.androidx.camera.video.internal.compat.quirk.i1.a b;

    public final int f19066f;

    public final int f19067g;

    public deobf.unlinked.p.a f19068h;

    public Executor f19069i;

    public long f19070j;

    public AudioManager.AudioRecordingCallback f19071k;

    public final AtomicBoolean f19063c = new AtomicBoolean(false);

    public final AtomicBoolean f19064d = new AtomicBoolean(false);

    public final AtomicReference<Boolean> f19065e = new AtomicReference<>(null);

    public boolean f19072l = false;

    public class a extends AudioManager.AudioRecordingCallback {
        public a() {
        }

        @Override // android.media.AudioManager.AudioRecordingCallback
        public void onRecordingConfigChanged(List<AudioRecordingConfiguration> list) {
            for (AudioRecordingConfiguration audioRecordingConfiguration : list) {
                if (deobf.unlinked.j1.b.a(audioRecordingConfiguration) == s.this.f19062a.getAudioSessionId()) {
                    s.this.o(deobf.unlinked.j1.d.b(audioRecordingConfiguration));
                    return;
                }
            }
        }
    }

    public s(deobf.androidx.camera.video.internal.compat.quirk.i1.a aVar, Context context) {
        if (!n(aVar.e(), aVar.f(), aVar.b())) {
            throw new UnsupportedOperationException(String.format("The combination of sample rate %d, channel count %d and audio format %d is not supported.", Integer.valueOf(aVar.e()), Integer.valueOf(aVar.f()), Integer.valueOf(aVar.b())));
        }
        this.b = aVar;
        this.f19067g = aVar.d();
        int l10 = l(aVar.e(), aVar.f(), aVar.b());
        deobf.androidx.camera.view.x2.g.i(l10 > 0);
        int i10 = l10 * 2;
        this.f19066f = i10;
        AudioRecord j10 = j(i10, aVar, context);
        this.f19062a = j10;
        e(j10);
    }

    public static void e(AudioRecord audioRecord) {
        if (audioRecord.getState() == 1) {
            return;
        }
        audioRecord.release();
        throw new deobf.unlinked.p.b("Unable to initialize AudioRecord");
    }

    public static AudioFormat h(int i10, int i11, int i12) {
        return new AudioFormat.Builder().setSampleRate(i10).setChannelMask(t.b(i11)).setEncoding(i12).build();
    }

    public static AudioFormat i(deobf.androidx.camera.video.internal.compat.quirk.i1.a aVar) {
        return h(aVar.e(), aVar.f(), aVar.b());
    }

    public static AudioRecord j(int i10, deobf.androidx.camera.video.internal.compat.quirk.i1.a aVar, Context context) {
        int i11 = Build.VERSION.SDK_INT;
        AudioFormat i12 = i(aVar);
        AudioRecord.Builder b = deobf.unlinked.j1.a.b();
        if (i11 >= 31 && context != null) {
            deobf.unlinked.j1.e.a(b, context);
        }
        deobf.unlinked.j1.a.d(b, aVar.c());
        deobf.unlinked.j1.a.c(b, i12);
        deobf.unlinked.j1.a.e(b, i10);
        try {
            return deobf.unlinked.j1.a.a(b);
        } catch (UnsupportedOperationException e10) {
            throw new IllegalArgumentException(e10);
        }
    }

    public static int l(int i10, int i11, int i12) {
        return AudioRecord.getMinBufferSize(i10, deobf.unlinked.t.a(i11), i12);
    }

    public static boolean m() {
        return deobf.unlinked.k1.c.b(AudioTimestampFramePositionIncorrectQuirk.class) != null;
    }

    public static boolean n(int i10, int i11, int i12) {
        if (i10 <= 0 || i11 <= 0 || l(i10, i11, i12) <= 0) {
            return false;
        }
        try {
            h(i10, i11, i12);
            return true;
        } catch (IllegalArgumentException unused) {
            return false;
        }
    }

    @Override // deobf.androidx.camera.video.internal.compat.quirk.i1.p
    public void a() {
        AudioManager.AudioRecordingCallback audioRecordingCallback;
        if (this.f19063c.getAndSet(true)) {
            return;
        }
        if (Build.VERSION.SDK_INT >= 29 && (audioRecordingCallback = this.f19071k) != null) {
            deobf.unlinked.j1.d.d(this.f19062a, audioRecordingCallback);
        }
        this.f19062a.release();
    }

    @Override // deobf.androidx.camera.video.internal.compat.quirk.i1.p
    public void b(deobf.unlinked.p.a aVar, Executor executor) {
        boolean z10 = true;
        deobf.androidx.camera.view.x2.g.j(!this.f19064d.get(), "AudioStream can not be started when setCallback.");
        f();
        if (aVar != null && executor == null) {
            z10 = false;
        }
        deobf.androidx.camera.view.x2.g.b(z10, "executor can't be null with non-null callback.");
        this.f19068h = aVar;
        this.f19069i = executor;
        if (Build.VERSION.SDK_INT >= 29) {
            AudioManager.AudioRecordingCallback audioRecordingCallback = this.f19071k;
            if (audioRecordingCallback != null) {
                deobf.unlinked.j1.d.d(this.f19062a, audioRecordingCallback);
            }
            if (aVar == null) {
                return;
            }
            if (this.f19071k == null) {
                this.f19071k = new a();
            }
            deobf.unlinked.j1.d.c(this.f19062a, executor, this.f19071k);
        }
    }

    public final void f() {
        deobf.androidx.camera.view.x2.g.j(!this.f19063c.get(), "AudioStream has been released.");
    }

    public final void g() {
        deobf.androidx.camera.view.x2.g.j(this.f19064d.get(), "AudioStream has not been started.");
    }

    /* JADX WARN: Removed duplicated region for block: B:10:0x0040  */
    /* JADX WARN: Removed duplicated region for block: B:13:0x0045 A[RETURN] */
    public final long k() {
        /*
            r9 = this;
            boolean r0 = r9.f19072l
            r1 = -1
            if (r0 != 0) goto L3b
            android.media.AudioTimestamp r0 = new android.media.AudioTimestamp
            r0.<init>()
            android.media.AudioRecord r3 = r9.f19062a
            r4 = 0
            int r3 = deobf.unlinked.j1.b.b(r3, r0, r4)
            if (r3 != 0) goto L34
            deobf.androidx.camera.video.internal.compat.quirk.i1.a r3 = r9.b
            int r3 = r3.e()
            long r4 = r9.f19070j
            long r3 = deobf.androidx.camera.video.internal.compat.quirk.i1.t.c(r3, r4, r0)
            long r5 = java.lang.System.nanoTime()
            long r5 = r3 - r5
            long r5 = java.lang.Math.abs(r5)
            long r7 = deobf.androidx.camera.video.internal.compat.quirk.i1.s.f19061m
            int r0 = (r5 > r7 ? 1 : (r5 == r7 ? 0 : -1))
            if (r0 <= 0) goto L3c
            r0 = 1
            r9.f19072l = r0
            goto L3b
        L34:
            java.lang.String r0 = "AudioStreamImpl"
            java.lang.String r3 = "Unable to get audio timestamp"
            deobf.androidx.camera.view.g0.r1.l(r0, r3)
        L3b:
            r3 = r1
        L3c:
            int r0 = (r3 > r1 ? 1 : (r3 == r1 ? 0 : -1))
            if (r0 != 0) goto L45
            long r0 = java.lang.System.nanoTime()
            return r0
        L45:
            return r3
        */
        throw new UnsupportedOperationException("Method not decompiled: deobf.androidx.camera.video.internal.compat.quirk.i1.s.k():long");
    }

    public void o(final boolean z10) {
        Executor executor = this.f19069i;
        final deobf.unlinked.p.a aVar = this.f19068h;
        if (executor == null || aVar == null || Objects.equals(this.f19065e.getAndSet(Boolean.valueOf(z10)), Boolean.valueOf(z10))) {
            return;
        }
        executor.execute(new Runnable() { // from class: i1.r
            @Override // java.lang.Runnable
            public final void run() {
                deobf.unlinked.p.a.this.a(z10);
            }
        });
    }

    @Override // deobf.androidx.camera.video.internal.compat.quirk.i1.p
    public deobf.unlinked.p.c read(ByteBuffer byteBuffer) {
        long j10;
        f();
        g();
        int read = this.f19062a.read(byteBuffer, this.f19066f);
        if (read > 0) {
            byteBuffer.limit(read);
            j10 = k();
            this.f19070j += t.g(read, this.f19067g);
        } else {
            j10 = 0;
        }
        return deobf.unlinked.p.c.c(read, j10);
    }

    @Override // deobf.androidx.camera.video.internal.compat.quirk.i1.p
    public void start() {
        f();
        if (this.f19064d.getAndSet(true)) {
            return;
        }
        if (m()) {
            e(this.f19062a);
        }
        this.f19062a.startRecording();
        boolean z10 = false;
        if (this.f19062a.getRecordingState() != 3) {
            this.f19064d.set(false);
            throw new deobf.unlinked.p.b("Unable to start AudioRecord with state: " + this.f19062a.getRecordingState());
        }
        this.f19070j = 0L;
        this.f19072l = false;
        this.f19065e.set(null);
        if (Build.VERSION.SDK_INT >= 29) {
            AudioRecordingConfiguration a10 = deobf.unlinked.j1.d.a(this.f19062a);
            z10 = a10 != null && deobf.unlinked.j1.d.b(a10);
        }
        o(z10);
    }

    @Override // deobf.androidx.camera.video.internal.compat.quirk.i1.p
    @SuppressLint({"MissingPermission"})
    public void stop() {
        f();
        if (this.f19064d.getAndSet(false)) {
            this.f19062a.stop();
            if (this.f19062a.getRecordingState() != 1) {
                r1.l("AudioStreamImpl", "Failed to stop AudioRecord with state: " + this.f19062a.getRecordingState());
            }
            if (m()) {
                this.f19062a.release();
                this.f19062a = j(this.f19066f, this.b, null);
            }
        }
    }
}
