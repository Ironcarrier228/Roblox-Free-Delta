package deobf.androidx.camera.video.internal.compat.quirk.l1;

import android.util.Range;
import android.util.Rational;
import deobf.androidx.camera.view.g0.r1;

// dex: classes.dex
public final class g implements deobf.androidx.camera.view.x2.h<deobf.androidx.camera.video.internal.compat.quirk.i1.a> {

    public final deobf.androidx.camera.video.internal.compat.quirk.f1.a f21843a;
    public final Rational b;

    public g(deobf.androidx.camera.video.internal.compat.quirk.f1.a aVar, Rational rational) {
        this.f21843a = aVar;
        this.b = rational;
    }

    @Override // deobf.androidx.camera.view.x2.h
    public deobf.androidx.camera.video.internal.compat.quirk.i1.a get() {
        int e10 = b.e(this.f21843a);
        int f10 = b.f(this.f21843a);
        int c10 = this.f21843a.c();
        if (c10 == -1) {
            deobf.androidx.camera.view.r1.a("DefAudioResolver", "Using fallback AUDIO channel count: 1");
            c10 = 1;
        } else {
            deobf.androidx.camera.view.r1.a("DefAudioResolver", "Using supplied AUDIO channel count: " + c10);
        }
        Range<Integer> d10 = this.f21843a.d();
        CaptureEncodeRates g10 = b.g(d10, deobf.androidx.camera.video.internal.compat.quirk.f1.a.b.equals(d10) ? 44100 : d10.getUpper().intValue(), c10, e10, this.b);
        deobf.androidx.camera.view.r1.a("DefAudioResolver", "Using AUDIO sample rate resolved from AudioSpec: Capture sample rate: " + g10.getCaptureRate() + "Hz. Encode sample rate: " + g10.getEncodeRate() + "Hz.");
        return deobf.androidx.camera.video.internal.compat.quirk.i1.a.a().d(e10).c(f10).f(c10).e(g10.getCaptureRate()).g(g10.getEncodeRate()).b();
    }
}
