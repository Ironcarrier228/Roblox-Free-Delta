package deobf.androidx.camera.video.internal.compat.quirk.l1;

// dex: classes.dex
public abstract class l {

    public static abstract class a<B> {
        public abstract B a(int i10);
    }

    public abstract String a();

    public abstract int b();
}
