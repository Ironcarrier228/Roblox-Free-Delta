package deobf.androidx.camera.video.internal.compat.quirk.l1;

import com.github.luben.zstd.BuildConfig;
import deobf.androidx.camera.video.internal.compat.quirk.l1.e;
import deobf.androidx.camera.camera2.internal.compat.quirk.n0.a2;

// dex: classes.dex
public final class h extends e {

    public final String f21844a;
    public final int b;

    public final deobf.androidx.constraintlayout.widget.a2.a f21845c;

    public static final class b extends deobf.com.roblox.client.e.a {

        public String f21846a;
        public Integer b;

        public deobf.androidx.constraintlayout.widget.a2.a f21847c;

        @Override // deobf.androidx.camera.video.internal.compat.quirk.l1.e.a
        public e b() {
            String str = this.f21846a;
            String str2 = BuildConfig.FLAVOR;
            if (str == null) {
                str2 = BuildConfig.FLAVOR + " mimeType";
            }
            if (this.b == null) {
                str2 = str2 + " profile";
            }
            if (str2.isEmpty()) {
                return new h(this.f21846a, this.b.intValue(), this.f21847c);
            }
            throw new IllegalStateException("Missing required properties:" + str2);
        }

        @Override // deobf.androidx.camera.video.internal.compat.quirk.l1.e.a
        public deobf.com.roblox.client.e.a c(deobf.androidx.constraintlayout.widget.a2.a aVar) {
            this.f21847c = aVar;
            return this;
        }

        public deobf.com.roblox.client.e.a d(String str) {
            if (str == null) {
                throw new NullPointerException("Null mimeType");
            }
            this.f21846a = str;
            return this;
        }

        @Override // deobf.androidx.camera.video.internal.compat.quirk.l1.l.a
        public deobf.com.roblox.client.e.a a(int i10) {
            this.b = Integer.valueOf(i10);
            return this;
        }
    }

    @Override // deobf.androidx.camera.video.internal.compat.quirk.l1.l
    public String a() {
        return this.f21844a;
    }

    @Override // deobf.androidx.camera.video.internal.compat.quirk.l1.l
    public int b() {
        return this.b;
    }

    @Override // deobf.androidx.camera.video.internal.compat.quirk.l1.e
    public deobf.androidx.constraintlayout.widget.a2.a d() {
        return this.f21845c;
    }

    public boolean equals(Object obj) {
        deobf.androidx.constraintlayout.widget.a2.a aVar;
        if (obj == this) {
            return true;
        }
        if (obj instanceof e) {
            e eVar = (e) obj;
            if (this.f21844a.equals(eVar.a()) && this.b == eVar.b() && ((aVar = this.f21845c) != null ? aVar.equals(eVar.d()) : eVar.d() == null)) {
                return true;
            }
        }
        return false;
    }

    public int hashCode() {
        int hashCode = (((this.f21844a.hashCode() ^ 1000003) * 1000003) ^ this.b) * 1000003;
        deobf.androidx.constraintlayout.widget.a2.a aVar = this.f21845c;
        return hashCode ^ (aVar == null ? 0 : aVar.hashCode());
    }

    public String toString() {
        return "AudioMimeInfo{mimeType=" + this.f21844a + ", profile=" + this.b + ", compatibleAudioProfile=" + this.f21845c + "}";
    }

    public h(String str, int i10, deobf.androidx.constraintlayout.widget.a2.a aVar) {
        this.f21844a = str;
        this.b = i10;
        this.f21845c = aVar;
    }
}
