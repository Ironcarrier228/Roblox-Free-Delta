package deobf.androidx.camera.video.internal.compat.quirk.l1;

import android.util.Range;
import deobf.androidx.camera.view.g0.r1;
import deobf.androidx.camera.camera2.internal.compat.quirk.n0.a4;

// dex: classes.dex
public final class d implements deobf.androidx.camera.view.x2.h<deobf.androidx.camera.video.internal.compat.quirk.m1.a> {

    public final String f21837a;
    public final int b;

    public final deobf.androidx.camera.video.internal.compat.quirk.f1.a f21838c;

    public final deobf.androidx.camera.video.internal.compat.quirk.i1.a f21839d;

    public final a4 f21840e;

    public d(String str, int i10, a4 a4Var, deobf.androidx.camera.video.internal.compat.quirk.f1.a aVar, deobf.androidx.camera.video.internal.compat.quirk.i1.a aVar2) {
        this.f21837a = str;
        this.b = i10;
        this.f21840e = a4Var;
        this.f21838c = aVar;
        this.f21839d = aVar2;
    }

    @Override // deobf.androidx.camera.view.x2.h
    public deobf.androidx.camera.video.internal.compat.quirk.m1.a get() {
        Range<Integer> b = this.f21838c.b();
        deobf.androidx.camera.view.r1.a("AudioEncCfgDefaultRslvr", "Using fallback AUDIO bitrate");
        return deobf.androidx.camera.video.internal.compat.quirk.m1.a.d().h(this.f21837a).i(this.b).g(this.f21840e).e(this.f21839d.f()).d(this.f21839d.e()).f(this.f21839d.g()).c(b.h(156000, this.f21839d.f(), 2, this.f21839d.g(), 48000, b)).b();
    }
}
