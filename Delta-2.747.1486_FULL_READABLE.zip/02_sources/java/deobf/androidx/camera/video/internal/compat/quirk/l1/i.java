package deobf.androidx.camera.video.internal.compat.quirk.l1;

import com.github.luben.zstd.BuildConfig;
import deobf.androidx.camera.video.internal.compat.quirk.l1.p;
import deobf.androidx.camera.camera2.internal.compat.quirk.n0.a2;

// dex: classes.dex
public final class i extends p {

    public final String f21848a;
    public final int b;

    public final deobf.androidx.constraintlayout.widget.a2.c f21849c;

    public static final class b extends deobf.unlinked.p.a {

        public String f21850a;
        public Integer b;

        public deobf.androidx.constraintlayout.widget.a2.c f21851c;

        @Override // deobf.androidx.camera.video.internal.compat.quirk.l1.p.a
        public p b() {
            String str = this.f21850a;
            String str2 = BuildConfig.FLAVOR;
            if (str == null) {
                str2 = BuildConfig.FLAVOR + " mimeType";
            }
            if (this.b == null) {
                str2 = str2 + " profile";
            }
            if (str2.isEmpty()) {
                return new i(this.f21850a, this.b.intValue(), this.f21851c);
            }
            throw new IllegalStateException("Missing required properties:" + str2);
        }

        @Override // deobf.androidx.camera.video.internal.compat.quirk.l1.p.a
        public deobf.unlinked.p.a c(deobf.androidx.constraintlayout.widget.a2.c cVar) {
            this.f21851c = cVar;
            return this;
        }

        public deobf.unlinked.p.a d(String str) {
            if (str == null) {
                throw new NullPointerException("Null mimeType");
            }
            this.f21850a = str;
            return this;
        }

        @Override // deobf.androidx.camera.video.internal.compat.quirk.l1.l.a
        public deobf.unlinked.p.a a(int i10) {
            this.b = Integer.valueOf(i10);
            return this;
        }
    }

    @Override // deobf.androidx.camera.video.internal.compat.quirk.l1.l
    public String a() {
        return this.f21848a;
    }

    @Override // deobf.androidx.camera.video.internal.compat.quirk.l1.l
    public int b() {
        return this.b;
    }

    @Override // deobf.androidx.camera.video.internal.compat.quirk.l1.p
    public deobf.androidx.constraintlayout.widget.a2.c d() {
        return this.f21849c;
    }

    public boolean equals(Object obj) {
        deobf.androidx.constraintlayout.widget.a2.c cVar;
        if (obj == this) {
            return true;
        }
        if (obj instanceof p) {
            p pVar = (p) obj;
            if (this.f21848a.equals(pVar.a()) && this.b == pVar.b() && ((cVar = this.f21849c) != null ? cVar.equals(pVar.d()) : pVar.d() == null)) {
                return true;
            }
        }
        return false;
    }

    public int hashCode() {
        int hashCode = (((this.f21848a.hashCode() ^ 1000003) * 1000003) ^ this.b) * 1000003;
        deobf.androidx.constraintlayout.widget.a2.c cVar = this.f21849c;
        return hashCode ^ (cVar == null ? 0 : cVar.hashCode());
    }

    public String toString() {
        return "VideoMimeInfo{mimeType=" + this.f21848a + ", profile=" + this.b + ", compatibleVideoProfile=" + this.f21849c + "}";
    }

    public i(String str, int i10, deobf.androidx.constraintlayout.widget.a2.c cVar) {
        this.f21848a = str;
        this.b = i10;
        this.f21849c = cVar;
    }
}
