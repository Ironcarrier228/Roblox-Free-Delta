package deobf.androidx.camera.video.internal.compat.quirk.i1;

import android.content.Context;
import deobf.androidx.camera.view.g0.r1;
import deobf.androidx.camera.video.internal.compat.quirk.h1.c;
import deobf.androidx.camera.video.internal.compat.quirk.i1.n;
import deobf.androidx.camera.video.internal.compat.quirk.i1.p;
import java.nio.ByteBuffer;
import java.nio.ShortBuffer;
import java.util.Objects;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Executor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicReference;
import deobf.androidx.camera.video.internal.compat.quirk.m1.h1;
import deobf.androidx.camera.camera2.internal.compat.quirk.n0.a3;
import deobf.androidx.work.y1.c;

// dex: classes.dex
public final class n {

    public final Executor f19032a;
    public final AtomicReference<Boolean> b;

    public final AtomicBoolean f19033c;

    public final p f19034d;

    public final e0 f19035e;

    public final long f19036f;

    public e f19037g;

    public deobf.com.withpersona.sdk2.inquiry.c.a f19038h;

    public boolean f19039i;

    public Executor f19040j;

    public c f19041k;

    public deobf.androidx.camera.video.internal.compat.quirk.h1.c<? extends h1> f19042l;

    public deobf.androidx.camera.view.r0.c<h1> f19043m;

    public deobf.unlinked.a3.a<deobf.com.withpersona.sdk2.inquiry.c.a> f19044n;

    public boolean f19045o;

    public long f19046p;

    public boolean f19047q;

    public boolean f19048r;

    public byte[] f19049s;

    public double f19050t;

    public long f19051u;

    public final int f19052v;

    public final int f19053w;

    public class a implements deobf.unlinked.a3.a<deobf.com.withpersona.sdk2.inquiry.c.a> {

        public final /* synthetic */ deobf.androidx.camera.video.internal.compat.quirk.h1.c f19054a;

        public a(deobf.androidx.camera.video.internal.compat.quirk.h1.c cVar) {
            this.f19054a = cVar;
        }

        @Override // deobf.androidx.camera.camera2.internal.compat.quirk.n0.a3.a
        public void a(deobf.com.withpersona.sdk2.inquiry.c.a aVar) {
            Objects.requireNonNull(aVar);
            if (n.this.f19042l == this.f19054a) {
                deobf.androidx.camera.view.r1.a("AudioSource", "Receive BufferProvider state change: " + n.this.f19038h + " to " + aVar);
                n nVar = n.this;
                if (nVar.f19038h != aVar) {
                    nVar.f19038h = aVar;
                    nVar.H();
                }
            }
        }

        @Override // deobf.androidx.camera.camera2.internal.compat.quirk.n0.a3.a
        public void onError(Throwable th2) {
            n nVar = n.this;
            if (nVar.f19042l == this.f19054a) {
                nVar.r(th2);
            }
        }
    }

    public class b implements deobf.androidx.camera.view.r0.c<h1> {

        public final /* synthetic */ deobf.androidx.camera.video.internal.compat.quirk.h1.c f19055a;

        public b(deobf.androidx.camera.video.internal.compat.quirk.h1.c cVar) {
            this.f19055a = cVar;
        }

        @Override // deobf.androidx.camera.view.r0.c
        public void onSuccess(h1 h1Var) {
            n nVar = n.this;
            if (!nVar.f19039i || nVar.f19042l != this.f19055a) {
                h1Var.cancel();
                return;
            }
            if (nVar.f19045o && nVar.p()) {
                n.this.y();
            }
            p m10 = n.this.m();
            ByteBuffer v8 = h1Var.v();
            deobf.unlinked.p.c read = m10.read(v8);
            if (read.a() > 0) {
                n nVar2 = n.this;
                if (nVar2.f19048r) {
                    nVar2.u(v8, read.a());
                }
                if (n.this.f19040j != null) {
                    long b = read.b();
                    n nVar3 = n.this;
                    if (b - nVar3.f19051u >= 200) {
                        nVar3.f19051u = read.b();
                        n.this.v(v8);
                    }
                }
                v8.limit(v8.position() + read.a());
                h1Var.c(TimeUnit.NANOSECONDS.toMicros(read.b()));
                h1Var.b();
            } else {
                r1.l("AudioSource", "Unable to read data from AudioStream.");
                h1Var.cancel();
            }
            n.this.z();
        }

        @Override // deobf.androidx.camera.view.r0.c
        public void onFailure(Throwable th2) {
            if (n.this.f19042l != this.f19055a) {
                return;
            }
            deobf.androidx.camera.view.r1.a("AudioSource", "Unable to get input buffer, the BufferProvider could be transitioning to INACTIVE state.");
            if (th2 instanceof IllegalStateException) {
                return;
            }
            n.this.r(th2);
        }
    }

    public interface c {
        void a(boolean z10);

        void b(double d10);

        default void c(boolean z10) {
        }

        void onError(Throwable th2);
    }

    public class d implements deobf.unlinked.p.a {
        public d() {
        }

        @Override // deobf.androidx.camera.video.internal.compat.quirk.i1.p.a
        public void a(boolean z10) {
            n nVar = n.this;
            nVar.f19047q = z10;
            if (nVar.f19037g == e.STARTED) {
                nVar.s();
            }
        }
    }

    public enum e {
        CONFIGURED,
        STARTED,
        RELEASED
    }

    public n(deobf.androidx.camera.video.internal.compat.quirk.i1.a aVar, Executor executor, Context context) {
        this(aVar, executor, context, new q() { // from class: i1.h
            @Override // deobf.androidx.camera.video.internal.compat.quirk.i1.q
            public final p a(a aVar2, Context context2) {
                return new s(aVar2, context2);
            }
        }, 3000L);
    }

    public static /* synthetic */ Object a(final n nVar, final deobf.com.withpersona.sdk2.inquiry.c.a aVar) {
        nVar.f19032a.execute(new Runnable() { // from class: i1.k
            @Override // java.lang.Runnable
            public final void run() {
                n.f(n.this, aVar);
            }
        });
        return "AudioSource-release";
    }

    public static /* synthetic */ void b(n nVar, Executor executor, c cVar) {
        int ordinal = nVar.f19037g.ordinal();
        if (ordinal == 0) {
            nVar.f19040j = executor;
            nVar.f19041k = cVar;
        } else if (ordinal == 1 || ordinal == 2) {
            throw new AssertionError("The audio recording callback must be registered before the audio source is started.");
        }
    }

    public static /* synthetic */ void d(n nVar, deobf.androidx.camera.video.internal.compat.quirk.h1.c cVar) {
        int ordinal = nVar.f19037g.ordinal();
        if (ordinal != 0 && ordinal != 1) {
            if (ordinal == 2) {
                throw new AssertionError("AudioSource is released");
            }
        } else if (nVar.f19042l != cVar) {
            nVar.x(cVar);
        }
    }

    public static /* synthetic */ void e(n nVar, boolean z10) {
        int ordinal = nVar.f19037g.ordinal();
        if (ordinal != 0 && ordinal != 1) {
            if (ordinal == 2) {
                throw new AssertionError("AudioSource is released");
            }
        } else {
            if (nVar.f19048r == z10) {
                return;
            }
            nVar.f19048r = z10;
            if (nVar.f19037g == e.STARTED) {
                nVar.s();
            }
        }
    }

    public static /* synthetic */ void f(n nVar, deobf.com.withpersona.sdk2.inquiry.c.a aVar) {
        nVar.getClass();
        try {
            int ordinal = nVar.f19037g.ordinal();
            if (ordinal == 0 || ordinal == 1) {
                nVar.x(null);
                nVar.f19035e.a();
                nVar.f19034d.a();
                nVar.G();
                nVar.C(e.RELEASED);
            }
            aVar.c(null);
        } catch (Throwable th2) {
            aVar.f(th2);
        }
    }

    public static /* synthetic */ void g(n nVar) {
        int ordinal = nVar.f19037g.ordinal();
        if (ordinal == 1) {
            nVar.C(e.CONFIGURED);
            nVar.H();
        } else {
            if (ordinal != 2) {
                return;
            }
            r1.l("AudioSource", "AudioSource is released. Calling stop() is a no-op.");
        }
    }

    public static /* synthetic */ void k(n nVar, boolean z10) {
        int ordinal = nVar.f19037g.ordinal();
        if (ordinal != 0) {
            if (ordinal == 2) {
                throw new AssertionError("AudioSource is released");
            }
            return;
        }
        nVar.b.set(null);
        nVar.f19033c.set(false);
        nVar.C(e.STARTED);
        nVar.q(z10);
        nVar.H();
    }

    public static deobf.com.withpersona.sdk2.inquiry.c.a l(deobf.androidx.camera.video.internal.compat.quirk.h1.c<? extends h1> cVar) {
        try {
            deobf.androidx.camera.view.pe.x<? extends h1> b10 = cVar.b();
            if (b10.isDone()) {
                return (deobf.com.withpersona.sdk2.inquiry.c.a) b10.get();
            }
        } catch (InterruptedException | ExecutionException unused) {
        }
        return null;
    }

    public static long n() {
        return System.nanoTime();
    }

    public static boolean o(int i10, int i11, int i12) {
        return s.n(i10, i11, i12);
    }

    public void A(final Executor executor, final c cVar) {
        this.f19032a.execute(new Runnable() { // from class: i1.l
            @Override // java.lang.Runnable
            public final void run() {
                n.b(n.this, executor, cVar);
            }
        });
    }

    public void B(final deobf.androidx.camera.video.internal.compat.quirk.h1.c<? extends h1> cVar) {
        this.f19032a.execute(new Runnable() { // from class: i1.g
            @Override // java.lang.Runnable
            public final void run() {
                n.d(n.this, cVar);
            }
        });
    }

    public void C(e eVar) {
        deobf.androidx.camera.view.r1.a("AudioSource", "Transitioning internal state: " + this.f19037g + " --> " + eVar);
        this.f19037g = eVar;
    }

    public void D(final boolean z10) {
        this.f19032a.execute(new Runnable() { // from class: i1.f
            @Override // java.lang.Runnable
            public final void run() {
                n.k(n.this, z10);
            }
        });
    }

    public final void E() {
        if (this.f19039i) {
            return;
        }
        try {
            deobf.androidx.camera.view.r1.a("AudioSource", "startSendingAudio");
            this.f19034d.start();
            this.f19045o = false;
        } catch (deobf.unlinked.p.b e10) {
            r1.m("AudioSource", "Failed to start AudioStream", e10);
            this.f19045o = true;
            this.f19035e.start();
            this.f19046p = n();
            s();
        }
        this.f19039i = true;
        z();
    }

    public void F() {
        this.f19032a.execute(new Runnable() { // from class: i1.b
            @Override // java.lang.Runnable
            public final void run() {
                n.g(n.this);
            }
        });
    }

    public final void G() {
        if (this.f19039i) {
            this.f19039i = false;
            deobf.androidx.camera.view.r1.a("AudioSource", "stopSendingAudio");
            this.f19034d.stop();
        }
    }

    public void H() {
        if (this.f19037g != e.STARTED) {
            G();
            return;
        }
        boolean z10 = this.f19038h == deobf.com.withpersona.sdk2.inquiry.c.a.ACTIVE;
        t(!z10);
        if (z10) {
            E();
        } else {
            G();
        }
    }

    public p m() {
        return this.f19045o ? this.f19035e : this.f19034d;
    }

    public boolean p() {
        deobf.androidx.camera.view.x2.g.i(this.f19046p > 0);
        return n() - this.f19046p >= this.f19036f;
    }

    public void q(final boolean z10) {
        this.f19032a.execute(new Runnable() { // from class: i1.i
            @Override // java.lang.Runnable
            public final void run() {
                n.e(n.this, z10);
            }
        });
    }

    public void r(final Throwable th2) {
        Executor executor = this.f19040j;
        final c cVar = this.f19041k;
        if (executor == null || cVar == null) {
            return;
        }
        executor.execute(new Runnable() { // from class: i1.d
            @Override // java.lang.Runnable
            public final void run() {
                n.c.this.onError(th2);
            }
        });
    }

    public void s() {
        Executor executor = this.f19040j;
        final c cVar = this.f19041k;
        if (executor == null || cVar == null) {
            return;
        }
        final boolean z10 = this.f19048r || this.f19045o || this.f19047q;
        if (Objects.equals(this.b.getAndSet(Boolean.valueOf(z10)), Boolean.valueOf(z10))) {
            return;
        }
        executor.execute(new Runnable() { // from class: i1.j
            @Override // java.lang.Runnable
            public final void run() {
                n.c.this.a(z10);
            }
        });
    }

    public void t(final boolean z10) {
        Executor executor = this.f19040j;
        final c cVar = this.f19041k;
        if (executor == null || cVar == null || this.f19033c.getAndSet(z10) == z10) {
            return;
        }
        executor.execute(new Runnable() { // from class: i1.c
            @Override // java.lang.Runnable
            public final void run() {
                n.c.this.c(z10);
            }
        });
    }

    public void u(ByteBuffer byteBuffer, int i10) {
        byte[] bArr = this.f19049s;
        if (bArr == null || bArr.length < i10) {
            this.f19049s = new byte[i10];
        }
        int position = byteBuffer.position();
        byteBuffer.put(this.f19049s, 0, i10);
        byteBuffer.limit(byteBuffer.position()).position(position);
    }

    public void v(ByteBuffer byteBuffer) {
        Executor executor = this.f19040j;
        final c cVar = this.f19041k;
        if (this.f19052v == 2) {
            ShortBuffer asShortBuffer = byteBuffer.asShortBuffer();
            double d10 = 0.0d;
            while (asShortBuffer.hasRemaining()) {
                d10 = Math.max(d10, Math.abs((int) asShortBuffer.get()));
            }
            this.f19050t = d10 / 32767.0d;
            if (executor == null || cVar == null) {
                return;
            }
            executor.execute(new Runnable() { // from class: i1.m
                @Override // java.lang.Runnable
                public final void run() {
                    cVar.b(n.this.f19050t);
                }
            });
        }
    }

    public deobf.androidx.camera.view.pe.x<Void> w() {
        return deobf.androidx.work.y1.c.a(new c.InterfaceC0761c() { // from class: i1.e
            @Override // deobf.androidx.work.y1.c.InterfaceC0761c
            public final Object a(deobf.com.withpersona.sdk2.inquiry.c.a aVar) {
                return deobf.unlinked.n.a(n.this, aVar);
            }
        });
    }

    public final void x(deobf.androidx.camera.video.internal.compat.quirk.h1.c<? extends h1> cVar) {
        deobf.androidx.camera.video.internal.compat.quirk.h1.c<? extends h1> cVar2 = this.f19042l;
        if (cVar2 != null) {
            deobf.unlinked.a3.a<deobf.com.withpersona.sdk2.inquiry.c.a> aVar = this.f19044n;
            Objects.requireNonNull(aVar);
            cVar2.d(aVar);
            this.f19042l = null;
            this.f19044n = null;
            this.f19043m = null;
            this.f19038h = deobf.com.withpersona.sdk2.inquiry.c.a.INACTIVE;
            H();
        }
        if (cVar != null) {
            this.f19042l = cVar;
            this.f19044n = new a(cVar);
            this.f19043m = new b(cVar);
            deobf.com.withpersona.sdk2.inquiry.c.a l10 = l(cVar);
            if (l10 != null) {
                this.f19038h = l10;
                H();
            }
            this.f19042l.c(this.f19032a, this.f19044n);
        }
    }

    public void y() {
        deobf.androidx.camera.view.x2.g.i(this.f19045o);
        try {
            this.f19034d.start();
            deobf.androidx.camera.view.r1.a("AudioSource", "Retry start AudioStream succeed");
            this.f19035e.stop();
            this.f19045o = false;
        } catch (deobf.unlinked.p.b e10) {
            r1.m("AudioSource", "Retry start AudioStream failed", e10);
            this.f19046p = n();
        }
    }

    public void z() {
        deobf.androidx.camera.video.internal.compat.quirk.h1.c<? extends h1> cVar = this.f19042l;
        Objects.requireNonNull(cVar);
        deobf.androidx.camera.view.pe.x<? extends h1> e10 = cVar.e();
        deobf.androidx.camera.view.r0.c<h1> cVar2 = this.f19043m;
        Objects.requireNonNull(cVar2);
        deobf.androidx.camera.view.r0.n.j(e10, cVar2, this.f19032a);
    }

    public n(deobf.androidx.camera.video.internal.compat.quirk.i1.a aVar, Executor executor, Context context, q qVar, long j10) {
        this.b = new AtomicReference<>(null);
        this.f19033c = new AtomicBoolean(false);
        this.f19037g = e.CONFIGURED;
        this.f19038h = deobf.com.withpersona.sdk2.inquiry.c.a.INACTIVE;
        this.f19051u = 0L;
        Executor g10 = deobf.unlinked.q0.c.g(executor);
        this.f19032a = g10;
        this.f19036f = TimeUnit.MILLISECONDS.toNanos(j10);
        try {
            c0 c0Var = new c0(qVar.a(aVar, context), aVar);
            this.f19034d = c0Var;
            c0Var.b(new d(), g10);
            this.f19035e = new e0(aVar);
            this.f19052v = aVar.b();
            this.f19053w = aVar.c();
        } catch (deobf.unlinked.p.b | IllegalArgumentException e10) {
            throw new o("Unable to create AudioStream", e10);
        }
    }
}
