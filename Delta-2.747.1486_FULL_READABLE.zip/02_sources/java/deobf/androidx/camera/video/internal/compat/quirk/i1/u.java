package deobf.androidx.camera.video.internal.compat.quirk.i1;

import com.github.luben.zstd.BuildConfig;
import deobf.androidx.camera.video.internal.compat.quirk.i1.a;

// dex: classes.dex
public final class u extends deobf.androidx.camera.video.internal.compat.quirk.i1.a {
    public final int b;

    public final int f19074c;

    public final int f19075d;

    public final int f19076e;

    public final int f19077f;

    public static final class b extends a.AbstractC0357a {

        public Integer f19078a;
        public Integer b;

        public Integer f19079c;

        public Integer f19080d;

        public Integer f19081e;

        @Override // deobf.androidx.camera.video.internal.compat.quirk.i1.a.AbstractC0357a
        public deobf.androidx.camera.video.internal.compat.quirk.i1.a a() {
            Integer num = this.f19078a;
            String str = BuildConfig.FLAVOR;
            if (num == null) {
                str = BuildConfig.FLAVOR + " audioSource";
            }
            if (this.b == null) {
                str = str + " captureSampleRate";
            }
            if (this.f19079c == null) {
                str = str + " encodeSampleRate";
            }
            if (this.f19080d == null) {
                str = str + " channelCount";
            }
            if (this.f19081e == null) {
                str = str + " audioFormat";
            }
            if (str.isEmpty()) {
                return new u(this.f19078a.intValue(), this.b.intValue(), this.f19079c.intValue(), this.f19080d.intValue(), this.f19081e.intValue());
            }
            throw new IllegalStateException("Missing required properties:" + str);
        }

        @Override // deobf.androidx.camera.video.internal.compat.quirk.i1.a.AbstractC0357a
        public a.AbstractC0357a c(int i10) {
            this.f19081e = Integer.valueOf(i10);
            return this;
        }

        @Override // deobf.androidx.camera.video.internal.compat.quirk.i1.a.AbstractC0357a
        public a.AbstractC0357a d(int i10) {
            this.f19078a = Integer.valueOf(i10);
            return this;
        }

        @Override // deobf.androidx.camera.video.internal.compat.quirk.i1.a.AbstractC0357a
        public a.AbstractC0357a e(int i10) {
            this.b = Integer.valueOf(i10);
            return this;
        }

        @Override // deobf.androidx.camera.video.internal.compat.quirk.i1.a.AbstractC0357a
        public a.AbstractC0357a f(int i10) {
            this.f19080d = Integer.valueOf(i10);
            return this;
        }

        @Override // deobf.androidx.camera.video.internal.compat.quirk.i1.a.AbstractC0357a
        public a.AbstractC0357a g(int i10) {
            this.f19079c = Integer.valueOf(i10);
            return this;
        }
    }

    @Override // deobf.androidx.camera.video.internal.compat.quirk.i1.a
    public int b() {
        return this.f19077f;
    }

    @Override // deobf.androidx.camera.video.internal.compat.quirk.i1.a
    public int c() {
        return this.b;
    }

    @Override // deobf.androidx.camera.video.internal.compat.quirk.i1.a
    public int e() {
        return this.f19074c;
    }

    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (obj instanceof deobf.androidx.camera.video.internal.compat.quirk.i1.a) {
            deobf.androidx.camera.video.internal.compat.quirk.i1.a aVar = (deobf.androidx.camera.video.internal.compat.quirk.i1.a) obj;
            if (this.b == aVar.c() && this.f19074c == aVar.e() && this.f19075d == aVar.g() && this.f19076e == aVar.f() && this.f19077f == aVar.b()) {
                return true;
            }
        }
        return false;
    }

    @Override // deobf.androidx.camera.video.internal.compat.quirk.i1.a
    public int f() {
        return this.f19076e;
    }

    @Override // deobf.androidx.camera.video.internal.compat.quirk.i1.a
    public int g() {
        return this.f19075d;
    }

    public int hashCode() {
        return ((((((((this.b ^ 1000003) * 1000003) ^ this.f19074c) * 1000003) ^ this.f19075d) * 1000003) ^ this.f19076e) * 1000003) ^ this.f19077f;
    }

    public String toString() {
        return "AudioSettings{audioSource=" + this.b + ", captureSampleRate=" + this.f19074c + ", encodeSampleRate=" + this.f19075d + ", channelCount=" + this.f19076e + ", audioFormat=" + this.f19077f + "}";
    }

    public u(int i10, int i11, int i12, int i13, int i14) {
        this.b = i10;
        this.f19074c = i11;
        this.f19075d = i12;
        this.f19076e = i13;
        this.f19077f = i14;
    }
}
