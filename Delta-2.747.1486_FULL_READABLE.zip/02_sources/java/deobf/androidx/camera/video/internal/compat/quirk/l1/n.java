package deobf.androidx.camera.video.internal.compat.quirk.l1;

import android.util.Range;
import android.util.Size;
import deobf.androidx.camera.video.internal.compat.quirk.f1.c2;
import deobf.androidx.camera.view.g0.k0;
import deobf.androidx.camera.view.g0.r1;
import deobf.androidx.camera.video.internal.compat.quirk.m1.p1;
import deobf.androidx.camera.camera2.internal.compat.quirk.n0.a4;

// dex: classes.dex
public class n implements deobf.androidx.camera.view.x2.h<p1> {

    public static final Size f21854g = new Size(1280, 720);

    public final String f21855a;
    public final a4 b;

    public final c2 f21856c;

    public final Size f21857d;

    public final k0 f21858e;

    public final Range<Integer> f21859f;

    public n(String str, a4 a4Var, c2 c2Var, Size size, k0 k0Var, Range<Integer> range) {
        this.f21855a = str;
        this.b = a4Var;
        this.f21856c = c2Var;
        this.f21857d = size;
        this.f21858e = k0Var;
        this.f21859f = range;
    }

    @Override // deobf.androidx.camera.view.x2.h
    public p1 get() {
        CaptureEncodeRates c10 = m.c(this.f21856c, this.f21859f);
        deobf.androidx.camera.view.r1.a("VidEncCfgDefaultRslvr", "Resolved VIDEO frame rates: Capture frame rate = " + c10.getCaptureRate() + "fps. Encode frame rate = " + c10.getEncodeRate() + "fps.");
        Range<Integer> c11 = this.f21856c.c();
        deobf.androidx.camera.view.r1.a("VidEncCfgDefaultRslvr", "Using fallback VIDEO bitrate");
        int a10 = this.f21858e.a();
        int encodeRate = c10.getEncodeRate();
        int width = this.f21857d.getWidth();
        Size size = f21854g;
        int f10 = m.f(14000000, a10, 8, encodeRate, 30, width, size.getWidth(), this.f21857d.getHeight(), size.getHeight(), c11);
        int a11 = deobf.androidx.camera.video.internal.compat.quirk.n1.b.a(this.f21855a, this.f21858e);
        return p1.d().i(this.f21855a).h(this.b).k(this.f21857d).b(f10).c(c10.getCaptureRate()).f(c10.getEncodeRate()).j(a11).e(m.b(this.f21855a, a11)).a();
    }
}
