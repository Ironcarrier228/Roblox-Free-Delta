package deobf.androidx.camera.video.internal.compat.quirk.i1;

import deobf.androidx.camera.view.g0.r1;
import deobf.androidx.camera.video.internal.compat.quirk.i1.p;
import java.nio.ByteBuffer;
import java.util.concurrent.Executor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;

// dex: classes.dex
public class e0 implements p {

    public final AtomicBoolean f19017a = new AtomicBoolean(false);
    public final AtomicBoolean b = new AtomicBoolean(false);

    public final int f19018c;

    public final int f19019d;

    public byte[] f19020e;

    public long f19021f;

    public deobf.unlinked.p.a f19022g;

    public Executor f19023h;

    public e0(a aVar) {
        this.f19018c = aVar.d();
        this.f19019d = aVar.e();
    }

    public static void d(long j10) {
        long g10 = j10 - g();
        if (g10 > 0) {
            try {
                Thread.sleep(TimeUnit.NANOSECONDS.toMillis(g10));
            } catch (InterruptedException e10) {
                r1.m("SilentAudioStream", "Ignore interruption", e10);
            }
        }
    }

    private void e() {
        deobf.androidx.camera.view.x2.g.j(!this.b.get(), "AudioStream has been released.");
    }

    private void f() {
        deobf.androidx.camera.view.x2.g.j(this.f19017a.get(), "AudioStream has not been started.");
    }

    public static long g() {
        return System.nanoTime();
    }

    @Override // deobf.androidx.camera.video.internal.compat.quirk.i1.p
    public void a() {
        this.b.getAndSet(true);
    }

    @Override // deobf.androidx.camera.video.internal.compat.quirk.i1.p
    public void b(deobf.unlinked.p.a aVar, Executor executor) {
        boolean z10 = true;
        deobf.androidx.camera.view.x2.g.j(!this.f19017a.get(), "AudioStream can not be started when setCallback.");
        e();
        if (aVar != null && executor == null) {
            z10 = false;
        }
        deobf.androidx.camera.view.x2.g.b(z10, "executor can't be null with non-null callback.");
        this.f19022g = aVar;
        this.f19023h = executor;
    }

    public final void h() {
        final deobf.unlinked.p.a aVar = this.f19022g;
        Executor executor = this.f19023h;
        if (aVar == null || executor == null) {
            return;
        }
        executor.execute(new Runnable() { // from class: i1.d0
            @Override // java.lang.Runnable
            public final void run() {
                deobf.unlinked.p.a.this.a(true);
            }
        });
    }

    public final void i(ByteBuffer byteBuffer, int i10) {
        deobf.androidx.camera.view.x2.g.i(i10 <= byteBuffer.remaining());
        byte[] bArr = this.f19020e;
        if (bArr == null || bArr.length < i10) {
            this.f19020e = new byte[i10];
        }
        int position = byteBuffer.position();
        byteBuffer.put(this.f19020e, 0, i10).limit(i10 + position).position(position);
    }

    @Override // deobf.androidx.camera.video.internal.compat.quirk.i1.p
    public deobf.unlinked.p.c read(ByteBuffer byteBuffer) {
        e();
        f();
        long g10 = t.g(byteBuffer.remaining(), this.f19018c);
        int e10 = (int) t.e(g10, this.f19018c);
        if (e10 <= 0) {
            return deobf.unlinked.p.c.c(0, this.f19021f);
        }
        long d10 = this.f19021f + t.d(g10, this.f19019d);
        d(d10);
        i(byteBuffer, e10);
        deobf.unlinked.p.c c10 = deobf.unlinked.p.c.c(e10, this.f19021f);
        this.f19021f = d10;
        return c10;
    }

    @Override // deobf.androidx.camera.video.internal.compat.quirk.i1.p
    public void start() {
        e();
        if (this.f19017a.getAndSet(true)) {
            return;
        }
        this.f19021f = g();
        h();
    }

    @Override // deobf.androidx.camera.video.internal.compat.quirk.i1.p
    public void stop() {
        e();
        this.f19017a.set(false);
    }
}
