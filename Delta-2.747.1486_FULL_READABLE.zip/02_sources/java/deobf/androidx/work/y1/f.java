package deobf.androidx.work.y1;

// dex: classes.dex
public final class f<V> extends a<V> {
    public static <V> f<V> B() {
        return new f<>();
    }

    @Override // deobf.androidx.work.y1.a
    public boolean x(V v8) {
        return super.x(v8);
    }

    @Override // deobf.androidx.work.y1.a
    public boolean y(Throwable th2) {
        return super.y(th2);
    }
}
