package deobf.androidx.work.y1;

import androidx.annotation.NonNull;
import java.lang.ref.WeakReference;
import java.util.concurrent.Executor;
import java.util.concurrent.TimeUnit;
import deobf.androidx.camera.view.pe.x;

// dex: classes.dex
public final class c {

    public static final class a<T> {

        public Object f37183a;
        public d<T> b;

        public f<Void> f37184c = f.B();

        public boolean f37185d;

        public void a(@NonNull Runnable runnable, @NonNull Executor executor) {
            f<Void> fVar = this.f37184c;
            if (fVar != null) {
                fVar.a(runnable, executor);
            }
        }

        public void b() {
            this.f37183a = null;
            this.b = null;
            this.f37184c.x(null);
        }

        public boolean c(T t8) {
            this.f37185d = true;
            d<T> dVar = this.b;
            boolean z10 = dVar != null && dVar.d(t8);
            if (z10) {
                e();
            }
            return z10;
        }

        public boolean d() {
            this.f37185d = true;
            d<T> dVar = this.b;
            boolean z10 = dVar != null && dVar.c(true);
            if (z10) {
                e();
            }
            return z10;
        }

        public final void e() {
            this.f37183a = null;
            this.b = null;
            this.f37184c = null;
        }

        public boolean f(@NonNull Throwable th2) {
            this.f37185d = true;
            d<T> dVar = this.b;
            boolean z10 = dVar != null && dVar.e(th2);
            if (z10) {
                e();
            }
            return z10;
        }

        public void finalize() {
            f<Void> fVar;
            d<T> dVar = this.b;
            if (dVar != null && !dVar.isDone()) {
                dVar.e(new b("The completer object was garbage collected - this future would otherwise never complete. The tag was: " + this.f37183a));
            }
            if (this.f37185d || (fVar = this.f37184c) == null) {
                return;
            }
            fVar.x(null);
        }
    }

    public static final class b extends Throwable {
        public b(String str) {
            super(str);
        }

        @Override // java.lang.Throwable
        public synchronized Throwable fillInStackTrace() {
            return this;
        }
    }

    public interface InterfaceC0761c<T> {
        Object a(@NonNull a<T> aVar);
    }

    public static final class d<T> implements x<T> {

        public final WeakReference<a<T>> f37186a;
        public final deobf.androidx.work.y1.a<T> b = new a();

        public class a extends deobf.androidx.work.y1.a<T> {
            public a() {
            }

            @Override // deobf.androidx.work.y1.a
            public String u() {
                a<T> aVar = d.this.f37186a.get();
                if (aVar == null) {
                    return "Completer object has been garbage collected, future will fail soon";
                }
                return "tag=[" + aVar.f37183a + "]";
            }
        }

        public d(a<T> aVar) {
            this.f37186a = new WeakReference<>(aVar);
        }

        @Override // deobf.androidx.camera.view.pe.x
        public void a(@NonNull Runnable runnable, @NonNull Executor executor) {
            this.b.a(runnable, executor);
        }

        public boolean c(boolean z10) {
            return this.b.cancel(z10);
        }

        @Override // java.util.concurrent.Future
        public boolean cancel(boolean z10) {
            a<T> aVar = this.f37186a.get();
            boolean cancel = this.b.cancel(z10);
            if (cancel && aVar != null) {
                aVar.b();
            }
            return cancel;
        }

        public boolean d(T t8) {
            return this.b.x(t8);
        }

        public boolean e(Throwable th2) {
            return this.b.y(th2);
        }

        @Override // java.util.concurrent.Future
        public T get() {
            return this.b.get();
        }

        @Override // java.util.concurrent.Future
        public boolean isCancelled() {
            return this.b.isCancelled();
        }

        @Override // java.util.concurrent.Future
        public boolean isDone() {
            return this.b.isDone();
        }

        public String toString() {
            return this.b.toString();
        }

        @Override // java.util.concurrent.Future
        public T get(long j10, @NonNull TimeUnit timeUnit) {
            return this.b.get(j10, timeUnit);
        }
    }

    @NonNull
    public static <T> x<T> a(@NonNull InterfaceC0761c<T> interfaceC0761c) {
        a<T> aVar = new a<>();
        d<T> dVar = new d<>(aVar);
        aVar.b = dVar;
        aVar.f37183a = interfaceC0761c.getClass();
        try {
            Object a10 = interfaceC0761c.a(aVar);
            if (a10 == null) {
                return dVar;
            }
            aVar.f37183a = a10;
            return dVar;
        } catch (Exception e10) {
            dVar.e(e10);
            return dVar;
        }
    }
}
