package deobf.androidx.work.y1;

import deobf.com.withpersona.sdk2.inquiry.av.n;
import com.github.luben.zstd.BuildConfig;
import java.util.concurrent.ExecutionException;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;
import deobf.androidx.camera.view.pe.x;
import deobf.com.withpersona.sdk2.inquiry.zt.n;
import deobf.com.withpersona.sdk2.inquiry.zt.o;

@Metadata(d1 = {"\u0000 \n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0002\b\u000b\b\u0002\u0018\u0000*\u0004\b\u0000\u0010\u00012\u00020\u0002B#\u0012\f\u0010\u0004\u001a\b\u0012\u0004\u0012\u00028\u00000\u0003\u0012\f\u0010\u0006\u001a\b\u0012\u0004\u0012\u00028\u00000\u0005¢\u0006\u0004\b\u0007\u0010\bJ\u000f\u0010\n\u001a\u00020\tH\u0016¢\u0006\u0004\b\n\u0010\u000bR\u001d\u0010\u0004\u001a\b\u0012\u0004\u0012\u00028\u00000\u00038\u0006¢\u0006\f\n\u0004\b\f\u0010\r\u001a\u0004\b\u000e\u0010\u000fR\u001d\u0010\u0006\u001a\b\u0012\u0004\u0012\u00028\u00000\u00058\u0006¢\u0006\f\n\u0004\b\u0010\u0010\u0011\u001a\u0004\b\u0012\u0010\u0013¨\u0006\u0014"}, d2 = {"Ly1/g;", "T", "Ljava/lang/Runnable;", "Lpe/x;", "futureToObserve", "Lav/n;", "continuation", "<init>", "(Lpe/x;Lav/n;)V", BuildConfig.FLAVOR, "run", "()V", deobf.android.view.xe.a.f36648e, "Lpe/x;", "getFutureToObserve", "()Lpe/x;", deobf.android.view.k6.b.f21144e, "Lav/n;", "getContinuation", "()Lav/n;", "concurrent-futures-ktx"}, k = 1, mv = {1, 4, 0})
// dex: classes.dex
public final class g<T> implements Runnable {

    @NotNull
    public final x<T> futureToObserve;

    @NotNull
    public final n<T> continuation;

    /* JADX WARN: Multi-variable type inference failed */
    public g(@NotNull x<T> futureToObserve, @NotNull n<? super T> continuation) {
        Intrinsics.e(futureToObserve, "futureToObserve");
        Intrinsics.e(continuation, "continuation");
        this.futureToObserve = futureToObserve;
        this.continuation = continuation;
    }

    @Override // java.lang.Runnable
    public void run() {
        Throwable c10;
        if (this.futureToObserve.isCancelled()) {
            deobf.unlinked.n.a.a(this.continuation, null, 1, null);
            return;
        }
        try {
            n<T> nVar = this.continuation;
            n.Companion companion = deobf.com.withpersona.sdk2.inquiry.zt.n.INSTANCE;
            nVar.resumeWith(deobf.com.withpersona.sdk2.inquiry.zt.n.b(a.r(this.futureToObserve)));
        } catch (ExecutionException e10) {
            deobf.com.withpersona.sdk2.inquiry.av.n<T> nVar2 = this.continuation;
            c10 = e.c(e10);
            n.Companion companion2 = deobf.com.withpersona.sdk2.inquiry.zt.n.INSTANCE;
            nVar2.resumeWith(deobf.com.withpersona.sdk2.inquiry.zt.n.b(deobf.com.google.android.material.o.a(c10)));
        }
    }
}
