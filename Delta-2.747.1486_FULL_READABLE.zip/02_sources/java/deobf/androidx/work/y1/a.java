package deobf.androidx.work.y1;

import androidx.annotation.NonNull;
import java.util.Locale;
import java.util.concurrent.CancellationException;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Executor;
import java.util.concurrent.Future;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
import java.util.concurrent.locks.LockSupport;
import java.util.logging.Level;
import java.util.logging.Logger;
import deobf.androidx.camera.view.pe.x;

// dex: classes.dex
public abstract class a<V> implements x<V> {

    public static final boolean f37163d = Boolean.parseBoolean(System.getProperty("guava.concurrent.generate_cancellation_cause", "false"));

    public static final Logger f37164e = Logger.getLogger(a.class.getName());

    public static final b f37165f;

    public static final Object f37166g;

    public volatile Object f37167a;
    public volatile e b;

    public volatile i f37168c;

    public static abstract class b {
        public b() {
        }

        public abstract boolean a(a<?> aVar, e eVar, e eVar2);

        public abstract boolean b(a<?> aVar, Object obj, Object obj2);

        public abstract boolean c(a<?> aVar, i iVar, i iVar2);

        public abstract void d(i iVar, i iVar2);

        public abstract void e(i iVar, Thread thread);
    }

    public static final class c {

        public static final c f37169c;

        public static final c f37170d;

        public final boolean f37171a;
        public final Throwable b;

        static {
            if (a.f37163d) {
                f37170d = null;
                f37169c = null;
            } else {
                f37170d = new c(false, null);
                f37169c = new c(true, null);
            }
        }

        public c(boolean z10, Throwable th2) {
            this.f37171a = z10;
            this.b = th2;
        }
    }

    public static final class d {
        public static final d b = new d(new C0760a("Failure occurred while trying to finish a future."));

        public final Throwable f37172a;

        public class C0760a extends Throwable {
            public C0760a(String str) {
                super(str);
            }

            @Override // java.lang.Throwable
            public synchronized Throwable fillInStackTrace() {
                return this;
            }
        }

        public d(Throwable th2) {
            this.f37172a = (Throwable) a.h(th2);
        }
    }

    public static final class e {

        public static final e f37173d = new e(null, null);

        public final Runnable f37174a;
        public final Executor b;

        public e f37175c;

        public e(Runnable runnable, Executor executor) {
            this.f37174a = runnable;
            this.b = executor;
        }
    }

    public static final class f extends b {

        public final AtomicReferenceFieldUpdater<i, Thread> f37176a;
        public final AtomicReferenceFieldUpdater<i, i> b;

        public final AtomicReferenceFieldUpdater<a, i> f37177c;

        public final AtomicReferenceFieldUpdater<a, e> f37178d;

        public final AtomicReferenceFieldUpdater<a, Object> f37179e;

        public f(AtomicReferenceFieldUpdater<i, Thread> atomicReferenceFieldUpdater, AtomicReferenceFieldUpdater<i, i> atomicReferenceFieldUpdater2, AtomicReferenceFieldUpdater<a, i> atomicReferenceFieldUpdater3, AtomicReferenceFieldUpdater<a, e> atomicReferenceFieldUpdater4, AtomicReferenceFieldUpdater<a, Object> atomicReferenceFieldUpdater5) {
            super();
            this.f37176a = atomicReferenceFieldUpdater;
            this.b = atomicReferenceFieldUpdater2;
            this.f37177c = atomicReferenceFieldUpdater3;
            this.f37178d = atomicReferenceFieldUpdater4;
            this.f37179e = atomicReferenceFieldUpdater5;
        }

        @Override // deobf.androidx.work.y1.a.b
        public boolean a(a<?> aVar, e eVar, e eVar2) {
            return deobf.androidx.work.y1.b.a(this.f37178d, aVar, eVar, eVar2);
        }

        @Override // deobf.androidx.work.y1.a.b
        public boolean b(a<?> aVar, Object obj, Object obj2) {
            return deobf.androidx.work.y1.b.a(this.f37179e, aVar, obj, obj2);
        }

        @Override // deobf.androidx.work.y1.a.b
        public boolean c(a<?> aVar, i iVar, i iVar2) {
            return deobf.androidx.work.y1.b.a(this.f37177c, aVar, iVar, iVar2);
        }

        @Override // deobf.androidx.work.y1.a.b
        public void d(i iVar, i iVar2) {
            this.b.lazySet(iVar, iVar2);
        }

        @Override // deobf.androidx.work.y1.a.b
        public void e(i iVar, Thread thread) {
            this.f37176a.lazySet(iVar, thread);
        }
    }

    public static final class g<V> implements Runnable {

        public final a<V> f37180a;
        public final x<? extends V> b;
    }

    public static final class h extends b {
        public h() {
            super();
        }

        @Override // deobf.androidx.work.y1.a.b
        public boolean a(a<?> aVar, e eVar, e eVar2) {
            synchronized (aVar) {
                try {
                    if (aVar.b != eVar) {
                        return false;
                    }
                    aVar.b = eVar2;
                    return true;
                } catch (Throwable th2) {
                    throw th2;
                }
            }
        }

        @Override // deobf.androidx.work.y1.a.b
        public boolean b(a<?> aVar, Object obj, Object obj2) {
            synchronized (aVar) {
                try {
                    if (aVar.f37167a != obj) {
                        return false;
                    }
                    aVar.f37167a = obj2;
                    return true;
                } catch (Throwable th2) {
                    throw th2;
                }
            }
        }

        @Override // deobf.androidx.work.y1.a.b
        public boolean c(a<?> aVar, i iVar, i iVar2) {
            synchronized (aVar) {
                try {
                    if (aVar.f37168c != iVar) {
                        return false;
                    }
                    aVar.f37168c = iVar2;
                    return true;
                } catch (Throwable th2) {
                    throw th2;
                }
            }
        }

        @Override // deobf.androidx.work.y1.a.b
        public void d(i iVar, i iVar2) {
            iVar.b = iVar2;
        }

        @Override // deobf.androidx.work.y1.a.b
        public void e(i iVar, Thread thread) {
            iVar.f37182a = thread;
        }
    }

    public static final class i {

        public static final i f37181c = new i(false);

        public volatile Thread f37182a;
        public volatile i b;

        public i(boolean z10) {
        }

        public void a(i iVar) {
            a.f37165f.d(this, iVar);
        }

        public void b() {
            Thread thread = this.f37182a;
            if (thread != null) {
                this.f37182a = null;
                LockSupport.unpark(thread);
            }
        }

        public i() {
            a.f37165f.e(this, Thread.currentThread());
        }
    }

    static {
        b hVar;
        try {
            hVar = new f(AtomicReferenceFieldUpdater.newUpdater(i.class, Thread.class, deobf.android.view.xe.a.f36648e), AtomicReferenceFieldUpdater.newUpdater(i.class, i.class, deobf.android.view.k6.b.f21144e), AtomicReferenceFieldUpdater.newUpdater(a.class, i.class, "c"), AtomicReferenceFieldUpdater.newUpdater(a.class, e.class, deobf.android.view.k6.b.f21144e), AtomicReferenceFieldUpdater.newUpdater(a.class, Object.class, deobf.android.view.xe.a.f36648e));
            th = null;
        } catch (Throwable th2) {
            th = th2;
            hVar = new h();
        }
        f37165f = hVar;
        if (th != null) {
            f37164e.log(Level.SEVERE, "SafeAtomicHelper is broken!", th);
        }
        f37166g = new Object();
    }

    private void c(StringBuilder sb2) {
        try {
            Object r10 = r(this);
            sb2.append("SUCCESS, result=[");
            sb2.append(z(r10));
            sb2.append("]");
        } catch (CancellationException unused) {
            sb2.append("CANCELLED");
        } catch (RuntimeException e10) {
            sb2.append("UNKNOWN, cause=[");
            sb2.append(e10.getClass());
            sb2.append(" thrown from get()]");
        } catch (ExecutionException e11) {
            sb2.append("FAILURE, cause=[");
            sb2.append(e11.getCause());
            sb2.append("]");
        }
    }

    private static CancellationException e(String str, Throwable th2) {
        CancellationException cancellationException = new CancellationException(str);
        cancellationException.initCause(th2);
        return cancellationException;
    }

    @NonNull
    public static <T> T h(T t8) {
        t8.getClass();
        return t8;
    }

    public static void m(a<?> aVar) {
        e eVar = null;
        while (true) {
            aVar.v();
            aVar.d();
            e k10 = aVar.k(eVar);
            while (k10 != null) {
                eVar = k10.f37175c;
                Runnable runnable = k10.f37174a;
                if (runnable instanceof g) {
                    g gVar = (g) runnable;
                    aVar = gVar.f37180a;
                    if (aVar.f37167a == gVar) {
                        if (f37165f.b(aVar, gVar, q(gVar.b))) {
                            break;
                        }
                    } else {
                        continue;
                    }
                } else {
                    o(runnable, k10.b);
                }
                k10 = eVar;
            }
            return;
        }
    }

    private static void o(Runnable runnable, Executor executor) {
        try {
            executor.execute(runnable);
        } catch (RuntimeException e10) {
            f37164e.log(Level.SEVERE, "RuntimeException while executing runnable " + runnable + " with executor " + executor, (Throwable) e10);
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    private V p(Object obj) {
        if (obj instanceof c) {
            throw e("Task was cancelled.", ((c) obj).b);
        }
        if (obj instanceof d) {
            throw new ExecutionException(((d) obj).f37172a);
        }
        if (obj == f37166g) {
            return null;
        }
        return obj;
    }

    public static Object q(x<?> xVar) {
        if (xVar instanceof a) {
            Object obj = ((a) xVar).f37167a;
            if (!(obj instanceof c)) {
                return obj;
            }
            c cVar = (c) obj;
            return cVar.f37171a ? cVar.b != null ? new c(false, cVar.b) : c.f37170d : obj;
        }
        boolean isCancelled = xVar.isCancelled();
        if ((!f37163d) && isCancelled) {
            return c.f37170d;
        }
        try {
            Object r10 = r(xVar);
            return r10 == null ? f37166g : r10;
        } catch (CancellationException e10) {
            if (isCancelled) {
                return new c(false, e10);
            }
            return new d(new IllegalArgumentException("get() threw CancellationException, despite reporting isCancelled() == false: " + xVar, e10));
        } catch (ExecutionException e11) {
            return new d(e11.getCause());
        } catch (Throwable th2) {
            return new d(th2);
        }
    }

    public static <V> V r(Future<V> future) {
        V v8;
        boolean z10 = false;
        while (true) {
            try {
                v8 = future.get();
                break;
            } catch (InterruptedException unused) {
                z10 = true;
            } catch (Throwable th2) {
                if (z10) {
                    Thread.currentThread().interrupt();
                }
                throw th2;
            }
        }
        if (z10) {
            Thread.currentThread().interrupt();
        }
        return v8;
    }

    private void v() {
        i iVar;
        do {
            iVar = this.f37168c;
        } while (!f37165f.c(this, iVar, i.f37181c));
        while (iVar != null) {
            iVar.b();
            iVar = iVar.b;
        }
    }

    public final boolean A() {
        Object obj = this.f37167a;
        return (obj instanceof c) && ((c) obj).f37171a;
    }

    @Override // deobf.androidx.camera.view.pe.x
    public final void a(Runnable runnable, Executor executor) {
        h(runnable);
        h(executor);
        e eVar = this.b;
        if (eVar != e.f37173d) {
            e eVar2 = new e(runnable, executor);
            do {
                eVar2.f37175c = eVar;
                if (f37165f.a(this, eVar, eVar2)) {
                    return;
                } else {
                    eVar = this.b;
                }
            } while (eVar != e.f37173d);
        }
        o(runnable, executor);
    }

    /* JADX WARN: Code restructure failed: missing block: B:35:0x0058, code lost:

        return true;
     */
    @Override // java.util.concurrent.Future
    public final boolean cancel(boolean r8) {
        /*
            r7 = this;
            java.lang.Object r0 = r7.f37167a
            r1 = 1
            r2 = 0
            if (r0 != 0) goto L8
            r3 = r1
            goto L9
        L8:
            r3 = r2
        L9:
            boolean r4 = r0 instanceof deobf.androidx.work.y1.a.g
            r3 = r3 | r4
            if (r3 == 0) goto L60
            boolean r3 = deobf.androidx.work.y1.a.f37163d
            if (r3 == 0) goto L1f
            y1.a$c r3 = new y1.a$c
            java.util.concurrent.CancellationException r4 = new java.util.concurrent.CancellationException
            java.lang.String r5 = "Future.cancel() was called."
            r4.<init>(r5)
            r3.<init>(r8, r4)
            goto L26
        L1f:
            if (r8 == 0) goto L24
            y1.a$c r3 = deobf.androidx.work.y1.a.c.f37169c
            goto L26
        L24:
            y1.a$c r3 = deobf.androidx.work.y1.a.c.f37170d
        L26:
            r4 = r7
            r5 = r2
        L28:
            y1.a$b r6 = deobf.androidx.work.y1.a.f37165f
            boolean r6 = deobf.unlinked.r6.b(r4, r0, r3)
            if (r6 == 0) goto L59
            if (r8 == 0) goto L35
            r4.s()
        L35:
            m(r4)
            boolean r4 = r0 instanceof deobf.androidx.work.y1.a.g
            if (r4 == 0) goto L58
            y1.a$g r0 = (deobf.androidx.work.y1.a.g) r0
            deobf.androidx.camera.view.pe.x<? extends V> r0 = deobf.androidx.camera.view.r0.b
            boolean r4 = r0 instanceof deobf.androidx.work.y1.a
            if (r4 == 0) goto L55
            r4 = r0
            deobf.androidx.work.y1.a r4 = (deobf.androidx.work.y1.a) r4
            java.lang.Object r0 = r4.f37167a
            if (r0 != 0) goto L4d
            r5 = r1
            goto L4e
        L4d:
            r5 = r2
        L4e:
            boolean r6 = r0 instanceof deobf.androidx.work.y1.a.g
            r5 = r5 | r6
            if (r5 == 0) goto L58
            r5 = r1
            goto L28
        L55:
            r0.cancel(r8)
        L58:
            return r1
        L59:
            java.lang.Object r0 = r4.f37167a
            boolean r6 = r0 instanceof deobf.androidx.work.y1.a.g
            if (r6 != 0) goto L28
            return r5
        L60:
            return r2
        */
        throw new UnsupportedOperationException("Method not decompiled: deobf.androidx.work.y1.a.cancel(boolean):boolean");
    }

    public void d() {
    }

    @Override // java.util.concurrent.Future
    public final V get(long j10, TimeUnit timeUnit) {
        long nanos = timeUnit.toNanos(j10);
        if (Thread.interrupted()) {
            throw new InterruptedException();
        }
        Object obj = this.f37167a;
        if ((obj != null) && (!(obj instanceof g))) {
            return p(obj);
        }
        long nanoTime = nanos > 0 ? System.nanoTime() + nanos : 0L;
        if (nanos >= 1000) {
            i iVar = this.f37168c;
            if (iVar != i.f37181c) {
                i iVar2 = new i();
                do {
                    iVar2.a(iVar);
                    if (f37165f.c(this, iVar, iVar2)) {
                        do {
                            LockSupport.parkNanos(this, nanos);
                            if (Thread.interrupted()) {
                                w(iVar2);
                                throw new InterruptedException();
                            }
                            Object obj2 = this.f37167a;
                            if ((obj2 != null) && (!(obj2 instanceof g))) {
                                return p(obj2);
                            }
                            nanos = nanoTime - System.nanoTime();
                        } while (nanos >= 1000);
                        w(iVar2);
                    } else {
                        iVar = this.f37168c;
                    }
                } while (iVar != i.f37181c);
            }
            return p(this.f37167a);
        }
        while (nanos > 0) {
            Object obj3 = this.f37167a;
            if ((obj3 != null) && (!(obj3 instanceof g))) {
                return p(obj3);
            }
            if (Thread.interrupted()) {
                throw new InterruptedException();
            }
            nanos = nanoTime - System.nanoTime();
        }
        String aVar = toString();
        String obj4 = timeUnit.toString();
        Locale locale = Locale.ROOT;
        String lowerCase = obj4.toLowerCase(locale);
        String str = "Waited " + j10 + " " + timeUnit.toString().toLowerCase(locale);
        if (nanos + 1000 < 0) {
            String str2 = str + " (plus ";
            long j11 = -nanos;
            long convert = timeUnit.convert(j11, TimeUnit.NANOSECONDS);
            long nanos2 = j11 - timeUnit.toNanos(convert);
            boolean z10 = convert == 0 || nanos2 > 1000;
            if (convert > 0) {
                String str3 = str2 + convert + " " + lowerCase;
                if (z10) {
                    str3 = str3 + ",";
                }
                str2 = str3 + " ";
            }
            if (z10) {
                str2 = str2 + nanos2 + " nanoseconds ";
            }
            str = str2 + "delay)";
        }
        if (isDone()) {
            throw new TimeoutException(str + " but future completed as timeout expired");
        }
        throw new TimeoutException(str + " for " + aVar);
    }

    @Override // java.util.concurrent.Future
    public final boolean isCancelled() {
        return this.f37167a instanceof c;
    }

    @Override // java.util.concurrent.Future
    public final boolean isDone() {
        return (!(r0 instanceof g)) & (this.f37167a != null);
    }

    public final e k(e eVar) {
        e eVar2;
        do {
            eVar2 = this.b;
        } while (!f37165f.a(this, eVar2, e.f37173d));
        e eVar3 = eVar;
        e eVar4 = eVar2;
        while (eVar4 != null) {
            e eVar5 = eVar4.f37175c;
            eVar4.f37175c = eVar3;
            eVar3 = eVar4;
            eVar4 = eVar5;
        }
        return eVar3;
    }

    public void s() {
    }

    public String toString() {
        String str;
        StringBuilder sb2 = new StringBuilder();
        sb2.append(super.toString());
        sb2.append("[status=");
        if (isCancelled()) {
            sb2.append("CANCELLED");
        } else if (isDone()) {
            c(sb2);
        } else {
            try {
                str = u();
            } catch (RuntimeException e10) {
                str = "Exception thrown from implementation: " + e10.getClass();
            }
            if (str != null && !str.isEmpty()) {
                sb2.append("PENDING, info=[");
                sb2.append(str);
                sb2.append("]");
            } else if (isDone()) {
                c(sb2);
            } else {
                sb2.append("PENDING");
            }
        }
        sb2.append("]");
        return sb2.toString();
    }

    /* JADX WARN: Multi-variable type inference failed */
    public String u() {
        Object obj = this.f37167a;
        if (obj instanceof g) {
            return "setFuture=[" + z(((g) obj).b) + "]";
        }
        if (!(this instanceof ScheduledFuture)) {
            return null;
        }
        return "remaining delay=[" + ((ScheduledFuture) this).getDelay(TimeUnit.MILLISECONDS) + " ms]";
    }

    public final void w(i iVar) {
        iVar.f37182a = null;
        while (true) {
            i iVar2 = this.f37168c;
            if (iVar2 == i.f37181c) {
                return;
            }
            i iVar3 = null;
            while (iVar2 != null) {
                i iVar4 = iVar2.b;
                if (iVar2.f37182a != null) {
                    iVar3 = iVar2;
                } else if (iVar3 != null) {
                    iVar3.b = iVar4;
                    if (iVar3.f37182a == null) {
                        break;
                    }
                } else if (!f37165f.c(this, iVar2, iVar4)) {
                    break;
                }
                iVar2 = iVar4;
            }
            return;
        }
    }

    public boolean x(V v8) {
        if (v8 == null) {
            v8 = (V) f37166g;
        }
        if (!f37165f.b(this, null, v8)) {
            return false;
        }
        m(this);
        return true;
    }

    public boolean y(Throwable th2) {
        if (!f37165f.b(this, null, new d((Throwable) h(th2)))) {
            return false;
        }
        m(this);
        return true;
    }

    public final String z(Object obj) {
        return obj == this ? "this future" : String.valueOf(obj);
    }

    @Override // java.util.concurrent.Future
    public final V get() {
        Object obj;
        if (!Thread.interrupted()) {
            Object obj2 = this.f37167a;
            if ((obj2 != null) & (!(obj2 instanceof g))) {
                return p(obj2);
            }
            i iVar = this.f37168c;
            if (iVar != i.f37181c) {
                i iVar2 = new i();
                do {
                    iVar2.a(iVar);
                    if (f37165f.c(this, iVar, iVar2)) {
                        do {
                            LockSupport.park(this);
                            if (!Thread.interrupted()) {
                                obj = this.f37167a;
                            } else {
                                w(iVar2);
                                throw new InterruptedException();
                            }
                        } while (!((obj != null) & (!(obj instanceof g))));
                        return p(obj);
                    }
                    iVar = this.f37168c;
                } while (iVar != i.f37181c);
            }
            return p(this.f37167a);
        }
        throw new InterruptedException();
    }
}
