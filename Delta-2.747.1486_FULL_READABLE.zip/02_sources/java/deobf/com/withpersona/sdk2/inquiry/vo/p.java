package deobf.com.withpersona.sdk2.inquiry.vo;

import android.content.Context;
import deobf.com.withpersona.sdk2.inquiry.vo.IdConfig;

// dex: classes3.dex
public final class p {

    public final deobf.com.withpersona.sdk2.inquiry.wt.i<Context> f34941a;
    public final deobf.com.withpersona.sdk2.inquiry.wt.i<deobf.com.withpersona.sdk2.inquiry.sn.h0> b;

    public final deobf.com.withpersona.sdk2.inquiry.wt.i<deobf.com.withpersona.sdk2.inquiry.er.c> f34942c;

    public p(deobf.com.withpersona.sdk2.inquiry.wt.i<Context> iVar, deobf.com.withpersona.sdk2.inquiry.wt.i<deobf.com.withpersona.sdk2.inquiry.sn.h0> iVar2, deobf.com.withpersona.sdk2.inquiry.wt.i<deobf.com.withpersona.sdk2.inquiry.er.c> iVar3) {
        this.f34941a = iVar;
        this.b = iVar2;
        this.f34942c = iVar3;
    }

    public static p a(deobf.com.withpersona.sdk2.inquiry.wt.i<Context> iVar, deobf.com.withpersona.sdk2.inquiry.wt.i<deobf.com.withpersona.sdk2.inquiry.sn.h0> iVar2, deobf.com.withpersona.sdk2.inquiry.wt.i<deobf.com.withpersona.sdk2.inquiry.er.c> iVar3) {
        return new p(iVar, iVar2, iVar3);
    }

    public static GovernmentIdAnalyzeWorker c(Context context, deobf.com.withpersona.sdk2.inquiry.sn.h0 h0Var, deobf.com.withpersona.sdk2.inquiry.er.c cVar, IdConfig.e eVar, String str) {
        return new GovernmentIdAnalyzeWorker(context, h0Var, cVar, eVar, str);
    }

    public GovernmentIdAnalyzeWorker b(IdConfig.e eVar, String str) {
        return c(this.f34941a.get(), this.b.get(), this.f34942c.get(), eVar, str);
    }
}
