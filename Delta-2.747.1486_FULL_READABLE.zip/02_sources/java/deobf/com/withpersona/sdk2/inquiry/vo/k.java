package deobf.com.withpersona.sdk2.inquiry.vo;

import android.content.Context;

// dex: classes3.dex
public final class k implements deobf.com.withpersona.sdk2.inquiry.wt.d<j> {

    public final deobf.com.withpersona.sdk2.inquiry.wt.i<deobf.com.roblox.protocols.mediapicker.g.d<String[]>> f34807a;
    public final deobf.com.withpersona.sdk2.inquiry.wt.i<Context> b;

    public final deobf.com.withpersona.sdk2.inquiry.wt.i<deobf.com.withpersona.sdk2.inquiry.er.c> f34808c;

    public k(deobf.com.withpersona.sdk2.inquiry.wt.i<deobf.com.roblox.protocols.mediapicker.g.d<String[]>> iVar, deobf.com.withpersona.sdk2.inquiry.wt.i<Context> iVar2, deobf.com.withpersona.sdk2.inquiry.wt.i<deobf.com.withpersona.sdk2.inquiry.er.c> iVar3) {
        this.f34807a = iVar;
        this.b = iVar2;
        this.f34808c = iVar3;
    }

    public static k a(deobf.com.withpersona.sdk2.inquiry.wt.i<deobf.com.roblox.protocols.mediapicker.g.d<String[]>> iVar, deobf.com.withpersona.sdk2.inquiry.wt.i<Context> iVar2, deobf.com.withpersona.sdk2.inquiry.wt.i<deobf.com.withpersona.sdk2.inquiry.er.c> iVar3) {
        return new k(iVar, iVar2, iVar3);
    }

    public static j c(deobf.com.roblox.protocols.mediapicker.g.d<String[]> dVar, Context context, deobf.com.withpersona.sdk2.inquiry.er.c cVar) {
        return new j(dVar, context, cVar);
    }

    @Override // deobf.unlinked.yt.a
    public j get() {
        return c(this.f34807a.get(), this.b.get(), this.f34808c.get());
    }
}
