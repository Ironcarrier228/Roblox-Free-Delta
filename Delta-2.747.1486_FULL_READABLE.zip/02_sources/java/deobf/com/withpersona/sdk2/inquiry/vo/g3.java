package deobf.com.withpersona.sdk2.inquiry.vo;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.drawable.GradientDrawable;
import com.github.luben.zstd.BuildConfig;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;
import deobf.com.withpersona.sdk2.inquiry.vo.IdConfig;
import deobf.com.withpersona.sdk2.inquiry.vo.y3;

@Metadata(d1 = {"\u0000&\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\b\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\u001a!\u0010\u0006\u001a\u00020\u0005*\u00020\u00002\u0006\u0010\u0002\u001a\u00020\u00012\u0006\u0010\u0004\u001a\u00020\u0003¢\u0006\u0004\b\u0006\u0010\u0007\u001a\u001b\u0010\u000b\u001a\u00020\n*\u00020\u00002\b\b\u0001\u0010\t\u001a\u00020\b¢\u0006\u0004\b\u000b\u0010\f¨\u0006\r"}, d2 = {"Landroid/content/Context;", "Lvo/y3$f;", "overlay", "Lvo/d3$e;", "captureSide", "Lvo/j3;", deobf.android.view.k6.b.f21144e, "(Landroid/content/Context;Lvo/y3$f;Lvo/d3$e;)Lvo/j3;", BuildConfig.FLAVOR, "attr", "Landroid/graphics/drawable/GradientDrawable;", deobf.android.view.xe.a.f36648e, "(Landroid/content/Context;I)Landroid/graphics/drawable/GradientDrawable;", "government-id_release"}, k = 2, mv = {2, 2, 0}, xi = 48)
// dex: classes3.dex
public final class g3 {
    @NotNull
    public static final GradientDrawable a(@NotNull Context context, int i10) {
        Intrinsics.checkNotNullParameter(context, "<this>");
        float dimension = context.getResources().getDimension(deobf.com.withpersona.sdk2.inquiry.jq.c.f20848c);
        int dimensionPixelSize = context.getResources().getDimensionPixelSize(deobf.com.withpersona.sdk2.inquiry.jq.c.f20849d);
        int c10 = deobf.com.google.android.gms.l2.b.c(context, deobf.com.withpersona.sdk2.inquiry.jq.b.f20846e);
        Integer f10 = deobf.com.withpersona.sdk2.inquiry.xq.z.f(context, i10, null, false, 6, null);
        if (f10 != null) {
            int intValue = f10.intValue();
            int[] Pi2IdFrame = deobf.com.withpersona.sdk2.inquiry.jq.i.f20897a;
            Intrinsics.checkNotNullExpressionValue(Pi2IdFrame, "Pi2IdFrame");
            TypedArray obtainStyledAttributes = context.obtainStyledAttributes(intValue, Pi2IdFrame);
            dimension = obtainStyledAttributes.getDimension(deobf.com.withpersona.sdk2.inquiry.jq.i.b, dimension);
            dimensionPixelSize = obtainStyledAttributes.getDimensionPixelSize(deobf.com.withpersona.sdk2.inquiry.jq.i.f20899d, dimensionPixelSize);
            c10 = obtainStyledAttributes.getColor(deobf.com.withpersona.sdk2.inquiry.jq.i.f20898c, c10);
            obtainStyledAttributes.recycle();
        }
        GradientDrawable gradientDrawable = new GradientDrawable();
        gradientDrawable.setCornerRadius(dimension);
        gradientDrawable.setStroke(dimensionPixelSize, c10);
        return gradientDrawable;
    }

    @NotNull
    public static final OverlayAssets b(@NotNull Context context, @NotNull deobf.com.google.firebase.y3.f overlay, @NotNull IdConfig.e captureSide) {
        int i10;
        int i11;
        int i12;
        Intrinsics.checkNotNullParameter(context, "<this>");
        Intrinsics.checkNotNullParameter(overlay, "overlay");
        Intrinsics.checkNotNullParameter(captureSide, "captureSide");
        deobf.com.google.firebase.y3.f.e eVar = deobf.com.google.firebase.y3.f.e.f35120a;
        if (Intrinsics.c(overlay, eVar)) {
            i10 = p3.f34948c;
        } else if (Intrinsics.c(overlay, deobf.com.google.firebase.y3.f.a.f35116a)) {
            i10 = p3.f34947a;
        } else {
            if (!Intrinsics.c(overlay, deobf.com.google.firebase.y3.f.b.f35117a) && !(overlay instanceof deobf.com.google.firebase.y3.f.c) && !Intrinsics.c(overlay, deobf.com.google.firebase.y3.f.d.f35119a) && !Intrinsics.c(overlay, deobf.com.google.firebase.y3.f.C0721f.f35121a)) {
                throw new deobf.com.withpersona.sdk2.inquiry.zt.l();
            }
            i10 = captureSide == IdConfig.e.f34632e ? p3.f34947a : deobf.unlinked.p3.b;
        }
        if (Intrinsics.c(overlay, eVar)) {
            i11 = m3.f34833j;
        } else if (Intrinsics.c(overlay, deobf.com.google.firebase.y3.f.a.f35116a)) {
            i11 = m3.f34825a;
        } else if (Intrinsics.c(overlay, deobf.com.google.firebase.y3.f.C0721f.f35121a)) {
            i11 = m3.b;
        } else if (Intrinsics.c(overlay, deobf.com.google.firebase.y3.f.b.f35117a)) {
            i11 = m3.f34829f;
        } else {
            if (!(overlay instanceof deobf.com.google.firebase.y3.f.c) && !Intrinsics.c(overlay, deobf.com.google.firebase.y3.f.d.f35119a)) {
                throw new deobf.com.withpersona.sdk2.inquiry.zt.l();
            }
            i11 = m3.f34830g;
        }
        if (Intrinsics.c(overlay, eVar)) {
            i12 = deobf.com.withpersona.sdk2.inquiry.jq.a.f20832j;
        } else if (Intrinsics.c(overlay, deobf.com.google.firebase.y3.f.a.f35116a)) {
            i12 = deobf.com.withpersona.sdk2.inquiry.jq.a.f20828f;
        } else {
            if (!Intrinsics.c(overlay, deobf.com.google.firebase.y3.f.b.f35117a) && !(overlay instanceof deobf.com.google.firebase.y3.f.c) && !Intrinsics.c(overlay, deobf.com.google.firebase.y3.f.d.f35119a) && !Intrinsics.c(overlay, deobf.com.google.firebase.y3.f.C0721f.f35121a)) {
                throw new deobf.com.withpersona.sdk2.inquiry.zt.l();
            }
            i12 = deobf.com.withpersona.sdk2.inquiry.jq.a.f20831i;
        }
        Integer f10 = deobf.com.withpersona.sdk2.inquiry.xq.z.f(context, i12, null, false, 6, null);
        if (f10 != null) {
            int intValue = f10.intValue();
            int[] Pi2IdFrameGuideAssets = deobf.com.withpersona.sdk2.inquiry.jq.i.f20900e;
            Intrinsics.checkNotNullExpressionValue(Pi2IdFrameGuideAssets, "Pi2IdFrameGuideAssets");
            TypedArray obtainStyledAttributes = context.obtainStyledAttributes(intValue, Pi2IdFrameGuideAssets);
            i10 = obtainStyledAttributes.getResourceId(deobf.com.withpersona.sdk2.inquiry.jq.i.f20901f, i10);
            i11 = obtainStyledAttributes.getResourceId(deobf.com.withpersona.sdk2.inquiry.jq.i.f20902g, i11);
            obtainStyledAttributes.recycle();
        }
        return new OverlayAssets(i10, i11);
    }
}
