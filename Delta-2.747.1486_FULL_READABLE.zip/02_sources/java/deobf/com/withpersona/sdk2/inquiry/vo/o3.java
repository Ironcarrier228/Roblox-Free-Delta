package deobf.com.withpersona.sdk2.inquiry.vo;

// dex: classes3.dex
public final class o3 {

    public static int f34928a = -2029584376;
    public static int b = -2029584369;

    public static int f34929c = -2029584368;

    public static int f34930d = -2029584367;

    public static int f34931e = -2029584366;

    public static int f34932f = -2029584365;

    public static int f34933g = -2029584364;

    public static int f34934h = -2029584363;

    public static int f34935i = -2029584362;

    public static int f34936j = -2029584361;

    public static int f34937k = -2029584360;

    public static int f34938l = -2029584359;

    public static int f34939m = -2029584358;

    public static int f34940n = -2029584357;
}
