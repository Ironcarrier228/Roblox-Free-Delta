package deobf.com.withpersona.sdk2.inquiry.un;

import android.content.Context;
import com.withpersona.sdk2.camera.camera2.Camera2PreviewView;
import com.withpersona.sdk2.inquiry.tracking.TrackingEventsLogger;
import org.jetbrains.annotations.Nullable;

// dex: classes3.dex
public final class c0 {

    public final deobf.com.withpersona.sdk2.inquiry.wt.i<Context> f33600a;
    public final deobf.com.withpersona.sdk2.inquiry.wt.i<deobf.unlinked.yn.a> b;

    public final deobf.com.withpersona.sdk2.inquiry.wt.i<deobf.com.withpersona.sdk2.inquiry.er.c> f33601c;

    public final deobf.com.withpersona.sdk2.inquiry.wt.i<i0> f33602d;

    public final deobf.com.withpersona.sdk2.inquiry.wt.i<deobf.unlinked.zq.a> f33603e;

    public final deobf.com.withpersona.sdk2.inquiry.wt.i<TrackingEventsLogger> f33604f;

    public final deobf.com.withpersona.sdk2.inquiry.wt.i<deobf.com.withpersona.sdk2.inquiry.dr.c> f33605g;

    public final deobf.com.withpersona.sdk2.inquiry.wt.i<deobf.com.withpersona.sdk2.inquiry.to.e> f33606h;

    public c0(deobf.com.withpersona.sdk2.inquiry.wt.i<Context> iVar, deobf.com.withpersona.sdk2.inquiry.wt.i<deobf.unlinked.yn.a> iVar2, deobf.com.withpersona.sdk2.inquiry.wt.i<deobf.com.withpersona.sdk2.inquiry.er.c> iVar3, deobf.com.withpersona.sdk2.inquiry.wt.i<i0> iVar4, deobf.com.withpersona.sdk2.inquiry.wt.i<deobf.unlinked.zq.a> iVar5, deobf.com.withpersona.sdk2.inquiry.wt.i<TrackingEventsLogger> iVar6, deobf.com.withpersona.sdk2.inquiry.wt.i<deobf.com.withpersona.sdk2.inquiry.dr.c> iVar7, deobf.com.withpersona.sdk2.inquiry.wt.i<deobf.com.withpersona.sdk2.inquiry.to.e> iVar8) {
        this.f33600a = iVar;
        this.b = iVar2;
        this.f33601c = iVar3;
        this.f33602d = iVar4;
        this.f33603e = iVar5;
        this.f33604f = iVar6;
        this.f33605g = iVar7;
        this.f33606h = iVar8;
    }

    public static c0 a(deobf.com.withpersona.sdk2.inquiry.wt.i<Context> iVar, deobf.com.withpersona.sdk2.inquiry.wt.i<deobf.unlinked.yn.a> iVar2, deobf.com.withpersona.sdk2.inquiry.wt.i<deobf.com.withpersona.sdk2.inquiry.er.c> iVar3, deobf.com.withpersona.sdk2.inquiry.wt.i<i0> iVar4, deobf.com.withpersona.sdk2.inquiry.wt.i<deobf.unlinked.zq.a> iVar5, deobf.com.withpersona.sdk2.inquiry.wt.i<TrackingEventsLogger> iVar6, deobf.com.withpersona.sdk2.inquiry.wt.i<deobf.com.withpersona.sdk2.inquiry.dr.c> iVar7, deobf.com.withpersona.sdk2.inquiry.wt.i<deobf.com.withpersona.sdk2.inquiry.to.e> iVar8) {
        return new c0(iVar, iVar2, iVar3, iVar4, iVar5, iVar6, iVar7, iVar8);
    }

    public static b0 c(Context context, deobf.unlinked.yn.a aVar, deobf.com.withpersona.sdk2.inquiry.er.c cVar, i0 i0Var, deobf.unlinked.zq.a aVar2, TrackingEventsLogger trackingEventsLogger, deobf.com.withpersona.sdk2.inquiry.dr.c cVar2, deobf.com.withpersona.sdk2.inquiry.to.e eVar, CameraChoices cameraChoices, Camera2PreviewView camera2PreviewView, g gVar, deobf.unlinked.zn.a aVar3, @Nullable deobf.unlinked.ks.a aVar4, boolean z10) {
        return new b0(context, aVar, cVar, i0Var, aVar2, trackingEventsLogger, cVar2, eVar, cameraChoices, camera2PreviewView, gVar, aVar3, aVar4, z10);
    }

    public b0 b(CameraChoices cameraChoices, Camera2PreviewView camera2PreviewView, g gVar, deobf.unlinked.zn.a aVar, @Nullable deobf.unlinked.ks.a aVar2, boolean z10) {
        return c(this.f33600a.get(), this.b.get(), this.f33601c.get(), this.f33602d.get(), this.f33603e.get(), this.f33604f.get(), this.f33605g.get(), this.f33606h.get(), cameraChoices, camera2PreviewView, gVar, aVar, aVar2, z10);
    }
}
