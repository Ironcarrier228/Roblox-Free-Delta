package deobf.com.withpersona.sdk2.inquiry.jn;

import deobf.com.withpersona.sdk2.inquiry.hn.h;
import deobf.com.withpersona.sdk2.inquiry.hn.j;
import deobf.com.withpersona.sdk2.inquiry.hn.m;
import deobf.com.withpersona.sdk2.inquiry.hn.t;

// dex: classes2.dex
public final class a<T> extends h<T> {

    public final h<T> f20811a;

    public a(h<T> hVar) {
        this.f20811a = hVar;
    }

    @Override // deobf.com.withpersona.sdk2.inquiry.hn.h
    public T fromJson(m mVar) {
        if (mVar.w() != m.c.NULL) {
            return this.f20811a.fromJson(mVar);
        }
        throw new j("Unexpected null at " + mVar.x());
    }

    @Override // deobf.com.withpersona.sdk2.inquiry.hn.h
    public void toJson(t tVar, T t8) {
        if (t8 != null) {
            this.f20811a.toJson(tVar, (t) t8);
            return;
        }
        throw new j("Unexpected null at " + tVar.x());
    }

    public String toString() {
        return this.f20811a + ".nonNull()";
    }
}
