package deobf.com.withpersona.sdk2.inquiry.vo;

import android.content.Context;
import android.os.Parcelable;
import com.github.luben.zstd.BuildConfig;
import com.google.mlkit.vision.barcode.common.Barcode;
import com.withpersona.sdk2.inquiry.network.core.InternalErrorInfo;
import com.withpersona.sdk2.inquiry.tracking.model.GovIdCaptureSide;
import deobf.com.withpersona.sdk2.inquiry.dp.GovernmentIdRequestArguments;
import deobf.com.withpersona.sdk2.inquiry.fq.n1;
import java.util.ArrayList;
import java.util.List;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import deobf.com.withpersona.sdk2.inquiry.ln.k;
import deobf.com.withpersona.sdk2.inquiry.ln.r;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import deobf.com.withpersona.sdk2.inquiry.vo.IdConfig;
import deobf.com.withpersona.sdk2.inquiry.vo.d2;
import deobf.com.withpersona.sdk2.inquiry.vo.f;
import deobf.com.withpersona.sdk2.inquiry.vo.i3;
import deobf.com.withpersona.sdk2.inquiry.vo.j0;
import deobf.com.withpersona.sdk2.inquiry.vo.n;
import deobf.com.withpersona.sdk2.inquiry.vo.y3;
import deobf.com.withpersona.sdk2.inquiry.zo.BottomSheetCaptureTipsViewModel;
import deobf.com.withpersona.sdk2.inquiry.zo.StaticCaptureTipsViewModel;

@Metadata(d1 = {"\u0000Ê\u0001\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\u0010\u0003\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0007\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\t\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\t\u001a=\u0010\n\u001a\u00020\t*\"0\u0000R\u001a\u0012\u0004\u0012\u00020\u0003\u0012\u0004\u0012\u00020\u0004\u0012\u0004\u0012\u00020\u0005\u0012\u0004\u0012\u00020\u00060\u0002j\u0002`\u00012\b\u0010\b\u001a\u0004\u0018\u00010\u0007H\u0000¢\u0006\u0004\b\n\u0010\u000b\u001a3\u0010\f\u001a\u00020\t*\"0\u0000R\u001a\u0012\u0004\u0012\u00020\u0003\u0012\u0004\u0012\u00020\u0004\u0012\u0004\u0012\u00020\u0005\u0012\u0004\u0012\u00020\u00060\u0002j\u0002`\u0001H\u0000¢\u0006\u0004\b\f\u0010\r\u001ag\u0010\u0017\u001a\u000e\u0012\u0004\u0012\u00020\u0006\u0012\u0004\u0012\u00020\u00060\u0016*\u00020\u00062\u0006\u0010\u000f\u001a\u00020\u000e2&\u0010\u0010\u001a\"0\u0000R\u001a\u0012\u0004\u0012\u00020\u0003\u0012\u0004\u0012\u00020\u0004\u0012\u0004\u0012\u00020\u0005\u0012\u0004\u0012\u00020\u00060\u0002j\u0002`\u00012\u0006\u0010\u0011\u001a\u00020\u00032\u0006\u0010\u0013\u001a\u00020\u00122\u0006\u0010\u0015\u001a\u00020\u0014H\u0000¢\u0006\u0004\b\u0017\u0010\u0018\u001ae\u0010\u0019\u001a\u000e\u0012\u0004\u0012\u00020\u0006\u0012\u0004\u0012\u00020\u00060\u0016*\u00020\u00062\u0006\u0010\u000f\u001a\u00020\u000e2&\u0010\u0010\u001a\"0\u0000R\u001a\u0012\u0004\u0012\u00020\u0003\u0012\u0004\u0012\u00020\u0004\u0012\u0004\u0012\u00020\u0005\u0012\u0004\u0012\u00020\u00060\u0002j\u0002`\u00012\u0006\u0010\u0011\u001a\u00020\u00032\u0006\u0010\u0013\u001a\u00020\u00122\u0006\u0010\u0015\u001a\u00020\u0014¢\u0006\u0004\b\u0019\u0010\u0018\u001aM\u0010\u001e\u001a\u0012\u0012\u0004\u0012\u00020\u001c\u0012\u0004\u0012\u00020\t0\u001bj\u0002`\u001d*\"0\u0000R\u001a\u0012\u0004\u0012\u00020\u0003\u0012\u0004\u0012\u00020\u0004\u0012\u0004\u0012\u00020\u0005\u0012\u0004\u0012\u00020\u00060\u0002j\u0002`\u00012\b\b\u0002\u0010\u001a\u001a\u00020\u0012H\u0000¢\u0006\u0004\b\u001e\u0010\u001f\u001a1\u0010#\u001a\u0004\u0018\u00010\u0004*\u00140 R\u0010\u0012\u0002\b\u0003\u0012\u0004\u0012\u00020\u0004\u0012\u0002\b\u00030!2\b\b\u0002\u0010\"\u001a\u00020\u0012H\u0000¢\u0006\u0004\b#\u0010$\u001a\u001f\u0010(\u001a\u00020'2\u0006\u0010\u0011\u001a\u00020\u00032\u0006\u0010&\u001a\u00020%H\u0000¢\u0006\u0004\b(\u0010)\u001a¥\u0001\u00109\u001a\u00020\t2\u0006\u0010*\u001a\u00020\u00042&\u0010\u0010\u001a\"0\u0000R\u001a\u0012\u0004\u0012\u00020\u0003\u0012\u0004\u0012\u00020\u0004\u0012\u0004\u0012\u00020\u0005\u0012\u0004\u0012\u00020\u00060\u0002j\u0002`\u00012\u0006\u0010\u0011\u001a\u00020\u00032\b\u0010,\u001a\u0004\u0018\u00010+2\u0006\u0010.\u001a\u00020-2\u0006\u0010\b\u001a\u00020\u00072\u0006\u00100\u001a\u00020/2\b\b\u0002\u0010\"\u001a\u00020\u00122\u000e\b\u0002\u00103\u001a\b\u0012\u0004\u0012\u000202012\b\b\u0002\u00105\u001a\u0002042\n\b\u0002\u00107\u001a\u0004\u0018\u0001062\n\b\u0002\u00108\u001a\u0004\u0018\u000106H\u0000¢\u0006\u0004\b9\u0010:\u001aO\u0010<\u001a\u00020\t2\u0006\u0010\u000f\u001a\u00020\u000e2&\u0010\u0010\u001a\"0\u0000R\u001a\u0012\u0004\u0012\u00020\u0003\u0012\u0004\u0012\u00020\u0004\u0012\u0004\u0012\u00020\u0005\u0012\u0004\u0012\u00020\u00060\u0002j\u0002`\u00012\u0006\u0010\u0011\u001a\u00020\u00032\u0006\u0010;\u001a\u00020\u0012H\u0000¢\u0006\u0004\b<\u0010=\u001a\u0013\u0010?\u001a\u00020>*\u00020%H\u0000¢\u0006\u0004\b?\u0010@\u001a\u0013\u0010B\u001a\u00020A*\u00020%H\u0000¢\u0006\u0004\bB\u0010C\u001a5\u0010H\u001a\u000206*\u00020D2\u0006\u0010E\u001a\u00020%2\u0006\u0010F\u001a\u0002062\b\u00108\u001a\u0004\u0018\u0001062\u0006\u0010G\u001a\u00020\u0012H\u0000¢\u0006\u0004\bH\u0010I\u001a-\u0010J\u001a\u000206*\u00020D2\u0006\u0010E\u001a\u00020%2\u0006\u0010F\u001a\u0002062\b\u00108\u001a\u0004\u0018\u000106H\u0000¢\u0006\u0004\bJ\u0010K\u001a-\u0010L\u001a\u000206*\u00020D2\u0006\u0010E\u001a\u00020%2\u0006\u0010F\u001a\u0002062\b\u00108\u001a\u0004\u0018\u000106H\u0000¢\u0006\u0004\bL\u0010K\u001a-\u0010M\u001a\u000206*\u00020D2\u0006\u0010E\u001a\u00020%2\u0006\u0010F\u001a\u0002062\b\u00108\u001a\u0004\u0018\u000106H\u0000¢\u0006\u0004\bM\u0010K\u001a\u001f\u0010P\u001a\u0004\u0018\u000106*\u00020D2\b\u0010O\u001a\u0004\u0018\u00010NH\u0000¢\u0006\u0004\bP\u0010Q\u001a\u001d\u0010S\u001a\u0004\u0018\u00010R*\u00020\u00032\u0006\u0010E\u001a\u00020%H\u0000¢\u0006\u0004\bS\u0010T\u001a\u0019\u0010V\u001a\b\u0012\u0004\u0012\u00020U01*\u00020\u0003H\u0000¢\u0006\u0004\bV\u0010W\u001aG\u0010Y\u001a\u00020\t2&\u0010\u000f\u001a\"0\u0000R\u001a\u0012\u0004\u0012\u00020\u0003\u0012\u0004\u0012\u00020\u0004\u0012\u0004\u0012\u00020\u0005\u0012\u0004\u0012\u00020\u00060\u0002j\u0002`\u00012\u0006\u0010X\u001a\u00020\u00052\u0006\u0010\b\u001a\u00020\u0007H\u0000¢\u0006\u0004\bY\u0010Z\"\u001a\u0010]\u001a\u0004\u0018\u00010%*\u0002028@X\u0080\u0004¢\u0006\u0006\u001a\u0004\b[\u0010\\¨\u0006^"}, d2 = {"Lln/k$a;", "Lcom/withpersona/sdk2/inquiry/governmentid/RenderContext;", "Lln/k;", "Lvo/d2$a;", "Lvo/j0;", "Lvo/d2$b;", BuildConfig.FLAVOR, "Lip/l;", "videoCaptureHelper", BuildConfig.FLAVOR, "S", "(Lln/k$a;Lip/l;)V", "v", "(Lln/k$a;)V", "Landroid/content/Context;", "context", "renderContext", "renderProps", BuildConfig.FLAVOR, "checkPermissions", "Lfq/n1;", "permissionRequestWorkflow", "Lcq/c;", "j0", "(Ljava/lang/Object;Landroid/content/Context;Lln/k$a;Lvo/d2$a;ZLfq/n1;)Lcq/c;", "f0", "inRecoverableState", "Lkotlin/Function1;", BuildConfig.FLAVOR, "Lcom/withpersona/sdk2/inquiry/governmentid/CameraErrorHandler;", "z", "(Lln/k$a;Z)Lkotlin/jvm/functions/Function1;", "Lln/r$c;", "Lln/r;", "addCurrentState", "x", "(Lln/r$c;Z)Lvo/j0;", "Lvo/d3$e;", "currentSide", "Lvo/y3$b$a;", "O", "(Lvo/d2$a;Lvo/d3$e;)Lvo/y3$b$a;", "renderState", "Lvo/n;", "acceptedId", "Lvo/d3;", "id", "Lsn/v;", "cameraProperties", BuildConfig.FLAVOR, "Lvo/i3;", "parts", BuildConfig.FLAVOR, "currentPartIndex", BuildConfig.FLAVOR, "webRtcObjectId", "countryCode", "W", "(Lvo/j0;Lln/k$a;Lvo/d2$a;Lvo/n;Lvo/d3;Lip/l;Lsn/v;ZLjava/util/List;ILjava/lang/String;Ljava/lang/String;)V", "useVideoCapture", "U", "(Landroid/content/Context;Lln/k$a;Lvo/d2$a;Z)V", "Lvo/n$d;", "e0", "(Lvo/d3$e;)Lvo/n$d;", "Lcom/withpersona/sdk2/inquiry/tracking/model/GovIdCaptureSide;", "d0", "(Lvo/d3$e;)Lcom/withpersona/sdk2/inquiry/tracking/model/GovIdCaptureSide;", "Lvo/d2$a$b;", "side", "selectedId", "isAutoClassification", "P", "(Lvo/d2$a$b;Lvo/d3$e;Ljava/lang/String;Ljava/lang/String;Z)Ljava/lang/String;", "K", "(Lvo/d2$a$b;Lvo/d3$e;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;", "J", "M", "Lcp/d;", "hint", "R", "(Lvo/d2$a$b;Lcp/d;)Ljava/lang/String;", "Lzo/i;", "L", "(Lvo/d2$a;Lvo/d3$e;)Lzo/i;", "Lvo/l;", "N", "(Lvo/d2$a;)Ljava/util/List;", "output", "b0", "(Lln/k$a;Lvo/d2$b;Lip/l;)V", "Q", "(Lvo/i3;)Lvo/d3$e;", "sideOrNull", "government-id_release"}, k = 2, mv = {2, 2, 0}, xi = 48)
// dex: classes3.dex
public final class b3 {

    @Metadata(k = 3, mv = {2, 2, 0}, xi = 48)
    public static final /* synthetic */ class a {

        public static final /* synthetic */ int[] f34487a;
        public static final /* synthetic */ int[] b;

        static {
            int[] iArr = new int[deobf.com.withpersona.sdk2.inquiry.fq.s1.values().length];
            try {
                iArr[deobf.com.withpersona.sdk2.inquiry.fq.s1.f16516a.ordinal()] = 1;
            } catch (NoSuchFieldError unused) {
            }
            try {
                iArr[deobf.com.withpersona.sdk2.inquiry.fq.s1.f16517c.ordinal()] = 2;
            } catch (NoSuchFieldError unused2) {
            }
            try {
                iArr[deobf.com.withpersona.sdk2.inquiry.fq.s1.b.ordinal()] = 3;
            } catch (NoSuchFieldError unused3) {
            }
            f34487a = iArr;
            int[] iArr2 = new int[IdConfig.e.values().length];
            try {
                iArr2[IdConfig.e.f34631d.ordinal()] = 1;
            } catch (NoSuchFieldError unused4) {
            }
            try {
                iArr2[IdConfig.e.f34632e.ordinal()] = 2;
            } catch (NoSuchFieldError unused5) {
            }
            try {
                iArr2[IdConfig.e.f34633f.ordinal()] = 3;
            } catch (NoSuchFieldError unused6) {
            }
            try {
                iArr2[IdConfig.e.f34634g.ordinal()] = 4;
            } catch (NoSuchFieldError unused7) {
            }
            try {
                iArr2[IdConfig.e.f34635h.ordinal()] = 5;
            } catch (NoSuchFieldError unused8) {
            }
            b = iArr2;
        }
    }

    public static /* synthetic */ Function1 A(deobf.unlinked.k.a aVar, boolean z10, int i10, Object obj) {
        if ((i10 & 1) != 0) {
            z10 = true;
        }
        return z(aVar, z10);
    }

    public static final Unit B(deobf.unlinked.k.a aVar, final boolean z10, final Throwable cameraError) {
        deobf.com.withpersona.sdk2.inquiry.ln.r c10;
        deobf.com.withpersona.sdk2.inquiry.ln.r c11;
        deobf.com.withpersona.sdk2.inquiry.ln.r c12;
        deobf.com.withpersona.sdk2.inquiry.ln.r c13;
        deobf.com.withpersona.sdk2.inquiry.ln.r c14;
        deobf.com.withpersona.sdk2.inquiry.ln.r c15;
        deobf.com.withpersona.sdk2.inquiry.ln.r c16;
        Intrinsics.checkNotNullParameter(cameraError, "cameraError");
        if (!(cameraError instanceof deobf.com.withpersona.sdk2.inquiry.sn.k)) {
            deobf.com.withpersona.sdk2.inquiry.ln.h d10 = aVar.d();
            c16 = ln.b0.c(null, new Function1() { // from class: vo.i2
                @Override // kotlin.jvm.functions.Function1
                public final Object invoke(Object obj) {
                    Unit H;
                    H = b3.H(cameraError, (deobf.android.view.r.c) obj);
                    return H;
                }
            }, 1, null);
            d10.a(c16);
            return Unit.f21504a;
        }
        deobf.com.withpersona.sdk2.inquiry.sn.k kVar = (deobf.com.withpersona.sdk2.inquiry.sn.k) cameraError;
        if (!(kVar instanceof deobf.com.withpersona.sdk2.inquiry.sn.t0)) {
            if (kVar instanceof deobf.com.withpersona.sdk2.inquiry.sn.v0) {
                deobf.com.withpersona.sdk2.inquiry.ln.h d11 = aVar.d();
                c15 = ln.b0.c(null, new Function1() { // from class: vo.j2
                    @Override // kotlin.jvm.functions.Function1
                    public final Object invoke(Object obj) {
                        Unit I;
                        I = b3.I((deobf.android.view.r.c) obj);
                        return I;
                    }
                }, 1, null);
                d11.a(c15);
            } else if (kVar instanceof deobf.com.withpersona.sdk2.inquiry.sn.p0) {
                deobf.com.withpersona.sdk2.inquiry.ln.h d12 = aVar.d();
                c14 = ln.b0.c(null, new Function1() { // from class: vo.k2
                    @Override // kotlin.jvm.functions.Function1
                    public final Object invoke(Object obj) {
                        Unit C;
                        C = b3.C((deobf.android.view.r.c) obj);
                        return C;
                    }
                }, 1, null);
                d12.a(c14);
            } else if (kVar instanceof deobf.com.withpersona.sdk2.inquiry.sn.a1) {
                deobf.com.withpersona.sdk2.inquiry.ln.h d13 = aVar.d();
                c13 = ln.b0.c(null, new Function1() { // from class: vo.l2
                    @Override // kotlin.jvm.functions.Function1
                    public final Object invoke(Object obj) {
                        Unit D;
                        D = b3.D(z10, (deobf.android.view.r.c) obj);
                        return D;
                    }
                }, 1, null);
                d13.a(c13);
            } else if (kVar instanceof deobf.com.withpersona.sdk2.inquiry.sn.f0) {
                deobf.com.withpersona.sdk2.inquiry.ln.h d14 = aVar.d();
                c12 = ln.b0.c(null, new Function1() { // from class: vo.m2
                    @Override // kotlin.jvm.functions.Function1
                    public final Object invoke(Object obj) {
                        Unit E;
                        E = b3.E((deobf.android.view.r.c) obj);
                        return E;
                    }
                }, 1, null);
                d14.a(c12);
            } else if (kVar instanceof deobf.com.withpersona.sdk2.inquiry.sn.j1) {
                deobf.com.withpersona.sdk2.inquiry.ln.h d15 = aVar.d();
                c11 = ln.b0.c(null, new Function1() { // from class: vo.n2
                    @Override // kotlin.jvm.functions.Function1
                    public final Object invoke(Object obj) {
                        Unit F;
                        F = b3.F((deobf.android.view.r.c) obj);
                        return F;
                    }
                }, 1, null);
                d15.a(c11);
            } else {
                if (!(kVar instanceof deobf.com.withpersona.sdk2.inquiry.sn.z0)) {
                    throw new deobf.com.withpersona.sdk2.inquiry.zt.l();
                }
                deobf.com.withpersona.sdk2.inquiry.ln.h d16 = aVar.d();
                c10 = ln.b0.c(null, new Function1() { // from class: vo.o2
                    @Override // kotlin.jvm.functions.Function1
                    public final Object invoke(Object obj) {
                        Unit G;
                        G = b3.G(z10, cameraError, (deobf.android.view.r.c) obj);
                        return G;
                    }
                }, 1, null);
                d16.a(c10);
            }
        }
        return Unit.f21504a;
    }

    public static final Unit C(deobf.android.view.r.c action) {
        Intrinsics.checkNotNullParameter(action, "$this$action");
        action.d(new deobf.androidx.constraintlayout.widget.d2.b.c(new InternalErrorInfo.CameraErrorInfo("Audio recording permission is required but was not granted.")));
        return Unit.f21504a;
    }

    public static final Unit D(boolean z10, deobf.android.view.r.c action) {
        Intrinsics.checkNotNullParameter(action, "$this$action");
        if (z10) {
            ((j0) action.c()).v();
            action.e(new j0.RestartStep(null, null, null, null, 0, ((j0) action.c()).getCountryCode(), null, null, 223, null));
        } else {
            action.d(new deobf.androidx.constraintlayout.widget.d2.b.c(new InternalErrorInfo.CameraErrorInfo("Recording too long.")));
        }
        return Unit.f21504a;
    }

    public static final Unit E(deobf.android.view.r.c action) {
        Intrinsics.checkNotNullParameter(action, "$this$action");
        action.d(new deobf.androidx.constraintlayout.widget.d2.b.c(new InternalErrorInfo.CameraErrorInfo("Unable to save video capture to device.")));
        return Unit.f21504a;
    }

    public static final Unit F(deobf.android.view.r.c action) {
        Intrinsics.checkNotNullParameter(action, "$this$action");
        action.d(new deobf.androidx.constraintlayout.widget.d2.b.c(new InternalErrorInfo.CameraErrorInfo("Unsupported device.")));
        return Unit.f21504a;
    }

    public static final Unit G(boolean z10, Throwable th2, deobf.android.view.r.c action) {
        Intrinsics.checkNotNullParameter(action, "$this$action");
        if (z10) {
            ((j0) action.c()).v();
            if (!((deobf.com.withpersona.sdk2.inquiry.sn.z0) th2).getIsClosedDueToBadCameraConfiguration()) {
                action.e(new j0.RestartStep(null, null, null, null, 0, ((j0) action.c()).getCountryCode(), null, null, 223, null));
            }
        } else {
            action.d(new deobf.androidx.constraintlayout.widget.d2.b.c(new InternalErrorInfo.CameraErrorInfo("Recording interrupted.")));
        }
        return Unit.f21504a;
    }

    public static final Unit H(Throwable th2, deobf.android.view.r.c action) {
        Intrinsics.checkNotNullParameter(action, "$this$action");
        action.d(new deobf.androidx.constraintlayout.widget.d2.b.c(new InternalErrorInfo.CameraErrorInfo("Unexpected camera error with type " + th2.getClass().getCanonicalName())));
        return Unit.f21504a;
    }

    public static final Unit I(deobf.android.view.r.c action) {
        Intrinsics.checkNotNullParameter(action, "$this$action");
        action.d(new deobf.androidx.constraintlayout.widget.d2.b.c(new InternalErrorInfo.CameraErrorInfo("Unable to find a camera that satisfies the requirements for the selfie flow.")));
        return Unit.f21504a;
    }

    @NotNull
    public static final String J(@NotNull deobf.androidx.constraintlayout.widget.d2.a.Strings strings, @NotNull IdConfig.e side, @NotNull String selectedId, @Nullable String str) {
        Intrinsics.checkNotNullParameter(strings, "<this>");
        Intrinsics.checkNotNullParameter(side, "side");
        Intrinsics.checkNotNullParameter(selectedId, "selectedId");
        String a10 = strings.getCaptureScreenDescription().a(str, selectedId, side);
        return a10 == null ? BuildConfig.FLAVOR : a10;
    }

    @NotNull
    public static final String K(@NotNull deobf.androidx.constraintlayout.widget.d2.a.Strings strings, @NotNull IdConfig.e side, @NotNull String selectedId, @Nullable String str) {
        Intrinsics.checkNotNullParameter(strings, "<this>");
        Intrinsics.checkNotNullParameter(side, "side");
        Intrinsics.checkNotNullParameter(selectedId, "selectedId");
        String a10 = strings.getCaptureScreenTitle().a(str, selectedId, side);
        return a10 == null ? BuildConfig.FLAVOR : a10;
    }

    @Nullable
    public static final deobf.com.withpersona.sdk2.inquiry.zo.i L(@NotNull deobf.androidx.constraintlayout.widget.d2.a aVar, @NotNull IdConfig.e side) {
        String idFrontHelpModalTitle;
        String idFrontHelpModalPrompt;
        String idFrontHelpModalHints;
        String idFrontHelpModalContinueButtonText;
        String idBackHelpModalTitle;
        String idBackHelpModalPrompt;
        String idBackHelpModalHints;
        String idBackHelpModalContinueButtonText;
        String barcodeHelpModalTitle;
        String barcodeHelpModalPrompt;
        String barcodeHelpModalHints;
        String barcodeHelpModalContinueButtonText;
        Intrinsics.checkNotNullParameter(aVar, "<this>");
        Intrinsics.checkNotNullParameter(side, "side");
        if (aVar.getStaticCaptureTipsEnabled()) {
            return new StaticCaptureTipsViewModel(aVar.getStrings().getStaticCaptureTipsTitle(), aVar.getStrings().getStaticCaptureTipsSubtext(), aVar.getAssetConfig().getCapturePage());
        }
        int i10 = deobf.unlinked.a.b[side.ordinal()];
        if (i10 == 1) {
            String helpButtonText = aVar.getStrings().getHelpButtonText();
            if (helpButtonText == null || (idFrontHelpModalTitle = aVar.getStrings().getIdFrontHelpModalTitle()) == null || (idFrontHelpModalPrompt = aVar.getStrings().getIdFrontHelpModalPrompt()) == null || (idFrontHelpModalHints = aVar.getStrings().getIdFrontHelpModalHints()) == null || (idFrontHelpModalContinueButtonText = aVar.getStrings().getIdFrontHelpModalContinueButtonText()) == null) {
                return null;
            }
            return new BottomSheetCaptureTipsViewModel(helpButtonText, idFrontHelpModalTitle, idFrontHelpModalPrompt, idFrontHelpModalHints, idFrontHelpModalContinueButtonText, side);
        }
        if (i10 == 2) {
            String helpButtonText2 = aVar.getStrings().getHelpButtonText();
            if (helpButtonText2 == null || (idBackHelpModalTitle = aVar.getStrings().getIdBackHelpModalTitle()) == null || (idBackHelpModalPrompt = aVar.getStrings().getIdBackHelpModalPrompt()) == null || (idBackHelpModalHints = aVar.getStrings().getIdBackHelpModalHints()) == null || (idBackHelpModalContinueButtonText = aVar.getStrings().getIdBackHelpModalContinueButtonText()) == null) {
                return null;
            }
            return new BottomSheetCaptureTipsViewModel(helpButtonText2, idBackHelpModalTitle, idBackHelpModalPrompt, idBackHelpModalHints, idBackHelpModalContinueButtonText, side);
        }
        if (i10 == 3) {
            return null;
        }
        if (i10 != 4) {
            if (i10 == 5) {
                return null;
            }
            throw new deobf.com.withpersona.sdk2.inquiry.zt.l();
        }
        String helpButtonText3 = aVar.getStrings().getHelpButtonText();
        if (helpButtonText3 == null || (barcodeHelpModalTitle = aVar.getStrings().getBarcodeHelpModalTitle()) == null || (barcodeHelpModalPrompt = aVar.getStrings().getBarcodeHelpModalPrompt()) == null || (barcodeHelpModalHints = aVar.getStrings().getBarcodeHelpModalHints()) == null || (barcodeHelpModalContinueButtonText = aVar.getStrings().getBarcodeHelpModalContinueButtonText()) == null) {
            return null;
        }
        return new BottomSheetCaptureTipsViewModel(helpButtonText3, barcodeHelpModalTitle, barcodeHelpModalPrompt, barcodeHelpModalHints, barcodeHelpModalContinueButtonText, side);
    }

    @NotNull
    public static final String M(@NotNull deobf.androidx.constraintlayout.widget.d2.a.Strings strings, @NotNull IdConfig.e side, @NotNull String selectedId, @Nullable String str) {
        Intrinsics.checkNotNullParameter(strings, "<this>");
        Intrinsics.checkNotNullParameter(side, "side");
        Intrinsics.checkNotNullParameter(selectedId, "selectedId");
        String a10 = strings.getConfirmCapture().a(str, selectedId, side);
        return a10 == null ? BuildConfig.FLAVOR : a10;
    }

    @NotNull
    public static final List<EnabledIdClass> N(@NotNull deobf.androidx.constraintlayout.widget.d2.a aVar) {
        Intrinsics.checkNotNullParameter(aVar, "<this>");
        List<IdConfig> o10 = aVar.o();
        ArrayList arrayList = new ArrayList(kotlin.collections.q.u(o10, 10));
        for (IdConfig idConfig : o10) {
            h3 icon = idConfig.getIcon();
            String str = aVar.getStrings().V().get(idConfig.getIdClassKey());
            if (str == null) {
                str = idConfig.getIdClassKey();
            }
            arrayList.add(new EnabledIdClass(icon, idConfig, str));
        }
        return arrayList;
    }

    @NotNull
    public static final deobf.com.google.firebase.y3.b.a O(@NotNull deobf.androidx.constraintlayout.widget.d2.a renderProps, @NotNull IdConfig.e currentSide) {
        Intrinsics.checkNotNullParameter(renderProps, "renderProps");
        Intrinsics.checkNotNullParameter(currentSide, "currentSide");
        return currentSide == IdConfig.e.f34635h ? deobf.com.google.firebase.y3.b.a.b : (Intrinsics.c(renderProps.getCountryCode(), "US") || currentSide != IdConfig.e.f34632e) ? deobf.com.google.firebase.y3.b.a.f35072c : deobf.com.google.firebase.y3.b.a.b;
    }

    @NotNull
    public static final String P(@NotNull deobf.androidx.constraintlayout.widget.d2.a.Strings strings, @NotNull IdConfig.e side, @NotNull String selectedId, @Nullable String str, boolean z10) {
        Intrinsics.checkNotNullParameter(strings, "<this>");
        Intrinsics.checkNotNullParameter(side, "side");
        Intrinsics.checkNotNullParameter(selectedId, "selectedId");
        if (z10 && strings.getAutoClassificationCaptureTipText() != null) {
            return strings.getAutoClassificationCaptureTipText();
        }
        String a10 = strings.getScanInstructions().a(str, selectedId, side);
        return a10 == null ? BuildConfig.FLAVOR : a10;
    }

    @Nullable
    public static final IdConfig.e Q(@NotNull i3 i3Var) {
        Intrinsics.checkNotNullParameter(i3Var, "<this>");
        i3.SideIdPart sideIdPart = i3Var instanceof i3.SideIdPart ? (i3.SideIdPart) i3Var : null;
        if (sideIdPart != null) {
            return sideIdPart.getSide();
        }
        return null;
    }

    @Nullable
    public static final String R(@NotNull deobf.androidx.constraintlayout.widget.d2.a.Strings strings, @Nullable deobf.com.withpersona.sdk2.inquiry.cp.d dVar) {
        Intrinsics.checkNotNullParameter(strings, "<this>");
        if (Intrinsics.c(dVar, cp.e.f11505a)) {
            return strings.getHintHoldStill();
        }
        if (Intrinsics.c(dVar, cp.f.f11506a)) {
            return strings.getHintLowLight();
        }
        if (dVar == null) {
            return null;
        }
        throw new deobf.com.withpersona.sdk2.inquiry.zt.l();
    }

    public static final void S(@NotNull deobf.com.withpersona.sdk2.inquiry.ln.k<? super deobf.androidx.constraintlayout.widget.d2.a, j0, ? extends deobf.androidx.constraintlayout.widget.d2.b, ? extends Object>.a aVar, @Nullable final deobf.unlinked.ip.l lVar) {
        deobf.com.withpersona.sdk2.inquiry.ln.r<? super Object, j0, ? extends Object> c10;
        Intrinsics.checkNotNullParameter(aVar, "<this>");
        deobf.com.withpersona.sdk2.inquiry.ln.h<deobf.com.withpersona.sdk2.inquiry.ln.r<? super Object, j0, ? extends Object>> d10 = aVar.d();
        c10 = ln.b0.c(null, new Function1() { // from class: vo.t2
            @Override // kotlin.jvm.functions.Function1
            public final Object invoke(Object obj) {
                Unit T;
                T = b3.T(deobf.unlinked.ip.l.this, (deobf.android.view.r.c) obj);
                return T;
            }
        }, 1, null);
        d10.a(c10);
    }

    public static final Unit T(deobf.unlinked.ip.l lVar, deobf.android.view.r.c action) {
        Intrinsics.checkNotNullParameter(action, "$this$action");
        j0 backState = ((j0) action.c()).getBackState();
        if (lVar != null) {
            lVar.a();
        }
        if (backState != null) {
            backState.F(true);
            action.e(backState);
        } else if (((deobf.androidx.constraintlayout.widget.d2.a) action.b()).getBackStepEnabled()) {
            action.d(deobf.androidx.constraintlayout.widget.d2.b.a.f34597a);
        } else {
            action.d(deobf.androidx.constraintlayout.widget.d2.b.C0708b.f34598a);
        }
        return Unit.f21504a;
    }

    public static final void U(@NotNull Context context, @NotNull deobf.com.withpersona.sdk2.inquiry.ln.k<? super deobf.androidx.constraintlayout.widget.d2.a, j0, ? extends deobf.androidx.constraintlayout.widget.d2.b, ? extends Object>.a renderContext, @NotNull deobf.androidx.constraintlayout.widget.d2.a renderProps, boolean z10) {
        deobf.com.withpersona.sdk2.inquiry.ln.r<? super Object, j0, ? extends Object> c10;
        Intrinsics.checkNotNullParameter(context, "context");
        Intrinsics.checkNotNullParameter(renderContext, "renderContext");
        Intrinsics.checkNotNullParameter(renderProps, "renderProps");
        List p8 = kotlin.collections.p.p(deobf.com.withpersona.sdk2.inquiry.fq.n0.f16455a);
        if (z10 && deobf.com.withpersona.sdk2.inquiry.xq.g.f(context)) {
            p8.add(deobf.com.withpersona.sdk2.inquiry.fq.n0.b);
        }
        final List<deobf.com.withpersona.sdk2.inquiry.fq.n0> a10 = deobf.com.withpersona.sdk2.inquiry.fq.y1.a(context, p8);
        if (a10.isEmpty()) {
            return;
        }
        deobf.com.withpersona.sdk2.inquiry.ln.h<deobf.com.withpersona.sdk2.inquiry.ln.r<? super Object, j0, ? extends Object>> d10 = renderContext.d();
        c10 = ln.b0.c(null, new Function1() { // from class: vo.v2
            @Override // kotlin.jvm.functions.Function1
            public final Object invoke(Object obj) {
                Unit V;
                V = b3.V(a10, (deobf.android.view.r.c) obj);
                return V;
            }
        }, 1, null);
        d10.a(c10);
    }

    public static final Unit V(List list, deobf.android.view.r.c action) {
        Intrinsics.checkNotNullParameter(action, "$this$action");
        j0 j0Var = (j0) action.c();
        if (j0Var instanceof j0.WaitForAutocapture) {
            action.e(j0.WaitForAutocapture.L((j0.WaitForAutocapture) j0Var, null, null, null, null, null, 0, null, null, null, null, list.contains(deobf.com.withpersona.sdk2.inquiry.fq.n0.f16455a), list.contains(deobf.com.withpersona.sdk2.inquiry.fq.n0.b), null, null, null, 29695, null));
        } else {
            ((j0) action.c()).v();
            action.e(new j0.RestartStep(null, null, null, null, 0, j0Var.getCountryCode(), null, null, 223, null));
        }
        return Unit.f21504a;
    }

    public static final void W(@NotNull final j0 renderState, @NotNull final deobf.com.withpersona.sdk2.inquiry.ln.k<? super deobf.androidx.constraintlayout.widget.d2.a, j0, ? extends deobf.androidx.constraintlayout.widget.d2.b, ? extends Object>.a renderContext, @NotNull final deobf.androidx.constraintlayout.widget.d2.a renderProps, @Nullable final n nVar, @NotNull final IdConfig id2, @NotNull final deobf.unlinked.ip.l videoCaptureHelper, @NotNull final deobf.com.withpersona.sdk2.inquiry.sn.v cameraProperties, final boolean z10, @NotNull final List<? extends i3> parts, final int i10, @Nullable final String str, @Nullable final String str2) {
        deobf.com.withpersona.sdk2.inquiry.ln.r<? super Object, j0, ? extends Object> c10;
        Intrinsics.checkNotNullParameter(renderState, "renderState");
        Intrinsics.checkNotNullParameter(renderContext, "renderContext");
        Intrinsics.checkNotNullParameter(renderProps, "renderProps");
        Intrinsics.checkNotNullParameter(id2, "id");
        Intrinsics.checkNotNullParameter(videoCaptureHelper, "videoCaptureHelper");
        Intrinsics.checkNotNullParameter(cameraProperties, "cameraProperties");
        Intrinsics.checkNotNullParameter(parts, "parts");
        final deobf.unlinked.zn.a e10 = videoCaptureHelper.e(renderProps);
        deobf.com.withpersona.sdk2.inquiry.ln.h<deobf.com.withpersona.sdk2.inquiry.ln.r<? super Object, j0, ? extends Object>> d10 = renderContext.d();
        c10 = ln.b0.c(null, new Function1() { // from class: vo.u2
            @Override // kotlin.jvm.functions.Function1
            public final Object invoke(Object obj) {
                Unit Y;
                Y = b3.Y(j0.this, nVar, i10, parts, renderProps, videoCaptureHelper, id2, z10, str2, e10, cameraProperties, str, renderContext, (deobf.android.view.r.c) obj);
                return Y;
            }
        }, 1, null);
        d10.a(c10);
    }

    public static final Unit Y(j0 j0Var, n nVar, int i10, List list, deobf.androidx.constraintlayout.widget.d2.a aVar, final deobf.unlinked.ip.l lVar, IdConfig idConfig, boolean z10, String str, deobf.unlinked.zn.a aVar2, deobf.com.withpersona.sdk2.inquiry.sn.v vVar, String str2, final deobf.unlinked.k.a aVar3, deobf.android.view.r.c action) {
        Parcelable submit;
        Intrinsics.checkNotNullParameter(action, "$this$action");
        if (action.c().getClass() != j0Var.getClass()) {
            return Unit.f21504a;
        }
        List<n> x02 = nVar != null ? CollectionsKt.x0(((j0) action.c()).D(), nVar) : ((j0) action.c()).D();
        int i11 = i10 == list.size() ? i10 : i10 + 1;
        i3 i3Var = (i3) CollectionsKt.f0(list, i11);
        if (i3Var instanceof i3.SideIdPart) {
            if (!aVar.u() || lVar.d()) {
                i3.SideIdPart sideIdPart = (i3.SideIdPart) i3Var;
                submit = new j0.WaitForAutocapture(sideIdPart, x02, new f.IdCaptureConfig(idConfig), O((deobf.androidx.constraintlayout.widget.d2.a) action.b(), sideIdPart.getSide()), list, i11, x(action, z10), lVar.d() ? deobf.unlinked.ip.x.b : deobf.unlinked.ip.x.f19686c, aVar.getVideoCaptureConfig().getWebRtcJwt(), null, false, false, str, null, new Function0() { // from class: vo.x2
                    @Override // kotlin.jvm.functions.Function0
                    public final Object invoke() {
                        Unit Z;
                        Z = b3.Z(deobf.unlinked.k.a.this, lVar);
                        return Z;
                    }
                }, 11776, null);
            } else {
                submit = new j0.ChooseCaptureMethod((i3.SideIdPart) i3Var, x02, list, i11, str, new f.IdCaptureConfig(idConfig), false, x(action, z10), null, 320, null);
            }
        } else {
            if (i3Var != null) {
                throw new deobf.com.withpersona.sdk2.inquiry.zt.l();
            }
            submit = (aVar2 != deobf.unlinked.zn.a.f39326a || (action.c() instanceof j0.f) || (action.c() instanceof j0.ReviewSelectedImage)) ? (aVar2 != deobf.unlinked.zn.a.b || (action.c() instanceof j0.FinalizeLocalVideoCapture) || (action.c() instanceof j0.ReviewSelectedImage)) ? new j0.Submit(idConfig, x02, null, list, i11, x(action, z10), str, new GovernmentIdRequestArguments(x02, aVar.getFieldKeyDocument(), aVar.getFieldKeyIdClass()), str2, vVar, false, 1028, null) : new j0.FinalizeLocalVideoCapture(idConfig, x02, (i3) CollectionsKt.o0(list), list, i11, x(action, z10), str, new GovernmentIdRequestArguments(x02, aVar.getFieldKeyDocument(), aVar.getFieldKeyIdClass()), 0L, false, 768, null) : new j0.f((i3) CollectionsKt.o0(list), x02, list, i11, x(action, z10), str, idConfig, vVar);
        }
        action.e(submit);
        return Unit.f21504a;
    }

    public static final Unit Z(deobf.unlinked.k.a aVar, final deobf.unlinked.ip.l lVar) {
        deobf.com.withpersona.sdk2.inquiry.ln.r c10;
        deobf.com.withpersona.sdk2.inquiry.ln.h d10 = aVar.d();
        c10 = ln.b0.c(null, new Function1() { // from class: vo.p2
            @Override // kotlin.jvm.functions.Function1
            public final Object invoke(Object obj) {
                Unit a02;
                a02 = b3.a0(deobf.unlinked.ip.l.this, (deobf.android.view.r.c) obj);
                return a02;
            }
        }, 1, null);
        d10.a(c10);
        return Unit.f21504a;
    }

    public static final Unit a0(deobf.unlinked.ip.l lVar, deobf.android.view.r.c action) {
        Intrinsics.checkNotNullParameter(action, "$this$action");
        Object c10 = action.c();
        j0.WaitForAutocapture waitForAutocapture = c10 instanceof j0.WaitForAutocapture ? (j0.WaitForAutocapture) c10 : null;
        if (waitForAutocapture != null) {
            action.e(j0.WaitForAutocapture.L(waitForAutocapture, null, null, null, null, null, 0, null, lVar.d() ? deobf.unlinked.ip.x.b : deobf.unlinked.ip.x.f19686c, null, null, false, false, null, null, null, 32639, null));
        }
        return Unit.f21504a;
    }

    public static final void b0(@NotNull deobf.com.withpersona.sdk2.inquiry.ln.k<? super deobf.androidx.constraintlayout.widget.d2.a, j0, ? extends deobf.androidx.constraintlayout.widget.d2.b, ? extends Object>.a context, @NotNull final deobf.androidx.constraintlayout.widget.d2.b output, @NotNull deobf.unlinked.ip.l videoCaptureHelper) {
        deobf.com.withpersona.sdk2.inquiry.ln.r<? super Object, j0, ? extends Object> c10;
        Intrinsics.checkNotNullParameter(context, "context");
        Intrinsics.checkNotNullParameter(output, "output");
        Intrinsics.checkNotNullParameter(videoCaptureHelper, "videoCaptureHelper");
        if ((output instanceof deobf.androidx.constraintlayout.widget.d2.b.d) || (output instanceof deobf.androidx.constraintlayout.widget.d2.b.a) || (output instanceof deobf.androidx.constraintlayout.widget.d2.b.c) || (output instanceof deobf.androidx.constraintlayout.widget.d2.b.C0708b)) {
            videoCaptureHelper.a();
        }
        deobf.com.withpersona.sdk2.inquiry.ln.h<deobf.com.withpersona.sdk2.inquiry.ln.r<? super Object, j0, ? extends Object>> d10 = context.d();
        c10 = ln.b0.c(null, new Function1() { // from class: vo.g2
            @Override // kotlin.jvm.functions.Function1
            public final Object invoke(Object obj) {
                Unit c02;
                c02 = b3.c0(deobf.androidx.constraintlayout.widget.d2.b.this, (deobf.android.view.r.c) obj);
                return c02;
            }
        }, 1, null);
        d10.a(c10);
    }

    public static final Unit c0(deobf.androidx.constraintlayout.widget.d2.b bVar, deobf.android.view.r.c action) {
        Intrinsics.checkNotNullParameter(action, "$this$action");
        action.d(bVar);
        return Unit.f21504a;
    }

    @NotNull
    public static final GovIdCaptureSide d0(@NotNull IdConfig.e eVar) {
        Intrinsics.checkNotNullParameter(eVar, "<this>");
        int i10 = deobf.unlinked.a.b[eVar.ordinal()];
        if (i10 == 1) {
            return GovIdCaptureSide.Front;
        }
        if (i10 == 2) {
            return GovIdCaptureSide.Back;
        }
        if (i10 == 3) {
            return GovIdCaptureSide.FrontOrBack;
        }
        if (i10 == 4) {
            return GovIdCaptureSide.BarcodePdf417;
        }
        if (i10 == 5) {
            return GovIdCaptureSide.PassportSignature;
        }
        throw new deobf.com.withpersona.sdk2.inquiry.zt.l();
    }

    @NotNull
    public static final n.d e0(@NotNull IdConfig.e eVar) {
        Intrinsics.checkNotNullParameter(eVar, "<this>");
        int i10 = deobf.unlinked.a.b[eVar.ordinal()];
        if (i10 == 1) {
            return n.d.f34848a;
        }
        if (i10 == 2) {
            return n.d.b;
        }
        if (i10 == 3) {
            return n.d.f34848a;
        }
        if (i10 != 4 && i10 != 5) {
            throw new deobf.com.withpersona.sdk2.inquiry.zt.l();
        }
        return n.d.b;
    }

    @NotNull
    public static final deobf.unlinked.cq.c<Object, Object> f0(@NotNull Object obj, @NotNull Context context, @NotNull final deobf.com.withpersona.sdk2.inquiry.ln.k<? super deobf.androidx.constraintlayout.widget.d2.a, j0, ? extends deobf.androidx.constraintlayout.widget.d2.b, ? extends Object>.a renderContext, @NotNull deobf.androidx.constraintlayout.widget.d2.a renderProps, boolean z10, @NotNull deobf.com.withpersona.sdk2.inquiry.fq.n1 permissionRequestWorkflow) {
        deobf.unlinked.cq.c<Object, Object> d10;
        Intrinsics.checkNotNullParameter(obj, "<this>");
        Intrinsics.checkNotNullParameter(context, "context");
        Intrinsics.checkNotNullParameter(renderContext, "renderContext");
        Intrinsics.checkNotNullParameter(renderProps, "renderProps");
        Intrinsics.checkNotNullParameter(permissionRequestWorkflow, "permissionRequestWorkflow");
        deobf.com.withpersona.sdk2.inquiry.fq.n0 n0Var = deobf.com.withpersona.sdk2.inquiry.fq.n0.b;
        String microphonePermissionsTitle = renderProps.getStrings().getMicrophonePermissionsTitle();
        if (microphonePermissionsTitle == null) {
            microphonePermissionsTitle = BuildConfig.FLAVOR;
        }
        String str = microphonePermissionsTitle;
        String microphonePermissionsPrompt = renderProps.getStrings().getMicrophonePermissionsPrompt();
        if (microphonePermissionsPrompt == null) {
            microphonePermissionsPrompt = context.getString(deobf.com.withpersona.sdk2.inquiry.jq.g.S);
            Intrinsics.checkNotNullExpressionValue(microphonePermissionsPrompt, "getString(...)");
        }
        String string = context.getString(deobf.com.withpersona.sdk2.inquiry.jq.g.R, deobf.com.withpersona.sdk2.inquiry.xq.g.b(context));
        Intrinsics.checkNotNullExpressionValue(string, "getString(...)");
        d10 = deobf.com.withpersona.sdk2.inquiry.fq.y1.d(obj, renderContext, z10, n0Var, (r36 & 8) != 0 ? false : false, str, microphonePermissionsPrompt, string, renderProps.getStrings().getMicrophonePermissionsAllowButtonText(), renderProps.getStrings().getMicrophonePermissionsCancelButtonText(), (r36 & Barcode.FORMAT_UPC_A) != 0 ? null : null, (r36 & Barcode.FORMAT_UPC_E) != 0 ? null : null, (r36 & Barcode.FORMAT_PDF417) != 0 ? null : null, permissionRequestWorkflow, renderProps.getStyles(), (r36 & 16384) != 0 ? BuildConfig.FLAVOR : "video_capture_mic_permission_request", new Function1() { // from class: vo.y2
            @Override // kotlin.jvm.functions.Function1
            public final Object invoke(Object obj2) {
                deobf.com.withpersona.sdk2.inquiry.ln.r g02;
                g02 = b3.g0(deobf.unlinked.k.a.this, (n1.Output) obj2);
                return g02;
            }
        });
        return d10;
    }

    public static final deobf.com.withpersona.sdk2.inquiry.ln.r g0(final deobf.unlinked.k.a aVar, final n1.Output it) {
        deobf.com.withpersona.sdk2.inquiry.ln.r c10;
        Intrinsics.checkNotNullParameter(it, "it");
        c10 = ln.b0.c(null, new Function1() { // from class: vo.a3
            @Override // kotlin.jvm.functions.Function1
            public final Object invoke(Object obj) {
                Unit h02;
                h02 = b3.h0(n1.Output.this, aVar, (deobf.android.view.r.c) obj);
                return h02;
            }
        }, 1, null);
        return c10;
    }

    public static final Unit h0(n1.Output output, deobf.unlinked.k.a aVar, deobf.android.view.r.c action) {
        deobf.com.withpersona.sdk2.inquiry.ln.r c10;
        Intrinsics.checkNotNullParameter(action, "$this$action");
        int i10 = a.f34487a[output.getPermissionState().getResult().ordinal()];
        if (i10 == 1 || i10 == 2) {
            deobf.com.withpersona.sdk2.inquiry.ln.h d10 = aVar.d();
            c10 = ln.b0.c(null, new Function1() { // from class: vo.q2
                @Override // kotlin.jvm.functions.Function1
                public final Object invoke(Object obj) {
                    Unit i02;
                    i02 = b3.i0((deobf.android.view.r.c) obj);
                    return i02;
                }
            }, 1, null);
            d10.a(c10);
        } else {
            if (i10 != 3) {
                throw new deobf.com.withpersona.sdk2.inquiry.zt.l();
            }
            S(aVar, null);
        }
        return Unit.f21504a;
    }

    public static final Unit i0(deobf.android.view.r.c action) {
        Intrinsics.checkNotNullParameter(action, "$this$action");
        Parcelable parcelable = (j0) action.c();
        if (parcelable instanceof b) {
            action.e(((b) parcelable).q(false));
        }
        return Unit.f21504a;
    }

    @NotNull
    public static final deobf.unlinked.cq.c<Object, Object> j0(@NotNull Object obj, @NotNull Context context, @NotNull final deobf.com.withpersona.sdk2.inquiry.ln.k<? super deobf.androidx.constraintlayout.widget.d2.a, j0, ? extends deobf.androidx.constraintlayout.widget.d2.b, ? extends Object>.a renderContext, @NotNull deobf.androidx.constraintlayout.widget.d2.a renderProps, boolean z10, @NotNull deobf.com.withpersona.sdk2.inquiry.fq.n1 permissionRequestWorkflow) {
        deobf.unlinked.cq.c<Object, Object> d10;
        Intrinsics.checkNotNullParameter(obj, "<this>");
        Intrinsics.checkNotNullParameter(context, "context");
        Intrinsics.checkNotNullParameter(renderContext, "renderContext");
        Intrinsics.checkNotNullParameter(renderProps, "renderProps");
        Intrinsics.checkNotNullParameter(permissionRequestWorkflow, "permissionRequestWorkflow");
        deobf.com.withpersona.sdk2.inquiry.fq.n0 n0Var = deobf.com.withpersona.sdk2.inquiry.fq.n0.f16455a;
        String cameraPermissionsTitle = renderProps.getStrings().getCameraPermissionsTitle();
        if (cameraPermissionsTitle == null) {
            cameraPermissionsTitle = BuildConfig.FLAVOR;
        }
        String str = cameraPermissionsTitle;
        String cameraPermissionsPrompt = renderProps.getStrings().getCameraPermissionsPrompt();
        if (cameraPermissionsPrompt == null) {
            cameraPermissionsPrompt = context.getString(deobf.com.withpersona.sdk2.inquiry.jq.g.f20885q);
            Intrinsics.checkNotNullExpressionValue(cameraPermissionsPrompt, "getString(...)");
        }
        String string = context.getString(deobf.com.withpersona.sdk2.inquiry.jq.g.f20884p, deobf.com.withpersona.sdk2.inquiry.xq.g.b(context));
        Intrinsics.checkNotNullExpressionValue(string, "getString(...)");
        d10 = deobf.com.withpersona.sdk2.inquiry.fq.y1.d(obj, renderContext, z10, n0Var, (r36 & 8) != 0 ? false : false, str, cameraPermissionsPrompt, string, renderProps.getStrings().getCameraPermissionsAllowButtonText(), renderProps.getStrings().getCameraPermissionsCancelButtonText(), (r36 & Barcode.FORMAT_UPC_A) != 0 ? null : null, (r36 & Barcode.FORMAT_UPC_E) != 0 ? null : null, (r36 & Barcode.FORMAT_PDF417) != 0 ? null : null, permissionRequestWorkflow, renderProps.getStyles(), (r36 & 16384) != 0 ? BuildConfig.FLAVOR : null, new Function1() { // from class: vo.w2
            @Override // kotlin.jvm.functions.Function1
            public final Object invoke(Object obj2) {
                deobf.com.withpersona.sdk2.inquiry.ln.r k02;
                k02 = b3.k0(deobf.unlinked.k.a.this, (n1.Output) obj2);
                return k02;
            }
        });
        return d10;
    }

    public static final deobf.com.withpersona.sdk2.inquiry.ln.r k0(final deobf.unlinked.k.a aVar, final n1.Output it) {
        deobf.com.withpersona.sdk2.inquiry.ln.r c10;
        Intrinsics.checkNotNullParameter(it, "it");
        c10 = ln.b0.c(null, new Function1() { // from class: vo.h2
            @Override // kotlin.jvm.functions.Function1
            public final Object invoke(Object obj) {
                Unit l02;
                l02 = b3.l0(n1.Output.this, aVar, (deobf.android.view.r.c) obj);
                return l02;
            }
        }, 1, null);
        return c10;
    }

    public static final Unit l0(n1.Output output, deobf.unlinked.k.a aVar, deobf.android.view.r.c action) {
        deobf.com.withpersona.sdk2.inquiry.ln.r c10;
        Intrinsics.checkNotNullParameter(action, "$this$action");
        int i10 = a.f34487a[output.getPermissionState().getResult().ordinal()];
        if (i10 == 1 || i10 == 2) {
            deobf.com.withpersona.sdk2.inquiry.ln.h d10 = aVar.d();
            c10 = ln.b0.c(null, new Function1() { // from class: vo.s2
                @Override // kotlin.jvm.functions.Function1
                public final Object invoke(Object obj) {
                    Unit m02;
                    m02 = b3.m0((deobf.android.view.r.c) obj);
                    return m02;
                }
            }, 1, null);
            d10.a(c10);
        } else {
            if (i10 != 3) {
                throw new deobf.com.withpersona.sdk2.inquiry.zt.l();
            }
            S(aVar, null);
        }
        return Unit.f21504a;
    }

    public static final Unit m0(deobf.android.view.r.c action) {
        Intrinsics.checkNotNullParameter(action, "$this$action");
        Parcelable parcelable = (j0) action.c();
        if (parcelable instanceof e) {
            action.e(((e) parcelable).r(false));
        }
        return Unit.f21504a;
    }

    public static final void v(@NotNull deobf.com.withpersona.sdk2.inquiry.ln.k<? super deobf.androidx.constraintlayout.widget.d2.a, j0, ? extends deobf.androidx.constraintlayout.widget.d2.b, ? extends Object>.a aVar) {
        deobf.com.withpersona.sdk2.inquiry.ln.r<? super Object, j0, ? extends Object> c10;
        Intrinsics.checkNotNullParameter(aVar, "<this>");
        deobf.com.withpersona.sdk2.inquiry.ln.h<deobf.com.withpersona.sdk2.inquiry.ln.r<? super Object, j0, ? extends Object>> d10 = aVar.d();
        c10 = ln.b0.c(null, new Function1() { // from class: vo.r2
            @Override // kotlin.jvm.functions.Function1
            public final Object invoke(Object obj) {
                Unit w5;
                w5 = b3.w((deobf.android.view.r.c) obj);
                return w5;
            }
        }, 1, null);
        d10.a(c10);
    }

    public static final Unit w(deobf.android.view.r.c action) {
        Intrinsics.checkNotNullParameter(action, "$this$action");
        action.d(deobf.androidx.constraintlayout.widget.d2.b.C0708b.f34598a);
        return Unit.f21504a;
    }

    @Nullable
    public static final j0 x(@NotNull deobf.com.withpersona.sdk2.inquiry.ln.r<?, j0, ?>.c cVar, boolean z10) {
        Intrinsics.checkNotNullParameter(cVar, "<this>");
        return z10 ? cVar.c() : cVar.c().getBackState();
    }

    public static /* synthetic */ j0 y(deobf.android.view.r.c cVar, boolean z10, int i10, Object obj) {
        if ((i10 & 1) != 0) {
            z10 = true;
        }
        return x(cVar, z10);
    }

    @NotNull
    public static final Function1<Throwable, Unit> z(@NotNull final deobf.com.withpersona.sdk2.inquiry.ln.k<? super deobf.androidx.constraintlayout.widget.d2.a, j0, ? extends deobf.androidx.constraintlayout.widget.d2.b, ? extends Object>.a aVar, final boolean z10) {
        Intrinsics.checkNotNullParameter(aVar, "<this>");
        return new Function1() { // from class: vo.z2
            @Override // kotlin.jvm.functions.Function1
            public final Object invoke(Object obj) {
                Unit B;
                B = b3.B(deobf.unlinked.k.a.this, z10, (Throwable) obj);
                return B;
            }
        };
    }
}
