package deobf.com.withpersona.sdk2.inquiry.un;

import com.withpersona.sdk2.camera.camera2.Camera2PreviewView;
import org.jetbrains.annotations.Nullable;
import deobf.com.withpersona.sdk2.inquiry.un.c;

// dex: classes3.dex
public final class f implements deobf.com.withpersona.sdk2.inquiry.c.a {

    public final e f33612a;

    public f(e eVar) {
        this.f33612a = eVar;
    }

    public static deobf.com.withpersona.sdk2.inquiry.wt.i<deobf.com.withpersona.sdk2.inquiry.c.a> b(e eVar) {
        return deobf.com.withpersona.sdk2.inquiry.wt.e.a(new f(eVar));
    }

    @Override // deobf.com.withpersona.sdk2.inquiry.un.c.a
    public c a(CameraChoices cameraChoices, Camera2PreviewView camera2PreviewView, g gVar, deobf.unlinked.zn.a aVar, @Nullable deobf.unlinked.ks.a aVar2, boolean z10) {
        return this.f33612a.b(cameraChoices, camera2PreviewView, gVar, aVar, aVar2, z10);
    }
}
