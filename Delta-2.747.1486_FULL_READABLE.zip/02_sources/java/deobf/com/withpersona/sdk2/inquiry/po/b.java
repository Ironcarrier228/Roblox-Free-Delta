package deobf.com.withpersona.sdk2.inquiry.po;

import deobf.com.withpersona.sdk2.inquiry.po.a;
import deobf.com.withpersona.sdk2.inquiry.wt.i;

// dex: classes3.dex
public final class b implements deobf.com.withpersona.sdk2.inquiry.wt.d<a.C0563a> {

    public final i<c> f29245a;

    public b(i<c> iVar) {
        this.f29245a = iVar;
    }

    public static b a(i<c> iVar) {
        return new b(iVar);
    }

    public static a.C0563a c(c cVar) {
        return new a.C0563a(cVar);
    }

    @Override // deobf.unlinked.yt.a
    public a.C0563a get() {
        return c(this.f29245a.get());
    }
}
