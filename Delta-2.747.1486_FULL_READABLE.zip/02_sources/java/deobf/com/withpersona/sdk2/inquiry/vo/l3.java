package deobf.com.withpersona.sdk2.inquiry.vo;

// dex: classes3.dex
public final class l3 {

    public static int f34820a = -2029846526;
}
