package deobf.com.withpersona.sdk2.inquiry.un;

import com.github.luben.zstd.BuildConfig;
import kotlin.Metadata;

@Metadata(d1 = {"\u0000\u0014\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\b\n\u0002\b\u0007\u0018\u00002\u00060\u0001j\u0002`\u0002B\u000f\u0012\u0006\u0010\u0004\u001a\u00020\u0003¢\u0006\u0004\b\u0005\u0010\u0006R\u0017\u0010\u0004\u001a\u00020\u00038\u0006¢\u0006\f\n\u0004\b\u0007\u0010\b\u001a\u0004\b\u0007\u0010\t¨\u0006\n"}, d2 = {"Lun/l0;", "Ljava/lang/Exception;", "Lkotlin/Exception;", BuildConfig.FLAVOR, "errorCode", "<init>", "(I)V", deobf.android.view.xe.a.f36648e, "I", "()I", "camera_release"}, k = 1, mv = {2, 2, 0}, xi = 48)
// dex: classes3.dex
public final class l0 extends Exception {

    public final int errorCode;

    public l0(int i10) {
        this.errorCode = i10;
    }

    public final int getErrorCode() {
        return this.errorCode;
    }
}
