package deobf.com.withpersona.sdk2.inquiry.un;

import android.util.Range;
import android.util.Size;
import com.github.luben.zstd.BuildConfig;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import deobf.com.withpersona.sdk2.inquiry.sn.v;

@Metadata(d1 = {"\u0000D\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0006\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\b\n\u0002\u0010\u000b\n\u0002\b\u0016\n\u0002\u0018\u0002\n\u0002\b\u0005\b\u0086\b\u0018\u00002\u00020\u0001BE\u0012\u0006\u0010\u0003\u001a\u00020\u0002\u0012\u0006\u0010\u0005\u001a\u00020\u0004\u0012\u0006\u0010\u0007\u001a\u00020\u0006\u0012\f\u0010\n\u001a\b\u0012\u0004\u0012\u00020\t0\b\u0012\u0006\u0010\u000b\u001a\u00020\t\u0012\u0006\u0010\r\u001a\u00020\f\u0012\u0006\u0010\u000f\u001a\u00020\u000e¢\u0006\u0004\b\u0010\u0010\u0011J\u000f\u0010\u0012\u001a\u00020\u0002H\u0016¢\u0006\u0004\b\u0012\u0010\u0013J\u0010\u0010\u0014\u001a\u00020\tHÖ\u0001¢\u0006\u0004\b\u0014\u0010\u0015J\u001a\u0010\u0018\u001a\u00020\u00172\b\u0010\u0016\u001a\u0004\u0018\u00010\u0001HÖ\u0003¢\u0006\u0004\b\u0018\u0010\u0019R\u0017\u0010\u0003\u001a\u00020\u00028\u0006¢\u0006\f\n\u0004\b\u001a\u0010\u001b\u001a\u0004\b\u001c\u0010\u0013R\u0017\u0010\u0005\u001a\u00020\u00048\u0006¢\u0006\f\n\u0004\b\u001d\u0010\u001e\u001a\u0004\b\u001f\u0010 R\u0017\u0010\u0007\u001a\u00020\u00068\u0006¢\u0006\f\n\u0004\b!\u0010\"\u001a\u0004\b#\u0010$R\u001d\u0010\n\u001a\b\u0012\u0004\u0012\u00020\t0\b8\u0006¢\u0006\f\n\u0004\b\u001c\u0010%\u001a\u0004\b&\u0010'R\u0017\u0010\u000b\u001a\u00020\t8\u0006¢\u0006\f\n\u0004\b(\u0010)\u001a\u0004\b(\u0010\u0015R\u0017\u0010\r\u001a\u00020\f8\u0006¢\u0006\f\n\u0004\b\u001f\u0010*\u001a\u0004\b!\u0010+R\u0017\u0010\u000f\u001a\u00020\u000e8\u0006¢\u0006\f\n\u0004\b&\u0010,\u001a\u0004\b\u001a\u0010-R\u0017\u00102\u001a\u00020.8\u0006¢\u0006\f\n\u0004\b/\u00100\u001a\u0004\b\u001d\u00101¨\u00063"}, d2 = {"Lun/h0;", BuildConfig.FLAVOR, BuildConfig.FLAVOR, "id", "Landroid/util/Size;", "size", BuildConfig.FLAVOR, "maxFps", "Landroid/util/Range;", BuildConfig.FLAVOR, "targetFpsRange", "rotation", "Lsn/v$b;", "facingMode", "Lun/n0;", "additionalOptions", "<init>", "(Ljava/lang/String;Landroid/util/Size;DLandroid/util/Range;ILsn/v$b;Lun/n0;)V", "toString", "()Ljava/lang/String;", "hashCode", "()I", "other", BuildConfig.FLAVOR, "equals", "(Ljava/lang/Object;)Z", deobf.android.view.xe.a.f36648e, "Ljava/lang/String;", "d", deobf.android.view.k6.b.f21144e, "Landroid/util/Size;", "f", "()Landroid/util/Size;", "c", "D", "getMaxFps", "()D", "Landroid/util/Range;", "g", "()Landroid/util/Range;", "e", "I", "Lsn/v$b;", "()Lsn/v$b;", "Lun/n0;", "()Lun/n0;", "Lsn/v;", "h", "Lsn/v;", "()Lsn/v;", "cameraProperties", "camera_release"}, k = 1, mv = {2, 2, 0}, xi = 48)
// dex: classes3.dex
public final /* data */ class h0 {

    @NotNull
    public final String id;

    @NotNull
    public final Size size;

    public final double maxFps;

    @NotNull
    public final Range<Integer> targetFpsRange;

    public final int rotation;

    @NotNull
    public final deobf.com.withpersona.sdk2.inquiry.v.b facing;

    @NotNull
    public final ExtraCameraOptions additionalOptions;

    @NotNull
    public final deobf.com.withpersona.sdk2.inquiry.sn.v cameraProperties;

    public h0(@NotNull String id2, @NotNull Size size, double d10, @NotNull Range<Integer> targetFpsRange, int i10, @NotNull deobf.com.withpersona.sdk2.inquiry.v.b facingMode, @NotNull ExtraCameraOptions additionalOptions) {
        Intrinsics.checkNotNullParameter(id2, "id");
        Intrinsics.checkNotNullParameter(size, "size");
        Intrinsics.checkNotNullParameter(targetFpsRange, "targetFpsRange");
        Intrinsics.checkNotNullParameter(facingMode, "facingMode");
        Intrinsics.checkNotNullParameter(additionalOptions, "additionalOptions");
        this.id = id2;
        this.size = size;
        this.maxFps = d10;
        this.targetFpsRange = targetFpsRange;
        this.rotation = i10;
        this.facing = facingMode;
        this.additionalOptions = additionalOptions;
        this.cameraProperties = new deobf.com.withpersona.sdk2.inquiry.sn.v(id2, facingMode, size, (int) d10, i10);
    }

    @NotNull
    public final ExtraCameraOptions getAdditionalOptions() {
        return this.additionalOptions;
    }

    @NotNull
    public final deobf.com.withpersona.sdk2.inquiry.sn.v getCameraProperties() {
        return this.cameraProperties;
    }

    @NotNull
    public final deobf.com.withpersona.sdk2.inquiry.v.b getFacing() {
        return this.facing;
    }

    @NotNull
    public final String getId() {
        return this.id;
    }

    public final int getRotation() {
        return this.rotation;
    }

    public boolean equals(@Nullable Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof h0)) {
            return false;
        }
        h0 h0Var = (h0) other;
        return Intrinsics.c(this.id, h0Var.id) && Intrinsics.c(this.size, h0Var.size) && Double.compare(this.maxFps, h0Var.maxFps) == 0 && Intrinsics.c(this.targetFpsRange, h0Var.targetFpsRange) && this.rotation == h0Var.rotation && this.facing == h0Var.facing && Intrinsics.c(this.additionalOptions, h0Var.additionalOptions);
    }

    @NotNull
    public final Size getSize() {
        return this.size;
    }

    @NotNull
    public final Range<Integer> g() {
        return this.targetFpsRange;
    }

    public int hashCode() {
        return (((((((((((this.id.hashCode() * 31) + this.size.hashCode()) * 31) + Double.hashCode(this.maxFps)) * 31) + this.targetFpsRange.hashCode()) * 31) + Integer.hashCode(this.rotation)) * 31) + this.facing.hashCode()) * 31) + this.additionalOptions.hashCode();
    }

    @NotNull
    public String toString() {
        return "(id=" + this.id + ", " + this.size.getWidth() + "x" + this.size.getHeight() + ", fps=" + this.targetFpsRange.getLower() + "-" + this.targetFpsRange.getUpper() + ", facing=" + this.facing + ")";
    }
}
