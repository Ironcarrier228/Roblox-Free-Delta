package deobf.com.withpersona.sdk2.inquiry.un;

import com.withpersona.sdk2.camera.camera2.Camera2PreviewView;
import org.jetbrains.annotations.Nullable;
import deobf.com.withpersona.sdk2.inquiry.un.b0;

// dex: classes3.dex
public final class d0 implements deobf.unlinked.b0.a {

    public final c0 f33608a;

    public d0(c0 c0Var) {
        this.f33608a = c0Var;
    }

    public static deobf.com.withpersona.sdk2.inquiry.wt.i<deobf.unlinked.b0.a> b(c0 c0Var) {
        return deobf.com.withpersona.sdk2.inquiry.wt.e.a(new d0(c0Var));
    }

    @Override // deobf.com.withpersona.sdk2.inquiry.un.b0.a
    public b0 a(CameraChoices cameraChoices, Camera2PreviewView camera2PreviewView, g gVar, deobf.unlinked.zn.a aVar, @Nullable deobf.unlinked.ks.a aVar2, boolean z10) {
        return this.f33608a.b(cameraChoices, camera2PreviewView, gVar, aVar, aVar2, z10);
    }
}
