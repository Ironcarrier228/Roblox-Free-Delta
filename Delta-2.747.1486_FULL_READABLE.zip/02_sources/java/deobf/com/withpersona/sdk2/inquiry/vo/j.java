package deobf.com.withpersona.sdk2.inquiry.vo;

import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import com.appsflyer.share.attribution.RequestError;
import com.github.luben.zstd.BuildConfig;
import com.withpersona.sdk2.inquiry.network.core.InternalErrorInfo;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import deobf.com.withpersona.sdk2.inquiry.ln.o;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(d1 = {"\u0000D\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u0011\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\n\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u00012\b\u0012\u0004\u0012\u00020\u00020\u0003:\u0001\u001eB/\b\u0007\u0012\u0014\b\u0001\u0010\u0007\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00060\u00050\u0004\u0012\u0006\u0010\t\u001a\u00020\b\u0012\u0006\u0010\u000b\u001a\u00020\n¢\u0006\u0004\b\f\u0010\rJ\r\u0010\u000f\u001a\u00020\u000e¢\u0006\u0004\b\u000f\u0010\u0010J\u0017\u0010\u0013\u001a\u0004\u0018\u00010\u00062\u0006\u0010\u0012\u001a\u00020\u0011¢\u0006\u0004\b\u0013\u0010\u0014J\u0015\u0010\u0016\u001a\b\u0012\u0004\u0012\u00020\u00020\u0015H\u0016¢\u0006\u0004\b\u0016\u0010\u0017R \u0010\u0007\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00060\u00050\u00048\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b\u0018\u0010\u0019R\u0014\u0010\t\u001a\u00020\b8\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b\u001a\u0010\u001bR\u0014\u0010\u000b\u001a\u00020\n8\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b\u001c\u0010\u001d¨\u0006\u001f"}, d2 = {"Lvo/j;", "Lln/o;", "Lvo/j$a;", "Lls/j;", "Lg/d;", BuildConfig.FLAVOR, BuildConfig.FLAVOR, "openDocumentLauncher", "Landroid/content/Context;", "context", "Ler/c;", "sdkFilesManager", "<init>", "(Lg/d;Landroid/content/Context;Ler/c;)V", BuildConfig.FLAVOR, "g", "()V", "Landroid/net/Uri;", "file", "f", "(Landroid/net/Uri;)Ljava/lang/String;", "Ldv/h;", "run", "()Ldv/h;", deobf.android.view.k6.b.f21144e, "Lg/d;", "c", "Landroid/content/Context;", "d", "Ler/c;", deobf.android.view.xe.a.f36648e, "government-id_release"}, k = 1, mv = {2, 2, 0}, xi = 48)
// dex: classes3.dex
public final class j implements deobf.com.withpersona.sdk2.inquiry.ln.o<a>, deobf.com.withpersona.sdk2.inquiry.ls.j<a> {

    @NotNull
    public final deobf.com.roblox.protocols.mediapicker.g.d<String[]> openDocumentLauncher;

    @NotNull
    public final Context context;

    @NotNull
    public final deobf.com.withpersona.sdk2.inquiry.er.c sdkFilesManager;

    @Metadata(d1 = {"\u0000\u001a\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\b6\u0018\u00002\u00020\u0001:\u0003\u0004\u0005\u0006B\t\b\u0004¢\u0006\u0004\b\u0002\u0010\u0003\u0082\u0001\u0003\u0007\b\t¨\u0006\n"}, d2 = {"Lvo/j$a;", BuildConfig.FLAVOR, "<init>", "()V", "c", deobf.android.view.k6.b.f21144e, deobf.android.view.xe.a.f36648e, "Lvo/j$a$a;", "Lvo/j$a$b;", "Lvo/j$a$c;", "government-id_release"}, k = 1, mv = {2, 2, 0}, xi = 48)
    public static abstract class a {

        @Metadata(d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\bÆ\u0002\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003¨\u0006\u0004"}, d2 = {"Lvo/j$a$a;", "Lvo/j$a;", "<init>", "()V", "government-id_release"}, k = 1, mv = {2, 2, 0}, xi = 48)
        public static final class C0712a extends a {

            @NotNull
            public static final C0712a f34670a = new C0712a();

            public C0712a() {
                super(null);
            }
        }

        @Metadata(d1 = {"\u0000\u0010\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0007\u0018\u00002\u00020\u0001B\u000f\u0012\u0006\u0010\u0003\u001a\u00020\u0002¢\u0006\u0004\b\u0004\u0010\u0005R\u0017\u0010\u0003\u001a\u00020\u00028\u0006¢\u0006\f\n\u0004\b\u0006\u0010\u0007\u001a\u0004\b\u0006\u0010\b¨\u0006\t"}, d2 = {"Lvo/j$a$b;", "Lvo/j$a;", "Lcom/withpersona/sdk2/inquiry/network/core/InternalErrorInfo;", "cause", "<init>", "(Lcom/withpersona/sdk2/inquiry/network/core/InternalErrorInfo;)V", deobf.android.view.xe.a.f36648e, "Lcom/withpersona/sdk2/inquiry/network/core/InternalErrorInfo;", "()Lcom/withpersona/sdk2/inquiry/network/core/InternalErrorInfo;", "government-id_release"}, k = 1, mv = {2, 2, 0}, xi = 48)
        public static final class b extends a {

            @NotNull
            public final InternalErrorInfo cause;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            public b(@NotNull InternalErrorInfo cause) {
                super(null);
                Intrinsics.checkNotNullParameter(cause, "cause");
                this.cause = cause;
            }

            @NotNull
            public final InternalErrorInfo getCause() {
                return this.cause;
            }
        }

        @Metadata(d1 = {"\u0000\u0010\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u000e\n\u0002\b\t\u0018\u00002\u00020\u0001B\u0019\u0012\u0006\u0010\u0003\u001a\u00020\u0002\u0012\b\u0010\u0004\u001a\u0004\u0018\u00010\u0002¢\u0006\u0004\b\u0005\u0010\u0006R\u0017\u0010\u0003\u001a\u00020\u00028\u0006¢\u0006\f\n\u0004\b\u0007\u0010\b\u001a\u0004\b\u0007\u0010\tR\u0019\u0010\u0004\u001a\u0004\u0018\u00010\u00028\u0006¢\u0006\f\n\u0004\b\n\u0010\b\u001a\u0004\b\n\u0010\t¨\u0006\u000b"}, d2 = {"Lvo/j$a$c;", "Lvo/j$a;", BuildConfig.FLAVOR, "absoluteFilePath", "fileName", "<init>", "(Ljava/lang/String;Ljava/lang/String;)V", deobf.android.view.xe.a.f36648e, "Ljava/lang/String;", "()Ljava/lang/String;", deobf.android.view.k6.b.f21144e, "government-id_release"}, k = 1, mv = {2, 2, 0}, xi = 48)
        public static final class c extends a {

            @NotNull
            public final String absoluteFilePath;

            @Nullable
            public final String fileName;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            public c(@NotNull String absoluteFilePath, @Nullable String str) {
                super(null);
                Intrinsics.checkNotNullParameter(absoluteFilePath, "absoluteFilePath");
                this.absoluteFilePath = absoluteFilePath;
                this.fileName = str;
            }

            @NotNull
            public final String getAbsoluteFilePath() {
                return this.absoluteFilePath;
            }

            @Nullable
            public final String getFileName() {
                return this.fileName;
            }
        }

        public /* synthetic */ a(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }

        public a() {
        }
    }

    @Metadata(d1 = {"\u0000\u0017\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0003*\u0001\u0000\b\n\u0018\u00002\b\u0012\u0004\u0012\u00028\u00000\u0001J\u001e\u0010\u0005\u001a\u00020\u00042\f\u0010\u0003\u001a\b\u0012\u0004\u0012\u00028\u00000\u0002H\u0096@¢\u0006\u0004\b\u0005\u0010\u0006¨\u0006\u0007"}, d2 = {"kotlinx/coroutines/flow/internal/SafeCollector_commonKt$unsafeFlow$1", "Ldv/h;", "Ldv/i;", "collector", BuildConfig.FLAVOR, "collect", "(Ldv/i;Leu/b;)Ljava/lang/Object;", "kotlinx-coroutines-core"}, k = 1, mv = {2, 2, 0}, xi = 48)
    public static final class b implements deobf.kotlin.dv.h<a> {

        public final /* synthetic */ deobf.kotlin.dv.h f34673a;
        public final /* synthetic */ j b;

        @Metadata(k = 3, mv = {2, 2, 0}, xi = 48)
        public static final class a<T> implements deobf.kotlin.dv.i {

            public final /* synthetic */ deobf.kotlin.dv.i f34674a;
            public final /* synthetic */ j b;

            @Metadata(k = 3, mv = {2, 2, 0}, xi = 48)
            @deobf.com.withpersona.sdk2.inquiry.gu.f(c = "com.withpersona.sdk2.inquiry.governmentid.DocumentSelectWorker$run$$inlined$map$1$2", f = "DocumentSelectWorker.kt", l = {RequestError.RESPONSE_CODE_FAILURE}, m = "emit")
            public static final class C0713a extends deobf.com.withpersona.sdk2.inquiry.gu.d {
                public int A;

                public /* synthetic */ Object f34675t;

                public int f34676u;

                public Object f34677v;

                public Object f34679x;

                public Object f34680y;

                public Object f34681z;

                public C0713a(deobf.kotlin.eu.b bVar) {
                    super(bVar);
                }

                @Override // deobf.com.withpersona.sdk2.inquiry.gu.a
                public final Object invokeSuspend(Object obj) {
                    this.f34675t = obj;
                    this.f34676u |= Integer.MIN_VALUE;
                    return a.this.emit(null, this);
                }
            }

            public a(deobf.kotlin.dv.i iVar, j jVar) {
                this.f34674a = iVar;
                this.b = jVar;
            }

            /* JADX WARN: Multi-variable type inference failed */
            /* JADX WARN: Removed duplicated region for block: B:15:0x003a  */
            /* JADX WARN: Removed duplicated region for block: B:8:0x0023  */
            @Override // deobf.kotlin.dv.i
            public final java.lang.Object emit(java.lang.Object r11, deobf.kotlin.eu.b r12) {
                /*
                    Method dump skipped, instructions count: 248
                    To view this dump add '--comments-level debug' option
                */
                throw new UnsupportedOperationException("Method not decompiled: deobf.com.withpersona.sdk2.inquiry.vo.j.b.a.emit(java.lang.Object, deobf.kotlin.eu.b):java.lang.Object");
            }
        }

        public b(deobf.kotlin.dv.h hVar, j jVar) {
            this.f34673a = hVar;
            this.b = jVar;
        }

        @Override // deobf.kotlin.dv.h
        public Object collect(deobf.kotlin.dv.i<? super a> iVar, deobf.kotlin.eu.b bVar) {
            Object collect = this.f34673a.collect(new a(iVar, this.b), bVar);
            return collect == deobf.kotlin.fu.c.e() ? collect : Unit.f21504a;
        }
    }

    public j(@NotNull deobf.com.roblox.protocols.mediapicker.g.d<String[]> openDocumentLauncher, @NotNull Context context, @NotNull deobf.com.withpersona.sdk2.inquiry.er.c sdkFilesManager) {
        Intrinsics.checkNotNullParameter(openDocumentLauncher, "openDocumentLauncher");
        Intrinsics.checkNotNullParameter(context, "context");
        Intrinsics.checkNotNullParameter(sdkFilesManager, "sdkFilesManager");
        this.openDocumentLauncher = openDocumentLauncher;
        this.context = context;
        this.sdkFilesManager = sdkFilesManager;
    }

    @Override // deobf.com.withpersona.sdk2.inquiry.ln.o
    public boolean a(@NotNull deobf.com.withpersona.sdk2.inquiry.ln.o<?> oVar) {
        return deobf.com.google.android.material.o.b.a(this, oVar);
    }

    @Override // deobf.com.withpersona.sdk2.inquiry.ls.j
    public boolean b(@NotNull deobf.com.withpersona.sdk2.inquiry.ls.j<?> jVar) {
        return super.b(jVar);
    }

    @Override // deobf.com.withpersona.sdk2.inquiry.ls.j
    public boolean c(@NotNull deobf.com.withpersona.sdk2.inquiry.ls.j<?> jVar) {
        return super.c(jVar);
    }

    @Nullable
    public final String f(@NotNull Uri file) {
        Intrinsics.checkNotNullParameter(file, "file");
        Cursor query = this.context.getContentResolver().query(file, null, null, null, null);
        if (query != null) {
            query.moveToFirst();
        }
        String string = query != null ? query.getString(Math.max(query.getColumnIndex("_display_name"), 0)) : null;
        if (query != null) {
            query.close();
        }
        return string;
    }

    public final void g() {
        this.openDocumentLauncher.b(new String[]{"image/*", "application/pdf"});
    }

    @Override // deobf.com.withpersona.sdk2.inquiry.ln.o, deobf.com.withpersona.sdk2.inquiry.ls.j
    @NotNull
    public deobf.kotlin.dv.h<a> run() {
        return deobf.kotlin.dv.j.y(new b(new deobf.com.withpersona.sdk2.inquiry.aq.u(), this), deobf.com.withpersona.sdk2.inquiry.av.g1.b());
    }
}
