package deobf.com.withpersona.sdk2.inquiry.un;

import com.withpersona.sdk2.camera.camera2.Camera2PreviewView;
import com.withpersona.sdk2.inquiry.tracking.TrackingEventsLogger;
import org.jetbrains.annotations.Nullable;
import deobf.com.withpersona.sdk2.inquiry.un.b0;

// dex: classes3.dex
public final class e {

    public final deobf.com.withpersona.sdk2.inquiry.wt.i<deobf.unlinked.b0.a> f33609a;
    public final deobf.com.withpersona.sdk2.inquiry.wt.i<i0> b;

    public final deobf.com.withpersona.sdk2.inquiry.wt.i<deobf.com.withpersona.sdk2.inquiry.av.p0> f33610c;

    public final deobf.com.withpersona.sdk2.inquiry.wt.i<TrackingEventsLogger> f33611d;

    public e(deobf.com.withpersona.sdk2.inquiry.wt.i<deobf.unlinked.b0.a> iVar, deobf.com.withpersona.sdk2.inquiry.wt.i<i0> iVar2, deobf.com.withpersona.sdk2.inquiry.wt.i<deobf.com.withpersona.sdk2.inquiry.av.p0> iVar3, deobf.com.withpersona.sdk2.inquiry.wt.i<TrackingEventsLogger> iVar4) {
        this.f33609a = iVar;
        this.b = iVar2;
        this.f33610c = iVar3;
        this.f33611d = iVar4;
    }

    public static e a(deobf.com.withpersona.sdk2.inquiry.wt.i<deobf.unlinked.b0.a> iVar, deobf.com.withpersona.sdk2.inquiry.wt.i<i0> iVar2, deobf.com.withpersona.sdk2.inquiry.wt.i<deobf.com.withpersona.sdk2.inquiry.av.p0> iVar3, deobf.com.withpersona.sdk2.inquiry.wt.i<TrackingEventsLogger> iVar4) {
        return new e(iVar, iVar2, iVar3, iVar4);
    }

    public static c c(deobf.unlinked.b0.a aVar, i0 i0Var, deobf.com.withpersona.sdk2.inquiry.av.p0 p0Var, TrackingEventsLogger trackingEventsLogger, CameraChoices cameraChoices, Camera2PreviewView camera2PreviewView, g gVar, deobf.unlinked.zn.a aVar2, @Nullable deobf.unlinked.ks.a aVar3, boolean z10) {
        return new c(aVar, i0Var, p0Var, trackingEventsLogger, cameraChoices, camera2PreviewView, gVar, aVar2, aVar3, z10);
    }

    public c b(CameraChoices cameraChoices, Camera2PreviewView camera2PreviewView, g gVar, deobf.unlinked.zn.a aVar, @Nullable deobf.unlinked.ks.a aVar2, boolean z10) {
        return c(this.f33609a.get(), this.b.get(), this.f33610c.get(), this.f33611d.get(), cameraChoices, camera2PreviewView, gVar, aVar, aVar2, z10);
    }
}
