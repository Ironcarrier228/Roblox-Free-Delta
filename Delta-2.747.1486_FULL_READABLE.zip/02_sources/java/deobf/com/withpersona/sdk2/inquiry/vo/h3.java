package deobf.com.withpersona.sdk2.inquiry.vo;

import com.github.luben.zstd.BuildConfig;
import kotlin.Metadata;

/* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
/* JADX WARN: Unknown enum class pattern. Please report as an issue! */
@Metadata(d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0010\u0010\n\u0002\b\u0007\b\u0086\u0081\u0002\u0018\u00002\b\u0012\u0004\u0012\u00020\u00000\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003j\u0002\b\u0004j\u0002\b\u0005j\u0002\b\u0006j\u0002\b\u0007¨\u0006\b"}, d2 = {"Lvo/h3;", BuildConfig.FLAVOR, "<init>", "(Ljava/lang/String;I)V", deobf.android.view.xe.a.f36648e, deobf.android.view.k6.b.f21144e, "c", "d", "government-id_release"}, k = 1, mv = {2, 2, 0}, xi = 48)
// dex: classes3.dex
public final class h3 {

    public static final h3 f34656a = new h3("World", 0);
    public static final h3 b = new h3("Card", 1);

    public static final h3 f34657c = new h3("Flag", 2);

    public static final h3 f34658d = new h3("House", 3);

    public static final /* synthetic */ h3[] f34659e;

    public static final /* synthetic */ deobf.com.withpersona.sdk2.inquiry.hu.a f34660f;

    static {
        h3[] a10 = a();
        f34659e = a10;
        f34660f = deobf.com.withpersona.sdk2.inquiry.hu.b.a(a10);
    }

    public h3(String str, int i10) {
    }

    public static final /* synthetic */ h3[] a() {
        return new h3[]{f34656a, b, f34657c, f34658d};
    }

    public static h3 valueOf(String str) {
        return (h3) Enum.valueOf(h3.class, str);
    }

    public static h3[] values() {
        return (h3[]) f34659e.clone();
    }
}
