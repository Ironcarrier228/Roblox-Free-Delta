package deobf.com.withpersona.sdk2.inquiry.vo;

import deobf.com.withpersona.sdk2.inquiry.hn.h;
import java.util.Set;

// dex: classes3.dex
public final class b0 implements deobf.com.withpersona.sdk2.inquiry.wt.d<Set<deobf.com.roblox.protocols.mediapicker.h.e>> {

    public static final class a {

        public static final b0 f34484a = new b0();
    }

    public static b0 a() {
        return a.f34484a;
    }

    public static Set<deobf.com.roblox.protocols.mediapicker.h.e> c() {
        return (Set) deobf.com.withpersona.sdk2.inquiry.wt.h.e(deobf.androidx.camera.camera2.internal.compat.quirk.a0.a());
    }

    @Override // deobf.unlinked.yt.a
    public Set<deobf.com.roblox.protocols.mediapicker.h.e> get() {
        return c();
    }
}
