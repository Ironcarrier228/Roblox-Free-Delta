package deobf.com.withpersona.sdk2.inquiry.vo;

import com.github.luben.zstd.BuildConfig;
import kotlin.Metadata;

/* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
/* JADX WARN: Unknown enum class pattern. Please report as an issue! */
@Metadata(d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0010\u0010\n\u0002\b\u0005\b\u0086\u0081\u0002\u0018\u00002\b\u0012\u0004\u0012\u00020\u00000\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003j\u0002\b\u0004j\u0002\b\u0005¨\u0006\u0006"}, d2 = {"Lvo/i;", BuildConfig.FLAVOR, "<init>", "(Ljava/lang/String;I)V", deobf.android.view.xe.a.f36648e, deobf.android.view.k6.b.f21144e, "government-id_release"}, k = 1, mv = {2, 2, 0}, xi = 48)
// dex: classes3.dex
public final class i {

    public static final i f34661a = new i("V0", 0);
    public static final i b = new i("K0000", 1);

    public static final /* synthetic */ i[] f34662c;

    public static final /* synthetic */ deobf.com.withpersona.sdk2.inquiry.hu.a f34663d;

    static {
        i[] a10 = a();
        f34662c = a10;
        f34663d = deobf.com.withpersona.sdk2.inquiry.hu.b.a(a10);
    }

    public i(String str, int i10) {
    }

    public static final /* synthetic */ i[] a() {
        return new i[]{f34661a, b};
    }

    public static i valueOf(String str) {
        return (i) Enum.valueOf(i.class, str);
    }

    public static i[] values() {
        return (i[]) f34662c.clone();
    }
}
