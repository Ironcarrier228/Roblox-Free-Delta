package deobf.com.withpersona.sdk2.inquiry.un;

import android.view.View;
import deobf.com.withpersona.sdk2.inquiry.av.d2;
import deobf.com.withpersona.sdk2.inquiry.av.g1;
import com.github.luben.zstd.BuildConfig;
import com.google.mlkit.common.MlKitException;
import com.withpersona.sdk2.camera.camera2.Camera2PreviewView;
import com.withpersona.sdk2.inquiry.tracking.TrackingEventsLogger;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import deobf.com.withpersona.sdk2.inquiry.sn.y;
import deobf.com.withpersona.sdk2.inquiry.un.b0;
import deobf.com.withpersona.sdk2.inquiry.un.c;
import deobf.com.withpersona.sdk2.inquiry.un.s;

@Metadata(d1 = {"\u0000\u009c\u0001\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0002\b\u0007\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0007\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\t\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0005\u0018\u00002\u00020\u0001:\u0001\u001dBg\b\u0007\u0012\u0006\u0010\u0003\u001a\u00020\u0002\u0012\u0006\u0010\u0005\u001a\u00020\u0004\u0012\u0006\u0010\u0007\u001a\u00020\u0006\u0012\u0006\u0010\t\u001a\u00020\b\u0012\b\b\u0001\u0010\u000b\u001a\u00020\n\u0012\b\b\u0001\u0010\r\u001a\u00020\f\u0012\b\b\u0001\u0010\u000f\u001a\u00020\u000e\u0012\b\b\u0001\u0010\u0011\u001a\u00020\u0010\u0012\n\b\u0001\u0010\u0013\u001a\u0004\u0018\u00010\u0012\u0012\b\b\u0001\u0010\u0015\u001a\u00020\u0014¢\u0006\u0004\b\u0016\u0010\u0017J\u000f\u0010\u0019\u001a\u00020\u0018H\u0016¢\u0006\u0004\b\u0019\u0010\u001aJ\u000f\u0010\u001b\u001a\u00020\u0018H\u0016¢\u0006\u0004\b\u001b\u0010\u001aJ\u0017\u0010\u001d\u001a\u00020\u00182\u0006\u0010\u001c\u001a\u00020\u0014H\u0016¢\u0006\u0004\b\u001d\u0010\u001eJ\u000f\u0010\u001f\u001a\u00020\u0018H\u0016¢\u0006\u0004\b\u001f\u0010\u001aJ\u0016\u0010\"\u001a\b\u0012\u0004\u0012\u00020!0 H\u0096@¢\u0006\u0004\b\"\u0010#J\u0016\u0010$\u001a\b\u0012\u0004\u0012\u00020\u00140 H\u0096@¢\u0006\u0004\b$\u0010#J\u0016\u0010%\u001a\b\u0012\u0004\u0012\u00020!0 H\u0096@¢\u0006\u0004\b%\u0010#J\u0017\u0010'\u001a\u00020\u00182\u0006\u0010&\u001a\u00020\u0014H\u0016¢\u0006\u0004\b'\u0010\u001eJ\u000f\u0010(\u001a\u00020\u0018H\u0002¢\u0006\u0004\b(\u0010\u001aJ\u001f\u0010,\u001a\b\u0012\u0004\u0012\u00020*0+*\b\u0012\u0004\u0012\u00020*0)H\u0002¢\u0006\u0004\b,\u0010-J\u000f\u0010.\u001a\u00020\u0018H\u0002¢\u0006\u0004\b.\u0010\u001aR\u0014\u0010\u0003\u001a\u00020\u00028\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b\u001d\u0010/R\u0014\u0010\u0005\u001a\u00020\u00048\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b0\u00101R\u0014\u0010\u0007\u001a\u00020\u00068\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b2\u00103R\u0014\u0010\t\u001a\u00020\b8\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b\u001f\u00104R\u0014\u00107\u001a\u0002058\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b'\u00106R\u0016\u0010;\u001a\u0002088\u0002@\u0002X\u0082\u000e¢\u0006\u0006\n\u0004\b9\u0010:R\u001c\u0010?\u001a\b\u0012\u0004\u0012\u00020=0<8\u0002@\u0002X\u0082\u000e¢\u0006\u0006\n\u0004\b\"\u0010>R\u0016\u0010B\u001a\u00020\u00148\u0002@\u0002X\u0082\u000e¢\u0006\u0006\n\u0004\b@\u0010AR\u0018\u0010E\u001a\u0004\u0018\u00010C8\u0002@\u0002X\u0082\u000e¢\u0006\u0006\n\u0004\b$\u0010DR\u001a\u0010G\u001a\b\u0012\u0004\u0012\u00020=0)8VX\u0096\u0004¢\u0006\u0006\u001a\u0004\b0\u0010FR\u0014\u0010\r\u001a\u00020H8VX\u0096\u0004¢\u0006\u0006\u001a\u0004\b2\u0010IR\u0014\u0010L\u001a\u00020J8VX\u0096\u0004¢\u0006\u0006\u001a\u0004\b9\u0010KR\u0014\u0010N\u001a\u00020\u00148VX\u0096\u0004¢\u0006\u0006\u001a\u0004\b@\u0010M¨\u0006O"}, d2 = {"Lun/c;", "Lsn/i;", "Lun/b0$a;", "camera2ManagerFactoryFactory", "Lun/i0;", "cameraChoiceHelper", "Lav/p0;", "coroutineScope", "Lcom/withpersona/sdk2/inquiry/tracking/TrackingEventsLogger;", "trackingEventsLogger", "Lun/k0;", "cameraChoices", "Lcom/withpersona/sdk2/camera/camera2/Camera2PreviewView;", "previewView", "Lun/g;", "analyzer", "Lzn/a;", "videoCaptureMethod", "Lks/a;", "webRtcManager", BuildConfig.FLAVOR, "isAudioRequired", "<init>", "(Lun/b0$a;Lun/i0;Lav/p0;Lcom/withpersona/sdk2/inquiry/tracking/TrackingEventsLogger;Lun/k0;Lcom/withpersona/sdk2/camera/camera2/Camera2PreviewView;Lun/g;Lzn/a;Lks/a;Z)V", BuildConfig.FLAVOR, "j", "()V", "destroy", "enable", deobf.android.view.xe.a.f36648e, "(Z)V", "d", "Lzt/n;", "Ljava/io/File;", "g", "(Leu/b;)Ljava/lang/Object;", "i", "k", "enableAnalyzer", "e", "z", "Ldv/p0;", "Lun/s$d;", "Ldv/h;", "w", "(Ldv/p0;)Ldv/h;", "y", "Lun/b0$a;", deobf.android.view.k6.b.f21144e, "Lun/i0;", "c", "Lav/p0;", "Lcom/withpersona/sdk2/inquiry/tracking/TrackingEventsLogger;", "Lun/b0;", "Lun/b0;", "camera2ManagerFactory", "Lun/s;", "f", "Lun/s;", "currentManager", "Ldv/c0;", "Lsn/y;", "Ldv/c0;", "_previewState", "h", "Z", "recordingOngoing", "Lav/d2;", "Lav/d2;", "currentStateCollectJob", "()Ldv/p0;", "cameraState", "Landroid/view/View;", "()Landroid/view/View;", "Lsn/v;", "()Lsn/v;", "cameraProperties", "()Z", "isRecordingLocally", "camera_release"}, k = 1, mv = {2, 2, 0}, xi = 48)
// dex: classes3.dex
public final class c implements deobf.com.withpersona.sdk2.inquiry.sn.i {

    @NotNull
    public final deobf.unlinked.b0.a camera2ManagerFactoryFactory;

    @NotNull
    public final i0 cameraChoiceHelper;

    @NotNull
    public final deobf.com.withpersona.sdk2.inquiry.av.p0 coroutineScope;

    @NotNull
    public final TrackingEventsLogger trackingEventsLogger;

    @NotNull
    public final b0 camera2ManagerFactory;

    @NotNull
    public s currentManager;

    @NotNull
    public deobf.kotlin.dv.c0<deobf.com.withpersona.sdk2.inquiry.sn.y> _previewState;

    public boolean recordingOngoing;

    @Nullable
    public d2 currentStateCollectJob;

    @Metadata(d1 = {"\u00004\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\bg\u0018\u00002\u00020\u0001JA\u0010\u000f\u001a\u00020\u000e2\u0006\u0010\u0003\u001a\u00020\u00022\u0006\u0010\u0005\u001a\u00020\u00042\u0006\u0010\u0007\u001a\u00020\u00062\u0006\u0010\t\u001a\u00020\b2\b\u0010\u000b\u001a\u0004\u0018\u00010\n2\u0006\u0010\r\u001a\u00020\fH&¢\u0006\u0004\b\u000f\u0010\u0010¨\u0006\u0011À\u0006\u0003"}, d2 = {"Lun/c$a;", BuildConfig.FLAVOR, "Lun/k0;", "cameraChoices", "Lcom/withpersona/sdk2/camera/camera2/Camera2PreviewView;", "previewView", "Lun/g;", "analyzer", "Lzn/a;", "videoCaptureMethod", "Lks/a;", "webRtcManager", BuildConfig.FLAVOR, "isAudioRequired", "Lun/c;", deobf.android.view.xe.a.f36648e, "(Lun/k0;Lcom/withpersona/sdk2/camera/camera2/Camera2PreviewView;Lun/g;Lzn/a;Lks/a;Z)Lun/c;", "camera_release"}, k = 1, mv = {2, 2, 0}, xi = 48)
    public interface a {
        @NotNull
        c a(@NotNull CameraChoices cameraChoices, @NotNull Camera2PreviewView previewView, @NotNull deobf.com.withpersona.sdk2.inquiry.un.g analyzer, @NotNull deobf.unlinked.zn.a videoCaptureMethod, @Nullable deobf.unlinked.ks.a webRtcManager, boolean isAudioRequired);
    }

    @Metadata(d1 = {"\u0000\u0012\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0002\u0010\u0004\u001a\u00020\u0003*\b\u0012\u0004\u0012\u00020\u00010\u00002\u0006\u0010\u0002\u001a\u00020\u0001H\n¢\u0006\u0004\b\u0004\u0010\u0005"}, d2 = {"Ldv/i;", "Lun/s$d;", "state", BuildConfig.FLAVOR, "<anonymous>", "(Ldv/i;Lun/s$d;)Z"}, k = 3, mv = {2, 2, 0})
    @deobf.com.withpersona.sdk2.inquiry.gu.f(c = "com.withpersona.sdk2.camera.camera2.Camera2Controller$completeWhenDestroyed$1", f = "Camera2Controller.kt", l = {MlKitException.CODE_SCANNER_CAMERA_PERMISSION_NOT_GRANTED}, m = "invokeSuspend")
    public static final class b extends deobf.com.withpersona.sdk2.inquiry.gu.m implements deobf.kotlin.pu.n<deobf.kotlin.dv.i<? super s.d>, s.d, deobf.kotlin.eu.b<? super Boolean>, Object> {

        public int f33583t;

        public /* synthetic */ Object f33584u;

        public /* synthetic */ Object f33585v;

        public b(deobf.kotlin.eu.b<? super b> bVar) {
            super(3, bVar);
        }

        @Override // deobf.com.withpersona.sdk2.inquiry.gu.a
        public final Object invokeSuspend(Object obj) {
            deobf.kotlin.dv.i iVar = (deobf.kotlin.dv.i) this.f33584u;
            s.d dVar = (s.d) this.f33585v;
            Object e10 = deobf.kotlin.fu.c.e();
            int i10 = this.f33583t;
            if (i10 == 0) {
                deobf.com.withpersona.sdk2.inquiry.zt.o.b(obj);
                this.f33584u = deobf.com.withpersona.sdk2.inquiry.gu.l.a(iVar);
                this.f33585v = dVar;
                this.f33583t = 1;
                if (iVar.emit(dVar, this) == e10) {
                    return e10;
                }
            } else {
                if (i10 != 1) {
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                deobf.com.withpersona.sdk2.inquiry.zt.o.b(obj);
            }
            return deobf.com.withpersona.sdk2.inquiry.gu.b.a(!Intrinsics.c(dVar, s.d.b.f33720a));
        }

        @Override // deobf.kotlin.pu.n
        public final Object invoke(deobf.kotlin.dv.i<? super s.d> iVar, s.d dVar, deobf.kotlin.eu.b<? super Boolean> bVar) {
            b bVar2 = new b(bVar);
            bVar2.f33584u = iVar;
            bVar2.f33585v = dVar;
            return bVar2.invokeSuspend(Unit.f21504a);
        }
    }

    @Metadata(d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0002\b\u0002\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\n¢\u0006\u0004\b\u0002\u0010\u0003"}, d2 = {"Lav/p0;", BuildConfig.FLAVOR, "<anonymous>", "(Lav/p0;)V"}, k = 3, mv = {2, 2, 0})
    @deobf.com.withpersona.sdk2.inquiry.gu.f(c = "com.withpersona.sdk2.camera.camera2.Camera2Controller$prepare$2", f = "Camera2Controller.kt", l = {98}, m = "invokeSuspend")
    public static final class C0683c extends deobf.com.withpersona.sdk2.inquiry.gu.m implements Function2<deobf.com.withpersona.sdk2.inquiry.av.p0, deobf.kotlin.eu.b<? super Unit>, Object> {

        public int f33586t;

        @Metadata(k = 3, mv = {2, 2, 0}, xi = 48)
        public static final class a<T> implements deobf.kotlin.dv.i {

            public final /* synthetic */ c f33588a;

            public a(c cVar) {
                this.f33588a = cVar;
            }

            public static final String d(c cVar) {
                return "First frame received for camera choice " + cVar.currentManager.getCameraChoice();
            }

            @Override // deobf.kotlin.dv.i
            public final Object emit(s.d dVar, deobf.kotlin.eu.b<? super Unit> bVar) {
                if (!Intrinsics.c(dVar, s.d.a.f33719a)) {
                    if (dVar instanceof s.d.Started) {
                        s.d.Started started = (s.d.Started) dVar;
                        if (started.getFirstFrameReceived()) {
                            TrackingEventsLogger trackingEventsLogger = this.f33588a.trackingEventsLogger;
                            final c cVar = this.f33588a;
                            TrackingEventsLogger.logDebugLogEvent$default(trackingEventsLogger, "camera", new Function0() { // from class: un.d
                                @Override // kotlin.jvm.functions.Function0
                                public final Object invoke() {
                                    String d10;
                                    d10 = c.C0683c.a.d(c.this);
                                    return d10;
                                }
                            }, false, 4, null);
                        }
                        this.f33588a._previewState.setValue(new y.Ready(started.getFirstFrameReceived()));
                    } else if (Intrinsics.c(dVar, s.d.b.f33720a)) {
                        this.f33588a._previewState.setValue(new y.Closed(this.f33588a.recordingOngoing, false));
                        c cVar2 = this.f33588a;
                        cVar2.currentManager = cVar2.camera2ManagerFactory.h();
                        this.f33588a.recordingOngoing = false;
                    } else {
                        if (!(dVar instanceof s.d.Error)) {
                            throw new deobf.com.withpersona.sdk2.inquiry.zt.l();
                        }
                        s.c error = ((s.d.Error) dVar).getError();
                        if (error instanceof s.c.a) {
                            this.f33588a.z();
                        } else {
                            if (!(error instanceof s.c.b)) {
                                throw new deobf.com.withpersona.sdk2.inquiry.zt.l();
                            }
                            this.f33588a._previewState.setValue(deobf.androidx.camera.camera2.y.c.f31745a);
                        }
                    }
                }
                return Unit.f21504a;
            }
        }

        public C0683c(deobf.kotlin.eu.b<? super C0683c> bVar) {
            super(2, bVar);
        }

        @Override // deobf.com.withpersona.sdk2.inquiry.gu.a
        public final deobf.kotlin.eu.b<Unit> create(Object obj, deobf.kotlin.eu.b<?> bVar) {
            return c.this.new C0683c(bVar);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(deobf.com.withpersona.sdk2.inquiry.av.p0 p0Var, deobf.kotlin.eu.b<? super Unit> bVar) {
            return ((C0683c) create(p0Var, bVar)).invokeSuspend(Unit.f21504a);
        }

        @Override // deobf.com.withpersona.sdk2.inquiry.gu.a
        public final Object invokeSuspend(Object obj) {
            Object e10 = deobf.kotlin.fu.c.e();
            int i10 = this.f33586t;
            if (i10 == 0) {
                deobf.com.withpersona.sdk2.inquiry.zt.o.b(obj);
                c cVar = c.this;
                deobf.kotlin.dv.h e11 = deobf.kotlin.dv.j.e(cVar.w(cVar.currentManager.e0()));
                a aVar = new a(c.this);
                this.f33586t = 1;
                if (e11.collect(aVar, this) == e10) {
                    return e10;
                }
            } else {
                if (i10 != 1) {
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                deobf.com.withpersona.sdk2.inquiry.zt.o.b(obj);
            }
            return Unit.f21504a;
        }
    }

    @Metadata(d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0002\b\u0002\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\n¢\u0006\u0004\b\u0002\u0010\u0003"}, d2 = {"Lav/p0;", BuildConfig.FLAVOR, "<anonymous>", "(Lav/p0;)V"}, k = 3, mv = {2, 2, 0})
    @deobf.com.withpersona.sdk2.inquiry.gu.f(c = "com.withpersona.sdk2.camera.camera2.Camera2Controller$retryPrepareWithNewCameraManager$1", f = "Camera2Controller.kt", l = {}, m = "invokeSuspend")
    public static final class d extends deobf.com.withpersona.sdk2.inquiry.gu.m implements Function2<deobf.com.withpersona.sdk2.inquiry.av.p0, deobf.kotlin.eu.b<? super Unit>, Object> {

        public int f33589t;

        public d(deobf.kotlin.eu.b<? super d> bVar) {
            super(2, bVar);
        }

        @Override // deobf.com.withpersona.sdk2.inquiry.gu.a
        public final deobf.kotlin.eu.b<Unit> create(Object obj, deobf.kotlin.eu.b<?> bVar) {
            return c.this.new d(bVar);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(deobf.com.withpersona.sdk2.inquiry.av.p0 p0Var, deobf.kotlin.eu.b<? super Unit> bVar) {
            return ((d) create(p0Var, bVar)).invokeSuspend(Unit.f21504a);
        }

        @Override // deobf.com.withpersona.sdk2.inquiry.gu.a
        public final Object invokeSuspend(Object obj) {
            deobf.kotlin.fu.c.e();
            if (this.f33589t != 0) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            deobf.com.withpersona.sdk2.inquiry.zt.o.b(obj);
            c.this._previewState.setValue(new y.Closed(true, true));
            c.this._previewState.setValue(deobf.androidx.camera.camera2.y.c.f31745a);
            c.this.j();
            return Unit.f21504a;
        }
    }

    @Metadata(k = 3, mv = {2, 2, 0}, xi = 48)
    @deobf.com.withpersona.sdk2.inquiry.gu.f(c = "com.withpersona.sdk2.camera.camera2.Camera2Controller", f = "Camera2Controller.kt", l = {159}, m = "startVideo-IoAF18A")
    public static final class e extends deobf.com.withpersona.sdk2.inquiry.gu.d {

        public /* synthetic */ Object f33591t;

        public int f33593v;

        public e(deobf.kotlin.eu.b<? super e> bVar) {
            super(bVar);
        }

        @Override // deobf.com.withpersona.sdk2.inquiry.gu.a
        @Nullable
        public final Object invokeSuspend(@NotNull Object obj) {
            this.f33591t = obj;
            this.f33593v |= Integer.MIN_VALUE;
            Object i10 = c.this.i(this);
            return i10 == deobf.kotlin.fu.c.e() ? i10 : deobf.com.withpersona.sdk2.inquiry.zt.n.a(i10);
        }
    }

    @Metadata(k = 3, mv = {2, 2, 0}, xi = 48)
    @deobf.com.withpersona.sdk2.inquiry.gu.f(c = "com.withpersona.sdk2.camera.camera2.Camera2Controller", f = "Camera2Controller.kt", l = {170}, m = "stopVideo-IoAF18A")
    public static final class f extends deobf.com.withpersona.sdk2.inquiry.gu.d {

        public /* synthetic */ Object f33594t;

        public int f33596v;

        public f(deobf.kotlin.eu.b<? super f> bVar) {
            super(bVar);
        }

        @Override // deobf.com.withpersona.sdk2.inquiry.gu.a
        @Nullable
        public final Object invokeSuspend(@NotNull Object obj) {
            this.f33594t = obj;
            this.f33596v |= Integer.MIN_VALUE;
            Object k10 = c.this.k(this);
            return k10 == deobf.kotlin.fu.c.e() ? k10 : deobf.com.withpersona.sdk2.inquiry.zt.n.a(k10);
        }
    }

    @Metadata(k = 3, mv = {2, 2, 0}, xi = 48)
    @deobf.com.withpersona.sdk2.inquiry.gu.f(c = "com.withpersona.sdk2.camera.camera2.Camera2Controller", f = "Camera2Controller.kt", l = {152}, m = "takePicture-IoAF18A")
    public static final class g extends deobf.com.withpersona.sdk2.inquiry.gu.d {

        public /* synthetic */ Object f33597t;

        public int f33599v;

        public g(deobf.kotlin.eu.b<? super g> bVar) {
            super(bVar);
        }

        @Override // deobf.com.withpersona.sdk2.inquiry.gu.a
        @Nullable
        public final Object invokeSuspend(@NotNull Object obj) {
            this.f33597t = obj;
            this.f33599v |= Integer.MIN_VALUE;
            Object g10 = c.this.g(this);
            return g10 == deobf.kotlin.fu.c.e() ? g10 : deobf.com.withpersona.sdk2.inquiry.zt.n.a(g10);
        }
    }

    public c(@NotNull deobf.unlinked.b0.a camera2ManagerFactoryFactory, @NotNull i0 cameraChoiceHelper, @NotNull deobf.com.withpersona.sdk2.inquiry.av.p0 coroutineScope, @NotNull TrackingEventsLogger trackingEventsLogger, @NotNull CameraChoices cameraChoices, @NotNull Camera2PreviewView previewView, @NotNull deobf.com.withpersona.sdk2.inquiry.un.g analyzer, @NotNull deobf.unlinked.zn.a videoCaptureMethod, @Nullable deobf.unlinked.ks.a aVar, boolean z10) {
        Intrinsics.checkNotNullParameter(camera2ManagerFactoryFactory, "camera2ManagerFactoryFactory");
        Intrinsics.checkNotNullParameter(cameraChoiceHelper, "cameraChoiceHelper");
        Intrinsics.checkNotNullParameter(coroutineScope, "coroutineScope");
        Intrinsics.checkNotNullParameter(trackingEventsLogger, "trackingEventsLogger");
        Intrinsics.checkNotNullParameter(cameraChoices, "cameraChoices");
        Intrinsics.checkNotNullParameter(previewView, "previewView");
        Intrinsics.checkNotNullParameter(analyzer, "analyzer");
        Intrinsics.checkNotNullParameter(videoCaptureMethod, "videoCaptureMethod");
        this.camera2ManagerFactoryFactory = camera2ManagerFactoryFactory;
        this.cameraChoiceHelper = cameraChoiceHelper;
        this.coroutineScope = coroutineScope;
        this.trackingEventsLogger = trackingEventsLogger;
        this._previewState = deobf.kotlin.dv.r0.a(deobf.androidx.camera.camera2.y.c.f31745a);
        b0 a10 = camera2ManagerFactoryFactory.a(cameraChoices, previewView, analyzer, videoCaptureMethod, aVar, z10);
        this.camera2ManagerFactory = a10;
        this.currentManager = a10.h();
    }

    public static final String A() {
        return "All camera choices exhausted. Emitting CameraState.Error, which surfaces as the \"Unsupported device.\" error.";
    }

    public static final String x(c cVar) {
        return "Attempting camera choice " + cVar.currentManager.getCameraChoice();
    }

    @Override // deobf.com.withpersona.sdk2.inquiry.sn.i
    public void a(boolean enable) {
        this.currentManager.Z(enable);
    }

    @Override // deobf.com.withpersona.sdk2.inquiry.sn.i
    @NotNull
    public deobf.kotlin.dv.p0<deobf.com.withpersona.sdk2.inquiry.sn.y> b() {
        return this._previewState;
    }

    @Override // deobf.com.withpersona.sdk2.inquiry.sn.i
    @NotNull
    public View getPreviewView() {
        return this.currentManager.getPreviewView();
    }

    @Override // deobf.com.withpersona.sdk2.inquiry.sn.i
    public void d() {
        this.currentManager.a0();
    }

    @Override // deobf.com.withpersona.sdk2.inquiry.sn.i
    public void destroy() {
        this.currentManager.Y();
    }

    @Override // deobf.com.withpersona.sdk2.inquiry.sn.i
    public void e(boolean enableAnalyzer) {
        this.currentManager.q0(enableAnalyzer);
    }

    @Override // deobf.com.withpersona.sdk2.inquiry.sn.i
    @NotNull
    public deobf.com.withpersona.sdk2.inquiry.sn.v f() {
        return this.currentManager.getCameraProperties();
    }

    /* JADX WARN: Removed duplicated region for block: B:14:0x0037  */
    /* JADX WARN: Removed duplicated region for block: B:8:0x0023  */
    @Override // deobf.com.withpersona.sdk2.inquiry.sn.i
    @org.jetbrains.annotations.Nullable
    public java.lang.Object g(@org.jetbrains.annotations.NotNull deobf.kotlin.eu.b<? super deobf.com.withpersona.sdk2.inquiry.zt.n<? extends java.io.File>> r5) {
        /*
            r4 = this;
            boolean r0 = r5 instanceof deobf.com.withpersona.sdk2.inquiry.un.c.g
            if (r0 == 0) goto L13
            r0 = r5
            un.c$g r0 = (deobf.com.withpersona.sdk2.inquiry.un.c.g) r0
            int r1 = r0.f33599v
            r2 = -2147483648(0xffffffff80000000, float:-0.0)
            r3 = r1 & r2
            if (r3 == 0) goto L13
            int r1 = r1 - r2
            r0.f33599v = r1
            goto L18
        L13:
            un.c$g r0 = new un.c$g
            r0.<init>(r5)
        L18:
            java.lang.Object r5 = r0.f33597t
            java.lang.Object r1 = deobf.kotlin.fu.c.e()
            int r2 = r0.f33599v
            r3 = 1
            if (r2 == 0) goto L37
            if (r2 != r3) goto L2f
            deobf.com.withpersona.sdk2.inquiry.zt.o.b(r5)
            deobf.com.withpersona.sdk2.inquiry.zt.n r5 = (deobf.com.withpersona.sdk2.inquiry.zt.n) r5
            java.lang.Object r5 = r5.getValue()
            return r5
        L2f:
            java.lang.IllegalStateException r5 = new java.lang.IllegalStateException
            java.lang.String r0 = "call to 'resume' before 'invoke' with coroutine"
            r5.<init>(r0)
            throw r5
        L37:
            deobf.com.withpersona.sdk2.inquiry.zt.o.b(r5)
            deobf.com.withpersona.sdk2.inquiry.un.s r5 = r4.currentManager
            r0.f33599v = r3
            java.lang.Object r5 = r5.o0(r0)
            if (r5 != r1) goto L45
            return r1
        L45:
            return r5
        */
        throw new UnsupportedOperationException("Method not decompiled: deobf.com.withpersona.sdk2.inquiry.un.c.g(deobf.kotlin.eu.b):java.lang.Object");
    }

    @Override // deobf.com.withpersona.sdk2.inquiry.sn.i
    public boolean getRecordingOngoing() {
        return this.recordingOngoing;
    }

    /* JADX WARN: Removed duplicated region for block: B:12:0x0061  */
    /* JADX WARN: Removed duplicated region for block: B:15:0x006e  */
    /* JADX WARN: Removed duplicated region for block: B:18:0x0063  */
    /* JADX WARN: Removed duplicated region for block: B:21:0x0037  */
    /* JADX WARN: Removed duplicated region for block: B:8:0x0023  */
    @Override // deobf.com.withpersona.sdk2.inquiry.sn.i
    @org.jetbrains.annotations.Nullable
    public java.lang.Object i(@org.jetbrains.annotations.NotNull deobf.kotlin.eu.b<? super deobf.com.withpersona.sdk2.inquiry.zt.n<java.lang.Boolean>> r5) {
        /*
            r4 = this;
            boolean r0 = r5 instanceof deobf.com.withpersona.sdk2.inquiry.un.c.e
            if (r0 == 0) goto L13
            r0 = r5
            un.c$e r0 = (deobf.com.withpersona.sdk2.inquiry.un.c.e) r0
            int r1 = r0.f33593v
            r2 = -2147483648(0xffffffff80000000, float:-0.0)
            r3 = r1 & r2
            if (r3 == 0) goto L13
            int r1 = r1 - r2
            r0.f33593v = r1
            goto L18
        L13:
            un.c$e r0 = new un.c$e
            r0.<init>(r5)
        L18:
            java.lang.Object r5 = r0.f33591t
            java.lang.Object r1 = deobf.kotlin.fu.c.e()
            int r2 = r0.f33593v
            r3 = 1
            if (r2 == 0) goto L37
            if (r2 != r3) goto L2f
            deobf.com.withpersona.sdk2.inquiry.zt.o.b(r5)
            deobf.com.withpersona.sdk2.inquiry.zt.n r5 = (deobf.com.withpersona.sdk2.inquiry.zt.n) r5
            java.lang.Object r5 = r5.getValue()
            goto L5b
        L2f:
            java.lang.IllegalStateException r5 = new java.lang.IllegalStateException
            java.lang.String r0 = "call to 'resume' before 'invoke' with coroutine"
            r5.<init>(r0)
            throw r5
        L37:
            deobf.com.withpersona.sdk2.inquiry.zt.o.b(r5)
            deobf.kotlin.dv.c0<deobf.com.withpersona.sdk2.inquiry.sn.y> r5 = r4._previewState
            java.lang.Object r5 = r5.getValue()
            boolean r5 = r5 instanceof deobf.com.withpersona.sdk2.inquiry.sn.y.Ready
            if (r5 != 0) goto L50
            zt.n$a r5 = deobf.com.withpersona.sdk2.inquiry.zt.n.INSTANCE
            r5 = 0
            java.lang.Boolean r5 = deobf.com.withpersona.sdk2.inquiry.gu.b.a(r5)
            java.lang.Object r5 = deobf.com.withpersona.sdk2.inquiry.zt.n.b(r5)
            return r5
        L50:
            deobf.com.withpersona.sdk2.inquiry.un.s r5 = r4.currentManager
            r0.f33593v = r3
            java.lang.Object r5 = r5.x0(r0)
            if (r5 != r1) goto L5b
            return r1
        L5b:
            boolean r0 = deobf.com.withpersona.sdk2.inquiry.zt.n.g(r5)
            if (r0 == 0) goto L63
            r0 = 0
            goto L64
        L63:
            r0 = r5
        L64:
            java.lang.Boolean r1 = deobf.com.withpersona.sdk2.inquiry.gu.b.a(r3)
            boolean r0 = kotlin.jvm.internal.Intrinsics.c(r0, r1)
            if (r0 == 0) goto L70
            r4.recordingOngoing = r3
        L70:
            return r5
        */
        throw new UnsupportedOperationException("Method not decompiled: deobf.com.withpersona.sdk2.inquiry.un.c.i(deobf.kotlin.eu.b):java.lang.Object");
    }

    @Override // deobf.com.withpersona.sdk2.inquiry.sn.i
    public void j() {
        d2 d10;
        if (Intrinsics.c(this._previewState.getValue(), deobf.androidx.camera.camera2.y.c.f31745a) || (this._previewState.getValue() instanceof y.Closed)) {
            d2 d2Var = this.currentStateCollectJob;
            if (d2Var != null) {
                deobf.androidx.constraintlayout.widget.d2.a.a(d2Var, null, 1, null);
            }
            this._previewState.setValue(deobf.androidx.camera.camera2.y.d.f31746a);
            TrackingEventsLogger.logDebugLogEvent$default(this.trackingEventsLogger, "camera", new Function0() { // from class: un.a
                @Override // kotlin.jvm.functions.Function0
                public final Object invoke() {
                    String x5;
                    x5 = c.x(c.this);
                    return x5;
                }
            }, false, 4, null);
            d10 = deobf.com.withpersona.sdk2.inquiry.av.k.d(this.coroutineScope, null, null, new C0683c(null), 3, null);
            this.currentStateCollectJob = d10;
            this.currentManager.r0();
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:14:0x0037  */
    /* JADX WARN: Removed duplicated region for block: B:8:0x0023  */
    @Override // deobf.com.withpersona.sdk2.inquiry.sn.i
    @org.jetbrains.annotations.Nullable
    public java.lang.Object k(@org.jetbrains.annotations.NotNull deobf.kotlin.eu.b<? super deobf.com.withpersona.sdk2.inquiry.zt.n<? extends java.io.File>> r5) {
        /*
            r4 = this;
            boolean r0 = r5 instanceof deobf.com.withpersona.sdk2.inquiry.un.c.f
            if (r0 == 0) goto L13
            r0 = r5
            un.c$f r0 = (deobf.com.withpersona.sdk2.inquiry.un.c.f) r0
            int r1 = r0.f33596v
            r2 = -2147483648(0xffffffff80000000, float:-0.0)
            r3 = r1 & r2
            if (r3 == 0) goto L13
            int r1 = r1 - r2
            r0.f33596v = r1
            goto L18
        L13:
            un.c$f r0 = new un.c$f
            r0.<init>(r5)
        L18:
            java.lang.Object r5 = r0.f33594t
            java.lang.Object r1 = deobf.kotlin.fu.c.e()
            int r2 = r0.f33596v
            r3 = 1
            if (r2 == 0) goto L37
            if (r2 != r3) goto L2f
            deobf.com.withpersona.sdk2.inquiry.zt.o.b(r5)
            deobf.com.withpersona.sdk2.inquiry.zt.n r5 = (deobf.com.withpersona.sdk2.inquiry.zt.n) r5
            java.lang.Object r5 = r5.getValue()
            return r5
        L2f:
            java.lang.IllegalStateException r5 = new java.lang.IllegalStateException
            java.lang.String r0 = "call to 'resume' before 'invoke' with coroutine"
            r5.<init>(r0)
            throw r5
        L37:
            deobf.com.withpersona.sdk2.inquiry.zt.o.b(r5)
            r5 = 0
            r4.recordingOngoing = r5
            deobf.com.withpersona.sdk2.inquiry.un.s r5 = r4.currentManager
            r0.f33596v = r3
            java.lang.Object r5 = r5.z0(r0)
            if (r5 != r1) goto L48
            return r1
        L48:
            return r5
        */
        throw new UnsupportedOperationException("Method not decompiled: deobf.com.withpersona.sdk2.inquiry.un.c.k(deobf.kotlin.eu.b):java.lang.Object");
    }

    public final deobf.kotlin.dv.h<s.d> w(deobf.kotlin.dv.p0<? extends s.d> p0Var) {
        return deobf.kotlin.dv.j.U(p0Var, new b(null));
    }

    public final void y() {
        this.currentManager = this.camera2ManagerFactory.h();
        deobf.com.withpersona.sdk2.inquiry.av.k.d(this.coroutineScope, g1.c(), null, new d(null), 2, null);
    }

    public final void z() {
        this.camera2ManagerFactory.f();
        if (!this.camera2ManagerFactory.i()) {
            TrackingEventsLogger.logDebugLogEvent$default(this.trackingEventsLogger, "camera", new Function0() { // from class: un.b
                @Override // kotlin.jvm.functions.Function0
                public final Object invoke() {
                    String A;
                    A = c.A();
                    return A;
                }
            }, false, 4, null);
            this._previewState.setValue(deobf.androidx.camera.camera2.y.b.f31744a);
        } else {
            d2 d2Var = this.currentStateCollectJob;
            if (d2Var != null) {
                deobf.androidx.constraintlayout.widget.d2.a.a(d2Var, null, 1, null);
            }
            y();
        }
    }
}
