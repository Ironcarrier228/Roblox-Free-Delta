package deobf.com.withpersona.sdk2.inquiry.un;

// dex: classes3.dex
public final /* synthetic */ class q0 {
    public static /* synthetic */ void a() {
    }
}
