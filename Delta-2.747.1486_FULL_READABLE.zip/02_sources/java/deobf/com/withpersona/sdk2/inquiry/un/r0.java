package deobf.com.withpersona.sdk2.inquiry.un;

import android.content.Context;
import android.media.MediaCodec;
import android.media.MediaRecorder;
import android.os.Build;
import android.view.Surface;
import deobf.com.withpersona.sdk2.inquiry.av.g1;
import com.github.luben.zstd.BuildConfig;
import java.io.File;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import deobf.com.withpersona.sdk2.inquiry.sn.AudioConfiguration;
import deobf.com.withpersona.sdk2.inquiry.sn.k1;

@Metadata(d1 = {"\u0000T\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\n\n\u0002\u0018\u0002\n\u0002\b\u000b\n\u0002\u0018\u0002\n\u0002\b\u0007\n\u0002\u0018\u0002\n\u0002\b\n\n\u0002\u0018\u0002\n\u0002\b\u0005\u0018\u0000 \u00132\u00020\u0001:\u0001\u001eB/\u0012\u0006\u0010\u0003\u001a\u00020\u0002\u0012\u0006\u0010\u0005\u001a\u00020\u0004\u0012\u0006\u0010\u0007\u001a\u00020\u0006\u0012\u0006\u0010\b\u001a\u00020\u0006\u0012\u0006\u0010\n\u001a\u00020\t¢\u0006\u0004\b\u000b\u0010\fJ\u0010\u0010\u000e\u001a\u00020\rH\u0086@¢\u0006\u0004\b\u000e\u0010\u000fJ\u0012\u0010\u0011\u001a\u0004\u0018\u00010\u0010H\u0086@¢\u0006\u0004\b\u0011\u0010\u000fJ\u0010\u0010\u0012\u001a\u00020\rH\u0086@¢\u0006\u0004\b\u0012\u0010\u000fJ\r\u0010\u0013\u001a\u00020\r¢\u0006\u0004\b\u0013\u0010\u0014J\u0017\u0010\u0016\u001a\u00020\r2\u0006\u0010\u0015\u001a\u00020\tH\u0002¢\u0006\u0004\b\u0016\u0010\u0017J\u0017\u0010\u0018\u001a\u00020\r2\u0006\u0010\u0015\u001a\u00020\tH\u0002¢\u0006\u0004\b\u0018\u0010\u0017J\u000f\u0010\u0019\u001a\u00020\u0010H\u0002¢\u0006\u0004\b\u0019\u0010\u001aJ\u000f\u0010\u001c\u001a\u00020\u001bH\u0002¢\u0006\u0004\b\u001c\u0010\u001dR\u0014\u0010\u0003\u001a\u00020\u00028\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b\u001e\u0010\u001fR\u0014\u0010\u0005\u001a\u00020\u00048\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b \u0010!R\u0014\u0010\u0007\u001a\u00020\u00068\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b\"\u0010#R\u0014\u0010\b\u001a\u00020\u00068\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b$\u0010#R\u0014\u0010\n\u001a\u00020\t8\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b%\u0010&R*\u0010.\u001a\n\u0012\u0004\u0012\u00020\r\u0018\u00010'8\u0006@\u0006X\u0086\u000e¢\u0006\u0012\n\u0004\b(\u0010)\u001a\u0004\b*\u0010+\"\u0004\b,\u0010-R\u0016\u00102\u001a\u0004\u0018\u00010/8\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b0\u00101R\u0016\u00104\u001a\u00020\u00108\u0002@\u0002X\u0082\u000e¢\u0006\u0006\n\u0004\b\u0012\u00103R\u0016\u00107\u001a\u00020\u001b8\u0002@\u0002X\u0082\u000e¢\u0006\u0006\n\u0004\b5\u00106R\u0016\u00108\u001a\u00020\t8\u0002@\u0002X\u0082\u000e¢\u0006\u0006\n\u0004\b\u0019\u0010&R\u0016\u00109\u001a\u00020\t8\u0002@\u0002X\u0082\u000e¢\u0006\u0006\n\u0004\b\u001c\u0010&R\u0014\u0010<\u001a\u00020:8\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b\u0018\u0010;R\u0011\u0010>\u001a\u00020/8F¢\u0006\u0006\u001a\u0004\b5\u0010=¨\u0006?"}, d2 = {"Lun/r0;", BuildConfig.FLAVOR, "Landroid/content/Context;", "context", "Lun/h0;", "cameraChoice", BuildConfig.FLAVOR, "fps", "orientationHint", BuildConfig.FLAVOR, "recordAudio", "<init>", "(Landroid/content/Context;Lun/h0;IIZ)V", BuildConfig.FLAVOR, "p", "(Leu/b;)Ljava/lang/Object;", "Ljava/io/File;", "q", "h", "m", "()V", "isInitialPrepare", "n", "(Z)V", "l", "j", "()Ljava/io/File;", "Landroid/media/MediaRecorder;", "k", "()Landroid/media/MediaRecorder;", deobf.android.view.xe.a.f36648e, "Landroid/content/Context;", deobf.android.view.k6.b.f21144e, "Lun/h0;", "c", "I", "d", "e", "Z", "Lkotlin/Function0;", "f", "Lkotlin/jvm/functions/Function0;", "getOnSurfaceChanged", "()Lkotlin/jvm/functions/Function0;", "o", "(Lkotlin/jvm/functions/Function0;)V", "onSurfaceChanged", "Landroid/view/Surface;", "g", "Landroid/view/Surface;", "_surface", "Ljava/io/File;", "currentFile", "i", "Landroid/media/MediaRecorder;", "mediaRecorder", "isPrepared", "isDestroyed", "Lkv/a;", "Lkv/a;", "mutex", "()Landroid/view/Surface;", "surface", "camera_release"}, k = 1, mv = {2, 2, 0}, xi = 48)
// dex: classes3.dex
public final class r0 {

    public static final boolean f33667n = true;

    @NotNull
    public final Context context;

    @NotNull
    public final h0 cameraChoice;

    public final int fps;

    public final int orientationHint;

    public final boolean recordAudio;

    @Nullable
    public Function0<Unit> onSurfaceChanged;

    @Nullable
    public final Surface _surface;

    @NotNull
    public File currentFile;

    @NotNull
    public MediaRecorder mediaRecorder;

    public boolean isPrepared;

    public boolean isDestroyed;

    @NotNull
    public final deobf.com.roblox.protocols.connectivityv2.kv.a mutex;

    @Metadata(k = 3, mv = {2, 2, 0}, xi = 48)
    @deobf.com.withpersona.sdk2.inquiry.gu.f(c = "com.withpersona.sdk2.camera.camera2.MediaRecorderWrapper", f = "MediaRecorderWrapper.kt", l = {212}, m = "destroy")
    public static final class b extends deobf.com.withpersona.sdk2.inquiry.gu.d {

        public Object f33679t;

        public int f33680u;

        public /* synthetic */ Object f33681v;

        public int f33683x;

        public b(deobf.kotlin.eu.b<? super b> bVar) {
            super(bVar);
        }

        @Override // deobf.com.withpersona.sdk2.inquiry.gu.a
        @Nullable
        public final Object invokeSuspend(@NotNull Object obj) {
            this.f33681v = obj;
            this.f33683x |= Integer.MIN_VALUE;
            return r0.this.h(this);
        }
    }

    @Metadata(d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0002\b\u0002\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\n¢\u0006\u0004\b\u0002\u0010\u0003"}, d2 = {"Lav/p0;", BuildConfig.FLAVOR, "<anonymous>", "(Lav/p0;)V"}, k = 3, mv = {2, 2, 0})
    @deobf.com.withpersona.sdk2.inquiry.gu.f(c = "com.withpersona.sdk2.camera.camera2.MediaRecorderWrapper$startRecording$2", f = "MediaRecorderWrapper.kt", l = {}, m = "invokeSuspend")
    public static final class c extends deobf.com.withpersona.sdk2.inquiry.gu.m implements Function2<deobf.com.withpersona.sdk2.inquiry.av.p0, deobf.kotlin.eu.b<? super Unit>, Object> {

        public int f33684t;

        public c(deobf.kotlin.eu.b<? super c> bVar) {
            super(2, bVar);
        }

        @Override // deobf.com.withpersona.sdk2.inquiry.gu.a
        public final deobf.kotlin.eu.b<Unit> create(Object obj, deobf.kotlin.eu.b<?> bVar) {
            return r0.this.new c(bVar);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(deobf.com.withpersona.sdk2.inquiry.av.p0 p0Var, deobf.kotlin.eu.b<? super Unit> bVar) {
            return ((c) create(p0Var, bVar)).invokeSuspend(Unit.f21504a);
        }

        @Override // deobf.com.withpersona.sdk2.inquiry.gu.a
        public final Object invokeSuspend(Object obj) {
            deobf.kotlin.fu.c.e();
            if (this.f33684t != 0) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            deobf.com.withpersona.sdk2.inquiry.zt.o.b(obj);
            try {
                r0.this.mediaRecorder.start();
            } catch (IllegalStateException unused) {
                r0.this.mediaRecorder.reset();
                r0.this.l(false);
                r0.this.mediaRecorder.start();
            }
            return Unit.f21504a;
        }
    }

    @Metadata(d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\u0010\u0002\u001a\u0004\u0018\u00010\u0001*\u00020\u0000H\n¢\u0006\u0004\b\u0002\u0010\u0003"}, d2 = {"Lav/p0;", "Ljava/io/File;", "<anonymous>", "(Lav/p0;)Ljava/io/File;"}, k = 3, mv = {2, 2, 0})
    @deobf.com.withpersona.sdk2.inquiry.gu.f(c = "com.withpersona.sdk2.camera.camera2.MediaRecorderWrapper$stopRecording$2", f = "MediaRecorderWrapper.kt", l = {212}, m = "invokeSuspend")
    public static final class d extends deobf.com.withpersona.sdk2.inquiry.gu.m implements Function2<deobf.com.withpersona.sdk2.inquiry.av.p0, deobf.kotlin.eu.b<? super File>, Object> {

        public Object f33686t;

        public Object f33687u;

        public int f33688v;

        public int f33689w;

        public d(deobf.kotlin.eu.b<? super d> bVar) {
            super(2, bVar);
        }

        @Override // deobf.com.withpersona.sdk2.inquiry.gu.a
        public final deobf.kotlin.eu.b<Unit> create(Object obj, deobf.kotlin.eu.b<?> bVar) {
            return r0.this.new d(bVar);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(deobf.com.withpersona.sdk2.inquiry.av.p0 p0Var, deobf.kotlin.eu.b<? super File> bVar) {
            return ((d) create(p0Var, bVar)).invokeSuspend(Unit.f21504a);
        }

        @Override // deobf.com.withpersona.sdk2.inquiry.gu.a
        public final Object invokeSuspend(Object obj) {
            deobf.com.roblox.protocols.connectivityv2.kv.a aVar;
            r0 r0Var;
            File file;
            Object e10 = deobf.kotlin.fu.c.e();
            int i10 = this.f33689w;
            if (i10 == 0) {
                deobf.com.withpersona.sdk2.inquiry.zt.o.b(obj);
                aVar = r0.this.mutex;
                r0 r0Var2 = r0.this;
                this.f33686t = aVar;
                this.f33687u = r0Var2;
                this.f33688v = 0;
                this.f33689w = 1;
                if (aVar.d(null, this) == e10) {
                    return e10;
                }
                r0Var = r0Var2;
            } else {
                if (i10 != 1) {
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                r0Var = (r0) this.f33687u;
                aVar = (deobf.com.roblox.protocols.connectivityv2.kv.a) this.f33686t;
                deobf.com.withpersona.sdk2.inquiry.zt.o.b(obj);
            }
            try {
                if (r0Var.isDestroyed) {
                    return null;
                }
                try {
                    r0Var.mediaRecorder.stop();
                    file = r0Var.currentFile;
                } catch (RuntimeException unused) {
                    r0Var.currentFile.delete();
                    file = null;
                }
                r0Var.mediaRecorder.release();
                if (r0Var.isDestroyed) {
                    return file;
                }
                r0Var.mediaRecorder = r0Var.k();
                r0Var.l(false);
                return file;
            } finally {
                aVar.f(null);
            }
        }
    }

    public r0(@NotNull Context context, @NotNull h0 cameraChoice, int i10, int i11, boolean z10) {
        Intrinsics.checkNotNullParameter(context, "context");
        Intrinsics.checkNotNullParameter(cameraChoice, "cameraChoice");
        this.context = context;
        this.cameraChoice = cameraChoice;
        this.fps = i10;
        this.orientationHint = i11;
        this.recordAudio = z10;
        this._surface = f33667n ? MediaCodec.createPersistentInputSurface() : null;
        this.currentFile = j();
        this.mediaRecorder = k();
        this.mutex = deobf.com.roblox.protocols.connectivityv2.kv.g.b(false, 1, null);
    }

    /* JADX WARN: Removed duplicated region for block: B:13:0x0055 A[Catch: all -> 0x005b, TRY_LEAVE, TryCatch #2 {all -> 0x005b, blocks: (B:11:0x0051, B:13:0x0055, B:17:0x005d), top: B:10:0x0051 }] */
    /* JADX WARN: Removed duplicated region for block: B:17:0x005d A[Catch: all -> 0x005b, TRY_ENTER, TRY_LEAVE, TryCatch #2 {all -> 0x005b, blocks: (B:11:0x0051, B:13:0x0055, B:17:0x005d), top: B:10:0x0051 }] */
    /* JADX WARN: Removed duplicated region for block: B:38:0x0036  */
    /* JADX WARN: Removed duplicated region for block: B:8:0x0024  */
    @org.jetbrains.annotations.Nullable
    public final java.lang.Object h(@org.jetbrains.annotations.NotNull deobf.kotlin.eu.b<? super kotlin.Unit> r6) {
        /*
            r5 = this;
            boolean r0 = r6 instanceof deobf.com.withpersona.sdk2.inquiry.un.r0.b
            if (r0 == 0) goto L13
            r0 = r6
            un.r0$b r0 = (deobf.com.withpersona.sdk2.inquiry.un.r0.b) r0
            int r1 = r0.f33683x
            r2 = -2147483648(0xffffffff80000000, float:-0.0)
            r3 = r1 & r2
            if (r3 == 0) goto L13
            int r1 = r1 - r2
            r0.f33683x = r1
            goto L18
        L13:
            un.r0$b r0 = new un.r0$b
            r0.<init>(r6)
        L18:
            java.lang.Object r6 = r0.f33681v
            java.lang.Object r1 = deobf.kotlin.fu.c.e()
            int r2 = r0.f33683x
            r3 = 1
            r4 = 0
            if (r2 == 0) goto L36
            if (r2 != r3) goto L2e
            java.lang.Object r0 = r0.f33679t
            deobf.com.roblox.protocols.connectivityv2.kv.a r0 = (deobf.com.roblox.protocols.connectivityv2.kv.a) r0
            deobf.com.withpersona.sdk2.inquiry.zt.o.b(r6)
            goto L51
        L2e:
            java.lang.IllegalStateException r6 = new java.lang.IllegalStateException
            java.lang.String r0 = "call to 'resume' before 'invoke' with coroutine"
            r6.<init>(r0)
            throw r6
        L36:
            deobf.com.withpersona.sdk2.inquiry.zt.o.b(r6)
            boolean r6 = r5.isDestroyed
            if (r6 == 0) goto L40
            kotlin.Unit r6 = kotlin.Unit.f21504a
            return r6
        L40:
            deobf.com.roblox.protocols.connectivityv2.kv.a r6 = r5.mutex
            r0.f33679t = r6
            r2 = 0
            r0.f33680u = r2
            r0.f33683x = r3
            java.lang.Object r0 = deobf.unlinked.r6.d(r4, r0)
            if (r0 != r1) goto L50
            return r1
        L50:
            r0 = r6
        L51:
            boolean r6 = r5.isDestroyed     // Catch: java.lang.Throwable -> L5b
            if (r6 == 0) goto L5d
            kotlin.Unit r6 = kotlin.Unit.f21504a     // Catch: java.lang.Throwable -> L5b
            r0.f(r4)
            return r6
        L5b:
            r6 = move-exception
            goto L80
        L5d:
            r5.isDestroyed = r3     // Catch: java.lang.Throwable -> L5b
            kotlin.Unit r6 = kotlin.Unit.f21504a     // Catch: java.lang.Throwable -> L5b
            r0.f(r4)
            android.view.Surface r6 = r5.i()     // Catch: java.lang.RuntimeException -> L6b
            r6.release()     // Catch: java.lang.RuntimeException -> L6b
        L6b:
            android.media.MediaRecorder r6 = r5.mediaRecorder     // Catch: java.lang.RuntimeException -> L70 java.lang.Throwable -> L76
            r6.stop()     // Catch: java.lang.RuntimeException -> L70 java.lang.Throwable -> L76
        L70:
            java.io.File r6 = r5.currentFile
            r6.delete()
            goto L7d
        L76:
            r6 = move-exception
            java.io.File r0 = r5.currentFile
            r0.delete()
            throw r6
        L7d:
            kotlin.Unit r6 = kotlin.Unit.f21504a
            return r6
        L80:
            r0.f(r4)
            throw r6
        */
        throw new UnsupportedOperationException("Method not decompiled: deobf.com.withpersona.sdk2.inquiry.un.r0.h(deobf.kotlin.eu.b):java.lang.Object");
    }

    @NotNull
    public final Surface i() {
        Surface surface = this._surface;
        if (surface != null) {
            return surface;
        }
        Surface surface2 = this.mediaRecorder.getSurface();
        Intrinsics.checkNotNullExpressionValue(surface2, "getSurface(...)");
        return surface2;
    }

    public final File j() {
        return new File(this.context.getCacheDir(), "video_recording_" + System.currentTimeMillis() + ".mp4");
    }

    public final MediaRecorder k() {
        if (Build.VERSION.SDK_INT < 31) {
            return new MediaRecorder();
        }
        q0.a();
        return deobf.androidx.camera.view.p0.a(this.context);
    }

    public final void l(boolean isInitialPrepare) {
        if (!isInitialPrepare) {
            this.currentFile = j();
        }
        n(isInitialPrepare);
    }

    public final void m() {
        if (this.isPrepared) {
            return;
        }
        this.isPrepared = true;
        l(true);
    }

    public final void n(boolean isInitialPrepare) {
        Function0<Unit> function0;
        this.mediaRecorder.setVideoSource(2);
        if (this.recordAudio) {
            this.mediaRecorder.setAudioSource(1);
        }
        this.mediaRecorder.setOutputFormat(2);
        this.mediaRecorder.setVideoFrameRate(this.fps);
        this.mediaRecorder.setVideoSize(this.cameraChoice.getSize().getWidth(), this.cameraChoice.getSize().getHeight());
        this.mediaRecorder.setVideoEncoder(2);
        this.mediaRecorder.setVideoEncodingBitRate(deobf.unlinked.k1.a(this.cameraChoice.getSize().getWidth(), this.cameraChoice.getSize().getHeight()));
        if (this.recordAudio) {
            AudioConfiguration a10 = deobf.com.withpersona.sdk2.inquiry.sn.d.a();
            if (a10 != null) {
                this.mediaRecorder.setAudioSamplingRate(a10.getSampleRateInHz());
                this.mediaRecorder.setAudioChannels(1);
            }
            this.mediaRecorder.setAudioEncoder(3);
        }
        this.mediaRecorder.setOrientationHint(this.orientationHint);
        boolean z10 = f33667n;
        if (z10) {
            this.mediaRecorder.setInputSurface(i());
        }
        this.mediaRecorder.setOutputFile(this.currentFile.getAbsolutePath());
        this.mediaRecorder.prepare();
        if (z10 || isInitialPrepare || (function0 = this.onSurfaceChanged) == null) {
            return;
        }
        function0.invoke();
    }

    public final void o(@Nullable Function0<Unit> function0) {
        this.onSurfaceChanged = function0;
    }

    @Nullable
    public final Object p(@NotNull deobf.kotlin.eu.b<? super Unit> bVar) {
        Object g10 = deobf.com.withpersona.sdk2.inquiry.av.i.g(deobf.unlinked.g1.a(), new c(null), bVar);
        return g10 == deobf.kotlin.fu.c.e() ? g10 : Unit.f21504a;
    }

    @Nullable
    public final Object q(@NotNull deobf.kotlin.eu.b<? super File> bVar) {
        return deobf.com.withpersona.sdk2.inquiry.av.i.g(deobf.unlinked.g1.a(), new d(null), bVar);
    }
}
