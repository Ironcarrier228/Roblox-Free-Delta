package deobf.com.withpersona.sdk2.inquiry.vo;

import android.content.Context;
import com.github.luben.zstd.BuildConfig;
import com.withpersona.sdk2.inquiry.governmentid.RawExtraction;
import deobf.com.withpersona.sdk2.inquiry.dp.AutocaptureState;
import java.io.IOException;
import java.util.List;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import deobf.com.withpersona.sdk2.inquiry.sn.ExtractedTexts;
import deobf.com.withpersona.sdk2.inquiry.sn.w0;
import deobf.com.withpersona.sdk2.inquiry.vo.IdConfig;
import deobf.com.withpersona.sdk2.inquiry.vo.n;
import deobf.com.withpersona.sdk2.inquiry.zt.n;

@Metadata(d1 = {"\u0000l\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0004\n\u0002\u0010\u000b\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u000b\n\u0002\u0018\u0002\n\u0002\b\u0003\b\u0086\b\u0018\u00002\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00030\u00020\u00012\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00030\u00020\u0004:\u0001\u0013B5\b\u0007\u0012\u0006\u0010\u0006\u001a\u00020\u0005\u0012\u0006\u0010\b\u001a\u00020\u0007\u0012\u0006\u0010\n\u001a\u00020\t\u0012\b\b\u0001\u0010\f\u001a\u00020\u000b\u0012\b\b\u0001\u0010\u000e\u001a\u00020\r¢\u0006\u0004\b\u000f\u0010\u0010J\u001b\u0010\u0013\u001a\u00020\u00122\n\u0010\u0011\u001a\u0006\u0012\u0002\b\u00030\u0001H\u0016¢\u0006\u0004\b\u0013\u0010\u0014J\u001b\u0010\u0015\u001a\u00020\u00122\n\u0010\u0011\u001a\u0006\u0012\u0002\b\u00030\u0004H\u0016¢\u0006\u0004\b\u0015\u0010\u0016J\u001b\u0010\u0018\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00030\u00020\u0017H\u0016¢\u0006\u0004\b\u0018\u0010\u0019J\u0010\u0010\u001a\u001a\u00020\rHÖ\u0001¢\u0006\u0004\b\u001a\u0010\u001bJ\u0010\u0010\u001d\u001a\u00020\u001cHÖ\u0001¢\u0006\u0004\b\u001d\u0010\u001eJ\u001a\u0010!\u001a\u00020\u00122\b\u0010 \u001a\u0004\u0018\u00010\u001fHÖ\u0003¢\u0006\u0004\b!\u0010\"J\u001d\u0010%\u001a\b\u0012\u0004\u0012\u00020\u00030\u00022\u0006\u0010$\u001a\u00020#H\u0002¢\u0006\u0004\b%\u0010&J\u0019\u0010(\u001a\u0004\u0018\u00010'2\u0006\u0010$\u001a\u00020#H\u0002¢\u0006\u0004\b(\u0010)R\u0014\u0010\u0006\u001a\u00020\u00058\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b*\u0010+R\u0014\u0010\b\u001a\u00020\u00078\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b\u0015\u0010,R\u0014\u0010\n\u001a\u00020\t8\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b-\u0010.R\u0014\u0010\f\u001a\u00020\u000b8\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b/\u00100R\u0014\u0010\u000e\u001a\u00020\r8\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b1\u00102R\u0016\u00105\u001a\u0002038\u0002@\u0002X\u0082\u000e¢\u0006\u0006\n\u0004\b%\u00104¨\u00066"}, d2 = {"Lvo/o;", "Lln/o;", "Lzt/n;", "Lvo/n$b;", "Lls/j;", "Landroid/content/Context;", "context", "Lsn/h0;", "governmentIdFeed", "Ler/c;", "sdkFilesManager", "Lvo/d3$e;", "side", BuildConfig.FLAVOR, "idClassKey", "<init>", "(Landroid/content/Context;Lsn/h0;Ler/c;Lvo/d3$e;Ljava/lang/String;)V", "otherWorker", BuildConfig.FLAVOR, deobf.android.view.xe.a.f36648e, "(Lln/o;)Z", "c", "(Lls/j;)Z", "Ldv/h;", "run", "()Ldv/h;", "toString", "()Ljava/lang/String;", BuildConfig.FLAVOR, "hashCode", "()I", BuildConfig.FLAVOR, "other", "equals", "(Ljava/lang/Object;)Z", "Lsn/w0$b;", "parsedIdSide", "g", "(Lsn/w0$b;)Ljava/lang/Object;", "Lvo/r;", "h", "(Lsn/w0$b;)Lvo/r;", deobf.android.view.k6.b.f21144e, "Landroid/content/Context;", "Lsn/h0;", "d", "Ler/c;", "e", "Lvo/d3$e;", "f", "Ljava/lang/String;", "Ldp/a;", "Ldp/a;", "autocaptureState", "government-id_release"}, k = 1, mv = {2, 2, 0}, xi = 48)
// dex: classes3.dex
public final /* data */ class GovernmentIdAnalyzeWorker implements deobf.com.withpersona.sdk2.inquiry.ln.o<deobf.com.withpersona.sdk2.inquiry.zt.n<? extends n.GovernmentIdImage>>, deobf.com.withpersona.sdk2.inquiry.ls.j<deobf.com.withpersona.sdk2.inquiry.zt.n<? extends n.GovernmentIdImage>> {

    @NotNull
    public final Context context;

    @NotNull
    public final deobf.com.withpersona.sdk2.inquiry.sn.h0 governmentIdFeed;

    @NotNull
    public final deobf.com.withpersona.sdk2.inquiry.er.c sdkFilesManager;

    @NotNull
    public final IdConfig.e side;

    @NotNull
    public final String idClassKey;

    @NotNull
    public AutocaptureState autocaptureState;

    @Metadata(d1 = {"\u0000\u001c\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\bg\u0018\u00002\u00020\u0001J\u001f\u0010\u0007\u001a\u00020\u00062\u0006\u0010\u0003\u001a\u00020\u00022\u0006\u0010\u0005\u001a\u00020\u0004H&¢\u0006\u0004\b\u0007\u0010\b¨\u0006\tÀ\u0006\u0003"}, d2 = {"Lvo/o$a;", BuildConfig.FLAVOR, "Lvo/d3$e;", "side", BuildConfig.FLAVOR, "idClassKey", "Lvo/o;", deobf.android.view.xe.a.f36648e, "(Lvo/d3$e;Ljava/lang/String;)Lvo/o;", "government-id_release"}, k = 1, mv = {2, 2, 0}, xi = 48)
    public interface a {
        @NotNull
        GovernmentIdAnalyzeWorker a(@NotNull IdConfig.e side, @NotNull String idClassKey);
    }

    @Metadata(k = 3, mv = {2, 2, 0}, xi = 48)
    public static final /* synthetic */ class b {

        public static final /* synthetic */ int[] f34910a;

        static {
            int[] iArr = new int[deobf.androidx.camera.video.internal.compat.quirk.w0.c.values().length];
            try {
                iArr[deobf.androidx.camera.video.internal.compat.quirk.w0.c.f31735a.ordinal()] = 1;
            } catch (NoSuchFieldError unused) {
            }
            try {
                iArr[deobf.androidx.camera.video.internal.compat.quirk.w0.c.b.ordinal()] = 2;
            } catch (NoSuchFieldError unused2) {
            }
            f34910a = iArr;
        }
    }

    @Metadata(d1 = {"\u0000\u0017\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0003*\u0001\u0000\b\n\u0018\u00002\b\u0012\u0004\u0012\u00028\u00000\u0001J\u001e\u0010\u0005\u001a\u00020\u00042\f\u0010\u0003\u001a\b\u0012\u0004\u0012\u00028\u00000\u0002H\u0096@¢\u0006\u0004\b\u0005\u0010\u0006¨\u0006\u0007"}, d2 = {"kotlinx/coroutines/flow/internal/SafeCollector_commonKt$unsafeFlow$1", "Ldv/h;", "Ldv/i;", "collector", BuildConfig.FLAVOR, "collect", "(Ldv/i;Leu/b;)Ljava/lang/Object;", "kotlinx-coroutines-core"}, k = 1, mv = {2, 2, 0}, xi = 48)
    public static final class c implements deobf.kotlin.dv.h<deobf.com.withpersona.sdk2.inquiry.zt.n<? extends n.GovernmentIdImage>> {

        public final /* synthetic */ deobf.kotlin.dv.h f34911a;
        public final /* synthetic */ GovernmentIdAnalyzeWorker b;

        @Metadata(k = 3, mv = {2, 2, 0}, xi = 48)
        public static final class a<T> implements deobf.kotlin.dv.i {

            public final /* synthetic */ deobf.kotlin.dv.i f34912a;
            public final /* synthetic */ GovernmentIdAnalyzeWorker b;

            @Metadata(k = 3, mv = {2, 2, 0}, xi = 48)
            @deobf.com.withpersona.sdk2.inquiry.gu.f(c = "com.withpersona.sdk2.inquiry.governmentid.GovernmentIdAnalyzeWorker$run$$inlined$mapNotNull$1$2", f = "GovernmentIdAnalyzeWorker.kt", l = {72}, m = "emit")
            public static final class C0716a extends deobf.com.withpersona.sdk2.inquiry.gu.d {
                public Object A;
                public int B;

                public /* synthetic */ Object f34913t;

                public int f34914u;

                public Object f34915v;

                public Object f34917x;

                public Object f34918y;

                public Object f34919z;

                public C0716a(deobf.kotlin.eu.b bVar) {
                    super(bVar);
                }

                @Override // deobf.com.withpersona.sdk2.inquiry.gu.a
                public final Object invokeSuspend(Object obj) {
                    this.f34913t = obj;
                    this.f34914u |= Integer.MIN_VALUE;
                    return a.this.emit(null, this);
                }
            }

            public a(deobf.kotlin.dv.i iVar, GovernmentIdAnalyzeWorker governmentIdAnalyzeWorker) {
                this.f34912a = iVar;
                this.b = governmentIdAnalyzeWorker;
            }

            /* JADX WARN: Removed duplicated region for block: B:15:0x003e  */
            /* JADX WARN: Removed duplicated region for block: B:8:0x0023  */
            @Override // deobf.kotlin.dv.i
            public final java.lang.Object emit(java.lang.Object r8, deobf.kotlin.eu.b r9) {
                /*
                    r7 = this;
                    boolean r0 = r9 instanceof vo.GovernmentIdAnalyzeWorker.c.a.C0716a
                    if (r0 == 0) goto L13
                    r0 = r9
                    vo.o$c$a$a r0 = (vo.GovernmentIdAnalyzeWorker.c.a.C0716a) r0
                    int r1 = r0.f34914u
                    r2 = -2147483648(0xffffffff80000000, float:-0.0)
                    r3 = r1 & r2
                    if (r3 == 0) goto L13
                    int r1 = r1 - r2
                    r0.f34914u = r1
                    goto L18
                L13:
                    vo.o$c$a$a r0 = new vo.o$c$a$a
                    r0.<init>(r9)
                L18:
                    java.lang.Object r9 = r0.f34913t
                    java.lang.Object r1 = deobf.kotlin.fu.c.e()
                    int r2 = r0.f34914u
                    r3 = 1
                    if (r2 == 0) goto L3e
                    if (r2 != r3) goto L36
                    java.lang.Object r8 = r0.A
                    deobf.com.withpersona.sdk2.inquiry.zt.n r8 = (deobf.com.withpersona.sdk2.inquiry.zt.n) r8
                    java.lang.Object r8 = r0.f34919z
                    deobf.kotlin.dv.i r8 = (deobf.kotlin.dv.i) r8
                    java.lang.Object r8 = r0.f34917x
                    vo.o$c$a$a r8 = (vo.GovernmentIdAnalyzeWorker.c.a.C0716a) r8
                    deobf.com.withpersona.sdk2.inquiry.zt.o.b(r9)
                    goto Lc7
                L36:
                    java.lang.IllegalStateException r8 = new java.lang.IllegalStateException
                    java.lang.String r9 = "call to 'resume' before 'invoke' with coroutine"
                    r8.<init>(r9)
                    throw r8
                L3e:
                    deobf.com.withpersona.sdk2.inquiry.zt.o.b(r9)
                    deobf.kotlin.dv.i r9 = r7.f34912a
                    r2 = r8
                    deobf.com.withpersona.sdk2.inquiry.zt.n r2 = (deobf.com.withpersona.sdk2.inquiry.zt.n) r2
                    java.lang.Object r2 = r2.getValue()
                    java.lang.Throwable r4 = deobf.com.withpersona.sdk2.inquiry.zt.n.e(r2)
                    if (r4 != 0) goto L8f
                    deobf.com.withpersona.sdk2.inquiry.sn.w0 r2 = (deobf.com.withpersona.sdk2.inquiry.sn.w0) r2
                    boolean r4 = r2 instanceof deobf.com.withpersona.sdk2.inquiry.sn.w0.ParsedIdSide
                    if (r4 == 0) goto L8d
                    sn.w0$b r2 = (deobf.com.withpersona.sdk2.inquiry.sn.w0.ParsedIdSide) r2
                    sn.j0 r4 = r2.getMetadata()
                    if (r4 == 0) goto L82
                    vo.o r5 = deobf.unlinked.r7.b
                    deobf.com.withpersona.sdk2.inquiry.dp.a r6 = vo.GovernmentIdAnalyzeWorker.e(r5)
                    deobf.com.withpersona.sdk2.inquiry.dp.a r4 = deobf.com.withpersona.sdk2.inquiry.dp.b.b(r6, r4)
                    vo.GovernmentIdAnalyzeWorker.f(r5, r4)
                    vo.o r4 = deobf.unlinked.r7.b
                    deobf.com.withpersona.sdk2.inquiry.dp.a r4 = vo.GovernmentIdAnalyzeWorker.e(r4)
                    boolean r4 = deobf.com.withpersona.sdk2.inquiry.dp.b.a(r4)
                    if (r4 == 0) goto L8d
                    vo.o r4 = deobf.unlinked.r7.b
                    java.lang.Object r2 = vo.GovernmentIdAnalyzeWorker.d(r4, r2)
                    deobf.com.withpersona.sdk2.inquiry.zt.n r2 = deobf.com.withpersona.sdk2.inquiry.zt.n.a(r2)
                    goto L9b
                L82:
                    vo.o r4 = deobf.unlinked.r7.b
                    java.lang.Object r2 = vo.GovernmentIdAnalyzeWorker.d(r4, r2)
                    deobf.com.withpersona.sdk2.inquiry.zt.n r2 = deobf.com.withpersona.sdk2.inquiry.zt.n.a(r2)
                    goto L9b
                L8d:
                    r2 = 0
                    goto L9b
                L8f:
                    java.lang.Object r2 = deobf.com.withpersona.sdk2.inquiry.zt.o.a(r4)
                    java.lang.Object r2 = deobf.com.withpersona.sdk2.inquiry.zt.n.b(r2)
                    deobf.com.withpersona.sdk2.inquiry.zt.n r2 = deobf.com.withpersona.sdk2.inquiry.zt.n.a(r2)
                L9b:
                    if (r2 == 0) goto Lc7
                    java.lang.Object r4 = deobf.com.withpersona.sdk2.inquiry.gu.l.a(r8)
                    r0.f34915v = r4
                    java.lang.Object r4 = deobf.com.withpersona.sdk2.inquiry.gu.l.a(r0)
                    r0.f34917x = r4
                    java.lang.Object r8 = deobf.com.withpersona.sdk2.inquiry.gu.l.a(r8)
                    r0.f34918y = r8
                    java.lang.Object r8 = deobf.com.withpersona.sdk2.inquiry.gu.l.a(r9)
                    r0.f34919z = r8
                    java.lang.Object r8 = deobf.com.withpersona.sdk2.inquiry.gu.l.a(r2)
                    r0.A = r8
                    r8 = 0
                    r0.B = r8
                    r0.f34914u = r3
                    java.lang.Object r8 = r9.emit(r2, r0)
                    if (r8 != r1) goto Lc7
                    return r1
                Lc7:
                    kotlin.Unit r8 = kotlin.Unit.f21504a
                    return r8
                */
                throw new UnsupportedOperationException("Method not decompiled: vo.GovernmentIdAnalyzeWorker.c.a.emit(java.lang.Object, deobf.kotlin.eu.b):java.lang.Object");
            }
        }

        public c(deobf.kotlin.dv.h hVar, GovernmentIdAnalyzeWorker governmentIdAnalyzeWorker) {
            this.f34911a = hVar;
            this.b = governmentIdAnalyzeWorker;
        }

        @Override // deobf.kotlin.dv.h
        public Object collect(deobf.kotlin.dv.i<? super deobf.com.withpersona.sdk2.inquiry.zt.n<? extends n.GovernmentIdImage>> iVar, deobf.kotlin.eu.b bVar) {
            Object collect = this.f34911a.collect(new a(iVar, this.b), bVar);
            return collect == deobf.kotlin.fu.c.e() ? collect : Unit.f21504a;
        }
    }

    public GovernmentIdAnalyzeWorker(@NotNull Context context, @NotNull deobf.com.withpersona.sdk2.inquiry.sn.h0 governmentIdFeed, @NotNull deobf.com.withpersona.sdk2.inquiry.er.c sdkFilesManager, @NotNull IdConfig.e side, @NotNull String idClassKey) {
        Intrinsics.checkNotNullParameter(context, "context");
        Intrinsics.checkNotNullParameter(governmentIdFeed, "governmentIdFeed");
        Intrinsics.checkNotNullParameter(sdkFilesManager, "sdkFilesManager");
        Intrinsics.checkNotNullParameter(side, "side");
        Intrinsics.checkNotNullParameter(idClassKey, "idClassKey");
        this.context = context;
        this.governmentIdFeed = governmentIdFeed;
        this.sdkFilesManager = sdkFilesManager;
        this.side = side;
        this.idClassKey = idClassKey;
        this.autocaptureState = new AutocaptureState(null, 1, null);
    }

    @Override // deobf.com.withpersona.sdk2.inquiry.ln.o
    public boolean a(@NotNull deobf.com.withpersona.sdk2.inquiry.ln.o<?> otherWorker) {
        Intrinsics.checkNotNullParameter(otherWorker, "otherWorker");
        return (otherWorker instanceof GovernmentIdAnalyzeWorker) && ((GovernmentIdAnalyzeWorker) otherWorker).side == this.side;
    }

    @Override // deobf.com.withpersona.sdk2.inquiry.ls.j
    public boolean b(@NotNull deobf.com.withpersona.sdk2.inquiry.ls.j<?> jVar) {
        return super.b(jVar);
    }

    @Override // deobf.com.withpersona.sdk2.inquiry.ls.j
    public boolean c(@NotNull deobf.com.withpersona.sdk2.inquiry.ls.j<?> otherWorker) {
        Intrinsics.checkNotNullParameter(otherWorker, "otherWorker");
        return (otherWorker instanceof GovernmentIdAnalyzeWorker) && ((GovernmentIdAnalyzeWorker) otherWorker).side == this.side;
    }

    public boolean equals(@Nullable Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof GovernmentIdAnalyzeWorker)) {
            return false;
        }
        GovernmentIdAnalyzeWorker governmentIdAnalyzeWorker = (GovernmentIdAnalyzeWorker) other;
        return Intrinsics.c(this.context, governmentIdAnalyzeWorker.context) && Intrinsics.c(this.governmentIdFeed, governmentIdAnalyzeWorker.governmentIdFeed) && Intrinsics.c(this.sdkFilesManager, governmentIdAnalyzeWorker.sdkFilesManager) && this.side == governmentIdAnalyzeWorker.side && Intrinsics.c(this.idClassKey, governmentIdAnalyzeWorker.idClassKey);
    }

    public final Object g(w0.ParsedIdSide parsedIdSide) {
        n.d dVar;
        try {
            String absolutePath = x.a(parsedIdSide.getBitmap(), this.sdkFilesManager).getAbsolutePath();
            Intrinsics.checkNotNullExpressionValue(absolutePath, "getAbsolutePath(...)");
            List d10 = kotlin.collections.o.d(new Frame(absolutePath, null, 2, null));
            int i10 = b.f34910a[parsedIdSide.getSide().ordinal()];
            if (i10 == 1) {
                dVar = n.d.f34848a;
            } else {
                if (i10 != 2) {
                    throw new deobf.com.withpersona.sdk2.inquiry.zt.l();
                }
                dVar = n.d.b;
            }
            String str = this.idClassKey;
            RawExtraction rawExtraction = null;
            deobf.unlinked.n.a aVar = deobf.unlinked.n.a.f34836a;
            deobf.com.withpersona.sdk2.inquiry.sn.g extractedBarcode = parsedIdSide.getExtractedBarcode();
            if (extractedBarcode != null) {
                rawExtraction = deobf.unlinked.q3.a(extractedBarcode);
            }
            return deobf.com.withpersona.sdk2.inquiry.zt.n.b(new n.GovernmentIdImage(d10, dVar, str, aVar, rawExtraction, h(parsedIdSide)));
        } catch (IOException e10) {
            n.Companion companion = deobf.com.withpersona.sdk2.inquiry.zt.n.INSTANCE;
            return deobf.com.withpersona.sdk2.inquiry.zt.n.b(deobf.com.withpersona.sdk2.inquiry.zt.o.a(e10));
        }
    }

    public final GovernmentIdDetails h(w0.ParsedIdSide parsedIdSide) {
        GovernmentIdDetails l10;
        deobf.com.withpersona.sdk2.inquiry.sn.g extractedBarcode = parsedIdSide.getExtractedBarcode();
        if (extractedBarcode != null && (l10 = h.l(extractedBarcode)) != null) {
            return l10;
        }
        ExtractedTexts extractedTexts = parsedIdSide.getExtractedTexts();
        if (extractedTexts != null) {
            return h.m(extractedTexts);
        }
        return null;
    }

    public int hashCode() {
        return (((((((this.context.hashCode() * 31) + this.governmentIdFeed.hashCode()) * 31) + this.sdkFilesManager.hashCode()) * 31) + this.side.hashCode()) * 31) + this.idClassKey.hashCode();
    }

    @Override // deobf.com.withpersona.sdk2.inquiry.ln.o, deobf.com.withpersona.sdk2.inquiry.ls.j
    @NotNull
    public deobf.kotlin.dv.h<deobf.com.withpersona.sdk2.inquiry.zt.n<n.GovernmentIdImage>> run() {
        return new c(this.governmentIdFeed, this);
    }

    @NotNull
    public String toString() {
        return "GovernmentIdAnalyzeWorker(context=" + this.context + ", governmentIdFeed=" + this.governmentIdFeed + ", sdkFilesManager=" + this.sdkFilesManager + ", side=" + this.side + ", idClassKey=" + this.idClassKey + ")";
    }
}
