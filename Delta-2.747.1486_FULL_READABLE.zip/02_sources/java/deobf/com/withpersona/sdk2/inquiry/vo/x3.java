package deobf.com.withpersona.sdk2.inquiry.vo;

import com.github.luben.zstd.BuildConfig;
import com.google.mlkit.vision.barcode.common.Barcode;
import com.withpersona.sdk2.inquiry.governmentid.network.AutoClassifyWorker;
import com.withpersona.sdk2.inquiry.network.core.ErrorResponse;
import com.withpersona.sdk2.inquiry.network.core.InternalErrorInfo;
import com.withpersona.sdk2.inquiry.tracking.TrackingEventsLogger;
import com.withpersona.sdk2.inquiry.tracking.model.GovIdCaptureButtonType;
import com.withpersona.sdk2.inquiry.tracking.model.GovernmentIdButtonEventData;
import java.util.List;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import deobf.com.withpersona.sdk2.inquiry.ln.k;
import deobf.com.withpersona.sdk2.inquiry.ln.r;
import org.jetbrains.annotations.NotNull;
import deobf.com.withpersona.sdk2.inquiry.vo.d2;
import deobf.com.withpersona.sdk2.inquiry.vo.f;
import deobf.com.withpersona.sdk2.inquiry.vo.j0;

@Metadata(d1 = {"\u0000\\\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\u001aU\u0010\u0010\u001a\u00020\u000f2\u0006\u0010\u0001\u001a\u00020\u00002\u0006\u0010\u0003\u001a\u00020\u00022&\u0010\n\u001a\"0\u0004R\u001a\u0012\u0004\u0012\u00020\u0000\u0012\u0004\u0012\u00020\u0007\u0012\u0004\u0012\u00020\b\u0012\u0004\u0012\u00020\t0\u0006j\u0002`\u00052\u0006\u0010\f\u001a\u00020\u000b2\u0006\u0010\u000e\u001a\u00020\r¢\u0006\u0004\b\u0010\u0010\u0011\u001aU\u0010\u0014\u001a\u00020\u000f2\u0006\u0010\u0001\u001a\u00020\u00002\u0006\u0010\u0003\u001a\u00020\u00022&\u0010\n\u001a\"0\u0004R\u001a\u0012\u0004\u0012\u00020\u0000\u0012\u0004\u0012\u00020\u0007\u0012\u0004\u0012\u00020\b\u0012\u0004\u0012\u00020\t0\u0006j\u0002`\u00052\u0006\u0010\f\u001a\u00020\u000b2\u0006\u0010\u0013\u001a\u00020\u0012¢\u0006\u0004\b\u0014\u0010\u0015\u001a=\u0010\u001e\u001a\u00020\u001d2\u0006\u0010\u0016\u001a\u00020\u00022\f\u0010\u0019\u001a\b\u0012\u0004\u0012\u00020\u00180\u00172\f\u0010\u001b\u001a\b\u0012\u0004\u0012\u00020\u001a0\u00172\b\u0010\u001c\u001a\u0004\u0018\u00010\u0007H\u0002¢\u0006\u0004\b\u001e\u0010\u001f¨\u0006 "}, d2 = {"Lvo/d2$a;", "renderProps", "Lvo/j0$j;", "renderState", "Lln/k$a;", "Lcom/withpersona/sdk2/inquiry/governmentid/RenderContext;", "Lln/k;", "Lvo/j0;", "Lvo/d2$b;", BuildConfig.FLAVOR, "context", "Lip/l;", "videoCaptureHelper", "Lcom/withpersona/sdk2/inquiry/tracking/TrackingEventsLogger;", "trackingEventsLogger", BuildConfig.FLAVOR, "h", "(Lvo/d2$a;Lvo/j0$j;Lln/k$a;Lip/l;Lcom/withpersona/sdk2/inquiry/tracking/TrackingEventsLogger;)V", "Lcom/withpersona/sdk2/inquiry/governmentid/network/AutoClassifyWorker$b;", "autoClassifyWorkerFactory", "j", "(Lvo/d2$a;Lvo/j0$j;Lln/k$a;Lip/l;Lcom/withpersona/sdk2/inquiry/governmentid/network/AutoClassifyWorker$b;)V", "state", BuildConfig.FLAVOR, "Lvo/m;", "captureFrames", "Lvo/f3;", "idConfigsForCountry", "backState", "Lvo/j0$b;", "g", "(Lvo/j0$j;Ljava/util/List;Ljava/util/List;Lvo/j0;)Lvo/j0$b;", "government-id_release"}, k = 2, mv = {2, 2, 0}, xi = 48)
// dex: classes3.dex
public final class x3 {
    public static final j0.AutoClassificationManualSelect g(j0.j jVar, List<Frame> list, List<IdConfigForCountry> list2, j0 j0Var) {
        String str;
        String str2;
        if (list2.size() == 1) {
            IdConfigForCountry idConfigForCountry = (IdConfigForCountry) CollectionsKt.d0(list2);
            String idClassKey = idConfigForCountry.g().size() == 1 ? ((IdConfig) CollectionsKt.d0(idConfigForCountry.g())).getIdClassKey() : null;
            str = idConfigForCountry.getCountryCode();
            str2 = idClassKey;
        } else {
            str = null;
            str2 = null;
        }
        return new j0.AutoClassificationManualSelect(jVar.getCurrentPart(), jVar.D(), jVar.C(), jVar.getPartIndex(), j0Var, jVar.getCountryCode(), list, new deobf.com.withpersona.sdk2.inquiry.sn.v(null, null, null, 0, 0, 31, null), list2, str, str2);
    }

    public static final void h(@NotNull deobf.androidx.constraintlayout.widget.d2.a renderProps, @NotNull j0.j renderState, @NotNull deobf.com.withpersona.sdk2.inquiry.ln.k<? super deobf.androidx.constraintlayout.widget.d2.a, j0, ? extends deobf.androidx.constraintlayout.widget.d2.b, ? extends Object>.a context, @NotNull deobf.unlinked.ip.l videoCaptureHelper, @NotNull TrackingEventsLogger trackingEventsLogger) {
        deobf.com.withpersona.sdk2.inquiry.ln.r<? super Object, j0, ? extends Object> c10;
        Intrinsics.checkNotNullParameter(renderProps, "renderProps");
        Intrinsics.checkNotNullParameter(renderState, "renderState");
        Intrinsics.checkNotNullParameter(context, "context");
        Intrinsics.checkNotNullParameter(videoCaptureHelper, "videoCaptureHelper");
        Intrinsics.checkNotNullParameter(trackingEventsLogger, "trackingEventsLogger");
        TrackingEventsLogger.logGovernmentIdButtonClickEvent$default(trackingEventsLogger, new GovernmentIdButtonEventData(GovIdCaptureButtonType.CONTINUE, null, 2, null), false, 2, null);
        f captureConfig = renderState.getCaptureConfig();
        if (captureConfig instanceof f.AutoClassifyConfig) {
            deobf.com.withpersona.sdk2.inquiry.ln.h<deobf.com.withpersona.sdk2.inquiry.ln.r<? super Object, j0, ? extends Object>> d10 = context.d();
            c10 = ln.b0.c(null, new Function1() { // from class: vo.r3
                @Override // kotlin.jvm.functions.Function1
                public final Object invoke(Object obj) {
                    Unit i10;
                    i10 = deobf.com.google.firebase.x3.i((deobf.android.view.r.c) obj);
                    return i10;
                }
            }, 1, null);
            d10.a(c10);
        } else {
            if (!(captureConfig instanceof f.IdCaptureConfig)) {
                throw new deobf.com.withpersona.sdk2.inquiry.zt.l();
            }
            b3.W(renderState, context, renderProps, renderState.getIdForReview(), ((f.IdCaptureConfig) captureConfig).getId(), videoCaptureHelper, renderState.getCameraProperties(), (r26 & Barcode.FORMAT_ITF) != 0, (r26 & Barcode.FORMAT_QR_CODE) != 0 ? renderState.C() : null, (r26 & Barcode.FORMAT_UPC_A) != 0 ? renderState.getPartIndex() : 0, (r26 & Barcode.FORMAT_UPC_E) != 0 ? null : null, (r26 & Barcode.FORMAT_PDF417) != 0 ? renderState.getCountryCode() : null);
        }
    }

    public static final Unit i(deobf.android.view.r.c action) {
        Intrinsics.checkNotNullParameter(action, "$this$action");
        Object c10 = action.c();
        j0.j jVar = c10 instanceof j0.j ? (j0.j) c10 : null;
        if (jVar == null) {
            return Unit.f21504a;
        }
        action.e(jVar.L(true));
        return Unit.f21504a;
    }

    public static final void j(@NotNull final deobf.androidx.constraintlayout.widget.d2.a renderProps, @NotNull final j0.j renderState, @NotNull final deobf.com.withpersona.sdk2.inquiry.ln.k<? super deobf.androidx.constraintlayout.widget.d2.a, j0, ? extends deobf.androidx.constraintlayout.widget.d2.b, ? extends Object>.a context, @NotNull final deobf.unlinked.ip.l videoCaptureHelper, @NotNull AutoClassifyWorker.b autoClassifyWorkerFactory) {
        Intrinsics.checkNotNullParameter(renderProps, "renderProps");
        Intrinsics.checkNotNullParameter(renderState, "renderState");
        Intrinsics.checkNotNullParameter(context, "context");
        Intrinsics.checkNotNullParameter(videoCaptureHelper, "videoCaptureHelper");
        Intrinsics.checkNotNullParameter(autoClassifyWorkerFactory, "autoClassifyWorkerFactory");
        deobf.com.withpersona.sdk2.inquiry.ln.w.l(context, autoClassifyWorkerFactory.a(renderProps.getSessionToken(), renderProps.getInquiryId(), renderProps.getFromStep(), renderProps.getFromComponent(), renderState.getIdForReview(), new AutoClassifyWorker.SupplementaryData(), renderProps.getManualCaptureButtonDelayMs(), renderProps.getAutoClassificationConfig().getExtractTextFromImage()), kotlin.jvm.internal.d0.k(AutoClassifyWorker.class), BuildConfig.FLAVOR, new Function1() { // from class: vo.s3
            @Override // kotlin.jvm.functions.Function1
            public final Object invoke(Object obj) {
                deobf.com.withpersona.sdk2.inquiry.ln.r k10;
                k10 = x3.k(deobf.unlinked.k.a.this, videoCaptureHelper, renderProps, renderState, (AutoClassifyWorker.c) obj);
                return k10;
            }
        });
    }

    public static final deobf.com.withpersona.sdk2.inquiry.ln.r k(final deobf.unlinked.k.a aVar, final deobf.unlinked.ip.l lVar, final deobf.androidx.constraintlayout.widget.d2.a aVar2, final j0.j jVar, final AutoClassifyWorker.c it) {
        deobf.com.withpersona.sdk2.inquiry.ln.r c10;
        deobf.com.withpersona.sdk2.inquiry.ln.r c11;
        deobf.com.withpersona.sdk2.inquiry.ln.r c12;
        deobf.com.withpersona.sdk2.inquiry.ln.r c13;
        Intrinsics.checkNotNullParameter(it, "it");
        if (it instanceof AutoClassifyWorker.c.a) {
            c13 = ln.b0.c(null, new Function1() { // from class: vo.t3
                @Override // kotlin.jvm.functions.Function1
                public final Object invoke(Object obj) {
                    Unit l10;
                    l10 = x3.l(AutoClassifyWorker.c.this, aVar, lVar, (deobf.android.view.r.c) obj);
                    return l10;
                }
            }, 1, null);
            return c13;
        }
        if (!(it instanceof AutoClassifyWorker.c.b)) {
            throw new deobf.com.withpersona.sdk2.inquiry.zt.l();
        }
        final AutoClassifyWorker.a autoClassificationResult = ((AutoClassifyWorker.c.b) it).getAutoClassificationResult();
        if (autoClassificationResult instanceof AutoClassifyWorker.a.C0175a) {
            c12 = ln.b0.c(null, new Function1() { // from class: vo.u3
                @Override // kotlin.jvm.functions.Function1
                public final Object invoke(Object obj) {
                    Unit m10;
                    m10 = x3.m(deobf.unlinked.k.a.this, aVar2, jVar, autoClassificationResult, lVar, (deobf.android.view.r.c) obj);
                    return m10;
                }
            }, 1, null);
            return c12;
        }
        if (autoClassificationResult instanceof AutoClassifyWorker.a.b) {
            c11 = ln.b0.c(null, new Function1() { // from class: vo.v3
                @Override // kotlin.jvm.functions.Function1
                public final Object invoke(Object obj) {
                    Unit n10;
                    n10 = x3.n(deobf.androidx.constraintlayout.widget.d2.a.this, jVar, autoClassificationResult, (deobf.android.view.r.c) obj);
                    return n10;
                }
            }, 1, null);
            return c11;
        }
        if (!(autoClassificationResult instanceof AutoClassifyWorker.a.c)) {
            throw new deobf.com.withpersona.sdk2.inquiry.zt.l();
        }
        c10 = ln.b0.c(null, new Function1() { // from class: vo.w3
            @Override // kotlin.jvm.functions.Function1
            public final Object invoke(Object obj) {
                Unit o10;
                o10 = x3.o(deobf.androidx.constraintlayout.widget.d2.a.this, jVar, autoClassificationResult, (deobf.android.view.r.c) obj);
                return o10;
            }
        }, 1, null);
        return c10;
    }

    public static final Unit l(AutoClassifyWorker.c cVar, deobf.unlinked.k.a aVar, deobf.unlinked.ip.l lVar, deobf.android.view.r.c action) {
        Intrinsics.checkNotNullParameter(action, "$this$action");
        InternalErrorInfo cause = ((AutoClassifyWorker.c.a) cVar).getCause();
        j0 backState = ((j0) action.c()).getBackState();
        InternalErrorInfo.NetworkErrorInfo networkErrorInfo = cause instanceof InternalErrorInfo.NetworkErrorInfo ? (InternalErrorInfo.NetworkErrorInfo) cause : null;
        if ((networkErrorInfo != null ? networkErrorInfo.getResponseError() : null) instanceof ErrorResponse.Error.InconsistentTransitionError) {
            b3.b0(aVar, new deobf.androidx.constraintlayout.widget.d2.b.c(cause), lVar);
        } else if (networkErrorInfo == null || networkErrorInfo.getCode() != 422 || backState == null) {
            b3.b0(aVar, new deobf.androidx.constraintlayout.widget.d2.b.c(cause), lVar);
        } else {
            action.e(backState);
        }
        return Unit.f21504a;
    }

    public static final Unit m(deobf.unlinked.k.a aVar, deobf.androidx.constraintlayout.widget.d2.a aVar2, j0.j jVar, AutoClassifyWorker.a aVar3, deobf.unlinked.ip.l lVar, deobf.android.view.r.c action) {
        Intrinsics.checkNotNullParameter(action, "$this$action");
        Object c10 = action.c();
        j0.j jVar2 = c10 instanceof j0.j ? (j0.j) c10 : null;
        if (jVar2 == null) {
            return Unit.f21504a;
        }
        action.e(jVar2.L(false));
        AutoClassifyWorker.a.C0175a c0175a = (AutoClassifyWorker.a.C0175a) aVar3;
        b3.W(jVar2, aVar, aVar2, jVar.getIdForReview(), c0175a.getIdConfig(), lVar, jVar.getCameraProperties(), (r26 & Barcode.FORMAT_ITF) != 0, (r26 & Barcode.FORMAT_QR_CODE) != 0 ? jVar2.C() : c0175a.getIdConfig().f(), (r26 & Barcode.FORMAT_UPC_A) != 0 ? jVar2.getPartIndex() : 0, (r26 & Barcode.FORMAT_UPC_E) != 0 ? null : null, (r26 & Barcode.FORMAT_PDF417) != 0 ? jVar2.getCountryCode() : null);
        return Unit.f21504a;
    }

    public static final Unit n(deobf.androidx.constraintlayout.widget.d2.a aVar, j0.j jVar, AutoClassifyWorker.a aVar2, deobf.android.view.r.c action) {
        Intrinsics.checkNotNullParameter(action, "$this$action");
        Object c10 = action.c();
        j0.j jVar2 = c10 instanceof j0.j ? (j0.j) c10 : null;
        if (jVar2 == null) {
            return Unit.f21504a;
        }
        action.e(aVar.getDesignVersion() == deobf.androidx.appcompat.widget.i.b ? g(jVar2, jVar.getIdForReview().j3(), ((AutoClassifyWorker.a.b) aVar2).a(), b3.x(action, false)) : new j0.AutoClassificationError(jVar2.getCurrentPart(), jVar2.D(), jVar2.C(), jVar2.getPartIndex(), b3.x(action, false), jVar2.getCountryCode(), jVar.getIdForReview().j3(), jVar.getCameraProperties(), ((AutoClassifyWorker.a.b) aVar2).a(), null, null, c.f34488a, 1536, null));
        return Unit.f21504a;
    }

    public static final Unit o(deobf.androidx.constraintlayout.widget.d2.a aVar, j0.j jVar, AutoClassifyWorker.a aVar2, deobf.android.view.r.c action) {
        Intrinsics.checkNotNullParameter(action, "$this$action");
        Object c10 = action.c();
        j0.j jVar2 = c10 instanceof j0.j ? (j0.j) c10 : null;
        if (jVar2 == null) {
            return Unit.f21504a;
        }
        action.e(aVar.getDesignVersion() == deobf.androidx.appcompat.widget.i.b ? g(jVar2, jVar.getIdForReview().j3(), ((AutoClassifyWorker.a.c) aVar2).a(), b3.x(action, false)) : new j0.AutoClassificationError(jVar2.getCurrentPart(), jVar2.D(), jVar2.C(), jVar2.getPartIndex(), b3.x(action, false), jVar2.getCountryCode(), jVar.getIdForReview().j3(), jVar.getCameraProperties(), ((AutoClassifyWorker.a.c) aVar2).a(), null, null, deobf.com.withpersona.sdk2.inquiry.c.b, 1536, null));
        return Unit.f21504a;
    }
}
