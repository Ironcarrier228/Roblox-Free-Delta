package deobf.com.withpersona.sdk2.inquiry.vo;

import android.graphics.Bitmap;
import com.withpersona.sdk2.inquiry.tracking.model.GovIdCaptureMethod;
import java.io.File;
import java.io.FileOutputStream;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;
import deobf.com.withpersona.sdk2.inquiry.vo.n;

@Metadata(d1 = {"\u0000\u001e\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\u001a\u001b\u0010\u0004\u001a\u00020\u0003*\u00020\u00002\u0006\u0010\u0002\u001a\u00020\u0001H\u0000¢\u0006\u0004\b\u0004\u0010\u0005\u001a\u0011\u0010\b\u001a\u00020\u0007*\u00020\u0006¢\u0006\u0004\b\b\u0010\t¨\u0006\n"}, d2 = {"Landroid/graphics/Bitmap;", "Ler/c;", "sdkFilesManager", "Ljava/io/File;", deobf.android.view.xe.a.f36648e, "(Landroid/graphics/Bitmap;Ler/c;)Ljava/io/File;", "Lvo/n$a;", "Lcom/withpersona/sdk2/inquiry/tracking/model/GovIdCaptureMethod;", deobf.android.view.k6.b.f21144e, "(Lvo/n$a;)Lcom/withpersona/sdk2/inquiry/tracking/model/GovIdCaptureMethod;", "government-id_release"}, k = 2, mv = {2, 2, 0}, xi = 48)
// dex: classes3.dex
public final class x {

    @Metadata(k = 3, mv = {2, 2, 0}, xi = 48)
    public static final /* synthetic */ class a {

        public static final /* synthetic */ int[] f35011a;

        static {
            int[] iArr = new int[deobf.unlinked.n.a.values().length];
            try {
                iArr[deobf.unlinked.n.a.f34836a.ordinal()] = 1;
            } catch (NoSuchFieldError unused) {
            }
            try {
                iArr[deobf.unlinked.n.a.b.ordinal()] = 2;
            } catch (NoSuchFieldError unused2) {
            }
            try {
                iArr[deobf.unlinked.n.a.f34837c.ordinal()] = 3;
            } catch (NoSuchFieldError unused3) {
            }
            f35011a = iArr;
        }
    }

    @NotNull
    public static final File a(@NotNull Bitmap bitmap, @NotNull deobf.com.withpersona.sdk2.inquiry.er.c sdkFilesManager) {
        Intrinsics.checkNotNullParameter(bitmap, "<this>");
        Intrinsics.checkNotNullParameter(sdkFilesManager, "sdkFilesManager");
        File e10 = sdkFilesManager.e("jpg");
        FileOutputStream fileOutputStream = new FileOutputStream(e10);
        try {
            bitmap.compress(Bitmap.CompressFormat.JPEG, 80, fileOutputStream);
            deobf.com.roblox.client.scheduledwork.lu.c.a(fileOutputStream, null);
            return e10;
        } finally {
        }
    }

    @NotNull
    public static final GovIdCaptureMethod b(@NotNull deobf.unlinked.n.a aVar) {
        Intrinsics.checkNotNullParameter(aVar, "<this>");
        int i10 = a.f35011a[aVar.ordinal()];
        if (i10 == 1) {
            return GovIdCaptureMethod.AUTO;
        }
        if (i10 == 2) {
            return GovIdCaptureMethod.MANUAL;
        }
        if (i10 == 3) {
            return GovIdCaptureMethod.VIDEO_UPLOAD;
        }
        throw new deobf.com.withpersona.sdk2.inquiry.zt.l();
    }
}
