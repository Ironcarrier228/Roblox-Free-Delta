package deobf.com.withpersona.sdk2.inquiry.jn;

import deobf.com.withpersona.sdk2.inquiry.hn.h;
import deobf.com.withpersona.sdk2.inquiry.hn.m;
import deobf.com.withpersona.sdk2.inquiry.hn.t;

// dex: classes2.dex
public final class b<T> extends h<T> {

    public final h<T> f20812a;

    public b(h<T> hVar) {
        this.f20812a = hVar;
    }

    @Override // deobf.com.withpersona.sdk2.inquiry.hn.h
    public T fromJson(m mVar) {
        return mVar.w() == m.c.NULL ? (T) mVar.p() : this.f20812a.fromJson(mVar);
    }

    @Override // deobf.com.withpersona.sdk2.inquiry.hn.h
    public void toJson(t tVar, T t8) {
        if (t8 == null) {
            tVar.p();
        } else {
            this.f20812a.toJson(tVar, (t) t8);
        }
    }

    public String toString() {
        return this.f20812a + ".nullSafe()";
    }
}
