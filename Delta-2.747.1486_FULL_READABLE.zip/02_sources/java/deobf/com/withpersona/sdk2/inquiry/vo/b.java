package deobf.com.withpersona.sdk2.inquiry.vo;

import com.github.luben.zstd.BuildConfig;
import kotlin.Metadata;
import org.jetbrains.annotations.NotNull;

@Metadata(d1 = {"\u0000\u0016\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\bf\u0018\u00002\u00020\u0001J\u0017\u0010\u0005\u001a\u00020\u00042\u0006\u0010\u0003\u001a\u00020\u0002H&¢\u0006\u0004\b\u0005\u0010\u0006¨\u0006\u0007À\u0006\u0003"}, d2 = {"Lvo/b;", BuildConfig.FLAVOR, BuildConfig.FLAVOR, "newValue", "Lvo/j0;", "q", "(Z)Lvo/j0;", "government-id_release"}, k = 1, mv = {2, 2, 0}, xi = 48)
// dex: classes3.dex
public interface b {
    @NotNull
    j0 q(boolean newValue);
}
