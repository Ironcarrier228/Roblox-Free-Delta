package deobf.com.withpersona.sdk2.inquiry.un;

import android.content.Context;
import android.media.MediaRecorder;

// dex: classes3.dex
public final /* synthetic */ class p0 {
    public static /* synthetic */ MediaRecorder a(Context context) {
        return new MediaRecorder(context);
    }
}
