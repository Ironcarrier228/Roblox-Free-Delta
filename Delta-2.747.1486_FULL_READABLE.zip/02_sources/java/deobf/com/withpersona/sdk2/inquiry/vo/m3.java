package deobf.com.withpersona.sdk2.inquiry.vo;

// dex: classes3.dex
public final class m3 {

    public static int f34825a = -2029780954;
    public static int b = -2029780953;

    public static int f34826c = -2029780952;

    public static int f34827d = -2029780951;

    public static int f34828e = -2029780949;

    public static int f34829f = -2029780948;

    public static int f34830g = -2029780947;

    public static int f34831h = -2029780946;

    public static int f34832i = -2029780943;

    public static int f34833j = -2029780942;

    public static int f34834k = -2029780941;

    public static int f34835l = -2029780925;
}
