package deobf.com.withpersona.sdk2.inquiry.vo;

import com.withpersona.sdk2.inquiry.governmentid.RawExtraction;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;
import deobf.com.withpersona.sdk2.inquiry.sn.g;

@Metadata(d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\u001a\u0011\u0010\u0002\u001a\u00020\u0001*\u00020\u0000¢\u0006\u0004\b\u0002\u0010\u0003¨\u0006\u0004"}, d2 = {"Lsn/g;", "Lcom/withpersona/sdk2/inquiry/governmentid/RawExtraction;", deobf.android.view.xe.a.f36648e, "(Lsn/g;)Lcom/withpersona/sdk2/inquiry/governmentid/RawExtraction;", "government-id_release"}, k = 2, mv = {2, 2, 0}, xi = 48)
// dex: classes3.dex
public final class q3 {
    @NotNull
    public static final RawExtraction a(@NotNull deobf.com.withpersona.sdk2.inquiry.sn.g gVar) {
        Intrinsics.checkNotNullParameter(gVar, "<this>");
        if (gVar instanceof g.MrzBarcodeInfo) {
            return new RawExtraction("mrz", ((g.MrzBarcodeInfo) gVar).getExtractionRawPayload());
        }
        if (gVar instanceof g.Pdf417BarcodeInfo) {
            return new RawExtraction("pdf417", ((g.Pdf417BarcodeInfo) gVar).getExtractionRawPayload());
        }
        throw new deobf.com.withpersona.sdk2.inquiry.zt.l();
    }
}
