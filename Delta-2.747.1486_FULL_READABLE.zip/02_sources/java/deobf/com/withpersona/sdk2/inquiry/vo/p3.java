package deobf.com.withpersona.sdk2.inquiry.vo;

// dex: classes3.dex
public final class p3 {

    public static int f34947a = -2029453311;
    public static int b = -2029453293;

    public static int f34948c = -2029453287;

    public static int f34949d = -2029453267;

    public static int f34950e = -2029453266;

    public static int f34951f = -2029453265;
}
