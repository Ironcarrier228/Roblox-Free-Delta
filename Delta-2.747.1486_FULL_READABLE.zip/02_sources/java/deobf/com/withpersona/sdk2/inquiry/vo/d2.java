package deobf.com.withpersona.sdk2.inquiry.vo;

import android.content.Context;
import android.os.Parcel;
import android.os.Parcelable;
import com.github.luben.zstd.BuildConfig;
import com.google.mlkit.vision.barcode.common.Barcode;
import com.withpersona.sdk2.inquiry.governmentid.network.AutoClassifyWorker;
import com.withpersona.sdk2.inquiry.governmentid.video_capture.VideoCaptureConfig;
import com.withpersona.sdk2.inquiry.network.core.GenericFileUploadErrorResponse;
import com.withpersona.sdk2.inquiry.network.core.InternalErrorInfo;
import com.withpersona.sdk2.inquiry.network.dto.NextStep;
import com.withpersona.sdk2.inquiry.network.dto.PendingPageTextPosition;
import com.withpersona.sdk2.inquiry.network.dto.government_id.CaptureOptionNativeMobile;
import com.withpersona.sdk2.inquiry.network.dto.ui.components.RemoteImage;
import com.withpersona.sdk2.inquiry.network.dto.ui.components.Title;
import com.withpersona.sdk2.inquiry.network.dto.ui.styling.StepStyles;
import com.withpersona.sdk2.inquiry.network.dto.ui.styling.StyleElements;
import com.withpersona.sdk2.inquiry.tracking.TrackingEventsLogger;
import com.withpersona.sdk2.inquiry.tracking.model.GovIdCaptureButtonType;
import com.withpersona.sdk2.inquiry.tracking.model.GovIdCaptureState;
import com.withpersona.sdk2.inquiry.tracking.model.GovernmentIdButtonEventData;
import com.withpersona.sdk2.inquiry.tracking.model.GovernmentIdStateEventData;
import deobf.com.withpersona.sdk2.inquiry.dp.f;
import deobf.com.withpersona.sdk2.inquiry.dr.h;
import deobf.com.withpersona.sdk2.inquiry.dr.i;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import deobf.com.withpersona.sdk2.inquiry.ln.Snapshot;
import deobf.com.withpersona.sdk2.inquiry.ln.k;
import deobf.com.withpersona.sdk2.inquiry.ln.r;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import deobf.com.withpersona.sdk2.inquiry.rn.AlertContainerScreen;
import deobf.com.withpersona.sdk2.inquiry.vo.IdConfig;
import deobf.com.withpersona.sdk2.inquiry.vo.d2;
import deobf.com.withpersona.sdk2.inquiry.vo.f;
import deobf.com.withpersona.sdk2.inquiry.vo.i3;
import deobf.com.withpersona.sdk2.inquiry.vo.j;
import deobf.com.withpersona.sdk2.inquiry.vo.j0;
import deobf.com.withpersona.sdk2.inquiry.vo.n;
import deobf.com.withpersona.sdk2.inquiry.vo.y3;

@Metadata(d1 = {"\u0000Ì\u0001\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\r\n\u0002\u0018\u0002\n\u0002\b\"\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0004\u0018\u00002\u001a\u0012\u0004\u0012\u00020\u0002\u0012\u0004\u0012\u00020\u0003\u0012\u0004\u0012\u00020\u0004\u0012\u0004\u0012\u00020\u00050\u00012\u00020\u0005:\u0002VXBy\b\u0007\u0012\u0006\u0010\u0007\u001a\u00020\u0006\u0012\u0006\u0010\t\u001a\u00020\b\u0012\u0006\u0010\u000b\u001a\u00020\n\u0012\u0006\u0010\r\u001a\u00020\f\u0012\u0006\u0010\u000f\u001a\u00020\u000e\u0012\u0006\u0010\u0011\u001a\u00020\u0010\u0012\u0006\u0010\u0013\u001a\u00020\u0012\u0012\u0006\u0010\u0015\u001a\u00020\u0014\u0012\u0006\u0010\u0017\u001a\u00020\u0016\u0012\u0006\u0010\u0019\u001a\u00020\u0018\u0012\u0006\u0010\u001b\u001a\u00020\u001a\u0012\u0006\u0010\u001d\u001a\u00020\u001c\u0012\u0006\u0010\u001f\u001a\u00020\u001e\u0012\u0006\u0010!\u001a\u00020 ¢\u0006\u0004\b\"\u0010#JC\u0010(\u001a\u00020\u00052\u0006\u0010$\u001a\u00020\u00022\u0006\u0010%\u001a\u00020\u00032\"\u0010'\u001a\u001e0&R\u001a\u0012\u0004\u0012\u00020\u0002\u0012\u0004\u0012\u00020\u0003\u0012\u0004\u0012\u00020\u0004\u0012\u0004\u0012\u00020\u00050\u0001H\u0002¢\u0006\u0004\b(\u0010)J;\u0010,\u001a\u00020+2\"\u0010'\u001a\u001e0&R\u001a\u0012\u0004\u0012\u00020\u0002\u0012\u0004\u0012\u00020\u0003\u0012\u0004\u0012\u00020\u0004\u0012\u0004\u0012\u00020\u00050\u00012\u0006\u0010*\u001a\u00020\u0004H\u0002¢\u0006\u0004\b,\u0010-J-\u00101\u001a\u00020+2\u001c\u00100\u001a\u00180.R\u0014\u0012\u0004\u0012\u00020\u0002\u0012\u0004\u0012\u00020\u0003\u0012\u0004\u0012\u00020\u00040/H\u0002¢\u0006\u0004\b1\u00102J\u001b\u00104\u001a\u000203*\u00020\u00052\u0006\u0010%\u001a\u00020\u0003H\u0002¢\u0006\u0004\b4\u00105J!\u00109\u001a\b\u0012\u0004\u0012\u00020\u000508*\u00020\u00052\u0006\u00107\u001a\u000206H\u0002¢\u0006\u0004\b9\u0010:J\u0013\u0010<\u001a\u00020;*\u00020\u0003H\u0002¢\u0006\u0004\b<\u0010=J\u0015\u0010>\u001a\u0004\u0018\u000106*\u00020\u0003H\u0002¢\u0006\u0004\b>\u0010?J-\u0010E\u001a\u000206*\u00020@2\u0006\u0010B\u001a\u00020A2\u0006\u0010C\u001a\u0002062\b\u0010D\u001a\u0004\u0018\u000106H\u0002¢\u0006\u0004\bE\u0010FJ-\u0010G\u001a\u000206*\u00020@2\u0006\u0010B\u001a\u00020A2\u0006\u0010C\u001a\u0002062\b\u0010D\u001a\u0004\u0018\u000106H\u0002¢\u0006\u0004\bG\u0010FJ-\u0010H\u001a\u000206*\u00020@2\u0006\u0010B\u001a\u00020A2\u0006\u0010C\u001a\u0002062\b\u0010D\u001a\u0004\u0018\u000106H\u0002¢\u0006\u0004\bH\u0010FJ\u001b\u0010I\u001a\u000206*\u00020@2\u0006\u0010B\u001a\u00020AH\u0002¢\u0006\u0004\bI\u0010JJ\u001b\u0010K\u001a\u000206*\u00020@2\u0006\u0010B\u001a\u00020AH\u0002¢\u0006\u0004\bK\u0010JJ\u0017\u0010M\u001a\u00020;2\u0006\u0010L\u001a\u00020\u0003H\u0002¢\u0006\u0004\bM\u0010=J!\u0010Q\u001a\u00020\u00032\u0006\u0010N\u001a\u00020\u00022\b\u0010P\u001a\u0004\u0018\u00010OH\u0016¢\u0006\u0004\bQ\u0010RJC\u0010S\u001a\u00020\u00052\u0006\u0010$\u001a\u00020\u00022\u0006\u0010%\u001a\u00020\u00032\"\u0010'\u001a\u001e0&R\u001a\u0012\u0004\u0012\u00020\u0002\u0012\u0004\u0012\u00020\u0003\u0012\u0004\u0012\u00020\u0004\u0012\u0004\u0012\u00020\u00050\u0001H\u0016¢\u0006\u0004\bS\u0010)J\u0019\u0010T\u001a\u0004\u0018\u00010O2\u0006\u0010L\u001a\u00020\u0003H\u0016¢\u0006\u0004\bT\u0010UR\u0014\u0010\u0007\u001a\u00020\u00068\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\bV\u0010WR\u0014\u0010\t\u001a\u00020\b8\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\bX\u0010YR\u0014\u0010\u000b\u001a\u00020\n8\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\bZ\u0010[R\u0014\u0010\r\u001a\u00020\f8\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b\\\u0010]R\u0014\u0010\u000f\u001a\u00020\u000e8\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b^\u0010_R\u0014\u0010\u0011\u001a\u00020\u00108\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b`\u0010aR\u0014\u0010\u0013\u001a\u00020\u00128\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\bb\u0010cR\u0014\u0010\u0015\u001a\u00020\u00148\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\bd\u0010eR\u0014\u0010\u0017\u001a\u00020\u00168\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\bf\u0010gR\u0014\u0010\u0019\u001a\u00020\u00188\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\bh\u0010iR\u0014\u0010\u001b\u001a\u00020\u001a8\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\bj\u0010kR\u0014\u0010\u001d\u001a\u00020\u001c8\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\bl\u0010mR\u0014\u0010\u001f\u001a\u00020\u001e8\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\bn\u0010oR\u0014\u0010!\u001a\u00020 8\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\bp\u0010qR\u0014\u0010u\u001a\u00020r8\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\bs\u0010tR \u0010y\u001a\f\u0012\u0006\b\u0001\u0012\u00020\u0003\u0018\u00010v8\u0002@\u0002X\u0082\u000e¢\u0006\u0006\n\u0004\bw\u0010x¨\u0006z"}, d2 = {"Lvo/d2;", "Lln/k;", "Lvo/d2$a;", "Lvo/j0;", "Lvo/d2$b;", BuildConfig.FLAVOR, "Landroid/content/Context;", "applicationContext", "Ll6/s;", "imageLoader", "Ldp/f$a;", "submitVerificationWorkerFactory", "Lvo/j;", "documentSelectWorker", "Lip/j;", "localVideoCaptureRenderer", "Lip/v;", "webRtcRenderer", "Lyo/t0;", "captureRenderer", "Lcom/withpersona/sdk2/inquiry/governmentid/network/AutoClassifyWorker$b;", "autoClassifyWorkerFactory", "Lwo/o;", "autoClassificationRenderer", "Lyn/a;", "cameraStatsManager", "Lir/b;", "navigationStateManager", "Ldr/c;", "externalEventLogger", "Lcom/withpersona/sdk2/inquiry/tracking/TrackingEventsLogger;", "trackingEventsLogger", "Lgr/b;", "themeManager", "<init>", "(Landroid/content/Context;Ll6/s;Ldp/f$a;Lvo/j;Lip/j;Lip/v;Lyo/t0;Lcom/withpersona/sdk2/inquiry/governmentid/network/AutoClassifyWorker$b;Lwo/o;Lyn/a;Lir/b;Ldr/c;Lcom/withpersona/sdk2/inquiry/tracking/TrackingEventsLogger;Lgr/b;)V", "renderProps", "renderState", "Lln/k$a;", "context", "j0", "(Lvo/d2$a;Lvo/j0;Lln/k$a;)Ljava/lang/Object;", "output", BuildConfig.FLAVOR, "b1", "(Lln/k$a;Lvo/d2$b;)V", "Lln/r$c;", "Lln/r;", "updater", "c1", "(Lln/r$c;)V", "Lkr/m;", "f1", "(Ljava/lang/Object;Lvo/j0;)Lkr/m;", BuildConfig.FLAVOR, "name", "Lnn/m;", "h0", "(Ljava/lang/Object;Ljava/lang/String;)Lnn/m;", BuildConfig.FLAVOR, "e1", "(Lvo/j0;)Z", "e0", "(Lvo/j0;)Ljava/lang/String;", "Lvo/d2$a$b;", "Lvo/d3$e;", "side", "selectedId", "countryCode", "a0", "(Lvo/d2$a$b;Lvo/d3$e;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;", "Z", "b0", "d0", "(Lvo/d2$a$b;Lvo/d3$e;)Ljava/lang/String;", "c0", "state", "g0", "props", "Lln/i;", "snapshot", "f0", "(Lvo/d2$a;Lln/i;)Lvo/j0;", "i0", "d1", "(Lvo/j0;)Lln/i;", deobf.android.view.xe.a.f36648e, "Landroid/content/Context;", deobf.android.view.k6.b.f21144e, "Ll6/s;", "c", "Ldp/f$a;", "d", "Lvo/j;", "e", "Lip/j;", "f", "Lip/v;", "g", "Lyo/t0;", "h", "Lcom/withpersona/sdk2/inquiry/governmentid/network/AutoClassifyWorker$b;", "i", "Lwo/o;", "j", "Lyn/a;", "k", "Lir/b;", "l", "Ldr/c;", "m", "Lcom/withpersona/sdk2/inquiry/tracking/TrackingEventsLogger;", "n", "Lgr/b;", "Lip/l;", "o", "Lip/l;", "videoCaptureHelper", "Lxu/c;", "p", "Lxu/c;", "previousStateClass", "government-id_release"}, k = 1, mv = {2, 2, 0}, xi = 48)
// dex: classes3.dex
public final class d2 extends deobf.com.withpersona.sdk2.inquiry.ln.k<a, j0, b, Object> {

    @NotNull
    public final Context applicationContext;

    @NotNull
    public final deobf.com.roblox.client.l6.s imageLoader;

    @NotNull
    public final deobf.unlinked.f.a submitVerificationWorkerFactory;

    @NotNull
    public final j documentSelectWorker;

    @NotNull
    public final deobf.unlinked.ip.j localVideoCaptureRenderer;

    @NotNull
    public final deobf.unlinked.ip.v webRtcRenderer;

    @NotNull
    public final deobf.com.withpersona.sdk2.inquiry.yo.t0 captureRenderer;

    @NotNull
    public final AutoClassifyWorker.b autoClassifyWorkerFactory;

    @NotNull
    public final deobf.com.withpersona.sdk2.inquiry.wo.o autoClassificationRenderer;

    @NotNull
    public final deobf.unlinked.yn.a cameraStatsManager;

    @NotNull
    public final deobf.com.withpersona.sdk2.inquiry.ir.b navigationStateManager;

    @NotNull
    public final deobf.com.withpersona.sdk2.inquiry.dr.c externalEventLogger;

    @NotNull
    public final TrackingEventsLogger trackingEventsLogger;

    @NotNull
    public final deobf.com.withpersona.sdk2.inquiry.gr.b themeManager;

    @NotNull
    public final deobf.unlinked.ip.l videoCaptureHelper;

    @Nullable
    public deobf.kotlin.jvm.internal.xu.c<? extends j0> previousStateClass;

    @Metadata(d1 = {"\u0000\u008e\u0001\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0002\b\u0003\n\u0002\u0010\t\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0002\bF\b\u0007\u0018\u00002\u00020\u0001:\u0001>B\u008f\u0002\u0012\u0006\u0010\u0003\u001a\u00020\u0002\u0012\b\u0010\u0004\u001a\u0004\u0018\u00010\u0002\u0012\f\u0010\u0007\u001a\b\u0012\u0004\u0012\u00020\u00060\u0005\u0012\u0006\u0010\b\u001a\u00020\u0002\u0012\u0006\u0010\t\u001a\u00020\u0002\u0012\u0006\u0010\n\u001a\u00020\u0002\u0012\u0006\u0010\f\u001a\u00020\u000b\u0012\u0006\u0010\r\u001a\u00020\u000b\u0012\f\u0010\u000f\u001a\b\u0012\u0004\u0012\u00020\u000e0\u0005\u0012\b\u0010\u0011\u001a\u0004\u0018\u00010\u0010\u0012\u0006\u0010\u0013\u001a\u00020\u0012\u0012\u0006\u0010\u0015\u001a\u00020\u0014\u0012\u0006\u0010\u0016\u001a\u00020\u0002\u0012\u0006\u0010\u0017\u001a\u00020\u0002\u0012\u0006\u0010\u0019\u001a\u00020\u0018\u0012\u0006\u0010\u001a\u001a\u00020\u000b\u0012\n\b\u0001\u0010\u001b\u001a\u0004\u0018\u00010\u0014\u0012\u0006\u0010\u001d\u001a\u00020\u001c\u0012\u0006\u0010\u001f\u001a\u00020\u001e\u0012\u0006\u0010 \u001a\u00020\u000b\u0012\u0006\u0010\"\u001a\u00020!\u0012\u0006\u0010$\u001a\u00020#\u0012\u0006\u0010&\u001a\u00020%\u0012\b\u0010(\u001a\u0004\u0018\u00010'\u0012\u0006\u0010)\u001a\u00020\u000b\u0012\b\u0010*\u001a\u0004\u0018\u00010\u0014\u0012\u0006\u0010,\u001a\u00020+\u0012\n\b\u0002\u0010-\u001a\u0004\u0018\u00010\u0002\u0012\n\b\u0002\u0010/\u001a\u0004\u0018\u00010.¢\u0006\u0004\b0\u00101J\r\u00102\u001a\u00020\u0014¢\u0006\u0004\b2\u00103J\u001d\u00108\u001a\u0002072\u0006\u00105\u001a\u0002042\u0006\u00106\u001a\u00020\u0014¢\u0006\u0004\b8\u00109R\u0017\u0010\u0003\u001a\u00020\u00028\u0006¢\u0006\f\n\u0004\b:\u0010;\u001a\u0004\b<\u0010=R\u0019\u0010\u0004\u001a\u0004\u0018\u00010\u00028\u0006¢\u0006\f\n\u0004\b>\u0010;\u001a\u0004\b?\u0010=R\u001d\u0010\u0007\u001a\b\u0012\u0004\u0012\u00020\u00060\u00058\u0006¢\u0006\f\n\u0004\b@\u0010A\u001a\u0004\bB\u0010CR\u0017\u0010\b\u001a\u00020\u00028\u0006¢\u0006\f\n\u0004\bD\u0010;\u001a\u0004\bE\u0010=R\u0017\u0010\t\u001a\u00020\u00028\u0006¢\u0006\f\n\u0004\bF\u0010;\u001a\u0004\bG\u0010=R\u0017\u0010\n\u001a\u00020\u00028\u0006¢\u0006\f\n\u0004\bH\u0010;\u001a\u0004\bI\u0010=R\u0017\u0010\f\u001a\u00020\u000b8\u0006¢\u0006\f\n\u0004\bJ\u0010K\u001a\u0004\bJ\u0010LR\u0017\u0010\r\u001a\u00020\u000b8\u0006¢\u0006\f\n\u0004\bM\u0010K\u001a\u0004\bN\u0010LR\u001d\u0010\u000f\u001a\b\u0012\u0004\u0012\u00020\u000e0\u00058\u0006¢\u0006\f\n\u0004\bN\u0010A\u001a\u0004\bO\u0010CR\u0019\u0010\u0011\u001a\u0004\u0018\u00010\u00108\u0006¢\u0006\f\n\u0004\b?\u0010P\u001a\u0004\bQ\u0010RR\u0017\u0010\u0013\u001a\u00020\u00128\u0006¢\u0006\f\n\u0004\bS\u0010T\u001a\u0004\bU\u0010VR\u0017\u0010\u0015\u001a\u00020\u00148\u0006¢\u0006\f\n\u0004\bW\u0010X\u001a\u0004\bY\u00103R\u0017\u0010\u0016\u001a\u00020\u00028\u0006¢\u0006\f\n\u0004\bZ\u0010;\u001a\u0004\b[\u0010=R\u0017\u0010\u0017\u001a\u00020\u00028\u0006¢\u0006\f\n\u0004\bO\u0010;\u001a\u0004\b\\\u0010=R\u0017\u0010\u0019\u001a\u00020\u00188\u0006¢\u0006\f\n\u0004\bB\u0010]\u001a\u0004\b^\u0010_R\u0017\u0010\u001a\u001a\u00020\u000b8\u0006¢\u0006\f\n\u0004\b[\u0010K\u001a\u0004\b`\u0010LR\u0019\u0010\u001b\u001a\u0004\u0018\u00010\u00148\u0006¢\u0006\f\n\u0004\b\\\u0010a\u001a\u0004\bb\u0010cR\u0017\u0010\u001d\u001a\u00020\u001c8\u0006¢\u0006\f\n\u0004\bd\u0010e\u001a\u0004\bf\u0010gR\u0017\u0010\u001f\u001a\u00020\u001e8\u0006¢\u0006\f\n\u0004\bI\u0010h\u001a\u0004\b:\u0010iR\u0017\u0010 \u001a\u00020\u000b8\u0006¢\u0006\f\n\u0004\bG\u0010K\u001a\u0004\b \u0010LR\u0017\u0010\"\u001a\u00020!8\u0006¢\u0006\f\n\u0004\bj\u0010k\u001a\u0004\bH\u0010lR\u0017\u0010$\u001a\u00020#8\u0006¢\u0006\f\n\u0004\bm\u0010n\u001a\u0004\bo\u0010pR\u0017\u0010&\u001a\u00020%8\u0006¢\u0006\f\n\u0004\bY\u0010q\u001a\u0004\br\u0010sR\u0019\u0010(\u001a\u0004\u0018\u00010'8\u0006¢\u0006\f\n\u0004\bE\u0010t\u001a\u0004\bu\u0010vR\u0017\u0010)\u001a\u00020\u000b8\u0006¢\u0006\f\n\u0004\b^\u0010K\u001a\u0004\bw\u0010LR\u0019\u0010*\u001a\u0004\u0018\u00010\u00148\u0006¢\u0006\f\n\u0004\br\u0010a\u001a\u0004\bm\u0010cR\u0017\u0010,\u001a\u00020+8\u0006¢\u0006\f\n\u0004\b<\u0010x\u001a\u0004\bW\u0010yR\u0019\u0010-\u001a\u0004\u0018\u00010\u00028\u0006¢\u0006\f\n\u0004\bo\u0010;\u001a\u0004\bd\u0010=R\u0019\u0010/\u001a\u0004\u0018\u00010.8\u0006¢\u0006\f\n\u0004\b`\u0010z\u001a\u0004\bS\u0010{R\u0011\u0010|\u001a\u00020\u000b8F¢\u0006\u0006\u001a\u0004\bj\u0010L¨\u0006}"}, d2 = {"Lvo/d2$a;", "Landroid/os/Parcelable;", BuildConfig.FLAVOR, "sessionToken", "countryCode", BuildConfig.FLAVOR, "Lvo/d3;", "enabledIdClasses", "inquiryId", "fromStep", "fromComponent", BuildConfig.FLAVOR, "backStepEnabled", "cancelButtonEnabled", "Lcom/withpersona/sdk2/inquiry/network/dto/government_id/CaptureOptionNativeMobile;", "enabledCaptureOptionsNativeMobile", "Lcom/withpersona/sdk2/inquiry/network/dto/ui/styling/StepStyles$GovernmentIdStepStyle;", "styles", "Lvo/d2$a$b;", "strings", BuildConfig.FLAVOR, "imageCaptureCount", "fieldKeyDocument", "fieldKeyIdClass", BuildConfig.FLAVOR, "manualCaptureButtonDelayMs", "shouldSkipReviewScreen", "theme", "Lcom/withpersona/sdk2/inquiry/governmentid/video_capture/VideoCaptureConfig;", "videoCaptureConfig", "Lcom/withpersona/sdk2/inquiry/network/dto/NextStep$GovernmentId$AssetConfig;", "assetConfig", "isEnabled", "Lwo/a;", "autoClassificationConfig", "Lcom/withpersona/sdk2/inquiry/network/dto/ui/styling/StyleElements$Axis;", "reviewCaptureButtonsAxis", "Lcom/withpersona/sdk2/inquiry/network/dto/PendingPageTextPosition;", "pendingPageTextVerticalPosition", "Lbp/a;", "digitalIdConfig", "staticCaptureTipsEnabled", "holographicTorchEnabledDurationMs", "Lvo/i;", "designVersion", "flowWatermarkText", "Lor/b;", "customPendingPage", "<init>", "(Ljava/lang/String;Ljava/lang/String;Ljava/util/List;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ZZLjava/util/List;Lcom/withpersona/sdk2/inquiry/network/dto/ui/styling/StepStyles$GovernmentIdStepStyle;Lvo/d2$a$b;ILjava/lang/String;Ljava/lang/String;JZLjava/lang/Integer;Lcom/withpersona/sdk2/inquiry/governmentid/video_capture/VideoCaptureConfig;Lcom/withpersona/sdk2/inquiry/network/dto/NextStep$GovernmentId$AssetConfig;ZLwo/a;Lcom/withpersona/sdk2/inquiry/network/dto/ui/styling/StyleElements$Axis;Lcom/withpersona/sdk2/inquiry/network/dto/PendingPageTextPosition;Lbp/a;ZLjava/lang/Integer;Lvo/i;Ljava/lang/String;Lor/b;)V", "describeContents", "()I", "Landroid/os/Parcel;", "dest", "flags", BuildConfig.FLAVOR, "writeToParcel", "(Landroid/os/Parcel;I)V", deobf.android.view.xe.a.f36648e, "Ljava/lang/String;", "A", "()Ljava/lang/String;", deobf.android.view.k6.b.f21144e, "j", "c", "Ljava/util/List;", "o", "()Ljava/util/List;", "d", "x", "e", deobf.com.withpersona.sdk2.inquiry.pm.t.f29212d, "f", "s", "g", "Z", "()Z", "h", "i", "n", "Lcom/withpersona/sdk2/inquiry/network/dto/ui/styling/StepStyles$GovernmentIdStepStyle;", "G", "()Lcom/withpersona/sdk2/inquiry/network/dto/ui/styling/StepStyles$GovernmentIdStepStyle;", "k", "Lvo/d2$a$b;", "F", "()Lvo/d2$a$b;", "l", "I", "w", "m", "p", "q", "J", "y", "()J", "C", "Ljava/lang/Integer;", "getTheme", "()Ljava/lang/Integer;", "r", "Lcom/withpersona/sdk2/inquiry/governmentid/video_capture/VideoCaptureConfig;", "H", "()Lcom/withpersona/sdk2/inquiry/governmentid/video_capture/VideoCaptureConfig;", "Lcom/withpersona/sdk2/inquiry/network/dto/NextStep$GovernmentId$AssetConfig;", "()Lcom/withpersona/sdk2/inquiry/network/dto/NextStep$GovernmentId$AssetConfig;", "u", "Lwo/a;", "()Lwo/a;", "v", "Lcom/withpersona/sdk2/inquiry/network/dto/ui/styling/StyleElements$Axis;", "B", "()Lcom/withpersona/sdk2/inquiry/network/dto/ui/styling/StyleElements$Axis;", "Lcom/withpersona/sdk2/inquiry/network/dto/PendingPageTextPosition;", "z", "()Lcom/withpersona/sdk2/inquiry/network/dto/PendingPageTextPosition;", "Lbp/a;", "getDigitalIdConfig", "()Lbp/a;", "D", "Lvo/i;", "()Lvo/i;", "Lor/b;", "()Lor/b;", "hasMultipleCaptureOptions", "government-id_release"}, k = 1, mv = {2, 2, 0}, xi = 48)
    public static final class a implements Parcelable {

        @NotNull
        public static final Parcelable.Creator<a> CREATOR = new C0706a();

        @NotNull
        public final i designVersion;

        @Nullable
        public final String flowWatermarkText;

        @Nullable
        public final deobf.com.withpersona.sdk2.inquiry.or.b customPendingPage;

        @NotNull
        public final String sessionToken;

        @Nullable
        public final String countryCode;

        @NotNull
        public final List<IdConfig> enabledIdClasses;

        @NotNull
        public final String inquiryId;

        @NotNull
        public final String fromStep;

        @NotNull
        public final String fromComponent;

        public final boolean backStepEnabled;

        public final boolean cancelButtonEnabled;

        @NotNull
        public final List<CaptureOptionNativeMobile> enabledCaptureOptionsNativeMobile;

        @Nullable
        public final StepStyles.GovernmentIdStepStyle styles;

        @NotNull
        public final Strings strings;

        public final int imageCaptureCount;

        @NotNull
        public final String fieldKeyDocument;

        @NotNull
        public final String fieldKeyIdClass;

        public final long manualCaptureButtonDelayMs;

        public final boolean shouldSkipReviewScreen;

        @Nullable
        public final Integer theme;

        @NotNull
        public final VideoCaptureConfig videoCaptureConfig;

        @NotNull
        public final NextStep.GovernmentId.AssetConfig assetConfig;

        public final boolean isEnabled;

        @NotNull
        public final deobf.com.withpersona.sdk2.inquiry.wo.a autoClassificationConfig;

        @NotNull
        public final StyleElements.Axis reviewCaptureButtonsAxis;

        @NotNull
        public final PendingPageTextPosition pendingPageTextVerticalPosition;

        @Nullable
        public final deobf.unlinked.bp.a digitalIdConfig;

        public final boolean staticCaptureTipsEnabled;

        @Nullable
        public final Integer holographicTorchEnabledDurationMs;

        @Metadata(k = 3, mv = {2, 2, 0}, xi = 48)
        public static final class C0706a implements Parcelable.Creator<a> {
            @Override // android.os.Parcelable.Creator
            public final a createFromParcel(Parcel parcel) {
                boolean z10;
                Class cls;
                boolean z11;
                deobf.com.withpersona.sdk2.inquiry.wo.a aVar;
                deobf.unlinked.bp.a createFromParcel;
                Intrinsics.checkNotNullParameter(parcel, "parcel");
                String readString = parcel.readString();
                String readString2 = parcel.readString();
                int readInt = parcel.readInt();
                ArrayList arrayList = new ArrayList(readInt);
                for (int i10 = 0; i10 != readInt; i10++) {
                    arrayList.add(IdConfig.CREATOR.createFromParcel(parcel));
                }
                String readString3 = parcel.readString();
                String readString4 = parcel.readString();
                String readString5 = parcel.readString();
                boolean z12 = true;
                if (parcel.readInt() != 0) {
                    z10 = true;
                } else {
                    z10 = true;
                    z12 = false;
                }
                boolean z13 = parcel.readInt() != 0 ? z10 : false;
                int readInt2 = parcel.readInt();
                ArrayList arrayList2 = new ArrayList(readInt2);
                for (int i11 = 0; i11 != readInt2; i11++) {
                    arrayList2.add(CaptureOptionNativeMobile.valueOf(parcel.readString()));
                }
                StepStyles.GovernmentIdStepStyle governmentIdStepStyle = (StepStyles.GovernmentIdStepStyle) parcel.readParcelable(a.class.getClassLoader());
                Strings createFromParcel2 = Strings.CREATOR.createFromParcel(parcel);
                int readInt3 = parcel.readInt();
                String readString6 = parcel.readString();
                String readString7 = parcel.readString();
                long readLong = parcel.readLong();
                if (parcel.readInt() != 0) {
                    cls = a.class;
                    z11 = z10;
                } else {
                    cls = a.class;
                    z11 = false;
                }
                Integer valueOf = parcel.readInt() == 0 ? null : Integer.valueOf(parcel.readInt());
                VideoCaptureConfig createFromParcel3 = VideoCaptureConfig.CREATOR.createFromParcel(parcel);
                NextStep.GovernmentId.AssetConfig assetConfig = (NextStep.GovernmentId.AssetConfig) parcel.readParcelable(cls.getClassLoader());
                boolean z14 = parcel.readInt() != 0;
                deobf.com.withpersona.sdk2.inquiry.wo.a createFromParcel4 = deobf.com.withpersona.sdk2.inquiry.wo.a.CREATOR.createFromParcel(parcel);
                StyleElements.Axis valueOf2 = StyleElements.Axis.valueOf(parcel.readString());
                PendingPageTextPosition valueOf3 = PendingPageTextPosition.valueOf(parcel.readString());
                if (parcel.readInt() == 0) {
                    aVar = createFromParcel4;
                    createFromParcel = null;
                } else {
                    aVar = createFromParcel4;
                    createFromParcel = deobf.unlinked.bp.a.CREATOR.createFromParcel(parcel);
                }
                return new a(readString, readString2, arrayList, readString3, readString4, readString5, z12, z13, arrayList2, governmentIdStepStyle, createFromParcel2, readInt3, readString6, readString7, readLong, z11, valueOf, createFromParcel3, assetConfig, z14, aVar, valueOf2, valueOf3, createFromParcel, parcel.readInt() != 0, parcel.readInt() != 0 ? Integer.valueOf(parcel.readInt()) : null, i.valueOf(parcel.readString()), parcel.readString(), (deobf.com.withpersona.sdk2.inquiry.or.b) parcel.readParcelable(cls.getClassLoader()));
            }

            @Override // android.os.Parcelable.Creator
            public final a[] newArray(int i10) {
                return new a[i10];
            }
        }

        @Metadata(d1 = {"\u0000Z\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u000e\n\u0002\b\u000b\n\u0002\u0018\u0002\n\u0002\b\u000b\n\u0002\u0010$\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b&\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0002\b\u0005\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000b\n\u0002\b_\b\u0087\b\u0018\u00002\u00020\u0001B\u0095\u0005\u0012\u0006\u0010\u0003\u001a\u00020\u0002\u0012\u0006\u0010\u0004\u001a\u00020\u0002\u0012\u0006\u0010\u0005\u001a\u00020\u0002\u0012\u0006\u0010\u0006\u001a\u00020\u0002\u0012\b\u0010\u0007\u001a\u0004\u0018\u00010\u0002\u0012\b\u0010\b\u001a\u0004\u0018\u00010\u0002\u0012\b\u0010\t\u001a\u0004\u0018\u00010\u0002\u0012\b\u0010\n\u001a\u0004\u0018\u00010\u0002\u0012\b\u0010\u000b\u001a\u0004\u0018\u00010\u0002\u0012\b\u0010\f\u001a\u0004\u0018\u00010\u0002\u0012\b\u0010\r\u001a\u0004\u0018\u00010\u0002\u0012\u0006\u0010\u000f\u001a\u00020\u000e\u0012\u0006\u0010\u0010\u001a\u00020\u000e\u0012\u0006\u0010\u0011\u001a\u00020\u000e\u0012\u0006\u0010\u0012\u001a\u00020\u0002\u0012\u0006\u0010\u0013\u001a\u00020\u000e\u0012\u0006\u0010\u0014\u001a\u00020\u0002\u0012\u0006\u0010\u0015\u001a\u00020\u0002\u0012\u0006\u0010\u0016\u001a\u00020\u0002\u0012\u0006\u0010\u0017\u001a\u00020\u000e\u0012\u0006\u0010\u0018\u001a\u00020\u0002\u0012\u0006\u0010\u0019\u001a\u00020\u0002\u0012\u0012\u0010\u001b\u001a\u000e\u0012\u0004\u0012\u00020\u0002\u0012\u0004\u0012\u00020\u00020\u001a\u0012\u0006\u0010\u001c\u001a\u00020\u000e\u0012\u0006\u0010\u001d\u001a\u00020\u000e\u0012\u0006\u0010\u001e\u001a\u00020\u0002\u0012\u0006\u0010\u001f\u001a\u00020\u0002\u0012\u0012\u0010!\u001a\u000e\u0012\u0004\u0012\u00020 \u0012\u0004\u0012\u00020\u00020\u001a\u0012\u0012\u0010\"\u001a\u000e\u0012\u0004\u0012\u00020 \u0012\u0004\u0012\u00020\u00020\u001a\u0012\u0006\u0010#\u001a\u00020\u0002\u0012\u0006\u0010$\u001a\u00020\u0002\u0012\b\u0010%\u001a\u0004\u0018\u00010\u0002\u0012\b\u0010&\u001a\u0004\u0018\u00010\u0002\u0012\b\u0010'\u001a\u0004\u0018\u00010\u0002\u0012\b\u0010(\u001a\u0004\u0018\u00010\u0002\u0012\b\u0010)\u001a\u0004\u0018\u00010\u0002\u0012\b\u0010*\u001a\u0004\u0018\u00010\u0002\u0012\b\u0010+\u001a\u0004\u0018\u00010\u0002\u0012\b\u0010,\u001a\u0004\u0018\u00010\u0002\u0012\b\u0010-\u001a\u0004\u0018\u00010\u0002\u0012\b\u0010.\u001a\u0004\u0018\u00010\u0002\u0012\b\u0010/\u001a\u0004\u0018\u00010\u0002\u0012\b\u00100\u001a\u0004\u0018\u00010\u0002\u0012\b\u00101\u001a\u0004\u0018\u00010\u0002\u0012\b\u00102\u001a\u0004\u0018\u00010\u0002\u0012\b\u00103\u001a\u0004\u0018\u00010\u0002\u0012\b\u00104\u001a\u0004\u0018\u00010\u0002\u0012\b\u00105\u001a\u0004\u0018\u00010\u0002\u0012\b\u00106\u001a\u0004\u0018\u00010\u0002\u0012\b\u00107\u001a\u0004\u0018\u00010\u0002\u0012\b\u00108\u001a\u0004\u0018\u00010\u0002\u0012\b\u00109\u001a\u0004\u0018\u00010\u0002\u0012\b\u0010:\u001a\u0004\u0018\u00010\u0002\u0012\b\u0010;\u001a\u0004\u0018\u00010\u0002\u0012\b\u0010<\u001a\u0004\u0018\u00010\u0002\u0012\b\u0010=\u001a\u0004\u0018\u00010\u0002\u0012\b\u0010>\u001a\u0004\u0018\u00010\u0002\u0012\b\u0010?\u001a\u0004\u0018\u00010\u0002\u0012\b\u0010@\u001a\u0004\u0018\u00010\u0002\u0012\b\u0010A\u001a\u0004\u0018\u00010\u0002\u0012\b\u0010B\u001a\u0004\u0018\u00010\u0002\u0012\b\u0010C\u001a\u0004\u0018\u00010\u0002\u0012\b\u0010D\u001a\u0004\u0018\u00010\u0002\u0012\b\u0010E\u001a\u0004\u0018\u00010\u0002\u0012\b\u0010F\u001a\u0004\u0018\u00010\u0002\u0012\u000e\u0010I\u001a\n\u0012\u0004\u0012\u00020H\u0018\u00010G¢\u0006\u0004\bJ\u0010KJ\r\u0010M\u001a\u00020L¢\u0006\u0004\bM\u0010NJ\u001d\u0010S\u001a\u00020R2\u0006\u0010P\u001a\u00020O2\u0006\u0010Q\u001a\u00020L¢\u0006\u0004\bS\u0010TJ\u0010\u0010U\u001a\u00020\u0002HÖ\u0001¢\u0006\u0004\bU\u0010VJ\u0010\u0010W\u001a\u00020LHÖ\u0001¢\u0006\u0004\bW\u0010NJ\u001a\u0010[\u001a\u00020Z2\b\u0010Y\u001a\u0004\u0018\u00010XHÖ\u0003¢\u0006\u0004\b[\u0010\\R\u0017\u0010\u0003\u001a\u00020\u00028\u0006¢\u0006\f\n\u0004\b]\u0010^\u001a\u0004\b_\u0010VR\u0017\u0010\u0004\u001a\u00020\u00028\u0006¢\u0006\f\n\u0004\b`\u0010^\u001a\u0004\ba\u0010VR\u0017\u0010\u0005\u001a\u00020\u00028\u0006¢\u0006\f\n\u0004\bb\u0010^\u001a\u0004\bc\u0010VR\u0017\u0010\u0006\u001a\u00020\u00028\u0006¢\u0006\f\n\u0004\bd\u0010^\u001a\u0004\be\u0010VR\u0019\u0010\u0007\u001a\u0004\u0018\u00010\u00028\u0006¢\u0006\f\n\u0004\bf\u0010^\u001a\u0004\bg\u0010VR\u0019\u0010\b\u001a\u0004\u0018\u00010\u00028\u0006¢\u0006\f\n\u0004\bh\u0010^\u001a\u0004\bi\u0010VR\u0019\u0010\t\u001a\u0004\u0018\u00010\u00028\u0006¢\u0006\f\n\u0004\bj\u0010^\u001a\u0004\bk\u0010VR\u0019\u0010\n\u001a\u0004\u0018\u00010\u00028\u0006¢\u0006\f\n\u0004\bl\u0010^\u001a\u0004\bm\u0010VR\u0019\u0010\u000b\u001a\u0004\u0018\u00010\u00028\u0006¢\u0006\f\n\u0004\bn\u0010^\u001a\u0004\bo\u0010VR\u0019\u0010\f\u001a\u0004\u0018\u00010\u00028\u0006¢\u0006\f\n\u0004\bp\u0010^\u001a\u0004\bq\u0010VR\u0019\u0010\r\u001a\u0004\u0018\u00010\u00028\u0006¢\u0006\f\n\u0004\br\u0010^\u001a\u0004\bh\u0010VR\u0017\u0010\u000f\u001a\u00020\u000e8\u0006¢\u0006\f\n\u0004\bs\u0010t\u001a\u0004\bu\u0010vR\u0017\u0010\u0010\u001a\u00020\u000e8\u0006¢\u0006\f\n\u0004\bw\u0010t\u001a\u0004\bx\u0010vR\u0017\u0010\u0011\u001a\u00020\u000e8\u0006¢\u0006\f\n\u0004\by\u0010t\u001a\u0004\bz\u0010vR\u0017\u0010\u0012\u001a\u00020\u00028\u0006¢\u0006\f\n\u0004\b{\u0010^\u001a\u0004\b|\u0010VR\u0017\u0010\u0013\u001a\u00020\u000e8\u0006¢\u0006\f\n\u0004\b}\u0010t\u001a\u0004\b~\u0010vR\u0018\u0010\u0014\u001a\u00020\u00028\u0006¢\u0006\r\n\u0004\b\u007f\u0010^\u001a\u0005\b\u0080\u0001\u0010VR\u0018\u0010\u0015\u001a\u00020\u00028\u0006¢\u0006\r\n\u0005\b\u0081\u0001\u0010^\u001a\u0004\by\u0010VR\u0018\u0010\u0016\u001a\u00020\u00028\u0006¢\u0006\r\n\u0005\b\u0080\u0001\u0010^\u001a\u0004\bs\u0010VR\u0018\u0010\u0017\u001a\u00020\u000e8\u0006¢\u0006\r\n\u0004\bi\u0010t\u001a\u0005\b\u0082\u0001\u0010vR\u0018\u0010\u0018\u001a\u00020\u00028\u0006¢\u0006\r\n\u0004\bx\u0010^\u001a\u0005\b\u0083\u0001\u0010VR\u0018\u0010\u0019\u001a\u00020\u00028\u0006¢\u0006\r\n\u0004\bu\u0010^\u001a\u0005\b\u0084\u0001\u0010VR&\u0010\u001b\u001a\u000e\u0012\u0004\u0012\u00020\u0002\u0012\u0004\u0012\u00020\u00020\u001a8\u0006¢\u0006\u000f\n\u0005\b|\u0010\u0085\u0001\u001a\u0006\b\u0086\u0001\u0010\u0087\u0001R\u0018\u0010\u001c\u001a\u00020\u000e8\u0006¢\u0006\r\n\u0004\bk\u0010t\u001a\u0005\b\u0088\u0001\u0010vR\u0018\u0010\u001d\u001a\u00020\u000e8\u0006¢\u0006\r\n\u0004\bc\u0010t\u001a\u0005\b\u0089\u0001\u0010vR\u0019\u0010\u001e\u001a\u00020\u00028\u0006¢\u0006\u000e\n\u0005\b\u0089\u0001\u0010^\u001a\u0005\b\u008a\u0001\u0010VR\u0019\u0010\u001f\u001a\u00020\u00028\u0006¢\u0006\u000e\n\u0005\b\u008b\u0001\u0010^\u001a\u0005\b\u008c\u0001\u0010VR'\u0010!\u001a\u000e\u0012\u0004\u0012\u00020 \u0012\u0004\u0012\u00020\u00020\u001a8\u0006¢\u0006\u0010\n\u0006\b\u008a\u0001\u0010\u0085\u0001\u001a\u0006\b\u008d\u0001\u0010\u0087\u0001R'\u0010\"\u001a\u000e\u0012\u0004\u0012\u00020 \u0012\u0004\u0012\u00020\u00020\u001a8\u0006¢\u0006\u0010\n\u0006\b\u0088\u0001\u0010\u0085\u0001\u001a\u0006\b\u008e\u0001\u0010\u0087\u0001R\u0019\u0010#\u001a\u00020\u00028\u0006¢\u0006\u000e\n\u0005\b\u008c\u0001\u0010^\u001a\u0005\b\u008f\u0001\u0010VR\u0019\u0010$\u001a\u00020\u00028\u0006¢\u0006\u000e\n\u0005\b\u0090\u0001\u0010^\u001a\u0005\b\u0091\u0001\u0010VR\u001a\u0010%\u001a\u0004\u0018\u00010\u00028\u0006¢\u0006\r\n\u0004\b~\u0010^\u001a\u0005\b\u0081\u0001\u0010VR\u001a\u0010&\u001a\u0004\u0018\u00010\u00028\u0006¢\u0006\r\n\u0005\b\u0082\u0001\u0010^\u001a\u0004\b\u007f\u0010VR\u001a\u0010'\u001a\u0004\u0018\u00010\u00028\u0006¢\u0006\r\n\u0005\b\u0092\u0001\u0010^\u001a\u0004\b{\u0010VR\u001a\u0010(\u001a\u0004\u0018\u00010\u00028\u0006¢\u0006\r\n\u0005\b\u0093\u0001\u0010^\u001a\u0004\b}\u0010VR\u001b\u0010)\u001a\u0004\u0018\u00010\u00028\u0006¢\u0006\u000e\n\u0005\b\u0094\u0001\u0010^\u001a\u0005\b\u0095\u0001\u0010VR\u001b\u0010*\u001a\u0004\u0018\u00010\u00028\u0006¢\u0006\u000e\n\u0005\b\u0096\u0001\u0010^\u001a\u0005\b\u0097\u0001\u0010VR\u001b\u0010+\u001a\u0004\u0018\u00010\u00028\u0006¢\u0006\u000e\n\u0005\b\u0098\u0001\u0010^\u001a\u0005\b\u0099\u0001\u0010VR\u001b\u0010,\u001a\u0004\u0018\u00010\u00028\u0006¢\u0006\u000e\n\u0005\b\u009a\u0001\u0010^\u001a\u0005\b\u009b\u0001\u0010VR\u001b\u0010-\u001a\u0004\u0018\u00010\u00028\u0006¢\u0006\u000e\n\u0005\b\u009c\u0001\u0010^\u001a\u0005\b\u0098\u0001\u0010VR\u001b\u0010.\u001a\u0004\u0018\u00010\u00028\u0006¢\u0006\u000e\n\u0005\b\u009d\u0001\u0010^\u001a\u0005\b\u009a\u0001\u0010VR\u001b\u0010/\u001a\u0004\u0018\u00010\u00028\u0006¢\u0006\u000e\n\u0005\b\u009e\u0001\u0010^\u001a\u0005\b\u0094\u0001\u0010VR\u001a\u00100\u001a\u0004\u0018\u00010\u00028\u0006¢\u0006\r\n\u0005\b\u009f\u0001\u0010^\u001a\u0004\br\u0010VR\u001a\u00101\u001a\u0004\u0018\u00010\u00028\u0006¢\u0006\r\n\u0005\b \u0001\u0010^\u001a\u0004\bp\u0010VR\u001a\u00102\u001a\u0004\u0018\u00010\u00028\u0006¢\u0006\r\n\u0005\b¡\u0001\u0010^\u001a\u0004\bn\u0010VR\u001a\u00103\u001a\u0004\u0018\u00010\u00028\u0006¢\u0006\r\n\u0005\b¢\u0001\u0010^\u001a\u0004\bj\u0010VR\u001b\u00104\u001a\u0004\u0018\u00010\u00028\u0006¢\u0006\u000e\n\u0005\b£\u0001\u0010^\u001a\u0005\b¤\u0001\u0010VR\u001b\u00105\u001a\u0004\u0018\u00010\u00028\u0006¢\u0006\u000e\n\u0005\b\u0086\u0001\u0010^\u001a\u0005\b¥\u0001\u0010VR\u001b\u00106\u001a\u0004\u0018\u00010\u00028\u0006¢\u0006\u000e\n\u0005\b¦\u0001\u0010^\u001a\u0005\b§\u0001\u0010VR\u001b\u00107\u001a\u0004\u0018\u00010\u00028\u0006¢\u0006\u000e\n\u0005\b§\u0001\u0010^\u001a\u0005\b¦\u0001\u0010VR\u001b\u00108\u001a\u0004\u0018\u00010\u00028\u0006¢\u0006\u000e\n\u0005\b¥\u0001\u0010^\u001a\u0005\b \u0001\u0010VR\u001b\u00109\u001a\u0004\u0018\u00010\u00028\u0006¢\u0006\u000e\n\u0005\b¤\u0001\u0010^\u001a\u0005\b\u009e\u0001\u0010VR\u001a\u0010:\u001a\u0004\u0018\u00010\u00028\u0006¢\u0006\r\n\u0004\be\u0010^\u001a\u0005\b\u009d\u0001\u0010VR\u001b\u0010;\u001a\u0004\u0018\u00010\u00028\u0006¢\u0006\u000e\n\u0005\b¨\u0001\u0010^\u001a\u0005\b\u009c\u0001\u0010VR\u001b\u0010<\u001a\u0004\u0018\u00010\u00028\u0006¢\u0006\u000e\n\u0005\b©\u0001\u0010^\u001a\u0005\bª\u0001\u0010VR\u001b\u0010=\u001a\u0004\u0018\u00010\u00028\u0006¢\u0006\u000e\n\u0005\b«\u0001\u0010^\u001a\u0005\b¬\u0001\u0010VR\u001b\u0010>\u001a\u0004\u0018\u00010\u00028\u0006¢\u0006\u000e\n\u0005\b\u00ad\u0001\u0010^\u001a\u0005\b®\u0001\u0010VR\u001b\u0010?\u001a\u0004\u0018\u00010\u00028\u0006¢\u0006\u000e\n\u0005\b¯\u0001\u0010^\u001a\u0005\b°\u0001\u0010VR\u001b\u0010@\u001a\u0004\u0018\u00010\u00028\u0006¢\u0006\u000e\n\u0005\b±\u0001\u0010^\u001a\u0005\b£\u0001\u0010VR\u001b\u0010A\u001a\u0004\u0018\u00010\u00028\u0006¢\u0006\u000e\n\u0005\b²\u0001\u0010^\u001a\u0005\b¢\u0001\u0010VR\u001b\u0010B\u001a\u0004\u0018\u00010\u00028\u0006¢\u0006\u000e\n\u0005\b³\u0001\u0010^\u001a\u0005\b\u0092\u0001\u0010VR\u001b\u0010C\u001a\u0004\u0018\u00010\u00028\u0006¢\u0006\u000e\n\u0005\b´\u0001\u0010^\u001a\u0005\b¡\u0001\u0010VR\u001b\u0010D\u001a\u0004\u0018\u00010\u00028\u0006¢\u0006\u000e\n\u0005\bµ\u0001\u0010^\u001a\u0005\b´\u0001\u0010VR\u001b\u0010E\u001a\u0004\u0018\u00010\u00028\u0006¢\u0006\u000e\n\u0005\b\u0099\u0001\u0010^\u001a\u0005\b±\u0001\u0010VR\u001a\u0010F\u001a\u0004\u0018\u00010\u00028\u0006¢\u0006\r\n\u0005\b\u009b\u0001\u0010^\u001a\u0004\b]\u0010VR#\u0010I\u001a\n\u0012\u0004\u0012\u00020H\u0018\u00010G8\u0006¢\u0006\u0010\n\u0006\b¶\u0001\u0010·\u0001\u001a\u0006\b¯\u0001\u0010¸\u0001¨\u0006¹\u0001"}, d2 = {"Lvo/d2$a$b;", "Landroid/os/Parcelable;", BuildConfig.FLAVOR, Title.type, "prompt", "choose", "instructionsDisclaimer", "selectPageNavBarTitle", "capturePageNavBarTitle", "checkPageNavBarTitle", "pendingPageNavBarTitle", "requestPageNavBarTitle", "reviewUploadPageNavBarTitle", "autoClassificationPageNavBarTitle", "Lvo/k3;", "captureScreenTitle", "captureScreenDescription", "scanInstructions", "capturing", "confirmCapture", "captureDisclaimer", "buttonSubmit", "buttonRetake", "confirmCaptureTitle", "processingTitle", "processingDescription", BuildConfig.FLAVOR, "idClassToName", "chooseCaptureMethodTitle", "chooseCaptureMethodBody", "chooseCaptureMethodCameraButton", "chooseCaptureMethodUploadButton", "Lvo/d3$e;", "reviewSelectedImageTitle", "reviewSelectedImageBody", "reviewSelectedImageConfirmButton", "reviewSelectedImageChooseAnotherButton", "cameraPermissionsTitle", "cameraPermissionsPrompt", "cameraPermissionsAllowButtonText", "cameraPermissionsCancelButtonText", "microphonePermissionsTitle", "microphonePermissionsPrompt", "microphonePermissionsAllowButtonText", "microphonePermissionsCancelButtonText", "hintHoldStill", "hintLowLight", "helpButtonText", "barcodeHelpModalTitle", "barcodeHelpModalPrompt", "barcodeHelpModalHints", "barcodeHelpModalContinueButtonText", "idFrontHelpModalTitle", "idFrontHelpModalPrompt", "idFrontHelpModalHints", "idFrontHelpModalContinueButtonText", "idBackHelpModalTitle", "idBackHelpModalPrompt", "idBackHelpModalHints", "idBackHelpModalContinueButtonText", "staticCaptureTipsTitle", "staticCaptureTipsSubtext", "unableToClassifyDocumentTitle", "unableToClassifyDocumentContinueButtonText", "idClassRejectedTitle", "idClassRejectedContinueButtonText", "countryInputTitle", "idClassInputTitle", "manualClassificationTitle", "manualClassificationContinueButtonText", "autoClassificationCaptureTipText", BuildConfig.FLAVOR, "Lcom/withpersona/sdk2/inquiry/network/dto/NextStep$GovernmentId$LocalizationOverride;", "localizationOverrides", "<init>", "(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lvo/k3;Lvo/k3;Lvo/k3;Ljava/lang/String;Lvo/k3;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lvo/k3;Ljava/lang/String;Ljava/lang/String;Ljava/util/Map;Lvo/k3;Lvo/k3;Ljava/lang/String;Ljava/lang/String;Ljava/util/Map;Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/util/List;)V", BuildConfig.FLAVOR, "describeContents", "()I", "Landroid/os/Parcel;", "dest", "flags", BuildConfig.FLAVOR, "writeToParcel", "(Landroid/os/Parcel;I)V", "toString", "()Ljava/lang/String;", "hashCode", BuildConfig.FLAVOR, "other", BuildConfig.FLAVOR, "equals", "(Ljava/lang/Object;)Z", deobf.android.view.xe.a.f36648e, "Ljava/lang/String;", "getTitle", deobf.android.view.k6.b.f21144e, "u0", "c", "y", "d", "a0", "e", "H0", "f", deobf.com.withpersona.sdk2.inquiry.pm.t.f29212d, "g", "x", "h", "q0", "i", "v0", "j", "C0", "k", "l", "Lvo/k3;", "v", "()Lvo/k3;", "m", "u", "n", "D0", "o", "w", "p", "F", "q", "s", "r", "G", "t0", "r0", "Ljava/util/Map;", "V", "()Ljava/util/Map;", "C", "z", "B", "A", "D", "B0", "w0", "y0", "E", "x0", "H", "I", "J", "p0", "K", "o0", "L", "l0", "M", "m0", "N", "O", "P", "Q", "R", "S", "T", "U", "Z", "Y", "W", "X", "b0", "c0", "L0", "d0", "J0", "e0", "b1", "f0", "N0", "g0", "h0", "i0", "j0", "k0", "n0", "Ljava/util/List;", "()Ljava/util/List;", "government-id_release"}, k = 1, mv = {2, 2, 0}, xi = 48)
        public static final /* data */ class Strings implements Parcelable {

            @NotNull
            public static final Parcelable.Creator<Strings> CREATOR = new C0707a();

            @NotNull
            public final String chooseCaptureMethodUploadButton;

            @NotNull
            public final Map<IdConfig.e, String> reviewSelectedImageTitle;

            @NotNull
            public final Map<IdConfig.e, String> reviewSelectedImageBody;

            @NotNull
            public final String reviewSelectedImageConfirmButton;

            @NotNull
            public final String reviewSelectedImageChooseAnotherButton;

            @Nullable
            public final String cameraPermissionsTitle;

            @Nullable
            public final String cameraPermissionsPrompt;

            @Nullable
            public final String cameraPermissionsAllowButtonText;

            @Nullable
            public final String cameraPermissionsCancelButtonText;

            @Nullable
            public final String microphonePermissionsTitle;

            @Nullable
            public final String microphonePermissionsPrompt;

            @Nullable
            public final String microphonePermissionsAllowButtonText;

            @Nullable
            public final String microphonePermissionsCancelButtonText;

            @Nullable
            public final String hintHoldStill;

            @Nullable
            public final String hintLowLight;

            @Nullable
            public final String helpButtonText;

            @Nullable
            public final String barcodeHelpModalTitle;

            @Nullable
            public final String barcodeHelpModalPrompt;

            @Nullable
            public final String barcodeHelpModalHints;

            @Nullable
            public final String barcodeHelpModalContinueButtonText;

            @Nullable
            public final String idFrontHelpModalTitle;

            @Nullable
            public final String idFrontHelpModalPrompt;

            @Nullable
            public final String idFrontHelpModalHints;

            @Nullable
            public final String idFrontHelpModalContinueButtonText;

            @Nullable
            public final String idBackHelpModalTitle;

            @Nullable
            public final String idBackHelpModalPrompt;

            @NotNull
            public final String title;

            @Nullable
            public final String idBackHelpModalHints;

            @NotNull
            public final String prompt;

            @Nullable
            public final String idBackHelpModalContinueButtonText;

            @NotNull
            public final String choose;

            @Nullable
            public final String staticCaptureTipsTitle;

            @NotNull
            public final String instructionsDisclaimer;

            @Nullable
            public final String staticCaptureTipsSubtext;

            @Nullable
            public final String selectPageNavBarTitle;

            @Nullable
            public final String unableToClassifyDocumentTitle;

            @Nullable
            public final String capturePageNavBarTitle;

            @Nullable
            public final String unableToClassifyDocumentContinueButtonText;

            @Nullable
            public final String checkPageNavBarTitle;

            @Nullable
            public final String idClassRejectedTitle;

            @Nullable
            public final String pendingPageNavBarTitle;

            @Nullable
            public final String idClassRejectedContinueButtonText;

            @Nullable
            public final String requestPageNavBarTitle;

            @Nullable
            public final String countryInputTitle;

            @Nullable
            public final String reviewUploadPageNavBarTitle;

            @Nullable
            public final String idClassInputTitle;

            @Nullable
            public final String autoClassificationPageNavBarTitle;

            @Nullable
            public final String manualClassificationTitle;

            @NotNull
            public final OverridableText captureScreenTitle;

            @Nullable
            public final String manualClassificationContinueButtonText;

            @NotNull
            public final OverridableText captureScreenDescription;

            @Nullable
            public final String autoClassificationCaptureTipText;

            @NotNull
            public final OverridableText scanInstructions;

            @Nullable
            public final List<NextStep.GovernmentId.LocalizationOverride> localizationOverrides;

            @NotNull
            public final String capturing;

            @NotNull
            public final OverridableText confirmCapture;

            @NotNull
            public final String captureDisclaimer;

            @NotNull
            public final String buttonSubmit;

            @NotNull
            public final String buttonRetake;

            @NotNull
            public final OverridableText confirmCaptureTitle;

            @NotNull
            public final String processingTitle;

            @NotNull
            public final String processingDescription;

            @NotNull
            public final Map<String, String> idClassToName;

            @NotNull
            public final OverridableText chooseCaptureMethodTitle;

            @NotNull
            public final OverridableText chooseCaptureMethodBody;

            @NotNull
            public final String chooseCaptureMethodCameraButton;

            @Metadata(k = 3, mv = {2, 2, 0}, xi = 48)
            public static final class C0707a implements Parcelable.Creator<Strings> {
                @Override // android.os.Parcelable.Creator
                public final Strings createFromParcel(Parcel parcel) {
                    String str;
                    LinkedHashMap linkedHashMap;
                    ArrayList arrayList;
                    Intrinsics.checkNotNullParameter(parcel, "parcel");
                    String readString = parcel.readString();
                    String readString2 = parcel.readString();
                    String readString3 = parcel.readString();
                    String readString4 = parcel.readString();
                    String readString5 = parcel.readString();
                    String readString6 = parcel.readString();
                    String readString7 = parcel.readString();
                    String readString8 = parcel.readString();
                    String readString9 = parcel.readString();
                    String readString10 = parcel.readString();
                    String readString11 = parcel.readString();
                    Parcelable.Creator<OverridableText> creator = OverridableText.CREATOR;
                    OverridableText createFromParcel = creator.createFromParcel(parcel);
                    OverridableText createFromParcel2 = creator.createFromParcel(parcel);
                    OverridableText createFromParcel3 = creator.createFromParcel(parcel);
                    String readString12 = parcel.readString();
                    OverridableText createFromParcel4 = creator.createFromParcel(parcel);
                    String readString13 = parcel.readString();
                    String readString14 = parcel.readString();
                    String readString15 = parcel.readString();
                    OverridableText createFromParcel5 = creator.createFromParcel(parcel);
                    String readString16 = parcel.readString();
                    String readString17 = parcel.readString();
                    int readInt = parcel.readInt();
                    LinkedHashMap linkedHashMap2 = new LinkedHashMap(readInt);
                    int i10 = 0;
                    while (i10 != readInt) {
                        linkedHashMap2.put(parcel.readString(), parcel.readString());
                        i10++;
                        readInt = readInt;
                    }
                    Parcelable.Creator<OverridableText> creator2 = OverridableText.CREATOR;
                    OverridableText createFromParcel6 = creator2.createFromParcel(parcel);
                    OverridableText createFromParcel7 = creator2.createFromParcel(parcel);
                    String readString18 = parcel.readString();
                    String readString19 = parcel.readString();
                    int readInt2 = parcel.readInt();
                    LinkedHashMap linkedHashMap3 = new LinkedHashMap(readInt2);
                    int i11 = 0;
                    while (i11 != readInt2) {
                        linkedHashMap3.put(IdConfig.e.valueOf(parcel.readString()), parcel.readString());
                        i11++;
                        readInt2 = readInt2;
                    }
                    int readInt3 = parcel.readInt();
                    LinkedHashMap linkedHashMap4 = new LinkedHashMap(readInt3);
                    int i12 = 0;
                    while (i12 != readInt3) {
                        linkedHashMap4.put(IdConfig.e.valueOf(parcel.readString()), parcel.readString());
                        i12++;
                        readInt3 = readInt3;
                    }
                    String readString20 = parcel.readString();
                    String readString21 = parcel.readString();
                    String readString22 = parcel.readString();
                    String readString23 = parcel.readString();
                    String readString24 = parcel.readString();
                    String readString25 = parcel.readString();
                    String readString26 = parcel.readString();
                    String readString27 = parcel.readString();
                    String readString28 = parcel.readString();
                    String readString29 = parcel.readString();
                    String readString30 = parcel.readString();
                    String readString31 = parcel.readString();
                    String readString32 = parcel.readString();
                    String readString33 = parcel.readString();
                    String readString34 = parcel.readString();
                    String readString35 = parcel.readString();
                    String readString36 = parcel.readString();
                    String readString37 = parcel.readString();
                    String readString38 = parcel.readString();
                    String readString39 = parcel.readString();
                    String readString40 = parcel.readString();
                    String readString41 = parcel.readString();
                    String readString42 = parcel.readString();
                    String readString43 = parcel.readString();
                    String readString44 = parcel.readString();
                    String readString45 = parcel.readString();
                    String readString46 = parcel.readString();
                    String readString47 = parcel.readString();
                    String readString48 = parcel.readString();
                    String readString49 = parcel.readString();
                    String readString50 = parcel.readString();
                    String readString51 = parcel.readString();
                    String readString52 = parcel.readString();
                    String readString53 = parcel.readString();
                    String readString54 = parcel.readString();
                    String readString55 = parcel.readString();
                    if (parcel.readInt() == 0) {
                        arrayList = null;
                        str = readString20;
                        linkedHashMap = linkedHashMap4;
                    } else {
                        int readInt4 = parcel.readInt();
                        str = readString20;
                        ArrayList arrayList2 = new ArrayList(readInt4);
                        linkedHashMap = linkedHashMap4;
                        int i13 = 0;
                        while (i13 != readInt4) {
                            arrayList2.add(parcel.readParcelable(Strings.class.getClassLoader()));
                            i13++;
                            readInt4 = readInt4;
                        }
                        arrayList = arrayList2;
                    }
                    return new Strings(readString, readString2, readString3, readString4, readString5, readString6, readString7, readString8, readString9, readString10, readString11, createFromParcel, createFromParcel2, createFromParcel3, readString12, createFromParcel4, readString13, readString14, readString15, createFromParcel5, readString16, readString17, linkedHashMap2, createFromParcel6, createFromParcel7, readString18, readString19, linkedHashMap3, linkedHashMap, str, readString21, readString22, readString23, readString24, readString25, readString26, readString27, readString28, readString29, readString30, readString31, readString32, readString33, readString34, readString35, readString36, readString37, readString38, readString39, readString40, readString41, readString42, readString43, readString44, readString45, readString46, readString47, readString48, readString49, readString50, readString51, readString52, readString53, readString54, readString55, arrayList);
                }

                @Override // android.os.Parcelable.Creator
                public final Strings[] newArray(int i10) {
                    return new Strings[i10];
                }
            }

            public Strings(@NotNull String title, @NotNull String prompt, @NotNull String choose, @NotNull String instructionsDisclaimer, @Nullable String str, @Nullable String str2, @Nullable String str3, @Nullable String str4, @Nullable String str5, @Nullable String str6, @Nullable String str7, @NotNull OverridableText captureScreenTitle, @NotNull OverridableText captureScreenDescription, @NotNull OverridableText scanInstructions, @NotNull String capturing, @NotNull OverridableText confirmCapture, @NotNull String captureDisclaimer, @NotNull String buttonSubmit, @NotNull String buttonRetake, @NotNull OverridableText confirmCaptureTitle, @NotNull String processingTitle, @NotNull String processingDescription, @NotNull Map<String, String> idClassToName, @NotNull OverridableText chooseCaptureMethodTitle, @NotNull OverridableText chooseCaptureMethodBody, @NotNull String chooseCaptureMethodCameraButton, @NotNull String chooseCaptureMethodUploadButton, @NotNull Map<IdConfig.e, String> reviewSelectedImageTitle, @NotNull Map<IdConfig.e, String> reviewSelectedImageBody, @NotNull String reviewSelectedImageConfirmButton, @NotNull String reviewSelectedImageChooseAnotherButton, @Nullable String str8, @Nullable String str9, @Nullable String str10, @Nullable String str11, @Nullable String str12, @Nullable String str13, @Nullable String str14, @Nullable String str15, @Nullable String str16, @Nullable String str17, @Nullable String str18, @Nullable String str19, @Nullable String str20, @Nullable String str21, @Nullable String str22, @Nullable String str23, @Nullable String str24, @Nullable String str25, @Nullable String str26, @Nullable String str27, @Nullable String str28, @Nullable String str29, @Nullable String str30, @Nullable String str31, @Nullable String str32, @Nullable String str33, @Nullable String str34, @Nullable String str35, @Nullable String str36, @Nullable String str37, @Nullable String str38, @Nullable String str39, @Nullable String str40, @Nullable String str41, @Nullable List<NextStep.GovernmentId.LocalizationOverride> list) {
                Intrinsics.checkNotNullParameter(title, "title");
                Intrinsics.checkNotNullParameter(prompt, "prompt");
                Intrinsics.checkNotNullParameter(choose, "choose");
                Intrinsics.checkNotNullParameter(instructionsDisclaimer, "instructionsDisclaimer");
                Intrinsics.checkNotNullParameter(captureScreenTitle, "captureScreenTitle");
                Intrinsics.checkNotNullParameter(captureScreenDescription, "captureScreenDescription");
                Intrinsics.checkNotNullParameter(scanInstructions, "scanInstructions");
                Intrinsics.checkNotNullParameter(capturing, "capturing");
                Intrinsics.checkNotNullParameter(confirmCapture, "confirmCapture");
                Intrinsics.checkNotNullParameter(captureDisclaimer, "captureDisclaimer");
                Intrinsics.checkNotNullParameter(buttonSubmit, "buttonSubmit");
                Intrinsics.checkNotNullParameter(buttonRetake, "buttonRetake");
                Intrinsics.checkNotNullParameter(confirmCaptureTitle, "confirmCaptureTitle");
                Intrinsics.checkNotNullParameter(processingTitle, "processingTitle");
                Intrinsics.checkNotNullParameter(processingDescription, "processingDescription");
                Intrinsics.checkNotNullParameter(idClassToName, "idClassToName");
                Intrinsics.checkNotNullParameter(chooseCaptureMethodTitle, "chooseCaptureMethodTitle");
                Intrinsics.checkNotNullParameter(chooseCaptureMethodBody, "chooseCaptureMethodBody");
                Intrinsics.checkNotNullParameter(chooseCaptureMethodCameraButton, "chooseCaptureMethodCameraButton");
                Intrinsics.checkNotNullParameter(chooseCaptureMethodUploadButton, "chooseCaptureMethodUploadButton");
                Intrinsics.checkNotNullParameter(reviewSelectedImageTitle, "reviewSelectedImageTitle");
                Intrinsics.checkNotNullParameter(reviewSelectedImageBody, "reviewSelectedImageBody");
                Intrinsics.checkNotNullParameter(reviewSelectedImageConfirmButton, "reviewSelectedImageConfirmButton");
                Intrinsics.checkNotNullParameter(reviewSelectedImageChooseAnotherButton, "reviewSelectedImageChooseAnotherButton");
                this.title = title;
                this.prompt = prompt;
                this.choose = choose;
                this.instructionsDisclaimer = instructionsDisclaimer;
                this.selectPageNavBarTitle = str;
                this.capturePageNavBarTitle = str2;
                this.checkPageNavBarTitle = str3;
                this.pendingPageNavBarTitle = str4;
                this.requestPageNavBarTitle = str5;
                this.reviewUploadPageNavBarTitle = str6;
                this.autoClassificationPageNavBarTitle = str7;
                this.captureScreenTitle = captureScreenTitle;
                this.captureScreenDescription = captureScreenDescription;
                this.scanInstructions = scanInstructions;
                this.capturing = capturing;
                this.confirmCapture = confirmCapture;
                this.captureDisclaimer = captureDisclaimer;
                this.buttonSubmit = buttonSubmit;
                this.buttonRetake = buttonRetake;
                this.confirmCaptureTitle = confirmCaptureTitle;
                this.processingTitle = processingTitle;
                this.processingDescription = processingDescription;
                this.idClassToName = idClassToName;
                this.chooseCaptureMethodTitle = chooseCaptureMethodTitle;
                this.chooseCaptureMethodBody = chooseCaptureMethodBody;
                this.chooseCaptureMethodCameraButton = chooseCaptureMethodCameraButton;
                this.chooseCaptureMethodUploadButton = chooseCaptureMethodUploadButton;
                this.reviewSelectedImageTitle = reviewSelectedImageTitle;
                this.reviewSelectedImageBody = reviewSelectedImageBody;
                this.reviewSelectedImageConfirmButton = reviewSelectedImageConfirmButton;
                this.reviewSelectedImageChooseAnotherButton = reviewSelectedImageChooseAnotherButton;
                this.cameraPermissionsTitle = str8;
                this.cameraPermissionsPrompt = str9;
                this.cameraPermissionsAllowButtonText = str10;
                this.cameraPermissionsCancelButtonText = str11;
                this.microphonePermissionsTitle = str12;
                this.microphonePermissionsPrompt = str13;
                this.microphonePermissionsAllowButtonText = str14;
                this.microphonePermissionsCancelButtonText = str15;
                this.hintHoldStill = str16;
                this.hintLowLight = str17;
                this.helpButtonText = str18;
                this.barcodeHelpModalTitle = str19;
                this.barcodeHelpModalPrompt = str20;
                this.barcodeHelpModalHints = str21;
                this.barcodeHelpModalContinueButtonText = str22;
                this.idFrontHelpModalTitle = str23;
                this.idFrontHelpModalPrompt = str24;
                this.idFrontHelpModalHints = str25;
                this.idFrontHelpModalContinueButtonText = str26;
                this.idBackHelpModalTitle = str27;
                this.idBackHelpModalPrompt = str28;
                this.idBackHelpModalHints = str29;
                this.idBackHelpModalContinueButtonText = str30;
                this.staticCaptureTipsTitle = str31;
                this.staticCaptureTipsSubtext = str32;
                this.unableToClassifyDocumentTitle = str33;
                this.unableToClassifyDocumentContinueButtonText = str34;
                this.idClassRejectedTitle = str35;
                this.idClassRejectedContinueButtonText = str36;
                this.countryInputTitle = str37;
                this.idClassInputTitle = str38;
                this.manualClassificationTitle = str39;
                this.manualClassificationContinueButtonText = str40;
                this.autoClassificationCaptureTipText = str41;
                this.localizationOverrides = list;
            }

            @NotNull
            public final String getChooseCaptureMethodCameraButton() {
                return this.chooseCaptureMethodCameraButton;
            }

            @NotNull
            public final Map<IdConfig.e, String> B0() {
                return this.reviewSelectedImageTitle;
            }

            @NotNull
            public final OverridableText getChooseCaptureMethodTitle() {
                return this.chooseCaptureMethodTitle;
            }

            @Nullable
            public final String getReviewUploadPageNavBarTitle() {
                return this.reviewUploadPageNavBarTitle;
            }

            @NotNull
            public final String getChooseCaptureMethodUploadButton() {
                return this.chooseCaptureMethodUploadButton;
            }

            @NotNull
            public final OverridableText getScanInstructions() {
                return this.scanInstructions;
            }

            @NotNull
            public final OverridableText getConfirmCapture() {
                return this.confirmCapture;
            }

            @NotNull
            public final OverridableText getConfirmCaptureTitle() {
                return this.confirmCaptureTitle;
            }

            @Nullable
            public final String getCountryInputTitle() {
                return this.countryInputTitle;
            }

            @Nullable
            public final String getSelectPageNavBarTitle() {
                return this.selectPageNavBarTitle;
            }

            @Nullable
            public final String getHelpButtonText() {
                return this.helpButtonText;
            }

            @Nullable
            public final String getStaticCaptureTipsSubtext() {
                return this.staticCaptureTipsSubtext;
            }

            @Nullable
            public final String getHintHoldStill() {
                return this.hintHoldStill;
            }

            @Nullable
            public final String getStaticCaptureTipsTitle() {
                return this.staticCaptureTipsTitle;
            }

            @Nullable
            public final String getHintLowLight() {
                return this.hintLowLight;
            }

            @Nullable
            public final String getIdBackHelpModalContinueButtonText() {
                return this.idBackHelpModalContinueButtonText;
            }

            @Nullable
            public final String getUnableToClassifyDocumentContinueButtonText() {
                return this.unableToClassifyDocumentContinueButtonText;
            }

            @Nullable
            public final String getIdBackHelpModalHints() {
                return this.idBackHelpModalHints;
            }

            @Nullable
            public final String getIdBackHelpModalPrompt() {
                return this.idBackHelpModalPrompt;
            }

            @Nullable
            public final String getIdBackHelpModalTitle() {
                return this.idBackHelpModalTitle;
            }

            @Nullable
            public final String getIdClassInputTitle() {
                return this.idClassInputTitle;
            }

            @Nullable
            public final String getIdClassRejectedContinueButtonText() {
                return this.idClassRejectedContinueButtonText;
            }

            @Nullable
            public final String getIdClassRejectedTitle() {
                return this.idClassRejectedTitle;
            }

            @NotNull
            public final Map<String, String> V() {
                return this.idClassToName;
            }

            @Nullable
            public final String getIdFrontHelpModalContinueButtonText() {
                return this.idFrontHelpModalContinueButtonText;
            }

            @Nullable
            public final String getIdFrontHelpModalHints() {
                return this.idFrontHelpModalHints;
            }

            @Nullable
            public final String getIdFrontHelpModalPrompt() {
                return this.idFrontHelpModalPrompt;
            }

            @Nullable
            public final String getIdFrontHelpModalTitle() {
                return this.idFrontHelpModalTitle;
            }

            @Nullable
            public final String getAutoClassificationCaptureTipText() {
                return this.autoClassificationCaptureTipText;
            }

            @NotNull
            public final String getInstructionsDisclaimer() {
                return this.instructionsDisclaimer;
            }

            @Nullable
            public final String getUnableToClassifyDocumentTitle() {
                return this.unableToClassifyDocumentTitle;
            }

            @Override // android.os.Parcelable
            public final int describeContents() {
                return 0;
            }

            public boolean equals(@Nullable Object other) {
                if (this == other) {
                    return true;
                }
                if (!(other instanceof Strings)) {
                    return false;
                }
                Strings strings = (Strings) other;
                return Intrinsics.c(this.title, strings.title) && Intrinsics.c(this.prompt, strings.prompt) && Intrinsics.c(this.choose, strings.choose) && Intrinsics.c(this.instructionsDisclaimer, strings.instructionsDisclaimer) && Intrinsics.c(this.selectPageNavBarTitle, strings.selectPageNavBarTitle) && Intrinsics.c(this.capturePageNavBarTitle, strings.capturePageNavBarTitle) && Intrinsics.c(this.checkPageNavBarTitle, strings.checkPageNavBarTitle) && Intrinsics.c(this.pendingPageNavBarTitle, strings.pendingPageNavBarTitle) && Intrinsics.c(this.requestPageNavBarTitle, strings.requestPageNavBarTitle) && Intrinsics.c(this.reviewUploadPageNavBarTitle, strings.reviewUploadPageNavBarTitle) && Intrinsics.c(this.autoClassificationPageNavBarTitle, strings.autoClassificationPageNavBarTitle) && Intrinsics.c(this.captureScreenTitle, strings.captureScreenTitle) && Intrinsics.c(this.captureScreenDescription, strings.captureScreenDescription) && Intrinsics.c(this.scanInstructions, strings.scanInstructions) && Intrinsics.c(this.capturing, strings.capturing) && Intrinsics.c(this.confirmCapture, strings.confirmCapture) && Intrinsics.c(this.captureDisclaimer, strings.captureDisclaimer) && Intrinsics.c(this.buttonSubmit, strings.buttonSubmit) && Intrinsics.c(this.buttonRetake, strings.buttonRetake) && Intrinsics.c(this.confirmCaptureTitle, strings.confirmCaptureTitle) && Intrinsics.c(this.processingTitle, strings.processingTitle) && Intrinsics.c(this.processingDescription, strings.processingDescription) && Intrinsics.c(this.idClassToName, strings.idClassToName) && Intrinsics.c(this.chooseCaptureMethodTitle, strings.chooseCaptureMethodTitle) && Intrinsics.c(this.chooseCaptureMethodBody, strings.chooseCaptureMethodBody) && Intrinsics.c(this.chooseCaptureMethodCameraButton, strings.chooseCaptureMethodCameraButton) && Intrinsics.c(this.chooseCaptureMethodUploadButton, strings.chooseCaptureMethodUploadButton) && Intrinsics.c(this.reviewSelectedImageTitle, strings.reviewSelectedImageTitle) && Intrinsics.c(this.reviewSelectedImageBody, strings.reviewSelectedImageBody) && Intrinsics.c(this.reviewSelectedImageConfirmButton, strings.reviewSelectedImageConfirmButton) && Intrinsics.c(this.reviewSelectedImageChooseAnotherButton, strings.reviewSelectedImageChooseAnotherButton) && Intrinsics.c(this.cameraPermissionsTitle, strings.cameraPermissionsTitle) && Intrinsics.c(this.cameraPermissionsPrompt, strings.cameraPermissionsPrompt) && Intrinsics.c(this.cameraPermissionsAllowButtonText, strings.cameraPermissionsAllowButtonText) && Intrinsics.c(this.cameraPermissionsCancelButtonText, strings.cameraPermissionsCancelButtonText) && Intrinsics.c(this.microphonePermissionsTitle, strings.microphonePermissionsTitle) && Intrinsics.c(this.microphonePermissionsPrompt, strings.microphonePermissionsPrompt) && Intrinsics.c(this.microphonePermissionsAllowButtonText, strings.microphonePermissionsAllowButtonText) && Intrinsics.c(this.microphonePermissionsCancelButtonText, strings.microphonePermissionsCancelButtonText) && Intrinsics.c(this.hintHoldStill, strings.hintHoldStill) && Intrinsics.c(this.hintLowLight, strings.hintLowLight) && Intrinsics.c(this.helpButtonText, strings.helpButtonText) && Intrinsics.c(this.barcodeHelpModalTitle, strings.barcodeHelpModalTitle) && Intrinsics.c(this.barcodeHelpModalPrompt, strings.barcodeHelpModalPrompt) && Intrinsics.c(this.barcodeHelpModalHints, strings.barcodeHelpModalHints) && Intrinsics.c(this.barcodeHelpModalContinueButtonText, strings.barcodeHelpModalContinueButtonText) && Intrinsics.c(this.idFrontHelpModalTitle, strings.idFrontHelpModalTitle) && Intrinsics.c(this.idFrontHelpModalPrompt, strings.idFrontHelpModalPrompt) && Intrinsics.c(this.idFrontHelpModalHints, strings.idFrontHelpModalHints) && Intrinsics.c(this.idFrontHelpModalContinueButtonText, strings.idFrontHelpModalContinueButtonText) && Intrinsics.c(this.idBackHelpModalTitle, strings.idBackHelpModalTitle) && Intrinsics.c(this.idBackHelpModalPrompt, strings.idBackHelpModalPrompt) && Intrinsics.c(this.idBackHelpModalHints, strings.idBackHelpModalHints) && Intrinsics.c(this.idBackHelpModalContinueButtonText, strings.idBackHelpModalContinueButtonText) && Intrinsics.c(this.staticCaptureTipsTitle, strings.staticCaptureTipsTitle) && Intrinsics.c(this.staticCaptureTipsSubtext, strings.staticCaptureTipsSubtext) && Intrinsics.c(this.unableToClassifyDocumentTitle, strings.unableToClassifyDocumentTitle) && Intrinsics.c(this.unableToClassifyDocumentContinueButtonText, strings.unableToClassifyDocumentContinueButtonText) && Intrinsics.c(this.idClassRejectedTitle, strings.idClassRejectedTitle) && Intrinsics.c(this.idClassRejectedContinueButtonText, strings.idClassRejectedContinueButtonText) && Intrinsics.c(this.countryInputTitle, strings.countryInputTitle) && Intrinsics.c(this.idClassInputTitle, strings.idClassInputTitle) && Intrinsics.c(this.manualClassificationTitle, strings.manualClassificationTitle) && Intrinsics.c(this.manualClassificationContinueButtonText, strings.manualClassificationContinueButtonText) && Intrinsics.c(this.autoClassificationCaptureTipText, strings.autoClassificationCaptureTipText) && Intrinsics.c(this.localizationOverrides, strings.localizationOverrides);
            }

            @Nullable
            public final String getAutoClassificationPageNavBarTitle() {
                return this.autoClassificationPageNavBarTitle;
            }

            @Nullable
            public final List<NextStep.GovernmentId.LocalizationOverride> f0() {
                return this.localizationOverrides;
            }

            @Nullable
            public final String getBarcodeHelpModalContinueButtonText() {
                return this.barcodeHelpModalContinueButtonText;
            }

            @Nullable
            public final String getManualClassificationContinueButtonText() {
                return this.manualClassificationContinueButtonText;
            }

            @NotNull
            public final String getTitle() {
                return this.title;
            }

            public int hashCode() {
                int hashCode = ((((((this.title.hashCode() * 31) + this.prompt.hashCode()) * 31) + this.choose.hashCode()) * 31) + this.instructionsDisclaimer.hashCode()) * 31;
                String str = this.selectPageNavBarTitle;
                int hashCode2 = (hashCode + (str == null ? 0 : str.hashCode())) * 31;
                String str2 = this.capturePageNavBarTitle;
                int hashCode3 = (hashCode2 + (str2 == null ? 0 : str2.hashCode())) * 31;
                String str3 = this.checkPageNavBarTitle;
                int hashCode4 = (hashCode3 + (str3 == null ? 0 : str3.hashCode())) * 31;
                String str4 = this.pendingPageNavBarTitle;
                int hashCode5 = (hashCode4 + (str4 == null ? 0 : str4.hashCode())) * 31;
                String str5 = this.requestPageNavBarTitle;
                int hashCode6 = (hashCode5 + (str5 == null ? 0 : str5.hashCode())) * 31;
                String str6 = this.reviewUploadPageNavBarTitle;
                int hashCode7 = (hashCode6 + (str6 == null ? 0 : str6.hashCode())) * 31;
                String str7 = this.autoClassificationPageNavBarTitle;
                int hashCode8 = (((((((((((((((((((((((((((((((((((((((((hashCode7 + (str7 == null ? 0 : str7.hashCode())) * 31) + this.captureScreenTitle.hashCode()) * 31) + this.captureScreenDescription.hashCode()) * 31) + this.scanInstructions.hashCode()) * 31) + this.capturing.hashCode()) * 31) + this.confirmCapture.hashCode()) * 31) + this.captureDisclaimer.hashCode()) * 31) + this.buttonSubmit.hashCode()) * 31) + this.buttonRetake.hashCode()) * 31) + this.confirmCaptureTitle.hashCode()) * 31) + this.processingTitle.hashCode()) * 31) + this.processingDescription.hashCode()) * 31) + this.idClassToName.hashCode()) * 31) + this.chooseCaptureMethodTitle.hashCode()) * 31) + this.chooseCaptureMethodBody.hashCode()) * 31) + this.chooseCaptureMethodCameraButton.hashCode()) * 31) + this.chooseCaptureMethodUploadButton.hashCode()) * 31) + this.reviewSelectedImageTitle.hashCode()) * 31) + this.reviewSelectedImageBody.hashCode()) * 31) + this.reviewSelectedImageConfirmButton.hashCode()) * 31) + this.reviewSelectedImageChooseAnotherButton.hashCode()) * 31;
                String str8 = this.cameraPermissionsTitle;
                int hashCode9 = (hashCode8 + (str8 == null ? 0 : str8.hashCode())) * 31;
                String str9 = this.cameraPermissionsPrompt;
                int hashCode10 = (hashCode9 + (str9 == null ? 0 : str9.hashCode())) * 31;
                String str10 = this.cameraPermissionsAllowButtonText;
                int hashCode11 = (hashCode10 + (str10 == null ? 0 : str10.hashCode())) * 31;
                String str11 = this.cameraPermissionsCancelButtonText;
                int hashCode12 = (hashCode11 + (str11 == null ? 0 : str11.hashCode())) * 31;
                String str12 = this.microphonePermissionsTitle;
                int hashCode13 = (hashCode12 + (str12 == null ? 0 : str12.hashCode())) * 31;
                String str13 = this.microphonePermissionsPrompt;
                int hashCode14 = (hashCode13 + (str13 == null ? 0 : str13.hashCode())) * 31;
                String str14 = this.microphonePermissionsAllowButtonText;
                int hashCode15 = (hashCode14 + (str14 == null ? 0 : str14.hashCode())) * 31;
                String str15 = this.microphonePermissionsCancelButtonText;
                int hashCode16 = (hashCode15 + (str15 == null ? 0 : str15.hashCode())) * 31;
                String str16 = this.hintHoldStill;
                int hashCode17 = (hashCode16 + (str16 == null ? 0 : str16.hashCode())) * 31;
                String str17 = this.hintLowLight;
                int hashCode18 = (hashCode17 + (str17 == null ? 0 : str17.hashCode())) * 31;
                String str18 = this.helpButtonText;
                int hashCode19 = (hashCode18 + (str18 == null ? 0 : str18.hashCode())) * 31;
                String str19 = this.barcodeHelpModalTitle;
                int hashCode20 = (hashCode19 + (str19 == null ? 0 : str19.hashCode())) * 31;
                String str20 = this.barcodeHelpModalPrompt;
                int hashCode21 = (hashCode20 + (str20 == null ? 0 : str20.hashCode())) * 31;
                String str21 = this.barcodeHelpModalHints;
                int hashCode22 = (hashCode21 + (str21 == null ? 0 : str21.hashCode())) * 31;
                String str22 = this.barcodeHelpModalContinueButtonText;
                int hashCode23 = (hashCode22 + (str22 == null ? 0 : str22.hashCode())) * 31;
                String str23 = this.idFrontHelpModalTitle;
                int hashCode24 = (hashCode23 + (str23 == null ? 0 : str23.hashCode())) * 31;
                String str24 = this.idFrontHelpModalPrompt;
                int hashCode25 = (hashCode24 + (str24 == null ? 0 : str24.hashCode())) * 31;
                String str25 = this.idFrontHelpModalHints;
                int hashCode26 = (hashCode25 + (str25 == null ? 0 : str25.hashCode())) * 31;
                String str26 = this.idFrontHelpModalContinueButtonText;
                int hashCode27 = (hashCode26 + (str26 == null ? 0 : str26.hashCode())) * 31;
                String str27 = this.idBackHelpModalTitle;
                int hashCode28 = (hashCode27 + (str27 == null ? 0 : str27.hashCode())) * 31;
                String str28 = this.idBackHelpModalPrompt;
                int hashCode29 = (hashCode28 + (str28 == null ? 0 : str28.hashCode())) * 31;
                String str29 = this.idBackHelpModalHints;
                int hashCode30 = (hashCode29 + (str29 == null ? 0 : str29.hashCode())) * 31;
                String str30 = this.idBackHelpModalContinueButtonText;
                int hashCode31 = (hashCode30 + (str30 == null ? 0 : str30.hashCode())) * 31;
                String str31 = this.staticCaptureTipsTitle;
                int hashCode32 = (hashCode31 + (str31 == null ? 0 : str31.hashCode())) * 31;
                String str32 = this.staticCaptureTipsSubtext;
                int hashCode33 = (hashCode32 + (str32 == null ? 0 : str32.hashCode())) * 31;
                String str33 = this.unableToClassifyDocumentTitle;
                int hashCode34 = (hashCode33 + (str33 == null ? 0 : str33.hashCode())) * 31;
                String str34 = this.unableToClassifyDocumentContinueButtonText;
                int hashCode35 = (hashCode34 + (str34 == null ? 0 : str34.hashCode())) * 31;
                String str35 = this.idClassRejectedTitle;
                int hashCode36 = (hashCode35 + (str35 == null ? 0 : str35.hashCode())) * 31;
                String str36 = this.idClassRejectedContinueButtonText;
                int hashCode37 = (hashCode36 + (str36 == null ? 0 : str36.hashCode())) * 31;
                String str37 = this.countryInputTitle;
                int hashCode38 = (hashCode37 + (str37 == null ? 0 : str37.hashCode())) * 31;
                String str38 = this.idClassInputTitle;
                int hashCode39 = (hashCode38 + (str38 == null ? 0 : str38.hashCode())) * 31;
                String str39 = this.manualClassificationTitle;
                int hashCode40 = (hashCode39 + (str39 == null ? 0 : str39.hashCode())) * 31;
                String str40 = this.manualClassificationContinueButtonText;
                int hashCode41 = (hashCode40 + (str40 == null ? 0 : str40.hashCode())) * 31;
                String str41 = this.autoClassificationCaptureTipText;
                int hashCode42 = (hashCode41 + (str41 == null ? 0 : str41.hashCode())) * 31;
                List<NextStep.GovernmentId.LocalizationOverride> list = this.localizationOverrides;
                return hashCode42 + (list != null ? list.hashCode() : 0);
            }

            @Nullable
            public final String getBarcodeHelpModalHints() {
                return this.barcodeHelpModalHints;
            }

            @Nullable
            public final String getBarcodeHelpModalPrompt() {
                return this.barcodeHelpModalPrompt;
            }

            @Nullable
            public final String getManualClassificationTitle() {
                return this.manualClassificationTitle;
            }

            @Nullable
            public final String getBarcodeHelpModalTitle() {
                return this.barcodeHelpModalTitle;
            }

            @NotNull
            public final String getButtonRetake() {
                return this.buttonRetake;
            }

            @Nullable
            public final String getMicrophonePermissionsAllowButtonText() {
                return this.microphonePermissionsAllowButtonText;
            }

            @Nullable
            public final String getMicrophonePermissionsCancelButtonText() {
                return this.microphonePermissionsCancelButtonText;
            }

            @NotNull
            public final String getButtonSubmit() {
                return this.buttonSubmit;
            }

            @Nullable
            public final String getCameraPermissionsAllowButtonText() {
                return this.cameraPermissionsAllowButtonText;
            }

            @Nullable
            public final String getMicrophonePermissionsPrompt() {
                return this.microphonePermissionsPrompt;
            }

            @Nullable
            public final String getCameraPermissionsCancelButtonText() {
                return this.cameraPermissionsCancelButtonText;
            }

            @Nullable
            public final String getMicrophonePermissionsTitle() {
                return this.microphonePermissionsTitle;
            }

            @Nullable
            public final String getCameraPermissionsPrompt() {
                return this.cameraPermissionsPrompt;
            }

            @Nullable
            public final String getPendingPageNavBarTitle() {
                return this.pendingPageNavBarTitle;
            }

            @Nullable
            public final String getCameraPermissionsTitle() {
                return this.cameraPermissionsTitle;
            }

            @NotNull
            public final String getProcessingDescription() {
                return this.processingDescription;
            }

            @NotNull
            public final String getCaptureDisclaimer() {
                return this.captureDisclaimer;
            }

            @Nullable
            public final String getCapturePageNavBarTitle() {
                return this.capturePageNavBarTitle;
            }

            @NotNull
            public final String getProcessingTitle() {
                return this.processingTitle;
            }

            @NotNull
            public String toString() {
                return "Strings(title=" + this.title + ", prompt=" + this.prompt + ", choose=" + this.choose + ", instructionsDisclaimer=" + this.instructionsDisclaimer + ", selectPageNavBarTitle=" + this.selectPageNavBarTitle + ", capturePageNavBarTitle=" + this.capturePageNavBarTitle + ", checkPageNavBarTitle=" + this.checkPageNavBarTitle + ", pendingPageNavBarTitle=" + this.pendingPageNavBarTitle + ", requestPageNavBarTitle=" + this.requestPageNavBarTitle + ", reviewUploadPageNavBarTitle=" + this.reviewUploadPageNavBarTitle + ", autoClassificationPageNavBarTitle=" + this.autoClassificationPageNavBarTitle + ", captureScreenTitle=" + this.captureScreenTitle + ", captureScreenDescription=" + this.captureScreenDescription + ", scanInstructions=" + this.scanInstructions + ", capturing=" + this.capturing + ", confirmCapture=" + this.confirmCapture + ", captureDisclaimer=" + this.captureDisclaimer + ", buttonSubmit=" + this.buttonSubmit + ", buttonRetake=" + this.buttonRetake + ", confirmCaptureTitle=" + this.confirmCaptureTitle + ", processingTitle=" + this.processingTitle + ", processingDescription=" + this.processingDescription + ", idClassToName=" + this.idClassToName + ", chooseCaptureMethodTitle=" + this.chooseCaptureMethodTitle + ", chooseCaptureMethodBody=" + this.chooseCaptureMethodBody + ", chooseCaptureMethodCameraButton=" + this.chooseCaptureMethodCameraButton + ", chooseCaptureMethodUploadButton=" + this.chooseCaptureMethodUploadButton + ", reviewSelectedImageTitle=" + this.reviewSelectedImageTitle + ", reviewSelectedImageBody=" + this.reviewSelectedImageBody + ", reviewSelectedImageConfirmButton=" + this.reviewSelectedImageConfirmButton + ", reviewSelectedImageChooseAnotherButton=" + this.reviewSelectedImageChooseAnotherButton + ", cameraPermissionsTitle=" + this.cameraPermissionsTitle + ", cameraPermissionsPrompt=" + this.cameraPermissionsPrompt + ", cameraPermissionsAllowButtonText=" + this.cameraPermissionsAllowButtonText + ", cameraPermissionsCancelButtonText=" + this.cameraPermissionsCancelButtonText + ", microphonePermissionsTitle=" + this.microphonePermissionsTitle + ", microphonePermissionsPrompt=" + this.microphonePermissionsPrompt + ", microphonePermissionsAllowButtonText=" + this.microphonePermissionsAllowButtonText + ", microphonePermissionsCancelButtonText=" + this.microphonePermissionsCancelButtonText + ", hintHoldStill=" + this.hintHoldStill + ", hintLowLight=" + this.hintLowLight + ", helpButtonText=" + this.helpButtonText + ", barcodeHelpModalTitle=" + this.barcodeHelpModalTitle + ", barcodeHelpModalPrompt=" + this.barcodeHelpModalPrompt + ", barcodeHelpModalHints=" + this.barcodeHelpModalHints + ", barcodeHelpModalContinueButtonText=" + this.barcodeHelpModalContinueButtonText + ", idFrontHelpModalTitle=" + this.idFrontHelpModalTitle + ", idFrontHelpModalPrompt=" + this.idFrontHelpModalPrompt + ", idFrontHelpModalHints=" + this.idFrontHelpModalHints + ", idFrontHelpModalContinueButtonText=" + this.idFrontHelpModalContinueButtonText + ", idBackHelpModalTitle=" + this.idBackHelpModalTitle + ", idBackHelpModalPrompt=" + this.idBackHelpModalPrompt + ", idBackHelpModalHints=" + this.idBackHelpModalHints + ", idBackHelpModalContinueButtonText=" + this.idBackHelpModalContinueButtonText + ", staticCaptureTipsTitle=" + this.staticCaptureTipsTitle + ", staticCaptureTipsSubtext=" + this.staticCaptureTipsSubtext + ", unableToClassifyDocumentTitle=" + this.unableToClassifyDocumentTitle + ", unableToClassifyDocumentContinueButtonText=" + this.unableToClassifyDocumentContinueButtonText + ", idClassRejectedTitle=" + this.idClassRejectedTitle + ", idClassRejectedContinueButtonText=" + this.idClassRejectedContinueButtonText + ", countryInputTitle=" + this.countryInputTitle + ", idClassInputTitle=" + this.idClassInputTitle + ", manualClassificationTitle=" + this.manualClassificationTitle + ", manualClassificationContinueButtonText=" + this.manualClassificationContinueButtonText + ", autoClassificationCaptureTipText=" + this.autoClassificationCaptureTipText + ", localizationOverrides=" + this.localizationOverrides + ")";
            }

            @NotNull
            public final OverridableText getCaptureScreenDescription() {
                return this.captureScreenDescription;
            }

            @NotNull
            public final String getPrompt() {
                return this.prompt;
            }

            @NotNull
            public final OverridableText getCaptureScreenTitle() {
                return this.captureScreenTitle;
            }

            @Nullable
            public final String getRequestPageNavBarTitle() {
                return this.requestPageNavBarTitle;
            }

            @NotNull
            public final String getCapturing() {
                return this.capturing;
            }

            @NotNull
            public final Map<IdConfig.e, String> w0() {
                return this.reviewSelectedImageBody;
            }

            @Override // android.os.Parcelable
            public final void writeToParcel(@NotNull Parcel dest, int flags) {
                Intrinsics.checkNotNullParameter(dest, "dest");
                dest.writeString(this.title);
                dest.writeString(this.prompt);
                dest.writeString(this.choose);
                dest.writeString(this.instructionsDisclaimer);
                dest.writeString(this.selectPageNavBarTitle);
                dest.writeString(this.capturePageNavBarTitle);
                dest.writeString(this.checkPageNavBarTitle);
                dest.writeString(this.pendingPageNavBarTitle);
                dest.writeString(this.requestPageNavBarTitle);
                dest.writeString(this.reviewUploadPageNavBarTitle);
                dest.writeString(this.autoClassificationPageNavBarTitle);
                this.captureScreenTitle.writeToParcel(dest, flags);
                this.captureScreenDescription.writeToParcel(dest, flags);
                this.scanInstructions.writeToParcel(dest, flags);
                dest.writeString(this.capturing);
                this.confirmCapture.writeToParcel(dest, flags);
                dest.writeString(this.captureDisclaimer);
                dest.writeString(this.buttonSubmit);
                dest.writeString(this.buttonRetake);
                this.confirmCaptureTitle.writeToParcel(dest, flags);
                dest.writeString(this.processingTitle);
                dest.writeString(this.processingDescription);
                Map<String, String> map = this.idClassToName;
                dest.writeInt(map.size());
                for (Map.Entry<String, String> entry : map.entrySet()) {
                    dest.writeString(entry.getKey());
                    dest.writeString(entry.getValue());
                }
                this.chooseCaptureMethodTitle.writeToParcel(dest, flags);
                this.chooseCaptureMethodBody.writeToParcel(dest, flags);
                dest.writeString(this.chooseCaptureMethodCameraButton);
                dest.writeString(this.chooseCaptureMethodUploadButton);
                Map<IdConfig.e, String> map2 = this.reviewSelectedImageTitle;
                dest.writeInt(map2.size());
                for (Map.Entry<IdConfig.e, String> entry2 : map2.entrySet()) {
                    dest.writeString(entry2.getKey().name());
                    dest.writeString(entry2.getValue());
                }
                Map<IdConfig.e, String> map3 = this.reviewSelectedImageBody;
                dest.writeInt(map3.size());
                for (Map.Entry<IdConfig.e, String> entry3 : map3.entrySet()) {
                    dest.writeString(entry3.getKey().name());
                    dest.writeString(entry3.getValue());
                }
                dest.writeString(this.reviewSelectedImageConfirmButton);
                dest.writeString(this.reviewSelectedImageChooseAnotherButton);
                dest.writeString(this.cameraPermissionsTitle);
                dest.writeString(this.cameraPermissionsPrompt);
                dest.writeString(this.cameraPermissionsAllowButtonText);
                dest.writeString(this.cameraPermissionsCancelButtonText);
                dest.writeString(this.microphonePermissionsTitle);
                dest.writeString(this.microphonePermissionsPrompt);
                dest.writeString(this.microphonePermissionsAllowButtonText);
                dest.writeString(this.microphonePermissionsCancelButtonText);
                dest.writeString(this.hintHoldStill);
                dest.writeString(this.hintLowLight);
                dest.writeString(this.helpButtonText);
                dest.writeString(this.barcodeHelpModalTitle);
                dest.writeString(this.barcodeHelpModalPrompt);
                dest.writeString(this.barcodeHelpModalHints);
                dest.writeString(this.barcodeHelpModalContinueButtonText);
                dest.writeString(this.idFrontHelpModalTitle);
                dest.writeString(this.idFrontHelpModalPrompt);
                dest.writeString(this.idFrontHelpModalHints);
                dest.writeString(this.idFrontHelpModalContinueButtonText);
                dest.writeString(this.idBackHelpModalTitle);
                dest.writeString(this.idBackHelpModalPrompt);
                dest.writeString(this.idBackHelpModalHints);
                dest.writeString(this.idBackHelpModalContinueButtonText);
                dest.writeString(this.staticCaptureTipsTitle);
                dest.writeString(this.staticCaptureTipsSubtext);
                dest.writeString(this.unableToClassifyDocumentTitle);
                dest.writeString(this.unableToClassifyDocumentContinueButtonText);
                dest.writeString(this.idClassRejectedTitle);
                dest.writeString(this.idClassRejectedContinueButtonText);
                dest.writeString(this.countryInputTitle);
                dest.writeString(this.idClassInputTitle);
                dest.writeString(this.manualClassificationTitle);
                dest.writeString(this.manualClassificationContinueButtonText);
                dest.writeString(this.autoClassificationCaptureTipText);
                List<NextStep.GovernmentId.LocalizationOverride> list = this.localizationOverrides;
                if (list == null) {
                    dest.writeInt(0);
                    return;
                }
                dest.writeInt(1);
                dest.writeInt(list.size());
                Iterator<NextStep.GovernmentId.LocalizationOverride> it = list.iterator();
                while (it.hasNext()) {
                    dest.writeParcelable(it.next(), flags);
                }
            }

            @Nullable
            public final String getCheckPageNavBarTitle() {
                return this.checkPageNavBarTitle;
            }

            @NotNull
            public final String getReviewSelectedImageChooseAnotherButton() {
                return this.reviewSelectedImageChooseAnotherButton;
            }

            @NotNull
            public final String getChoose() {
                return this.choose;
            }

            @NotNull
            public final String getReviewSelectedImageConfirmButton() {
                return this.reviewSelectedImageConfirmButton;
            }

            @NotNull
            public final OverridableText getChooseCaptureMethodBody() {
                return this.chooseCaptureMethodBody;
            }
        }

        /* JADX WARN: Multi-variable type inference failed */
        public a(@NotNull String sessionToken, @Nullable String str, @NotNull List<IdConfig> enabledIdClasses, @NotNull String inquiryId, @NotNull String fromStep, @NotNull String fromComponent, boolean z10, boolean z11, @NotNull List<? extends CaptureOptionNativeMobile> enabledCaptureOptionsNativeMobile, @Nullable StepStyles.GovernmentIdStepStyle governmentIdStepStyle, @NotNull Strings strings, int i10, @NotNull String fieldKeyDocument, @NotNull String fieldKeyIdClass, long j10, boolean z12, @Nullable Integer num, @NotNull VideoCaptureConfig videoCaptureConfig, @NotNull NextStep.GovernmentId.AssetConfig assetConfig, boolean z13, @NotNull deobf.com.withpersona.sdk2.inquiry.wo.a autoClassificationConfig, @NotNull StyleElements.Axis reviewCaptureButtonsAxis, @NotNull PendingPageTextPosition pendingPageTextVerticalPosition, @Nullable deobf.unlinked.bp.a aVar, boolean z14, @Nullable Integer num2, @NotNull i designVersion, @Nullable String str2, @Nullable deobf.com.withpersona.sdk2.inquiry.or.b bVar) {
            Intrinsics.checkNotNullParameter(sessionToken, "sessionToken");
            Intrinsics.checkNotNullParameter(enabledIdClasses, "enabledIdClasses");
            Intrinsics.checkNotNullParameter(inquiryId, "inquiryId");
            Intrinsics.checkNotNullParameter(fromStep, "fromStep");
            Intrinsics.checkNotNullParameter(fromComponent, "fromComponent");
            Intrinsics.checkNotNullParameter(enabledCaptureOptionsNativeMobile, "enabledCaptureOptionsNativeMobile");
            Intrinsics.checkNotNullParameter(strings, "strings");
            Intrinsics.checkNotNullParameter(fieldKeyDocument, "fieldKeyDocument");
            Intrinsics.checkNotNullParameter(fieldKeyIdClass, "fieldKeyIdClass");
            Intrinsics.checkNotNullParameter(videoCaptureConfig, "videoCaptureConfig");
            Intrinsics.checkNotNullParameter(assetConfig, "assetConfig");
            Intrinsics.checkNotNullParameter(autoClassificationConfig, "autoClassificationConfig");
            Intrinsics.checkNotNullParameter(reviewCaptureButtonsAxis, "reviewCaptureButtonsAxis");
            Intrinsics.checkNotNullParameter(pendingPageTextVerticalPosition, "pendingPageTextVerticalPosition");
            Intrinsics.checkNotNullParameter(designVersion, "designVersion");
            this.sessionToken = sessionToken;
            this.countryCode = str;
            this.enabledIdClasses = enabledIdClasses;
            this.inquiryId = inquiryId;
            this.fromStep = fromStep;
            this.fromComponent = fromComponent;
            this.backStepEnabled = z10;
            this.cancelButtonEnabled = z11;
            this.enabledCaptureOptionsNativeMobile = enabledCaptureOptionsNativeMobile;
            this.styles = governmentIdStepStyle;
            this.strings = strings;
            this.imageCaptureCount = i10;
            this.fieldKeyDocument = fieldKeyDocument;
            this.fieldKeyIdClass = fieldKeyIdClass;
            this.manualCaptureButtonDelayMs = j10;
            this.shouldSkipReviewScreen = z12;
            this.theme = num;
            this.videoCaptureConfig = videoCaptureConfig;
            this.assetConfig = assetConfig;
            this.isEnabled = z13;
            this.autoClassificationConfig = autoClassificationConfig;
            this.reviewCaptureButtonsAxis = reviewCaptureButtonsAxis;
            this.pendingPageTextVerticalPosition = pendingPageTextVerticalPosition;
            this.digitalIdConfig = aVar;
            this.staticCaptureTipsEnabled = z14;
            this.holographicTorchEnabledDurationMs = num2;
            this.designVersion = designVersion;
            this.flowWatermarkText = str2;
            this.customPendingPage = bVar;
        }

        @NotNull
        public final String getSessionToken() {
            return this.sessionToken;
        }

        @NotNull
        public final StyleElements.Axis getReviewCaptureButtonsAxis() {
            return this.reviewCaptureButtonsAxis;
        }

        public final boolean getShouldSkipReviewScreen() {
            return this.shouldSkipReviewScreen;
        }

        public final boolean getStaticCaptureTipsEnabled() {
            return this.staticCaptureTipsEnabled;
        }

        @NotNull
        public final Strings getStrings() {
            return this.strings;
        }

        @Nullable
        public final StepStyles.GovernmentIdStepStyle getStyles() {
            return this.styles;
        }

        @NotNull
        public final VideoCaptureConfig getVideoCaptureConfig() {
            return this.videoCaptureConfig;
        }

        @NotNull
        public final NextStep.GovernmentId.AssetConfig getAssetConfig() {
            return this.assetConfig;
        }

        @Override // android.os.Parcelable
        public final int describeContents() {
            return 0;
        }

        @NotNull
        public final deobf.com.withpersona.sdk2.inquiry.wo.a getAutoClassificationConfig() {
            return this.autoClassificationConfig;
        }

        public final boolean getBackStepEnabled() {
            return this.backStepEnabled;
        }

        public final boolean getCancelButtonEnabled() {
            return this.cancelButtonEnabled;
        }

        public final boolean getIsEnabled() {
            return this.isEnabled;
        }

        @Nullable
        public final String getCountryCode() {
            return this.countryCode;
        }

        @Nullable
        public final deobf.com.withpersona.sdk2.inquiry.or.b getCustomPendingPage() {
            return this.customPendingPage;
        }

        @NotNull
        public final i getDesignVersion() {
            return this.designVersion;
        }

        @NotNull
        public final List<CaptureOptionNativeMobile> n() {
            return this.enabledCaptureOptionsNativeMobile;
        }

        @NotNull
        public final List<IdConfig> o() {
            return this.enabledIdClasses;
        }

        @NotNull
        public final String getFieldKeyDocument() {
            return this.fieldKeyDocument;
        }

        @NotNull
        public final String getFieldKeyIdClass() {
            return this.fieldKeyIdClass;
        }

        @Nullable
        public final String getFlowWatermarkText() {
            return this.flowWatermarkText;
        }

        @NotNull
        public final String getFromComponent() {
            return this.fromComponent;
        }

        @NotNull
        public final String getFromStep() {
            return this.fromStep;
        }

        public final boolean u() {
            return this.enabledCaptureOptionsNativeMobile.size() > 1;
        }

        @Nullable
        public final Integer getHolographicTorchEnabledDurationMs() {
            return this.holographicTorchEnabledDurationMs;
        }

        public final int getImageCaptureCount() {
            return this.imageCaptureCount;
        }

        @Override // android.os.Parcelable
        public final void writeToParcel(@NotNull Parcel dest, int flags) {
            Intrinsics.checkNotNullParameter(dest, "dest");
            dest.writeString(this.sessionToken);
            dest.writeString(this.countryCode);
            List<IdConfig> list = this.enabledIdClasses;
            dest.writeInt(list.size());
            Iterator<IdConfig> it = list.iterator();
            while (it.hasNext()) {
                it.next().writeToParcel(dest, flags);
            }
            dest.writeString(this.inquiryId);
            dest.writeString(this.fromStep);
            dest.writeString(this.fromComponent);
            dest.writeInt(this.backStepEnabled ? 1 : 0);
            dest.writeInt(this.cancelButtonEnabled ? 1 : 0);
            List<CaptureOptionNativeMobile> list2 = this.enabledCaptureOptionsNativeMobile;
            dest.writeInt(list2.size());
            Iterator<CaptureOptionNativeMobile> it2 = list2.iterator();
            while (it2.hasNext()) {
                dest.writeString(it2.next().name());
            }
            dest.writeParcelable(this.styles, flags);
            this.strings.writeToParcel(dest, flags);
            dest.writeInt(this.imageCaptureCount);
            dest.writeString(this.fieldKeyDocument);
            dest.writeString(this.fieldKeyIdClass);
            dest.writeLong(this.manualCaptureButtonDelayMs);
            dest.writeInt(this.shouldSkipReviewScreen ? 1 : 0);
            Integer num = this.theme;
            if (num == null) {
                dest.writeInt(0);
            } else {
                dest.writeInt(1);
                dest.writeInt(num.intValue());
            }
            this.videoCaptureConfig.writeToParcel(dest, flags);
            dest.writeParcelable(this.assetConfig, flags);
            dest.writeInt(this.isEnabled ? 1 : 0);
            this.autoClassificationConfig.writeToParcel(dest, flags);
            dest.writeString(this.reviewCaptureButtonsAxis.name());
            dest.writeString(this.pendingPageTextVerticalPosition.name());
            deobf.unlinked.bp.a aVar = this.digitalIdConfig;
            if (aVar == null) {
                dest.writeInt(0);
            } else {
                dest.writeInt(1);
                aVar.writeToParcel(dest, flags);
            }
            dest.writeInt(this.staticCaptureTipsEnabled ? 1 : 0);
            Integer num2 = this.holographicTorchEnabledDurationMs;
            if (num2 == null) {
                dest.writeInt(0);
            } else {
                dest.writeInt(1);
                dest.writeInt(num2.intValue());
            }
            dest.writeString(this.designVersion.name());
            dest.writeString(this.flowWatermarkText);
            dest.writeParcelable(this.customPendingPage, flags);
        }

        @NotNull
        public final String getInquiryId() {
            return this.inquiryId;
        }

        public final long getManualCaptureButtonDelayMs() {
            return this.manualCaptureButtonDelayMs;
        }

        @NotNull
        public final PendingPageTextPosition getPendingPageTextVerticalPosition() {
            return this.pendingPageTextVerticalPosition;
        }
    }

    @Metadata(d1 = {"\u0000\u001e\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\b6\u0018\u00002\u00020\u0001:\u0004\u0004\u0005\u0006\u0007B\t\b\u0004¢\u0006\u0004\b\u0002\u0010\u0003\u0082\u0001\u0004\b\t\n\u000b¨\u0006\f"}, d2 = {"Lvo/d2$b;", BuildConfig.FLAVOR, "<init>", "()V", deobf.android.view.k6.b.f21144e, "d", deobf.android.view.xe.a.f36648e, "c", "Lvo/d2$b$a;", "Lvo/d2$b$b;", "Lvo/d2$b$c;", "Lvo/d2$b$d;", "government-id_release"}, k = 1, mv = {2, 2, 0}, xi = 48)
    public static abstract class b {

        @Metadata(d1 = {"\u0000*\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0003\bÆ\n\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\u0010\u0010\u0005\u001a\u00020\u0004HÖ\u0001¢\u0006\u0004\b\u0005\u0010\u0006J\u0010\u0010\b\u001a\u00020\u0007HÖ\u0001¢\u0006\u0004\b\b\u0010\tJ\u001a\u0010\r\u001a\u00020\f2\b\u0010\u000b\u001a\u0004\u0018\u00010\nHÖ\u0003¢\u0006\u0004\b\r\u0010\u000e¨\u0006\u000f"}, d2 = {"Lvo/d2$b$a;", "Lvo/d2$b;", "<init>", "()V", BuildConfig.FLAVOR, "toString", "()Ljava/lang/String;", BuildConfig.FLAVOR, "hashCode", "()I", BuildConfig.FLAVOR, "other", BuildConfig.FLAVOR, "equals", "(Ljava/lang/Object;)Z", "government-id_release"}, k = 1, mv = {2, 2, 0}, xi = 48)
        public static final /* data */ class a extends b {

            @NotNull
            public static final a f34597a = new a();

            public a() {
                super(null);
            }

            public boolean equals(@Nullable Object other) {
                return this == other || (other instanceof a);
            }

            public int hashCode() {
                return 1411335115;
            }

            @NotNull
            public String toString() {
                return "Back";
            }
        }

        @Metadata(d1 = {"\u0000*\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0003\bÆ\n\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\u0010\u0010\u0005\u001a\u00020\u0004HÖ\u0001¢\u0006\u0004\b\u0005\u0010\u0006J\u0010\u0010\b\u001a\u00020\u0007HÖ\u0001¢\u0006\u0004\b\b\u0010\tJ\u001a\u0010\r\u001a\u00020\f2\b\u0010\u000b\u001a\u0004\u0018\u00010\nHÖ\u0003¢\u0006\u0004\b\r\u0010\u000e¨\u0006\u000f"}, d2 = {"Lvo/d2$b$b;", "Lvo/d2$b;", "<init>", "()V", BuildConfig.FLAVOR, "toString", "()Ljava/lang/String;", BuildConfig.FLAVOR, "hashCode", "()I", BuildConfig.FLAVOR, "other", BuildConfig.FLAVOR, "equals", "(Ljava/lang/Object;)Z", "government-id_release"}, k = 1, mv = {2, 2, 0}, xi = 48)
        public static final /* data */ class C0708b extends b {

            @NotNull
            public static final C0708b f34598a = new C0708b();

            public C0708b() {
                super(null);
            }

            public boolean equals(@Nullable Object other) {
                return this == other || (other instanceof C0708b);
            }

            public int hashCode() {
                return 1649914237;
            }

            @NotNull
            public String toString() {
                return "Canceled";
            }
        }

        @Metadata(d1 = {"\u0000\u0010\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0007\u0018\u00002\u00020\u0001B\u000f\u0012\u0006\u0010\u0003\u001a\u00020\u0002¢\u0006\u0004\b\u0004\u0010\u0005R\u0017\u0010\u0003\u001a\u00020\u00028\u0006¢\u0006\f\n\u0004\b\u0006\u0010\u0007\u001a\u0004\b\u0006\u0010\b¨\u0006\t"}, d2 = {"Lvo/d2$b$c;", "Lvo/d2$b;", "Lcom/withpersona/sdk2/inquiry/network/core/InternalErrorInfo;", "cause", "<init>", "(Lcom/withpersona/sdk2/inquiry/network/core/InternalErrorInfo;)V", deobf.android.view.xe.a.f36648e, "Lcom/withpersona/sdk2/inquiry/network/core/InternalErrorInfo;", "()Lcom/withpersona/sdk2/inquiry/network/core/InternalErrorInfo;", "government-id_release"}, k = 1, mv = {2, 2, 0}, xi = 48)
        public static final class c extends b {

            @NotNull
            public final InternalErrorInfo cause;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            public c(@NotNull InternalErrorInfo cause) {
                super(null);
                Intrinsics.checkNotNullParameter(cause, "cause");
                this.cause = cause;
            }

            @NotNull
            public final InternalErrorInfo getCause() {
                return this.cause;
            }
        }

        @Metadata(d1 = {"\u0000*\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0003\bÆ\n\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\u0010\u0010\u0005\u001a\u00020\u0004HÖ\u0001¢\u0006\u0004\b\u0005\u0010\u0006J\u0010\u0010\b\u001a\u00020\u0007HÖ\u0001¢\u0006\u0004\b\b\u0010\tJ\u001a\u0010\r\u001a\u00020\f2\b\u0010\u000b\u001a\u0004\u0018\u00010\nHÖ\u0003¢\u0006\u0004\b\r\u0010\u000e¨\u0006\u000f"}, d2 = {"Lvo/d2$b$d;", "Lvo/d2$b;", "<init>", "()V", BuildConfig.FLAVOR, "toString", "()Ljava/lang/String;", BuildConfig.FLAVOR, "hashCode", "()I", BuildConfig.FLAVOR, "other", BuildConfig.FLAVOR, "equals", "(Ljava/lang/Object;)Z", "government-id_release"}, k = 1, mv = {2, 2, 0}, xi = 48)
        public static final /* data */ class d extends b {

            @NotNull
            public static final d f34600a = new d();

            public d() {
                super(null);
            }

            public boolean equals(@Nullable Object other) {
                return this == other || (other instanceof d);
            }

            public int hashCode() {
                return 1099427158;
            }

            @NotNull
            public String toString() {
                return "Finished";
            }
        }

        public /* synthetic */ b(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }

        public b() {
        }
    }

    @Metadata(k = 3, mv = {2, 2, 0}, xi = 48)
    public static final /* synthetic */ class c {

        public static final /* synthetic */ int[] f34601a;

        static {
            int[] iArr = new int[IdConfig.e.values().length];
            try {
                iArr[IdConfig.e.f34631d.ordinal()] = 1;
            } catch (NoSuchFieldError unused) {
            }
            try {
                iArr[IdConfig.e.f34632e.ordinal()] = 2;
            } catch (NoSuchFieldError unused2) {
            }
            try {
                iArr[IdConfig.e.f34633f.ordinal()] = 3;
            } catch (NoSuchFieldError unused3) {
            }
            try {
                iArr[IdConfig.e.f34634g.ordinal()] = 4;
            } catch (NoSuchFieldError unused4) {
            }
            try {
                iArr[IdConfig.e.f34635h.ordinal()] = 5;
            } catch (NoSuchFieldError unused5) {
            }
            f34601a = iArr;
        }
    }

    @Metadata(d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0002\b\u0002\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\n¢\u0006\u0004\b\u0002\u0010\u0003"}, d2 = {"Lav/p0;", BuildConfig.FLAVOR, "<anonymous>", "(Lav/p0;)V"}, k = 3, mv = {2, 2, 0})
    @deobf.com.withpersona.sdk2.inquiry.gu.f(c = "com.withpersona.sdk2.inquiry.governmentid.GovernmentIdWorkflow$render$2", f = "GovernmentIdWorkflow.kt", l = {157}, m = "invokeSuspend")
    public static final class d extends deobf.com.withpersona.sdk2.inquiry.gu.m implements Function2<deobf.com.withpersona.sdk2.inquiry.av.p0, deobf.kotlin.eu.b<? super Unit>, Object> {

        public int f34602t;

        public d(deobf.kotlin.eu.b<? super d> bVar) {
            super(2, bVar);
        }

        @Override // deobf.com.withpersona.sdk2.inquiry.gu.a
        public final deobf.kotlin.eu.b<Unit> create(Object obj, deobf.kotlin.eu.b<?> bVar) {
            return d2.this.new d(bVar);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(deobf.com.withpersona.sdk2.inquiry.av.p0 p0Var, deobf.kotlin.eu.b<? super Unit> bVar) {
            return ((d) create(p0Var, bVar)).invokeSuspend(Unit.f21504a);
        }

        @Override // deobf.com.withpersona.sdk2.inquiry.gu.a
        public final Object invokeSuspend(Object obj) {
            Object e10 = deobf.kotlin.fu.c.e();
            int i10 = this.f34602t;
            if (i10 == 0) {
                deobf.com.withpersona.sdk2.inquiry.zt.o.b(obj);
                deobf.com.withpersona.sdk2.inquiry.sn.m mVar = deobf.com.withpersona.sdk2.inquiry.sn.m.f31641a;
                Context context = d2.this.applicationContext;
                this.f34602t = 1;
                if (mVar.b(context, this) == e10) {
                    return e10;
                }
            } else {
                if (i10 != 1) {
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                deobf.com.withpersona.sdk2.inquiry.zt.o.b(obj);
            }
            d2.this.videoCaptureHelper.a();
            return Unit.f21504a;
        }
    }

    @Metadata(d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0002\b\u0002\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\n¢\u0006\u0004\b\u0002\u0010\u0003"}, d2 = {"Lav/p0;", BuildConfig.FLAVOR, "<anonymous>", "(Lav/p0;)V"}, k = 3, mv = {2, 2, 0})
    @deobf.com.withpersona.sdk2.inquiry.gu.f(c = "com.withpersona.sdk2.inquiry.governmentid.GovernmentIdWorkflow$render$3", f = "GovernmentIdWorkflow.kt", l = {}, m = "invokeSuspend")
    public static final class e extends deobf.com.withpersona.sdk2.inquiry.gu.m implements Function2<deobf.com.withpersona.sdk2.inquiry.av.p0, deobf.kotlin.eu.b<? super Unit>, Object> {

        public int f34604t;

        public final /* synthetic */ deobf.com.withpersona.sdk2.inquiry.ln.k<a, j0, b, Object>.a f34605u;

        public final /* synthetic */ d2 f34606v;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        /* JADX WARN: Multi-variable type inference failed */
        public e(deobf.com.withpersona.sdk2.inquiry.ln.k<? super a, j0, ? extends b, ? extends Object>.a aVar, d2 d2Var, deobf.kotlin.eu.b<? super e> bVar) {
            super(2, bVar);
            this.f34605u = aVar;
            this.f34606v = d2Var;
        }

        public static final Unit p(d2 d2Var, deobf.android.view.r.c cVar) {
            d2Var.c1(cVar);
            return Unit.f21504a;
        }

        @Override // deobf.com.withpersona.sdk2.inquiry.gu.a
        public final deobf.kotlin.eu.b<Unit> create(Object obj, deobf.kotlin.eu.b<?> bVar) {
            return new e(this.f34605u, this.f34606v, bVar);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(deobf.com.withpersona.sdk2.inquiry.av.p0 p0Var, deobf.kotlin.eu.b<? super Unit> bVar) {
            return ((e) create(p0Var, bVar)).invokeSuspend(Unit.f21504a);
        }

        @Override // deobf.com.withpersona.sdk2.inquiry.gu.a
        public final Object invokeSuspend(Object obj) {
            deobf.com.withpersona.sdk2.inquiry.ln.r<? super a, j0, ? extends b> d10;
            deobf.kotlin.fu.c.e();
            if (this.f34604t != 0) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            deobf.com.withpersona.sdk2.inquiry.zt.o.b(obj);
            deobf.com.withpersona.sdk2.inquiry.ln.h<deobf.com.withpersona.sdk2.inquiry.ln.r<? super a, j0, ? extends b>> d11 = this.f34605u.d();
            final d2 d2Var = this.f34606v;
            d10 = ln.z.d(d2Var, null, new Function1() { // from class: vo.e2
                @Override // kotlin.jvm.functions.Function1
                public final Object invoke(Object obj2) {
                    Unit p8;
                    p8 = deobf.androidx.constraintlayout.widget.d2.e.p(d2.this, (deobf.android.view.r.c) obj2);
                    return p8;
                }
            }, 1, null);
            d11.a(d10);
            return Unit.f21504a;
        }
    }

    @Metadata(d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0002\b\u0002\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\n¢\u0006\u0004\b\u0002\u0010\u0003"}, d2 = {"Lav/p0;", BuildConfig.FLAVOR, "<anonymous>", "(Lav/p0;)V"}, k = 3, mv = {2, 2, 0})
    @deobf.com.withpersona.sdk2.inquiry.gu.f(c = "com.withpersona.sdk2.inquiry.governmentid.GovernmentIdWorkflow$renderScreen$1", f = "GovernmentIdWorkflow.kt", l = {}, m = "invokeSuspend")
    public static final class f extends deobf.com.withpersona.sdk2.inquiry.gu.m implements Function2<deobf.com.withpersona.sdk2.inquiry.av.p0, deobf.kotlin.eu.b<? super Unit>, Object> {

        public int f34607t;

        public final /* synthetic */ a f34608u;

        public final /* synthetic */ j0 f34609v;

        public final /* synthetic */ d2 f34610w;

        public final /* synthetic */ deobf.com.withpersona.sdk2.inquiry.ln.k<a, j0, b, Object>.a f34611x;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        /* JADX WARN: Multi-variable type inference failed */
        public f(a aVar, j0 j0Var, d2 d2Var, deobf.com.withpersona.sdk2.inquiry.ln.k<? super a, j0, ? extends b, ? extends Object>.a aVar2, deobf.kotlin.eu.b<? super f> bVar) {
            super(2, bVar);
            this.f34608u = aVar;
            this.f34609v = j0Var;
            this.f34610w = d2Var;
            this.f34611x = aVar2;
        }

        @Override // deobf.com.withpersona.sdk2.inquiry.gu.a
        public final deobf.kotlin.eu.b<Unit> create(Object obj, deobf.kotlin.eu.b<?> bVar) {
            return new f(this.f34608u, this.f34609v, this.f34610w, this.f34611x, bVar);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(deobf.com.withpersona.sdk2.inquiry.av.p0 p0Var, deobf.kotlin.eu.b<? super Unit> bVar) {
            return ((f) create(p0Var, bVar)).invokeSuspend(Unit.f21504a);
        }

        @Override // deobf.com.withpersona.sdk2.inquiry.gu.a
        public final Object invokeSuspend(Object obj) {
            deobf.kotlin.fu.c.e();
            if (this.f34607t != 0) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            deobf.com.withpersona.sdk2.inquiry.zt.o.b(obj);
            if (this.f34608u.o().size() == 1) {
                j0 j0Var = this.f34609v;
                d2 d2Var = this.f34610w;
                deobf.com.withpersona.sdk2.inquiry.ln.k<a, j0, b, Object>.a aVar = this.f34611x;
                a aVar2 = this.f34608u;
                d2.Z0(j0Var, d2Var, aVar, aVar2, (IdConfig) CollectionsKt.d0(aVar2.o()), false);
            }
            return Unit.f21504a;
        }
    }

    @Metadata(d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0002\b\u0002\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\n¢\u0006\u0004\b\u0002\u0010\u0003"}, d2 = {"Lav/p0;", BuildConfig.FLAVOR, "<anonymous>", "(Lav/p0;)V"}, k = 3, mv = {2, 2, 0})
    @deobf.com.withpersona.sdk2.inquiry.gu.f(c = "com.withpersona.sdk2.inquiry.governmentid.GovernmentIdWorkflow$renderScreen$24", f = "GovernmentIdWorkflow.kt", l = {774}, m = "invokeSuspend")
    public static final class g extends deobf.com.withpersona.sdk2.inquiry.gu.m implements Function2<deobf.com.withpersona.sdk2.inquiry.av.p0, deobf.kotlin.eu.b<? super Unit>, Object> {

        public int f34612t;

        public final /* synthetic */ deobf.com.withpersona.sdk2.inquiry.ln.k<a, j0, b, Object>.a f34614v;

        public final /* synthetic */ j0 f34615w;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        /* JADX WARN: Multi-variable type inference failed */
        public g(deobf.com.withpersona.sdk2.inquiry.ln.k<? super a, j0, ? extends b, ? extends Object>.a aVar, j0 j0Var, deobf.kotlin.eu.b<? super g> bVar) {
            super(2, bVar);
            this.f34614v = aVar;
            this.f34615w = j0Var;
        }

        public static final Unit p(j0 j0Var, deobf.android.view.r.c cVar) {
            cVar.e(j0Var);
            return Unit.f21504a;
        }

        @Override // deobf.com.withpersona.sdk2.inquiry.gu.a
        public final deobf.kotlin.eu.b<Unit> create(Object obj, deobf.kotlin.eu.b<?> bVar) {
            return d2.this.new g(this.f34614v, this.f34615w, bVar);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(deobf.com.withpersona.sdk2.inquiry.av.p0 p0Var, deobf.kotlin.eu.b<? super Unit> bVar) {
            return ((g) create(p0Var, bVar)).invokeSuspend(Unit.f21504a);
        }

        @Override // deobf.com.withpersona.sdk2.inquiry.gu.a
        public final Object invokeSuspend(Object obj) {
            deobf.com.withpersona.sdk2.inquiry.ln.r<? super a, j0, ? extends b> d10;
            Object e10 = deobf.kotlin.fu.c.e();
            int i10 = this.f34612t;
            if (i10 == 0) {
                deobf.com.withpersona.sdk2.inquiry.zt.o.b(obj);
                deobf.com.withpersona.sdk2.inquiry.sn.m mVar = deobf.com.withpersona.sdk2.inquiry.sn.m.f31641a;
                Context context = d2.this.applicationContext;
                this.f34612t = 1;
                if (mVar.b(context, this) == e10) {
                    return e10;
                }
            } else {
                if (i10 != 1) {
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                deobf.com.withpersona.sdk2.inquiry.zt.o.b(obj);
            }
            d2.this.videoCaptureHelper.a();
            deobf.com.withpersona.sdk2.inquiry.ln.h<deobf.com.withpersona.sdk2.inquiry.ln.r<? super a, j0, ? extends b>> d11 = this.f34614v.d();
            d2 d2Var = d2.this;
            final j0 j0Var = this.f34615w;
            d10 = ln.z.d(d2Var, null, new Function1() { // from class: vo.f2
                @Override // kotlin.jvm.functions.Function1
                public final Object invoke(Object obj2) {
                    Unit p8;
                    p8 = deobf.androidx.constraintlayout.widget.d2.g.p(j0.this, (deobf.android.view.r.c) obj2);
                    return p8;
                }
            }, 1, null);
            d11.a(d10);
            return Unit.f21504a;
        }
    }

    @Metadata(k = 3, mv = {2, 2, 0}, xi = 48)
    public static final /* synthetic */ class h extends kotlin.jvm.internal.a implements Function1<IdConfig, Unit> {

        public final /* synthetic */ j0 f34616h;

        public final /* synthetic */ d2 f34617i;

        public final /* synthetic */ deobf.com.withpersona.sdk2.inquiry.ln.k<a, j0, b, Object>.a f34618j;

        public final /* synthetic */ a f34619k;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        /* JADX WARN: Multi-variable type inference failed */
        public h(j0 j0Var, d2 d2Var, deobf.com.withpersona.sdk2.inquiry.ln.k<? super a, j0, ? extends b, ? extends Object>.a aVar, a aVar2) {
            super(1, Intrinsics.a.class, "selectIdClass", "renderScreen$selectIdClass(Lcom/withpersona/sdk2/inquiry/governmentid/GovernmentIdState;Lcom/withpersona/sdk2/inquiry/governmentid/GovernmentIdWorkflow;Lcom/squareup/workflow1/StatefulWorkflow$RenderContext;Lcom/withpersona/sdk2/inquiry/governmentid/GovernmentIdWorkflow$Input;Lcom/withpersona/sdk2/inquiry/governmentid/IdConfig;Z)V", 0);
            this.f34616h = j0Var;
            this.f34617i = d2Var;
            this.f34618j = aVar;
            this.f34619k = aVar2;
        }

        public final void a(IdConfig p02) {
            Intrinsics.checkNotNullParameter(p02, "p0");
            d2.a1(this.f34616h, this.f34617i, this.f34618j, this.f34619k, p02, false, 32, null);
        }

        @Override // kotlin.jvm.functions.Function1
        public /* bridge */ /* synthetic */ Unit invoke(IdConfig idConfig) {
            a(idConfig);
            return Unit.f21504a;
        }
    }

    public d2(@NotNull Context applicationContext, @NotNull deobf.com.roblox.client.l6.s imageLoader, @NotNull deobf.unlinked.f.a submitVerificationWorkerFactory, @NotNull j documentSelectWorker, @NotNull deobf.unlinked.ip.j localVideoCaptureRenderer, @NotNull deobf.unlinked.ip.v webRtcRenderer, @NotNull deobf.com.withpersona.sdk2.inquiry.yo.t0 captureRenderer, @NotNull AutoClassifyWorker.b autoClassifyWorkerFactory, @NotNull deobf.com.withpersona.sdk2.inquiry.wo.o autoClassificationRenderer, @NotNull deobf.unlinked.yn.a cameraStatsManager, @NotNull deobf.com.withpersona.sdk2.inquiry.ir.b navigationStateManager, @NotNull deobf.com.withpersona.sdk2.inquiry.dr.c externalEventLogger, @NotNull TrackingEventsLogger trackingEventsLogger, @NotNull deobf.com.withpersona.sdk2.inquiry.gr.b themeManager) {
        Intrinsics.checkNotNullParameter(applicationContext, "applicationContext");
        Intrinsics.checkNotNullParameter(imageLoader, "imageLoader");
        Intrinsics.checkNotNullParameter(submitVerificationWorkerFactory, "submitVerificationWorkerFactory");
        Intrinsics.checkNotNullParameter(documentSelectWorker, "documentSelectWorker");
        Intrinsics.checkNotNullParameter(localVideoCaptureRenderer, "localVideoCaptureRenderer");
        Intrinsics.checkNotNullParameter(webRtcRenderer, "webRtcRenderer");
        Intrinsics.checkNotNullParameter(captureRenderer, "captureRenderer");
        Intrinsics.checkNotNullParameter(autoClassifyWorkerFactory, "autoClassifyWorkerFactory");
        Intrinsics.checkNotNullParameter(autoClassificationRenderer, "autoClassificationRenderer");
        Intrinsics.checkNotNullParameter(cameraStatsManager, "cameraStatsManager");
        Intrinsics.checkNotNullParameter(navigationStateManager, "navigationStateManager");
        Intrinsics.checkNotNullParameter(externalEventLogger, "externalEventLogger");
        Intrinsics.checkNotNullParameter(trackingEventsLogger, "trackingEventsLogger");
        Intrinsics.checkNotNullParameter(themeManager, "themeManager");
        this.applicationContext = applicationContext;
        this.imageLoader = imageLoader;
        this.submitVerificationWorkerFactory = submitVerificationWorkerFactory;
        this.documentSelectWorker = documentSelectWorker;
        this.localVideoCaptureRenderer = localVideoCaptureRenderer;
        this.webRtcRenderer = webRtcRenderer;
        this.captureRenderer = captureRenderer;
        this.autoClassifyWorkerFactory = autoClassifyWorkerFactory;
        this.autoClassificationRenderer = autoClassificationRenderer;
        this.cameraStatsManager = cameraStatsManager;
        this.navigationStateManager = navigationStateManager;
        this.externalEventLogger = externalEventLogger;
        this.trackingEventsLogger = trackingEventsLogger;
        this.themeManager = themeManager;
        this.videoCaptureHelper = new deobf.unlinked.ip.l(null, 1, null);
    }

    public static final Unit A0(final d2 d2Var, final deobf.unlinked.k.a aVar, final j0 j0Var, final a aVar2, final deobf.com.withpersona.sdk2.inquiry.vo.f fVar) {
        deobf.com.withpersona.sdk2.inquiry.ln.r d10;
        TrackingEventsLogger.logGovernmentIdButtonClickEvent$default(d2Var.trackingEventsLogger, new GovernmentIdButtonEventData(GovIdCaptureButtonType.RETAKE_PHOTO, null, 2, null), false, 2, null);
        deobf.com.withpersona.sdk2.inquiry.ln.h d11 = aVar.d();
        d10 = ln.z.d(d2Var, null, new Function1() { // from class: vo.d1
            @Override // kotlin.jvm.functions.Function1
            public final Object invoke(Object obj) {
                Unit B0;
                B0 = d2.B0(j0.this, aVar2, fVar, aVar, d2Var, (deobf.android.view.r.c) obj);
                return B0;
            }
        }, 1, null);
        d11.a(d10);
        return Unit.f21504a;
    }

    public static final Unit B0(j0 j0Var, a aVar, deobf.com.withpersona.sdk2.inquiry.vo.f fVar, final deobf.unlinked.k.a aVar2, final d2 d2Var, deobf.android.view.r.c action) {
        Intrinsics.checkNotNullParameter(action, "$this$action");
        Object c10 = action.c();
        j0 j0Var2 = c10 instanceof j0 ? (j0) c10 : null;
        if (j0Var2 == null) {
            return Unit.f21504a;
        }
        j0.ReviewCapturedImage reviewCapturedImage = (j0.ReviewCapturedImage) j0Var;
        j0.WaitForAutocapture waitForAutocapture = new j0.WaitForAutocapture(reviewCapturedImage.getCurrentPart(), ((j0) action.c()).D(), fVar, b3.O((a) action.b(), reviewCapturedImage.getCurrentPart().getSide()), j0Var2.C(), j0Var2.getPartIndex(), b3.x(action, false), deobf.unlinked.ip.x.f19686c, aVar.getVideoCaptureConfig().getWebRtcJwt(), null, false, false, reviewCapturedImage.getCountryCode(), null, new Function0() { // from class: vo.r1
            @Override // kotlin.jvm.functions.Function0
            public final Object invoke() {
                Unit C0;
                C0 = d2.C0(deobf.unlinked.k.a.this, d2Var);
                return C0;
            }
        }, 11776, null);
        waitForAutocapture.F(true);
        action.e(waitForAutocapture);
        return Unit.f21504a;
    }

    public static final Unit C0(deobf.unlinked.k.a aVar, final d2 d2Var) {
        deobf.com.withpersona.sdk2.inquiry.ln.r d10;
        deobf.com.withpersona.sdk2.inquiry.ln.h d11 = aVar.d();
        d10 = ln.z.d(d2Var, null, new Function1() { // from class: vo.v1
            @Override // kotlin.jvm.functions.Function1
            public final Object invoke(Object obj) {
                Unit D0;
                D0 = d2.D0(d2.this, (deobf.android.view.r.c) obj);
                return D0;
            }
        }, 1, null);
        d11.a(d10);
        return Unit.f21504a;
    }

    public static final Unit D0(d2 d2Var, deobf.android.view.r.c action) {
        Intrinsics.checkNotNullParameter(action, "$this$action");
        Object c10 = action.c();
        j0.WaitForAutocapture waitForAutocapture = c10 instanceof j0.WaitForAutocapture ? (j0.WaitForAutocapture) c10 : null;
        if (waitForAutocapture != null) {
            action.e(j0.WaitForAutocapture.L(waitForAutocapture, null, null, null, null, null, 0, null, d2Var.videoCaptureHelper.d() ? deobf.unlinked.ip.x.b : deobf.unlinked.ip.x.f19686c, null, null, false, false, null, null, null, 32639, null));
        }
        return Unit.f21504a;
    }

    public static final Unit E0(deobf.com.withpersona.sdk2.inquiry.ln.h hVar) {
        hVar.a(b.C0708b.f34598a);
        return Unit.f21504a;
    }

    public static final Unit F0(deobf.unlinked.k.a aVar, d2 d2Var, final j0 j0Var) {
        deobf.com.withpersona.sdk2.inquiry.ln.r d10;
        deobf.com.withpersona.sdk2.inquiry.ln.h d11 = aVar.d();
        d10 = ln.z.d(d2Var, null, new Function1() { // from class: vo.o1
            @Override // kotlin.jvm.functions.Function1
            public final Object invoke(Object obj) {
                Unit G0;
                G0 = d2.G0(j0.this, (deobf.android.view.r.c) obj);
                return G0;
            }
        }, 1, null);
        d11.a(d10);
        return Unit.f21504a;
    }

    public static final Unit G0(j0 j0Var, deobf.android.view.r.c action) {
        Intrinsics.checkNotNullParameter(action, "$this$action");
        action.e(j0.ReviewCapturedImage.N((j0.ReviewCapturedImage) j0Var, null, null, null, null, null, 0, null, null, null, false, null, 1791, null));
        return Unit.f21504a;
    }

    public static final Unit H0(a aVar, j0 j0Var, deobf.unlinked.k.a aVar2, d2 d2Var) {
        deobf.com.google.firebase.x3.h(aVar, (j0.j) j0Var, aVar2, d2Var.videoCaptureHelper, d2Var.trackingEventsLogger);
        return Unit.f21504a;
    }

    public static final Unit I0(deobf.unlinked.k.a aVar, d2 d2Var) {
        b3.S(aVar, d2Var.videoCaptureHelper);
        return Unit.f21504a;
    }

    public static final Unit J0(deobf.unlinked.k.a aVar, d2 d2Var) {
        b3.S(aVar, d2Var.videoCaptureHelper);
        return Unit.f21504a;
    }

    public static final Unit K0(deobf.unlinked.k.a aVar) {
        b3.v(aVar);
        return Unit.f21504a;
    }

    public static final Unit L0(deobf.unlinked.k.a aVar, d2 d2Var, final j0 j0Var) {
        deobf.com.withpersona.sdk2.inquiry.ln.r d10;
        deobf.com.withpersona.sdk2.inquiry.ln.h d11 = aVar.d();
        d10 = ln.z.d(d2Var, null, new Function1() { // from class: vo.e1
            @Override // kotlin.jvm.functions.Function1
            public final Object invoke(Object obj) {
                Unit M0;
                M0 = d2.M0(j0.this, (deobf.android.view.r.c) obj);
                return M0;
            }
        }, 1, null);
        d11.a(d10);
        return Unit.f21504a;
    }

    public static final Unit M0(j0 j0Var, deobf.android.view.r.c action) {
        Intrinsics.checkNotNullParameter(action, "$this$action");
        action.e(j0.ReviewSelectedImage.N((j0.ReviewSelectedImage) j0Var, null, null, null, null, null, null, 0, null, null, null, false, null, 3583, null));
        return Unit.f21504a;
    }

    public static final Unit N0(deobf.unlinked.k.a aVar, d2 d2Var) {
        b3.S(aVar, d2Var.videoCaptureHelper);
        return Unit.f21504a;
    }

    public static final deobf.com.withpersona.sdk2.inquiry.ln.r O0(final d2 d2Var, final deobf.unlinked.k.a aVar, final deobf.unlinked.f.b it) {
        deobf.com.withpersona.sdk2.inquiry.ln.r d10;
        final String string;
        deobf.com.withpersona.sdk2.inquiry.ln.r d11;
        deobf.com.withpersona.sdk2.inquiry.ln.r d12;
        Intrinsics.checkNotNullParameter(it, "it");
        if (it instanceof deobf.unlinked.f.b.c) {
            d12 = ln.z.d(d2Var, null, new Function1() { // from class: vo.g1
                @Override // kotlin.jvm.functions.Function1
                public final Object invoke(Object obj) {
                    Unit P0;
                    P0 = d2.P0(d2.this, aVar, (deobf.android.view.r.c) obj);
                    return P0;
                }
            }, 1, null);
            return d12;
        }
        if (!(it instanceof deobf.unlinked.f.b.C0228b)) {
            if (!(it instanceof deobf.unlinked.f.b.a)) {
                throw new deobf.com.withpersona.sdk2.inquiry.zt.l();
            }
            d10 = ln.z.d(d2Var, null, new Function1() { // from class: vo.i1
                @Override // kotlin.jvm.functions.Function1
                public final Object invoke(Object obj) {
                    Unit R0;
                    R0 = d2.R0(deobf.unlinked.f.b.this, d2Var, aVar, (deobf.android.view.r.c) obj);
                    return R0;
                }
            }, 1, null);
            return d10;
        }
        deobf.unlinked.f.b.C0228b c0228b = (deobf.unlinked.f.b.C0228b) it;
        if (c0228b.getCause() instanceof GenericFileUploadErrorResponse.DocumentErrorResponse.GovernmentIdDimensionSizeError) {
            string = d2Var.applicationContext.getString(deobf.com.withpersona.sdk2.inquiry.jq.g.f20888t, Integer.valueOf(((GenericFileUploadErrorResponse.DocumentErrorResponse.GovernmentIdDimensionSizeError) c0228b.getCause()).getDetails().getMinDimensionSize()));
            Intrinsics.checkNotNullExpressionValue(string, "getString(...)");
        } else {
            string = d2Var.applicationContext.getString(deobf.com.withpersona.sdk2.inquiry.jq.g.f20889u);
            Intrinsics.checkNotNullExpressionValue(string, "getString(...)");
        }
        d11 = ln.z.d(d2Var, null, new Function1() { // from class: vo.h1
            @Override // kotlin.jvm.functions.Function1
            public final Object invoke(Object obj) {
                Unit Q0;
                Q0 = d2.Q0(string, (deobf.android.view.r.c) obj);
                return Q0;
            }
        }, 1, null);
        return d11;
    }

    public static final Unit P0(d2 d2Var, deobf.unlinked.k.a aVar, deobf.android.view.r.c action) {
        Intrinsics.checkNotNullParameter(action, "$this$action");
        d2Var.b1(aVar, b.d.f34600a);
        return Unit.f21504a;
    }

    public static final Unit Q0(String str, deobf.android.view.r.c action) {
        Intrinsics.checkNotNullParameter(action, "$this$action");
        j0 backState = ((j0) action.c()).getBackState();
        if (backState != null) {
            action.e(backState.u(str));
        }
        return Unit.f21504a;
    }

    public static final Unit R0(deobf.unlinked.f.b bVar, d2 d2Var, deobf.unlinked.k.a aVar, deobf.android.view.r.c action) {
        Intrinsics.checkNotNullParameter(action, "$this$action");
        j0 backState = ((j0) action.c()).getBackState();
        deobf.unlinked.f.b.a aVar2 = (deobf.unlinked.f.b.a) bVar;
        if ((aVar2.getCause() instanceof InternalErrorInfo.NetworkErrorInfo) && ((InternalErrorInfo.NetworkErrorInfo) aVar2.getCause()).isRecoverable() && backState != null) {
            String string = d2Var.applicationContext.getString(deobf.com.withpersona.sdk2.inquiry.jq.g.B);
            Intrinsics.checkNotNullExpressionValue(string, "getString(...)");
            action.e(backState.u(string));
        } else {
            d2Var.b1(aVar, new b.c(aVar2.getCause()));
        }
        return Unit.f21504a;
    }

    public static final Unit S0(d2 d2Var, deobf.unlinked.k.a aVar) {
        d2Var.b1(aVar, b.C0708b.f34598a);
        return Unit.f21504a;
    }

    public static final Unit T0(d2 d2Var, deobf.unlinked.k.a aVar) {
        d2Var.b1(aVar, b.C0708b.f34598a);
        return Unit.f21504a;
    }

    public static final Unit U0(deobf.unlinked.k.a aVar) {
        b3.v(aVar);
        return Unit.f21504a;
    }

    public static final Unit V0(deobf.unlinked.k.a aVar, d2 d2Var, final j0 j0Var) {
        deobf.com.withpersona.sdk2.inquiry.ln.r d10;
        deobf.com.withpersona.sdk2.inquiry.ln.h d11 = aVar.d();
        d10 = ln.z.d(d2Var, null, new Function1() { // from class: vo.q1
            @Override // kotlin.jvm.functions.Function1
            public final Object invoke(Object obj) {
                Unit W0;
                W0 = d2.W0(j0.this, (deobf.android.view.r.c) obj);
                return W0;
            }
        }, 1, null);
        d11.a(d10);
        return Unit.f21504a;
    }

    public static final Unit W0(j0 j0Var, deobf.android.view.r.c action) {
        Intrinsics.checkNotNullParameter(action, "$this$action");
        action.e(j0.ShowInstructions.H((j0.ShowInstructions) j0Var, null, null, null, null, 0, null, null, null, 127, null));
        return Unit.f21504a;
    }

    public static final deobf.com.withpersona.sdk2.inquiry.ln.r<a, j0, b> X0(i3.SideIdPart sideIdPart, final j0 j0Var, d2 d2Var, String str, final String str2) {
        deobf.com.withpersona.sdk2.inquiry.ln.r<a, j0, b> d10;
        final n.GovernmentIdImage governmentIdImage = new n.GovernmentIdImage(kotlin.collections.o.d(new Frame(str, null, 2, null)), b3.e0(sideIdPart.getSide()), deobf.com.withpersona.sdk2.inquiry.vo.g.b(((j0.ChooseCaptureMethod) j0Var).getCaptureConfig()), deobf.unlinked.n.a.f34837c, null, null, 32, null);
        d10 = ln.z.d(d2Var, null, new Function1() { // from class: vo.s1
            @Override // kotlin.jvm.functions.Function1
            public final Object invoke(Object obj) {
                Unit Y0;
                Y0 = d2.Y0(j0.this, governmentIdImage, str2, (deobf.android.view.r.c) obj);
                return Y0;
            }
        }, 1, null);
        return d10;
    }

    public static final Unit Y0(j0 j0Var, n.GovernmentIdImage governmentIdImage, String str, deobf.android.view.r.c action) {
        Intrinsics.checkNotNullParameter(action, "$this$action");
        Object c10 = action.c();
        j0.ChooseCaptureMethod chooseCaptureMethod = c10 instanceof j0.ChooseCaptureMethod ? (j0.ChooseCaptureMethod) c10 : null;
        if (chooseCaptureMethod == null) {
            return Unit.f21504a;
        }
        j0.ChooseCaptureMethod chooseCaptureMethod2 = chooseCaptureMethod;
        j0.ChooseCaptureMethod chooseCaptureMethod3 = (j0.ChooseCaptureMethod) j0Var;
        action.e(new j0.ReviewSelectedImage(chooseCaptureMethod3.getCurrentPart(), chooseCaptureMethod3.D(), chooseCaptureMethod3.getCaptureConfig(), governmentIdImage, str, chooseCaptureMethod2.C(), chooseCaptureMethod2.getPartIndex(), b3.y(action, false, 1, null), null, null, false, chooseCaptureMethod3.getCountryCode(), 1792, null));
        return Unit.f21504a;
    }

    public static final void Z0(j0 j0Var, d2 d2Var, deobf.com.withpersona.sdk2.inquiry.ln.k<? super a, j0, ? extends b, ? extends Object>.a aVar, a aVar2, IdConfig idConfig, boolean z10) {
        b3.W(r0, aVar, aVar2, null, idConfig, d2Var.videoCaptureHelper, new deobf.com.withpersona.sdk2.inquiry.sn.v(null, null, null, 0, 0, 31, null), (r26 & Barcode.FORMAT_ITF) != 0 ? true : z10, (r26 & Barcode.FORMAT_QR_CODE) != 0 ? r0.C() : idConfig.f(), (r26 & Barcode.FORMAT_UPC_A) != 0 ? r0.getPartIndex() : 0, (r26 & Barcode.FORMAT_UPC_E) != 0 ? null : null, (r26 & Barcode.FORMAT_PDF417) != 0 ? ((j0.ShowInstructions) j0Var).getCountryCode() : null);
    }

    public static /* synthetic */ void a1(j0 j0Var, d2 d2Var, deobf.unlinked.k.a aVar, a aVar2, IdConfig idConfig, boolean z10, int i10, Object obj) {
        if ((i10 & 32) != 0) {
            z10 = true;
        }
        Z0(j0Var, d2Var, aVar, aVar2, idConfig, z10);
    }

    public static final deobf.com.withpersona.sdk2.inquiry.ln.r k0(final d2 d2Var, i3.SideIdPart sideIdPart, final j0 j0Var, final deobf.unlinked.k.a aVar, final deobf.com.google.android.material.j.a it) {
        deobf.com.withpersona.sdk2.inquiry.ln.r d10;
        deobf.com.withpersona.sdk2.inquiry.ln.r d11;
        Intrinsics.checkNotNullParameter(it, "it");
        if (it instanceof deobf.com.google.android.material.j.a.c) {
            deobf.com.google.android.material.j.a.c cVar = (deobf.com.google.android.material.j.a.c) it;
            return X0(sideIdPart, j0Var, d2Var, cVar.getAbsoluteFilePath(), cVar.getFileName());
        }
        if (Intrinsics.c(it, deobf.com.google.android.material.j.a.C0712a.f34670a)) {
            d11 = ln.z.d(d2Var, null, new Function1() { // from class: vo.k1
                @Override // kotlin.jvm.functions.Function1
                public final Object invoke(Object obj) {
                    Unit m02;
                    m02 = d2.m0(j0.this, (deobf.android.view.r.c) obj);
                    return m02;
                }
            }, 1, null);
            return d11;
        }
        if (!(it instanceof deobf.com.google.android.material.j.a.b)) {
            throw new deobf.com.withpersona.sdk2.inquiry.zt.l();
        }
        d10 = ln.z.d(d2Var, null, new Function1() { // from class: vo.m1
            @Override // kotlin.jvm.functions.Function1
            public final Object invoke(Object obj) {
                Unit l02;
                l02 = d2.l0(d2.this, aVar, it, (deobf.android.view.r.c) obj);
                return l02;
            }
        }, 1, null);
        return d10;
    }

    public static final Unit l0(d2 d2Var, deobf.unlinked.k.a aVar, deobf.com.google.android.material.j.a aVar2, deobf.android.view.r.c action) {
        Intrinsics.checkNotNullParameter(action, "$this$action");
        d2Var.b1(aVar, new b.c(((deobf.com.google.android.material.j.a.b) aVar2).getCause()));
        return Unit.f21504a;
    }

    public static final Unit m0(j0 j0Var, deobf.android.view.r.c action) {
        Intrinsics.checkNotNullParameter(action, "$this$action");
        action.e(j0.ChooseCaptureMethod.H((j0.ChooseCaptureMethod) j0Var, null, null, null, 0, null, null, false, null, null, 447, null));
        return Unit.f21504a;
    }

    public static final Unit n0(final deobf.unlinked.k.a aVar, final d2 d2Var, final j0 j0Var, final a aVar2) {
        deobf.com.withpersona.sdk2.inquiry.ln.r d10;
        deobf.com.withpersona.sdk2.inquiry.ln.h d11 = aVar.d();
        d10 = ln.z.d(d2Var, null, new Function1() { // from class: vo.f1
            @Override // kotlin.jvm.functions.Function1
            public final Object invoke(Object obj) {
                Unit o02;
                o02 = d2.o0(j0.this, aVar2, aVar, d2Var, (deobf.android.view.r.c) obj);
                return o02;
            }
        }, 1, null);
        d11.a(d10);
        return Unit.f21504a;
    }

    public static final Unit o0(j0 j0Var, a aVar, final deobf.unlinked.k.a aVar2, final d2 d2Var, deobf.android.view.r.c action) {
        Intrinsics.checkNotNullParameter(action, "$this$action");
        Object c10 = action.c();
        j0.ChooseCaptureMethod chooseCaptureMethod = c10 instanceof j0.ChooseCaptureMethod ? (j0.ChooseCaptureMethod) c10 : null;
        if (chooseCaptureMethod == null) {
            return Unit.f21504a;
        }
        j0.ChooseCaptureMethod chooseCaptureMethod2 = (j0.ChooseCaptureMethod) j0Var;
        action.e(new j0.WaitForAutocapture(chooseCaptureMethod2.getCurrentPart(), chooseCaptureMethod2.D(), chooseCaptureMethod2.getCaptureConfig(), b3.O(aVar, chooseCaptureMethod2.getCurrentPart().getSide()), chooseCaptureMethod.C(), chooseCaptureMethod.getPartIndex(), b3.y(action, false, 1, null), deobf.unlinked.ip.x.f19686c, aVar.getVideoCaptureConfig().getWebRtcJwt(), null, false, false, chooseCaptureMethod2.getCountryCode(), null, new Function0() { // from class: vo.t1
            @Override // kotlin.jvm.functions.Function0
            public final Object invoke() {
                Unit p02;
                p02 = d2.p0(deobf.unlinked.k.a.this, d2Var);
                return p02;
            }
        }, 11776, null));
        return Unit.f21504a;
    }

    public static final Unit p0(deobf.unlinked.k.a aVar, final d2 d2Var) {
        deobf.com.withpersona.sdk2.inquiry.ln.r d10;
        deobf.com.withpersona.sdk2.inquiry.ln.h d11 = aVar.d();
        d10 = ln.z.d(d2Var, null, new Function1() { // from class: vo.u1
            @Override // kotlin.jvm.functions.Function1
            public final Object invoke(Object obj) {
                Unit q02;
                q02 = d2.q0(d2.this, (deobf.android.view.r.c) obj);
                return q02;
            }
        }, 1, null);
        d11.a(d10);
        return Unit.f21504a;
    }

    public static final Unit q0(d2 d2Var, deobf.android.view.r.c action) {
        Intrinsics.checkNotNullParameter(action, "$this$action");
        Object c10 = action.c();
        j0.WaitForAutocapture waitForAutocapture = c10 instanceof j0.WaitForAutocapture ? (j0.WaitForAutocapture) c10 : null;
        if (waitForAutocapture != null) {
            action.e(j0.WaitForAutocapture.L(waitForAutocapture, null, null, null, null, null, 0, null, d2Var.videoCaptureHelper.d() ? deobf.unlinked.ip.x.b : deobf.unlinked.ip.x.f19686c, null, null, false, false, null, null, null, 32639, null));
        }
        return Unit.f21504a;
    }

    public static final Unit r0(deobf.unlinked.k.a aVar, final d2 d2Var, final j0 j0Var) {
        deobf.com.withpersona.sdk2.inquiry.ln.r d10;
        deobf.com.withpersona.sdk2.inquiry.ln.h d11 = aVar.d();
        d10 = ln.z.d(d2Var, null, new Function1() { // from class: vo.n1
            @Override // kotlin.jvm.functions.Function1
            public final Object invoke(Object obj) {
                Unit s02;
                s02 = d2.s0(d2.this, j0Var, (deobf.android.view.r.c) obj);
                return s02;
            }
        }, 1, null);
        d11.a(d10);
        return Unit.f21504a;
    }

    public static final Unit s0(d2 d2Var, j0 j0Var, deobf.android.view.r.c action) {
        Intrinsics.checkNotNullParameter(action, "$this$action");
        d2Var.documentSelectWorker.g();
        action.e(j0.ChooseCaptureMethod.H((j0.ChooseCaptureMethod) j0Var, null, null, null, 0, null, null, true, null, null, 447, null));
        return Unit.f21504a;
    }

    public static final Unit t0(deobf.unlinked.k.a aVar, d2 d2Var) {
        b3.S(aVar, d2Var.videoCaptureHelper);
        return Unit.f21504a;
    }

    public static final Unit u0(deobf.unlinked.k.a aVar) {
        b3.v(aVar);
        return Unit.f21504a;
    }

    public static final void v0(final deobf.unlinked.k.a aVar, final d2 d2Var, final b it) {
        deobf.com.withpersona.sdk2.inquiry.ln.r d10;
        Intrinsics.checkNotNullParameter(it, "it");
        deobf.com.withpersona.sdk2.inquiry.ln.h d11 = aVar.d();
        d10 = ln.z.d(d2Var, null, new Function1() { // from class: vo.p1
            @Override // kotlin.jvm.functions.Function1
            public final Object invoke(Object obj) {
                Unit w02;
                w02 = d2.w0(d2.this, aVar, it, (deobf.android.view.r.c) obj);
                return w02;
            }
        }, 1, null);
        d11.a(d10);
    }

    public static final Unit w0(d2 d2Var, deobf.unlinked.k.a aVar, b bVar, deobf.android.view.r.c action) {
        Intrinsics.checkNotNullParameter(action, "$this$action");
        d2Var.b1(aVar, bVar);
        return Unit.f21504a;
    }

    public static final Unit x0(deobf.unlinked.k.a aVar, d2 d2Var, final j0 j0Var) {
        deobf.com.withpersona.sdk2.inquiry.ln.r d10;
        deobf.com.withpersona.sdk2.inquiry.ln.h d11 = aVar.d();
        d10 = ln.z.d(d2Var, null, new Function1() { // from class: vo.j1
            @Override // kotlin.jvm.functions.Function1
            public final Object invoke(Object obj) {
                Unit y02;
                y02 = d2.y0(j0.this, (deobf.android.view.r.c) obj);
                return y02;
            }
        }, 1, null);
        d11.a(d10);
        return Unit.f21504a;
    }

    public static final Unit y0(j0 j0Var, deobf.android.view.r.c action) {
        Intrinsics.checkNotNullParameter(action, "$this$action");
        action.e(j0.ChooseCaptureMethod.H((j0.ChooseCaptureMethod) j0Var, null, null, null, 0, null, null, false, null, null, 255, null));
        return Unit.f21504a;
    }

    public static final Unit z0(a aVar, j0 j0Var, deobf.unlinked.k.a aVar2, d2 d2Var) {
        deobf.com.google.firebase.x3.h(aVar, (j0.j) j0Var, aVar2, d2Var.videoCaptureHelper, d2Var.trackingEventsLogger);
        return Unit.f21504a;
    }

    public final String Z(a.Strings strings, IdConfig.e eVar, String str, String str2) {
        String a10 = strings.getChooseCaptureMethodBody().a(str2, str, eVar);
        if (a10 != null) {
            return a10;
        }
        String string = this.applicationContext.getString(deobf.com.withpersona.sdk2.inquiry.jq.g.f20886r);
        Intrinsics.checkNotNullExpressionValue(string, "getString(...)");
        return string;
    }

    public final String a0(a.Strings strings, IdConfig.e eVar, String str, String str2) {
        String a10 = strings.getChooseCaptureMethodTitle().a(str2, str, eVar);
        if (a10 != null) {
            return a10;
        }
        String string = this.applicationContext.getString(deobf.com.withpersona.sdk2.inquiry.jq.g.f20887s);
        Intrinsics.checkNotNullExpressionValue(string, "getString(...)");
        return string;
    }

    public final String b0(a.Strings strings, IdConfig.e eVar, String str, String str2) {
        String a10 = strings.getConfirmCaptureTitle().a(str2, str, eVar);
        return a10 == null ? BuildConfig.FLAVOR : a10;
    }

    public final void b1(deobf.com.withpersona.sdk2.inquiry.ln.k<? super a, j0, ? extends b, ? extends Object>.a context, b output) {
        b3.b0(context, output, this.videoCaptureHelper);
    }

    public final String c0(a.Strings strings, IdConfig.e eVar) {
        String str = strings.w0().get(eVar);
        if (str != null) {
            return str;
        }
        String string = this.applicationContext.getString(deobf.com.withpersona.sdk2.inquiry.jq.g.f20890v);
        Intrinsics.checkNotNullExpressionValue(string, "getString(...)");
        return string;
    }

    public final void c1(deobf.com.withpersona.sdk2.inquiry.ln.r<? super a, j0, ? extends b>.c updater) {
        updater.d(new b.c(new InternalErrorInfo.WebRtcIntegrationErrorInfo("WebRTC is listed as the preferred or only capture method, but it has not been configured for this project.")));
    }

    public final String d0(a.Strings strings, IdConfig.e eVar) {
        String str = strings.B0().get(eVar);
        if (str != null) {
            return str;
        }
        String string = this.applicationContext.getString(deobf.com.withpersona.sdk2.inquiry.jq.g.f20891w);
        Intrinsics.checkNotNullExpressionValue(string, "getString(...)");
        return string;
    }

    @Override // deobf.com.withpersona.sdk2.inquiry.ln.k
    @Nullable
    public Snapshot g(@NotNull j0 state) {
        Intrinsics.checkNotNullParameter(state, "state");
        if (g0(state)) {
            return null;
        }
        return deobf.com.withpersona.sdk2.inquiry.nn.r.a(state);
    }

    public final String e0(j0 j0Var) {
        if ((j0Var instanceof j0.CountdownToCapture) || (j0Var instanceof j0.ReviewCapturedImage) || (j0Var instanceof j0.WaitForAutocapture) || (j0Var instanceof j0.FinalizeLocalVideoCapture) || (j0Var instanceof j0.f) || (j0Var instanceof j0.HolographicTorchDelay)) {
            return "camera_screen";
        }
        if ((j0Var instanceof j0.ChooseCaptureMethod) || (j0Var instanceof j0.ReviewSelectedImage) || (j0Var instanceof j0.ShowInstructions) || (j0Var instanceof j0.Submit) || (j0Var instanceof j0.AutoClassificationError) || (j0Var instanceof j0.AutoClassificationManualSelect) || (j0Var instanceof j0.RestartStep)) {
            return null;
        }
        throw new deobf.com.withpersona.sdk2.inquiry.zt.l();
    }

    public final boolean e1(j0 j0Var) {
        if ((j0Var instanceof j0.CountdownToCapture) || (j0Var instanceof j0.f) || (j0Var instanceof j0.WaitForAutocapture) || (j0Var instanceof j0.FinalizeLocalVideoCapture) || (j0Var instanceof j0.HolographicTorchDelay)) {
            return true;
        }
        if ((j0Var instanceof j0.ChooseCaptureMethod) || (j0Var instanceof j0.ReviewSelectedImage) || (j0Var instanceof j0.ShowInstructions) || (j0Var instanceof j0.Submit) || (j0Var instanceof j0.ReviewCapturedImage) || (j0Var instanceof j0.AutoClassificationError) || (j0Var instanceof j0.AutoClassificationManualSelect) || (j0Var instanceof j0.RestartStep)) {
            return false;
        }
        throw new deobf.com.withpersona.sdk2.inquiry.zt.l();
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r2v17, types: [android.os.Parcelable, java.lang.Object] */
    @Override // deobf.com.withpersona.sdk2.inquiry.ln.k
    @NotNull
    public j0 d(@NotNull a props, @Nullable Snapshot snapshot) {
        Intrinsics.checkNotNullParameter(props, "props");
        j0 j0Var = null;
        if (snapshot != null) {
            deobf.com.withpersona.sdk2.inquiry.ew.h b10 = snapshot.b();
            if (b10.I() <= 0) {
                b10 = null;
            }
            if (b10 != null) {
                Parcel obtain = Parcel.obtain();
                Intrinsics.checkNotNullExpressionValue(obtain, "obtain()");
                byte[] O = b10.O();
                obtain.unmarshall(O, 0, O.length);
                obtain.setDataPosition(0);
                ?? readParcelable = obtain.readParcelable(Snapshot.class.getClassLoader());
                Intrinsics.checkNotNull(readParcelable);
                Intrinsics.checkNotNullExpressionValue(readParcelable, "parcel.readParcelable<T>…class.java.classLoader)!!");
                obtain.recycle();
                j0Var = readParcelable;
            }
            j0Var = j0Var;
        }
        if (j0Var != null) {
            return j0Var;
        }
        if (props.getAutoClassificationConfig().getIsEnabled() && !this.videoCaptureHelper.c(props)) {
            if (props.u()) {
                return new j0.ChooseCaptureMethod(new i3.SideIdPart(IdConfig.e.f34631d), kotlin.collections.p.k(), kotlin.collections.p.k(), 0, props.getCountryCode(), new f.AutoClassifyConfig(props.getAutoClassificationConfig()), false, null, null, 320, null);
            }
            return new j0.WaitForAutocapture(new i3.SideIdPart(IdConfig.e.f34631d), kotlin.collections.p.k(), new f.AutoClassifyConfig(props.getAutoClassificationConfig()), props.getDesignVersion() == deobf.androidx.appcompat.widget.i.b ? deobf.com.google.firebase.y3.b.a.f35072c : deobf.com.google.firebase.y3.b.a.b, kotlin.collections.p.k(), 0, null, deobf.unlinked.ip.x.f19686c, props.getVideoCaptureConfig().getWebRtcJwt(), null, false, false, props.getCountryCode(), null, null, 28160, null);
        }
        return new j0.ShowInstructions(null, null, null, null, 0, props.getCountryCode(), null, null, 223, null);
    }

    public final deobf.com.withpersona.sdk2.inquiry.kr.m f1(Object obj, j0 j0Var) {
        return new deobf.com.withpersona.sdk2.inquiry.kr.m(obj, j0Var.getDidGoBack() ? deobf.com.withpersona.sdk2.inquiry.kr.l.b : deobf.com.withpersona.sdk2.inquiry.kr.l.f21779a);
    }

    public final boolean g0(j0 state) {
        while (state != null) {
            if ((state instanceof j0.AutoClassificationError) || (state instanceof j0.AutoClassificationManualSelect)) {
                return true;
            }
            state = state.getBackState();
        }
        return false;
    }

    public final deobf.com.withpersona.sdk2.inquiry.nn.m<Object> h0(Object obj, String str) {
        return new deobf.com.withpersona.sdk2.inquiry.nn.m<>(obj, str);
    }

    @Override // deobf.com.withpersona.sdk2.inquiry.ln.k
    @NotNull
    public Object f(@NotNull a renderProps, @NotNull j0 renderState, @NotNull deobf.com.withpersona.sdk2.inquiry.ln.k<? super a, j0, ? extends b, ? extends Object>.a context) {
        Intrinsics.checkNotNullParameter(renderProps, "renderProps");
        Intrinsics.checkNotNullParameter(renderState, "renderState");
        Intrinsics.checkNotNullParameter(context, "context");
        Object j02 = j0(renderProps, renderState, context);
        String e02 = e0(renderState);
        if (e02 != null) {
            j02 = h0(j02, e02);
        }
        if (!e1(renderState)) {
            context.b("close_camera", new d(null));
        }
        if (!this.videoCaptureHelper.f(renderProps) && deobf.com.withpersona.sdk2.inquiry.xq.g.e(this.applicationContext)) {
            context.b("output_webrtc_error", new e(context, this, null));
        }
        return f1(j02, renderState);
    }

    public final Object j0(final a renderProps, final j0 renderState, final deobf.com.withpersona.sdk2.inquiry.ln.k<? super a, j0, ? extends b, ? extends Object>.a context) {
        deobf.com.withpersona.sdk2.inquiry.dr.h takePhoto;
        RemoteImage idFrontPictograph;
        RemoteImage remoteImage;
        deobf.kotlin.jvm.internal.xu.c<? extends j0> b10 = kotlin.jvm.internal.d0.b(renderState.getClass());
        final deobf.com.withpersona.sdk2.inquiry.ln.h<? super b> hVar = new deobf.com.withpersona.sdk2.inquiry.ln.h() { // from class: vo.p0
            @Override // deobf.com.withpersona.sdk2.inquiry.ln.h
            public final void a(Object obj) {
                d2.v0(deobf.unlinked.k.a.this, this, (deobf.androidx.constraintlayout.widget.d2.b) obj);
            }
        };
        deobf.com.withpersona.sdk2.inquiry.ir.b.d(this.navigationStateManager, renderProps.getBackStepEnabled(), renderProps.getCancelButtonEnabled(), renderProps.getIsEnabled() && !(renderState instanceof j0.Submit), false, 8, null);
        boolean z10 = renderState instanceof j0.AutoClassificationError;
        if (z10) {
            takePhoto = deobf.com.roblox.protocols.mediapicker.h.a.f12629a;
        } else if (renderState instanceof j0.AutoClassificationManualSelect) {
            takePhoto = deobf.com.roblox.protocols.mediapicker.h.b.f12630a;
        } else if (renderState instanceof j0.ShowInstructions) {
            takePhoto = h.C0231h.f12636a;
        } else if (renderState instanceof j0.ChooseCaptureMethod) {
            takePhoto = new h.Prompt(((j0.ChooseCaptureMethod) renderState).getPartIndex());
        } else if ((renderState instanceof j0.WaitForAutocapture) || (renderState instanceof j0.CountdownToCapture) || (renderState instanceof j0.FinalizeLocalVideoCapture) || (renderState instanceof j0.f) || (renderState instanceof j0.HolographicTorchDelay)) {
            takePhoto = new h.TakePhoto(renderState.getPartIndex());
        } else if (renderState instanceof j0.ReviewCapturedImage) {
            takePhoto = new h.Check(((j0.ReviewCapturedImage) renderState).getPartIndex());
        } else if (renderState instanceof j0.ReviewSelectedImage) {
            takePhoto = new h.CheckUpload(((j0.ReviewSelectedImage) renderState).getPartIndex());
        } else if (renderState instanceof j0.Submit) {
            takePhoto = deobf.com.roblox.protocols.mediapicker.h.e.f12633a;
        } else {
            if (!(renderState instanceof j0.RestartStep)) {
                throw new deobf.com.withpersona.sdk2.inquiry.zt.l();
            }
            takePhoto = deobf.com.roblox.protocols.mediapicker.h.g.f12635a;
        }
        this.externalEventLogger.c(new deobf.androidx.appcompat.widget.i.c(renderProps.getFromStep(), takePhoto));
        if (!Intrinsics.c(this.previousStateClass, b10)) {
            TrackingEventsLogger.logInquiryPageViewEvent$default(this.trackingEventsLogger, renderProps.getFromStep(), takePhoto.toString(), false, 4, null);
            if (Intrinsics.c(b10, kotlin.jvm.internal.d0.b(j0.WaitForAutocapture.class))) {
                TrackingEventsLogger trackingEventsLogger = this.trackingEventsLogger;
                GovIdCaptureState govIdCaptureState = GovIdCaptureState.LOADING;
                IdConfig.e Q = b3.Q(renderState.getCurrentPart());
                TrackingEventsLogger.logGovernmentIdStateEvent$default(trackingEventsLogger, new GovernmentIdStateEventData(govIdCaptureState, null, Q != null ? b3.d0(Q) : null, null, 8, null), false, 2, null);
            }
            this.previousStateClass = b10;
        }
        if (renderState instanceof j0.ShowInstructions) {
            context.b("check_if_single_id_class", new f(renderProps, renderState, this, context, null));
            String title = renderProps.getStrings().getTitle();
            String prompt = renderProps.getStrings().getPrompt();
            String choose = renderProps.getStrings().getChoose();
            String instructionsDisclaimer = renderProps.getStrings().getInstructionsDisclaimer();
            List<EnabledIdClass> N = b3.N(renderProps);
            h hVar2 = new h(renderState, this, context, renderProps);
            NextStep.GovernmentId.AssetConfig.SelectPage selectPage = renderProps.getAssetConfig().getSelectPage();
            return new deobf.com.google.firebase.y3.e(title, prompt, choose, instructionsDisclaimer, N, this.navigationStateManager.b(), hVar2, renderProps.getStyles(), selectPage, renderProps.getIsEnabled(), new Function0() { // from class: vo.r0
                @Override // kotlin.jvm.functions.Function0
                public final Object invoke() {
                    Unit N0;
                    N0 = d2.N0(deobf.unlinked.k.a.this, this);
                    return N0;
                }
            }, new Function0() { // from class: vo.u0
                @Override // kotlin.jvm.functions.Function0
                public final Object invoke() {
                    Unit U0;
                    U0 = d2.U0(deobf.unlinked.k.a.this);
                    return U0;
                }
            }, ((j0.ShowInstructions) renderState).getError(), new Function0() { // from class: vo.v0
                @Override // kotlin.jvm.functions.Function0
                public final Object invoke() {
                    Unit V0;
                    V0 = d2.V0(deobf.unlinked.k.a.this, this, renderState);
                    return V0;
                }
            }, this.themeManager.a().getIconStyle(), renderProps.getStrings().getSelectPageNavBarTitle(), null, 65536, null);
        }
        if (renderState instanceof j0.ChooseCaptureMethod) {
            j0.ChooseCaptureMethod chooseCaptureMethod = (j0.ChooseCaptureMethod) renderState;
            final i3.SideIdPart currentPart = chooseCaptureMethod.getCurrentPart();
            if (chooseCaptureMethod.getChoosingDocumentToUpload()) {
                deobf.com.withpersona.sdk2.inquiry.ln.w.l(context, this.documentSelectWorker, kotlin.jvm.internal.d0.k(j.class), BuildConfig.FLAVOR, new Function1() { // from class: vo.w0
                    @Override // kotlin.jvm.functions.Function1
                    public final Object invoke(Object obj) {
                        deobf.com.withpersona.sdk2.inquiry.ln.r k02;
                        k02 = d2.k0(d2.this, currentPart, renderState, context, (deobf.com.google.android.material.j.a) obj);
                        return k02;
                    }
                });
            }
            NextStep.GovernmentId.AssetConfig.PromptPage promptPage = renderProps.getAssetConfig().getPromptPage();
            List<CaptureOptionNativeMobile> n10 = renderProps.n();
            String a02 = a0(renderProps.getStrings(), currentPart.getSide(), deobf.com.withpersona.sdk2.inquiry.vo.g.b(chooseCaptureMethod.getCaptureConfig()), chooseCaptureMethod.getCountryCode());
            String Z = Z(renderProps.getStrings(), currentPart.getSide(), deobf.com.withpersona.sdk2.inquiry.vo.g.b(chooseCaptureMethod.getCaptureConfig()), chooseCaptureMethod.getCountryCode());
            String chooseCaptureMethodCameraButton = renderProps.getStrings().getChooseCaptureMethodCameraButton();
            String chooseCaptureMethodUploadButton = renderProps.getStrings().getChooseCaptureMethodUploadButton();
            deobf.com.withpersona.sdk2.inquiry.ir.a b11 = this.navigationStateManager.b();
            Function0 function0 = new Function0() { // from class: vo.x0
                @Override // kotlin.jvm.functions.Function0
                public final Object invoke() {
                    Unit n02;
                    n02 = d2.n0(deobf.unlinked.k.a.this, this, renderState, renderProps);
                    return n02;
                }
            };
            Function0 function02 = new Function0() { // from class: vo.y0
                @Override // kotlin.jvm.functions.Function0
                public final Object invoke() {
                    Unit r02;
                    r02 = d2.r0(deobf.unlinked.k.a.this, this, renderState);
                    return r02;
                }
            };
            Function0 function03 = new Function0() { // from class: vo.z0
                @Override // kotlin.jvm.functions.Function0
                public final Object invoke() {
                    Unit t02;
                    t02 = d2.t0(deobf.unlinked.k.a.this, this);
                    return t02;
                }
            };
            Function0 function04 = new Function0() { // from class: vo.b1
                @Override // kotlin.jvm.functions.Function0
                public final Object invoke() {
                    Unit u02;
                    u02 = d2.u0(deobf.unlinked.k.a.this);
                    return u02;
                }
            };
            String error = chooseCaptureMethod.getError();
            Function0 function05 = new Function0() { // from class: vo.c1
                @Override // kotlin.jvm.functions.Function0
                public final Object invoke() {
                    Unit x02;
                    x02 = d2.x0(deobf.unlinked.k.a.this, this, renderState);
                    return x02;
                }
            };
            StepStyles.GovernmentIdStepStyle styles = renderProps.getStyles();
            IdConfig.e side = chooseCaptureMethod.getCurrentPart().getSide();
            int[] iArr = c.f34601a;
            int i10 = iArr[side.ordinal()];
            if (i10 != 1) {
                if (i10 != 2) {
                    if (i10 != 3) {
                        if (i10 != 4) {
                            if (i10 != 5) {
                                throw new deobf.com.withpersona.sdk2.inquiry.zt.l();
                            }
                            if (promptPage != null) {
                                idFrontPictograph = promptPage.getPassportSignaturePictograph();
                                remoteImage = idFrontPictograph;
                            }
                        } else if (promptPage != null) {
                            idFrontPictograph = promptPage.getBarcodePdf417Pictograph();
                            remoteImage = idFrontPictograph;
                        }
                    }
                    remoteImage = null;
                } else {
                    if (promptPage != null) {
                        idFrontPictograph = promptPage.getIdBackPictograph();
                        remoteImage = idFrontPictograph;
                    }
                    remoteImage = null;
                }
            } else if (deobf.com.withpersona.sdk2.inquiry.vo.g.a(chooseCaptureMethod.getCaptureConfig()) == deobf.com.withpersona.sdk2.inquiry.dp.e.f12557j) {
                if (promptPage != null) {
                    idFrontPictograph = promptPage.getPassportFrontPictograph();
                    remoteImage = idFrontPictograph;
                }
                remoteImage = null;
            } else {
                if (promptPage != null) {
                    idFrontPictograph = promptPage.getIdFrontPictograph();
                    remoteImage = idFrontPictograph;
                }
                remoteImage = null;
            }
            int i11 = iArr[chooseCaptureMethod.getCurrentPart().getSide().ordinal()];
            int i12 = i11 != 1 ? (i11 == 2 || i11 == 4) ? p3.f34949d : p3.f34950e : deobf.com.withpersona.sdk2.inquiry.vo.g.a(chooseCaptureMethod.getCaptureConfig()) == deobf.com.withpersona.sdk2.inquiry.dp.e.f12557j ? p3.f34951f : p3.f34950e;
            String requestPageNavBarTitle = renderProps.getStrings().getRequestPageNavBarTitle();
            if (requestPageNavBarTitle == null) {
                requestPageNavBarTitle = renderProps.getStrings().getCapturePageNavBarTitle();
            }
            return new deobf.com.google.firebase.y3.c(n10, a02, Z, chooseCaptureMethodCameraButton, chooseCaptureMethodUploadButton, b11, function0, function02, function03, function04, error, function05, styles, remoteImage, i12, requestPageNavBarTitle, null, 65536, null);
        }
        if (renderState instanceof j0.WaitForAutocapture) {
            return this.captureRenderer.n0(renderProps, (j0.WaitForAutocapture) renderState, context, this.videoCaptureHelper, hVar);
        }
        if (renderState instanceof j0.CountdownToCapture) {
            return this.captureRenderer.Y(renderProps, (j0.CountdownToCapture) renderState, context, this.videoCaptureHelper, hVar);
        }
        if (renderState instanceof j0.ReviewCapturedImage) {
            j0.ReviewCapturedImage reviewCapturedImage = (j0.ReviewCapturedImage) renderState;
            TrackingEventsLogger.logGovernmentIdStateEvent$default(this.trackingEventsLogger, new GovernmentIdStateEventData(GovIdCaptureState.CONFIRMING, null, b3.d0(reviewCapturedImage.getCurrentPart().getSide()), null, 8, null), false, 2, null);
            final deobf.com.withpersona.sdk2.inquiry.vo.f captureConfig = reviewCapturedImage.getCaptureConfig();
            IdConfig.IdSideConfig d10 = deobf.com.withpersona.sdk2.inquiry.vo.g.d(captureConfig, reviewCapturedImage.getCurrentPart().getSide());
            Frame frame = (Frame) CollectionsKt.d0(reviewCapturedImage.getIdForReview().j3());
            if (reviewCapturedImage.getSubmittingForAutoClassification()) {
                x3.j(renderProps, (j0.j) renderState, context, this.videoCaptureHelper, this.autoClassifyWorkerFactory);
            }
            return new AlertContainerScreen(deobf.com.withpersona.sdk2.inquiry.fq.y1.c(new deobf.com.google.firebase.y3.i(this.imageLoader, b3.M(renderProps.getStrings(), reviewCapturedImage.getCurrentPart().getSide(), deobf.com.withpersona.sdk2.inquiry.vo.g.b(reviewCapturedImage.getCaptureConfig()), reviewCapturedImage.getCountryCode()), renderProps.getStrings().getCaptureDisclaimer(), d10.getOverlay(), frame.getAbsoluteFilePath(), reviewCapturedImage.getCurrentPart().getSide(), deobf.com.withpersona.sdk2.inquiry.vo.g.a(captureConfig), this.navigationStateManager.b(), new Function0() { // from class: vo.a1
                @Override // kotlin.jvm.functions.Function0
                public final Object invoke() {
                    Unit z02;
                    z02 = d2.z0(deobf.androidx.constraintlayout.widget.d2.a.this, renderState, context, this);
                    return z02;
                }
            }, renderProps.getStrings().getButtonSubmit(), new Function0() { // from class: vo.l1
                @Override // kotlin.jvm.functions.Function0
                public final Object invoke() {
                    Unit A0;
                    A0 = d2.A0(d2.this, context, renderState, renderProps, captureConfig);
                    return A0;
                }
            }, renderProps.getStrings().getButtonRetake(), b0(renderProps.getStrings(), reviewCapturedImage.getCurrentPart().getSide(), deobf.com.withpersona.sdk2.inquiry.vo.g.b(reviewCapturedImage.getCaptureConfig()), reviewCapturedImage.getCountryCode()), new Function0() { // from class: vo.w1
                @Override // kotlin.jvm.functions.Function0
                public final Object invoke() {
                    Unit E0;
                    E0 = d2.E0(deobf.com.withpersona.sdk2.inquiry.ln.h.this);
                    return E0;
                }
            }, renderProps.getStyles(), reviewCapturedImage.getError(), new Function0() { // from class: vo.x1
                @Override // kotlin.jvm.functions.Function0
                public final Object invoke() {
                    Unit F0;
                    F0 = d2.F0(deobf.unlinked.k.a.this, this, renderState);
                    return F0;
                }
            }, renderProps.getAssetConfig().getCapturePage(), renderProps.getIsEnabled() && !reviewCapturedImage.getSubmittingForAutoClassification(), reviewCapturedImage.getSubmittingForAutoClassification(), renderProps.getReviewCaptureButtonsAxis(), renderProps.getDesignVersion(), false, renderProps.getStrings().getCheckPageNavBarTitle(), null, 20971520, null)), null, 2, null);
        }
        if (!(renderState instanceof j0.ReviewSelectedImage)) {
            if (renderState instanceof j0.Submit) {
                j0.Submit submit = (j0.Submit) renderState;
                deobf.com.withpersona.sdk2.inquiry.ln.w.l(context, this.submitVerificationWorkerFactory.a(renderProps.getSessionToken(), renderProps.getInquiryId(), renderProps.getFromComponent(), renderProps.getFromStep(), submit.getGovernmentIdRequestArguments(), submit.getWebRtcObjectId(), submit.getCameraProperties()), kotlin.jvm.internal.d0.k(deobf.com.withpersona.sdk2.inquiry.dp.f.class), BuildConfig.FLAVOR, new Function1() { // from class: vo.q0
                    @Override // kotlin.jvm.functions.Function1
                    public final Object invoke(Object obj) {
                        deobf.com.withpersona.sdk2.inquiry.ln.r O0;
                        O0 = d2.O0(d2.this, context, (deobf.unlinked.f.b) obj);
                        return O0;
                    }
                });
                deobf.com.withpersona.sdk2.inquiry.ir.b.d(this.navigationStateManager, false, false, false, false, 12, null);
                return new y3.k(renderProps.getStrings().getProcessingTitle(), renderProps.getStrings().getProcessingDescription(), renderProps.getStyles(), renderProps.getAssetConfig().getPendingPage(), this.navigationStateManager.b(), new Function0() { // from class: vo.s0
                    @Override // kotlin.jvm.functions.Function0
                    public final Object invoke() {
                        Unit S0;
                        S0 = d2.S0(d2.this, context);
                        return S0;
                    }
                }, new Function0() { // from class: vo.t0
                    @Override // kotlin.jvm.functions.Function0
                    public final Object invoke() {
                        Unit T0;
                        T0 = d2.T0(d2.this, context);
                        return T0;
                    }
                }, renderProps.getPendingPageTextVerticalPosition(), false, renderProps.getStrings().getPendingPageNavBarTitle(), null, 1280, null);
            }
            if (renderState instanceof j0.FinalizeLocalVideoCapture) {
                return this.localVideoCaptureRenderer.i(renderProps, (j0.FinalizeLocalVideoCapture) renderState, context, this.videoCaptureHelper);
            }
            if (renderState instanceof j0.f) {
                return this.webRtcRenderer.j(renderProps, (j0.f) renderState, context, this.videoCaptureHelper);
            }
            if (renderState instanceof j0.HolographicTorchDelay) {
                return this.captureRenderer.j0(renderProps, (j0.HolographicTorchDelay) renderState, context, this.videoCaptureHelper, hVar);
            }
            if (z10) {
                return this.autoClassificationRenderer.n(renderProps, (j0.AutoClassificationError) renderState, context, this.videoCaptureHelper);
            }
            if (renderState instanceof j0.AutoClassificationManualSelect) {
                return this.autoClassificationRenderer.t(renderProps, (j0.AutoClassificationManualSelect) renderState, context, this.videoCaptureHelper);
            }
            if (!(renderState instanceof j0.RestartStep)) {
                throw new deobf.com.withpersona.sdk2.inquiry.zt.l();
            }
            context.b("restart_step", new g(context, d(renderProps, null), null));
            return new deobf.com.google.firebase.y3.h(null, 1, null);
        }
        j0.ReviewSelectedImage reviewSelectedImage = (j0.ReviewSelectedImage) renderState;
        TrackingEventsLogger.logGovernmentIdStateEvent$default(this.trackingEventsLogger, new GovernmentIdStateEventData(GovIdCaptureState.CONFIRMING, null, b3.d0(reviewSelectedImage.getCurrentPart().getSide()), null, 8, null), false, 2, null);
        i3.SideIdPart currentPart2 = reviewSelectedImage.getCurrentPart();
        if (reviewSelectedImage.getSubmittingForAutoClassification()) {
            x3.j(renderProps, (j0.j) renderState, context, this.videoCaptureHelper, this.autoClassifyWorkerFactory);
        }
        deobf.com.roblox.client.l6.s sVar = this.imageLoader;
        String d02 = d0(renderProps.getStrings(), currentPart2.getSide());
        String c02 = c0(renderProps.getStrings(), currentPart2.getSide());
        String reviewSelectedImageConfirmButton = renderProps.getStrings().getReviewSelectedImageConfirmButton();
        String reviewSelectedImageChooseAnotherButton = renderProps.getStrings().getReviewSelectedImageChooseAnotherButton();
        String absoluteFilePath = ((Frame) CollectionsKt.d0(reviewSelectedImage.getIdForReview().j3())).getAbsoluteFilePath();
        String mimeType = ((Frame) CollectionsKt.d0(reviewSelectedImage.getIdForReview().j3())).getMimeType();
        String fileName = reviewSelectedImage.getFileName();
        deobf.com.withpersona.sdk2.inquiry.ir.a b12 = this.navigationStateManager.b();
        String error2 = reviewSelectedImage.getError();
        boolean submittingForAutoClassification = reviewSelectedImage.getSubmittingForAutoClassification();
        StepStyles.GovernmentIdStepStyle styles2 = renderProps.getStyles();
        String reviewUploadPageNavBarTitle = renderProps.getStrings().getReviewUploadPageNavBarTitle();
        if (reviewUploadPageNavBarTitle == null) {
            reviewUploadPageNavBarTitle = renderProps.getStrings().getCapturePageNavBarTitle();
        }
        return new deobf.com.google.firebase.y3.j(sVar, d02, c02, reviewSelectedImageConfirmButton, reviewSelectedImageChooseAnotherButton, absoluteFilePath, mimeType, fileName, b12, new Function0() { // from class: vo.y1
            @Override // kotlin.jvm.functions.Function0
            public final Object invoke() {
                Unit H0;
                H0 = d2.H0(deobf.androidx.constraintlayout.widget.d2.a.this, renderState, context, this);
                return H0;
            }
        }, new Function0() { // from class: vo.z1
            @Override // kotlin.jvm.functions.Function0
            public final Object invoke() {
                Unit I0;
                I0 = d2.I0(deobf.unlinked.k.a.this, this);
                return I0;
            }
        }, new Function0() { // from class: vo.a2
            @Override // kotlin.jvm.functions.Function0
            public final Object invoke() {
                Unit J0;
                J0 = d2.J0(deobf.unlinked.k.a.this, this);
                return J0;
            }
        }, new Function0() { // from class: vo.b2
            @Override // kotlin.jvm.functions.Function0
            public final Object invoke() {
                Unit K0;
                K0 = d2.K0(deobf.unlinked.k.a.this);
                return K0;
            }
        }, error2, new Function0() { // from class: vo.c2
            @Override // kotlin.jvm.functions.Function0
            public final Object invoke() {
                Unit L0;
                L0 = d2.L0(deobf.unlinked.k.a.this, this, renderState);
                return L0;
            }
        }, styles2, submittingForAutoClassification, reviewUploadPageNavBarTitle, null, 262144, null);
    }
}
