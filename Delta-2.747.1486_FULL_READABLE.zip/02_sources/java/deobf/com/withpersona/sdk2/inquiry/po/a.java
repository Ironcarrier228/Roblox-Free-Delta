package deobf.com.withpersona.sdk2.inquiry.po;

import com.appsflyer.share.attribution.RequestError;
import com.github.luben.zstd.BuildConfig;
import com.google.mlkit.vision.barcode.common.Barcode;
import com.withpersona.sdk2.inquiry.network.core.InternalErrorInfo;
import deobf.kotlin.dv.h;
import deobf.kotlin.dv.i;
import deobf.com.withpersona.sdk2.inquiry.gu.f;
import deobf.com.withpersona.sdk2.inquiry.gu.m;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import deobf.com.withpersona.sdk2.inquiry.ln.o;
import deobf.com.withpersona.sdk2.inquiry.ls.j;
import deobf.com.withpersona.sdk2.inquiry.no.e;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import deobf.com.withpersona.sdk2.inquiry.sw.x;

@Metadata(d1 = {"\u00006\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010\u000b\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\r\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u00012\b\u0012\u0004\u0012\u00020\u00020\u0003:\u0002\u0016\u000fB)\b\u0002\u0012\u0006\u0010\u0005\u001a\u00020\u0004\u0012\u0006\u0010\u0007\u001a\u00020\u0006\u0012\u0006\u0010\b\u001a\u00020\u0004\u0012\u0006\u0010\n\u001a\u00020\t¢\u0006\u0004\b\u000b\u0010\fJ\u001b\u0010\u000f\u001a\u00020\u000e2\n\u0010\r\u001a\u0006\u0012\u0002\b\u00030\u0001H\u0016¢\u0006\u0004\b\u000f\u0010\u0010J\u001b\u0010\u0011\u001a\u00020\u000e2\n\u0010\r\u001a\u0006\u0012\u0002\b\u00030\u0003H\u0016¢\u0006\u0004\b\u0011\u0010\u0012J\u0015\u0010\u0014\u001a\b\u0012\u0004\u0012\u00020\u00020\u0013H\u0016¢\u0006\u0004\b\u0014\u0010\u0015R\u0014\u0010\u0005\u001a\u00020\u00048\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b\u0016\u0010\u0017R\u0014\u0010\u0007\u001a\u00020\u00068\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b\u0011\u0010\u0018R\u0017\u0010\b\u001a\u00020\u00048\u0006¢\u0006\f\n\u0004\b\u0019\u0010\u0017\u001a\u0004\b\u001a\u0010\u001bR\u0017\u0010\n\u001a\u00020\t8\u0006¢\u0006\f\n\u0004\b\u001c\u0010\u001d\u001a\u0004\b\u001e\u0010\u001f¨\u0006 "}, d2 = {"Lpo/a;", "Lln/o;", "Lpo/a$b;", "Lls/j;", BuildConfig.FLAVOR, "sessionToken", "Lpo/c;", "service", "documentId", "Lno/e$b;", "remoteDocument", "<init>", "(Ljava/lang/String;Lpo/c;Ljava/lang/String;Lno/e$b;)V", "otherWorker", BuildConfig.FLAVOR, deobf.android.view.xe.a.f36648e, "(Lln/o;)Z", "c", "(Lls/j;)Z", "Ldv/h;", "run", "()Ldv/h;", deobf.android.view.k6.b.f21144e, "Ljava/lang/String;", "Lpo/c;", "d", "getDocumentId", "()Ljava/lang/String;", "e", "Lno/e$b;", "f", "()Lno/e$b;", "document_release"}, k = 1, mv = {2, 2, 0}, xi = 48)
// dex: classes3.dex
public final class a implements o<b>, j<b> {

    @NotNull
    public final String sessionToken;

    @NotNull
    public final deobf.com.withpersona.sdk2.inquiry.po.c service;

    @NotNull
    public final String documentId;

    @NotNull
    public final e.Remote remoteDocument;

    @Metadata(d1 = {"\u0000&\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\u0018\u00002\u00020\u0001B\u0011\b\u0007\u0012\u0006\u0010\u0003\u001a\u00020\u0002¢\u0006\u0004\b\u0004\u0010\u0005J'\u0010\f\u001a\u00020\u000b2\u0006\u0010\u0007\u001a\u00020\u00062\u0006\u0010\b\u001a\u00020\u00062\u0006\u0010\n\u001a\u00020\tH\u0000¢\u0006\u0004\b\f\u0010\rR\u0014\u0010\u0003\u001a\u00020\u00028\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b\f\u0010\u000e¨\u0006\u000f"}, d2 = {"Lpo/a$a;", BuildConfig.FLAVOR, "Lpo/c;", "service", "<init>", "(Lpo/c;)V", BuildConfig.FLAVOR, "sessionToken", "documentId", "Lno/e$b;", "remoteDocument", "Lpo/a;", deobf.android.view.xe.a.f36648e, "(Ljava/lang/String;Ljava/lang/String;Lno/e$b;)Lpo/a;", "Lpo/c;", "document_release"}, k = 1, mv = {2, 2, 0}, xi = 48)
    public static final class C0563a {

        @NotNull
        public final deobf.com.withpersona.sdk2.inquiry.po.c service;

        public C0563a(@NotNull deobf.com.withpersona.sdk2.inquiry.po.c service) {
            Intrinsics.checkNotNullParameter(service, "service");
            this.service = service;
        }

        @NotNull
        public final a a(@NotNull String sessionToken, @NotNull String documentId, @NotNull e.Remote remoteDocument) {
            Intrinsics.checkNotNullParameter(sessionToken, "sessionToken");
            Intrinsics.checkNotNullParameter(documentId, "documentId");
            Intrinsics.checkNotNullParameter(remoteDocument, "remoteDocument");
            return new a(sessionToken, this.service, documentId, remoteDocument, null);
        }
    }

    @Metadata(d1 = {"\u0000\u0016\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\b6\u0018\u00002\u00020\u0001:\u0002\u0004\u0005B\t\b\u0004¢\u0006\u0004\b\u0002\u0010\u0003\u0082\u0001\u0002\u0006\u0007¨\u0006\b"}, d2 = {"Lpo/a$b;", BuildConfig.FLAVOR, "<init>", "()V", deobf.android.view.k6.b.f21144e, deobf.android.view.xe.a.f36648e, "Lpo/a$b$a;", "Lpo/a$b$b;", "document_release"}, k = 1, mv = {2, 2, 0}, xi = 48)
    public static abstract class b {

        @Metadata(d1 = {"\u0000.\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0006\b\u0086\b\u0018\u00002\u00020\u0001B\u000f\u0012\u0006\u0010\u0003\u001a\u00020\u0002¢\u0006\u0004\b\u0004\u0010\u0005J\u0010\u0010\u0007\u001a\u00020\u0006HÖ\u0001¢\u0006\u0004\b\u0007\u0010\bJ\u0010\u0010\n\u001a\u00020\tHÖ\u0001¢\u0006\u0004\b\n\u0010\u000bJ\u001a\u0010\u000f\u001a\u00020\u000e2\b\u0010\r\u001a\u0004\u0018\u00010\fHÖ\u0003¢\u0006\u0004\b\u000f\u0010\u0010R\u0017\u0010\u0003\u001a\u00020\u00028\u0006¢\u0006\f\n\u0004\b\u0011\u0010\u0012\u001a\u0004\b\u0011\u0010\u0013¨\u0006\u0014"}, d2 = {"Lpo/a$b$a;", "Lpo/a$b;", "Lcom/withpersona/sdk2/inquiry/network/core/InternalErrorInfo;", "cause", "<init>", "(Lcom/withpersona/sdk2/inquiry/network/core/InternalErrorInfo;)V", BuildConfig.FLAVOR, "toString", "()Ljava/lang/String;", BuildConfig.FLAVOR, "hashCode", "()I", BuildConfig.FLAVOR, "other", BuildConfig.FLAVOR, "equals", "(Ljava/lang/Object;)Z", deobf.android.view.xe.a.f36648e, "Lcom/withpersona/sdk2/inquiry/network/core/InternalErrorInfo;", "()Lcom/withpersona/sdk2/inquiry/network/core/InternalErrorInfo;", "document_release"}, k = 1, mv = {2, 2, 0}, xi = 48)
        public static final /* data */ class Error extends b {

            @NotNull
            public final InternalErrorInfo cause;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            public Error(@NotNull InternalErrorInfo cause) {
                super(null);
                Intrinsics.checkNotNullParameter(cause, "cause");
                this.cause = cause;
            }

            @NotNull
            public final InternalErrorInfo getCause() {
                return this.cause;
            }

            public boolean equals(@Nullable Object other) {
                if (this == other) {
                    return true;
                }
                return (other instanceof Error) && Intrinsics.c(this.cause, ((Error) other).cause);
            }

            public int hashCode() {
                return this.cause.hashCode();
            }

            @NotNull
            public String toString() {
                return "Error(cause=" + this.cause + ")";
            }
        }

        @Metadata(d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\bÆ\u0002\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003¨\u0006\u0004"}, d2 = {"Lpo/a$b$b;", "Lpo/a$b;", "<init>", "()V", "document_release"}, k = 1, mv = {2, 2, 0}, xi = 48)
        public static final class C0565b extends b {

            @NotNull
            public static final C0565b f29235a = new C0565b();

            public C0565b() {
                super(null);
            }
        }

        public /* synthetic */ b(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }

        public b() {
        }
    }

    @Metadata(d1 = {"\u0000\u0010\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0002\b\u0002\u0010\u0003\u001a\u00020\u0002*\b\u0012\u0004\u0012\u00020\u00010\u0000H\n¢\u0006\u0004\b\u0003\u0010\u0004"}, d2 = {"Ldv/i;", "Lpo/a$b;", BuildConfig.FLAVOR, "<anonymous>", "(Ldv/i;)V"}, k = 3, mv = {2, 2, 0})
    @f(c = "com.withpersona.sdk2.inquiry.document.network.DocumentFileDeleteWorker$run$1", f = "DocumentFileDeleteWorker.kt", l = {Barcode.FORMAT_EAN_13, 38, RequestError.NETWORK_FAILURE}, m = "invokeSuspend")
    public static final class c extends m implements Function2<i<? super b>, deobf.kotlin.eu.b<? super Unit>, Object> {

        public Object f29236t;

        public Object f29237u;

        public int f29238v;

        public int f29239w;

        public int f29240x;

        public /* synthetic */ Object f29241y;

        @Metadata(d1 = {"\u0000\b\n\u0002\u0018\u0002\n\u0002\b\u0002\u0010\u0001\u001a\u0006\u0012\u0002\b\u00030\u0000H\n¢\u0006\u0004\b\u0001\u0010\u0002"}, d2 = {"Lsw/x;", "<anonymous>", "()Lsw/x;"}, k = 3, mv = {2, 2, 0})
        @f(c = "com.withpersona.sdk2.inquiry.document.network.DocumentFileDeleteWorker$run$1$1", f = "DocumentFileDeleteWorker.kt", l = {33}, m = "invokeSuspend")
        public static final class C0566a extends m implements Function1<deobf.kotlin.eu.b<? super x<?>>, Object> {

            public int f29243t;

            public final /* synthetic */ a f29244u;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            public C0566a(a aVar, deobf.kotlin.eu.b<? super C0566a> bVar) {
                super(1, bVar);
                this.f29244u = aVar;
            }

            @Override // deobf.com.withpersona.sdk2.inquiry.gu.a
            public final deobf.kotlin.eu.b<Unit> create(deobf.kotlin.eu.b<?> bVar) {
                return new C0566a(this.f29244u, bVar);
            }

            @Override // deobf.com.withpersona.sdk2.inquiry.gu.a
            public final Object invokeSuspend(Object obj) {
                Object e10 = deobf.kotlin.fu.c.e();
                int i10 = this.f29243t;
                if (i10 != 0) {
                    if (i10 != 1) {
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                    deobf.com.withpersona.sdk2.inquiry.zt.o.b(obj);
                    return obj;
                }
                deobf.com.withpersona.sdk2.inquiry.zt.o.b(obj);
                deobf.com.withpersona.sdk2.inquiry.po.c cVar = this.f29244u.service;
                String str = this.f29244u.sessionToken;
                String documentFileId = this.f29244u.getRemoteDocument().getDocumentFileId();
                this.f29243t = 1;
                Object b = cVar.b(str, documentFileId, this);
                return b == e10 ? e10 : b;
            }

            @Override // kotlin.jvm.functions.Function1
            public final Object invoke(deobf.kotlin.eu.b<? super x<?>> bVar) {
                return ((C0566a) create(bVar)).invokeSuspend(Unit.f21504a);
            }
        }

        public c(deobf.kotlin.eu.b<? super c> bVar) {
            super(2, bVar);
        }

        @Override // deobf.com.withpersona.sdk2.inquiry.gu.a
        public final deobf.kotlin.eu.b<Unit> create(Object obj, deobf.kotlin.eu.b<?> bVar) {
            c cVar = a.this.new c(bVar);
            cVar.f29241y = obj;
            return cVar;
        }

        /* JADX WARN: Code restructure failed: missing block: B:16:0x009c, code lost:

            if (r0.emit(r4, r8) == r1) goto L24;
         */
        /* JADX WARN: Code restructure failed: missing block: B:17:0x009e, code lost:

            return r1;
         */
        /* JADX WARN: Code restructure failed: missing block: B:22:0x0071, code lost:

            if (r0.emit(r5, r8) == r1) goto L24;
         */
        /* JADX WARN: Code restructure failed: missing block: B:24:0x004a, code lost:

            if (r9 == r1) goto L24;
         */
        /* JADX WARN: Removed duplicated region for block: B:15:0x0078  */
        @Override // deobf.com.withpersona.sdk2.inquiry.gu.a
        public final java.lang.Object invokeSuspend(java.lang.Object r9) {
            /*
                r8 = this;
                java.lang.Object r0 = r8.f29241y
                deobf.kotlin.dv.i r0 = (deobf.kotlin.dv.i) r0
                java.lang.Object r1 = deobf.kotlin.fu.c.e()
                int r2 = r8.f29240x
                r3 = 3
                r4 = 2
                r5 = 1
                r6 = 0
                if (r2 == 0) goto L37
                if (r2 == r5) goto L33
                if (r2 == r4) goto L2b
                if (r2 != r3) goto L23
                java.lang.Object r0 = r8.f29237u
                com.withpersona.sdk2.inquiry.network.core.InternalErrorInfo$NetworkErrorInfo r0 = (com.withpersona.sdk2.inquiry.network.core.InternalErrorInfo.NetworkErrorInfo) r0
                java.lang.Object r0 = r8.f29236t
                com.withpersona.sdk2.inquiry.network.core.NetworkCallResult r0 = (com.withpersona.sdk2.inquiry.network.core.NetworkCallResult) r0
                deobf.com.withpersona.sdk2.inquiry.zt.o.b(r9)
                goto L9f
            L23:
                java.lang.IllegalStateException r9 = new java.lang.IllegalStateException
                java.lang.String r0 = "call to 'resume' before 'invoke' with coroutine"
                r9.<init>(r0)
                throw r9
            L2b:
                java.lang.Object r2 = r8.f29236t
                com.withpersona.sdk2.inquiry.network.core.NetworkCallResult r2 = (com.withpersona.sdk2.inquiry.network.core.NetworkCallResult) r2
                deobf.com.withpersona.sdk2.inquiry.zt.o.b(r9)
                goto L74
            L33:
                deobf.com.withpersona.sdk2.inquiry.zt.o.b(r9)
                goto L4d
            L37:
                deobf.com.withpersona.sdk2.inquiry.zt.o.b(r9)
                po.a$c$a r9 = new po.a$c$a
                deobf.com.withpersona.sdk2.inquiry.po.a r2 = deobf.com.withpersona.sdk2.inquiry.po.a.this
                r7 = 0
                r9.<init>(r2, r7)
                r8.f29241y = r0
                r8.f29240x = r5
                java.lang.Object r9 = com.withpersona.sdk2.inquiry.network.core.NetworkUtilsKt.enqueueRetriableRequestWithRetry(r9, r8)
                if (r9 != r1) goto L4d
                goto L9e
            L4d:
                r2 = r9
                com.withpersona.sdk2.inquiry.network.core.NetworkCallResult r2 = (com.withpersona.sdk2.inquiry.network.core.NetworkCallResult) r2
                boolean r9 = r2 instanceof com.withpersona.sdk2.inquiry.network.core.NetworkCallResult.Success
                if (r9 == 0) goto L74
                r9 = r2
                com.withpersona.sdk2.inquiry.network.core.NetworkCallResult$Success r9 = (com.withpersona.sdk2.inquiry.network.core.NetworkCallResult.Success) r9
                java.lang.Object r9 = r9.getResponse()
                po.a$b$b r5 = deobf.com.withpersona.sdk2.inquiry.po.a.b.C0565b.f29235a
                r8.f29241y = r0
                r8.f29236t = r2
                java.lang.Object r9 = deobf.com.withpersona.sdk2.inquiry.gu.l.a(r9)
                r8.f29237u = r9
                r8.f29238v = r6
                r8.f29239w = r6
                r8.f29240x = r4
                java.lang.Object r9 = r0.emit(r5, r8)
                if (r9 != r1) goto L74
                goto L9e
            L74:
                boolean r9 = r2 instanceof com.withpersona.sdk2.inquiry.network.core.NetworkCallResult.Failure
                if (r9 == 0) goto L9f
                r9 = r2
                com.withpersona.sdk2.inquiry.network.core.NetworkCallResult$Failure r9 = (com.withpersona.sdk2.inquiry.network.core.NetworkCallResult.Failure) r9
                com.withpersona.sdk2.inquiry.network.core.InternalErrorInfo$NetworkErrorInfo r9 = r9.getNetworkErrorInfo()
                po.a$b$a r4 = new po.a$b$a
                r4.<init>(r9)
                java.lang.Object r5 = deobf.com.withpersona.sdk2.inquiry.gu.l.a(r0)
                r8.f29241y = r5
                r8.f29236t = r2
                java.lang.Object r9 = deobf.com.withpersona.sdk2.inquiry.gu.l.a(r9)
                r8.f29237u = r9
                r8.f29238v = r6
                r8.f29239w = r6
                r8.f29240x = r3
                java.lang.Object r9 = r0.emit(r4, r8)
                if (r9 != r1) goto L9f
            L9e:
                return r1
            L9f:
                kotlin.Unit r9 = kotlin.Unit.f21504a
                return r9
            */
            throw new UnsupportedOperationException("Method not decompiled: deobf.com.withpersona.sdk2.inquiry.po.a.c.invokeSuspend(java.lang.Object):java.lang.Object");
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(i<? super b> iVar, deobf.kotlin.eu.b<? super Unit> bVar) {
            return ((c) create(iVar, bVar)).invokeSuspend(Unit.f21504a);
        }
    }

    public /* synthetic */ a(String str, deobf.com.withpersona.sdk2.inquiry.po.c cVar, String str2, e.Remote remote, DefaultConstructorMarker defaultConstructorMarker) {
        this(str, cVar, str2, remote);
    }

    @Override // deobf.com.withpersona.sdk2.inquiry.ln.o
    public boolean a(@NotNull o<?> otherWorker) {
        Intrinsics.checkNotNullParameter(otherWorker, "otherWorker");
        if (!(otherWorker instanceof a)) {
            return false;
        }
        a aVar = (a) otherWorker;
        return Intrinsics.c(this.sessionToken, aVar.sessionToken) && Intrinsics.c(this.remoteDocument, aVar.remoteDocument);
    }

    @Override // deobf.com.withpersona.sdk2.inquiry.ls.j
    public boolean b(@NotNull j<?> jVar) {
        return super.b(jVar);
    }

    @Override // deobf.com.withpersona.sdk2.inquiry.ls.j
    public boolean c(@NotNull j<?> otherWorker) {
        Intrinsics.checkNotNullParameter(otherWorker, "otherWorker");
        if (!(otherWorker instanceof a)) {
            return false;
        }
        a aVar = (a) otherWorker;
        return Intrinsics.c(this.sessionToken, aVar.sessionToken) && Intrinsics.c(this.remoteDocument, aVar.remoteDocument);
    }

    @NotNull
    public final e.Remote getRemoteDocument() {
        return this.remoteDocument;
    }

    @Override // deobf.com.withpersona.sdk2.inquiry.ln.o, deobf.com.withpersona.sdk2.inquiry.ls.j
    @NotNull
    public h<b> run() {
        return deobf.kotlin.dv.j.w(new c(null));
    }

    public a(String str, deobf.com.withpersona.sdk2.inquiry.po.c cVar, String str2, e.Remote remote) {
        this.sessionToken = str;
        this.service = cVar;
        this.documentId = str2;
        this.remoteDocument = remote;
    }
}
