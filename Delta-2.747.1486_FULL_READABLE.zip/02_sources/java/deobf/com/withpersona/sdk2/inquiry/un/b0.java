package deobf.com.withpersona.sdk2.inquiry.un;

import android.content.Context;
import com.github.luben.zstd.BuildConfig;
import com.withpersona.sdk2.camera.camera2.Camera2PreviewView;
import com.withpersona.sdk2.inquiry.tracking.TrackingEventsLogger;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import kotlin.Metadata;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(d1 = {"\u0000v\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u001b\n\u0002\u0010\b\n\u0002\b\u0004\u0018\u00002\u00020\u0001:\u0001(B\u0087\u0001\b\u0007\u0012\u0006\u0010\u0003\u001a\u00020\u0002\u0012\u0006\u0010\u0005\u001a\u00020\u0004\u0012\u0006\u0010\u0007\u001a\u00020\u0006\u0012\u0006\u0010\t\u001a\u00020\b\u0012\u0006\u0010\u000b\u001a\u00020\n\u0012\u0006\u0010\r\u001a\u00020\f\u0012\u0006\u0010\u000f\u001a\u00020\u000e\u0012\u0006\u0010\u0011\u001a\u00020\u0010\u0012\b\b\u0001\u0010\u0013\u001a\u00020\u0012\u0012\b\b\u0001\u0010\u0015\u001a\u00020\u0014\u0012\b\b\u0001\u0010\u0017\u001a\u00020\u0016\u0012\b\b\u0001\u0010\u0019\u001a\u00020\u0018\u0012\n\b\u0001\u0010\u001b\u001a\u0004\u0018\u00010\u001a\u0012\b\b\u0001\u0010\u001d\u001a\u00020\u001c¢\u0006\u0004\b\u001e\u0010\u001fJ\r\u0010!\u001a\u00020 ¢\u0006\u0004\b!\u0010\"J\r\u0010#\u001a\u00020\u001c¢\u0006\u0004\b#\u0010$J\r\u0010&\u001a\u00020%¢\u0006\u0004\b&\u0010'R\u0014\u0010\u0003\u001a\u00020\u00028\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b(\u0010)R\u0014\u0010\u0005\u001a\u00020\u00048\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b*\u0010+R\u0014\u0010\u0007\u001a\u00020\u00068\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b,\u0010-R\u0014\u0010\t\u001a\u00020\b8\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b.\u0010/R\u0014\u0010\u000b\u001a\u00020\n8\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b0\u00101R\u0014\u0010\r\u001a\u00020\f8\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b!\u00102R\u0014\u0010\u000f\u001a\u00020\u000e8\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b3\u00104R\u0014\u0010\u0011\u001a\u00020\u00108\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b&\u00105R\u0014\u0010\u0013\u001a\u00020\u00128\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b#\u00106R\u0014\u0010\u0015\u001a\u00020\u00148\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b7\u00108R\u0014\u0010\u0017\u001a\u00020\u00168\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b9\u0010:R\u0014\u0010\u0019\u001a\u00020\u00188\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b;\u0010<R\u0016\u0010\u001b\u001a\u0004\u0018\u00010\u001a8\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b=\u0010>R\u0014\u0010\u001d\u001a\u00020\u001c8\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b?\u0010@R\u0016\u0010D\u001a\u00020A8\u0002@\u0002X\u0082\u000e¢\u0006\u0006\n\u0004\bB\u0010C¨\u0006E"}, d2 = {"Lun/b0;", BuildConfig.FLAVOR, "Landroid/content/Context;", "context", "Lyn/a;", "cameraStatsManager", "Ler/c;", "sdkFilesManager", "Lun/i0;", "cameraChoiceHelper", "Lzq/a;", "coroutineScopeFactory", "Lcom/withpersona/sdk2/inquiry/tracking/TrackingEventsLogger;", "trackingEventsLogger", "Ldr/c;", "externalEventLogger", "Lto/e;", "featureFlagManager", "Lun/k0;", "cameraChoices", "Lcom/withpersona/sdk2/camera/camera2/Camera2PreviewView;", "previewView", "Lun/g;", "analyzer", "Lzn/a;", "videoCaptureMethod", "Lks/a;", "webRtcManager", BuildConfig.FLAVOR, "isAudioRequired", "<init>", "(Landroid/content/Context;Lyn/a;Ler/c;Lun/i0;Lzq/a;Lcom/withpersona/sdk2/inquiry/tracking/TrackingEventsLogger;Ldr/c;Lto/e;Lun/k0;Lcom/withpersona/sdk2/camera/camera2/Camera2PreviewView;Lun/g;Lzn/a;Lks/a;Z)V", BuildConfig.FLAVOR, "f", "()V", "i", "()Z", "Lun/s;", "h", "()Lun/s;", deobf.android.view.xe.a.f36648e, "Landroid/content/Context;", deobf.android.view.k6.b.f21144e, "Lyn/a;", "c", "Ler/c;", "d", "Lun/i0;", "e", "Lzq/a;", "Lcom/withpersona/sdk2/inquiry/tracking/TrackingEventsLogger;", "g", "Ldr/c;", "Lto/e;", "Lun/k0;", "j", "Lcom/withpersona/sdk2/camera/camera2/Camera2PreviewView;", "k", "Lun/g;", "l", "Lzn/a;", "m", "Lks/a;", "n", "Z", BuildConfig.FLAVOR, "o", "I", "choiceIndex", "camera_release"}, k = 1, mv = {2, 2, 0}, xi = 48)
// dex: classes3.dex
public final class b0 {

    @NotNull
    public final Context context;

    @NotNull
    public final deobf.unlinked.yn.a cameraStatsManager;

    @NotNull
    public final deobf.com.withpersona.sdk2.inquiry.er.c sdkFilesManager;

    @NotNull
    public final i0 cameraChoiceHelper;

    @NotNull
    public final deobf.unlinked.zq.a coroutineScopeFactory;

    @NotNull
    public final TrackingEventsLogger trackingEventsLogger;

    @NotNull
    public final deobf.com.withpersona.sdk2.inquiry.dr.c externalEventLogger;

    @NotNull
    public final deobf.com.withpersona.sdk2.inquiry.to.e featureFlagManager;

    @NotNull
    public final CameraChoices cameraChoices;

    @NotNull
    public final Camera2PreviewView previewView;

    @NotNull
    public final g analyzer;

    @NotNull
    public final deobf.unlinked.zn.a videoCaptureMethod;

    @Nullable
    public final deobf.unlinked.ks.a webRtcManager;

    public final boolean isAudioRequired;

    public int choiceIndex;

    @Metadata(d1 = {"\u00004\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\bg\u0018\u00002\u00020\u0001JA\u0010\u000f\u001a\u00020\u000e2\u0006\u0010\u0003\u001a\u00020\u00022\u0006\u0010\u0005\u001a\u00020\u00042\u0006\u0010\u0007\u001a\u00020\u00062\u0006\u0010\t\u001a\u00020\b2\b\u0010\u000b\u001a\u0004\u0018\u00010\n2\u0006\u0010\r\u001a\u00020\fH&¢\u0006\u0004\b\u000f\u0010\u0010¨\u0006\u0011À\u0006\u0003"}, d2 = {"Lun/b0$a;", BuildConfig.FLAVOR, "Lun/k0;", "cameraChoices", "Lcom/withpersona/sdk2/camera/camera2/Camera2PreviewView;", "previewView", "Lun/g;", "analyzer", "Lzn/a;", "videoCaptureMethod", "Lks/a;", "webRtcManager", BuildConfig.FLAVOR, "isAudioRequired", "Lun/b0;", deobf.android.view.xe.a.f36648e, "(Lun/k0;Lcom/withpersona/sdk2/camera/camera2/Camera2PreviewView;Lun/g;Lzn/a;Lks/a;Z)Lun/b0;", "camera_release"}, k = 1, mv = {2, 2, 0}, xi = 48)
    public interface a {
        @NotNull
        b0 a(@NotNull CameraChoices cameraChoices, @NotNull Camera2PreviewView previewView, @NotNull g analyzer, @NotNull deobf.unlinked.zn.a videoCaptureMethod, @Nullable deobf.unlinked.ks.a webRtcManager, boolean isAudioRequired);
    }

    public b0(@NotNull Context context, @NotNull deobf.unlinked.yn.a cameraStatsManager, @NotNull deobf.com.withpersona.sdk2.inquiry.er.c sdkFilesManager, @NotNull i0 cameraChoiceHelper, @NotNull deobf.unlinked.zq.a coroutineScopeFactory, @NotNull TrackingEventsLogger trackingEventsLogger, @NotNull deobf.com.withpersona.sdk2.inquiry.dr.c externalEventLogger, @NotNull deobf.com.withpersona.sdk2.inquiry.to.e featureFlagManager, @NotNull CameraChoices cameraChoices, @NotNull Camera2PreviewView previewView, @NotNull g analyzer, @NotNull deobf.unlinked.zn.a videoCaptureMethod, @Nullable deobf.unlinked.ks.a aVar, boolean z10) {
        Intrinsics.checkNotNullParameter(context, "context");
        Intrinsics.checkNotNullParameter(cameraStatsManager, "cameraStatsManager");
        Intrinsics.checkNotNullParameter(sdkFilesManager, "sdkFilesManager");
        Intrinsics.checkNotNullParameter(cameraChoiceHelper, "cameraChoiceHelper");
        Intrinsics.checkNotNullParameter(coroutineScopeFactory, "coroutineScopeFactory");
        Intrinsics.checkNotNullParameter(trackingEventsLogger, "trackingEventsLogger");
        Intrinsics.checkNotNullParameter(externalEventLogger, "externalEventLogger");
        Intrinsics.checkNotNullParameter(featureFlagManager, "featureFlagManager");
        Intrinsics.checkNotNullParameter(cameraChoices, "cameraChoices");
        Intrinsics.checkNotNullParameter(previewView, "previewView");
        Intrinsics.checkNotNullParameter(analyzer, "analyzer");
        Intrinsics.checkNotNullParameter(videoCaptureMethod, "videoCaptureMethod");
        this.context = context;
        this.cameraStatsManager = cameraStatsManager;
        this.sdkFilesManager = sdkFilesManager;
        this.cameraChoiceHelper = cameraChoiceHelper;
        this.coroutineScopeFactory = coroutineScopeFactory;
        this.trackingEventsLogger = trackingEventsLogger;
        this.externalEventLogger = externalEventLogger;
        this.featureFlagManager = featureFlagManager;
        this.cameraChoices = cameraChoices;
        this.previewView = previewView;
        this.analyzer = analyzer;
        this.videoCaptureMethod = videoCaptureMethod;
        this.webRtcManager = aVar;
        this.isAudioRequired = z10;
        Iterator<h0> it = cameraChoices.a().iterator();
        final int i10 = 0;
        while (true) {
            if (!it.hasNext()) {
                i10 = -1;
                break;
            } else {
                if (!this.cameraChoiceHelper.b(it.next())) {
                    break;
                } else {
                    i10++;
                }
            }
        }
        this.choiceIndex = i10 != -1 ? i10 : 0;
        TrackingEventsLogger.logDebugLogEvent$default(this.trackingEventsLogger, "camera", new Function0() { // from class: un.x
            @Override // kotlin.jvm.functions.Function0
            public final Object invoke() {
                String e10;
                e10 = deobf.unlinked.b0.e(b0.this, i10);
                return e10;
            }
        }, false, 4, null);
    }

    public static CharSequence a(b0 b0Var, String id2) {
        Intrinsics.checkNotNullParameter(id2, "id");
        return id2 + "=" + f0.d(b0Var.context, id2);
    }

    public static final String e(final b0 b0Var, int i10) {
        List<h0> a10 = b0Var.cameraChoices.a();
        int i11 = 0;
        if (!(a10 instanceof Collection) || !a10.isEmpty()) {
            Iterator<T> it = a10.iterator();
            while (it.hasNext()) {
                if (b0Var.cameraChoiceHelper.b((h0) it.next()) && (i11 = i11 + 1) < 0) {
                    kotlin.collections.p.s();
                }
            }
        }
        List<h0> a11 = b0Var.cameraChoices.a();
        ArrayList arrayList = new ArrayList(kotlin.collections.q.u(a11, 10));
        Iterator<T> it2 = a11.iterator();
        while (it2.hasNext()) {
            arrayList.add(((h0) it2.next()).getId());
        }
        String m02 = CollectionsKt.m0(CollectionsKt.X(arrayList), null, null, null, 0, null, new Function1() { // from class: un.y
            @Override // kotlin.jvm.functions.Function1
            public final Object invoke(Object obj) {
                return deobf.unlinked.b0.a(b0.this, (String) obj);
            }
        }, 31, null);
        return "Camera2ManagerFactory created. choices=" + CollectionsKt.m0(b0Var.cameraChoices.a(), null, null, null, 0, null, null, 63, null) + ", hardwareLevels=[" + m02 + "], preMarkedBadCount=" + i11 + "/" + b0Var.cameraChoices.a().size() + ", startIndex=" + b0Var.choiceIndex + (i10 == -1 ? " (ALL choices pre-marked bad, falling back to index 0)" : BuildConfig.FLAVOR);
    }

    public static final String g(b0 b0Var) {
        return "Marking camera choice as bad: " + b0Var.cameraChoices.a().get(b0Var.choiceIndex);
    }

    public static final String j(b0 b0Var) {
        return "Skipping pre-marked-bad camera choice: " + b0Var.cameraChoices.a().get(b0Var.choiceIndex);
    }

    public final void f() {
        TrackingEventsLogger.logDebugLogEvent$default(this.trackingEventsLogger, "camera", new Function0() { // from class: un.z
            @Override // kotlin.jvm.functions.Function0
            public final Object invoke() {
                String g10;
                g10 = deobf.unlinked.b0.g(b0.this);
                return g10;
            }
        }, false, 4, null);
        this.cameraChoiceHelper.a(this.cameraChoices.a().get(this.choiceIndex));
    }

    @NotNull
    public final s h() {
        return new s(this.context, this.cameraChoices.a().get(this.choiceIndex), this.previewView, this.analyzer, this.videoCaptureMethod, this.webRtcManager, this.isAudioRequired, this.cameraStatsManager, this.sdkFilesManager, this.coroutineScopeFactory, this.trackingEventsLogger, this.externalEventLogger, this.featureFlagManager.a(deobf.com.withpersona.sdk2.inquiry.to.b0.f32604a), this.featureFlagManager.a(deobf.com.withpersona.sdk2.inquiry.to.u.f32630a));
    }

    public final boolean i() {
        while (this.choiceIndex + 1 < this.cameraChoices.a().size()) {
            this.choiceIndex++;
            if (!this.cameraChoiceHelper.b(this.cameraChoices.a().get(this.choiceIndex))) {
                return true;
            }
            TrackingEventsLogger.logDebugLogEvent$default(this.trackingEventsLogger, "camera", new Function0() { // from class: un.a0
                @Override // kotlin.jvm.functions.Function0
                public final Object invoke() {
                    String j10;
                    j10 = deobf.unlinked.b0.j(b0.this);
                    return j10;
                }
            }, false, 4, null);
        }
        return false;
    }
}
