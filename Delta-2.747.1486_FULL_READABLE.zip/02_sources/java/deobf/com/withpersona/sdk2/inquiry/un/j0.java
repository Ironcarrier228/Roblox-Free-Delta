package deobf.com.withpersona.sdk2.inquiry.un;

// dex: classes3.dex
public final class j0 implements deobf.com.withpersona.sdk2.inquiry.wt.d<i0> {

    public static final class a {

        public static final j0 f33651a = new j0();
    }

    public static j0 a() {
        return a.f33651a;
    }

    public static i0 c() {
        return new i0();
    }

    @Override // deobf.unlinked.yt.a
    public i0 get() {
        return c();
    }
}
