package deobf.com.withpersona.sdk2.inquiry.po;

import android.os.Parcel;
import android.os.Parcelable;
import deobf.com.withpersona.sdk2.inquiry.ar.f;
import com.github.luben.zstd.BuildConfig;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(d1 = {"\u0000@\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0002\b\u0005\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000b\n\u0002\b\t\b\u0087\b\u0018\u00002\u00020\u0001B\u001d\u0012\u0006\u0010\u0003\u001a\u00020\u0002\u0012\f\u0010\u0006\u001a\b\u0012\u0004\u0012\u00020\u00050\u0004¢\u0006\u0004\b\u0007\u0010\bJ\r\u0010\n\u001a\u00020\t¢\u0006\u0004\b\n\u0010\u000bJ\u001d\u0010\u0010\u001a\u00020\u000f2\u0006\u0010\r\u001a\u00020\f2\u0006\u0010\u000e\u001a\u00020\t¢\u0006\u0004\b\u0010\u0010\u0011J\u0010\u0010\u0012\u001a\u00020\u0002HÖ\u0001¢\u0006\u0004\b\u0012\u0010\u0013J\u0010\u0010\u0014\u001a\u00020\tHÖ\u0001¢\u0006\u0004\b\u0014\u0010\u000bJ\u001a\u0010\u0018\u001a\u00020\u00172\b\u0010\u0016\u001a\u0004\u0018\u00010\u0015HÖ\u0003¢\u0006\u0004\b\u0018\u0010\u0019R\u001a\u0010\u0003\u001a\u00020\u00028\u0016X\u0096\u0004¢\u0006\f\n\u0004\b\u001a\u0010\u001b\u001a\u0004\b\u001c\u0010\u0013R\u001d\u0010\u0006\u001a\b\u0012\u0004\u0012\u00020\u00050\u00048\u0006¢\u0006\f\n\u0004\b\u001d\u0010\u001e\u001a\u0004\b\u001a\u0010\u001f¨\u0006 "}, d2 = {"Lpo/d;", "Lar/f;", BuildConfig.FLAVOR, "stepName", BuildConfig.FLAVOR, "Lno/e;", "documents", "<init>", "(Ljava/lang/String;Ljava/util/List;)V", BuildConfig.FLAVOR, "describeContents", "()I", "Landroid/os/Parcel;", "dest", "flags", BuildConfig.FLAVOR, "writeToParcel", "(Landroid/os/Parcel;I)V", "toString", "()Ljava/lang/String;", "hashCode", BuildConfig.FLAVOR, "other", BuildConfig.FLAVOR, "equals", "(Ljava/lang/Object;)Z", deobf.android.view.xe.a.f36648e, "Ljava/lang/String;", "f", deobf.android.view.k6.b.f21144e, "Ljava/util/List;", "()Ljava/util/List;", "document_release"}, k = 1, mv = {2, 2, 0}, xi = 48)
// dex: classes3.dex
public final /* data */ class DocumentStepData implements f {

    @NotNull
    public static final Parcelable.Creator<DocumentStepData> CREATOR = new a();

    @NotNull
    public final String stepName;

    @NotNull
    public final List<deobf.com.withpersona.sdk2.inquiry.no.e> documents;

    @Metadata(k = 3, mv = {2, 2, 0}, xi = 48)
    public static final class a implements Parcelable.Creator<DocumentStepData> {
        @Override // android.os.Parcelable.Creator
        public final DocumentStepData createFromParcel(Parcel parcel) {
            Intrinsics.checkNotNullParameter(parcel, "parcel");
            String readString = parcel.readString();
            int readInt = parcel.readInt();
            ArrayList arrayList = new ArrayList(readInt);
            for (int i10 = 0; i10 != readInt; i10++) {
                arrayList.add(parcel.readParcelable(DocumentStepData.class.getClassLoader()));
            }
            return new DocumentStepData(readString, arrayList);
        }

        @Override // android.os.Parcelable.Creator
        public final DocumentStepData[] newArray(int i10) {
            return new DocumentStepData[i10];
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    public DocumentStepData(@NotNull String stepName, @NotNull List<? extends deobf.com.withpersona.sdk2.inquiry.no.e> documents) {
        Intrinsics.checkNotNullParameter(stepName, "stepName");
        Intrinsics.checkNotNullParameter(documents, "documents");
        this.stepName = stepName;
        this.documents = documents;
    }

    @NotNull
    public final List<deobf.com.withpersona.sdk2.inquiry.no.e> a() {
        return this.documents;
    }

    @Override // android.os.Parcelable
    public final int describeContents() {
        return 0;
    }

    public boolean equals(@Nullable Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof DocumentStepData)) {
            return false;
        }
        DocumentStepData documentStepData = (DocumentStepData) other;
        return Intrinsics.c(this.stepName, documentStepData.stepName) && Intrinsics.c(this.documents, documentStepData.documents);
    }

    @NotNull
    public String getStepName() {
        return this.stepName;
    }

    public int hashCode() {
        return (this.stepName.hashCode() * 31) + this.documents.hashCode();
    }

    @NotNull
    public String toString() {
        return "DocumentStepData(stepName=" + this.stepName + ", documents=" + this.documents + ")";
    }

    @Override // android.os.Parcelable
    public final void writeToParcel(@NotNull Parcel dest, int flags) {
        Intrinsics.checkNotNullParameter(dest, "dest");
        dest.writeString(this.stepName);
        List<deobf.com.withpersona.sdk2.inquiry.no.e> list = this.documents;
        dest.writeInt(list.size());
        Iterator<deobf.com.withpersona.sdk2.inquiry.no.e> it = list.iterator();
        while (it.hasNext()) {
            dest.writeParcelable(it.next(), flags);
        }
    }
}
