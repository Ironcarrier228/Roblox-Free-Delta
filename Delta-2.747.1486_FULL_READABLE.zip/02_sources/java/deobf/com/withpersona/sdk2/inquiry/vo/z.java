package deobf.com.withpersona.sdk2.inquiry.vo;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.LayerDrawable;
import android.graphics.drawable.RippleDrawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;
import com.github.luben.zstd.BuildConfig;
import com.withpersona.sdk2.inquiry.network.dto.NextStep;
import com.withpersona.sdk2.inquiry.network.dto.ui.components.RemoteImage;
import com.withpersona.sdk2.inquiry.network.dto.ui.styling.StepStyles;
import com.withpersona.sdk2.inquiry.network.dto.ui.styling.TextBasedComponentStyle;
import com.withpersona.sdk2.inquiry.shared.ui.ClickableConstraintLayout;
import deobf.com.withpersona.sdk2.inquiry.gr.InquiryTheme;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(d1 = {"\u0000~\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\f\n\u0002\u0018\u0002\n\u0002\b\t\n\u0002\u0018\u0002\n\u0002\b\u0013\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u000b\n\u0002\b\n\b\u0000\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001BM\u0012\u0006\u0010\u0004\u001a\u00020\u0003\u0012\f\u0010\u0007\u001a\b\u0012\u0004\u0012\u00020\u00060\u0005\u0012\b\u0010\t\u001a\u0004\u0018\u00010\b\u0012\b\u0010\u000b\u001a\u0004\u0018\u00010\n\u0012\u0006\u0010\r\u001a\u00020\f\u0012\u0012\u0010\u0011\u001a\u000e\u0012\u0004\u0012\u00020\u000f\u0012\u0004\u0012\u00020\u00100\u000e¢\u0006\u0004\b\u0012\u0010\u0013J*\u0010\u001b\u001a\r\u0012\t\u0012\u00070\u0019¢\u0006\u0002\b\u001a0\u00182\u0006\u0010\u0015\u001a\u00020\u00142\u0006\u0010\u0017\u001a\u00020\u0016H\u0016¢\u0006\u0004\b\u001b\u0010\u001cJ\u000f\u0010\u001d\u001a\u00020\u0016H\u0016¢\u0006\u0004\b\u001d\u0010\u001eJ\u001f\u0010!\u001a\u00020\u00102\u0006\u0010\u001f\u001a\u00020\u00022\u0006\u0010 \u001a\u00020\u0016H\u0016¢\u0006\u0004\b!\u0010\"J\u0017\u0010$\u001a\u00020\u00102\u0006\u0010#\u001a\u00020\u0019H\u0002¢\u0006\u0004\b$\u0010%J\u001f\u0010)\u001a\u00020\u00102\u0006\u0010&\u001a\u00020\u00192\u0006\u0010(\u001a\u00020'H\u0002¢\u0006\u0004\b)\u0010*J3\u0010.\u001a\u00020'2\u0006\u0010\u0004\u001a\u00020\u00032\b\u0010+\u001a\u0004\u0018\u00010\u00162\b\u0010,\u001a\u0004\u0018\u00010\u00162\u0006\u0010-\u001a\u00020'H\u0002¢\u0006\u0004\b.\u0010/J\u0017\u00102\u001a\u0002012\u0006\u00100\u001a\u00020\u0016H\u0002¢\u0006\u0004\b2\u00103R\u001d\u0010\u0007\u001a\b\u0012\u0004\u0012\u00020\u00060\u00058\u0006¢\u0006\f\n\u0004\b4\u00105\u001a\u0004\b6\u00107R\u0019\u0010\t\u001a\u0004\u0018\u00010\b8\u0006¢\u0006\f\n\u0004\b\u001d\u00108\u001a\u0004\b9\u0010:R\u0016\u0010\u000b\u001a\u0004\u0018\u00010\n8\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b;\u0010<R\u0017\u0010\r\u001a\u00020\f8\u0006¢\u0006\f\n\u0004\b=\u0010>\u001a\u0004\b?\u0010@R#\u0010\u0011\u001a\u000e\u0012\u0004\u0012\u00020\u000f\u0012\u0004\u0012\u00020\u00100\u000e8\u0006¢\u0006\f\n\u0004\bA\u0010B\u001a\u0004\bC\u0010DR0\u0010I\u001a\u001e\u0012\u0004\u0012\u00020\u0016\u0012\u0004\u0012\u00020'0Ej\u000e\u0012\u0004\u0012\u00020\u0016\u0012\u0004\u0012\u00020'`F8\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\bG\u0010HR\u0014\u0010M\u001a\u00020J8\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\bK\u0010LR*\u0010P\u001a\u00020J2\u0006\u0010N\u001a\u00020J8\u0006@FX\u0086\u000e¢\u0006\u0012\n\u0004\bO\u0010L\u001a\u0004\bP\u0010Q\"\u0004\bR\u0010S¨\u0006T"}, d2 = {"Lvo/z;", "Landroidx/recyclerview/widget/RecyclerView$h;", "Landroidx/recyclerview/widget/RecyclerView$g0;", "Landroid/content/Context;", "context", BuildConfig.FLAVOR, "Lvo/l;", "data", "Lcom/withpersona/sdk2/inquiry/network/dto/ui/styling/StepStyles$GovernmentIdStepStyle;", "styles", "Lcom/withpersona/sdk2/inquiry/network/dto/NextStep$GovernmentId$AssetConfig$SelectPage;", "assetConfig", "Lgr/a$c;", "iconStyle", "Lkotlin/Function1;", "Lvo/d3;", BuildConfig.FLAVOR, "onClick", "<init>", "(Landroid/content/Context;Ljava/util/List;Lcom/withpersona/sdk2/inquiry/network/dto/ui/styling/StepStyles$GovernmentIdStepStyle;Lcom/withpersona/sdk2/inquiry/network/dto/NextStep$GovernmentId$AssetConfig$SelectPage;Lgr/a$c;Lkotlin/jvm/functions/Function1;)V", "Landroid/view/ViewGroup;", "parent", BuildConfig.FLAVOR, "viewType", "Lxq/j0;", "Lap/f;", "Lkotlin/jvm/internal/EnhancedNullability;", "H", "(Landroid/view/ViewGroup;I)Lxq/j0;", "e", "()I", "holder", "position", "r", "(Landroidx/recyclerview/widget/RecyclerView$g0;I)V", "viewHolder", "D", "(Lap/f;)V", "binding", "Landroid/graphics/drawable/Drawable;", "drawableRes", "J", "(Lap/f;Landroid/graphics/drawable/Drawable;)V", "strokeColor", "fillColor", "iconDrawable", "F", "(Landroid/content/Context;Ljava/lang/Integer;Ljava/lang/Integer;Landroid/graphics/drawable/Drawable;)Landroid/graphics/drawable/Drawable;", "pressedColor", "Landroid/content/res/ColorStateList;", "E", "(I)Landroid/content/res/ColorStateList;", "d", "Ljava/util/List;", "getData", "()Ljava/util/List;", "Lcom/withpersona/sdk2/inquiry/network/dto/ui/styling/StepStyles$GovernmentIdStepStyle;", "getStyles", "()Lcom/withpersona/sdk2/inquiry/network/dto/ui/styling/StepStyles$GovernmentIdStepStyle;", "f", "Lcom/withpersona/sdk2/inquiry/network/dto/NextStep$GovernmentId$AssetConfig$SelectPage;", "g", "Lgr/a$c;", "getIconStyle", "()Lgr/a$c;", "h", "Lkotlin/jvm/functions/Function1;", "getOnClick", "()Lkotlin/jvm/functions/Function1;", "Ljava/util/HashMap;", "Lkotlin/collections/HashMap;", "i", "Ljava/util/HashMap;", "cachedImages", BuildConfig.FLAVOR, "j", "Z", "useIcons", "value", "k", "isEnabled", "()Z", "I", "(Z)V", "government-id_release"}, k = 1, mv = {2, 2, 0}, xi = 48)
// dex: classes3.dex
public final class z extends RecyclerView.h<RecyclerView.g0> {

    @NotNull
    public final List<EnabledIdClass> data;

    @Nullable
    public final StepStyles.GovernmentIdStepStyle styles;

    @Nullable
    public final NextStep.GovernmentId.AssetConfig.SelectPage assetConfig;

    @NotNull
    public final InquiryTheme.c iconStyle;

    @NotNull
    public final Function1<IdConfig, Unit> onClick;

    @NotNull
    public final HashMap<Integer, Drawable> cachedImages;

    public final boolean useIcons;

    public boolean isEnabled;

    @Metadata(k = 3, mv = {2, 2, 0}, xi = 48)
    public static final /* synthetic */ class a {

        public static final /* synthetic */ int[] f35190a;

        static {
            int[] iArr = new int[h3.values().length];
            try {
                iArr[h3.f34656a.ordinal()] = 1;
            } catch (NoSuchFieldError unused) {
            }
            try {
                iArr[deobf.androidx.credentials.playservices.controllers.identitycredentials.signalcredentialstate.h3.b.ordinal()] = 2;
            } catch (NoSuchFieldError unused2) {
            }
            try {
                iArr[h3.f34657c.ordinal()] = 3;
            } catch (NoSuchFieldError unused3) {
            }
            try {
                iArr[h3.f34658d.ordinal()] = 4;
            } catch (NoSuchFieldError unused4) {
            }
            f35190a = iArr;
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    public z(@NotNull Context context, @NotNull List<EnabledIdClass> data, @Nullable StepStyles.GovernmentIdStepStyle governmentIdStepStyle, @Nullable NextStep.GovernmentId.AssetConfig.SelectPage selectPage, @NotNull InquiryTheme.c iconStyle, @NotNull Function1<? super IdConfig, Unit> onClick) {
        Intrinsics.checkNotNullParameter(context, "context");
        Intrinsics.checkNotNullParameter(data, "data");
        Intrinsics.checkNotNullParameter(iconStyle, "iconStyle");
        Intrinsics.checkNotNullParameter(onClick, "onClick");
        this.data = data;
        this.styles = governmentIdStepStyle;
        this.assetConfig = selectPage;
        this.iconStyle = iconStyle;
        this.onClick = onClick;
        this.cachedImages = new HashMap<>();
        this.useIcons = !deobf.com.withpersona.sdk2.inquiry.xq.z.b(context, deobf.com.withpersona.sdk2.inquiry.jq.a.f20826d, null, false, false, 14, null);
        this.isEnabled = true;
    }

    public static final void G(z zVar, EnabledIdClass enabledIdClass, View view) {
        zVar.onClick.invoke(enabledIdClass.getIdConfig());
    }

    public final void D(deobf.com.withpersona.sdk2.inquiry.ap.f viewHolder) {
        Double governmentIdSelectOptionMinRowHeight;
        Integer backgroundColorValue;
        Integer chevronColor;
        TextBasedComponentStyle governmentIdVerticalOptionTextStyle;
        StepStyles.GovernmentIdStepStyle governmentIdStepStyle = this.styles;
        if (governmentIdStepStyle != null && (governmentIdVerticalOptionTextStyle = governmentIdStepStyle.getGovernmentIdVerticalOptionTextStyle()) != null) {
            TextView label = viewHolder.f3220e;
            Intrinsics.checkNotNullExpressionValue(label, "label");
            deobf.com.withpersona.sdk2.inquiry.yr.h0.l(label, governmentIdVerticalOptionTextStyle, null, 2, null);
        }
        StepStyles.GovernmentIdStepStyle governmentIdStepStyle2 = this.styles;
        if (governmentIdStepStyle2 != null && (chevronColor = governmentIdStepStyle2.getChevronColor()) != null) {
            viewHolder.b.setColorFilter(chevronColor.intValue());
        }
        StepStyles.GovernmentIdStepStyle governmentIdStepStyle3 = this.styles;
        if (governmentIdStepStyle3 != null && (backgroundColorValue = governmentIdStepStyle3.getBackgroundColorValue()) != null) {
            int intValue = backgroundColorValue.intValue();
            Integer activeOptionBackgroundColorValue = this.styles.getActiveOptionBackgroundColorValue();
            if (activeOptionBackgroundColorValue != null) {
                viewHolder.getRoot().setBackground(new RippleDrawable(E(activeOptionBackgroundColorValue.intValue()), new ColorDrawable(intValue), null));
            }
        }
        StepStyles.GovernmentIdStepStyle governmentIdStepStyle4 = this.styles;
        if (governmentIdStepStyle4 == null || (governmentIdSelectOptionMinRowHeight = governmentIdStepStyle4.getGovernmentIdSelectOptionMinRowHeight()) == null) {
            return;
        }
        viewHolder.f3221f.setMinHeight((int) deobf.com.withpersona.sdk2.inquiry.xq.j.a(governmentIdSelectOptionMinRowHeight.doubleValue()));
    }

    public final ColorStateList E(int pressedColor) {
        return new ColorStateList(new int[][]{new int[0]}, new int[]{pressedColor});
    }

    public final Drawable F(Context context, Integer strokeColor, Integer fillColor, Drawable iconDrawable) {
        Drawable mutate;
        ArrayList arrayList = new ArrayList();
        if (strokeColor != null) {
            iconDrawable.mutate().setTint(strokeColor.intValue());
        }
        Drawable b = deobf.unlinked.k.a.b(context, m3.f34828e);
        if (fillColor != null && b != null && (mutate = b.mutate()) != null) {
            mutate.setTint(fillColor.intValue());
        }
        if (b != null) {
            arrayList.add(b);
        }
        arrayList.add(iconDrawable);
        return new LayerDrawable((Drawable[]) arrayList.toArray(new Drawable[0]));
    }

    @Override // androidx.recyclerview.widget.RecyclerView.h
    @NotNull
    public deobf.com.withpersona.sdk2.inquiry.xq.j0<deobf.com.withpersona.sdk2.inquiry.ap.f> t(@NotNull ViewGroup parent, int viewType) {
        Intrinsics.checkNotNullParameter(parent, "parent");
        deobf.com.withpersona.sdk2.inquiry.ap.f c10 = deobf.com.withpersona.sdk2.inquiry.ap.f.c(LayoutInflater.from(parent.getContext()), parent, false);
        Intrinsics.checkNotNullExpressionValue(c10, "inflate(...)");
        deobf.com.withpersona.sdk2.inquiry.xq.j0<deobf.com.withpersona.sdk2.inquiry.ap.f> j0Var = new deobf.com.withpersona.sdk2.inquiry.xq.j0<>(c10);
        deobf.com.withpersona.sdk2.inquiry.ap.f N = j0Var.N();
        Intrinsics.checkNotNullExpressionValue(N, "<get-binding>(...)");
        D(N);
        return j0Var;
    }

    public final void I(boolean z10) {
        if (this.isEnabled == z10) {
            return;
        }
        this.isEnabled = z10;
        j();
    }

    public final void J(deobf.com.withpersona.sdk2.inquiry.ap.f binding, Drawable drawableRes) {
        Integer governmentIdIconFillColor;
        Integer governmentIdIconStrokeColor;
        StepStyles.GovernmentIdStepStyle governmentIdStepStyle = this.styles;
        Integer num = null;
        Integer valueOf = (governmentIdStepStyle == null || (governmentIdIconStrokeColor = governmentIdStepStyle.getGovernmentIdIconStrokeColor()) == null) ? null : Integer.valueOf(governmentIdIconStrokeColor.intValue());
        StepStyles.GovernmentIdStepStyle governmentIdStepStyle2 = this.styles;
        if (governmentIdStepStyle2 != null && (governmentIdIconFillColor = governmentIdStepStyle2.getGovernmentIdIconFillColor()) != null) {
            num = Integer.valueOf(governmentIdIconFillColor.intValue());
        }
        Context context = binding.getRoot().getContext();
        Intrinsics.checkNotNullExpressionValue(context, "getContext(...)");
        Drawable mutate = F(context, valueOf, num, drawableRes).mutate();
        Intrinsics.checkNotNullExpressionValue(mutate, "mutate(...)");
        binding.f3218c.setImageDrawable(mutate);
    }

    @Override // androidx.recyclerview.widget.RecyclerView.h
    public int e() {
        return this.data.size();
    }

    @Override // androidx.recyclerview.widget.RecyclerView.h
    public void r(@NotNull RecyclerView.g0 holder, int position) {
        RemoteImage iconPassport;
        int i10;
        Intrinsics.checkNotNullParameter(holder, "holder");
        final EnabledIdClass enabledIdClass = this.data.get(position);
        deobf.com.withpersona.sdk2.inquiry.ap.f fVar = (deobf.com.withpersona.sdk2.inquiry.ap.f) deobf.com.withpersona.sdk2.inquiry.xq.k0.a(holder);
        fVar.f3220e.setText(enabledIdClass.getName());
        h3 icon = enabledIdClass.getIcon();
        int[] iArr = a.f35190a;
        int i11 = iArr[icon.ordinal()];
        if (i11 == 1) {
            NextStep.GovernmentId.AssetConfig.SelectPage selectPage = this.assetConfig;
            if (selectPage != null) {
                iconPassport = selectPage.getIconPassport();
            }
            iconPassport = null;
        } else if (i11 == 2) {
            NextStep.GovernmentId.AssetConfig.SelectPage selectPage2 = this.assetConfig;
            if (selectPage2 != null) {
                iconPassport = selectPage2.getIconGovernmentId();
            }
            iconPassport = null;
        } else if (i11 == 3) {
            NextStep.GovernmentId.AssetConfig.SelectPage selectPage3 = this.assetConfig;
            if (selectPage3 != null) {
                iconPassport = selectPage3.getIconDriversLicense();
            }
            iconPassport = null;
        } else {
            if (i11 != 4) {
                throw new deobf.com.withpersona.sdk2.inquiry.zt.l();
            }
            NextStep.GovernmentId.AssetConfig.SelectPage selectPage4 = this.assetConfig;
            if (selectPage4 == null || (iconPassport = selectPage4.getIconNationalId()) == null) {
                NextStep.GovernmentId.AssetConfig.SelectPage selectPage5 = this.assetConfig;
                if (selectPage5 != null) {
                    iconPassport = selectPage5.getIconGovernmentId();
                }
                iconPassport = null;
            }
        }
        Object tag = fVar.f3219d.getTag(n3.f34878m0);
        View view = tag instanceof View ? (View) tag : null;
        if (view != null) {
            fVar.f3219d.removeView(view);
        }
        if (!this.useIcons || this.iconStyle == InquiryTheme.c.b) {
            fVar.f3219d.setVisibility(8);
            TextView label = fVar.f3220e;
            Intrinsics.checkNotNullExpressionValue(label, "label");
            label.setPaddingRelative(0, label.getPaddingTop(), label.getPaddingEnd(), label.getPaddingBottom());
        } else if (iconPassport != null) {
            ConstraintLayout iconContainer = fVar.f3219d;
            Intrinsics.checkNotNullExpressionValue(iconContainer, "iconContainer");
            fVar.f3219d.setTag(n3.f34878m0, deobf.com.withpersona.sdk2.inquiry.as.c.e(iconPassport, iconContainer, true));
            fVar.f3218c.setVisibility(8);
            TextView label2 = fVar.f3220e;
            Intrinsics.checkNotNullExpressionValue(label2, "label");
            label2.setPaddingRelative((int) deobf.com.withpersona.sdk2.inquiry.xq.j.a(8.0d), label2.getPaddingTop(), label2.getPaddingEnd(), label2.getPaddingBottom());
        } else {
            fVar.f3218c.setVisibility(0);
            if (this.cachedImages.get(Integer.valueOf(position)) != null) {
                fVar.f3218c.setImageDrawable(this.cachedImages.get(Integer.valueOf(position)));
            } else {
                int i12 = iArr[enabledIdClass.getIcon().ordinal()];
                if (i12 == 1) {
                    i10 = m3.f34834k;
                } else if (i12 == 2) {
                    i10 = m3.f34827d;
                } else if (i12 == 3) {
                    i10 = m3.f34831h;
                } else {
                    if (i12 != 4) {
                        throw new deobf.com.withpersona.sdk2.inquiry.zt.l();
                    }
                    i10 = m3.f34832i;
                }
                Drawable b = deobf.unlinked.k.a.b(fVar.getRoot().getContext(), i10);
                if (b != null) {
                    J(fVar, b);
                    this.cachedImages.put(Integer.valueOf(position), fVar.f3218c.getDrawable());
                }
            }
            TextView label3 = fVar.f3220e;
            Intrinsics.checkNotNullExpressionValue(label3, "label");
            label3.setPaddingRelative((int) deobf.com.withpersona.sdk2.inquiry.xq.j.a(8.0d), label3.getPaddingTop(), label3.getPaddingEnd(), label3.getPaddingBottom());
        }
        ClickableConstraintLayout root = fVar.getRoot();
        Intrinsics.checkNotNullExpressionValue(root, "getRoot(...)");
        deobf.unlinked.mr.a.a(root, deobf.com.withpersona.sdk2.inquiry.jq.g.f20867a);
        fVar.getRoot().setOnClickListener(new View.OnClickListener() { // from class: vo.y
            @Override // android.view.View.OnClickListener
            public final void onClick(View view2) {
                z.G(z.this, enabledIdClass, view2);
            }
        });
        fVar.getRoot().setEnabled(this.isEnabled);
    }
}
