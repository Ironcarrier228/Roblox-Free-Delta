package deobf.com.withpersona.sdk2.inquiry.vo;

import androidx.camera.view.PreviewView;
import com.github.luben.zstd.BuildConfig;
import kotlin.Metadata;
import deobf.com.withpersona.sdk2.inquiry.sn.t;
import deobf.com.withpersona.sdk2.inquiry.vo.y3;

@Metadata(d1 = {"\u00000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\u001aC\u0010\u000e\u001a\u00020\r*\u00020\u00002\u0006\u0010\u0002\u001a\u00020\u00012\u0006\u0010\u0004\u001a\u00020\u00032\u0006\u0010\u0006\u001a\u00020\u00052\u0006\u0010\b\u001a\u00020\u00072\u0006\u0010\n\u001a\u00020\t2\b\b\u0002\u0010\f\u001a\u00020\u000b¢\u0006\u0004\b\u000e\u0010\u000f¨\u0006\u0010"}, d2 = {"Lvo/y3$b;", "Landroid/content/Context;", "context", "Lsn/t;", "cameraPreview", "Lcom/withpersona/sdk2/camera/camera2/Camera2PreviewView;", "camera2Preview", "Landroidx/camera/view/PreviewView;", "cameraXPreview", "Lsn/h0;", "governmentIdFeed", BuildConfig.FLAVOR, "useCameraXForVideo", "Lsn/i;", deobf.android.view.xe.a.f36648e, "(Lvo/y3$b;Landroid/content/Context;Lsn/t;Lcom/withpersona/sdk2/camera/camera2/Camera2PreviewView;Landroidx/camera/view/PreviewView;Lsn/h0;Z)Lsn/i;", "government-id_release"}, k = 2, mv = {2, 2, 0}, xi = 48)
// dex: classes3.dex
public final class d {

    @Metadata(k = 3, mv = {2, 2, 0}, xi = 48)
    public static final /* synthetic */ class a {

        public static final /* synthetic */ int[] f34509a;

        static {
            int[] iArr = new int[deobf.unlinked.zn.a.values().length];
            try {
                iArr[deobf.unlinked.zn.a.f39326a.ordinal()] = 1;
            } catch (NoSuchFieldError unused) {
            }
            try {
                iArr[deobf.unlinked.zn.a.b.ordinal()] = 2;
            } catch (NoSuchFieldError unused2) {
            }
            try {
                iArr[deobf.unlinked.zn.a.f39327c.ordinal()] = 3;
            } catch (NoSuchFieldError unused3) {
            }
            f34509a = iArr;
        }
    }

    @Metadata(d1 = {"\u0000\u0011\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0002\b\u0003*\u0001\u0000\b\n\u0018\u00002\u00020\u0001J\u000f\u0010\u0003\u001a\u00020\u0002H\u0016¢\u0006\u0004\b\u0003\u0010\u0004¨\u0006\u0005"}, d2 = {"vo/d$b", "Lsn/z;", BuildConfig.FLAVOR, deobf.android.view.xe.a.f36648e, "()V", "government-id_release"}, k = 1, mv = {2, 2, 0}, xi = 48)
    public static final class b implements deobf.com.withpersona.sdk2.inquiry.sn.z {

        public final /* synthetic */ deobf.com.google.firebase.y3.b f34510a;
        public final /* synthetic */ deobf.com.withpersona.sdk2.inquiry.sn.t b;

        public final /* synthetic */ PreviewView f34511c;

        public final /* synthetic */ deobf.com.withpersona.sdk2.inquiry.sn.h0 f34512d;

        public final /* synthetic */ boolean f34513e;

        public b(deobf.com.google.firebase.y3.b bVar, deobf.com.withpersona.sdk2.inquiry.sn.t tVar, PreviewView previewView, deobf.com.withpersona.sdk2.inquiry.sn.h0 h0Var, boolean z10) {
            this.f34510a = bVar;
            this.b = tVar;
            this.f34511c = previewView;
            this.f34512d = h0Var;
            this.f34513e = z10;
        }

        @Override // deobf.com.withpersona.sdk2.inquiry.sn.z
        public void a() {
            this.b.f(this.f34511c, deobf.unlinked.t.a.b, this.f34512d, true, this.f34513e, this.f34510a.D());
        }
    }

    /* JADX WARN: Code restructure failed: missing block: B:15:0x003a, code lost:

        if (r14 == false) goto L12;
     */
    @org.jetbrains.annotations.NotNull
    public static final deobf.com.withpersona.sdk2.inquiry.sn.i a(@org.jetbrains.annotations.NotNull deobf.com.withpersona.sdk2.inquiry.vo.y3.b r8, @org.jetbrains.annotations.NotNull android.content.Context r9, @org.jetbrains.annotations.NotNull deobf.com.withpersona.sdk2.inquiry.sn.t r10, @org.jetbrains.annotations.NotNull com.withpersona.sdk2.camera.camera2.Camera2PreviewView r11, @org.jetbrains.annotations.NotNull androidx.camera.view.PreviewView r12, @org.jetbrains.annotations.NotNull deobf.com.withpersona.sdk2.inquiry.sn.h0 r13, boolean r14) {
        /*
            java.lang.String r0 = "<this>"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r8, r0)
            java.lang.String r0 = "context"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r9, r0)
            java.lang.String r0 = "cameraPreview"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r10, r0)
            java.lang.String r0 = "camera2Preview"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r11, r0)
            java.lang.String r0 = "cameraXPreview"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r12, r0)
            java.lang.String r0 = "governmentIdFeed"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r13, r0)
            deobf.unlinked.zn.a r0 = r8.getVideoCaptureMethod()
            int[] r1 = deobf.com.withpersona.sdk2.inquiry.vo.d.a.f34509a
            int r0 = r0.ordinal()
            r0 = r1[r0]
            r1 = 1
            if (r0 == r1) goto L3c
            r2 = 2
            if (r0 == r2) goto L3a
            r9 = 3
            if (r0 != r9) goto L34
            goto L3e
        L34:
            deobf.com.withpersona.sdk2.inquiry.zt.l r8 = new deobf.com.withpersona.sdk2.inquiry.zt.l
            r8.<init>()
            throw r8
        L3a:
            if (r14 != 0) goto L3e
        L3c:
            r12 = r13
            goto L61
        L3e:
            deobf.unlinked.zn.a r9 = r8.getVideoCaptureMethod()
            deobf.unlinked.zn.a r11 = deobf.unlinked.zn.a.b
            if (r9 != r11) goto L47
            goto L48
        L47:
            r1 = 0
        L48:
            sn.a0$a r14 = r8.getCameraXControllerFactory()
            r9 = r8
            vo.d$b r8 = new vo.d$b
            r11 = r12
            r12 = r13
            r13 = r1
            r8.<init>(r9, r10, r11, r12, r13)
            r7 = r9
            r9 = r8
            r8 = r7
            boolean r8 = r8.getIsAudioRequired()
            deobf.com.withpersona.sdk2.inquiry.sn.a0 r8 = r14.a(r10, r11, r9, r8)
            return r8
        L61:
            android.content.Context r9 = r9.getApplicationContext()
            java.lang.String r10 = "getApplicationContext(...)"
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r9, r10)
            deobf.com.withpersona.sdk2.inquiry.un.m0 r10 = deobf.com.withpersona.sdk2.inquiry.un.m0.b
            un.k0 r1 = deobf.com.withpersona.sdk2.inquiry.un.f0.b(r9, r10)
            if (r1 != 0) goto L84
            kotlin.jvm.functions.Function1 r8 = r8.D()
            deobf.com.withpersona.sdk2.inquiry.sn.v0 r9 = new deobf.com.withpersona.sdk2.inquiry.sn.v0
            r9.<init>()
            r8.invoke(r9)
            deobf.com.withpersona.sdk2.inquiry.sn.u0 r8 = new deobf.com.withpersona.sdk2.inquiry.sn.u0
            r8.<init>(r11)
            return r8
        L84:
            un.c$a r0 = r8.getCamera2ControllerFactory()
            deobf.unlinked.zn.a r4 = r8.getVideoCaptureMethod()
            deobf.unlinked.ks.a r5 = r8.getWebRtcManager()
            boolean r6 = r8.getIsAudioRequired()
            r2 = r11
            r3 = r12
            deobf.com.withpersona.sdk2.inquiry.un.c r8 = deobf.androidx.camera.view.r0.a(r1, r2, r3, r4, r5, r6)
            return r8
        */
        throw new UnsupportedOperationException("Method not decompiled: deobf.com.withpersona.sdk2.inquiry.vo.d.a(vo.y3$b, android.content.Context, deobf.com.withpersona.sdk2.inquiry.sn.t, com.withpersona.sdk2.camera.camera2.Camera2PreviewView, androidx.camera.view.PreviewView, deobf.com.withpersona.sdk2.inquiry.sn.h0, boolean):deobf.com.withpersona.sdk2.inquiry.sn.i");
    }
}
