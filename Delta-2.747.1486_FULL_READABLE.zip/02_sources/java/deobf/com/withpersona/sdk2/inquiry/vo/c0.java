package deobf.com.withpersona.sdk2.inquiry.vo;

import java.util.Set;

// dex: classes3.dex
public final class c0 implements deobf.com.withpersona.sdk2.inquiry.wt.d<Set<deobf.com.withpersona.sdk2.inquiry.nn.b0<?>>> {

    public final deobf.com.withpersona.sdk2.inquiry.wt.i<deobf.com.withpersona.sdk2.inquiry.xo.z> f34491a;

    public c0(deobf.com.withpersona.sdk2.inquiry.wt.i<deobf.com.withpersona.sdk2.inquiry.xo.z> iVar) {
        this.f34491a = iVar;
    }

    public static c0 a(deobf.com.withpersona.sdk2.inquiry.wt.i<deobf.com.withpersona.sdk2.inquiry.xo.z> iVar) {
        return new c0(iVar);
    }

    public static Set<deobf.com.withpersona.sdk2.inquiry.nn.b0<?>> c(deobf.com.withpersona.sdk2.inquiry.xo.z zVar) {
        return (Set) deobf.com.withpersona.sdk2.inquiry.wt.h.e(deobf.androidx.camera.camera2.internal.compat.quirk.a0.b(zVar));
    }

    @Override // deobf.unlinked.yt.a
    public Set<deobf.com.withpersona.sdk2.inquiry.nn.b0<?>> get() {
        return c(this.f34491a.get());
    }
}
