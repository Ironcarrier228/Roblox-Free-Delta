package deobf.com.withpersona.sdk2.inquiry.vo;

import android.content.Context;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.appsflyer.sdk_base.referrer.Payload;
import com.github.luben.zstd.BuildConfig;
import com.withpersona.sdk2.inquiry.network.dto.NextStep;
import com.withpersona.sdk2.inquiry.network.dto.ui.components.RemoteImage;
import com.withpersona.sdk2.inquiry.network.dto.ui.styling.StepStyles;
import com.withpersona.sdk2.inquiry.network.dto.ui.styling.TextBasedComponentStyle;
import com.withpersona.sdk2.inquiry.shared.ui.Pi2NavigationBar;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.StringsKt;
import deobf.com.withpersona.sdk2.inquiry.nn.ViewEnvironment;
import deobf.com.withpersona.sdk2.inquiry.nn.k;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import deobf.com.withpersona.sdk2.inquiry.vo.y3;

@Metadata(d1 = {"\u0000B\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0010\u000b\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0005\b\u0000\u0018\u0000 \u000f2\b\u0012\u0004\u0012\u00020\u00020\u0001:\u0001\u001fB\u000f\u0012\u0006\u0010\u0004\u001a\u00020\u0003¢\u0006\u0004\b\u0005\u0010\u0006J\u001f\u0010\u000b\u001a\u00020\n2\u0006\u0010\u0007\u001a\u00020\u00022\u0006\u0010\t\u001a\u00020\bH\u0016¢\u0006\u0004\b\u000b\u0010\fJ\u001f\u0010\u000f\u001a\u00020\n2\u0006\u0010\u000e\u001a\u00020\r2\u0006\u0010\t\u001a\u00020\bH\u0002¢\u0006\u0004\b\u000f\u0010\u0010R\u0014\u0010\u0004\u001a\u00020\u00038\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b\u0011\u0010\u0012R\u0014\u0010\u0016\u001a\u00020\u00138\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b\u0014\u0010\u0015R\u0014\u0010\u001a\u001a\u00020\u00178\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b\u0018\u0010\u0019R\u0014\u0010\u001e\u001a\u00020\u001b8\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b\u001c\u0010\u001d¨\u0006 "}, d2 = {"Lvo/w;", "Lnn/k;", "Lvo/y3$e;", "Lap/g;", "binding", "<init>", "(Lap/g;)V", "rendering", "Lnn/z;", "viewEnvironment", BuildConfig.FLAVOR, "h", "(Lvo/y3$e;Lnn/z;)V", "Lcom/withpersona/sdk2/inquiry/network/dto/ui/styling/StepStyles$GovernmentIdStepStyle;", "styles", "f", "(Lcom/withpersona/sdk2/inquiry/network/dto/ui/styling/StepStyles$GovernmentIdStepStyle;Lnn/z;)V", deobf.android.view.k6.b.f21144e, "Lap/g;", BuildConfig.FLAVOR, "c", "Z", "shouldHideSeparators", "Landroidx/recyclerview/widget/h;", "d", "Landroidx/recyclerview/widget/h;", "dividerItemDecoration", "Landroidx/recyclerview/widget/RecyclerView;", "e", "Landroidx/recyclerview/widget/RecyclerView;", "recyclerView", deobf.android.view.xe.a.f36648e, "government-id_release"}, k = 1, mv = {2, 2, 0}, xi = 48)
// dex: classes3.dex
public final class w implements deobf.com.withpersona.sdk2.inquiry.nn.k<deobf.com.google.firebase.y3.e> {

    @NotNull
    public static final Companion INSTANCE = new Companion(null);

    @NotNull
    public final deobf.com.withpersona.sdk2.inquiry.ap.g binding;

    public final boolean shouldHideSeparators;

    @NotNull
    public final androidx.recyclerview.widget.h dividerItemDecoration;

    @NotNull
    public final RecyclerView recyclerView;

    @Metadata(d1 = {"\u00002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0004\b\u0086\u0003\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0003\u0010\u0004J2\u0010\r\u001a\u00020\f2\u0006\u0010\u0005\u001a\u00020\u00022\u0006\u0010\u0007\u001a\u00020\u00062\u0006\u0010\t\u001a\u00020\b2\b\u0010\u000b\u001a\u0004\u0018\u00010\nH\u0096\u0001¢\u0006\u0004\b\r\u0010\u000eR\u001c\u0010\u0012\u001a\n\u0012\u0006\b\u0000\u0012\u00020\u00020\u000f8\u0016X\u0096\u0005¢\u0006\u0006\u001a\u0004\b\u0010\u0010\u0011¨\u0006\u0013"}, d2 = {"Lvo/w$a;", "Lnn/b0;", "Lvo/y3$e;", "<init>", "()V", "initialRendering", "Lnn/z;", "initialViewEnvironment", "Landroid/content/Context;", "contextForNewView", "Landroid/view/ViewGroup;", "container", "Landroid/view/View;", deobf.android.view.k6.b.f21144e, "(Lvo/y3$e;Lnn/z;Landroid/content/Context;Landroid/view/ViewGroup;)Landroid/view/View;", "Lxu/c;", "getType", "()Lxu/c;", Payload.TYPE, "government-id_release"}, k = 1, mv = {2, 2, 0}, xi = 48)
    public static final class Companion implements deobf.com.withpersona.sdk2.inquiry.nn.b0<deobf.com.google.firebase.y3.e> {

        public final /* synthetic */ deobf.com.withpersona.sdk2.inquiry.nn.b0<deobf.com.google.firebase.y3.e> f35001a;

        @Metadata(k = 3, mv = {2, 2, 0}, xi = 48)
        public static final /* synthetic */ class C0718a extends kotlin.jvm.internal.k implements deobf.kotlin.pu.n<LayoutInflater, ViewGroup, Boolean, deobf.com.withpersona.sdk2.inquiry.ap.g> {

            public static final C0718a f35002a = new C0718a();

            public C0718a() {
                super(3, deobf.com.withpersona.sdk2.inquiry.ap.g.class, "inflate", "inflate(Landroid/view/LayoutInflater;Landroid/view/ViewGroup;Z)Lcom/withpersona/sdk2/inquiry/governmentid/databinding/Pi2GovernmentidInstructionsBinding;", 0);
            }

            public final deobf.com.withpersona.sdk2.inquiry.ap.g d(LayoutInflater p02, ViewGroup viewGroup, boolean z10) {
                Intrinsics.checkNotNullParameter(p02, "p0");
                return deobf.com.withpersona.sdk2.inquiry.ap.g.c(p02, viewGroup, z10);
            }

            @Override // deobf.kotlin.pu.n
            public /* bridge */ /* synthetic */ deobf.com.withpersona.sdk2.inquiry.ap.g invoke(LayoutInflater layoutInflater, ViewGroup viewGroup, Boolean bool) {
                return d(layoutInflater, viewGroup, bool.booleanValue());
            }
        }

        @Metadata(k = 3, mv = {2, 2, 0}, xi = 48)
        public static final /* synthetic */ class b extends kotlin.jvm.internal.k implements Function1<deobf.com.withpersona.sdk2.inquiry.ap.g, w> {

            public static final b f35003a = new b();

            public b() {
                super(1, w.class, "<init>", "<init>(Lcom/withpersona/sdk2/inquiry/governmentid/databinding/Pi2GovernmentidInstructionsBinding;)V", 0);
            }

            @Override // kotlin.jvm.functions.Function1
            public final w invoke(deobf.com.withpersona.sdk2.inquiry.ap.g p02) {
                Intrinsics.checkNotNullParameter(p02, "p0");
                return new w(p02);
            }
        }

        public /* synthetic */ Companion(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }

        @Override // deobf.com.withpersona.sdk2.inquiry.nn.b0
        @NotNull
        public View a(@NotNull deobf.com.google.firebase.y3.e initialRendering, @NotNull ViewEnvironment initialViewEnvironment, @NotNull Context contextForNewView, @Nullable ViewGroup container) {
            Intrinsics.checkNotNullParameter(initialRendering, "initialRendering");
            Intrinsics.checkNotNullParameter(initialViewEnvironment, "initialViewEnvironment");
            Intrinsics.checkNotNullParameter(contextForNewView, "contextForNewView");
            return this.f35001a.a(initialRendering, initialViewEnvironment, contextForNewView, container);
        }

        @Override // deobf.com.withpersona.sdk2.inquiry.nn.b0
        @NotNull
        public deobf.kotlin.jvm.internal.xu.c<? super deobf.com.google.firebase.y3.e> getType() {
            return this.f35001a.getType();
        }

        public Companion() {
            k.Companion companion = deobf.com.withpersona.sdk2.inquiry.nn.k.INSTANCE;
            this.f35001a = new deobf.com.withpersona.sdk2.inquiry.nn.y(kotlin.jvm.internal.d0.b(deobf.com.google.firebase.y3.e.class), C0718a.f35002a, b.f35003a);
        }
    }

    public w(@NotNull deobf.com.withpersona.sdk2.inquiry.ap.g binding) {
        Intrinsics.checkNotNullParameter(binding, "binding");
        this.binding = binding;
        Context context = binding.getRoot().getContext();
        Intrinsics.checkNotNullExpressionValue(context, "getContext(...)");
        boolean b = deobf.com.withpersona.sdk2.inquiry.xq.z.b(context, deobf.com.withpersona.sdk2.inquiry.jq.a.f20827e, null, false, false, 14, null);
        this.shouldHideSeparators = b;
        androidx.recyclerview.widget.h hVar = new androidx.recyclerview.widget.h(binding.getRoot().getContext(), 1);
        this.dividerItemDecoration = hVar;
        RecyclerView recyclerView = binding.f3228h;
        recyclerView.setLayoutManager(new LinearLayoutManager(binding.getRoot().getContext()));
        if (!b) {
            recyclerView.j(hVar);
        }
        Intrinsics.checkNotNullExpressionValue(recyclerView, "apply(...)");
        this.recyclerView = recyclerView;
        CoordinatorLayout root = binding.getRoot();
        Intrinsics.checkNotNullExpressionValue(root, "getRoot(...)");
        deobf.com.withpersona.sdk2.inquiry.kr.g.d(root, false, false, false, false, 15, null);
    }

    public static final Unit g(w wVar, double d10) {
        View view = wVar.binding.f3226f;
        ViewGroup.LayoutParams layoutParams = view.getLayoutParams();
        if (d10 > 0.0d) {
            layoutParams.height = (int) deobf.com.withpersona.sdk2.inquiry.xq.j.a(d10);
        } else {
            wVar.binding.f3226f.setVisibility(8);
        }
        view.setLayoutParams(layoutParams);
        return Unit.f21504a;
    }

    public static final Unit i(deobf.com.google.firebase.y3.e eVar, IdConfig idClass) {
        Intrinsics.checkNotNullParameter(idClass, "idClass");
        eVar.o().invoke(idClass);
        return Unit.f21504a;
    }

    public static final Unit j(deobf.com.google.firebase.y3.e eVar) {
        eVar.k().invoke();
        return Unit.f21504a;
    }

    public static final Unit k(deobf.com.google.firebase.y3.e eVar) {
        eVar.l().invoke();
        return Unit.f21504a;
    }

    public final void f(StepStyles.GovernmentIdStepStyle styles, ViewEnvironment viewEnvironment) {
        Integer backgroundColorValue = styles.getBackgroundColorValue();
        if (backgroundColorValue != null) {
            int intValue = backgroundColorValue.intValue();
            this.binding.getRoot().setBackgroundColor(intValue);
            Context context = this.binding.getRoot().getContext();
            Intrinsics.checkNotNullExpressionValue(context, "getContext(...)");
            deobf.unlinked.jr.c.b(viewEnvironment, context, intValue);
        }
        Context context2 = this.binding.getRoot().getContext();
        Intrinsics.checkNotNullExpressionValue(context2, "getContext(...)");
        Drawable a10 = deobf.com.withpersona.sdk2.inquiry.as.d.a(styles, context2);
        if (a10 != null) {
            this.binding.getRoot().setBackground(a10);
        }
        Integer headerButtonColorValue = styles.getHeaderButtonColorValue();
        if (headerButtonColorValue != null) {
            this.binding.f3227g.setControlsColor(headerButtonColorValue.intValue());
        }
        TextBasedComponentStyle titleStyleValue = styles.getTitleStyleValue();
        if (titleStyleValue != null) {
            TextView textviewGovernmentidInstructionsTitle = this.binding.f3231k;
            Intrinsics.checkNotNullExpressionValue(textviewGovernmentidInstructionsTitle, "textviewGovernmentidInstructionsTitle");
            deobf.com.withpersona.sdk2.inquiry.yr.h0.l(textviewGovernmentidInstructionsTitle, titleStyleValue, null, 2, null);
        }
        TextBasedComponentStyle textStyleValue = styles.getTextStyleValue();
        if (textStyleValue != null) {
            TextView textviewGovernmentidInstructionsBody = this.binding.f3229i;
            Intrinsics.checkNotNullExpressionValue(textviewGovernmentidInstructionsBody, "textviewGovernmentidInstructionsBody");
            deobf.com.withpersona.sdk2.inquiry.yr.h0.l(textviewGovernmentidInstructionsBody, textStyleValue, null, 2, null);
            TextView textviewGovernmentidInstructionslistheader = this.binding.f3232l;
            Intrinsics.checkNotNullExpressionValue(textviewGovernmentidInstructionslistheader, "textviewGovernmentidInstructionslistheader");
            deobf.com.withpersona.sdk2.inquiry.yr.h0.l(textviewGovernmentidInstructionslistheader, textStyleValue, null, 2, null);
        }
        TextBasedComponentStyle disclaimerStyleValue = styles.getDisclaimerStyleValue();
        if (disclaimerStyleValue != null) {
            TextView textviewGovernmentidInstructionsDisclaimer = this.binding.f3230j;
            Intrinsics.checkNotNullExpressionValue(textviewGovernmentidInstructionsDisclaimer, "textviewGovernmentidInstructionsDisclaimer");
            deobf.com.withpersona.sdk2.inquiry.yr.h0.l(textviewGovernmentidInstructionsDisclaimer, disclaimerStyleValue, null, 2, null);
        }
        Integer governmentIdSelectOptionBorderColorValue = styles.getGovernmentIdSelectOptionBorderColorValue();
        if (governmentIdSelectOptionBorderColorValue != null) {
            int intValue2 = governmentIdSelectOptionBorderColorValue.intValue();
            GradientDrawable gradientDrawable = new GradientDrawable(GradientDrawable.Orientation.BOTTOM_TOP, new int[]{intValue2, intValue2});
            gradientDrawable.setSize((int) Math.ceil(deobf.com.withpersona.sdk2.inquiry.xq.j.a(1.0d)), (int) Math.ceil(deobf.com.withpersona.sdk2.inquiry.xq.j.a(1.0d)));
            this.dividerItemDecoration.m(gradientDrawable);
            this.binding.f3226f.setBackgroundColor(intValue2);
        }
        Double governmentIdOptionBorderWidthValue = styles.getGovernmentIdOptionBorderWidthValue();
        if (governmentIdOptionBorderWidthValue != null) {
            final double doubleValue = governmentIdOptionBorderWidthValue.doubleValue();
            GradientDrawable gradientDrawable2 = (GradientDrawable) this.dividerItemDecoration.l();
            if (gradientDrawable2 != null) {
                gradientDrawable2.setSize((int) Math.ceil(deobf.com.withpersona.sdk2.inquiry.xq.j.a(doubleValue)), (int) Math.ceil(deobf.com.withpersona.sdk2.inquiry.xq.j.a(doubleValue)));
            }
            View listDivider = this.binding.f3226f;
            Intrinsics.checkNotNullExpressionValue(listDivider, "listDivider");
            deobf.com.withpersona.sdk2.inquiry.kr.a0.b(listDivider, new Function0() { // from class: vo.v
                @Override // kotlin.jvm.functions.Function0
                public final Object invoke() {
                    Unit g10;
                    g10 = w.g(w.this, doubleValue);
                    return g10;
                }
            });
        }
        ConstraintLayout contentContainer = this.binding.b;
        Intrinsics.checkNotNullExpressionValue(contentContainer, "contentContainer");
        deobf.com.withpersona.sdk2.inquiry.yr.p.b(contentContainer, styles, false, false, 6, null);
    }

    @Override // deobf.com.withpersona.sdk2.inquiry.nn.k
    public void a(@NotNull final deobf.com.google.firebase.y3.e rendering, @NotNull ViewEnvironment viewEnvironment) {
        Intrinsics.checkNotNullParameter(rendering, "rendering");
        Intrinsics.checkNotNullParameter(viewEnvironment, "viewEnvironment");
        Context context = this.binding.getRoot().getContext();
        Intrinsics.checkNotNullExpressionValue(context, "getContext(...)");
        Integer f10 = deobf.com.withpersona.sdk2.inquiry.xq.z.f(context, deobf.com.withpersona.sdk2.inquiry.jq.a.f20825c, null, false, 6, null);
        NextStep.GovernmentId.AssetConfig.SelectPage assetConfig = rendering.getAssetConfig();
        RemoteImage headerPictograph = assetConfig != null ? assetConfig.getHeaderPictograph() : null;
        if (f10 != null) {
            this.binding.f3225e.setImageResource(f10.intValue());
            TextView textviewGovernmentidInstructionsTitle = this.binding.f3231k;
            Intrinsics.checkNotNullExpressionValue(textviewGovernmentidInstructionsTitle, "textviewGovernmentidInstructionsTitle");
            ViewGroup.LayoutParams layoutParams = textviewGovernmentidInstructionsTitle.getLayoutParams();
            if (layoutParams == null) {
                throw new NullPointerException("null cannot be cast to non-null type android.view.ViewGroup.MarginLayoutParams");
            }
            ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) layoutParams;
            marginLayoutParams.topMargin = 0;
            textviewGovernmentidInstructionsTitle.setLayoutParams(marginLayoutParams);
            this.binding.f3224d.setVisibility(8);
            this.binding.f3225e.setVisibility(0);
        } else if (headerPictograph != null) {
            ConstraintLayout governmentidHeaderImageContainer = this.binding.f3224d;
            Intrinsics.checkNotNullExpressionValue(governmentidHeaderImageContainer, "governmentidHeaderImageContainer");
            deobf.com.withpersona.sdk2.inquiry.as.c.f(headerPictograph, governmentidHeaderImageContainer, false, 2, null);
            this.binding.f3224d.setVisibility(0);
            this.binding.f3225e.setVisibility(8);
        } else {
            this.binding.f3224d.setVisibility(8);
            this.binding.f3225e.setVisibility(8);
        }
        TextView textviewGovernmentidInstructionsTitle2 = this.binding.f3231k;
        Intrinsics.checkNotNullExpressionValue(textviewGovernmentidInstructionsTitle2, "textviewGovernmentidInstructionsTitle");
        deobf.com.withpersona.sdk2.inquiry.kr.u.b(textviewGovernmentidInstructionsTitle2, rendering.getTitle());
        TextView textviewGovernmentidInstructionsBody = this.binding.f3229i;
        Intrinsics.checkNotNullExpressionValue(textviewGovernmentidInstructionsBody, "textviewGovernmentidInstructionsBody");
        deobf.com.withpersona.sdk2.inquiry.kr.u.b(textviewGovernmentidInstructionsBody, rendering.getPrompt());
        TextView textviewGovernmentidInstructionslistheader = this.binding.f3232l;
        Intrinsics.checkNotNullExpressionValue(textviewGovernmentidInstructionslistheader, "textviewGovernmentidInstructionslistheader");
        deobf.com.withpersona.sdk2.inquiry.kr.u.b(textviewGovernmentidInstructionslistheader, rendering.getChooseText());
        TextView textviewGovernmentidInstructionsDisclaimer = this.binding.f3230j;
        Intrinsics.checkNotNullExpressionValue(textviewGovernmentidInstructionsDisclaimer, "textviewGovernmentidInstructionsDisclaimer");
        deobf.com.withpersona.sdk2.inquiry.kr.u.b(textviewGovernmentidInstructionsDisclaimer, rendering.getDisclaimer());
        if (!StringsKt.p0(rendering.getDisclaimer())) {
            this.binding.f3227g.setAccessibilityTraversalAfter(n3.H0);
        }
        this.binding.f3226f.setVisibility(this.shouldHideSeparators ? 8 : 0);
        RecyclerView.h adapter = this.recyclerView.getAdapter();
        z zVar = adapter instanceof z ? (z) adapter : null;
        if (zVar == null) {
            Context context2 = this.binding.getRoot().getContext();
            Intrinsics.checkNotNullExpressionValue(context2, "getContext(...)");
            zVar = new z(context2, rendering.f(), rendering.getStyles(), rendering.getAssetConfig(), rendering.getIconStyle(), new Function1() { // from class: vo.s
                @Override // kotlin.jvm.functions.Function1
                public final Object invoke(Object obj) {
                    Unit i10;
                    i10 = w.i(deobf.com.google.firebase.y3.e.this, (IdConfig) obj);
                    return i10;
                }
            });
        }
        if (this.recyclerView.getAdapter() == null) {
            this.recyclerView.setAdapter(zVar);
        }
        zVar.I(rendering.getIsEnabled());
        deobf.com.withpersona.sdk2.inquiry.ir.a navigationState = rendering.getNavigationState();
        Function0 function0 = new Function0() { // from class: vo.t
            @Override // kotlin.jvm.functions.Function0
            public final Object invoke() {
                Unit j10;
                j10 = w.j(deobf.com.google.firebase.y3.e.this);
                return j10;
            }
        };
        Function0 function02 = new Function0() { // from class: vo.u
            @Override // kotlin.jvm.functions.Function0
            public final Object invoke() {
                Unit k10;
                k10 = w.k(deobf.com.google.firebase.y3.e.this);
                return k10;
            }
        };
        Pi2NavigationBar navigationBar = this.binding.f3227g;
        Intrinsics.checkNotNullExpressionValue(navigationBar, "navigationBar");
        CoordinatorLayout root = this.binding.getRoot();
        Intrinsics.checkNotNullExpressionValue(root, "getRoot(...)");
        StepStyles.GovernmentIdStepStyle styles = rendering.getStyles();
        Rect h10 = styles != null ? deobf.com.withpersona.sdk2.inquiry.sr.h.h(styles) : null;
        String navBarTitle = rendering.getNavBarTitle();
        StepStyles.GovernmentIdStepStyle styles2 = rendering.getStyles();
        deobf.unlinked.xr.c.e(navigationState, function0, function02, null, navigationBar, root, h10, navBarTitle, styles2 != null ? styles2.getNavBarTitleStyleValue() : null, 8, null);
        CoordinatorLayout root2 = this.binding.getRoot();
        Intrinsics.checkNotNullExpressionValue(root2, "getRoot(...)");
        deobf.com.withpersona.sdk2.inquiry.xq.g0.b(root2, rendering.getError(), rendering.m(), null, 0, 0, 56, null);
        StepStyles.GovernmentIdStepStyle styles3 = rendering.getStyles();
        if (styles3 != null) {
            f(styles3, viewEnvironment);
        }
    }
}
