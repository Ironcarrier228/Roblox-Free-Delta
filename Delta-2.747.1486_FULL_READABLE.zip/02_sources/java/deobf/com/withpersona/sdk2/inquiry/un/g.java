package deobf.com.withpersona.sdk2.inquiry.un;

import android.media.Image;
import com.github.luben.zstd.BuildConfig;
import kotlin.Metadata;
import org.jetbrains.annotations.NotNull;

@Metadata(d1 = {"\u0000\u001c\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0003\bf\u0018\u00002\u00020\u0001J\u001f\u0010\u0007\u001a\u00020\u00062\u0006\u0010\u0003\u001a\u00020\u00022\u0006\u0010\u0005\u001a\u00020\u0004H&¢\u0006\u0004\b\u0007\u0010\b¨\u0006\tÀ\u0006\u0003"}, d2 = {"Lun/g;", BuildConfig.FLAVOR, "Landroid/media/Image;", "image", BuildConfig.FLAVOR, "rotationDegrees", BuildConfig.FLAVOR, "i", "(Landroid/media/Image;I)V", "camera_release"}, k = 1, mv = {2, 2, 0}, xi = 48)
// dex: classes3.dex
public interface g {
    void i(@NotNull Image image, int rotationDegrees);
}
