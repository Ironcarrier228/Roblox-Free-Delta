package deobf.com.withpersona.sdk2.inquiry.vo;

import deobf.com.withpersona.sdk2.inquiry.vo.GovernmentIdAnalyzeWorker;
import deobf.com.withpersona.sdk2.inquiry.vo.IdConfig;

// dex: classes3.dex
public final class q implements GovernmentIdAnalyzeWorker.a {

    public final p f34952a;

    public q(p pVar) {
        this.f34952a = pVar;
    }

    public static deobf.com.withpersona.sdk2.inquiry.wt.i<GovernmentIdAnalyzeWorker.a> b(p pVar) {
        return deobf.com.withpersona.sdk2.inquiry.wt.e.a(new q(pVar));
    }

    @Override // vo.GovernmentIdAnalyzeWorker.a
    public GovernmentIdAnalyzeWorker a(IdConfig.e eVar, String str) {
        return this.f34952a.b(eVar, str);
    }
}
