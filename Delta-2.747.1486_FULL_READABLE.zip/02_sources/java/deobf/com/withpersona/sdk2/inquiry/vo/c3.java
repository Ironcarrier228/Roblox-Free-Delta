package deobf.com.withpersona.sdk2.inquiry.vo;

import android.content.Context;
import com.withpersona.sdk2.inquiry.governmentid.network.AutoClassifyWorker;
import com.withpersona.sdk2.inquiry.tracking.TrackingEventsLogger;
import deobf.com.withpersona.sdk2.inquiry.dp.f;

// dex: classes3.dex
public final class c3 implements deobf.com.withpersona.sdk2.inquiry.wt.d<d2> {

    public final deobf.com.withpersona.sdk2.inquiry.wt.i<Context> f34496a;
    public final deobf.com.withpersona.sdk2.inquiry.wt.i<deobf.com.roblox.client.l6.s> b;

    public final deobf.com.withpersona.sdk2.inquiry.wt.i<deobf.unlinked.f.a> f34497c;

    public final deobf.com.withpersona.sdk2.inquiry.wt.i<j> f34498d;

    public final deobf.com.withpersona.sdk2.inquiry.wt.i<deobf.unlinked.ip.j> f34499e;

    public final deobf.com.withpersona.sdk2.inquiry.wt.i<deobf.unlinked.ip.v> f34500f;

    public final deobf.com.withpersona.sdk2.inquiry.wt.i<deobf.com.withpersona.sdk2.inquiry.yo.t0> f34501g;

    public final deobf.com.withpersona.sdk2.inquiry.wt.i<AutoClassifyWorker.b> f34502h;

    public final deobf.com.withpersona.sdk2.inquiry.wt.i<deobf.com.withpersona.sdk2.inquiry.wo.o> f34503i;

    public final deobf.com.withpersona.sdk2.inquiry.wt.i<deobf.unlinked.yn.a> f34504j;

    public final deobf.com.withpersona.sdk2.inquiry.wt.i<deobf.com.withpersona.sdk2.inquiry.ir.b> f34505k;

    public final deobf.com.withpersona.sdk2.inquiry.wt.i<deobf.com.withpersona.sdk2.inquiry.dr.c> f34506l;

    public final deobf.com.withpersona.sdk2.inquiry.wt.i<TrackingEventsLogger> f34507m;

    public final deobf.com.withpersona.sdk2.inquiry.wt.i<deobf.com.withpersona.sdk2.inquiry.gr.b> f34508n;

    public c3(deobf.com.withpersona.sdk2.inquiry.wt.i<Context> iVar, deobf.com.withpersona.sdk2.inquiry.wt.i<deobf.com.roblox.client.l6.s> iVar2, deobf.com.withpersona.sdk2.inquiry.wt.i<deobf.unlinked.f.a> iVar3, deobf.com.withpersona.sdk2.inquiry.wt.i<j> iVar4, deobf.com.withpersona.sdk2.inquiry.wt.i<deobf.unlinked.ip.j> iVar5, deobf.com.withpersona.sdk2.inquiry.wt.i<deobf.unlinked.ip.v> iVar6, deobf.com.withpersona.sdk2.inquiry.wt.i<deobf.com.withpersona.sdk2.inquiry.yo.t0> iVar7, deobf.com.withpersona.sdk2.inquiry.wt.i<AutoClassifyWorker.b> iVar8, deobf.com.withpersona.sdk2.inquiry.wt.i<deobf.com.withpersona.sdk2.inquiry.wo.o> iVar9, deobf.com.withpersona.sdk2.inquiry.wt.i<deobf.unlinked.yn.a> iVar10, deobf.com.withpersona.sdk2.inquiry.wt.i<deobf.com.withpersona.sdk2.inquiry.ir.b> iVar11, deobf.com.withpersona.sdk2.inquiry.wt.i<deobf.com.withpersona.sdk2.inquiry.dr.c> iVar12, deobf.com.withpersona.sdk2.inquiry.wt.i<TrackingEventsLogger> iVar13, deobf.com.withpersona.sdk2.inquiry.wt.i<deobf.com.withpersona.sdk2.inquiry.gr.b> iVar14) {
        this.f34496a = iVar;
        this.b = iVar2;
        this.f34497c = iVar3;
        this.f34498d = iVar4;
        this.f34499e = iVar5;
        this.f34500f = iVar6;
        this.f34501g = iVar7;
        this.f34502h = iVar8;
        this.f34503i = iVar9;
        this.f34504j = iVar10;
        this.f34505k = iVar11;
        this.f34506l = iVar12;
        this.f34507m = iVar13;
        this.f34508n = iVar14;
    }

    public static c3 a(deobf.com.withpersona.sdk2.inquiry.wt.i<Context> iVar, deobf.com.withpersona.sdk2.inquiry.wt.i<deobf.com.roblox.client.l6.s> iVar2, deobf.com.withpersona.sdk2.inquiry.wt.i<deobf.unlinked.f.a> iVar3, deobf.com.withpersona.sdk2.inquiry.wt.i<j> iVar4, deobf.com.withpersona.sdk2.inquiry.wt.i<deobf.unlinked.ip.j> iVar5, deobf.com.withpersona.sdk2.inquiry.wt.i<deobf.unlinked.ip.v> iVar6, deobf.com.withpersona.sdk2.inquiry.wt.i<deobf.com.withpersona.sdk2.inquiry.yo.t0> iVar7, deobf.com.withpersona.sdk2.inquiry.wt.i<AutoClassifyWorker.b> iVar8, deobf.com.withpersona.sdk2.inquiry.wt.i<deobf.com.withpersona.sdk2.inquiry.wo.o> iVar9, deobf.com.withpersona.sdk2.inquiry.wt.i<deobf.unlinked.yn.a> iVar10, deobf.com.withpersona.sdk2.inquiry.wt.i<deobf.com.withpersona.sdk2.inquiry.ir.b> iVar11, deobf.com.withpersona.sdk2.inquiry.wt.i<deobf.com.withpersona.sdk2.inquiry.dr.c> iVar12, deobf.com.withpersona.sdk2.inquiry.wt.i<TrackingEventsLogger> iVar13, deobf.com.withpersona.sdk2.inquiry.wt.i<deobf.com.withpersona.sdk2.inquiry.gr.b> iVar14) {
        return new c3(iVar, iVar2, iVar3, iVar4, iVar5, iVar6, iVar7, iVar8, iVar9, iVar10, iVar11, iVar12, iVar13, iVar14);
    }

    public static d2 c(Context context, deobf.com.roblox.client.l6.s sVar, deobf.unlinked.f.a aVar, j jVar, deobf.unlinked.ip.j jVar2, deobf.unlinked.ip.v vVar, deobf.com.withpersona.sdk2.inquiry.yo.t0 t0Var, AutoClassifyWorker.b bVar, deobf.com.withpersona.sdk2.inquiry.wo.o oVar, deobf.unlinked.yn.a aVar2, deobf.com.withpersona.sdk2.inquiry.ir.b bVar2, deobf.com.withpersona.sdk2.inquiry.dr.c cVar, TrackingEventsLogger trackingEventsLogger, deobf.com.withpersona.sdk2.inquiry.gr.b bVar3) {
        return new d2(context, sVar, aVar, jVar, jVar2, vVar, t0Var, bVar, oVar, aVar2, bVar2, cVar, trackingEventsLogger, bVar3);
    }

    @Override // deobf.unlinked.yt.a
    public d2 get() {
        return c(this.f34496a.get(), this.b.get(), this.f34497c.get(), this.f34498d.get(), this.f34499e.get(), this.f34500f.get(), this.f34501g.get(), this.f34502h.get(), this.f34503i.get(), this.f34504j.get(), this.f34505k.get(), this.f34506l.get(), this.f34507m.get(), this.f34508n.get());
    }
}
