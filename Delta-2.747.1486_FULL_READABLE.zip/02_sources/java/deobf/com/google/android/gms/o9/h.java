package deobf.com.google.android.gms.o9;

import android.accounts.Account;
import android.os.Bundle;
import android.os.IBinder;
import android.os.Parcel;
import android.os.Parcelable;
import androidx.annotation.NonNull;
import com.google.android.gms.common.api.Scope;
import deobf.com.google.android.gms.o9.l;

// dex: classes.dex
public class h extends deobf.com.google.android.gms.p9.a {

    @NonNull
    public static final Parcelable.Creator<h> CREATOR = new o1();

    public static final Scope[] f26961t = new Scope[0];

    public static final deobf.com.google.mlkit.vision.k9.d[] f26962u = new deobf.com.google.mlkit.vision.k9.d[0];

    public final int f26963f;

    public final int f26964g;

    public final int f26965h;

    public String f26966i;

    public IBinder f26967j;

    public Scope[] f26968k;

    public Bundle f26969l;

    public Account f26970m;

    public deobf.com.google.mlkit.vision.k9.d[] f26971n;

    public deobf.com.google.mlkit.vision.k9.d[] f26972o;

    public final boolean f26973p;

    public final int f26974q;

    public boolean f26975r;

    public final String f26976s;

    public h(int i10, int i11, int i12, String str, IBinder iBinder, Scope[] scopeArr, Bundle bundle, Account account, deobf.com.google.mlkit.vision.k9.d[] dVarArr, deobf.com.google.mlkit.vision.k9.d[] dVarArr2, boolean z10, int i13, boolean z11, String str2) {
        scopeArr = scopeArr == null ? f26961t : scopeArr;
        bundle = bundle == null ? new Bundle() : bundle;
        dVarArr = dVarArr == null ? f26962u : dVarArr;
        dVarArr2 = dVarArr2 == null ? f26962u : dVarArr2;
        this.f26963f = i10;
        this.f26964g = i11;
        this.f26965h = i12;
        if ("com.google.android.gms".equals(str)) {
            this.f26966i = "com.google.android.gms";
        } else {
            this.f26966i = str;
        }
        if (i10 < 2) {
            this.f26970m = iBinder != null ? a.t2(deobf.unlinked.l.a.s2(iBinder)) : null;
        } else {
            this.f26967j = iBinder;
            this.f26970m = account;
        }
        this.f26968k = scopeArr;
        this.f26969l = bundle;
        this.f26971n = dVarArr;
        this.f26972o = dVarArr2;
        this.f26973p = z10;
        this.f26974q = i13;
        this.f26975r = z11;
        this.f26976s = str2;
    }

    public String A3() {
        return this.f26976s;
    }

    @Override // android.os.Parcelable
    public final void writeToParcel(@NonNull Parcel parcel, int i10) {
        deobf.unlinked.o1.a(this, parcel, i10);
    }
}
