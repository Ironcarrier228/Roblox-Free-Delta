package deobf.com.google.android.gms.fb;

import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;

// dex: classes.dex
public final class w4 extends a implements IInterface {
    public w4(IBinder iBinder) {
        super(iBinder, "com.google.android.gms.fido.fido2.internal.regular.IFido2AppService");
    }

    /* JADX WARN: Multi-variable type inference failed */
    public final void t2(v4 v4Var, deobf.androidx.credentials.playservices.controllers.identityauth.createpublickeycredential.da.r rVar) {
        Parcel r22 = r2();
        ClassLoader classLoader = b1.f15720a;
        r22.writeStrongBinder(v4Var);
        deobf.androidx.camera.camera2.internal.compat.quirk.b1.c(r22, rVar);
        s2(1, r22);
    }
}
