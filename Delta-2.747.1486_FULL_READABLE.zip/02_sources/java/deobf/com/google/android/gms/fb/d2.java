package deobf.com.google.android.gms.fb;

import java.util.ListIterator;

// dex: classes.dex
public abstract class d2 extends c2 implements ListIterator {
    @Override // java.util.ListIterator
    @Deprecated
    public final void add(Object obj) {
        throw new UnsupportedOperationException();
    }

    @Override // java.util.ListIterator
    @Deprecated
    public final void set(Object obj) {
        throw new UnsupportedOperationException();
    }
}
