package deobf.com.google.android.gms.o9;

// dex: classes.dex
public final class u1 {

    public final String f27048a;
    public final String b;

    public final boolean f27049c;

    public u1(String str, String str2, boolean z10, int i10, boolean z11) {
        this.b = str;
        this.f27048a = str2;
        this.f27049c = z11;
    }

    public final String a() {
        return this.f27048a;
    }

    public final String b() {
        return this.b;
    }

    public final boolean c() {
        return this.f27049c;
    }
}
