package deobf.com.google.android.gms.fb;

import com.appsflyer.sdk_base.referrer.Payload;

// dex: classes.dex
public final class p3 {

    public static final c4 f15796a = e4.m("id");
    public static final c4 b = e4.m(Payload.TYPE);

    public static final c4 f15797c = e4.m("transports");

    public static final c4 f15798d = e4.m("name");

    public static final c4 f15799e = e4.m("icon");

    public static final c4 f15800f = e4.m("displayName");

    public static final c4 f15801g = e4.m("alg");

    public static final c4 f15802h = e4.m("plat");

    public static final c4 f15803i = e4.m("rk");

    public static final c4 f15804j = e4.m("clientPin");

    public static final c4 f15805k = e4.m("up");

    public static final c4 f15806l = e4.m("uv");

    public static final c4 f15807m = e4.m("alwaysUv");

    public static final c4 f15808n = e4.m("credMgmt");

    public static final c4 f15809o = e4.m("authnrCfg");

    public static final c4 f15810p = e4.m("bioEnroll");

    public static final c4 f15811q = e4.m("largeBlobs");

    public static final c4 f15812r = e4.m("pinUvAuthToken");

    public static final c4 f15813s = e4.m("noMcGaPermissionsWithClientPin");

    public static final c4 f15814t = e4.m("ep");

    public static final c4 f15815u = e4.m("uvBioEnroll");

    public static final c4 f15816v = e4.m("uvAcfg");

    public static final c4 f15817w = e4.m("setMinPINLength");

    public static final c4 f15818x = e4.m("makeCredUvNotRqd");

    public static final c4 f15819y = e4.m("credentialMgmtPreview");

    public static final c4 f15820z = e4.m("userVerificationMgmtPreview");
    public static final c4 A = e4.m("uvm");
    public static final c4 B = e4.m("hmac-secret");
    public static final c4 C = e4.m("multiAssertion");
    public static final c4 D = e4.m("sessionId");
    public static final c4 E = e4.m("google_userVerificationOrigin");
}
