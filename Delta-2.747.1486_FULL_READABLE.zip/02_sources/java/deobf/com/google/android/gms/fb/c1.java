package deobf.com.google.android.gms.fb;

import java.util.List;

// dex: classes.dex
public final class c1 extends e1 {

    public final transient e1 f15722c;

    public c1(e1 e1Var) {
        this.f15722c = e1Var;
    }

    @Override // deobf.com.google.android.gms.fb.e1, deobf.com.google.android.gms.fb.z0, java.util.AbstractCollection, java.util.Collection, java.util.List
    public final boolean contains(Object obj) {
        return this.f15722c.contains(obj);
    }

    @Override // deobf.com.google.android.gms.fb.e1
    public final e1 f() {
        return this.f15722c;
    }

    @Override // deobf.com.google.android.gms.fb.e1
    public final e1 subList(int i10, int i11) {
        deobf.androidx.camera.camera2.internal.compat.quirk.n0.e(i10, i11, this.f15722c.size());
        e1 e1Var = this.f15722c;
        return e1Var.subList(e1Var.size() - i11, this.f15722c.size() - i10).f();
    }

    @Override // java.util.List
    public final Object get(int i10) {
        n0.a(i10, this.f15722c.size(), "index");
        return this.f15722c.get(m(i10));
    }

    @Override // deobf.com.google.android.gms.fb.e1, java.util.List
    public final int indexOf(Object obj) {
        int lastIndexOf = this.f15722c.lastIndexOf(obj);
        if (lastIndexOf >= 0) {
            return m(lastIndexOf);
        }
        return -1;
    }

    @Override // deobf.com.google.android.gms.fb.e1, java.util.List
    public final int lastIndexOf(Object obj) {
        int indexOf = this.f15722c.indexOf(obj);
        if (indexOf >= 0) {
            return m(indexOf);
        }
        return -1;
    }

    public final int m(int i10) {
        return (this.f15722c.size() - 1) - i10;
    }

    @Override // java.util.AbstractCollection, java.util.Collection, java.util.List
    public final int size() {
        return this.f15722c.size();
    }

    @Override // deobf.com.google.android.gms.fb.e1, java.util.List
    public final /* bridge */ /* synthetic */ List subList(int i10, int i11) {
        return subList(i10, i11);
    }
}
