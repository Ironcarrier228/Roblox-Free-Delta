package deobf.com.google.android.gms.o9;

import android.content.Context;
import androidx.annotation.NonNull;

// dex: classes.dex
public class x {
    @NonNull
    public static y a(@NonNull Context context) {
        return b(context, deobf.androidx.camera.camera2.z.b);
    }

    @NonNull
    public static y b(@NonNull Context context, @NonNull z zVar) {
        return new deobf.unlinked.q9.d(context, zVar);
    }
}
