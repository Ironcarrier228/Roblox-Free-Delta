package deobf.com.google.android.gms.o9;

import android.util.Log;
import java.util.Objects;

// dex: classes.dex
public abstract class f1 {

    public Object f26950a;
    public boolean b;

    public final /* synthetic */ d f26951c;

    public f1(d dVar, Object obj) {
        Objects.requireNonNull(dVar);
        this.f26951c = dVar;
        this.f26950a = obj;
        this.b = false;
    }

    public abstract void a(Object obj);

    public final void b() {
        Object obj;
        synchronized (this) {
            try {
                obj = this.f26950a;
                if (this.b) {
                    String obj2 = toString();
                    StringBuilder sb2 = new StringBuilder(obj2.length() + 47);
                    sb2.append("Callback proxy ");
                    sb2.append(obj2);
                    sb2.append(" being reused. This is not safe.");
                    Log.w("GmsClient", sb2.toString());
                }
            } catch (Throwable th2) {
                throw th2;
            }
        }
        if (obj != null) {
            a(obj);
        }
        synchronized (this) {
            this.b = true;
        }
        c();
    }

    public final void c() {
        d();
        d dVar = this.f26951c;
        synchronized (dVar.zzj()) {
            dVar.zzj().remove(this);
        }
    }

    public final void d() {
        synchronized (this) {
            this.f26950a = null;
        }
    }
}
