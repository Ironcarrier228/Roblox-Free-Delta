package deobf.com.google.android.gms.o9;

import android.content.Intent;

// dex: classes.dex
public final class h0 extends i0 {

    public final /* synthetic */ Intent f26977a;
    public final /* synthetic */ deobf.com.google.android.gms.m9.j b;

    public h0(Intent intent, deobf.com.google.android.gms.m9.j jVar, int i10) {
        this.f26977a = intent;
        this.b = jVar;
    }

    @Override // deobf.com.google.android.gms.o9.i0
    public final void a() {
        Intent intent = this.f26977a;
        if (intent != null) {
            this.b.startActivityForResult(intent, 2);
        }
    }
}
