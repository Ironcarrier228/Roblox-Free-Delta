package deobf.com.google.android.gms.fb;

// dex: classes.dex
public final class g4 {

    public final byte f15738a;
    public final byte b;

    public g4(int i10) {
        this.f15738a = (byte) (i10 & 224);
        this.b = (byte) (i10 & 31);
    }

    public final byte a() {
        return this.b;
    }

    public final byte b() {
        return this.f15738a;
    }

    public final int c() {
        return (this.f15738a >> 5) & 7;
    }
}
