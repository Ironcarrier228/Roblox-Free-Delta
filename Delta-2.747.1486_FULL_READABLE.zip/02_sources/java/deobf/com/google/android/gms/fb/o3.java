package deobf.com.google.android.gms.fb;

// dex: classes.dex
public final class o3 extends r3 {
    public final byte[] b;

    public int f15783c;

    public int f15784d;

    public int f15785e;

    public /* synthetic */ o3(byte[] bArr, int i10, int i11, boolean z10, n3 n3Var) {
        super(null);
        this.f15785e = Integer.MAX_VALUE;
        this.b = bArr;
        this.f15783c = 0;
    }

    public final int a(int i10) {
        int i11 = this.f15785e;
        this.f15785e = 0;
        int i12 = this.f15783c + this.f15784d;
        this.f15783c = i12;
        if (i12 <= 0) {
            this.f15784d = 0;
            return i11;
        }
        this.f15784d = i12;
        this.f15783c = 0;
        return i11;
    }
}
