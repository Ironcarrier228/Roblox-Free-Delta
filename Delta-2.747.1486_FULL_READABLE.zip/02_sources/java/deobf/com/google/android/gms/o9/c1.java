package deobf.com.google.android.gms.o9;

import android.os.Parcel;
import android.os.Parcelable;

// dex: classes.dex
public final class c1 implements Parcelable.Creator {
    @Override // android.os.Parcelable.Creator
    public final /* bridge */ /* synthetic */ Object createFromParcel(Parcel parcel) {
        int D = deobf.com.google.android.gms.p9.b.D(parcel);
        int i10 = 0;
        boolean z10 = false;
        boolean z11 = false;
        int i11 = 0;
        int i12 = 0;
        while (parcel.dataPosition() < D) {
            int u8 = deobf.com.google.android.gms.p9.b.u(parcel);
            int n10 = deobf.com.google.android.gms.p9.b.n(u8);
            if (n10 == 1) {
                i10 = deobf.com.google.android.gms.p9.b.w(parcel, u8);
            } else if (n10 == 2) {
                z10 = deobf.com.google.android.gms.p9.b.o(parcel, u8);
            } else if (n10 == 3) {
                z11 = deobf.com.google.android.gms.p9.b.o(parcel, u8);
            } else if (n10 == 4) {
                i11 = deobf.com.google.android.gms.p9.b.w(parcel, u8);
            } else if (n10 != 5) {
                deobf.com.google.android.gms.p9.b.C(parcel, u8);
            } else {
                i12 = deobf.com.google.android.gms.p9.b.w(parcel, u8);
            }
        }
        deobf.com.google.android.gms.p9.b.m(parcel, D);
        return new u(i10, z10, z11, i11, i12);
    }

    @Override // android.os.Parcelable.Creator
    public final /* synthetic */ Object[] newArray(int i10) {
        return new u[i10];
    }
}
