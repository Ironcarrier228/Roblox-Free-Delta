package deobf.com.google.android.gms.fb;

import android.content.Context;
import android.os.Bundle;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Looper;
import androidx.annotation.NonNull;
import deobf.com.google.android.gms.l9.h;

// dex: classes.dex
public final class d extends deobf.com.google.android.gms.o9.i {
    public d(Context context, Looper looper, deobf.com.google.android.gms.o9.f fVar, deobf.com.roblox.protocols.mediapicker.h.a aVar, deobf.com.roblox.protocols.mediapicker.h.b bVar) {
        super(context, looper, 119, fVar, aVar, bVar);
    }

    @Override // deobf.com.google.android.gms.o9.d
    public final /* synthetic */ IInterface createServiceInterface(IBinder iBinder) {
        if (iBinder == null) {
            return null;
        }
        IInterface queryLocalInterface = iBinder.queryLocalInterface("com.google.android.gms.fido.u2f.internal.zeroparty.IU2fZeroPartyService");
        return queryLocalInterface instanceof x4 ? (x4) queryLocalInterface : new x4(iBinder);
    }

    @Override // deobf.com.google.android.gms.o9.d
    public final Bundle getGetServiceRequestExtraArgs() {
        Bundle bundle = new Bundle();
        bundle.putString("ACTION_START_SERVICE", "com.google.android.gms.fido.u2f.zeroparty.START");
        return bundle;
    }

    @Override // deobf.com.google.android.gms.o9.d, deobf.com.google.android.gms.l9.a.f
    public final int getMinApkVersion() {
        return 13000000;
    }

    @Override // deobf.com.google.android.gms.o9.d
    @NonNull
    public final String getServiceDescriptor() {
        return "com.google.android.gms.fido.u2f.internal.zeroparty.IU2fZeroPartyService";
    }

    @Override // deobf.com.google.android.gms.o9.d
    @NonNull
    public final String getStartServiceAction() {
        return "com.google.android.gms.fido.u2f.zeroparty.START";
    }

    @Override // deobf.com.google.android.gms.o9.d
    public final boolean usesClientTelemetry() {
        return true;
    }
}
