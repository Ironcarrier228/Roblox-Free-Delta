package deobf.com.google.android.gms.o9;

import android.os.Bundle;
import android.os.IBinder;
import android.os.Parcel;

// dex: classes.dex
public abstract class z1 extends deobf.com.google.android.gms.eb.n implements m {
    public z1() {
        super("com.google.android.gms.common.internal.IGmsCallbacks");
    }

    @Override // deobf.com.google.android.gms.eb.n
    public final boolean r2(int i10, Parcel parcel, Parcel parcel2, int i11) {
        if (i10 == 1) {
            int readInt = parcel.readInt();
            IBinder readStrongBinder = parcel.readStrongBinder();
            Bundle bundle = (Bundle) deobf.com.google.android.gms.eb.o.b(parcel, Bundle.CREATOR);
            deobf.com.google.android.gms.eb.o.e(parcel);
            Z(readInt, readStrongBinder, bundle);
        } else if (i10 == 2) {
            int readInt2 = parcel.readInt();
            Bundle bundle2 = (Bundle) deobf.com.google.android.gms.eb.o.b(parcel, Bundle.CREATOR);
            deobf.com.google.android.gms.eb.o.e(parcel);
            i(readInt2, bundle2);
        } else {
            if (i10 != 3) {
                return false;
            }
            int readInt3 = parcel.readInt();
            IBinder readStrongBinder2 = parcel.readStrongBinder();
            l1 l1Var = (l1) deobf.com.google.android.gms.eb.o.b(parcel, l1.CREATOR);
            deobf.com.google.android.gms.eb.o.e(parcel);
            T1(readInt3, readStrongBinder2, l1Var);
        }
        parcel2.writeNoException();
        return true;
    }
}
