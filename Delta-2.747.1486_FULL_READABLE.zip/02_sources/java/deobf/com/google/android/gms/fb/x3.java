package deobf.com.google.android.gms.fb;

import java.util.Arrays;

// dex: classes.dex
public final class x3 extends e4 {

    public final m3 f15892a;

    public x3(m3 m3Var) {
        this.f15892a = m3Var;
    }

    @Override // java.lang.Comparable
    public final /* bridge */ /* synthetic */ int compareTo(Object obj) {
        e4 e4Var = (e4) obj;
        if (deobf.androidx.fragment.app.e4.c((byte) 64) != e4Var.zza()) {
            return deobf.androidx.fragment.app.e4.c((byte) 64) - e4Var.zza();
        }
        x3 x3Var = (x3) e4Var;
        m3 m3Var = this.f15892a;
        int d10 = m3Var.d();
        m3 m3Var2 = x3Var.f15892a;
        if (d10 != m3Var2.d()) {
            return m3Var.d() - m3Var2.d();
        }
        return deobf.unlinked.b3.a().compare(m3Var.n(), x3Var.f15892a.n());
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj != null && x3.class == obj.getClass()) {
            return this.f15892a.equals(((x3) obj).f15892a);
        }
        return false;
    }

    public final int hashCode() {
        return Arrays.hashCode(new Object[]{Integer.valueOf(deobf.androidx.fragment.app.e4.c((byte) 64)), this.f15892a});
    }

    public final m3 q() {
        return this.f15892a;
    }

    public final String toString() {
        u2 c10 = deobf.com.google.android.gms.u2.d().c();
        byte[] n10 = this.f15892a.n();
        return "h'" + c10.e(n10, 0, n10.length) + "'";
    }

    @Override // deobf.com.google.android.gms.fb.e4
    public final int zza() {
        return deobf.androidx.fragment.app.e4.c((byte) 64);
    }
}
