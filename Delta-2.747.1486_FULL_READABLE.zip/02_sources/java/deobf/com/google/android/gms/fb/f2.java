package deobf.com.google.android.gms.fb;

// dex: classes.dex
public abstract class f2 implements j2 {
}
