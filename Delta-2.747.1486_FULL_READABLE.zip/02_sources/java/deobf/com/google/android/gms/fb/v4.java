package deobf.com.google.android.gms.fb;

import android.app.PendingIntent;
import android.os.IInterface;
import com.google.android.gms.common.api.Status;

// dex: classes.dex
public interface v4 extends IInterface {
    void E0(Status status, PendingIntent pendingIntent);
}
