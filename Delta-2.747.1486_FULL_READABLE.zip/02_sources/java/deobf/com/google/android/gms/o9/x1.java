package deobf.com.google.android.gms.o9;

import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;

// dex: classes.dex
public abstract class x1 extends deobf.com.google.android.gms.eb.n implements y1 {
    public x1() {
        super("com.google.android.gms.common.internal.ICertData");
    }

    public static y1 s2(IBinder iBinder) {
        IInterface queryLocalInterface = iBinder.queryLocalInterface("com.google.android.gms.common.internal.ICertData");
        return queryLocalInterface instanceof y1 ? (y1) queryLocalInterface : new w1(iBinder);
    }

    @Override // deobf.com.google.android.gms.eb.n
    public final boolean r2(int i10, Parcel parcel, Parcel parcel2, int i11) {
        if (i10 == 1) {
            deobf.com.google.android.gms.z9.a zzd = zzd();
            parcel2.writeNoException();
            deobf.com.google.android.gms.eb.o.d(parcel2, zzd);
        } else {
            if (i10 != 2) {
                return false;
            }
            int zze = zze();
            parcel2.writeNoException();
            parcel2.writeInt(zze);
        }
        return true;
    }
}
