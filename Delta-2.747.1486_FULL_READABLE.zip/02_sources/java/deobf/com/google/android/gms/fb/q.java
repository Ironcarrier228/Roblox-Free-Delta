package deobf.com.google.android.gms.fb;

// dex: classes.dex
public final class q implements q0 {

    public static volatile k f15822f = new k(new Object() { // from class: fb.p
    });
    public final String b;

    public final Object f15824c;

    public final l f15826e;

    public volatile int f15825d = -1;

    public final String f15823a = "com.google.android.gms.fido";

    public q(String str, String str2, Object obj, l lVar, boolean z10) {
        this.b = str2;
        this.f15824c = obj;
        this.f15826e = lVar;
    }

    @Override // deobf.com.google.android.gms.fb.q0
    public final Object zza() {
        deobf.unlinked.f.a();
        synchronized (this) {
            deobf.unlinked.f.b();
            n nVar = o.f15779a;
            throw null;
        }
    }
}
