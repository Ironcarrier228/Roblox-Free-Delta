package deobf.com.google.android.gms.fb;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.util.Arrays;

// dex: classes.dex
public abstract class e4 implements Comparable {
    public static int c(byte b) {
        return (b >> 5) & 7;
    }

    public static z3 h(long j10) {
        return new z3(j10);
    }

    public static c4 m(String str) {
        return new c4(str);
    }

    public static e4 o(byte... bArr) {
        bArr.getClass();
        ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(Arrays.copyOf(bArr, bArr.length));
        return deobf.com.withpersona.sdk2.inquiry.f4.a(byteArrayInputStream, new h4(byteArrayInputStream));
    }

    public static e4 p(InputStream inputStream) {
        return deobf.com.withpersona.sdk2.inquiry.f4.a(inputStream, new h4(inputStream));
    }

    public int a() {
        return 0;
    }

    public final e4 b(Class cls) {
        if (cls.isInstance(this)) {
            return (e4) cls.cast(this);
        }
        throw new d4("Expected a " + cls.getName() + " value, but got " + getClass().getName());
    }

    public final x3 d() {
        return (x3) b(x3.class);
    }

    public final z3 e() {
        return (z3) b(z3.class);
    }

    public final b4 k() {
        return (b4) b(b4.class);
    }

    public abstract int zza();
}
