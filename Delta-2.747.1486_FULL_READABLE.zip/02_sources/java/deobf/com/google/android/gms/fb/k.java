package deobf.com.google.android.gms.fb;

// dex: classes.dex
public final class k {
    public k(p pVar) {
        k kVar = q.f15822f;
    }
}
