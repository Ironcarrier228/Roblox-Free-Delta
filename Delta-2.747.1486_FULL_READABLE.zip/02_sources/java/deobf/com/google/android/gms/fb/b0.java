package deobf.com.google.android.gms.fb;

// dex: classes.dex
public final class b0 {
    public static boolean a(char c10) {
        return c10 >= 'a' && c10 <= 'z';
    }
}
