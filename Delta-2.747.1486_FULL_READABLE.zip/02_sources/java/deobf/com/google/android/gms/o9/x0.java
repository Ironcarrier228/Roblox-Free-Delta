package deobf.com.google.android.gms.o9;

import android.os.IBinder;
import android.os.Parcel;

// dex: classes.dex
public final class x0 extends deobf.com.google.android.gms.eb.a implements z0 {
    public x0(IBinder iBinder) {
        super(iBinder, "com.google.android.gms.common.internal.IGoogleCertificatesApi");
    }

    @Override // deobf.com.google.android.gms.o9.z0
    public final deobf.com.google.mlkit.vision.k9.h0 N1(deobf.com.google.mlkit.vision.k9.f0 f0Var) {
        Parcel s22 = s2();
        deobf.com.google.android.gms.eb.o.c(s22, f0Var);
        Parcel r22 = r2(8, s22);
        deobf.com.google.mlkit.vision.k9.h0 h0Var = (deobf.com.google.mlkit.vision.k9.h0) deobf.com.google.android.gms.eb.o.b(r22, deobf.com.google.mlkit.vision.k9.h0.CREATOR);
        r22.recycle();
        return h0Var;
    }

    @Override // deobf.com.google.android.gms.o9.z0
    public final boolean Q1(deobf.com.google.mlkit.vision.k9.j0 j0Var, deobf.com.google.android.gms.z9.a aVar) {
        Parcel s22 = s2();
        deobf.com.google.android.gms.eb.o.c(s22, j0Var);
        deobf.com.google.android.gms.eb.o.d(s22, aVar);
        Parcel r22 = r2(5, s22);
        boolean a10 = deobf.com.google.android.gms.eb.o.a(r22);
        r22.recycle();
        return a10;
    }

    @Override // deobf.com.google.android.gms.o9.z0
    public final boolean c() {
        Parcel r22 = r2(7, s2());
        boolean a10 = deobf.com.google.android.gms.eb.o.a(r22);
        r22.recycle();
        return a10;
    }

    @Override // deobf.com.google.android.gms.o9.z0
    public final deobf.com.google.mlkit.vision.k9.h0 l2(deobf.com.google.mlkit.vision.k9.f0 f0Var) {
        Parcel s22 = s2();
        deobf.com.google.android.gms.eb.o.c(s22, f0Var);
        Parcel r22 = r2(6, s22);
        deobf.com.google.mlkit.vision.k9.h0 h0Var = (deobf.com.google.mlkit.vision.k9.h0) deobf.com.google.android.gms.eb.o.b(r22, deobf.com.google.mlkit.vision.k9.h0.CREATOR);
        r22.recycle();
        return h0Var;
    }
}
