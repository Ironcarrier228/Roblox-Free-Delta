package deobf.com.google.android.gms.o9;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.IBinder;
import android.os.StrictMode;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.Executor;

// dex: classes.dex
public final class q1 implements ServiceConnection, t1 {

    public final Map f27016a;
    public int b;

    public boolean f27017c;

    public IBinder f27018d;

    public final p1 f27019e;

    public ComponentName f27020f;

    public final /* synthetic */ s1 f27021g;

    public q1(s1 s1Var, p1 p1Var) {
        Objects.requireNonNull(s1Var);
        this.f27021g = s1Var;
        this.f27019e = p1Var;
        this.f27016a = new HashMap();
        this.b = 2;
    }

    public final void a(String str) {
        p1 p1Var = this.f27019e;
        s1 s1Var = this.f27021g;
        s1Var.h().removeMessages(1, p1Var);
        s1Var.i().c(s1Var.g(), this);
        this.f27017c = false;
        this.b = 2;
    }

    public final void b(ServiceConnection serviceConnection, ServiceConnection serviceConnection2, String str) {
        this.f27016a.put(serviceConnection, serviceConnection2);
    }

    public final void c(ServiceConnection serviceConnection, String str) {
        this.f27016a.remove(serviceConnection);
    }

    public final boolean d() {
        return this.f27017c;
    }

    public final int e() {
        return this.b;
    }

    public final boolean f(ServiceConnection serviceConnection) {
        return this.f27016a.containsKey(serviceConnection);
    }

    public final boolean g() {
        return this.f27016a.isEmpty();
    }

    public final IBinder h() {
        return this.f27018d;
    }

    public final ComponentName i() {
        return this.f27020f;
    }

    public final /* synthetic */ deobf.com.google.mlkit.vision.k9.b j(String str, Executor executor) {
        s1 s1Var;
        deobf.unlinked.u9.a i10;
        Context g10;
        p1 p1Var;
        try {
            Intent a10 = deobf.com.withpersona.sdk2.inquiry.d1.a(this.f27021g.g(), this.f27019e);
            this.b = 3;
            StrictMode.VmPolicy a11 = deobf.com.google.android.gms.v9.t.a();
            try {
                s1Var = this.f27021g;
                i10 = s1Var.i();
                g10 = s1Var.g();
                p1Var = this.f27019e;
            } catch (Throwable th2) {
                th = th2;
            }
            try {
                boolean d10 = i10.d(g10, str, a10, this, 4225, executor);
                this.f27017c = d10;
                if (d10) {
                    s1Var.h().sendMessageDelayed(s1Var.h().obtainMessage(1, p1Var), s1Var.j());
                    deobf.com.google.mlkit.vision.k9.b bVar = deobf.com.google.mlkit.vision.k9.b.f21213k;
                    StrictMode.setVmPolicy(a11);
                    return bVar;
                }
                this.b = 2;
                try {
                    s1Var.i().c(s1Var.g(), this);
                } catch (IllegalArgumentException unused) {
                }
                deobf.com.google.mlkit.vision.k9.b bVar2 = new deobf.com.google.mlkit.vision.k9.b(16);
                StrictMode.setVmPolicy(a11);
                return bVar2;
            } catch (Throwable th3) {
                th = th3;
                Throwable th4 = th;
                StrictMode.setVmPolicy(a11);
                throw th4;
            }
        } catch (b1 e10) {
            return e10.f26930a;
        }
    }

    @Override // android.content.ServiceConnection
    public final void onBindingDied(ComponentName componentName) {
        onServiceDisconnected(componentName);
    }

    @Override // android.content.ServiceConnection
    public final void onServiceConnected(ComponentName componentName, IBinder iBinder) {
        s1 s1Var = this.f27021g;
        synchronized (s1Var.f()) {
            try {
                s1Var.h().removeMessages(1, this.f27019e);
                this.f27018d = iBinder;
                this.f27020f = componentName;
                Iterator it = this.f27016a.values().iterator();
                while (it.hasNext()) {
                    ((ServiceConnection) it.next()).onServiceConnected(componentName, iBinder);
                }
                this.b = 1;
            } catch (Throwable th2) {
                throw th2;
            }
        }
    }

    @Override // android.content.ServiceConnection
    public final void onServiceDisconnected(ComponentName componentName) {
        s1 s1Var = this.f27021g;
        synchronized (s1Var.f()) {
            try {
                s1Var.h().removeMessages(1, this.f27019e);
                this.f27018d = null;
                this.f27020f = componentName;
                Iterator it = this.f27016a.values().iterator();
                while (it.hasNext()) {
                    ((ServiceConnection) it.next()).onServiceDisconnected(componentName);
                }
                this.b = 2;
            } catch (Throwable th2) {
                throw th2;
            }
        }
    }
}
