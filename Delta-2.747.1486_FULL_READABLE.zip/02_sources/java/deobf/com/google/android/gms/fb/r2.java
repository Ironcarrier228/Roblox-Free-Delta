package deobf.com.google.android.gms.fb;

import com.google.mlkit.vision.barcode.common.Barcode;

// dex: classes.dex
public final class r2 extends t2 {

    public final char[] f15837i;

    public r2(q2 q2Var) {
        super(q2Var, null);
        char[] cArr;
        this.f15837i = new char[Barcode.FORMAT_UPC_A];
        cArr = q2Var.b;
        deobf.androidx.camera.camera2.internal.compat.quirk.n0.c(cArr.length == 16);
        for (int i10 = 0; i10 < 256; i10++) {
            this.f15837i[i10] = q2Var.a(i10 >>> 4);
            this.f15837i[i10 | Barcode.FORMAT_QR_CODE] = q2Var.a(i10 & 15);
        }
    }

    @Override // deobf.com.google.android.gms.fb.t2, deobf.com.google.android.gms.fb.u2
    public final void a(Appendable appendable, byte[] bArr, int i10, int i11) {
        deobf.androidx.camera.camera2.internal.compat.quirk.n0.e(0, i11, bArr.length);
        for (int i12 = 0; i12 < i11; i12++) {
            int i13 = bArr[i12] & 255;
            appendable.append(this.f15837i[i13]);
            appendable.append(this.f15837i[i13 | Barcode.FORMAT_QR_CODE]);
        }
    }

    @Override // deobf.com.google.android.gms.fb.t2
    public final u2 f(q2 q2Var, Character ch2) {
        return new r2(q2Var);
    }

    public r2(String str, String str2) {
        this(new q2("base16()", "0123456789ABCDEF".toCharArray()));
    }
}
