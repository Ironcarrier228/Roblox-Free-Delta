package deobf.com.google.android.gms.fb;

// dex: classes.dex
public interface j2 {
    k2 zza();
}
