package deobf.com.google.android.gms.fb;

import java.util.Collection;
import java.util.Set;

// dex: classes.dex
public interface p1 extends Collection {
    Set zza();
}
