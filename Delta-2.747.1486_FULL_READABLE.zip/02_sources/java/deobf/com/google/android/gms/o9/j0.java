package deobf.com.google.android.gms.o9;

import android.os.Bundle;
import deobf.com.google.android.gms.o9.d;

// dex: classes.dex
public final class j0 implements deobf.com.roblox.client.pushnotification.d.a {

    public final /* synthetic */ deobf.com.google.android.gms.m9.e f26988a;

    public j0(deobf.com.google.android.gms.m9.e eVar) {
        this.f26988a = eVar;
    }

    @Override // deobf.com.google.android.gms.o9.d.a
    public final void onConnected(Bundle bundle) {
        this.f26988a.onConnected(bundle);
    }

    @Override // deobf.com.google.android.gms.o9.d.a
    public final void onConnectionSuspended(int i10) {
        this.f26988a.onConnectionSuspended(i10);
    }
}
