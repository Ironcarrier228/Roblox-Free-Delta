package deobf.com.google.android.gms.fb;

// dex: classes.dex
public final class l2 {

    public static final j2 f15763a = new p2("SHA-256", "Hashing.sha256()");
}
