package deobf.com.google.android.gms.fb;

import java.io.IOException;

// dex: classes.dex
public final class u3 extends IOException {
    public u3(String str) {
        super(str);
    }
}
