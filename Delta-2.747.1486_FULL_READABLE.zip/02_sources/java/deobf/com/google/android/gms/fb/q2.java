package deobf.com.google.android.gms.fb;

import java.math.RoundingMode;
import java.util.Arrays;

// dex: classes.dex
public final class q2 {

    public final String f15828a;
    public final char[] b;

    public final int f15829c;

    public final int f15830d;

    public final int f15831e;

    public final int f15832f;

    public final byte[] f15833g;

    public final boolean f15834h;

    /* JADX WARN: Illegal instructions before constructor call */
    public q2(java.lang.String r10, char[] r11) {
        /*
            r9 = this;
            r0 = 128(0x80, float:1.8E-43)
            byte[] r1 = new byte[r0]
            r2 = -1
            java.util.Arrays.fill(r1, r2)
            r3 = 0
            r4 = r3
        La:
            int r5 = r11.length
            if (r4 >= r5) goto L2b
            char r5 = r11[r4]
            r6 = 1
            if (r5 >= r0) goto L14
            r7 = r6
            goto L15
        L14:
            r7 = r3
        L15:
            java.lang.String r8 = "Non-ASCII character: %s"
            deobf.com.google.android.gms.fb.n0.d(r7, r8, r5)
            r7 = r1[r5]
            if (r7 != r2) goto L1f
            goto L20
        L1f:
            r6 = r3
        L20:
            java.lang.String r7 = "Duplicate character: %s"
            deobf.com.google.android.gms.fb.n0.d(r6, r7, r5)
            byte r6 = (byte) r4
            r1[r5] = r6
            int r4 = r4 + 1
            goto La
        L2b:
            r9.<init>(r10, r11, r1, r3)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: deobf.com.google.android.gms.fb.q2.<init>(java.lang.String, char[]):void");
    }

    public final char a(int i10) {
        return this.b[i10];
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r2v10 */
    public final q2 b() {
        int i10;
        boolean z10;
        int i11 = 0;
        int i12 = 0;
        while (true) {
            char[] cArr = this.b;
            if (i12 >= cArr.length) {
                return this;
            }
            if (deobf.unlinked.b0.a(cArr[i12])) {
                int i13 = 0;
                while (true) {
                    if (i13 >= cArr.length) {
                        z10 = false;
                        break;
                    }
                    char c10 = cArr[i13];
                    if (c10 >= 'A' && c10 <= 'Z') {
                        z10 = true;
                        break;
                    }
                    i13++;
                }
                deobf.androidx.camera.camera2.internal.compat.quirk.n0.f(!z10, "Cannot call upperCase() on a mixed-case alphabet");
                char[] cArr2 = new char[this.b.length];
                while (true) {
                    char[] cArr3 = this.b;
                    if (i11 >= cArr3.length) {
                        break;
                    }
                    char c11 = cArr3[i11];
                    if (deobf.unlinked.b0.a(c11)) {
                        c11 ^= 32;
                    }
                    cArr2[i11] = (char) c11;
                    i11++;
                }
                q2 q2Var = new q2(this.f15828a.concat(".upperCase()"), cArr2);
                if (!this.f15834h || q2Var.f15834h) {
                    return q2Var;
                }
                byte[] bArr = q2Var.f15833g;
                byte[] copyOf = Arrays.copyOf(bArr, bArr.length);
                for (i10 = 65; i10 <= 90; i10++) {
                    int i14 = i10 | 32;
                    byte[] bArr2 = q2Var.f15833g;
                    byte b = bArr2[i10];
                    byte b10 = bArr2[i14];
                    if (b == -1) {
                        copyOf[i10] = b10;
                    } else {
                        char c12 = (char) i10;
                        char c13 = (char) i14;
                        if (b10 != -1) {
                            throw new IllegalStateException(deobf.androidx.camera.view.p0.a("Can't ignoreCase() since '%s' and '%s' encode different values", Character.valueOf(c12), Character.valueOf(c13)));
                        }
                        copyOf[i14] = b;
                    }
                }
                return new q2(q2Var.f15828a.concat(".ignoreCase()"), q2Var.b, copyOf, true);
            }
            i12++;
        }
    }

    public final boolean c(char c10) {
        byte[] bArr = this.f15833g;
        return bArr.length > 61 && bArr[61] != -1;
    }

    public final boolean equals(Object obj) {
        if (obj instanceof q2) {
            q2 q2Var = (q2) obj;
            if (this.f15834h == q2Var.f15834h && Arrays.equals(this.b, q2Var.b)) {
                return true;
            }
        }
        return false;
    }

    public final int hashCode() {
        return Arrays.hashCode(this.b) + (true != this.f15834h ? 1237 : 1231);
    }

    public final String toString() {
        return this.f15828a;
    }

    public q2(String str, char[] cArr, byte[] bArr, boolean z10) {
        this.f15828a = str;
        cArr.getClass();
        this.b = cArr;
        try {
            int length = cArr.length;
            int b = deobf.androidx.appcompat.widget.w2.b(length, RoundingMode.UNNECESSARY);
            this.f15830d = b;
            int numberOfTrailingZeros = Integer.numberOfTrailingZeros(b);
            int i10 = 1 << (3 - numberOfTrailingZeros);
            this.f15831e = i10;
            this.f15832f = b >> numberOfTrailingZeros;
            this.f15829c = length - 1;
            this.f15833g = bArr;
            boolean[] zArr = new boolean[i10];
            for (int i11 = 0; i11 < this.f15832f; i11++) {
                zArr[deobf.androidx.appcompat.widget.w2.a(i11 * 8, this.f15830d, RoundingMode.CEILING)] = true;
            }
            this.f15834h = z10;
        } catch (ArithmeticException e10) {
            throw new IllegalArgumentException("Illegal alphabet length " + cArr.length, e10);
        }
    }
}
