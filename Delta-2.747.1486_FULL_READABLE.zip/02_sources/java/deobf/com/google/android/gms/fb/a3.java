package deobf.com.google.android.gms.fb;

import java.util.Comparator;
import java.util.Objects;

// dex: classes.dex
public final class a3 {

    public static final String f15718a;
    public static final Comparator b;

    static {
        Comparator comparator;
        String concat = a3.class.getName().concat("$UnsafeComparator");
        f15718a = concat;
        try {
            Object[] enumConstants = Class.forName(concat).getEnumConstants();
            Objects.requireNonNull(enumConstants);
            comparator = (Comparator) enumConstants[0];
        } catch (Throwable unused) {
            comparator = z2.INSTANCE;
        }
        b = comparator;
    }
}
