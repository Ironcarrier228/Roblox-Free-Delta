package deobf.com.google.android.gms.fb;

// dex: classes.dex
public final class c3 {

    public static final /* synthetic */ int f15723a = 0;
}
