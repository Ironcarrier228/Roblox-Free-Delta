package deobf.com.google.android.gms.fb;

// dex: classes.dex
public final class o0 extends m0 {

    public final Object f15780a;

    public o0(Object obj) {
        this.f15780a = obj;
    }

    @Override // deobf.com.google.android.gms.fb.m0
    public final Object a() {
        return this.f15780a;
    }

    @Override // deobf.com.google.android.gms.fb.m0
    public final boolean b() {
        return true;
    }

    public final boolean equals(Object obj) {
        if (obj instanceof o0) {
            return this.f15780a.equals(((o0) obj).f15780a);
        }
        return false;
    }

    public final int hashCode() {
        return this.f15780a.hashCode() + 1502476572;
    }

    public final String toString() {
        return "Optional.of(" + this.f15780a.toString() + ")";
    }
}
