package deobf.com.google.android.gms.o9;

import android.content.ComponentName;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import java.util.Objects;

// dex: classes.dex
public final class r1 implements Handler.Callback {

    public final /* synthetic */ s1 f27027a;

    public /* synthetic */ r1(s1 s1Var, byte[] bArr) {
        Objects.requireNonNull(s1Var);
        this.f27027a = s1Var;
    }

    @Override // android.os.Handler.Callback
    public final boolean handleMessage(Message message) {
        int i10 = message.what;
        if (i10 == 0) {
            s1 s1Var = this.f27027a;
            synchronized (s1Var.f()) {
                try {
                    p1 p1Var = (p1) message.obj;
                    q1 q1Var = (q1) s1Var.f().get(p1Var);
                    if (q1Var != null && q1Var.g()) {
                        if (q1Var.d()) {
                            q1Var.a("GmsClientSupervisor");
                        }
                        s1Var.f().remove(p1Var);
                    }
                } finally {
                }
            }
            return true;
        }
        if (i10 != 1) {
            return false;
        }
        s1 s1Var2 = this.f27027a;
        synchronized (s1Var2.f()) {
            try {
                p1 p1Var2 = (p1) message.obj;
                q1 q1Var2 = (q1) s1Var2.f().get(p1Var2);
                if (q1Var2 != null && q1Var2.e() == 3) {
                    String valueOf = String.valueOf(p1Var2);
                    StringBuilder sb2 = new StringBuilder(valueOf.length() + 47);
                    sb2.append("Timeout waiting for ServiceConnection callback ");
                    sb2.append(valueOf);
                    Log.e("GmsClientSupervisor", sb2.toString(), new Exception());
                    ComponentName i11 = q1Var2.i();
                    if (i11 == null) {
                        i11 = p1Var2.c();
                    }
                    if (i11 == null) {
                        String b = p1Var2.b();
                        s.l(b);
                        i11 = new ComponentName(b, "unknown");
                    }
                    q1Var2.onServiceDisconnected(i11);
                }
            } finally {
            }
        }
        return true;
    }
}
