package deobf.com.google.android.gms.fb;

import java.io.Serializable;
import java.util.Arrays;

// dex: classes.dex
public final class t0 implements Serializable, q0 {

    public final Object f15864a;

    public t0(Object obj) {
        this.f15864a = obj;
    }

    public final boolean equals(Object obj) {
        if (obj instanceof t0) {
            return deobf.androidx.camera.camera2.internal.compat.quirk.l0.a(this.f15864a, ((t0) obj).f15864a);
        }
        return false;
    }

    public final int hashCode() {
        return Arrays.hashCode(new Object[]{this.f15864a});
    }

    public final String toString() {
        return "Suppliers.ofInstance(" + this.f15864a.toString() + ")";
    }

    @Override // deobf.com.google.android.gms.fb.q0
    public final Object zza() {
        return this.f15864a;
    }
}
