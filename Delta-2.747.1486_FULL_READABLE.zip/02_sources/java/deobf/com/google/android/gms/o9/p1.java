package deobf.com.google.android.gms.o9;

import android.content.ComponentName;

// dex: classes.dex
public final class p1 {

    public final String f27011a;
    public final String b;

    public final ComponentName f27012c;

    public final int f27013d;

    public final boolean f27014e;

    public p1(String str, String str2, int i10, boolean z10) {
        s.f(str);
        this.f27011a = str;
        s.f(str2);
        this.b = str2;
        this.f27012c = null;
        this.f27013d = 4225;
        this.f27014e = z10;
    }

    public final String a() {
        return this.f27011a;
    }

    public final String b() {
        return this.b;
    }

    public final ComponentName c() {
        return this.f27012c;
    }

    public final boolean d() {
        return this.f27014e;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof p1)) {
            return false;
        }
        p1 p1Var = (p1) obj;
        return deobf.androidx.appcompat.widget.q.b(this.f27011a, p1Var.f27011a) && deobf.androidx.appcompat.widget.q.b(this.b, p1Var.b) && deobf.androidx.appcompat.widget.q.b(this.f27012c, p1Var.f27012c) && this.f27014e == p1Var.f27014e;
    }

    public final int hashCode() {
        return deobf.androidx.appcompat.widget.q.c(this.f27011a, this.b, this.f27012c, 4225, Boolean.valueOf(this.f27014e));
    }

    public final String toString() {
        String str = this.f27011a;
        if (str != null) {
            return str;
        }
        ComponentName componentName = this.f27012c;
        s.l(componentName);
        return componentName.flattenToString();
    }
}
