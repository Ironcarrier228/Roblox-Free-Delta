package deobf.com.google.android.gms.fb;

import java.util.Iterator;

// dex: classes.dex
public interface h3 extends Iterator {
    byte zza();
}
