package deobf.com.google.android.gms.fb;

// dex: classes.dex
public final class o4 implements n4 {

    public static final q f15786a;
    public static final q b;

    public static final q f15787c;

    public static final q f15788d;

    public static final q f15789e;

    public static final q f15790f;

    public static final q f15791g;

    static {
        y d10 = new y("com.google.android.gms.fido").e(h1.m("FIDO")).d();
        f15786a = d10.c("Hybrid__client_enabled", false);
        b = d10.c("Hybrid__disavow_location_permissions", true);
        f15787c = d10.a("Hybrid__number_of_seconds_to_wait_for_bt_scanning_radio_to_be_ready", 3L);
        f15788d = d10.a("Hybrid__number_of_seconds_to_wait_for_bt_scanning_turning_on", 3L);
        f15789e = d10.c("Hybrid__prf_eval_during_create", true);
        f15790f = d10.c("Hybrid__use_hybrid_for_server_link", false);
        f15791g = d10.c("Hybrid__websocket_close_socket", true);
    }

    @Override // deobf.com.google.android.gms.fb.n4
    public final boolean zza() {
        return ((Boolean) f15786a.zza()).booleanValue();
    }
}
