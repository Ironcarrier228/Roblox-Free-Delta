package deobf.com.google.android.gms.fb;

// dex: classes.dex
public interface k2 {
    k2 a(byte[] bArr);

    i2 zzc();
}
