package deobf.com.google.android.gms.fb;

import java.io.Serializable;
import java.util.Comparator;

// dex: classes.dex
public final class x0 extends s1 implements Serializable {

    public final Comparator f15890a;

    public x0(Comparator comparator) {
        comparator.getClass();
        this.f15890a = comparator;
    }

    @Override // deobf.com.google.android.gms.fb.s1, java.util.Comparator
    public final int compare(Object obj, Object obj2) {
        return this.f15890a.compare(obj, obj2);
    }

    @Override // java.util.Comparator
    public final boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (obj instanceof x0) {
            return this.f15890a.equals(((x0) obj).f15890a);
        }
        return false;
    }

    public final int hashCode() {
        return this.f15890a.hashCode();
    }

    public final String toString() {
        return this.f15890a.toString();
    }
}
