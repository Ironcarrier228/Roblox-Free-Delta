package deobf.com.google.android.gms.fb;

import android.content.Context;
import android.os.Looper;
import deobf.com.google.android.gms.l9.a;
import deobf.com.google.android.gms.l9.h;

// dex: classes.dex
public final class s4 extends a.AbstractC0421a {
    @Override // deobf.com.google.android.gms.l9.a.AbstractC0421a
    public final /* synthetic */ a.f a(Context context, Looper looper, deobf.com.google.android.gms.o9.f fVar, Object obj, deobf.com.roblox.protocols.mediapicker.h.a aVar, deobf.com.roblox.protocols.mediapicker.h.b bVar) {
        return new t4(context, looper, fVar, aVar, bVar);
    }
}
