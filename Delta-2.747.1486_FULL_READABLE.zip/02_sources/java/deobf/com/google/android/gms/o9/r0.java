package deobf.com.google.android.gms.o9;

import android.accounts.Account;
import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;

// dex: classes.dex
public final class r0 extends deobf.com.google.android.gms.p9.a {
    public static final Parcelable.Creator<r0> CREATOR = new s0();

    public final int f27023f;

    public final Account f27024g;

    public final int f27025h;

    public final GoogleSignInAccount f27026i;

    public r0(int i10, Account account, int i11, GoogleSignInAccount googleSignInAccount) {
        this.f27023f = i10;
        this.f27024g = account;
        this.f27025h = i11;
        this.f27026i = googleSignInAccount;
    }

    @Override // android.os.Parcelable
    public final void writeToParcel(Parcel parcel, int i10) {
        int i11 = this.f27023f;
        int a10 = deobf.com.google.android.gms.p9.c.a(parcel);
        deobf.com.google.android.gms.p9.c.n(parcel, 1, i11);
        deobf.com.google.android.gms.p9.c.t(parcel, 2, this.f27024g, i10, false);
        deobf.com.google.android.gms.p9.c.n(parcel, 3, this.f27025h);
        deobf.com.google.android.gms.p9.c.t(parcel, 4, this.f27026i, i10, false);
        deobf.com.google.android.gms.p9.c.b(parcel, a10);
    }

    public r0(Account account, int i10, GoogleSignInAccount googleSignInAccount) {
        this(2, account, i10, googleSignInAccount);
    }
}
