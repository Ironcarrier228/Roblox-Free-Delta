package deobf.com.google.android.gms.fb;

import java.util.NoSuchElementException;

// dex: classes.dex
public final class d3 extends f3 {

    public int f15728a = 0;
    public final int b;

    public final /* synthetic */ m3 f15729c;

    public d3(m3 m3Var) {
        this.f15729c = m3Var;
        this.b = m3Var.d();
    }

    @Override // java.util.Iterator
    public final boolean hasNext() {
        return this.f15728a < this.b;
    }

    @Override // deobf.com.google.android.gms.fb.h3
    public final byte zza() {
        int i10 = this.f15728a;
        if (i10 >= this.b) {
            throw new NoSuchElementException();
        }
        this.f15728a = i10 + 1;
        return this.f15729c.c(i10);
    }
}
