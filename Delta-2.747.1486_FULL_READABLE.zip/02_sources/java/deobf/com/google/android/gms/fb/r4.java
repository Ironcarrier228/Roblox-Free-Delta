package deobf.com.google.android.gms.fb;

// dex: classes.dex
public final class r4 implements q4 {

    public static final q f15839a;
    public static final q b;

    public static final q f15840c;

    public static final q f15841d;

    public static final q f15842e;

    public static final q f15843f;

    public static final q f15844g;

    public static final q f15845h;

    public static final q f15846i;

    public static final q f15847j;

    public static final q f15848k;

    public static final q f15849l;

    public static final q f15850m;

    public static final q f15851n;

    public static final q f15852o;

    public static final q f15853p;

    public static final q f15854q;

    public static final q f15855r;

    public static final q f15856s;

    static {
        y d10 = new y("com.google.android.gms.fido").e(h1.m("FIDO")).d();
        f15839a = d10.c("Passkeys__check_all_keys", false);
        b = d10.c("Passkeys__check_sync_status", true);
        f15840c = d10.c("Passkeys__client_data_hash_override_for_security_keys", false);
        f15841d = d10.c("Passkeys__direct_assetlinks", false);
        f15842e = d10.a("Passkeys__direct_assetlinks_cache_seconds", 604800L);
        f15843f = d10.b("Passkeys__direct_assetlinks_rpids", "*");
        f15844g = d10.c("Passkeys__dispatch_prf_via_credman", true);
        f15845h = d10.b("Passkeys__help_center_url", "https://support.google.com/accounts/answer/6208650");
        f15846i = d10.c("Passkeys__hide_consent_page_in_registration_enabled", false);
        f15847j = d10.c("Passkeys__ignore_stop_during_hybrid_request", false);
        f15848k = d10.c("Passkeys__json_for_parcelables", false);
        f15849l = d10.c("Passkeys__passkey_entries_use_gpm_icon", false);
        f15850m = d10.c("Passkeys__reencrypt_passkey", false);
        f15851n = d10.c("Passkeys__return_cryptauth_status", false);
        f15852o = d10.c("Passkeys__set_key_version", true);
        f15853p = d10.a("Passkeys__should_show_welcome_fragment", -1L);
        f15854q = d10.c("Passkeys__skip_consent_after_retrieval", false);
        f15855r = d10.c("Passkeys__skip_consent_screen", false);
        f15856s = d10.c("Passkeys__use_result_receiver", false);
    }

    @Override // deobf.com.google.android.gms.fb.q4
    public final boolean zza() {
        return ((Boolean) f15848k.zza()).booleanValue();
    }
}
