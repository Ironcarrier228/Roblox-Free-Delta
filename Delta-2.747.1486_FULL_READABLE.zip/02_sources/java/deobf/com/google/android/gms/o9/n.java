package deobf.com.google.android.gms.o9;

import android.os.IInterface;
import androidx.annotation.NonNull;

// dex: classes.dex
public interface n extends IInterface {
    void h1(@NonNull m mVar, h hVar);
}
