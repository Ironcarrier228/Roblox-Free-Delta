package deobf.com.google.android.gms.fb;

import com.github.luben.zstd.BuildConfig;
import java.util.Arrays;

// dex: classes.dex
public final class j0 {

    public final String f15750a;
    public final h0 b;

    public h0 f15751c;

    public /* synthetic */ j0(String str, i0 i0Var) {
        h0 h0Var = new h0();
        this.b = h0Var;
        this.f15751c = h0Var;
        str.getClass();
        this.f15750a = str;
    }

    public final j0 a(String str, int i10) {
        String valueOf = String.valueOf(i10);
        g0 g0Var = new g0(null);
        this.f15751c.f15740c = g0Var;
        this.f15751c = g0Var;
        g0Var.b = valueOf;
        g0Var.f15739a = "errorCode";
        return this;
    }

    public final j0 b(String str, Object obj) {
        h0 h0Var = new h0();
        this.f15751c.f15740c = h0Var;
        this.f15751c = h0Var;
        h0Var.b = obj;
        h0Var.f15739a = str;
        return this;
    }

    public final String toString() {
        StringBuilder sb2 = new StringBuilder(32);
        sb2.append(this.f15750a);
        sb2.append('{');
        h0 h0Var = this.b.f15740c;
        String str = BuildConfig.FLAVOR;
        while (h0Var != null) {
            Object obj = h0Var.b;
            sb2.append(str);
            String str2 = h0Var.f15739a;
            if (str2 != null) {
                sb2.append(str2);
                sb2.append('=');
            }
            if (obj == null || !obj.getClass().isArray()) {
                sb2.append(obj);
            } else {
                sb2.append((CharSequence) Arrays.deepToString(new Object[]{obj}), 1, r2.length() - 1);
            }
            h0Var = h0Var.f15740c;
            str = ", ";
        }
        sb2.append('}');
        return sb2.toString();
    }
}
