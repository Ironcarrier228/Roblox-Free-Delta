package deobf.com.google.android.gms.o9;

import android.os.IBinder;
import android.os.IInterface;

// dex: classes.dex
public abstract class y0 extends deobf.com.google.android.gms.eb.n implements z0 {
    public static z0 s2(IBinder iBinder) {
        if (iBinder == null) {
            return null;
        }
        IInterface queryLocalInterface = iBinder.queryLocalInterface("com.google.android.gms.common.internal.IGoogleCertificatesApi");
        return queryLocalInterface instanceof z0 ? (z0) queryLocalInterface : new x0(iBinder);
    }
}
