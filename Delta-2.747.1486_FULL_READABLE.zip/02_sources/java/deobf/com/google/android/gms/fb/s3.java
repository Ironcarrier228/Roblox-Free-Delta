package deobf.com.google.android.gms.fb;

import java.nio.ByteBuffer;
import java.nio.charset.Charset;

// dex: classes.dex
public final class s3 {

    public static final Charset f15858a = Charset.forName("US-ASCII");
    public static final Charset b = Charset.forName("UTF-8");

    public static final Charset f15859c = Charset.forName("ISO-8859-1");

    public static final byte[] f15860d;

    public static final ByteBuffer f15861e;

    public static final r3 f15862f;

    static {
        byte[] bArr = new byte[0];
        f15860d = bArr;
        f15861e = ByteBuffer.wrap(bArr);
        int i10 = r3.f15838a;
        o3 o3Var = new o3(bArr, 0, 0, false, null);
        o3Var.a(0);
        f15862f = o3Var;
    }
}
