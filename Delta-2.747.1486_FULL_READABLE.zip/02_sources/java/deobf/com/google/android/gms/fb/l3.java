package deobf.com.google.android.gms.fb;

// dex: classes.dex
public final class l3 {
    public /* synthetic */ l3(k3 k3Var) {
    }
}
