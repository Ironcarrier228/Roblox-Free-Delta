package deobf.com.google.android.gms.fb;

// dex: classes.dex
public final class z extends m0 {

    public static final z f15895a = new z();

    @Override // deobf.com.google.android.gms.fb.m0
    public final Object a() {
        throw new IllegalStateException("Optional.get() cannot be called on an absent value");
    }

    @Override // deobf.com.google.android.gms.fb.m0
    public final boolean b() {
        return false;
    }

    public final boolean equals(Object obj) {
        return obj == this;
    }

    public final int hashCode() {
        return 2040732332;
    }

    public final String toString() {
        return "Optional.absent()";
    }
}
