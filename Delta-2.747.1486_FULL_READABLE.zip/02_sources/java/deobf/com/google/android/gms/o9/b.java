package deobf.com.google.android.gms.o9;

import androidx.annotation.NonNull;
import com.google.android.gms.common.api.Status;

// dex: classes.dex
public class b {
    @NonNull
    public static deobf.com.google.android.gms.l9.b a(@NonNull Status status) {
        return status.E3() ? new deobf.com.google.android.gms.l9.n(status) : new deobf.com.google.android.gms.l9.b(status);
    }
}
