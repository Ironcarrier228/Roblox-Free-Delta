package deobf.com.google.android.gms.p9;

import com.google.android.gms.common.internal.safeparcel.SafeParcelable;

// dex: classes.dex
public abstract class a implements SafeParcelable {
    @Override // android.os.Parcelable
    public final int describeContents() {
        return 0;
    }
}
