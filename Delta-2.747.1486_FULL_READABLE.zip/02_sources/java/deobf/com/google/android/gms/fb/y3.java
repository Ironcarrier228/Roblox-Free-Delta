package deobf.com.google.android.gms.fb;

import java.io.IOException;

// dex: classes.dex
public final class y3 extends IOException {
    public y3(String str) {
        super(str);
    }

    public y3(String str, Throwable th2) {
        super("Error in decoding CborValue from bytes", th2);
    }
}
