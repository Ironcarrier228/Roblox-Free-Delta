package deobf.com.google.android.gms.o9;

import android.os.Parcel;
import android.os.Parcelable;
import androidx.annotation.NonNull;

// dex: classes.dex
public class e extends deobf.com.google.android.gms.p9.a {

    @NonNull
    public static final Parcelable.Creator<e> CREATOR = new a0();

    public final int f26933f;

    public final String f26934g;

    public e(int i10, String str) {
        this.f26933f = i10;
        this.f26934g = str;
    }

    public final boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof e)) {
            return false;
        }
        e eVar = (e) obj;
        return eVar.f26933f == this.f26933f && deobf.androidx.appcompat.widget.q.b(eVar.f26934g, this.f26934g);
    }

    public final int hashCode() {
        return this.f26933f;
    }

    @NonNull
    public final String toString() {
        return this.f26933f + ":" + this.f26934g;
    }

    @Override // android.os.Parcelable
    public final void writeToParcel(@NonNull Parcel parcel, int i10) {
        int i11 = this.f26933f;
        int a10 = deobf.com.google.android.gms.p9.c.a(parcel);
        deobf.com.google.android.gms.p9.c.n(parcel, 1, i11);
        deobf.com.google.android.gms.p9.c.v(parcel, 2, this.f26934g, false);
        deobf.com.google.android.gms.p9.c.b(parcel, a10);
    }
}
