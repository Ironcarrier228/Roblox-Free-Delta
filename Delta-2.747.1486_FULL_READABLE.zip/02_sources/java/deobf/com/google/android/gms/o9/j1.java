package deobf.com.google.android.gms.o9;

import android.os.Bundle;
import java.util.Objects;

// dex: classes.dex
public final class j1 extends v0 {

    public final /* synthetic */ d f26989g;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public j1(d dVar, int i10, Bundle bundle) {
        super(dVar, i10, bundle);
        Objects.requireNonNull(dVar);
        this.f26989g = dVar;
    }

    @Override // deobf.com.google.android.gms.o9.v0
    public final boolean e() {
        this.f26989g.zzc.c(deobf.com.google.mlkit.vision.k9.b.f21213k);
        return true;
    }

    @Override // deobf.com.google.android.gms.o9.v0
    public final void f(deobf.com.google.mlkit.vision.k9.b bVar) {
        d dVar = this.f26989g;
        if (dVar.enableLocalFallback() && dVar.zzg()) {
            dVar.zzf(16);
        } else {
            dVar.zzc.c(bVar);
            dVar.onConnectionFailed(bVar);
        }
    }
}
