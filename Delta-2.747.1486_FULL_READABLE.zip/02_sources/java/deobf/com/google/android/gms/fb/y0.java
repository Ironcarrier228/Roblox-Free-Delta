package deobf.com.google.android.gms.fb;

// dex: classes.dex
public final class y0 {
    public static int a(int i10) {
        return (int) (Integer.rotateLeft((int) (i10 * (-862048943)), 15) * 461845907);
    }
}
