package deobf.com.google.android.gms.fb;

import android.os.IBinder;
import android.os.IInterface;

// dex: classes.dex
public final class x4 extends a implements IInterface {
    public x4(IBinder iBinder) {
        super(iBinder, "com.google.android.gms.fido.u2f.internal.zeroparty.IU2fZeroPartyService");
    }
}
