package deobf.com.google.android.gms.o9;

import android.os.Bundle;
import androidx.annotation.NonNull;
import deobf.com.google.android.gms.l9.a;

// dex: classes.dex
public class z implements a.d {

    @NonNull
    public static final z b = a().a();

    public final String f27057a;

    public static class a {

        public String f27058a;

        public /* synthetic */ a(c0 c0Var) {
        }

        @NonNull
        public z a() {
            return new z(this.f27058a, null);
        }

        @NonNull
        public a b(String str) {
            this.f27058a = str;
            return this;
        }
    }

    public /* synthetic */ z(String str, d0 d0Var) {
        this.f27057a = str;
    }

    @NonNull
    public static a a() {
        return new a(null);
    }

    @NonNull
    public final Bundle b() {
        Bundle bundle = new Bundle();
        String str = this.f27057a;
        if (str != null) {
            bundle.putString("api", str);
        }
        return bundle;
    }

    public final boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (obj instanceof z) {
            return deobf.androidx.appcompat.widget.q.b(this.f27057a, ((z) obj).f27057a);
        }
        return false;
    }

    public final int hashCode() {
        return deobf.androidx.appcompat.widget.q.c(this.f27057a);
    }
}
