package deobf.com.google.android.gms.o9;

import androidx.annotation.NonNull;
import com.google.android.gms.tasks.Task;

// dex: classes.dex
public class r {

    public static final q0 f27022a = new n0();

    public interface a<R extends deobf.com.google.android.gms.l9.p, T> {
        T a(@NonNull R r10);
    }

    @NonNull
    public static <R extends deobf.com.google.android.gms.l9.p, T> Task<T> a(@NonNull deobf.com.google.android.gms.l9.k<R> kVar, @NonNull a<R, T> aVar) {
        q0 q0Var = f27022a;
        deobf.com.google.mlkit.common.tb.k kVar2 = new deobf.com.google.mlkit.common.tb.k();
        kVar.c(new o0(kVar, kVar2, aVar, q0Var));
        return kVar2.a();
    }

    @NonNull
    public static <R extends deobf.com.google.android.gms.l9.p> Task<Void> b(@NonNull deobf.com.google.android.gms.l9.k<R> kVar) {
        return a(kVar, new p0());
    }
}
