package deobf.com.google.android.gms.fb;

// dex: classes.dex
public final class l4 implements k4 {

    public static final q f15764a;
    public static final q b;

    public static final q f15765c;

    public static final q f15766d;

    public static final q f15767e;

    public static final q f15768f;

    public static final q f15769g;

    public static final q f15770h;

    static {
        y d10 = new y("com.google.android.gms.fido").e(h1.m("FIDO")).d();
        f15764a = d10.c("Fido2Ctap2Support__disable_transport_comparator", true);
        b = d10.c("Fido2Ctap2Support__enable_cancelling_requests", true);
        f15765c = d10.c("Fido2Ctap2Support__enable_flow_separation_refactor", false);
        f15766d = d10.c("Fido2Ctap2Support__nfc_activity_destroyed_check", true);
        f15767e = d10.c("Fido2Ctap2Support__remove_this_device_for_assertions", false);
        f15768f = d10.c("Fido2Ctap2Support__skip_usb_permission_dialog", false);
        f15769g = d10.c("Fido2Ctap2Support__transport_controller_refactor", false);
        f15770h = d10.c("Fido2Ctap2Support__update_user_cancel_response", false);
    }

    @Override // deobf.com.google.android.gms.fb.k4
    public final boolean zza() {
        return ((Boolean) f15765c.zza()).booleanValue();
    }
}
