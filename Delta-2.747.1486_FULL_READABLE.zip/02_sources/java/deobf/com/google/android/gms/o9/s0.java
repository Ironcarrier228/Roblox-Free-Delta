package deobf.com.google.android.gms.o9;

import android.accounts.Account;
import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;

// dex: classes.dex
public final class s0 implements Parcelable.Creator {
    @Override // android.os.Parcelable.Creator
    public final /* bridge */ /* synthetic */ Object createFromParcel(Parcel parcel) {
        int D = deobf.com.google.android.gms.p9.b.D(parcel);
        Account account = null;
        int i10 = 0;
        int i11 = 0;
        GoogleSignInAccount googleSignInAccount = null;
        while (parcel.dataPosition() < D) {
            int u8 = deobf.com.google.android.gms.p9.b.u(parcel);
            int n10 = deobf.com.google.android.gms.p9.b.n(u8);
            if (n10 == 1) {
                i10 = deobf.com.google.android.gms.p9.b.w(parcel, u8);
            } else if (n10 == 2) {
                account = (Account) deobf.com.google.android.gms.p9.b.g(parcel, u8, Account.CREATOR);
            } else if (n10 == 3) {
                i11 = deobf.com.google.android.gms.p9.b.w(parcel, u8);
            } else if (n10 != 4) {
                deobf.com.google.android.gms.p9.b.C(parcel, u8);
            } else {
                googleSignInAccount = (GoogleSignInAccount) deobf.com.google.android.gms.p9.b.g(parcel, u8, GoogleSignInAccount.CREATOR);
            }
        }
        deobf.com.google.android.gms.p9.b.m(parcel, D);
        return new r0(i10, account, i11, googleSignInAccount);
    }

    @Override // android.os.Parcelable.Creator
    public final /* synthetic */ Object[] newArray(int i10) {
        return new r0[i10];
    }
}
