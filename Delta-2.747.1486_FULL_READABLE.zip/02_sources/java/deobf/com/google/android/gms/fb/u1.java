package deobf.com.google.android.gms.fb;

import java.util.Iterator;

// dex: classes.dex
public final class u1 extends h1 {

    public static final Object[] f15871h;

    public static final u1 f15872i;

    public final transient Object[] f15873c;

    public final transient int f15874d;

    public final transient Object[] f15875e;

    public final transient int f15876f;

    public final transient int f15877g;

    static {
        Object[] objArr = new Object[0];
        f15871h = objArr;
        f15872i = new u1(objArr, 0, objArr, 0, 0);
    }

    public u1(Object[] objArr, int i10, Object[] objArr2, int i11, int i12) {
        this.f15873c = objArr;
        this.f15874d = i10;
        this.f15875e = objArr2;
        this.f15876f = i11;
        this.f15877g = i12;
    }

    @Override // deobf.com.google.android.gms.fb.z0
    public final int a(Object[] objArr, int i10) {
        System.arraycopy(this.f15873c, 0, objArr, 0, this.f15877g);
        return this.f15877g;
    }

    @Override // deobf.com.google.android.gms.fb.z0
    public final int b() {
        return this.f15877g;
    }

    @Override // deobf.com.google.android.gms.fb.z0
    public final int c() {
        return 0;
    }

    @Override // deobf.com.google.android.gms.fb.z0, java.util.AbstractCollection, java.util.Collection, java.util.List
    public final boolean contains(Object obj) {
        if (obj != null) {
            Object[] objArr = this.f15875e;
            if (objArr.length != 0) {
                int a10 = deobf.androidx.camera.camera2.internal.compat.quirk.y0.a(obj.hashCode());
                while (true) {
                    int i10 = a10 & this.f15876f;
                    Object obj2 = objArr[i10];
                    if (obj2 == null) {
                        return false;
                    }
                    if (obj2.equals(obj)) {
                        return true;
                    }
                    a10 = i10 + 1;
                }
            }
        }
        return false;
    }

    @Override // deobf.com.google.android.gms.fb.h1, deobf.com.google.android.gms.fb.z0
    public final c2 d() {
        return i().listIterator(0);
    }

    @Override // deobf.com.google.android.gms.fb.z0
    public final Object[] e() {
        return this.f15873c;
    }

    @Override // deobf.com.google.android.gms.fb.h1
    public final boolean g() {
        return true;
    }

    @Override // deobf.com.google.android.gms.fb.h1, java.util.Collection, java.util.Set
    public final int hashCode() {
        return this.f15874d;
    }

    @Override // java.util.AbstractCollection, java.util.Collection, java.lang.Iterable, java.util.Set
    public final /* synthetic */ Iterator iterator() {
        return i().listIterator(0);
    }

    @Override // deobf.com.google.android.gms.fb.h1
    public final e1 j() {
        return e1.h(this.f15873c, this.f15877g);
    }

    @Override // java.util.AbstractCollection, java.util.Collection, java.util.Set
    public final int size() {
        return this.f15877g;
    }
}
