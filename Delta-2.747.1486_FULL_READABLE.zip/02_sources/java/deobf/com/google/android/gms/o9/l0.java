package deobf.com.google.android.gms.o9;

import android.content.Context;
import android.util.SparseIntArray;
import androidx.annotation.NonNull;
import com.google.errorprone.annotations.ResultIgnorabilityUnspecified;
import deobf.com.google.android.gms.l9.a;

// dex: classes.dex
public final class l0 {

    public final SparseIntArray f26992a = new SparseIntArray();
    public deobf.com.google.mlkit.vision.k9.f b;

    public l0(@NonNull deobf.com.google.mlkit.vision.k9.f fVar) {
        s.l(fVar);
        this.b = fVar;
    }

    public final int a(Context context, int i10) {
        return this.f26992a.get(i10, -1);
    }

    @ResultIgnorabilityUnspecified
    public final int b(@NonNull Context context, @NonNull a.f fVar) {
        s.l(context);
        s.l(fVar);
        int i10 = 0;
        if (!fVar.requiresGooglePlayServices()) {
            return 0;
        }
        int minApkVersion = fVar.getMinApkVersion();
        int a10 = a(context, minApkVersion);
        if (a10 != -1) {
            return a10;
        }
        int i11 = 0;
        while (true) {
            if (i11 >= this.f26992a.size()) {
                i10 = -1;
                break;
            }
            int keyAt = this.f26992a.keyAt(i11);
            if (keyAt > minApkVersion && this.f26992a.get(keyAt) == 0) {
                break;
            }
            i11++;
        }
        if (i10 == -1) {
            i10 = this.b.h(context, minApkVersion);
        }
        this.f26992a.put(minApkVersion, i10);
        return i10;
    }

    public final void c() {
        this.f26992a.clear();
    }
}
