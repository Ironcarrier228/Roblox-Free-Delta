package deobf.com.google.android.gms.fb;

// dex: classes.dex
public interface q0 {
    Object zza();
}
