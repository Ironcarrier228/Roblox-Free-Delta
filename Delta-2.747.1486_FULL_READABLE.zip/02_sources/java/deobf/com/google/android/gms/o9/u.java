package deobf.com.google.android.gms.o9;

import android.os.Parcel;
import android.os.Parcelable;
import androidx.annotation.NonNull;

// dex: classes.dex
public class u extends deobf.com.google.android.gms.p9.a {

    @NonNull
    public static final Parcelable.Creator<u> CREATOR = new c1();

    public final int f27043f;

    public final boolean f27044g;

    public final boolean f27045h;

    public final int f27046i;

    public final int f27047j;

    public u(int i10, boolean z10, boolean z11, int i11, int i12) {
        this.f27043f = i10;
        this.f27044g = z10;
        this.f27045h = z11;
        this.f27046i = i11;
        this.f27047j = i12;
    }

    public int A3() {
        return this.f27046i;
    }

    public int B3() {
        return this.f27047j;
    }

    public boolean C3() {
        return this.f27044g;
    }

    public boolean D3() {
        return this.f27045h;
    }

    public int E3() {
        return this.f27043f;
    }

    @Override // android.os.Parcelable
    public final void writeToParcel(@NonNull Parcel parcel, int i10) {
        int a10 = deobf.com.google.android.gms.p9.c.a(parcel);
        deobf.com.google.android.gms.p9.c.n(parcel, 1, E3());
        deobf.com.google.android.gms.p9.c.c(parcel, 2, C3());
        deobf.com.google.android.gms.p9.c.c(parcel, 3, D3());
        deobf.com.google.android.gms.p9.c.n(parcel, 4, A3());
        deobf.com.google.android.gms.p9.c.n(parcel, 5, B3());
        deobf.com.google.android.gms.p9.c.b(parcel, a10);
    }
}
