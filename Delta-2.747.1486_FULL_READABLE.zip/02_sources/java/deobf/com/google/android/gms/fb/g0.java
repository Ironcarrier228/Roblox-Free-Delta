package deobf.com.google.android.gms.fb;

// dex: classes.dex
public final class g0 extends h0 {
    public /* synthetic */ g0(f0 f0Var) {
    }
}
