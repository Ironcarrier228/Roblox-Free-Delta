package deobf.com.google.android.gms.fb;

// dex: classes.dex
public class h0 {

    public String f15739a;
    public Object b;

    public h0 f15740c;
}
