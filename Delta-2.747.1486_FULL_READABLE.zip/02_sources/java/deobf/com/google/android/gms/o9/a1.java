package deobf.com.google.android.gms.o9;

import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.util.Log;
import com.google.mlkit.vision.barcode.common.Barcode;

// dex: classes.dex
public final class a1 {

    public static final Object f26927a = new Object();
    public static boolean b;

    public static String f26928c;

    public static int f26929d;

    public static int a(Context context) {
        b(context);
        return f26929d;
    }

    public static void b(Context context) {
        Bundle bundle;
        synchronized (f26927a) {
            try {
                if (b) {
                    return;
                }
                b = true;
                try {
                    bundle = deobf.unlinked.x9.c.a(context).c(context.getPackageName(), Barcode.FORMAT_ITF).metaData;
                } catch (PackageManager.NameNotFoundException e10) {
                    Log.wtf("MetadataValueReader", "This should never happen.", e10);
                }
                if (bundle == null) {
                    return;
                }
                f26928c = bundle.getString("com.google.app.id");
                f26929d = bundle.getInt("com.google.android.gms.version");
            } catch (Throwable th2) {
                throw th2;
            }
        }
    }
}
