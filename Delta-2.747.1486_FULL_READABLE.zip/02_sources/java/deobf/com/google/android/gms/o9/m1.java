package deobf.com.google.android.gms.o9;

import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;

// dex: classes.dex
public final class m1 implements Parcelable.Creator {
    @Override // android.os.Parcelable.Creator
    public final /* bridge */ /* synthetic */ Object createFromParcel(Parcel parcel) {
        int D = deobf.com.google.android.gms.p9.b.D(parcel);
        Bundle bundle = null;
        g gVar = null;
        int i10 = 0;
        deobf.com.google.mlkit.vision.k9.d[] dVarArr = null;
        while (parcel.dataPosition() < D) {
            int u8 = deobf.com.google.android.gms.p9.b.u(parcel);
            int n10 = deobf.com.google.android.gms.p9.b.n(u8);
            if (n10 == 1) {
                bundle = deobf.com.google.android.gms.p9.b.b(parcel, u8);
            } else if (n10 == 2) {
                dVarArr = (deobf.com.google.mlkit.vision.k9.d[]) deobf.com.google.android.gms.p9.b.k(parcel, u8, deobf.com.google.mlkit.vision.k9.d.CREATOR);
            } else if (n10 == 3) {
                i10 = deobf.com.google.android.gms.p9.b.w(parcel, u8);
            } else if (n10 != 4) {
                deobf.com.google.android.gms.p9.b.C(parcel, u8);
            } else {
                gVar = (g) deobf.com.google.android.gms.p9.b.g(parcel, u8, g.CREATOR);
            }
        }
        deobf.com.google.android.gms.p9.b.m(parcel, D);
        return new l1(bundle, dVarArr, i10, gVar);
    }

    @Override // android.os.Parcelable.Creator
    public final /* synthetic */ Object[] newArray(int i10) {
        return new l1[i10];
    }
}
