package deobf.com.google.android.gms.o9;

import androidx.annotation.NonNull;

// dex: classes.dex
public final class t {
    public static t b;

    public static final u f27036c = new u(0, false, false, 0, 0);

    public u f27037a;

    @NonNull
    public static synchronized t b() {
        t tVar;
        synchronized (t.class) {
            try {
                if (b == null) {
                    b = new t();
                }
                tVar = b;
            } catch (Throwable th2) {
                throw th2;
            }
        }
        return tVar;
    }

    public u a() {
        return this.f27037a;
    }

    public final synchronized void c(u uVar) {
        if (uVar == null) {
            this.f27037a = f27036c;
            return;
        }
        u uVar2 = this.f27037a;
        if (uVar2 == null || uVar2.E3() < uVar.E3()) {
            this.f27037a = uVar;
        }
    }
}
