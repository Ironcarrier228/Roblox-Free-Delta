package deobf.com.google.android.gms.fb;

import java.util.Comparator;

// dex: classes.dex
public final class b3 {
    public static Comparator a() {
        return a3.b;
    }
}
