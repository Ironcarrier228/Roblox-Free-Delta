package deobf.com.google.android.gms.fb;

import java.util.Comparator;

// dex: classes.dex
public interface a2 extends Iterable {
    Comparator comparator();
}
