package deobf.com.google.android.gms.o9;

import android.os.Parcel;
import android.os.Parcelable;
import androidx.annotation.NonNull;
import java.util.ArrayList;
import java.util.List;

// dex: classes.dex
public class w extends deobf.com.google.android.gms.p9.a {

    @NonNull
    public static final Parcelable.Creator<w> CREATOR = new b0();

    public final int f27054f;

    public List f27055g;

    public w(int i10, List list) {
        this.f27054f = i10;
        this.f27055g = list;
    }

    public final int A3() {
        return this.f27054f;
    }

    public final List B3() {
        return this.f27055g;
    }

    public final void C3(@NonNull p pVar) {
        if (this.f27055g == null) {
            this.f27055g = new ArrayList();
        }
        this.f27055g.add(pVar);
    }

    @Override // android.os.Parcelable
    public final void writeToParcel(@NonNull Parcel parcel, int i10) {
        int a10 = deobf.com.google.android.gms.p9.c.a(parcel);
        deobf.com.google.android.gms.p9.c.n(parcel, 1, this.f27054f);
        deobf.com.google.android.gms.p9.c.z(parcel, 2, this.f27055g, false);
        deobf.com.google.android.gms.p9.c.b(parcel, a10);
    }
}
