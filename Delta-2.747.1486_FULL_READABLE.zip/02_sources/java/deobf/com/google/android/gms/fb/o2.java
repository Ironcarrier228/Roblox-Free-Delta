package deobf.com.google.android.gms.fb;

import java.security.MessageDigest;
import java.util.Arrays;

// dex: classes.dex
public final class o2 extends e2 {
    public final MessageDigest b;

    public final int f15781c;

    public boolean f15782d;

    public /* synthetic */ o2(MessageDigest messageDigest, int i10, n2 n2Var) {
        this.b = messageDigest;
        this.f15781c = i10;
    }

    @Override // deobf.com.google.android.gms.fb.e2
    public final void b(byte[] bArr, int i10, int i11) {
        c();
        this.b.update(bArr, 0, i11);
    }

    public final void c() {
        deobf.androidx.camera.camera2.internal.compat.quirk.n0.f(!this.f15782d, "Cannot re-use a Hasher after calling hash() on it");
    }

    @Override // deobf.com.google.android.gms.fb.k2
    public final i2 zzc() {
        c();
        this.f15782d = true;
        int i10 = this.f15781c;
        if (i10 == this.b.getDigestLength()) {
            byte[] digest = this.b.digest();
            char[] cArr = i2.f15748a;
            return new h2(digest);
        }
        byte[] copyOf = Arrays.copyOf(this.b.digest(), i10);
        char[] cArr2 = i2.f15748a;
        return new h2(copyOf);
    }
}
