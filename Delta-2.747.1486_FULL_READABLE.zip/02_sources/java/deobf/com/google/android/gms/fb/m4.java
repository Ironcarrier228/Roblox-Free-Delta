package deobf.com.google.android.gms.fb;

// dex: classes.dex
public final class m4 implements q0 {
    public static final m4 b = new m4();

    public final q0 f15776a = deobf.unlinked.u0.b(new o4());

    public static boolean a() {
        return ((n4) b.f15776a.zza()).zza();
    }

    @Override // deobf.com.google.android.gms.fb.q0
    public final /* bridge */ /* synthetic */ Object zza() {
        throw null;
    }
}
