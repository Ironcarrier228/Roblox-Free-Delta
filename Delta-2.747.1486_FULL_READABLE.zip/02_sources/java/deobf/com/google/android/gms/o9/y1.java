package deobf.com.google.android.gms.o9;

import android.os.IInterface;

// dex: classes.dex
public interface y1 extends IInterface {
    deobf.com.google.android.gms.z9.a zzd();

    int zze();
}
