package deobf.com.google.android.gms.o9;

import android.os.IBinder;
import android.os.Parcel;
import deobf.com.google.android.gms.z9.a;

// dex: classes.dex
public final class w1 extends deobf.com.google.android.gms.eb.a implements y1 {
    public w1(IBinder iBinder) {
        super(iBinder, "com.google.android.gms.common.internal.ICertData");
    }

    @Override // deobf.com.google.android.gms.o9.y1
    public final deobf.com.google.android.gms.z9.a zzd() {
        Parcel r22 = r2(1, s2());
        deobf.com.google.android.gms.z9.a s22 = a.AbstractBinderC0786a.s2(r22.readStrongBinder());
        r22.recycle();
        return s22;
    }

    @Override // deobf.com.google.android.gms.o9.y1
    public final int zze() {
        Parcel r22 = r2(2, s2());
        int readInt = r22.readInt();
        r22.recycle();
        return readInt;
    }
}
