package deobf.com.google.android.gms.z9;

import android.os.IBinder;
import android.os.IInterface;
import androidx.annotation.NonNull;
import deobf.com.google.android.gms.eb.n;

// dex: classes.dex
public interface a extends IInterface {

    public static abstract class AbstractBinderC0786a extends n implements a {
        public AbstractBinderC0786a() {
            super("com.google.android.gms.dynamic.IObjectWrapper");
        }

        @NonNull
        public static a s2(@NonNull IBinder iBinder) {
            if (iBinder == null) {
                return null;
            }
            IInterface queryLocalInterface = iBinder.queryLocalInterface("com.google.android.gms.dynamic.IObjectWrapper");
            return queryLocalInterface instanceof a ? (a) queryLocalInterface : new c(iBinder);
        }
    }
}
