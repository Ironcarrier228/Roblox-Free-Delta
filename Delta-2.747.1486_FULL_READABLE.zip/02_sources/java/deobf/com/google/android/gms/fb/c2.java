package deobf.com.google.android.gms.fb;

import java.util.Iterator;

// dex: classes.dex
public abstract class c2 implements Iterator {
    @Override // java.util.Iterator
    @Deprecated
    public final void remove() {
        throw new UnsupportedOperationException();
    }
}
