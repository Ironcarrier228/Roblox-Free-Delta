package deobf.com.google.android.gms.fb;

// dex: classes.dex
public final class x2 {
    public static void a(boolean z10) {
        if (!z10) {
            throw new ArithmeticException("mode was UNNECESSARY, but rounding was necessary");
        }
    }
}
