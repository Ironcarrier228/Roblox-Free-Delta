package deobf.com.google.android.gms.fb;

import java.io.Serializable;

// dex: classes.dex
public final class w1 extends s1 implements Serializable {

    public static final w1 f15888a = new w1();

    @Override // deobf.com.google.android.gms.fb.s1
    public final s1 a() {
        return q1.f15827a;
    }

    @Override // deobf.com.google.android.gms.fb.s1, java.util.Comparator
    public final /* bridge */ /* synthetic */ int compare(Object obj, Object obj2) {
        Comparable comparable = (Comparable) obj;
        Comparable comparable2 = (Comparable) obj2;
        comparable.getClass();
        if (comparable == comparable2) {
            return 0;
        }
        return comparable2.compareTo(comparable);
    }

    public final String toString() {
        return "Ordering.natural().reverse()";
    }
}
