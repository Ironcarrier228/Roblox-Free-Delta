package deobf.com.google.android.gms.fb;

import java.util.Objects;

// dex: classes.dex
public final class t1 extends e1 {

    public static final e1 f15865e = new t1(new Object[0], 0);

    public final transient Object[] f15866c;

    public final transient int f15867d;

    public t1(Object[] objArr, int i10) {
        this.f15866c = objArr;
        this.f15867d = i10;
    }

    @Override // deobf.com.google.android.gms.fb.e1, deobf.com.google.android.gms.fb.z0
    public final int a(Object[] objArr, int i10) {
        System.arraycopy(this.f15866c, 0, objArr, 0, this.f15867d);
        return this.f15867d;
    }

    @Override // deobf.com.google.android.gms.fb.z0
    public final int b() {
        return this.f15867d;
    }

    @Override // deobf.com.google.android.gms.fb.z0
    public final int c() {
        return 0;
    }

    @Override // deobf.com.google.android.gms.fb.z0
    public final Object[] e() {
        return this.f15866c;
    }

    @Override // java.util.List
    public final Object get(int i10) {
        n0.a(i10, this.f15867d, "index");
        Object obj = this.f15866c[i10];
        Objects.requireNonNull(obj);
        return obj;
    }

    @Override // java.util.AbstractCollection, java.util.Collection, java.util.List
    public final int size() {
        return this.f15867d;
    }
}
