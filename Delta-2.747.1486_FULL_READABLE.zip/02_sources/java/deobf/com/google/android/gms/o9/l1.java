package deobf.com.google.android.gms.o9;

import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;

// dex: classes.dex
public final class l1 extends deobf.com.google.android.gms.p9.a {
    public static final Parcelable.Creator<l1> CREATOR = new m1();

    public Bundle f26993f;

    public deobf.com.google.mlkit.vision.k9.d[] f26994g;

    public int f26995h;

    public g f26996i;

    public l1() {
    }

    @Override // android.os.Parcelable
    public final void writeToParcel(Parcel parcel, int i10) {
        int a10 = deobf.com.google.android.gms.p9.c.a(parcel);
        deobf.com.google.android.gms.p9.c.f(parcel, 1, this.f26993f, false);
        deobf.com.google.android.gms.p9.c.y(parcel, 2, this.f26994g, i10, false);
        deobf.com.google.android.gms.p9.c.n(parcel, 3, this.f26995h);
        deobf.com.google.android.gms.p9.c.t(parcel, 4, this.f26996i, i10, false);
        deobf.com.google.android.gms.p9.c.b(parcel, a10);
    }

    public l1(Bundle bundle, deobf.com.google.mlkit.vision.k9.d[] dVarArr, int i10, g gVar) {
        this.f26993f = bundle;
        this.f26994g = dVarArr;
        this.f26995h = i10;
        this.f26996i = gVar;
    }
}
