package deobf.com.google.android.gms.o9;

import android.app.PendingIntent;
import android.os.Bundle;
import java.util.Objects;

// dex: classes.dex
public abstract class v0 extends f1 {

    public final int f27051d;

    public final Bundle f27052e;

    public final /* synthetic */ d f27053f;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public v0(d dVar, int i10, Bundle bundle) {
        super(dVar, Boolean.TRUE);
        Objects.requireNonNull(dVar);
        this.f27053f = dVar;
        this.f27051d = i10;
        this.f27052e = bundle;
    }

    @Override // deobf.com.google.android.gms.o9.f1
    public final /* bridge */ /* synthetic */ void a(Object obj) {
        int i10 = this.f27051d;
        if (i10 != 0) {
            this.f27053f.zzd(1, null);
            Bundle bundle = this.f27052e;
            f(new deobf.com.google.mlkit.vision.k9.b(i10, bundle != null ? (PendingIntent) bundle.getParcelable("pendingIntent") : null));
        } else {
            if (e()) {
                return;
            }
            this.f27053f.zzd(1, null);
            f(new deobf.com.google.mlkit.vision.k9.b(8, null));
        }
    }

    public abstract boolean e();

    public abstract void f(deobf.com.google.mlkit.vision.k9.b bVar);
}
