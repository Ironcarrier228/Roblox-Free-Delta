package deobf.com.google.android.gms.o9;

// dex: classes.dex
public final class b1 extends Exception {

    public final deobf.com.google.mlkit.vision.k9.b f26930a;

    public b1(deobf.com.google.mlkit.vision.k9.b bVar) {
        deobf.android.view.s.b(bVar.E3(), "ResolvableConnectionException can only be created with a connection result containing a resolution.");
        this.f26930a = bVar;
    }
}
