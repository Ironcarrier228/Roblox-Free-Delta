package deobf.com.google.android.gms.fb;

import java.util.Iterator;

// dex: classes.dex
public final class k1 extends g1 {

    public final /* synthetic */ l1 f15755c;

    public k1(l1 l1Var) {
        this.f15755c = l1Var;
    }

    @Override // deobf.com.google.android.gms.fb.h1, deobf.com.google.android.gms.fb.z0
    public final c2 d() {
        return i().listIterator(0);
    }

    @Override // java.util.AbstractCollection, java.util.Collection, java.lang.Iterable, java.util.Set
    public final /* synthetic */ Iterator iterator() {
        return i().listIterator(0);
    }

    @Override // deobf.com.google.android.gms.fb.h1
    public final e1 j() {
        return new j1(this);
    }

    @Override // deobf.com.google.android.gms.fb.g1
    public final f1 q() {
        return this.f15755c;
    }
}
