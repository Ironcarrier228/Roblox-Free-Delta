package deobf.com.google.android.gms.fb;

// dex: classes.dex
public interface q4 {
    boolean zza();
}
