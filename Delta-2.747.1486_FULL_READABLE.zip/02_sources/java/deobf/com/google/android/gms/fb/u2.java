package deobf.com.google.android.gms.fb;

import java.io.IOException;

// dex: classes.dex
public abstract class u2 {

    public static final u2 f15878a = new s2("base64()", "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/", '=');
    public static final u2 b = new s2("base64Url()", "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_", '=');

    public static final u2 f15879c = new t2("base32()", "ABCDEFGHIJKLMNOPQRSTUVWXYZ234567", '=');

    public static final u2 f15880d = new t2("base32Hex()", "0123456789ABCDEFGHIJKLMNOPQRSTUV", '=');

    public static final u2 f15881e = new r2("base16()", "0123456789ABCDEF");

    public static u2 d() {
        return f15881e;
    }

    public abstract void a(Appendable appendable, byte[] bArr, int i10, int i11);

    public abstract int b(int i10);

    public abstract u2 c();

    public final String e(byte[] bArr, int i10, int i11) {
        deobf.androidx.camera.camera2.internal.compat.quirk.n0.e(0, i11, bArr.length);
        StringBuilder sb2 = new StringBuilder(b(i11));
        try {
            a(sb2, bArr, 0, i11);
            return sb2.toString();
        } catch (IOException e10) {
            throw new AssertionError(e10);
        }
    }
}
