package deobf.com.google.android.gms.fb;

// dex: classes.dex
public final class a1 extends v0 {

    public final e1 f15717c;

    public a1(e1 e1Var, int i10) {
        super(e1Var.size(), i10);
        this.f15717c = e1Var;
    }

    @Override // deobf.com.google.android.gms.fb.v0
    public final Object a(int i10) {
        return this.f15717c.get(i10);
    }
}
