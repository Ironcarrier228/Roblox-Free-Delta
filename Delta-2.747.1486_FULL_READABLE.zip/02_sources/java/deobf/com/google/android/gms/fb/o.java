package deobf.com.google.android.gms.fb;

// dex: classes.dex
public final class o {

    public static final n f15779a = new n(null);
}
