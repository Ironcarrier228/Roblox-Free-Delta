package deobf.com.google.android.gms.o9;

import android.util.Log;
import androidx.annotation.NonNull;

// dex: classes.dex
public final class k {

    public final String f26990a;
    public final String b;

    public k(@NonNull String str) {
        this(str, null);
    }

    public boolean a(int i10) {
        return Log.isLoggable(this.f26990a, i10);
    }

    public void b(@NonNull String str, @NonNull String str2) {
        if (a(3)) {
            Log.d(str, j(str2));
        }
    }

    public void c(@NonNull String str, @NonNull String str2, @NonNull Throwable th2) {
        if (a(3)) {
            Log.d(str, j(str2), th2);
        }
    }

    public void d(@NonNull String str, @NonNull String str2) {
        if (a(6)) {
            Log.e(str, j(str2));
        }
    }

    public void e(@NonNull String str, @NonNull String str2, @NonNull Throwable th2) {
        if (a(6)) {
            Log.e(str, j(str2), th2);
        }
    }

    public void f(@NonNull String str, @NonNull String str2) {
        if (a(4)) {
            Log.i(str, j(str2));
        }
    }

    public void g(@NonNull String str, @NonNull String str2) {
        if (a(2)) {
            Log.v(str, j(str2));
        }
    }

    public void h(@NonNull String str, @NonNull String str2) {
        if (a(5)) {
            Log.w(str, j(str2));
        }
    }

    public void i(@NonNull String str, @NonNull String str2, @NonNull Throwable th2) {
        if (a(5)) {
            Log.w(str, j(str2), th2);
        }
    }

    public final String j(String str) {
        String str2 = this.b;
        return str2 == null ? str : str2.concat(str);
    }

    public k(@NonNull String str, String str2) {
        s.m(str, "log tag cannot be null");
        s.c(str.length() <= 23, "tag \"%s\" is longer than the %d character maximum", str, 23);
        this.f26990a = str;
        this.b = (str2 == null || str2.length() <= 0) ? null : str2;
    }
}
