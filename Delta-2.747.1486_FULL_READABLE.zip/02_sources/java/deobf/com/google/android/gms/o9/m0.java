package deobf.com.google.android.gms.o9;

import android.os.Parcel;
import android.os.Parcelable;

// dex: classes.dex
public final class m0 implements Parcelable.Creator {
    @Override // android.os.Parcelable.Creator
    public final /* bridge */ /* synthetic */ Object createFromParcel(Parcel parcel) {
        int D = deobf.com.google.android.gms.p9.b.D(parcel);
        int i10 = -1;
        int i11 = 0;
        int i12 = 0;
        int i13 = 0;
        int i14 = 0;
        String str = null;
        String str2 = null;
        long j10 = 0;
        long j11 = 0;
        while (parcel.dataPosition() < D) {
            int u8 = deobf.com.google.android.gms.p9.b.u(parcel);
            switch (deobf.com.google.android.gms.p9.b.n(u8)) {
                case 1:
                    i11 = deobf.com.google.android.gms.p9.b.w(parcel, u8);
                    break;
                case 2:
                    i12 = deobf.com.google.android.gms.p9.b.w(parcel, u8);
                    break;
                case 3:
                    i13 = deobf.com.google.android.gms.p9.b.w(parcel, u8);
                    break;
                case 4:
                    j10 = deobf.com.google.android.gms.p9.b.y(parcel, u8);
                    break;
                case 5:
                    j11 = deobf.com.google.android.gms.p9.b.y(parcel, u8);
                    break;
                case 6:
                    str = deobf.com.google.android.gms.p9.b.h(parcel, u8);
                    break;
                case 7:
                    str2 = deobf.com.google.android.gms.p9.b.h(parcel, u8);
                    break;
                case 8:
                    i14 = deobf.com.google.android.gms.p9.b.w(parcel, u8);
                    break;
                case 9:
                    i10 = deobf.com.google.android.gms.p9.b.w(parcel, u8);
                    break;
                default:
                    deobf.com.google.android.gms.p9.b.C(parcel, u8);
                    break;
            }
        }
        deobf.com.google.android.gms.p9.b.m(parcel, D);
        return new p(i11, i12, i13, j10, j11, str, str2, i14, i10);
    }

    @Override // android.os.Parcelable.Creator
    public final /* synthetic */ Object[] newArray(int i10) {
        return new p[i10];
    }
}
