package deobf.com.google.android.gms.o9;

import android.accounts.Account;
import android.os.Bundle;
import android.os.IBinder;
import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.api.Scope;

// dex: classes.dex
public final class o1 implements Parcelable.Creator {
    public static void a(h hVar, Parcel parcel, int i10) {
        int a10 = deobf.com.google.android.gms.p9.c.a(parcel);
        deobf.com.google.android.gms.p9.c.n(parcel, 1, hVar.f26963f);
        deobf.com.google.android.gms.p9.c.n(parcel, 2, hVar.f26964g);
        deobf.com.google.android.gms.p9.c.n(parcel, 3, hVar.f26965h);
        deobf.com.google.android.gms.p9.c.v(parcel, 4, hVar.f26966i, false);
        deobf.com.google.android.gms.p9.c.m(parcel, 5, hVar.f26967j, false);
        deobf.com.google.android.gms.p9.c.y(parcel, 6, hVar.f26968k, i10, false);
        deobf.com.google.android.gms.p9.c.f(parcel, 7, hVar.f26969l, false);
        deobf.com.google.android.gms.p9.c.t(parcel, 8, hVar.f26970m, i10, false);
        deobf.com.google.android.gms.p9.c.y(parcel, 10, hVar.f26971n, i10, false);
        deobf.com.google.android.gms.p9.c.y(parcel, 11, hVar.f26972o, i10, false);
        deobf.com.google.android.gms.p9.c.c(parcel, 12, hVar.f26973p);
        deobf.com.google.android.gms.p9.c.n(parcel, 13, hVar.f26974q);
        deobf.com.google.android.gms.p9.c.c(parcel, 14, hVar.f26975r);
        deobf.com.google.android.gms.p9.c.v(parcel, 15, hVar.A3(), false);
        deobf.com.google.android.gms.p9.c.b(parcel, a10);
    }

    @Override // android.os.Parcelable.Creator
    public final /* bridge */ /* synthetic */ Object createFromParcel(Parcel parcel) {
        int D = deobf.com.google.android.gms.p9.b.D(parcel);
        Scope[] scopeArr = h.f26961t;
        Bundle bundle = new Bundle();
        deobf.com.google.mlkit.vision.k9.d[] dVarArr = h.f26962u;
        deobf.com.google.mlkit.vision.k9.d[] dVarArr2 = dVarArr;
        String str = null;
        IBinder iBinder = null;
        Account account = null;
        String str2 = null;
        int i10 = 0;
        int i11 = 0;
        int i12 = 0;
        boolean z10 = false;
        int i13 = 0;
        boolean z11 = false;
        while (parcel.dataPosition() < D) {
            int u8 = deobf.com.google.android.gms.p9.b.u(parcel);
            switch (deobf.com.google.android.gms.p9.b.n(u8)) {
                case 1:
                    i10 = deobf.com.google.android.gms.p9.b.w(parcel, u8);
                    break;
                case 2:
                    i11 = deobf.com.google.android.gms.p9.b.w(parcel, u8);
                    break;
                case 3:
                    i12 = deobf.com.google.android.gms.p9.b.w(parcel, u8);
                    break;
                case 4:
                    str = deobf.com.google.android.gms.p9.b.h(parcel, u8);
                    break;
                case 5:
                    iBinder = deobf.com.google.android.gms.p9.b.v(parcel, u8);
                    break;
                case 6:
                    scopeArr = (Scope[]) deobf.com.google.android.gms.p9.b.k(parcel, u8, Scope.CREATOR);
                    break;
                case 7:
                    bundle = deobf.com.google.android.gms.p9.b.b(parcel, u8);
                    break;
                case 8:
                    account = (Account) deobf.com.google.android.gms.p9.b.g(parcel, u8, Account.CREATOR);
                    break;
                case 9:
                default:
                    deobf.com.google.android.gms.p9.b.C(parcel, u8);
                    break;
                case 10:
                    dVarArr = (deobf.com.google.mlkit.vision.k9.d[]) deobf.com.google.android.gms.p9.b.k(parcel, u8, deobf.com.google.mlkit.vision.k9.d.CREATOR);
                    break;
                case 11:
                    dVarArr2 = (deobf.com.google.mlkit.vision.k9.d[]) deobf.com.google.android.gms.p9.b.k(parcel, u8, deobf.com.google.mlkit.vision.k9.d.CREATOR);
                    break;
                case 12:
                    z10 = deobf.com.google.android.gms.p9.b.o(parcel, u8);
                    break;
                case 13:
                    i13 = deobf.com.google.android.gms.p9.b.w(parcel, u8);
                    break;
                case 14:
                    z11 = deobf.com.google.android.gms.p9.b.o(parcel, u8);
                    break;
                case 15:
                    str2 = deobf.com.google.android.gms.p9.b.h(parcel, u8);
                    break;
            }
        }
        deobf.com.google.android.gms.p9.b.m(parcel, D);
        return new h(i10, i11, i12, str, iBinder, scopeArr, bundle, account, dVarArr, dVarArr2, z10, i13, z11, str2);
    }

    @Override // android.os.Parcelable.Creator
    public final /* synthetic */ Object[] newArray(int i10) {
        return new h[i10];
    }
}
