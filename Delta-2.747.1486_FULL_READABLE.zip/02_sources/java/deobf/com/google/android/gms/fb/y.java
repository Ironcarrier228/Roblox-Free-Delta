package deobf.com.google.android.gms.fb;

import com.google.android.apps.common.proguard.SideEffectFree;
import java.util.Set;

// dex: classes.dex
public final class y {

    public final String f15893a;
    public final Set b;

    public final boolean f15894c;

    public y(String str, Set set, boolean z10, boolean z11, boolean z12, boolean z13, boolean z14) {
        this.f15893a = "com.google.android.gms.fido";
        this.b = set;
        this.f15894c = z13;
    }

    @SideEffectFree
    public final q a(String str, long j10) {
        final Class<Long> cls = Long.class;
        return new q(this.f15893a, str, Long.valueOf(j10), new l(false, false, false, this.f15894c, false, this.b, new x() { // from class: fb.v
        }, new x(cls) { // from class: fb.w
        }), true);
    }

    @SideEffectFree
    public final q b(String str, String str2) {
        final Class<String> cls = String.class;
        return new q(this.f15893a, str, str2, new l(false, false, false, this.f15894c, false, this.b, new x() { // from class: fb.t
        }, new x(cls) { // from class: fb.u
        }), true);
    }

    @SideEffectFree
    public final q c(String str, boolean z10) {
        Boolean valueOf = Boolean.valueOf(z10);
        final Class<Boolean> cls = Boolean.class;
        return new q(this.f15893a, str, valueOf, new l(false, false, false, this.f15894c, false, this.b, new x() { // from class: fb.r
        }, new x(cls) { // from class: fb.s
        }), true);
    }

    public final y d() {
        return new y(this.f15893a, this.b, false, false, false, true, false);
    }

    public final y e(Set set) {
        return new y(this.f15893a, set, false, false, false, this.f15894c, false);
    }

    public y(String str) {
        this("com.google.android.gms.fido", h1.l(), false, false, false, false, false);
    }
}
