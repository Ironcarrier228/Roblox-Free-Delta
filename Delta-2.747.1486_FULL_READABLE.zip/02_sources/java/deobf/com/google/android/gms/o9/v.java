package deobf.com.google.android.gms.o9;

import android.content.Context;
import android.content.res.Resources;
import androidx.annotation.NonNull;
import com.withpersona.sdk2.inquiry.network.dto.InquiryField;

// dex: classes.dex
public class v {

    public final Resources f27050a;
    public final String b;

    public v(@NonNull Context context) {
        s.l(context);
        Resources resources = context.getResources();
        this.f27050a = resources;
        this.b = resources.getResourcePackageName(deobf.com.google.mlkit.vision.k9.l.f21267a);
    }

    public String a(@NonNull String str) {
        String str2 = this.b;
        Resources resources = this.f27050a;
        int identifier = resources.getIdentifier(str, InquiryField.StringField.TYPE, str2);
        if (identifier == 0) {
            return null;
        }
        return resources.getString(identifier);
    }
}
