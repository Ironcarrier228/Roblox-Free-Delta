package deobf.com.google.android.gms.o9;

import android.accounts.Account;
import android.view.View;
import androidx.annotation.NonNull;
import com.google.android.gms.common.api.Scope;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

// dex: classes.dex
public final class f {

    public final Account f26936a;
    public final Set b;

    public final Set f26937c;

    public final Map f26938d;

    public final int f26939e;

    public final View f26940f;

    public final String f26941g;

    public final String f26942h;

    public final deobf.unlinked.qb.a f26943i;

    public Integer f26944j;

    public static final class a {

        public Account f26945a;
        public deobf.com.google.android.gms.w1.b b;

        public String f26946c;

        public String f26947d;

        public final deobf.unlinked.qb.a f26948e = deobf.unlinked.qb.a.f29947j;

        @NonNull
        public f a() {
            return new f(this.f26945a, this.b, null, 0, null, this.f26946c, this.f26947d, this.f26948e, false);
        }

        @NonNull
        public a b(@NonNull String str) {
            this.f26946c = str;
            return this;
        }

        @NonNull
        public final a c(@NonNull Collection collection) {
            if (this.b == null) {
                this.b = new deobf.com.google.android.gms.w1.b();
            }
            this.b.addAll(collection);
            return this;
        }

        @NonNull
        public final a d(Account account) {
            this.f26945a = account;
            return this;
        }

        @NonNull
        public final a e(@NonNull String str) {
            this.f26947d = str;
            return this;
        }
    }

    public f(Account account, @NonNull Set set, @NonNull Map map, int i10, View view, @NonNull String str, @NonNull String str2, deobf.unlinked.qb.a aVar, boolean z10) {
        this.f26936a = account;
        Set unmodifiableSet = set == null ? Collections.EMPTY_SET : Collections.unmodifiableSet(set);
        this.b = unmodifiableSet;
        map = map == null ? Collections.EMPTY_MAP : map;
        this.f26938d = map;
        this.f26940f = view;
        this.f26939e = i10;
        this.f26941g = str;
        this.f26942h = str2;
        this.f26943i = aVar == null ? deobf.unlinked.qb.a.f29947j : aVar;
        HashSet hashSet = new HashSet(unmodifiableSet);
        Iterator it = map.values().iterator();
        while (it.hasNext()) {
            hashSet.addAll(((e0) it.next()).f26935a);
        }
        this.f26937c = Collections.unmodifiableSet(hashSet);
    }

    public Account a() {
        return this.f26936a;
    }

    @Deprecated
    public String b() {
        Account account = this.f26936a;
        if (account != null) {
            return account.name;
        }
        return null;
    }

    @NonNull
    public Account c() {
        Account account = this.f26936a;
        return account != null ? account : new Account("<<default account>>", "com.google");
    }

    @NonNull
    public Set<Scope> d() {
        return this.f26937c;
    }

    @NonNull
    public Set<Scope> e(@NonNull deobf.com.google.android.gms.l9.a<?> aVar) {
        e0 e0Var = (e0) this.f26938d.get(aVar);
        if (e0Var == null || e0Var.f26935a.isEmpty()) {
            return this.b;
        }
        HashSet hashSet = new HashSet(this.b);
        hashSet.addAll(e0Var.f26935a);
        return hashSet;
    }

    public int f() {
        return this.f26939e;
    }

    @NonNull
    public String g() {
        return this.f26941g;
    }

    @NonNull
    public Set<Scope> h() {
        return this.b;
    }

    public View i() {
        return this.f26940f;
    }

    @NonNull
    public final deobf.unlinked.qb.a j() {
        return this.f26943i;
    }

    public final Integer k() {
        return this.f26944j;
    }

    public final String l() {
        return this.f26942h;
    }

    public final void m(@NonNull Integer num) {
        this.f26944j = num;
    }
}
