package deobf.com.google.android.gms.o9;

import android.content.Context;
import android.content.ServiceConnection;
import android.os.Handler;
import android.os.Looper;
import java.util.HashMap;
import java.util.concurrent.Executor;

// dex: classes.dex
public final class s1 extends j {

    public final HashMap f27028g = new HashMap();

    public final Context f27029h;

    public volatile Handler f27030i;

    public final r1 f27031j;

    public final deobf.unlinked.u9.a f27032k;

    public final long f27033l;

    public final long f27034m;

    public volatile Executor f27035n;

    public s1(Context context, Looper looper, Executor executor) {
        r1 r1Var = new r1(this, null);
        this.f27031j = r1Var;
        this.f27029h = context.getApplicationContext();
        this.f27030i = new deobf.com.google.android.gms.eb.p(looper, r1Var);
        this.f27032k = deobf.unlinked.u9.a.b();
        this.f27033l = 5000L;
        this.f27034m = 300000L;
        this.f27035n = executor;
    }

    @Override // deobf.com.google.android.gms.o9.j
    public final deobf.com.google.mlkit.vision.k9.b c(p1 p1Var, ServiceConnection serviceConnection, String str, Executor executor) {
        deobf.com.google.mlkit.vision.k9.b bVar;
        s.m(serviceConnection, "ServiceConnection must not be null");
        HashMap hashMap = this.f27028g;
        synchronized (hashMap) {
            try {
                q1 q1Var = (q1) hashMap.get(p1Var);
                if (executor == null) {
                    executor = this.f27035n;
                }
                if (q1Var == null) {
                    q1Var = new q1(this, p1Var);
                    q1Var.b(serviceConnection, serviceConnection, str);
                    bVar = q1Var.j(str, executor);
                    hashMap.put(p1Var, q1Var);
                } else {
                    this.f27030i.removeMessages(0, p1Var);
                    if (q1Var.f(serviceConnection)) {
                        String obj = p1Var.toString();
                        StringBuilder sb2 = new StringBuilder(obj.length() + 81);
                        sb2.append("Trying to bind a GmsServiceConnection that was already connected before.  config=");
                        sb2.append(obj);
                        throw new IllegalStateException(sb2.toString());
                    }
                    q1Var.b(serviceConnection, serviceConnection, str);
                    int e10 = q1Var.e();
                    if (e10 == 1) {
                        serviceConnection.onServiceConnected(q1Var.i(), q1Var.h());
                    } else if (e10 == 2) {
                        bVar = q1Var.j(str, executor);
                    }
                    bVar = null;
                }
                if (q1Var.d()) {
                    return deobf.com.google.mlkit.vision.k9.b.f21213k;
                }
                if (bVar == null) {
                    bVar = new deobf.com.google.mlkit.vision.k9.b(-1);
                }
                return bVar;
            } catch (Throwable th2) {
                throw th2;
            }
        }
    }

    @Override // deobf.com.google.android.gms.o9.j
    public final void e(p1 p1Var, ServiceConnection serviceConnection, String str) {
        s.m(serviceConnection, "ServiceConnection must not be null");
        HashMap hashMap = this.f27028g;
        synchronized (hashMap) {
            try {
                q1 q1Var = (q1) hashMap.get(p1Var);
                if (q1Var == null) {
                    String obj = p1Var.toString();
                    StringBuilder sb2 = new StringBuilder(obj.length() + 50);
                    sb2.append("Nonexistent connection status for service config: ");
                    sb2.append(obj);
                    throw new IllegalStateException(sb2.toString());
                }
                if (!q1Var.f(serviceConnection)) {
                    String obj2 = p1Var.toString();
                    StringBuilder sb3 = new StringBuilder(obj2.length() + 76);
                    sb3.append("Trying to unbind a GmsServiceConnection  that was not bound before.  config=");
                    sb3.append(obj2);
                    throw new IllegalStateException(sb3.toString());
                }
                q1Var.c(serviceConnection, str);
                if (q1Var.g()) {
                    this.f27030i.sendMessageDelayed(this.f27030i.obtainMessage(0, p1Var), this.f27033l);
                }
            } catch (Throwable th2) {
                throw th2;
            }
        }
    }

    public final /* synthetic */ HashMap f() {
        return this.f27028g;
    }

    public final /* synthetic */ Context g() {
        return this.f27029h;
    }

    public final /* synthetic */ Handler h() {
        return this.f27030i;
    }

    public final /* synthetic */ deobf.unlinked.u9.a i() {
        return this.f27032k;
    }

    public final /* synthetic */ long j() {
        return this.f27034m;
    }
}
