package deobf.com.google.android.gms.o9;

import androidx.annotation.NonNull;
import deobf.com.google.android.gms.o9.d;

// dex: classes.dex
public final class k0 implements d.b {

    public final /* synthetic */ deobf.com.google.android.gms.m9.n f26991a;

    public k0(deobf.com.google.android.gms.m9.n nVar) {
        this.f26991a = nVar;
    }

    @Override // deobf.com.google.android.gms.o9.d.b
    public final void onConnectionFailed(@NonNull deobf.com.google.mlkit.vision.k9.b bVar) {
        this.f26991a.onConnectionFailed(bVar);
    }
}
