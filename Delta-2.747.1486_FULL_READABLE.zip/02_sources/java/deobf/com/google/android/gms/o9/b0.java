package deobf.com.google.android.gms.o9;

import android.os.Parcel;
import android.os.Parcelable;
import java.util.ArrayList;

// dex: classes.dex
public final class b0 implements Parcelable.Creator {
    @Override // android.os.Parcelable.Creator
    public final /* bridge */ /* synthetic */ Object createFromParcel(Parcel parcel) {
        int D = deobf.com.google.android.gms.p9.b.D(parcel);
        ArrayList arrayList = null;
        int i10 = 0;
        while (parcel.dataPosition() < D) {
            int u8 = deobf.com.google.android.gms.p9.b.u(parcel);
            int n10 = deobf.com.google.android.gms.p9.b.n(u8);
            if (n10 == 1) {
                i10 = deobf.com.google.android.gms.p9.b.w(parcel, u8);
            } else if (n10 != 2) {
                deobf.com.google.android.gms.p9.b.C(parcel, u8);
            } else {
                arrayList = deobf.com.google.android.gms.p9.b.l(parcel, u8, p.CREATOR);
            }
        }
        deobf.com.google.android.gms.p9.b.m(parcel, D);
        return new w(i10, arrayList);
    }

    @Override // android.os.Parcelable.Creator
    public final /* synthetic */ Object[] newArray(int i10) {
        return new w[i10];
    }
}
