package deobf.com.google.android.gms.fb;

import java.util.List;

// dex: classes.dex
public final class d1 extends e1 {

    public final transient int f15725c;

    public final transient int f15726d;

    public final /* synthetic */ e1 f15727e;

    public d1(e1 e1Var, int i10, int i11) {
        this.f15727e = e1Var;
        this.f15725c = i10;
        this.f15726d = i11;
    }

    @Override // deobf.com.google.android.gms.fb.z0
    public final int b() {
        return this.f15727e.c() + this.f15725c + this.f15726d;
    }

    @Override // deobf.com.google.android.gms.fb.z0
    public final int c() {
        return this.f15727e.c() + this.f15725c;
    }

    @Override // deobf.com.google.android.gms.fb.z0
    public final Object[] e() {
        return this.f15727e.e();
    }

    @Override // deobf.com.google.android.gms.fb.e1
    public final e1 subList(int i10, int i11) {
        deobf.androidx.camera.camera2.internal.compat.quirk.n0.e(i10, i11, this.f15726d);
        int i12 = this.f15725c;
        return this.f15727e.subList(i10 + i12, i11 + i12);
    }

    @Override // java.util.List
    public final Object get(int i10) {
        n0.a(i10, this.f15726d, "index");
        return this.f15727e.get(i10 + this.f15725c);
    }

    @Override // java.util.AbstractCollection, java.util.Collection, java.util.List
    public final int size() {
        return this.f15726d;
    }

    @Override // deobf.com.google.android.gms.fb.e1, java.util.List
    public final /* bridge */ /* synthetic */ List subList(int i10, int i11) {
        return subList(i10, i11);
    }
}
