package deobf.com.google.android.gms.o9;

import android.os.Bundle;
import android.os.IBinder;
import android.os.IInterface;
import android.os.RemoteException;
import android.util.Log;
import java.util.Objects;
import deobf.com.google.android.gms.o9.d;

// dex: classes.dex
public final class i1 extends v0 {

    public final IBinder f26981g;

    public final /* synthetic */ d f26982h;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public i1(d dVar, int i10, IBinder iBinder, Bundle bundle) {
        super(dVar, i10, bundle);
        Objects.requireNonNull(dVar);
        this.f26982h = dVar;
        this.f26981g = iBinder;
    }

    @Override // deobf.com.google.android.gms.o9.v0
    public final boolean e() {
        try {
            IBinder iBinder = this.f26981g;
            s.l(iBinder);
            String interfaceDescriptor = iBinder.getInterfaceDescriptor();
            d dVar = this.f26982h;
            if (!dVar.getServiceDescriptor().equals(interfaceDescriptor)) {
                String serviceDescriptor = dVar.getServiceDescriptor();
                StringBuilder sb2 = new StringBuilder(String.valueOf(serviceDescriptor).length() + 34 + String.valueOf(interfaceDescriptor).length());
                sb2.append("service descriptor mismatch: ");
                sb2.append(serviceDescriptor);
                sb2.append(" vs. ");
                sb2.append(interfaceDescriptor);
                Log.w("GmsClient", sb2.toString());
                return false;
            }
            IInterface createServiceInterface = dVar.createServiceInterface(this.f26981g);
            if (createServiceInterface == null || !(dVar.zze(2, 4, createServiceInterface) || dVar.zze(3, 4, createServiceInterface))) {
                return false;
            }
            dVar.zzn(null);
            deobf.com.roblox.client.pushnotification.d.a zzk = dVar.zzk();
            Bundle connectionHint = dVar.getConnectionHint();
            if (zzk == null) {
                return true;
            }
            dVar.zzk().onConnected(connectionHint);
            return true;
        } catch (RemoteException unused) {
            Log.w("GmsClient", "service probably died");
            return false;
        }
    }

    @Override // deobf.com.google.android.gms.o9.v0
    public final void f(deobf.com.google.mlkit.vision.k9.b bVar) {
        d dVar = this.f26982h;
        if (dVar.zzl() != null) {
            dVar.zzl().onConnectionFailed(bVar);
        }
        dVar.onConnectionFailed(bVar);
    }
}
