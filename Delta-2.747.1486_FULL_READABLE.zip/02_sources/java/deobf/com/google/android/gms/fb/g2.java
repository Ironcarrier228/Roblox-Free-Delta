package deobf.com.google.android.gms.fb;

// dex: classes.dex
public abstract class g2 implements k2 {
}
