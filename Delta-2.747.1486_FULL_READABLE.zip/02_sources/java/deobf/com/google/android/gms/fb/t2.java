package deobf.com.google.android.gms.fb;

import java.math.RoundingMode;
import java.util.Objects;

// dex: classes.dex
public class t2 extends u2 {

    public final q2 f15868f;

    public final Character f15869g;

    public volatile u2 f15870h;

    public t2(q2 q2Var, Character ch2) {
        this.f15868f = q2Var;
        if (ch2 != null && q2Var.c('=')) {
            throw new IllegalArgumentException(deobf.androidx.camera.view.p0.a("Padding character %s was already in alphabet", ch2));
        }
        this.f15869g = ch2;
    }

    @Override // deobf.com.google.android.gms.fb.u2
    public void a(Appendable appendable, byte[] bArr, int i10, int i11) {
        int i12 = 0;
        deobf.androidx.camera.camera2.internal.compat.quirk.n0.e(0, i11, bArr.length);
        while (i12 < i11) {
            g(appendable, bArr, i12, Math.min(this.f15868f.f15832f, i11 - i12));
            i12 += this.f15868f.f15832f;
        }
    }

    @Override // deobf.com.google.android.gms.fb.u2
    public final int b(int i10) {
        q2 q2Var = this.f15868f;
        return q2Var.f15831e * deobf.androidx.appcompat.widget.w2.a(i10, q2Var.f15832f, RoundingMode.CEILING);
    }

    @Override // deobf.com.google.android.gms.fb.u2
    public final u2 c() {
        u2 u2Var = this.f15870h;
        if (u2Var == null) {
            q2 q2Var = this.f15868f;
            q2 b = q2Var.b();
            u2Var = b == q2Var ? this : f(b, this.f15869g);
            this.f15870h = u2Var;
        }
        return u2Var;
    }

    public final boolean equals(Object obj) {
        if (obj instanceof t2) {
            t2 t2Var = (t2) obj;
            if (this.f15868f.equals(t2Var.f15868f) && Objects.equals(this.f15869g, t2Var.f15869g)) {
                return true;
            }
        }
        return false;
    }

    public u2 f(q2 q2Var, Character ch2) {
        return new t2(q2Var, ch2);
    }

    public final void g(Appendable appendable, byte[] bArr, int i10, int i11) {
        deobf.androidx.camera.camera2.internal.compat.quirk.n0.e(i10, i10 + i11, bArr.length);
        int i12 = 0;
        deobf.androidx.camera.camera2.internal.compat.quirk.n0.c(i11 <= this.f15868f.f15832f);
        long j10 = 0;
        for (int i13 = 0; i13 < i11; i13++) {
            j10 = (j10 | (bArr[i10 + i13] & 255)) << 8;
        }
        int i14 = (i11 + 1) * 8;
        q2 q2Var = this.f15868f;
        while (i12 < i11 * 8) {
            long j11 = j10 >>> ((i14 - q2Var.f15830d) - i12);
            q2 q2Var2 = this.f15868f;
            appendable.append(q2Var2.a(((int) j11) & q2Var2.f15829c));
            i12 += this.f15868f.f15830d;
        }
        if (this.f15869g != null) {
            while (i12 < this.f15868f.f15832f * 8) {
                this.f15869g.getClass();
                appendable.append('=');
                i12 += this.f15868f.f15830d;
            }
        }
    }

    public final int hashCode() {
        Character ch2 = this.f15869g;
        return Objects.hashCode(ch2) ^ this.f15868f.hashCode();
    }

    public final String toString() {
        StringBuilder sb2 = new StringBuilder("BaseEncoding.");
        sb2.append(this.f15868f);
        if (8 % this.f15868f.f15830d != 0) {
            if (this.f15869g == null) {
                sb2.append(".omitPadding()");
            } else {
                sb2.append(".withPadChar('");
                sb2.append(this.f15869g);
                sb2.append("')");
            }
        }
        return sb2.toString();
    }

    public t2(String str, String str2, Character ch2) {
        this(new q2(str, str2.toCharArray()), ch2);
    }
}
