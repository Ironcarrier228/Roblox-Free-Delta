package deobf.com.google.android.gms.fb;

// dex: classes.dex
public final class k0 {
    public static j0 a(Object obj) {
        return new j0(obj.getClass().getSimpleName(), null);
    }
}
