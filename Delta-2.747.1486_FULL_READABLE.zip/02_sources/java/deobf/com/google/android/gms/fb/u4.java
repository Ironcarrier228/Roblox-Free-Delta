package deobf.com.google.android.gms.fb;

import android.app.PendingIntent;
import android.os.Parcel;
import com.google.android.gms.common.api.Status;

// dex: classes.dex
public abstract class u4 extends a0 implements v4 {
    public u4() {
        super("com.google.android.gms.fido.fido2.internal.regular.IFido2AppCallbacks");
    }

    @Override // deobf.com.google.android.gms.fb.a0
    public final boolean r2(int i10, Parcel parcel, Parcel parcel2, int i11) {
        if (i10 != 1) {
            return false;
        }
        Status status = (Status) deobf.androidx.camera.camera2.internal.compat.quirk.b1.a(parcel, Status.CREATOR);
        PendingIntent pendingIntent = (PendingIntent) deobf.androidx.camera.camera2.internal.compat.quirk.b1.a(parcel, PendingIntent.CREATOR);
        b1.b(parcel);
        E0(status, pendingIntent);
        return true;
    }
}
