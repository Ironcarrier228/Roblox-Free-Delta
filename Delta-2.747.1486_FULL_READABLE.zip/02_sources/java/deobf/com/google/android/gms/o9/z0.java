package deobf.com.google.android.gms.o9;

import android.os.IInterface;

// dex: classes.dex
public interface z0 extends IInterface {
    deobf.com.google.mlkit.vision.k9.h0 N1(deobf.com.google.mlkit.vision.k9.f0 f0Var);

    boolean Q1(deobf.com.google.mlkit.vision.k9.j0 j0Var, deobf.com.google.android.gms.z9.a aVar);

    boolean c();

    deobf.com.google.mlkit.vision.k9.h0 l2(deobf.com.google.mlkit.vision.k9.f0 f0Var);
}
