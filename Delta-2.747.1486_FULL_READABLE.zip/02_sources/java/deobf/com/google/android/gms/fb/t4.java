package deobf.com.google.android.gms.fb;

import android.content.Context;
import android.os.Bundle;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Looper;
import androidx.annotation.NonNull;
import deobf.com.google.android.gms.l9.h;

// dex: classes.dex
public final class t4 extends deobf.com.google.android.gms.o9.i {
    public t4(Context context, Looper looper, deobf.com.google.android.gms.o9.f fVar, deobf.com.roblox.protocols.mediapicker.h.a aVar, deobf.com.roblox.protocols.mediapicker.h.b bVar) {
        super(context, looper, 148, fVar, aVar, bVar);
    }

    @Override // deobf.com.google.android.gms.o9.d
    public final /* synthetic */ IInterface createServiceInterface(IBinder iBinder) {
        if (iBinder == null) {
            return null;
        }
        IInterface queryLocalInterface = iBinder.queryLocalInterface("com.google.android.gms.fido.fido2.internal.regular.IFido2AppService");
        return queryLocalInterface instanceof w4 ? (w4) queryLocalInterface : new w4(iBinder);
    }

    @Override // deobf.com.google.android.gms.o9.d
    public final deobf.com.google.mlkit.vision.k9.d[] getApiFeatures() {
        return new deobf.com.google.mlkit.vision.k9.d[]{deobf.unlinked.ba.b.f3807h, deobf.unlinked.ba.b.f3806g};
    }

    @Override // deobf.com.google.android.gms.o9.d
    public final Bundle getGetServiceRequestExtraArgs() {
        Bundle bundle = new Bundle();
        bundle.putString("FIDO2_ACTION_START_SERVICE", "com.google.android.gms.fido.fido2.regular.START");
        return bundle;
    }

    @Override // deobf.com.google.android.gms.o9.d, deobf.com.google.android.gms.l9.a.f
    public final int getMinApkVersion() {
        return 13000000;
    }

    @Override // deobf.com.google.android.gms.o9.d
    @NonNull
    public final String getServiceDescriptor() {
        return "com.google.android.gms.fido.fido2.internal.regular.IFido2AppService";
    }

    @Override // deobf.com.google.android.gms.o9.d
    @NonNull
    public final String getStartServiceAction() {
        return "com.google.android.gms.fido.fido2.regular.START";
    }

    @Override // deobf.com.google.android.gms.o9.d
    public final boolean usesClientTelemetry() {
        return true;
    }
}
