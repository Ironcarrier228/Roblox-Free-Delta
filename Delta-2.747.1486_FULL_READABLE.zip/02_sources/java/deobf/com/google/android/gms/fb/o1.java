package deobf.com.google.android.gms.fb;

import java.util.Map;

// dex: classes.dex
public final class o1 {
    public static Object a(Map.Entry entry) {
        if (entry == null) {
            return null;
        }
        return entry.getKey();
    }
}
