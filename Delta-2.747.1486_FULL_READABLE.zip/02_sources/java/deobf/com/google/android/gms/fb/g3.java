package deobf.com.google.android.gms.fb;

// dex: classes.dex
public final class g3 extends j3 {

    public final int f15736f;

    public final int f15737g;

    public g3(byte[] bArr, int i10, int i11) {
        super(bArr);
        m3.j(i10, i10 + i11, bArr.length);
        this.f15736f = i10;
        this.f15737g = i11;
    }

    @Override // deobf.com.google.android.gms.fb.j3, deobf.com.google.android.gms.fb.m3
    public final byte b(int i10) {
        int i11 = this.f15737g;
        if (((i11 - (i10 + 1)) | i10) >= 0) {
            return this.f15753e[this.f15736f + i10];
        }
        if (i10 < 0) {
            throw new ArrayIndexOutOfBoundsException("Index < 0: " + i10);
        }
        throw new ArrayIndexOutOfBoundsException("Index > length: " + i10 + ", " + i11);
    }

    @Override // deobf.com.google.android.gms.fb.j3, deobf.com.google.android.gms.fb.m3
    public final byte c(int i10) {
        return this.f15753e[this.f15736f + i10];
    }

    @Override // deobf.com.google.android.gms.fb.j3, deobf.com.google.android.gms.fb.m3
    public final int d() {
        return this.f15737g;
    }

    @Override // deobf.com.google.android.gms.fb.j3, deobf.com.google.android.gms.fb.m3
    public final void e(byte[] bArr, int i10, int i11, int i12) {
        System.arraycopy(this.f15753e, this.f15736f, bArr, 0, i12);
    }

    @Override // deobf.com.google.android.gms.fb.j3
    public final int q() {
        return this.f15736f;
    }
}
