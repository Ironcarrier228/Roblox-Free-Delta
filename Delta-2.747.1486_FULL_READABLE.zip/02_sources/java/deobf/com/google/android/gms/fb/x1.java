package deobf.com.google.android.gms.fb;

import java.io.Serializable;

// dex: classes.dex
public final class x1 extends s1 implements Serializable {

    public final s1 f15891a;

    public x1(s1 s1Var) {
        this.f15891a = s1Var;
    }

    @Override // deobf.com.google.android.gms.fb.s1
    public final s1 a() {
        return this.f15891a;
    }

    @Override // deobf.com.google.android.gms.fb.s1, java.util.Comparator
    public final int compare(Object obj, Object obj2) {
        return this.f15891a.compare(obj2, obj);
    }

    @Override // java.util.Comparator
    public final boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (obj instanceof x1) {
            return this.f15891a.equals(((x1) obj).f15891a);
        }
        return false;
    }

    public final int hashCode() {
        return -this.f15891a.hashCode();
    }

    public final String toString() {
        return this.f15891a.toString().concat(".reverse()");
    }
}
