package deobf.com.google.android.gms.fb;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;

// dex: classes.dex
public abstract class e2 extends g2 {

    public final ByteBuffer f15732a = ByteBuffer.allocate(8).order(ByteOrder.LITTLE_ENDIAN);

    @Override // deobf.com.google.android.gms.fb.k2
    public final k2 a(byte[] bArr) {
        bArr.getClass();
        b(bArr, 0, bArr.length);
        return this;
    }

    public abstract void b(byte[] bArr, int i10, int i11);
}
