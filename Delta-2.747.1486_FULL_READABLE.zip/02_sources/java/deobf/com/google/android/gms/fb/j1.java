package deobf.com.google.android.gms.fb;

import java.util.AbstractMap;

// dex: classes.dex
public final class j1 extends e1 {

    public final /* synthetic */ k1 f15752c;

    public j1(k1 k1Var) {
        this.f15752c = k1Var;
    }

    @Override // java.util.List
    public final /* bridge */ /* synthetic */ Object get(int i10) {
        v1 v1Var;
        e1 e1Var;
        v1Var = this.f15752c.f15755c.f15760c;
        Object obj = v1Var.f15885e.get(i10);
        e1Var = this.f15752c.f15755c.f15761d;
        return new AbstractMap.SimpleImmutableEntry(obj, e1Var.get(i10));
    }

    @Override // java.util.AbstractCollection, java.util.Collection, java.util.List
    public final int size() {
        return this.f15752c.f15755c.size();
    }
}
