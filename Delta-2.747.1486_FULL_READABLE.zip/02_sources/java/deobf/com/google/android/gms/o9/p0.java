package deobf.com.google.android.gms.o9;

import deobf.com.google.android.gms.o9.r;

// dex: classes.dex
public final class p0 implements r.a {
    @Override // deobf.com.google.android.gms.o9.r.a
    public final /* bridge */ /* synthetic */ Object a(deobf.com.google.android.gms.l9.p pVar) {
        return null;
    }
}
