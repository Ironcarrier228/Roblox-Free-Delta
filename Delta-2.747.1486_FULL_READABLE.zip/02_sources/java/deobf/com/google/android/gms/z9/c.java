package deobf.com.google.android.gms.z9;

import android.os.IBinder;

// dex: classes.dex
public final class c extends deobf.com.google.android.gms.eb.a implements a {
    public c(IBinder iBinder) {
        super(iBinder, "com.google.android.gms.dynamic.IObjectWrapper");
    }
}
