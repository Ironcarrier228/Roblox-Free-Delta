package deobf.com.google.android.gms.fb;

// dex: classes.dex
public final class u0 {
    public static q0 a(q0 q0Var) {
        return new s0(q0Var);
    }

    public static q0 b(Object obj) {
        return new t0(obj);
    }
}
