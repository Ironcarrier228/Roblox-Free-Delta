package deobf.com.google.android.gms.fb;

import java.io.Serializable;

// dex: classes.dex
public abstract class m0 implements Serializable {
    public static m0 c() {
        return z.f15895a;
    }

    public static m0 d(Object obj) {
        return new o0(obj);
    }

    public abstract Object a();

    public abstract boolean b();
}
