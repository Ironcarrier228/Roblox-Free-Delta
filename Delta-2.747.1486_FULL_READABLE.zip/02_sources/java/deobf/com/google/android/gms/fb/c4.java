package deobf.com.google.android.gms.fb;

import java.util.Arrays;

// dex: classes.dex
public final class c4 extends e4 {

    public final String f15724a;

    public c4(String str) {
        this.f15724a = str;
    }

    @Override // java.lang.Comparable
    public final /* bridge */ /* synthetic */ int compareTo(Object obj) {
        int length;
        int length2;
        e4 e4Var = (e4) obj;
        if (deobf.androidx.fragment.app.e4.c((byte) 96) != e4Var.zza()) {
            length = e4Var.zza();
            length2 = deobf.androidx.fragment.app.e4.c((byte) 96);
        } else {
            String str = this.f15724a;
            String str2 = ((c4) e4Var).f15724a;
            if (str.length() == str2.length()) {
                return str.compareTo(str2);
            }
            length = str2.length();
            length2 = str.length();
        }
        return length2 - length;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj != null && c4.class == obj.getClass()) {
            return this.f15724a.equals(((c4) obj).f15724a);
        }
        return false;
    }

    public final int hashCode() {
        return Arrays.hashCode(new Object[]{Integer.valueOf(deobf.androidx.fragment.app.e4.c((byte) 96)), this.f15724a});
    }

    public final String toString() {
        return "\"" + this.f15724a + "\"";
    }

    @Override // deobf.com.google.android.gms.fb.e4
    public final int zza() {
        return deobf.androidx.fragment.app.e4.c((byte) 96);
    }
}
