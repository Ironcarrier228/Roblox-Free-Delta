package deobf.com.google.android.gms.fb;

// dex: classes.dex
public class r3 {

    public static final /* synthetic */ int f15838a = 0;

    public /* synthetic */ r3(q3 q3Var) {
    }
}
