package deobf.com.google.android.gms.fb;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.nio.charset.Charset;

// dex: classes.dex
public class j3 extends i3 {

    public final byte[] f15753e;

    public j3(byte[] bArr) {
        bArr.getClass();
        this.f15753e = bArr;
    }

    @Override // deobf.com.google.android.gms.fb.m3
    public byte b(int i10) {
        return this.f15753e[i10];
    }

    @Override // deobf.com.google.android.gms.fb.m3
    public byte c(int i10) {
        return this.f15753e[i10];
    }

    @Override // deobf.com.google.android.gms.fb.m3
    public int d() {
        return this.f15753e.length;
    }

    @Override // deobf.com.google.android.gms.fb.m3
    public void e(byte[] bArr, int i10, int i11, int i12) {
        System.arraycopy(this.f15753e, 0, bArr, 0, i12);
    }

    @Override // deobf.com.google.android.gms.fb.m3
    public final boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof m3) || d() != ((m3) obj).d()) {
            return false;
        }
        if (d() == 0) {
            return true;
        }
        if (!(obj instanceof j3)) {
            return obj.equals(this);
        }
        j3 j3Var = (j3) obj;
        int l10 = l();
        int l11 = j3Var.l();
        if (l10 != 0 && l11 != 0 && l10 != l11) {
            return false;
        }
        int d10 = d();
        if (d10 > j3Var.d()) {
            throw new IllegalArgumentException("Length too large: " + d10 + d());
        }
        if (d10 > j3Var.d()) {
            throw new IllegalArgumentException("Ran off end of other: 0, " + d10 + ", " + j3Var.d());
        }
        byte[] bArr = this.f15753e;
        byte[] bArr2 = j3Var.f15753e;
        int q8 = q() + d10;
        int q10 = q();
        int q11 = j3Var.q();
        while (q10 < q8) {
            if (bArr[q10] != bArr2[q11]) {
                return false;
            }
            q10++;
            q11++;
        }
        return true;
    }

    @Override // deobf.com.google.android.gms.fb.m3
    public final int f(int i10, int i11, int i12) {
        int q8 = q();
        Charset charset = s3.f15858a;
        for (int i13 = q8; i13 < q8 + i12; i13++) {
            i10 = (i10 * 31) + this.f15753e[i13];
        }
        return i10;
    }

    @Override // deobf.com.google.android.gms.fb.m3
    public final m3 g(int i10, int i11) {
        int j10 = m3.j(i10, i11, d());
        return j10 == 0 ? m3.b : new g3(this.f15753e, q() + i10, j10);
    }

    @Override // deobf.com.google.android.gms.fb.m3
    public final InputStream h() {
        return new ByteArrayInputStream(this.f15753e, q(), d());
    }

    @Override // deobf.com.google.android.gms.fb.m3
    public final ByteBuffer i() {
        return ByteBuffer.wrap(this.f15753e, q(), d()).asReadOnlyBuffer();
    }

    public int q() {
        return 0;
    }
}
