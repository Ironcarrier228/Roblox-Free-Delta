package deobf.com.google.android.gms.o9;

import android.os.Parcel;
import android.os.Parcelable;

// dex: classes.dex
public final class n1 implements Parcelable.Creator {
    @Override // android.os.Parcelable.Creator
    public final /* bridge */ /* synthetic */ Object createFromParcel(Parcel parcel) {
        int D = deobf.com.google.android.gms.p9.b.D(parcel);
        u uVar = null;
        int[] iArr = null;
        int[] iArr2 = null;
        boolean z10 = false;
        boolean z11 = false;
        int i10 = 0;
        while (parcel.dataPosition() < D) {
            int u8 = deobf.com.google.android.gms.p9.b.u(parcel);
            switch (deobf.com.google.android.gms.p9.b.n(u8)) {
                case 1:
                    uVar = (u) deobf.com.google.android.gms.p9.b.g(parcel, u8, u.CREATOR);
                    break;
                case 2:
                    z10 = deobf.com.google.android.gms.p9.b.o(parcel, u8);
                    break;
                case 3:
                    z11 = deobf.com.google.android.gms.p9.b.o(parcel, u8);
                    break;
                case 4:
                    iArr = deobf.com.google.android.gms.p9.b.e(parcel, u8);
                    break;
                case 5:
                    i10 = deobf.com.google.android.gms.p9.b.w(parcel, u8);
                    break;
                case 6:
                    iArr2 = deobf.com.google.android.gms.p9.b.e(parcel, u8);
                    break;
                default:
                    deobf.com.google.android.gms.p9.b.C(parcel, u8);
                    break;
            }
        }
        deobf.com.google.android.gms.p9.b.m(parcel, D);
        return new g(uVar, z10, z11, iArr, i10, iArr2);
    }

    @Override // android.os.Parcelable.Creator
    public final /* synthetic */ Object[] newArray(int i10) {
        return new g[i10];
    }
}
