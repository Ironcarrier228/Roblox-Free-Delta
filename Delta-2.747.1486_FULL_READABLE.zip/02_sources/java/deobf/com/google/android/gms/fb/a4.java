package deobf.com.google.android.gms.fb;

// dex: classes.dex
public final class a4 {

    public final e4 f15719a;
    public final e4 b;

    public a4(e4 e4Var, e4 e4Var2) {
        this.f15719a = e4Var;
        this.b = e4Var2;
    }

    public final e4 a() {
        return this.f15719a;
    }

    public final e4 b() {
        return this.b;
    }
}
