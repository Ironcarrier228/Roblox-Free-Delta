package deobf.com.google.android.gms.fb;

import java.util.Arrays;

// dex: classes.dex
public final class w3 extends e4 {

    public final boolean f15889a;

    public w3(boolean z10) {
        this.f15889a = z10;
    }

    @Override // java.lang.Comparable
    public final /* bridge */ /* synthetic */ int compareTo(Object obj) {
        e4 e4Var = (e4) obj;
        if (deobf.androidx.fragment.app.e4.c((byte) -32) != e4Var.zza()) {
            return deobf.androidx.fragment.app.e4.c((byte) -32) - e4Var.zza();
        }
        return (true != this.f15889a ? 20 : 21) - (true != ((w3) e4Var).f15889a ? 20 : 21);
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        return obj != null && w3.class == obj.getClass() && this.f15889a == ((w3) obj).f15889a;
    }

    public final int hashCode() {
        return Arrays.hashCode(new Object[]{Integer.valueOf(deobf.androidx.fragment.app.e4.c((byte) -32)), Boolean.valueOf(this.f15889a)});
    }

    public final String toString() {
        return Boolean.toString(this.f15889a);
    }

    @Override // deobf.com.google.android.gms.fb.e4
    public final int zza() {
        return deobf.androidx.fragment.app.e4.c((byte) -32);
    }
}
