package deobf.com.google.android.gms.o9;

import android.os.IBinder;
import android.os.Parcel;

// dex: classes.dex
public final class w0 implements n {

    public final IBinder f27056a;

    public w0(IBinder iBinder) {
        this.f27056a = iBinder;
    }

    @Override // android.os.IInterface
    public final IBinder asBinder() {
        return this.f27056a;
    }

    @Override // deobf.com.google.android.gms.o9.n
    public final void h1(m mVar, h hVar) {
        Parcel obtain = Parcel.obtain();
        Parcel obtain2 = Parcel.obtain();
        try {
            obtain.writeInterfaceToken("com.google.android.gms.common.internal.IGmsServiceBroker");
            obtain.writeStrongBinder(mVar != null ? mVar.asBinder() : null);
            if (hVar != null) {
                obtain.writeInt(1);
                deobf.unlinked.o1.a(hVar, obtain, 0);
            } else {
                obtain.writeInt(0);
            }
            this.f27056a.transact(46, obtain, obtain2, 0);
            obtain2.readException();
            obtain2.recycle();
            obtain.recycle();
        } catch (Throwable th2) {
            obtain2.recycle();
            obtain.recycle();
            throw th2;
        }
    }
}
