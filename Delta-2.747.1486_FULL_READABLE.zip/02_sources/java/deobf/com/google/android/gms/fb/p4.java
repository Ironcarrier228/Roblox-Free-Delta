package deobf.com.google.android.gms.fb;

// dex: classes.dex
public final class p4 implements q0 {
    public static final p4 b = new p4();

    public final q0 f15821a = deobf.unlinked.u0.b(new r4());

    public static boolean b() {
        return b.a().zza();
    }

    public final q4 a() {
        return (q4) this.f15821a.zza();
    }

    @Override // deobf.com.google.android.gms.fb.q0
    public final /* bridge */ /* synthetic */ Object zza() {
        throw null;
    }
}
