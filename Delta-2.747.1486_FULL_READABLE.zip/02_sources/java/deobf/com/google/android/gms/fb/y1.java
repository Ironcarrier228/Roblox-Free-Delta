package deobf.com.google.android.gms.fb;

import java.util.Iterator;
import java.util.Set;

// dex: classes.dex
public final class y1 {
    public static int a(Set set) {
        Iterator it = set.iterator();
        int i10 = 0;
        while (it.hasNext()) {
            Object next = it.next();
            i10 += next != null ? next.hashCode() : 0;
        }
        return i10;
    }
}
