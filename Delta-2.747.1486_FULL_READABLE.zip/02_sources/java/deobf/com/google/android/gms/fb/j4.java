package deobf.com.google.android.gms.fb;

// dex: classes.dex
public final class j4 implements q0 {
    public static final j4 b = new j4();

    public final q0 f15754a = deobf.unlinked.u0.b(new l4());

    public static boolean a() {
        return ((k4) b.f15754a.zza()).zza();
    }

    @Override // deobf.com.google.android.gms.fb.q0
    public final /* bridge */ /* synthetic */ Object zza() {
        throw null;
    }
}
