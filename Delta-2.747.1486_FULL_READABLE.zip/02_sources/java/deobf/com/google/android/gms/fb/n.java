package deobf.com.google.android.gms.fb;

import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;

// dex: classes.dex
public final class n {

    public final ConcurrentMap f15777a = new ConcurrentHashMap();

    public /* synthetic */ n(m mVar) {
    }
}
