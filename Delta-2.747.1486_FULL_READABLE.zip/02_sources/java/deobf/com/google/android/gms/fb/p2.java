package deobf.com.google.android.gms.fb;

import java.io.Serializable;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

// dex: classes.dex
public final class p2 extends f2 implements Serializable {

    public final MessageDigest f15793a;
    public final int b;

    public final boolean f15794c;

    public final String f15795d;

    public p2(String str, String str2) {
        MessageDigest a10 = a("SHA-256");
        this.f15793a = a10;
        this.b = a10.getDigestLength();
        this.f15795d = "Hashing.sha256()";
        this.f15794c = b(a10);
    }

    public static MessageDigest a(String str) {
        try {
            return MessageDigest.getInstance(str);
        } catch (NoSuchAlgorithmException e10) {
            throw new AssertionError(e10);
        }
    }

    public static boolean b(MessageDigest messageDigest) {
        try {
            messageDigest.clone();
            return true;
        } catch (CloneNotSupportedException unused) {
            return false;
        }
    }

    public final String toString() {
        return this.f15795d;
    }

    @Override // deobf.com.google.android.gms.fb.j2
    public final k2 zza() {
        n2 n2Var = null;
        if (this.f15794c) {
            try {
                return new o2((MessageDigest) this.f15793a.clone(), this.b, n2Var);
            } catch (CloneNotSupportedException unused) {
            }
        }
        return new o2(a(this.f15793a.getAlgorithm()), this.b, n2Var);
    }
}
