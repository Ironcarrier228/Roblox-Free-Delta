package deobf.com.google.android.gms.o9;

import androidx.annotation.NonNull;
import com.google.android.gms.tasks.Task;
import com.google.errorprone.annotations.RestrictedInheritance;
import com.google.errorprone.annotations.ResultIgnorabilityUnspecified;

@RestrictedInheritance(allowedOnPath = ".*java.*/com/google/android/gms.*", explanation = "Use canonical fakes instead.", link = "go/gmscore-restrictedinheritance")
// dex: classes.dex
public interface y extends deobf.com.google.android.gms.l9.i<z> {
    @NonNull
    @ResultIgnorabilityUnspecified
    Task<Void> g(@NonNull w wVar);
}
