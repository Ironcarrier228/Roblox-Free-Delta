package deobf.com.google.android.gms.o9;

import android.content.Context;
import android.content.ServiceConnection;
import android.os.HandlerThread;
import androidx.annotation.NonNull;
import java.util.concurrent.Executor;

// dex: classes.dex
public abstract class j {

    public static final Object f26983a = new Object();
    public static int b = 9;

    public static s1 f26984c;

    public static HandlerThread f26985d;

    public static Executor f26986e;

    public static boolean f26987f;

    @NonNull
    public static j a(@NonNull Context context) {
        synchronized (f26983a) {
            try {
                if (f26984c == null) {
                    f26984c = new s1(context.getApplicationContext(), f26987f ? b().getLooper() : context.getMainLooper(), f26986e);
                }
            } catch (Throwable th2) {
                throw th2;
            }
        }
        return f26984c;
    }

    @NonNull
    public static HandlerThread b() {
        synchronized (f26983a) {
            try {
                HandlerThread handlerThread = f26985d;
                if (handlerThread != null) {
                    return handlerThread;
                }
                HandlerThread handlerThread2 = new HandlerThread("GoogleApiHandler", b);
                f26985d = handlerThread2;
                handlerThread2.start();
                return f26985d;
            } catch (Throwable th2) {
                throw th2;
            }
        }
    }

    public abstract deobf.com.google.mlkit.vision.k9.b c(p1 p1Var, ServiceConnection serviceConnection, String str, Executor executor);

    public final void d(@NonNull String str, @NonNull String str2, int i10, @NonNull ServiceConnection serviceConnection, @NonNull String str3, boolean z10) {
        e(new p1(str, str2, 4225, z10), serviceConnection, str3);
    }

    public abstract void e(p1 p1Var, ServiceConnection serviceConnection, String str);
}
