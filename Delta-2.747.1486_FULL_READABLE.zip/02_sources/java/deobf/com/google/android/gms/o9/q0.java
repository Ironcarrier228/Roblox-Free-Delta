package deobf.com.google.android.gms.o9;

// dex: classes.dex
public interface q0 {
}
