package deobf.com.google.android.gms.o9;

import android.app.Activity;
import android.content.Intent;

// dex: classes.dex
public final class g0 extends i0 {

    public final /* synthetic */ Intent f26958a;
    public final /* synthetic */ Activity b;

    public final /* synthetic */ int f26959c;

    public g0(Intent intent, Activity activity, int i10) {
        this.f26958a = intent;
        this.b = activity;
        this.f26959c = i10;
    }

    @Override // deobf.com.google.android.gms.o9.i0
    public final void a() {
        Intent intent = this.f26958a;
        if (intent != null) {
            this.b.startActivityForResult(intent, this.f26959c);
        }
    }
}
