package deobf.com.google.android.gms.fb;

import java.util.Iterator;

// dex: classes.dex
public final class z1 extends h1 {

    public final transient Object f15897c;

    public z1(Object obj) {
        obj.getClass();
        this.f15897c = obj;
    }

    @Override // deobf.com.google.android.gms.fb.z0
    public final int a(Object[] objArr, int i10) {
        objArr[0] = this.f15897c;
        return 1;
    }

    @Override // deobf.com.google.android.gms.fb.z0, java.util.AbstractCollection, java.util.Collection, java.util.List
    public final boolean contains(Object obj) {
        return this.f15897c.equals(obj);
    }

    @Override // deobf.com.google.android.gms.fb.h1, deobf.com.google.android.gms.fb.z0
    public final c2 d() {
        return new n1(this.f15897c);
    }

    @Override // deobf.com.google.android.gms.fb.h1, java.util.Collection, java.util.Set
    public final int hashCode() {
        return this.f15897c.hashCode();
    }

    @Override // deobf.com.google.android.gms.fb.h1
    public final e1 i() {
        return e1.j(this.f15897c);
    }

    @Override // java.util.AbstractCollection, java.util.Collection, java.lang.Iterable, java.util.Set
    public final /* synthetic */ Iterator iterator() {
        return new n1(this.f15897c);
    }

    @Override // java.util.AbstractCollection, java.util.Collection, java.util.Set
    public final int size() {
        return 1;
    }

    @Override // java.util.AbstractCollection
    public final String toString() {
        return "[" + this.f15897c.toString() + "]";
    }
}
