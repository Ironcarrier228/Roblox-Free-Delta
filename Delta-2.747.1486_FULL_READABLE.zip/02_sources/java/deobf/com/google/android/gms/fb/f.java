package deobf.com.google.android.gms.fb;

// dex: classes.dex
public final class f {

    public static final Object f15733a = new Object();
    public static final j b = new j();

    public static final q0 f15734c = u0.a(new q0() { // from class: fb.e
        @Override // deobf.com.google.android.gms.fb.q0
        public final Object zza() {
            throw null;
        }
    });

    public static f a() {
        deobf.androidx.appcompat.widget.i.a();
        deobf.androidx.appcompat.widget.i.b();
        deobf.androidx.appcompat.widget.i.d();
        throw new IllegalStateException("Must call PhenotypeContext.setContext() first");
    }

    public static boolean b() {
        deobf.androidx.appcompat.widget.i.d();
        deobf.androidx.appcompat.widget.i.c();
        return false;
    }
}
