package deobf.com.google.android.gms.o9;

import android.os.Parcel;
import android.os.Parcelable;
import androidx.annotation.NonNull;

// dex: classes.dex
public class p extends deobf.com.google.android.gms.p9.a {

    @NonNull
    public static final Parcelable.Creator<p> CREATOR = new m0();

    public final int f27002f;

    public final int f27003g;

    public final int f27004h;

    public final long f27005i;

    public final long f27006j;

    public final String f27007k;

    public final String f27008l;

    public final int f27009m;

    public final int f27010n;

    @Deprecated
    public p(int i10, int i11, int i12, long j10, long j11, String str, String str2, int i13) {
        this(i10, i11, i12, j10, j11, str, str2, i13, -1);
    }

    @Override // android.os.Parcelable
    public final void writeToParcel(@NonNull Parcel parcel, int i10) {
        int i11 = this.f27002f;
        int a10 = deobf.com.google.android.gms.p9.c.a(parcel);
        deobf.com.google.android.gms.p9.c.n(parcel, 1, i11);
        deobf.com.google.android.gms.p9.c.n(parcel, 2, this.f27003g);
        deobf.com.google.android.gms.p9.c.n(parcel, 3, this.f27004h);
        deobf.com.google.android.gms.p9.c.r(parcel, 4, this.f27005i);
        deobf.com.google.android.gms.p9.c.r(parcel, 5, this.f27006j);
        deobf.com.google.android.gms.p9.c.v(parcel, 6, this.f27007k, false);
        deobf.com.google.android.gms.p9.c.v(parcel, 7, this.f27008l, false);
        deobf.com.google.android.gms.p9.c.n(parcel, 8, this.f27009m);
        deobf.com.google.android.gms.p9.c.n(parcel, 9, this.f27010n);
        deobf.com.google.android.gms.p9.c.b(parcel, a10);
    }

    public p(int i10, int i11, int i12, long j10, long j11, String str, String str2, int i13, int i14) {
        this.f27002f = i10;
        this.f27003g = i11;
        this.f27004h = i12;
        this.f27005i = j10;
        this.f27006j = j11;
        this.f27007k = str;
        this.f27008l = str2;
        this.f27009m = i13;
        this.f27010n = i14;
    }
}
