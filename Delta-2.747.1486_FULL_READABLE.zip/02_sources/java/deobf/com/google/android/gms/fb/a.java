package deobf.com.google.android.gms.fb;

import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;

// dex: classes.dex
public class a implements IInterface {

    public final IBinder f15716a;
    public final String b;

    public a(IBinder iBinder, String str) {
        this.f15716a = iBinder;
        this.b = str;
    }

    @Override // android.os.IInterface
    public final IBinder asBinder() {
        return this.f15716a;
    }

    public final Parcel r2() {
        Parcel obtain = Parcel.obtain();
        obtain.writeInterfaceToken(this.b);
        return obtain;
    }

    public final void s2(int i10, Parcel parcel) {
        Parcel obtain = Parcel.obtain();
        try {
            this.f15716a.transact(i10, parcel, obtain, 0);
            obtain.readException();
        } finally {
            parcel.recycle();
            obtain.recycle();
        }
    }
}
