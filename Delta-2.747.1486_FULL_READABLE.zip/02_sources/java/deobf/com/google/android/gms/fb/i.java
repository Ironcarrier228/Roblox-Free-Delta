package deobf.com.google.android.gms.fb;

// dex: classes.dex
public final class i {

    public static final Object f15744a = new Object();
    public static volatile h b;

    public static volatile boolean f15745c;

    public static volatile h f15746d;

    public static void a() {
        f15745c = true;
    }

    public static void b() {
        if (f15746d == null) {
            f15746d = new h(null);
        }
    }

    public static void c() {
        if (b == null) {
            b = new h(null);
        }
    }

    public static boolean d() {
        synchronized (f15744a) {
        }
        return false;
    }
}
