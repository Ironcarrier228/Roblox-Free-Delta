package deobf.com.google.android.gms.o9;

import android.os.Parcel;
import android.os.Parcelable;
import androidx.annotation.NonNull;

// dex: classes.dex
public class g extends deobf.com.google.android.gms.p9.a {

    @NonNull
    public static final Parcelable.Creator<g> CREATOR = new n1();

    public final u f26952f;

    public final boolean f26953g;

    public final boolean f26954h;

    public final int[] f26955i;

    public final int f26956j;

    public final int[] f26957k;

    public g(@NonNull u uVar, boolean z10, boolean z11, int[] iArr, int i10, int[] iArr2) {
        this.f26952f = uVar;
        this.f26953g = z10;
        this.f26954h = z11;
        this.f26955i = iArr;
        this.f26956j = i10;
        this.f26957k = iArr2;
    }

    public int A3() {
        return this.f26956j;
    }

    public int[] B3() {
        return this.f26955i;
    }

    public int[] C3() {
        return this.f26957k;
    }

    public boolean D3() {
        return this.f26953g;
    }

    public boolean E3() {
        return this.f26954h;
    }

    @NonNull
    public final u F3() {
        return this.f26952f;
    }

    @Override // android.os.Parcelable
    public final void writeToParcel(@NonNull Parcel parcel, int i10) {
        int a10 = deobf.com.google.android.gms.p9.c.a(parcel);
        deobf.com.google.android.gms.p9.c.t(parcel, 1, this.f26952f, i10, false);
        deobf.com.google.android.gms.p9.c.c(parcel, 2, D3());
        deobf.com.google.android.gms.p9.c.c(parcel, 3, E3());
        deobf.com.google.android.gms.p9.c.o(parcel, 4, B3(), false);
        deobf.com.google.android.gms.p9.c.n(parcel, 5, A3());
        deobf.com.google.android.gms.p9.c.o(parcel, 6, C3(), false);
        deobf.com.google.android.gms.p9.c.b(parcel, a10);
    }
}
