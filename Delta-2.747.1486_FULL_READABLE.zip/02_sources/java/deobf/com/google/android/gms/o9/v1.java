package deobf.com.google.android.gms.o9;

import android.accounts.Account;
import android.os.IBinder;
import android.os.Parcel;

// dex: classes.dex
public final class v1 extends deobf.com.google.android.gms.eb.a implements l {
    public v1(IBinder iBinder) {
        super(iBinder, "com.google.android.gms.common.internal.IAccountAccessor");
    }

    @Override // deobf.com.google.android.gms.o9.l
    public final Account zzb() {
        Parcel r22 = r2(2, s2());
        Account account = (Account) deobf.com.google.android.gms.eb.o.b(r22, Account.CREATOR);
        r22.recycle();
        return account;
    }
}
