package deobf.com.google.android.gms.fb;

// dex: classes.dex
public interface x {
}
