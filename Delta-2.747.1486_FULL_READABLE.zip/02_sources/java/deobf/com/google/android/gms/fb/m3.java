package deobf.com.google.android.gms.fb;

import java.io.InputStream;
import java.io.Serializable;
import java.nio.ByteBuffer;
import java.util.Comparator;
import java.util.Iterator;
import java.util.Locale;

// dex: classes.dex
public abstract class m3 implements Iterable<Byte>, Serializable {
    public static final m3 b = new j3(s3.f15860d);

    public static final Comparator f15773c;

    public static final l3 f15774d;

    public int f15775a = 0;

    static {
        int i10 = c3.f15723a;
        f15774d = new l3(null);
        f15773c = new e3();
    }

    public static int j(int i10, int i11, int i12) {
        int i13 = i11 - i10;
        if ((i10 | i11 | i13 | (i12 - i11)) >= 0) {
            return i13;
        }
        if (i10 < 0) {
            throw new IndexOutOfBoundsException("Beginning index: " + i10 + " < 0");
        }
        if (i11 < i10) {
            throw new IndexOutOfBoundsException("Beginning index larger than ending index: " + i10 + ", " + i11);
        }
        throw new IndexOutOfBoundsException("End index: " + i11 + " >= " + i12);
    }

    public static m3 m(byte[] bArr, int i10, int i11) {
        j(0, i11, bArr.length);
        byte[] bArr2 = new byte[i11];
        System.arraycopy(bArr, 0, bArr2, 0, i11);
        return new j3(bArr2);
    }

    public abstract byte b(int i10);

    public abstract byte c(int i10);

    public abstract int d();

    public abstract void e(byte[] bArr, int i10, int i11, int i12);

    public abstract boolean equals(Object obj);

    public abstract int f(int i10, int i11, int i12);

    public abstract m3 g(int i10, int i11);

    public abstract InputStream h();

    public final int hashCode() {
        int i10 = this.f15775a;
        if (i10 == 0) {
            int d10 = d();
            i10 = f(d10, 0, d10);
            if (i10 == 0) {
                i10 = 1;
            }
            this.f15775a = i10;
        }
        return i10;
    }

    public abstract ByteBuffer i();

    @Override // java.lang.Iterable
    public final /* synthetic */ Iterator<Byte> iterator() {
        return new d3(this);
    }

    public final int l() {
        return this.f15775a;
    }

    public final byte[] n() {
        int d10 = d();
        if (d10 == 0) {
            return s3.f15860d;
        }
        byte[] bArr = new byte[d10];
        e(bArr, 0, 0, d10);
        return bArr;
    }

    public final String toString() {
        return String.format(Locale.ROOT, "<ByteString@%s size=%d contents=\"%s\">", Integer.toHexString(System.identityHashCode(this)), Integer.valueOf(d()), d() <= 50 ? deobf.unlinked.t3.a(this) : deobf.unlinked.t3.a(g(0, 47)).concat("..."));
    }
}
