package deobf.com.google.android.gms.fb;

// dex: classes.dex
public final class d4 extends Exception {
    public d4(String str) {
        super(str);
    }
}
