package deobf.com.google.android.gms.fb;

import java.util.NoSuchElementException;

// dex: classes.dex
public final class n1 extends c2 {
    public static final Object b = new Object();

    public Object f15778a;

    public n1(Object obj) {
        this.f15778a = obj;
    }

    @Override // java.util.Iterator
    public final boolean hasNext() {
        return this.f15778a != b;
    }

    @Override // java.util.Iterator
    public final Object next() {
        Object obj = this.f15778a;
        Object obj2 = b;
        if (obj == obj2) {
            throw new NoSuchElementException();
        }
        this.f15778a = obj2;
        return obj;
    }
}
