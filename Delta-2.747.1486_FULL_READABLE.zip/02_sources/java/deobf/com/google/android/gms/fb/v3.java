package deobf.com.google.android.gms.fb;

import java.util.ArrayList;
import java.util.Arrays;

// dex: classes.dex
public final class v3 extends e4 {

    public final e1 f15887a;
    public final int b;

    public v3(e1 e1Var) {
        e1Var.getClass();
        this.f15887a = e1Var;
        int i10 = 0;
        int i11 = 0;
        while (true) {
            e1 e1Var2 = this.f15887a;
            if (i10 >= e1Var2.size()) {
                break;
            }
            int a10 = ((e4) e1Var2.get(i10)).a();
            if (i11 < a10) {
                i11 = a10;
            }
            i10++;
        }
        int i12 = i11 + 1;
        this.b = i12;
        if (i12 > 8) {
            throw new u3("Exceeded cutoff limit for max depth of cbor value");
        }
    }

    @Override // deobf.com.google.android.gms.fb.e4
    public final int a() {
        return this.b;
    }

    @Override // java.lang.Comparable
    public final /* bridge */ /* synthetic */ int compareTo(Object obj) {
        e4 e4Var = (e4) obj;
        if (deobf.androidx.fragment.app.e4.c(Byte.MIN_VALUE) != e4Var.zza()) {
            return deobf.androidx.fragment.app.e4.c(Byte.MIN_VALUE) - e4Var.zza();
        }
        v3 v3Var = (v3) e4Var;
        e1 e1Var = this.f15887a;
        int size = e1Var.size();
        e1 e1Var2 = v3Var.f15887a;
        if (size != e1Var2.size()) {
            return e1Var.size() - e1Var2.size();
        }
        int i10 = 0;
        while (true) {
            e1 e1Var3 = this.f15887a;
            if (i10 >= e1Var3.size()) {
                return 0;
            }
            int compareTo = ((e4) e1Var3.get(i10)).compareTo((e4) v3Var.f15887a.get(i10));
            if (compareTo != 0) {
                return compareTo;
            }
            i10++;
        }
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj != null && v3.class == obj.getClass()) {
            return this.f15887a.equals(((v3) obj).f15887a);
        }
        return false;
    }

    public final int hashCode() {
        return Arrays.hashCode(new Object[]{Integer.valueOf(deobf.androidx.fragment.app.e4.c(Byte.MIN_VALUE)), this.f15887a});
    }

    public final String toString() {
        if (this.f15887a.isEmpty()) {
            return "[]";
        }
        ArrayList arrayList = new ArrayList();
        e1 e1Var = this.f15887a;
        int size = e1Var.size();
        for (int i10 = 0; i10 < size; i10++) {
            arrayList.add(((e4) e1Var.get(i10)).toString().replace("\n", "\n  "));
        }
        e0 a10 = deobf.unlinked.e0.a(",\n  ");
        StringBuilder sb2 = new StringBuilder("[\n  ");
        a10.c(sb2, arrayList.iterator());
        sb2.append("\n]");
        return sb2.toString();
    }

    @Override // deobf.com.google.android.gms.fb.e4
    public final int zza() {
        return deobf.androidx.fragment.app.e4.c(Byte.MIN_VALUE);
    }
}
