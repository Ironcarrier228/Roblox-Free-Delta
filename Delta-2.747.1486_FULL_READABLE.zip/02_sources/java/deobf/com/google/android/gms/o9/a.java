package deobf.com.google.android.gms.o9;

import android.accounts.Account;
import android.os.Binder;
import android.os.RemoteException;
import android.util.Log;
import androidx.annotation.NonNull;
import deobf.com.google.android.gms.o9.l;

// dex: classes.dex
public class a extends deobf.unlinked.l.a {
    public static Account t2(@NonNull l lVar) {
        if (lVar == null) {
            return null;
        }
        long clearCallingIdentity = Binder.clearCallingIdentity();
        try {
            return lVar.zzb();
        } catch (RemoteException unused) {
            Log.w("AccountAccessor", "Remote account accessor probably died");
            return null;
        } finally {
            Binder.restoreCallingIdentity(clearCallingIdentity);
        }
    }
}
