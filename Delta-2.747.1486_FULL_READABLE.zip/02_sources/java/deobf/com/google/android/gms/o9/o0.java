package deobf.com.google.android.gms.o9;

import com.google.android.gms.common.api.Status;
import java.util.concurrent.TimeUnit;
import deobf.com.google.android.gms.l9.k;
import deobf.com.google.android.gms.o9.r;

// dex: classes.dex
public final class o0 implements deobf.unlinked.k.a {

    public final /* synthetic */ deobf.com.google.android.gms.l9.k f26999a;
    public final /* synthetic */ deobf.com.google.mlkit.common.tb.k b;

    public final /* synthetic */ r.a f27000c;

    public final /* synthetic */ q0 f27001d;

    public o0(deobf.com.google.android.gms.l9.k kVar, deobf.com.google.mlkit.common.tb.k kVar2, r.a aVar, q0 q0Var) {
        this.f26999a = kVar;
        this.b = kVar2;
        this.f27000c = aVar;
        this.f27001d = q0Var;
    }

    @Override // deobf.com.google.android.gms.l9.k.a
    public final void a(Status status) {
        if (!status.F3()) {
            this.b.b(b.a(status));
        } else {
            this.b.c(this.f27000c.a(this.f26999a.d(0L, TimeUnit.MILLISECONDS)));
        }
    }
}
