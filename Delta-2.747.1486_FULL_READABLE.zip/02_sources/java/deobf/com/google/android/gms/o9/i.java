package deobf.com.google.android.gms.o9;

import android.accounts.Account;
import android.content.Context;
import android.os.IInterface;
import android.os.Looper;
import androidx.annotation.NonNull;
import com.google.android.gms.common.api.Scope;
import java.util.Collections;
import java.util.Iterator;
import java.util.Set;
import java.util.concurrent.Executor;
import deobf.com.google.android.gms.l9.a;
import deobf.com.google.android.gms.l9.h;

// dex: classes.dex
public abstract class i<T extends IInterface> extends d<T> implements a.f {
    public final f b;

    public final Set f26979c;

    public final Account f26980d;

    @Deprecated
    public i(@NonNull Context context, @NonNull Looper looper, int i10, @NonNull f fVar, @NonNull deobf.com.roblox.protocols.mediapicker.h.a aVar, @NonNull deobf.com.roblox.protocols.mediapicker.h.b bVar) {
        this(context, looper, i10, fVar, (deobf.com.google.android.gms.m9.e) aVar, (deobf.com.google.android.gms.m9.n) bVar);
    }

    @NonNull
    public Set<Scope> c() {
        return requiresSignIn() ? this.f26979c : Collections.EMPTY_SET;
    }

    @NonNull
    public final f d() {
        return this.b;
    }

    @NonNull
    public Set<Scope> e(@NonNull Set<Scope> set) {
        return set;
    }

    public final Set f(@NonNull Set set) {
        Set<Scope> e10 = e(set);
        Iterator<Scope> it = e10.iterator();
        while (it.hasNext()) {
            if (!set.contains(it.next())) {
                throw new IllegalStateException("Expanding scopes is not permitted, use implied scopes instead");
            }
        }
        return e10;
    }

    @Override // deobf.com.google.android.gms.o9.d
    public final Account getAccount() {
        return this.f26980d;
    }

    @Override // deobf.com.google.android.gms.o9.d
    public Executor getBindServiceExecutor() {
        return null;
    }

    @Override // deobf.com.google.android.gms.o9.d
    @NonNull
    public final Set<Scope> getScopes() {
        return this.f26979c;
    }

    public i(@NonNull Context context, @NonNull Looper looper, int i10, @NonNull f fVar, @NonNull deobf.com.google.android.gms.m9.e eVar, @NonNull deobf.com.google.android.gms.m9.n nVar) {
        this(context, looper, deobf.com.google.android.material.j.a(context), deobf.com.google.mlkit.vision.k9.e.o(), i10, fVar, (deobf.com.google.android.gms.m9.e) s.l(eVar), (deobf.com.google.android.gms.m9.n) s.l(nVar));
    }

    public i(@NonNull Context context, @NonNull Looper looper, @NonNull j jVar, @NonNull deobf.com.google.mlkit.vision.k9.e eVar, int i10, @NonNull f fVar, deobf.com.google.android.gms.m9.e eVar2, deobf.com.google.android.gms.m9.n nVar) {
        super(context, looper, jVar, eVar, i10, eVar2 == null ? null : new j0(eVar2), nVar != null ? new k0(nVar) : null, fVar.l());
        this.b = fVar;
        this.f26980d = fVar.a();
        this.f26979c = f(fVar.d());
    }
}
