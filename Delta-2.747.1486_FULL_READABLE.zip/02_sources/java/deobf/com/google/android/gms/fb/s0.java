package deobf.com.google.android.gms.fb;

// dex: classes.dex
public final class s0 implements q0 {
    public static final q0 b = new q0() { // from class: fb.r0
        @Override // deobf.com.google.android.gms.fb.q0
        public final Object zza() {
            throw null;
        }
    };

    public volatile q0 f15857a;

    public s0(q0 q0Var) {
        this.f15857a = q0Var;
    }

    public final String toString() {
        Object obj = this.f15857a;
        if (obj == b) {
            obj = "<supplier that returned null>";
        }
        return "Suppliers.memoize(" + String.valueOf(obj) + ")";
    }

    @Override // deobf.com.google.android.gms.fb.q0
    public final Object zza() {
        throw null;
    }
}
