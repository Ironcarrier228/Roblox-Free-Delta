package deobf.com.google.android.gms.fb;

// dex: classes.dex
public abstract class f3 implements h3 {
    @Override // java.util.Iterator
    public final /* synthetic */ Object next() {
        return Byte.valueOf(zza());
    }

    @Override // java.util.Iterator
    public final void remove() {
        throw new UnsupportedOperationException();
    }
}
