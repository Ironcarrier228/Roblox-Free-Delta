package deobf.com.google.android.gms.o9;

import android.accounts.Account;
import android.os.IBinder;
import android.os.IInterface;
import androidx.annotation.NonNull;

// dex: classes.dex
public interface l extends IInterface {

    public static abstract class a extends deobf.com.google.android.gms.eb.n implements l {
        @NonNull
        public static l s2(@NonNull IBinder iBinder) {
            if (iBinder == null) {
                return null;
            }
            IInterface queryLocalInterface = iBinder.queryLocalInterface("com.google.android.gms.common.internal.IAccountAccessor");
            return queryLocalInterface instanceof l ? (l) queryLocalInterface : new v1(iBinder);
        }
    }

    @NonNull
    Account zzb();
}
