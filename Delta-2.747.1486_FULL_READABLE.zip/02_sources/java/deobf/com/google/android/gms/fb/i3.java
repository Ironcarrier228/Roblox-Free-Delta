package deobf.com.google.android.gms.fb;

// dex: classes.dex
public abstract class i3 extends m3 {
}
