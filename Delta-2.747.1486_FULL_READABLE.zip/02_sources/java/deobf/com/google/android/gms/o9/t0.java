package deobf.com.google.android.gms.o9;

import android.os.IBinder;
import android.os.Parcel;
import android.os.Parcelable;
import deobf.com.google.android.gms.o9.l;

// dex: classes.dex
public final class t0 extends deobf.com.google.android.gms.p9.a {
    public static final Parcelable.Creator<t0> CREATOR = new u0();

    public final int f27038f;

    public final IBinder f27039g;

    public final deobf.com.google.mlkit.vision.k9.b f27040h;

    public final boolean f27041i;

    public final boolean f27042j;

    public t0(int i10, IBinder iBinder, deobf.com.google.mlkit.vision.k9.b bVar, boolean z10, boolean z11) {
        this.f27038f = i10;
        this.f27039g = iBinder;
        this.f27040h = bVar;
        this.f27041i = z10;
        this.f27042j = z11;
    }

    public final deobf.com.google.mlkit.vision.k9.b A3() {
        return this.f27040h;
    }

    public final l B3() {
        IBinder iBinder = this.f27039g;
        if (iBinder == null) {
            return null;
        }
        return deobf.unlinked.l.a.s2(iBinder);
    }

    public final boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof t0)) {
            return false;
        }
        t0 t0Var = (t0) obj;
        return this.f27040h.equals(t0Var.f27040h) && deobf.androidx.appcompat.widget.q.b(B3(), t0Var.B3());
    }

    @Override // android.os.Parcelable
    public final void writeToParcel(Parcel parcel, int i10) {
        int a10 = deobf.com.google.android.gms.p9.c.a(parcel);
        deobf.com.google.android.gms.p9.c.n(parcel, 1, this.f27038f);
        deobf.com.google.android.gms.p9.c.m(parcel, 2, this.f27039g, false);
        deobf.com.google.android.gms.p9.c.t(parcel, 3, this.f27040h, i10, false);
        deobf.com.google.android.gms.p9.c.c(parcel, 4, this.f27041i);
        deobf.com.google.android.gms.p9.c.c(parcel, 5, this.f27042j);
        deobf.com.google.android.gms.p9.c.b(parcel, a10);
    }
}
