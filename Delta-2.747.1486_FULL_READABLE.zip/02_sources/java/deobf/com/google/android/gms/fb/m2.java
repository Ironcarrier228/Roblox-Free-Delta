package deobf.com.google.android.gms.fb;

// dex: classes.dex
public final class m2 {
    static {
        System.currentTimeMillis();
    }

    public static j2 a() {
        return l2.f15763a;
    }
}
