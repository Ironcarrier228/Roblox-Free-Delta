package deobf.com.google.android.gms.fb;

// dex: classes.dex
public final class h extends Exception {
    public /* synthetic */ h(g gVar) {
    }
}
