package deobf.com.roblox.client.startup.xm;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import deobf.com.roblox.client.bi.h;
import com.roblox.universalapp.logging.LoggingProtocol;
import java.util.concurrent.atomic.AtomicBoolean;

// dex: classes2.dex
public class a {

    public static a f36793f;

    public static b f36794g = b.USER_INITIATED;
    public boolean b;

    public final AtomicBoolean f36795a = new AtomicBoolean(false);

    public boolean f36796c = false;

    public boolean f36797d = false;

    public boolean f36798e = false;

    public enum EnumC0756a {
        SPLASH,
        MAIN,
        GAME
    }

    public enum b {
        USER_INITIATED,
        BACKGROUND
    }

    public a(boolean z10) {
        this.b = z10;
    }

    public static void c(Context context) {
        if (f36793f == null) {
            f36793f = new a(context instanceof Activity);
        }
    }

    public static void i() {
        f36794g = b.BACKGROUND;
    }

    public static a j() {
        return f36793f;
    }

    public void a(EnumC0756a enumC0756a, Bundle bundle) {
        if (enumC0756a == EnumC0756a.SPLASH) {
            if (bundle != null || !this.b || f36794g == b.BACKGROUND || this.f36796c || this.f36797d) {
                LoggingProtocol.g("warm_start");
                return;
            } else if (!d()) {
                LoggingProtocol.h("cold_start", 1L);
                return;
            } else {
                LoggingProtocol.g("warm_start");
                LoggingProtocol.g("warm_start_pre_forked");
                return;
            }
        }
        if (deobf.com.roblox.protocols.mediapicker.h.a().Q1() && enumC0756a == EnumC0756a.GAME) {
            if (bundle != null || !this.b || f36794g == b.BACKGROUND || this.f36798e) {
                LoggingProtocol.g("warm_start");
                LoggingProtocol.g("game_activity_warm_start");
            } else if (d()) {
                LoggingProtocol.g("warm_start");
                LoggingProtocol.g("game_activity_warm_start");
                LoggingProtocol.g("warm_start_pre_forked");
            } else {
                LoggingProtocol.h("cold_start", 1L);
                LoggingProtocol.g("game_activity_cold_start");
            }
            this.f36798e = true;
            return;
        }
        if (enumC0756a != EnumC0756a.MAIN || this.f36795a.getAndSet(false) || bundle == null) {
            return;
        }
        if (this.f36796c || this.f36797d) {
            LoggingProtocol.g("warm_start");
            LoggingProtocol.g("main_activity_warm_start");
            return;
        }
        if (d()) {
            LoggingProtocol.g("warm_start");
            LoggingProtocol.g("main_activity_warm_start");
            LoggingProtocol.g("warm_start_pre_forked");
            return;
        }
        boolean z10 = this.f36796c;
        if (!z10 && !this.f36797d) {
            LoggingProtocol.h("cold_start", 1L);
            LoggingProtocol.g("main_activity_cold_start");
        } else {
            if (z10 || !this.f36797d) {
                return;
            }
            LoggingProtocol.g("warm_start");
            LoggingProtocol.g("main_activity_warm_start_no_splash");
        }
    }

    public void b(EnumC0756a enumC0756a) {
        LoggingProtocol.g("app_paused");
    }

    public final boolean d() {
        return LoggingProtocol.getProcessTimestamp() > 30000;
    }

    public void e() {
        this.f36795a.set(true);
    }

    public void f() {
        this.f36798e = true;
    }

    public void g() {
        this.f36797d = true;
    }

    public void h() {
        this.f36796c = true;
    }
}
