package deobf.com.roblox.client.implementation.ih;

// dex: classes2.dex
public interface a {
    void a();

    void b(deobf.com.google.android.material.j.b bVar);
}
