package deobf.com.roblox.client.implementation.ih;

import android.content.Context;
import deobf.com.roblox.client.implementation.pw.e;

// dex: classes2.dex
public class c implements a {

    public final org.webrtc.voiceengine.a f19492a;

    public c(Context context) {
        this.f19492a = deobf.com.roblox.client.e.p(context);
    }

    @Override // deobf.com.roblox.client.implementation.ih.a
    public void a() {
        this.f19492a.a();
    }

    @Override // deobf.com.roblox.client.implementation.ih.a
    public void b(deobf.com.google.android.material.j.b bVar) {
        this.f19492a.e(bVar);
    }
}
