package deobf.com.roblox.client.implementation.ih;

import android.content.Context;
import androidx.annotation.NonNull;

// dex: classes2.dex
public interface b {
    @NonNull
    a getRtcAudioManager(Context context);
}
