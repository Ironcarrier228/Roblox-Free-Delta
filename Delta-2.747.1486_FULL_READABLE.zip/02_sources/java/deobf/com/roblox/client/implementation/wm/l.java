package deobf.com.roblox.client.implementation.wm;

import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.util.Log;
import androidx.annotation.NonNull;
import com.github.luben.zstd.BuildConfig;
import deobf.com.roblox.protocols.mediapicker.g.i;
import deobf.com.roblox.client.implementation.wm.l;

// dex: classes2.dex
public class l {

    public static String f35917a = "l";

    public static class a {

        public static final l f35918a = new l();
    }

    public interface b {
        void onFailure(String str);

        void onSuccess();
    }

    public static /* synthetic */ void a(b bVar, Exception exc) {
        Log.i(f35917a, "SignInClient not available: " + exc.toString());
        bVar.onFailure("google_auth_api_not_available");
    }

    public static /* synthetic */ void b(deobf.com.roblox.protocols.mediapicker.g.d dVar, b bVar, PendingIntent pendingIntent) {
        try {
            dVar.b(new deobf.androidx.appcompat.widget.i.a(pendingIntent.getIntentSender()).a());
        } catch (Exception e10) {
            Log.e(f35917a, "Error occurred in launching Activity result", e10);
            bVar.onFailure("google_auth_api_error");
        }
    }

    public static /* synthetic */ void d(b bVar, Exception exc) {
        Log.e("Failure occurred", "Failure getting phone number");
        bVar.onFailure("google_auth_api_error");
    }

    public static l f() {
        return a.f35918a;
    }

    public String e(@NonNull Context context, @NonNull Intent intent) {
        try {
            return deobf.androidx.credentials.playservices.controllers.identityauth.createpublickeycredential.a9.f.b(context.getApplicationContext()).p(intent);
        } catch (Exception e10) {
            Log.e(f35917a, "Phone Number Hint failed", e10);
            return BuildConfig.FLAVOR;
        }
    }

    public void g(@NonNull Context context, b bVar) {
        h(context, deobf.com.google.mlkit.vision.k9.e.o(), bVar);
    }

    public void h(@NonNull Context context, deobf.com.google.mlkit.vision.k9.e eVar, final b bVar) {
        if (!context.getPackageManager().hasSystemFeature("android.hardware.telephony")) {
            Log.i(f35917a, "Telephony is not available!");
            bVar.onFailure("telephony_not_available");
            return;
        }
        if (eVar.g(context) != 0) {
            Log.i(f35917a, "GooglePlayServices is not available!");
            bVar.onFailure("google_play_services_not_available");
            return;
        }
        try {
            eVar.l(deobf.androidx.credentials.playservices.controllers.identityauth.createpublickeycredential.a9.f.b(context.getApplicationContext()), new deobf.com.google.android.gms.l9.i[0]).g(new deobf.com.google.mlkit.common.tb.g() { // from class: wm.j
                @Override // deobf.com.google.mlkit.common.tb.g
                public final void onSuccess(Object obj) {
                    deobf.unlinked.l.b.this.onSuccess();
                }
            }).e(new deobf.com.google.mlkit.common.tb.f() { // from class: wm.k
                @Override // deobf.com.google.mlkit.common.tb.f
                public final void onFailure(Exception exc) {
                    deobf.unlinked.l.a(deobf.unlinked.l.b.this, exc);
                }
            });
        } catch (Exception e10) {
            Log.i(f35917a, "Error checking api availability: " + e10.toString());
            bVar.onFailure("google_auth_api_error");
        }
    }

    public void i(@NonNull Context context, @NonNull final deobf.com.roblox.protocols.mediapicker.g.d<deobf.com.roblox.protocols.mediapicker.g.i> dVar, final b bVar) {
        Log.d(f35917a, "Requesting phone number hint");
        deobf.androidx.credentials.playservices.controllers.identityauth.createpublickeycredential.a9.f.b(context.getApplicationContext()).d(deobf.androidx.credentials.playservices.controllers.identityauth.createpublickeycredential.a9.d.A3().a()).g(new deobf.com.google.mlkit.common.tb.g() { // from class: wm.h
            @Override // deobf.com.google.mlkit.common.tb.g
            public final void onSuccess(Object obj) {
                deobf.unlinked.l.b(deobf.com.roblox.protocols.mediapicker.g.d.this, bVar, (PendingIntent) obj);
            }
        }).e(new deobf.com.google.mlkit.common.tb.f() { // from class: wm.i
            @Override // deobf.com.google.mlkit.common.tb.f
            public final void onFailure(Exception exc) {
                l.d(deobf.unlinked.l.b.this, exc);
            }
        });
    }
}
