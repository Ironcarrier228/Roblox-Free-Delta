package deobf.com.roblox.client.implementation.wm;

import android.content.Context;
import android.content.Intent;
import android.util.Log;
import com.github.luben.zstd.BuildConfig;
import com.roblox.universalapp.logging.LoggingProtocol;
import com.roblox.universalapp.messagebus.Callback;
import com.roblox.universalapp.messagebus.Connection;
import com.roblox.universalapp.messagebus.MessageBus;
import deobf.com.roblox.client.e.p;
import java.lang.ref.WeakReference;
import java.util.HashMap;
import org.json.JSONException;
import org.json.JSONObject;
import deobf.com.roblox.client.implementation.wm.l;

// dex: classes2.dex
public class f {

    public MessageBus f35903a;
    public Context b;

    public WeakReference<deobf.com.roblox.protocols.mediapicker.g.d<deobf.com.roblox.protocols.mediapicker.g.i>> f35904c;

    public Connection f35905d;

    public Connection f35906e;

    public Connection f35907f;

    public Connection f35908g;

    public class a implements deobf.unlinked.l.b {
        public a() {
        }

        @Override // deobf.com.roblox.client.implementation.wm.l.b
        public void onFailure(String str) {
            LoggingProtocol.g("supportsGetSMSOTP_" + str);
            f.this.v("supportsGetSMSOTP", "support", false);
        }

        @Override // deobf.com.roblox.client.implementation.wm.l.b
        public void onSuccess() {
            f.this.v("supportsGetSMSOTP", "support", true);
        }
    }

    public class b implements deobf.unlinked.l.b {
        public b() {
        }

        @Override // deobf.com.roblox.client.implementation.wm.l.b
        public void onFailure(String str) {
            LoggingProtocol.g("getPhoneNumber_" + str);
            f.this.u("getPhoneNumber");
        }

        @Override // deobf.com.roblox.client.implementation.wm.l.b
        public void onSuccess() {
        }
    }

    public class c implements deobf.unlinked.l.b {
        public c() {
        }

        @Override // deobf.com.roblox.client.implementation.wm.l.b
        public void onFailure(String str) {
            LoggingProtocol.g("supportsGetPhoneNumber_" + str);
            f.this.v("supportsGetPhoneNumber", "support", false);
        }

        @Override // deobf.com.roblox.client.implementation.wm.l.b
        public void onSuccess() {
            f.this.v("supportsGetPhoneNumber", "support", true);
        }
    }

    public static class d {

        public static f f35912a = new f(MessageBus.getInstance());
    }

    public static f z() {
        return d.f35912a;
    }

    public void h(Context context, deobf.unlinked.em.e eVar) {
        if (context == null) {
            this.f35903a.publishProtocolMethodResponse("IdentityProtocol", "getSMSOTP", new JSONObject(), 13, new HashMap());
        } else {
            eVar.a(context, "IdentityProtocol");
        }
    }

    public final /* synthetic */ void m(p pVar, deobf.com.roblox.protocols.mediapicker.g.a aVar) {
        r(pVar, aVar.getData());
    }

    public void n(final p pVar) {
        Log.i("IdentityProtocol", "Registering activity result for IdentityProtocol.");
        this.f35904c = new WeakReference<>(pVar.h(new deobf.com.roblox.protocols.mediapicker.h.j(), new deobf.com.roblox.protocols.mediapicker.g.b() { // from class: wm.a
            @Override // deobf.com.roblox.protocols.mediapicker.g.b
            public final void a(Object obj) {
                f.this.m(pVar, (deobf.com.roblox.protocols.mediapicker.g.a) obj);
            }
        }));
    }

    public void o(String str) {
        try {
            JSONObject jSONObject = new JSONObject();
            jSONObject.put("result", str);
            this.f35903a.publishProtocolMethodResponse("IdentityProtocol", "getSMSOTP", jSONObject, 0, new HashMap());
        } catch (JSONException e10) {
            Log.e("IdentityProtocol", "JSON exception while handling supports get sms otp: " + e10.toString());
            u("getSMSOTP");
        }
    }

    public void k(JSONObject jSONObject) {
        WeakReference<deobf.com.roblox.protocols.mediapicker.g.d<deobf.com.roblox.protocols.mediapicker.g.i>> weakReference;
        Log.d("IdentityProtocol", "onGetPhoneNumber: " + jSONObject.toString());
        if (this.b != null && (weakReference = this.f35904c) != null && weakReference.get() != null) {
            l.f().i(this.b, this.f35904c.get(), new b());
        } else {
            Log.e("IdentityProtocol", "Context or launcher is null while getting phone number!");
            x(BuildConfig.FLAVOR);
        }
    }

    public void i(JSONObject jSONObject) {
        Log.d("IdentityProtocol", "onGetSMSOTP: " + jSONObject.toString());
        h(this.b, new deobf.unlinked.em.e());
    }

    public void r(Context context, Intent intent) {
        if (context == null || intent == null) {
            return;
        }
        x(l.f().e(context, intent));
    }

    public void l(JSONObject jSONObject) {
        Log.d("IdentityProtocol", "onSupportsGetPhoneNumber: " + jSONObject.toString());
        if (this.b == null) {
            v("supportsGetPhoneNumber", "support", false);
        } else {
            l.f().g(this.b, new c());
        }
    }

    public void j(JSONObject jSONObject) {
        Log.d("IdentityProtocol", "onSupportsGetSMSOTP: " + jSONObject.toString());
        if (this.b == null) {
            v("supportsGetSMSOTP", "support", false);
        } else {
            l.f().g(this.b, new a());
        }
    }

    public final void u(String str) {
        this.f35903a.publishProtocolMethodResponse("IdentityProtocol", str, new JSONObject(), 13, new HashMap());
    }

    public final void v(String str, String str2, boolean z10) {
        String str3;
        try {
            JSONObject jSONObject = new JSONObject();
            jSONObject.put(str2, z10);
            str3 = str;
            try {
                this.f35903a.publishProtocolMethodResponse("IdentityProtocol", str3, jSONObject, 0, new HashMap());
            } catch (JSONException e10) {
                e = e10;
                Log.e("IdentityProtocol", "JSON exception in " + str3 + ": " + e.toString());
                this.f35903a.publishProtocolMethodResponse("IdentityProtocol", str3, new JSONObject(), 13, new HashMap());
            }
        } catch (JSONException e11) {
            e = e11;
            str3 = str;
        }
    }

    public void w(Context context) {
        this.b = context;
    }

    public void x(String str) {
        if (str != null) {
            try {
                if (!str.isEmpty()) {
                    JSONObject jSONObject = new JSONObject();
                    jSONObject.put("result", str);
                    this.f35903a.publishProtocolMethodResponse("IdentityProtocol", "getPhoneNumber", jSONObject, 0, new HashMap());
                    return;
                }
            } catch (JSONException e10) {
                Log.e("IdentityProtocol", "Exception while handling get phone number request", e10);
            }
        }
        u("getPhoneNumber");
    }

    @Deprecated
    public void y(deobf.com.roblox.protocols.mediapicker.g.d<deobf.com.roblox.protocols.mediapicker.g.i> dVar) {
        this.f35904c = new WeakReference<>(dVar);
    }

    public f(MessageBus messageBus) {
        this.f35903a = messageBus;
        this.f35905d = messageBus.subscribeProtocolMethodRequest("IdentityProtocol", "getSMSOTP", new Callback() { // from class: wm.b
            @Override // com.roblox.universalapp.messagebus.Callback
            public final void run(JSONObject jSONObject) {
                f.this.i(jSONObject);
            }
        });
        this.f35906e = messageBus.subscribeProtocolMethodRequest("IdentityProtocol", "supportsGetSMSOTP", new Callback() { // from class: wm.c
            @Override // com.roblox.universalapp.messagebus.Callback
            public final void run(JSONObject jSONObject) {
                f.this.j(jSONObject);
            }
        });
        this.f35907f = messageBus.subscribeProtocolMethodRequest("IdentityProtocol", "getPhoneNumber", new Callback() { // from class: wm.d
            @Override // com.roblox.universalapp.messagebus.Callback
            public final void run(JSONObject jSONObject) {
                f.this.k(jSONObject);
            }
        });
        this.f35908g = messageBus.subscribeProtocolMethodRequest("IdentityProtocol", "supportsGetPhoneNumber", new Callback() { // from class: wm.e
            @Override // com.roblox.universalapp.messagebus.Callback
            public final void run(JSONObject jSONObject) {
                f.this.l(jSONObject);
            }
        });
    }
}
