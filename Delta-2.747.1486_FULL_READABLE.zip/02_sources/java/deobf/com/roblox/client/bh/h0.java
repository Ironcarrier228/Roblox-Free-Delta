package deobf.com.roblox.client.bh;

// dex: classes2.dex
public final class h0 {

    public static int f4074a = 2130969829;
}
