package deobf.com.roblox.client.bh;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.os.Bundle;
import androidx.annotation.NonNull;
import org.greenrobot.eventbus.ThreadMode;

// dex: classes2.dex
public class d0 extends x0 {
    public d H0;

    public class a implements DialogInterface.OnCancelListener {
        public a() {
        }

        @Override // android.content.DialogInterface.OnCancelListener
        public void onCancel(DialogInterface dialogInterface) {
            deobf.unlinked.t0.d("logout", "no");
            dialogInterface.dismiss();
        }
    }

    public class b implements DialogInterface.OnClickListener {
        public b() {
        }

        @Override // android.content.DialogInterface.OnClickListener
        public void onClick(DialogInterface dialogInterface, int i10) {
            deobf.unlinked.t0.d("logout", "no");
            dialogInterface.dismiss();
        }
    }

    public class c implements DialogInterface.OnClickListener {
        public c() {
        }

        @Override // android.content.DialogInterface.OnClickListener
        public void onClick(DialogInterface dialogInterface, int i10) {
            deobf.unlinked.t0.d("logout", "yes");
            dialogInterface.dismiss();
            d0.this.H0.a();
        }
    }

    public interface d {
        void a();
    }

    public void B2(d dVar) {
        this.H0 = dVar;
    }

    @Override // deobf.com.roblox.client.bh.x0, deobf.com.withpersona.sdk2.inquiry.f4.o, deobf.com.withpersona.sdk2.inquiry.f4.q
    public void c1() {
        super.c1();
        deobf.com.roblox.client.mw.c.d().n(this);
    }

    @Override // deobf.com.roblox.client.bh.x0, deobf.com.withpersona.sdk2.inquiry.f4.o, deobf.com.withpersona.sdk2.inquiry.f4.q
    public void d1() {
        deobf.com.roblox.client.mw.c.d().p(this);
        super.d1();
    }

    @Override // deobf.com.withpersona.sdk2.inquiry.f4.o
    @NonNull
    public Dialog k2(Bundle bundle) {
        return new AlertDialog.Builder(p()).setMessage(q0.f4237g).setPositiveButton(q0.f4234f, new c()).setNegativeButton(q0.f4270r, new b()).setOnCancelListener(new a()).create();
    }

    @deobf.com.roblox.client.mw.j(threadMode = ThreadMode.MAIN)
    public void onNavigatToFeatureEvent(deobf.com.roblox.client.yh.g gVar) {
        if (i2()) {
            h2().dismiss();
        }
    }
}
