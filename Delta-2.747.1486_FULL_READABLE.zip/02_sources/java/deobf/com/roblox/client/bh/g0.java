package deobf.com.roblox.client.bh;

// dex: classes2.dex
public final class g0 {

    public static int f4070a = 2130772012;
    public static int b = 2130772013;

    public static int f4071c = 2130772014;
}
