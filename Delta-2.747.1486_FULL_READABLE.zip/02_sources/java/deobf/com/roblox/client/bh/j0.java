package deobf.com.roblox.client.bh;

// dex: classes2.dex
public final class j0 {

    public static int f4079a = 2131099650;
    public static int b = 2131099654;

    public static int f4080c = 2131099714;

    public static int f4081d = 2131099715;

    public static int f4082e = 2131099742;

    public static int f4083f = 2131099743;

    public static int f4084g = 2131099744;

    public static int f4085h = 2131099745;

    public static int f4086i = 2131099746;

    public static int f4087j = 2131099802;

    public static int f4088k = 2131099803;

    public static int f4089l = 2131099804;

    public static int f4090m = 2131099805;

    public static int f4091n = 2131099806;

    public static int f4092o = 2131100499;
}
