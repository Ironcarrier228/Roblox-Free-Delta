package deobf.com.roblox.client.bh;

import android.app.Dialog;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.appcompat.app.a;
import deobf.com.roblox.client.lk.e;

// dex: classes2.dex
public class x0 extends deobf.com.withpersona.sdk2.inquiry.f4.o implements e.b {
    public deobf.com.roblox.client.lk.e F0;

    public final String f4380v0 = "dialogHeight";

    public final String f4381w0 = "dialogWidth";

    public final String f4382x0 = "dialogGravity";

    public final String f4383y0 = "dialogOffsetY";

    public final String f4384z0 = "dialogOffsetX";
    public int A0 = 0;
    public int B0 = 0;
    public int C0 = 0;
    public int D0 = 0;
    public int E0 = 0;
    public deobf.unlinked.ui.c G0 = w2();

    public static /* synthetic */ class a {

        public static final /* synthetic */ int[] f4385a;

        static {
            int[] iArr = new int[deobf.unlinked.cm.a.values().length];
            f4385a = iArr;
            try {
                iArr[deobf.unlinked.cm.a.f5518c.ordinal()] = 1;
            } catch (NoSuchFieldError unused) {
            }
            try {
                f4385a[deobf.unlinked.cm.a.f5520e.ordinal()] = 2;
            } catch (NoSuchFieldError unused2) {
            }
            try {
                f4385a[deobf.unlinked.cm.a.f5519d.ordinal()] = 3;
            } catch (NoSuchFieldError unused3) {
            }
        }
    }

    @Override // deobf.com.withpersona.sdk2.inquiry.f4.o, deobf.com.withpersona.sdk2.inquiry.f4.q
    public void F0(Bundle bundle) {
        super.F0(bundle);
        Bundle t8 = t();
        if (t8 != null) {
            this.A0 = t8.getInt("dialogHeight", 0);
            this.B0 = t8.getInt("dialogWidth", 0);
            this.C0 = t8.getInt("dialogGravity", 0);
            this.D0 = t8.getInt("dialogOffsetY", 0);
            this.E0 = t8.getInt("dialogOffsetX", 0);
        }
    }

    public void T(int i10) {
        deobf.com.withpersona.sdk2.inquiry.f4.v p8 = p();
        if (p8 instanceof com.roblox.client.b) {
            ((com.roblox.client.b) p8).T(i10);
        }
    }

    public void V(String str) {
        deobf.com.withpersona.sdk2.inquiry.f4.v p8 = p();
        if (p8 instanceof com.roblox.client.b) {
            ((com.roblox.client.b) p8).V(str);
        }
    }

    @Override // deobf.com.withpersona.sdk2.inquiry.f4.o, deobf.com.withpersona.sdk2.inquiry.f4.q
    public void c1() {
        super.c1();
    }

    @Override // deobf.com.withpersona.sdk2.inquiry.f4.o, deobf.com.withpersona.sdk2.inquiry.f4.q
    public void d1() {
        super.d1();
    }

    @Override // deobf.com.withpersona.sdk2.inquiry.f4.q
    public void e1(@NonNull View view, Bundle bundle) {
        super.e1(view, bundle);
        deobf.com.roblox.client.lk.e eVar = new deobf.com.roblox.client.lk.e(this);
        this.F0 = eVar;
        eVar.b(k0());
    }

    @Override // deobf.com.roblox.client.lk.e.b
    public void g0(deobf.unlinked.cm.a aVar) {
        deobf.com.roblox.client.ok.q.b("rbx.theme", getClass().getSimpleName() + ".onThemeChanged() " + aVar);
        if (this.G0 != null) {
            int i10 = a.f4385a[aVar.ordinal()];
            this.G0.l(i10 != 1 ? i10 != 2 ? S().getColor(j0.f4084g) : S().getColor(j0.f4079a) : S().getColor(j0.f4090m));
        }
    }

    public boolean u2() {
        deobf.com.withpersona.sdk2.inquiry.f4.v p8 = p();
        if (p8 instanceof com.roblox.client.a) {
            return ((com.roblox.client.a) p8).N1();
        }
        deobf.com.roblox.client.ok.q.k("roblox.app", "The activity containing this fragment must be of type RobloxActivity!");
        return false;
    }

    public synchronized void v2(CharSequence charSequence) {
        deobf.com.withpersona.sdk2.inquiry.f4.v p8 = p();
        if (p8 == null) {
            return;
        }
        androidx.appcompat.app.a a10 = new a.C0021a(p8).a();
        TextView textView = new TextView(p8);
        String string = p8.getString(q0.W);
        int indexOf = charSequence.toString().indexOf(string);
        deobf.unlinked.pk.b.b(textView, charSequence.toString(), new deobf.unlinked.pk.c(p8, null, string, indexOf, indexOf + string.length()));
        textView.setTextSize(20.0f);
        textView.setEllipsize(null);
        a10.w(textView, 150, 100, 150, 100);
        a10.setCanceledOnTouchOutside(true);
        try {
            a10.show();
        } catch (WindowManager.BadTokenException unused) {
        }
    }

    public deobf.unlinked.ui.c w2() {
        return null;
    }

    public View x2(LayoutInflater layoutInflater, View view) {
        deobf.unlinked.ui.c cVar = this.G0;
        if (cVar == null) {
            return view;
        }
        View j10 = cVar.j(layoutInflater, this);
        this.G0.g().addView(view);
        return j10;
    }

    public void y2(int i10, int i11) {
        deobf.com.withpersona.sdk2.inquiry.f4.v p8 = p();
        if (p8 instanceof com.roblox.client.b) {
            ((com.roblox.client.b) p8).K1(i10, i11);
        }
    }

    @Override // deobf.com.withpersona.sdk2.inquiry.f4.o, deobf.com.withpersona.sdk2.inquiry.f4.q
    public void z0(Bundle bundle) {
        super.z0(bundle);
        Dialog h22 = h2();
        if (h22 != null) {
            Window window = h22.getWindow();
            if (window != null) {
                int i10 = this.A0;
                if (i10 != 0) {
                    int i11 = this.B0;
                    if (i11 == 0) {
                        i11 = -2;
                    }
                    window.setLayout(i11, i10);
                }
                window.setGravity(this.C0);
                WindowManager.LayoutParams attributes = window.getAttributes();
                attributes.y = this.D0;
                attributes.x = this.E0;
                window.setAttributes(attributes);
            }
            h22.setCanceledOnTouchOutside(true);
        }
    }

    public void z2(String str, int i10) {
        deobf.com.withpersona.sdk2.inquiry.f4.v p8 = p();
        if (p8 instanceof com.roblox.client.b) {
            ((com.roblox.client.b) p8).L1(str, i10);
        }
    }
}
