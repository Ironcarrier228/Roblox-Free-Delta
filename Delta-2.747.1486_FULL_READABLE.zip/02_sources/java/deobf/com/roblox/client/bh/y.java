package deobf.com.roblox.client.bh;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import androidx.annotation.NonNull;
import com.roblox.client.ActivityNativeMain;
import com.roblox.client.implementation.AppImplementations;
import com.roblox.client.startup.MainGameActivity;
import deobf.com.roblox.client.ei.n;

// dex: classes2.dex
public class y {

    public final String f4387a;
    public Object b;

    public static class a {

        public static final com.roblox.client.game.c f4388a = new com.roblox.client.game.c();
    }

    public static final class b {

        public static final y f4389a = new y();
    }

    public static y h() {
        return b.f4389a;
    }

    public deobf.com.roblox.client.ei.n a(deobf.unlinked.n.a aVar, n.b bVar) {
        Object obj = this.b;
        if (obj instanceof deobf.com.roblox.client.implementation.fk.b) {
            return ((deobf.com.roblox.client.implementation.fk.b) obj).a(aVar, bVar);
        }
        deobf.com.roblox.client.ok.q.i("rbx.main", "Using default DataModelNotifications");
        return new deobf.com.roblox.client.ei.n(aVar, bVar);
    }

    public deobf.com.roblox.client.startup.di.d b() {
        Object obj = this.b;
        if (obj instanceof deobf.com.roblox.client.implementation.fk.d) {
            return ((deobf.com.roblox.client.implementation.fk.d) obj).a();
        }
        deobf.com.roblox.client.ok.q.b("rbx.main", "Using default GenericWebFragment");
        return new deobf.com.roblox.client.startup.di.d();
    }

    public deobf.com.roblox.client.implementation.ih.a c(Context context) {
        Object obj = this.b;
        if (obj instanceof deobf.com.roblox.client.implementation.ih.b) {
            return ((deobf.com.roblox.client.implementation.ih.b) obj).getRtcAudioManager(context);
        }
        deobf.com.roblox.client.ok.q.b("rbx.main", "No AudioRtcManager");
        return null;
    }

    public deobf.com.roblox.client.dj.d d() {
        Object obj = this.b;
        if (obj instanceof deobf.com.roblox.client.implementation.fk.a) {
            return ((deobf.com.roblox.client.implementation.fk.a) obj).getAppsFlyerManager();
        }
        deobf.com.roblox.client.ok.q.b("rbx.main", "No AppsFlyer");
        return new deobf.com.roblox.client.dj.d();
    }

    @NonNull
    public deobf.com.withpersona.sdk2.inquiry.pm.r e() {
        Object obj = this.b;
        return obj instanceof deobf.unlinked.qh.a ? ((deobf.unlinked.qh.a) obj).a() : deobf.com.withpersona.sdk2.inquiry.pm.r.y();
    }

    @NonNull
    public com.roblox.client.game.c f() {
        Object obj = this.b;
        return obj instanceof deobf.com.roblox.client.implementation.fk.c ? ((deobf.com.roblox.client.implementation.fk.c) obj).a() : a.f4388a;
    }

    @NonNull
    public deobf.com.roblox.client.implementation.wm.f g() {
        Object obj = this.b;
        return obj instanceof deobf.unlinked.si.a ? ((deobf.unlinked.si.a) obj).getIdentityProtocol() : deobf.com.roblox.client.implementation.wm.f.z();
    }

    public Intent i(Context context) {
        Object obj = this.b;
        if (obj instanceof deobf.com.roblox.client.implementation.fk.e) {
            return ((deobf.com.roblox.client.implementation.fk.e) obj).a(context);
        }
        if (deobf.com.roblox.client.bi.h.a().Q1() && deobf.com.roblox.client.bi.h.a().D3()) {
            return new Intent(context, (Class<?>) MainGameActivity.class);
        }
        deobf.com.roblox.client.ok.q.i("rbx.main", "Using default Main class");
        return new Intent(context, (Class<?>) ActivityNativeMain.class);
    }

    public deobf.unlinked.oj.a j(Activity activity) {
        Object obj = this.b;
        if (obj instanceof deobf.com.roblox.client.implementation.fk.f) {
            return ((deobf.com.roblox.client.implementation.fk.f) obj).a(activity);
        }
        deobf.com.roblox.client.ok.q.b("rbx.main", "Using empty Midas");
        return new deobf.unlinked.oj.a();
    }

    @NonNull
    public deobf.com.roblox.client.implementation.bn.k k() {
        Object obj = this.b;
        return obj instanceof deobf.unlinked.ij.a ? ((deobf.unlinked.ij.a) obj).getPermissionsProtocol() : deobf.com.roblox.client.implementation.bn.l.U();
    }

    public deobf.com.roblox.universalapp.systemtheme.cl.f l() {
        Object obj = this.b;
        if (obj instanceof deobf.com.roblox.client.implementation.fk.h) {
            return ((deobf.com.roblox.client.implementation.fk.h) obj).a();
        }
        deobf.com.roblox.client.ok.q.i("rbx.main", "Using default Provider");
        return new deobf.com.roblox.universalapp.systemtheme.cl.a();
    }

    public deobf.com.roblox.client.pushnotification.rj.s m() {
        Object obj = this.b;
        if (obj instanceof deobf.com.roblox.client.implementation.fk.i) {
            return ((deobf.com.roblox.client.implementation.fk.i) obj).a();
        }
        deobf.com.roblox.client.ok.q.b("rbx.main", "No default push registrar");
        return null;
    }

    public deobf.com.withpersona.sdk2.inquiry.sw.d<deobf.com.withpersona.sdk2.inquiry.mv.i0> n(deobf.com.roblox.platform.http.kl.d dVar) {
        Object obj = this.b;
        if (obj instanceof deobf.com.roblox.client.implementation.fk.g) {
            return ((deobf.com.roblox.client.implementation.fk.g) obj).a(dVar);
        }
        deobf.com.roblox.client.ok.q.b("rbx.main", "No default push registration call");
        return null;
    }

    public Intent o(Context context) {
        Object obj = this.b;
        if (obj instanceof deobf.com.roblox.client.implementation.fk.j) {
            return ((deobf.com.roblox.client.implementation.fk.j) obj).a(context);
        }
        throw new RuntimeException("No StartActivityIntentFactory interface implemented");
    }

    public deobf.unlinked.dk.a p() {
        Object obj = this.b;
        if (obj instanceof deobf.com.roblox.client.implementation.fk.k) {
            return ((deobf.com.roblox.client.implementation.fk.k) obj).a();
        }
        deobf.com.roblox.client.ok.q.b("rbx.main", "Using empty TSS");
        return new deobf.unlinked.dk.a();
    }

    public y() {
        this.f4387a = "com.roblox.client.implementation.AppImplementations";
        try {
            this.b = AppImplementations.class.newInstance();
        } catch (ClassNotFoundException unused) {
            deobf.com.roblox.client.ok.q.k("rbx.main", "Failed to find implementation class");
        } catch (IllegalAccessException | InstantiationException unused2) {
            deobf.com.roblox.client.ok.q.k("rbx.main", "Failed to instantiate implementation");
        }
    }
}
