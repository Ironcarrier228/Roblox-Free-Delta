package deobf.com.roblox.client.bh;

// dex: classes2.dex
public final class l0 {
    public static int A = 2131231048;
    public static int B = 2131231049;

    public static int f4102a = 2131230840;
    public static int b = 2131230856;

    public static int f4103c = 2131230899;

    public static int f4104d = 2131230900;

    public static int f4105e = 2131230901;

    public static int f4106f = 2131230909;

    public static int f4107g = 2131230910;

    public static int f4108h = 2131230913;

    public static int f4109i = 2131230919;

    public static int f4110j = 2131230991;

    public static int f4111k = 2131231019;

    public static int f4112l = 2131231020;

    public static int f4113m = 2131231031;

    public static int f4114n = 2131231035;

    public static int f4115o = 2131231036;

    public static int f4116p = 2131231037;

    public static int f4117q = 2131231038;

    public static int f4118r = 2131231039;

    public static int f4119s = 2131231040;

    public static int f4120t = 2131231041;

    public static int f4121u = 2131231042;

    public static int f4122v = 2131231043;

    public static int f4123w = 2131231044;

    public static int f4124x = 2131231045;

    public static int f4125y = 2131231046;

    public static int f4126z = 2131231047;
}
