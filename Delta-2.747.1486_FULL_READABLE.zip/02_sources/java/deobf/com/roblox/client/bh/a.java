package deobf.com.roblox.client.bh;

// dex: classes2.dex
public final /* synthetic */ class a {
}
