package deobf.com.roblox.client.bh;

// dex: classes2.dex
public interface f0 {
    void H();

    boolean b();

    void f(boolean z10);

    void l();
}
