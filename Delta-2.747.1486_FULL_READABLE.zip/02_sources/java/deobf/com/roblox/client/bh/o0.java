package deobf.com.roblox.client.bh;

// dex: classes2.dex
public final class o0 {

    public static int f4212a = 2131623936;
    public static int b = 2131623937;

    public static int f4213c = 2131623938;

    public static int f4214d = 2131623939;
}
