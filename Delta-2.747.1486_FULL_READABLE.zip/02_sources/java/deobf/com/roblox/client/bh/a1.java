package deobf.com.roblox.client.bh;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.os.Build;
import android.provider.Settings;
import android.text.TextUtils;
import com.appsflyer.sdk_base.referrer.Payload;
import com.github.luben.zstd.BuildConfig;
import com.roblox.engine.jni.NativeSettingsInterface;
import com.roblox.protocols.telemetrybindingsplatforminterface.generated.TelemetryBackend;
import com.roblox.universalapp.logging.LoggingProtocol;
import deobf.com.roblox.client.startup.dl.e;
import deobf.com.roblox.universalapp.facialageestimation.fn.c;
import java.util.Set;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import deobf.com.google.android.gms.ob.ze;

// dex: classes2.dex
public class a1 {
    public static deobf.com.roblox.client.ok.e b;

    public static boolean f4023g;

    public static boolean f4028l;

    public static Pattern f4033q;

    public static boolean f4034r;

    public static SharedPreferences f4035s;

    public static String f4036t;

    public static long f4037u;

    public static boolean f4038v;

    public static final AtomicBoolean f4018a = new AtomicBoolean(false);

    public static String f4019c = BuildConfig.FLAVOR;

    public static String f4020d = BuildConfig.FLAVOR;

    public static String f4021e = BuildConfig.FLAVOR;

    public static boolean f4022f = false;

    public static String f4024h = null;

    public static boolean f4025i = false;

    public static String f4026j = null;

    public static boolean f4027k = false;

    public static boolean f4029m = false;

    public static String f4030n = null;

    public static String f4031o = null;

    public static boolean f4032p = false;

    static {
        f4023g = false;
        K0("www.roblox.com");
        P0(BuildConfig.FLAVOR);
        if (!f4019c.isEmpty()) {
            f4023g = true;
        }
        f4034r = false;
        f4035s = null;
        f4036t = BuildConfig.FLAVOR;
        f4037u = 0L;
        f4038v = false;
    }

    public static String A(String str) {
        return g() + "games/?SortFilter=" + str;
    }

    public static String A0(long j10) {
        return g() + "my/messages/#!/inbox?conversationId=" + j10;
    }

    public static String B(Context context) {
        return U(context).getString("moduleName", BuildConfig.FLAVOR);
    }

    public static String B0() {
        return d0("profile");
    }

    public static String C(Context context) {
        SharedPreferences U = U(context);
        String string = U.getString("engine", BuildConfig.FLAVOR);
        U.edit().remove("engine").apply();
        return string;
    }

    public static void C0() {
        Set a10;
        e.b q8 = deobf.com.roblox.client.startup.dl.e.q();
        try {
            a10 = deobf.android.view.ze.a(new Object[]{TelemetryBackend.COUNTER});
            deobf.com.roblox.universalapp.facialageestimation.fn.c.d(new deobf.com.withpersona.sdk2.inquiry.c.a("cookie_versionb_webview_pull", a10).j(2026, 10, 13).d(), new deobf.com.withpersona.sdk2.inquiry.c.b().b("result", q8.name()).l());
        } catch (UnsatisfiedLinkError e10) {
            deobf.com.roblox.client.ok.q.k("roblox.config", "pullSecurityCookieFromWebView: telemetry failed: " + e10);
        }
    }

    public static String D(Context context) {
        SharedPreferences U = U(context);
        String string = U.getString("channel", BuildConfig.FLAVOR);
        if (s.c(context)) {
            U.edit().remove("channel").apply();
        }
        return string;
    }

    public static String D0() {
        return "https://ecsv2." + P() + "mobile/pbe";
    }

    public static String E() {
        return "AppAndroidV";
    }

    public static boolean E0() {
        return false;
    }

    public static String F() {
        return f4024h;
    }

    public static String F0() {
        return g() + "upgrades/robux";
    }

    public static String G() {
        return b.c();
    }

    public static String G0(String str) {
        return g() + "catalog?Keyword=" + str;
    }

    public static String H() {
        return b.d();
    }

    public static String H0(String str) {
        return g() + "games/?Keyword=" + str;
    }

    public static String I() {
        return f4021e;
    }

    public static String I0(String str) {
        return g() + "search/groups?keyword=" + str;
    }

    public static String J() {
        return f4020d;
    }

    public static String J0(String str) {
        return g() + "users/search?keyword=" + str;
    }

    public static String K() {
        return "Development";
    }

    public static void K0(String str) {
        deobf.com.roblox.client.ok.q.h("roblox.config", "setBaseUrl() " + b + " => " + str);
        b = new deobf.com.roblox.client.ok.e(str);
        f4033q = Pattern.compile(u0(), 2);
    }

    public static SharedPreferences L(Context context) {
        return deobf.com.roblox.client.ok.z.e(context).c("cached_app_settings_prefs");
    }

    public static boolean L0(deobf.com.roblox.client.provider.ph.c cVar) {
        if (cVar == null) {
            return false;
        }
        String a10 = cVar.a();
        if (TextUtils.isEmpty(a10)) {
            return false;
        }
        K0(a10);
        return true;
    }

    public static String M() {
        return "GoogleAndroidApp";
    }

    public static void M0(String str) {
        if (str != null) {
            f4024h = new deobf.com.roblox.client.ok.f().d(str);
        } else {
            f4024h = null;
        }
    }

    public static String N() {
        return deobf.com.roblox.client.ok.t.j() ? "Android-TENCENTPlayer-Crash" : q0() ? "Quest-ROBLOXPlayer-Crash" : "Android-ROBLOXPlayer-Crash";
    }

    public static void N0(String str) {
        deobf.com.roblox.client.ok.q.h("roblox.config", "setBinaryChannelEngineLibName() " + f4021e + " => " + str);
        if (str == null) {
            str = BuildConfig.FLAVOR;
        }
        f4021e = str;
    }

    public static String O() {
        return b.a();
    }

    public static void O0(String str) {
        deobf.com.roblox.client.ok.q.h("roblox.config", "setBinaryChannelModuleName() " + f4020d + " => " + str);
        if (str == null) {
            str = BuildConfig.FLAVOR;
        }
        f4020d = str;
    }

    public static String P() {
        return b.b();
    }

    public static void P0(String str) {
        if (str == null || deobf.unlinked.jh.c.e(str)) {
            return;
        }
        deobf.com.roblox.client.ok.q.h("roblox.config", "setChannel() " + f4019c + " => " + str);
        f4019c = str.trim();
    }

    public static String Q(Context context) {
        return "{\"searchParams\":{\"searchType\":\"Players\"},\"url\":\"" + R() + "\",\"title\":\"" + context.getString(q0.C) + "\",\"animated\":true}";
    }

    public static void Q0(boolean z10) {
        f4034r = z10;
    }

    public static String R() {
        return g() + "/users/friends#!/friend-requests";
    }

    public static boolean R0(Configuration configuration) {
        return l0() && configuration.orientation == 2;
    }

    public static String S() {
        return "application/json;charset=UTF-8";
    }

    public static void S0(Context context) {
        f4027k = context.getResources().getBoolean(i0.f4076a);
        f4028l = context.getPackageManager().hasSystemFeature("org.chromium.arc.device_management");
        f4029m = context.getPackageManager().hasSystemFeature("android.software.leanback");
    }

    public static SharedPreferences T() {
        return f4035s;
    }

    public static void T0() {
        Set a10;
        Set a11;
        boolean L2 = deobf.com.roblox.client.bi.h.a().L2();
        if (L2) {
            LoggingProtocol.g("cookie_read_begin");
        }
        String d10 = deobf.com.roblox.client.startup.dl.j.e().d(g());
        if (L2) {
            LoggingProtocol.g("cookie_read_end");
        }
        deobf.com.roblox.client.startup.ik.w0.l();
        if (d10 == null) {
            d10 = BuildConfig.FLAVOR;
        }
        NativeSettingsInterface.nativeSetMultipleCookies(g(), d10);
        if (deobf.com.roblox.client.bi.h.a().W1() && f4018a.compareAndSet(false, true)) {
            boolean contains = d10.contains(".ROBLOSECURITY=_");
            boolean h10 = deobf.com.roblox.client.dj.h.h();
            String j10 = deobf.com.roblox.client.startup.dl.e.j();
            boolean u8 = u();
            TelemetryBackend telemetryBackend = TelemetryBackend.COUNTER;
            a10 = deobf.android.view.ze.a(new Object[]{telemetryBackend});
            deobf.com.roblox.universalapp.facialageestimation.fn.c.d(new deobf.com.withpersona.sdk2.inquiry.c.a("cookie_versionb_migration_result", a10).j(2026, 6, 24).d(), new deobf.com.withpersona.sdk2.inquiry.c.b().b("has_roblosecurity", String.valueOf(contains)).b("has_cached_user", String.valueOf(h10)).b("webview_state", j10).l());
            a11 = deobf.android.view.ze.a(new Object[]{telemetryBackend});
            deobf.com.roblox.universalapp.facialageestimation.fn.c.d(new deobf.com.withpersona.sdk2.inquiry.c.a("cookie_versionb_engine_push", a11).j(2026, 6, 24).d(), new deobf.com.withpersona.sdk2.inquiry.c.b().b("has_roblosecurity", String.valueOf(contains)).b("has_cached_user", String.valueOf(h10)).b("engine_has_roblosecurity", String.valueOf(u8)).l());
            deobf.com.roblox.client.ok.q.h("roblox.config", "updateNativeCookies: pushed len=" + d10.length() + " shellHasRoblosecurity=" + contains + " engineHasRoblosecurity=" + u8 + " webviewState=" + j10);
        }
    }

    public static SharedPreferences U(Context context) {
        return deobf.com.roblox.client.ok.z.a(context, "prefs");
    }

    public static void U0() {
        NativeSettingsInterface.nativeSetCacheDirectory(f4030n);
        NativeSettingsInterface.nativeSetFilesDirectory(f4031o);
    }

    public static String V(String str) {
        Matcher matcher = f4033q.matcher(str);
        if (matcher.matches()) {
            return matcher.group(1);
        }
        return null;
    }

    public static void V0() {
        NativeSettingsInterface.nativeSetHttpClientProxy(System.getProperty("http.proxyHost", BuildConfig.FLAVOR), Long.getLong("http.proxyPort", 0L).longValue());
    }

    public static String W() {
        return f4019c;
    }

    public static void W0() {
        X0(true);
    }

    public static String X() {
        return "my/account#!/notifications";
    }

    public static void X0(boolean z10) {
        NativeSettingsInterface.nativeSetExceptionReasonFilename(z());
        NativeSettingsInterface.nativeSetBaseUrl(g(), h());
        NativeSettingsInterface.nativeSetRobloxChannel(W());
        if (deobf.com.roblox.client.bi.h.a().P0()) {
            NativeSettingsInterface.nativeOverrideChannelPlatformName2(M());
        } else {
            NativeSettingsInterface.nativeOverrideChannelPlatformName(M());
        }
        if (f4030n == null) {
            throw new NullPointerException("Missing cacheDirectory");
        }
        U0();
        NativeSettingsInterface.nativeInitFastLog();
        NativeSettingsInterface.nativeSetRobloxVersion(e1());
        deobf.com.roblox.client.ok.c.f28242c.a(new Runnable() { // from class: bh.z0
            @Override // java.lang.Runnable
            public final void run() {
                deobf.androidx.camera.view.a1.a();
            }
        }, deobf.androidx.camera.view.pe.a0.a());
        h0();
        if (deobf.com.roblox.client.startup.ik.k0.T()) {
            NativeSettingsInterface.nativeSetUserId("1");
        }
        if (z10) {
            T0();
        }
    }

    public static boolean Y() {
        return f4022f;
    }

    public static void Y0() {
        NativeSettingsInterface.nativeSetPlatformHeadersWithIdfa(f4036t, "googleplay", deobf.com.roblox.client.ok.c.d());
    }

    public static String Z(long j10) {
        return deobf.com.roblox.client.ok.b0.b("%sv1/users/%d", k(), Long.valueOf(j10));
    }

    public static String Z0() {
        return c() + "v1/mobile-client-version?appVersion=" + E() + e1();
    }

    public static /* synthetic */ void a() {
        Y0();
        LoggingProtocol.g("get_advertisingid_end");
    }

    public static String a0(long j10) {
        return g() + "users/" + j10 + "/friends#!/friend-requests";
    }

    public static String a1() {
        return f4026j;
    }

    public static String b() {
        return g().replace("www.", "apis.");
    }

    public static String b0(long j10) {
        return g() + "users/" + j10 + "/friends#!/friends";
    }

    public static String b1() {
        return k() + "v1/users/authenticated";
    }

    public static String c() {
        return "https://clientsettingscdn." + P();
    }

    public static String c0(long j10) {
        return g() + "users/" + j10 + "/profile";
    }

    public static String c1() {
        return l() + "v1/google/validate";
    }

    public static String d(boolean z10) {
        StringBuilder sb2 = new StringBuilder();
        sb2.append(c());
        sb2.append("v2/settings");
        if (z10) {
            sb2.append("-compressed");
        }
        sb2.append("/application/");
        sb2.append(M());
        String W = W();
        if (!W.isEmpty()) {
            sb2.append("/bucket/");
            sb2.append(W);
        }
        if (z10) {
            sb2.append("/");
            sb2.append("c0101e39d0563e9590a0ab27f90e91ea36d6bcfdf99add6915870c306a286479");
            sb2.append(".dcz");
        }
        return sb2.toString();
    }

    public static String d0(String str) {
        long g10 = deobf.com.roblox.client.dj.h.e().g();
        if (g10 == -1) {
            return g() + "users/" + str;
        }
        return g() + "users/" + g10 + "/" + str;
    }

    public static String d1() {
        return l() + "v1/google/purchase";
    }

    public static String e() {
        return b() + "v1/attribution-eligibility";
    }

    public static String e0() {
        return g() + "home";
    }

    public static String e1() {
        return "2.747.1486";
    }

    public static String f() {
        return j() + "v1/user/currency";
    }

    public static boolean f0() {
        return f4019c.isEmpty();
    }

    public static String g() {
        return "https://" + b.d();
    }

    public static void g0(Context context) {
        f4031o = context.getFilesDir().getAbsolutePath();
        f4030n = context.getCacheDir().getAbsolutePath();
        f4036t = Settings.Secure.getString(context.getContentResolver(), "android_id");
    }

    public static String h() {
        if (f4024h == null) {
            return "https://api." + P();
        }
        return "https://" + f4024h;
    }

    public static void h0() {
    }

    public static String i() {
        return "https://auth." + P();
    }

    public static void i0(Context context, deobf.com.roblox.client.provider.ph.c cVar) {
        String string = Settings.Global.getString(context.getContentResolver(), "roblox_channel_override");
        if (string != null) {
            string = string.trim();
        }
        boolean z10 = (f4023g || TextUtils.isEmpty(string)) ? false : true;
        if (z10) {
            deobf.com.roblox.client.ok.q.h("roblox.config", "Using channel from launch override: " + string);
            P0(string);
        }
        if (cVar != null) {
            if (!f4023g && !z10) {
                P0(cVar.h());
            }
            String a10 = cVar.a();
            if (L0(cVar)) {
                deobf.com.roblox.client.ok.q.h("roblox.config", "initConfig: Set base-URL from: " + b + " => " + a10);
            }
        }
        M0(deobf.com.roblox.client.ok.z.b(context, "configure_dev_roblox", true).getString("BaseApiUrl", null));
        f4035s = U(context);
        if (deobf.com.roblox.client.bi.h.a().w3()) {
            O0(B(context));
            N0(C(context));
            f4022f = U(context).getString("supportsAndroidBinaries", BuildConfig.FLAVOR).equals("true");
        }
        String D = D(context);
        if (!f4023g && !z10 && !D.isEmpty()) {
            deobf.com.roblox.client.ok.q.h("roblox.config", "Found channel from preferences: " + D);
            P0(D);
        }
        S0(context);
        if (cVar == null || TextUtils.isEmpty(cVar.k())) {
            f4026j = m(context);
            return;
        }
        f4026j = cVar.k();
        f4032p = true;
        deobf.com.roblox.client.ok.q.k("roblox.config", "Using a custom user agent: " + f4026j);
    }

    public static String j() {
        return "https://economy." + P();
    }

    public static boolean j0() {
        return Build.VERSION.SDK_INT >= 29;
    }

    public static String k() {
        return "https://users." + P();
    }

    public static boolean k0() {
        return f4028l;
    }

    public static String l() {
        return g().replace("www.", "billing.");
    }

    public static boolean l0() {
        return (!deobf.com.roblox.client.bi.h.a().V4() || k0() || q0()) ? false : true;
    }

    public static String m(Context context) {
        return n(context, Payload.SOURCE_GOOGLE);
    }

    public static boolean m0(String str) {
        String V = V(str);
        return (!n0(str)) & ((V == null || V.isEmpty()) ? false : true);
    }

    public static String n(Context context, String str) {
        return deobf.com.roblox.universalapp.systemtheme.cl.g.a(context, e1(), "AppleWebKit/537.36", "GlobalDist", "GooglePlayStore", "questvr".equals(str), p0(), k0(), t0());
    }

    public static boolean n0(String str) {
        return str.contains("Login/FulfillConstraint.aspx") || str.toLowerCase().contains("login/maintenance");
    }

    public static String o() {
        return g() + "mobile-app-upgrades/native-ios/bc";
    }

    public static boolean o0() {
        if (deobf.com.roblox.client.bi.h.a().N4()) {
            return true;
        }
        return deobf.com.roblox.client.bi.h.a().A5() && r0();
    }

    public static String p(String str, String str2) {
        return deobf.com.roblox.client.ok.b0.b("%scaptcha/app/login?credentialsType=%s&credentialsValue=%s&hybrid-return-token=1", g(), str, str2);
    }

    public static boolean p0() {
        return !f4027k;
    }

    public static String q() {
        return deobf.com.roblox.client.ok.b0.b("%scaptcha/app/signup?hybrid-return-token=1", g());
    }

    public static boolean q0() {
        return false;
    }

    public static boolean r(Context context) {
        return U(context).getBoolean("under13", true);
    }

    public static boolean r0() {
        return f4027k;
    }

    public static void s(Context context) {
        U(context).edit().remove("moduleName").apply();
    }

    public static boolean s0() {
        return b.c().contains(".robloxlabs.com");
    }

    public static String t() {
        if (!f4032p) {
            return "GlobalDist";
        }
        Matcher matcher = Pattern.compile("\\b[A-Za-z]+Dist\\b").matcher(f4026j);
        if (matcher.find()) {
            return matcher.group();
        }
        deobf.com.roblox.client.ok.q.e("roblox.config", "Unable to find correct distributor type inside customized user agent.");
        return "GlobalDist";
    }

    public static boolean t0() {
        return f4029m;
    }

    public static boolean u() {
        if (!deobf.com.roblox.client.bi.h.a().W1()) {
            return false;
        }
        try {
            String nativeGetCookiesInNetscapeFormat = NativeSettingsInterface.nativeGetCookiesInNetscapeFormat(g());
            if (nativeGetCookiesInNetscapeFormat != null) {
                if (nativeGetCookiesInNetscapeFormat.contains(".ROBLOSECURITY")) {
                    return true;
                }
            }
            return false;
        } catch (Throwable th2) {
            deobf.com.roblox.client.ok.q.k("roblox.config", "engineHasSecurityCookie: read-back failed: " + th2);
            return false;
        }
    }

    public static String u0() {
        return "^(https?://" + Pattern.quote(H()) + "(?:login|newlogin))(?!/reset-password).*";
    }

    public static String v(String str, int i10) {
        return "&counterName=" + str + "&amount=" + i10;
    }

    public static String v0() {
        return i() + "/v2/logout";
    }

    public static String w() {
        return "https://ephemeralcounters.api." + P() + "v1.1/Counters/Increment/?apiKey=76E5A40C-3AE1-4028-9F10-7C62520BD94F";
    }

    public static String w0() {
        return g() + "my/messages/#!/inbox";
    }

    public static String x(String str, long j10) {
        return "&sequenceName=" + str + "&value=" + j10;
    }

    public static boolean x0() {
        return f4034r;
    }

    public static String y() {
        return "https://ephemeralcounters.api." + P() + "v1.0/SequenceStatistics/AddToSequence?apiKey=76E5A40C-3AE1-4028-9F10-7C62520BD94F";
    }

    public static String y0() {
        return g() + deobf.com.roblox.client.bi.h.a().b2();
    }

    public static String z() {
        return "exception_reason.txt";
    }

    public static String z0() {
        return g() + "login/resetpasswordrequest/success";
    }
}
