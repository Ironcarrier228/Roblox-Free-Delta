package deobf.com.roblox.client.bh;

// dex: classes2.dex
public final class q0 {
    public static int A = 2131886118;
    public static int A0 = 2131886230;
    public static int A1 = 2131886289;
    public static int B = 2131886119;
    public static int B0 = 2131886231;
    public static int B1 = 2131886290;
    public static int C = 2131886120;
    public static int C0 = 2131886232;
    public static int C1 = 2131886291;
    public static int D = 2131886121;
    public static int D0 = 2131886233;
    public static int D1 = 2131886292;
    public static int E = 2131886122;
    public static int E0 = 2131886234;
    public static int E1 = 2131886293;
    public static int F = 2131886124;
    public static int F0 = 2131886235;
    public static int F1 = 2131886294;
    public static int G = 2131886125;
    public static int G0 = 2131886236;
    public static int G1 = 2131886295;
    public static int H = 2131886126;
    public static int H0 = 2131886237;
    public static int H1 = 2131886296;
    public static int I = 2131886128;
    public static int I0 = 2131886238;
    public static int I1 = 2131886298;
    public static int J = 2131886130;
    public static int J0 = 2131886240;
    public static int J1 = 2131886299;
    public static int K = 2131886131;
    public static int K0 = 2131886241;
    public static int K1 = 2131886300;
    public static int L = 2131886132;
    public static int L0 = 2131886242;
    public static int L1 = 2131886301;
    public static int M = 2131886134;
    public static int M0 = 2131886245;
    public static int M1 = 2131886302;
    public static int N = 2131886135;
    public static int N0 = 2131886246;
    public static int N1 = 2131886307;
    public static int O = 2131886137;
    public static int O0 = 2131886247;
    public static int O1 = 2131886615;
    public static int P = 2131886138;
    public static int P0 = 2131886248;
    public static int Q = 2131886139;
    public static int Q0 = 2131886249;
    public static int R = 2131886140;
    public static int R0 = 2131886250;
    public static int S = 2131886141;
    public static int S0 = 2131886252;
    public static int T = 2131886142;
    public static int T0 = 2131886253;
    public static int U = 2131886143;
    public static int U0 = 2131886254;
    public static int V = 2131886144;
    public static int V0 = 2131886255;
    public static int W = 2131886145;
    public static int W0 = 2131886256;
    public static int X = 2131886148;
    public static int X0 = 2131886257;
    public static int Y = 2131886178;
    public static int Y0 = 2131886258;
    public static int Z = 2131886180;
    public static int Z0 = 2131886259;

    public static int f4220a = 2131886083;

    public static int f4221a0 = 2131886181;

    public static int f4222a1 = 2131886260;
    public static int b = 2131886084;

    public static int f4223b0 = 2131886182;

    public static int f4224b1 = 2131886261;

    public static int f4225c = 2131886088;

    public static int f4226c0 = 2131886183;

    public static int f4227c1 = 2131886262;

    public static int f4228d = 2131886089;

    public static int f4229d0 = 2131886184;

    public static int f4230d1 = 2131886263;

    public static int f4231e = 2131886090;

    public static int f4232e0 = 2131886185;

    public static int f4233e1 = 2131886264;

    public static int f4234f = 2131886091;

    public static int f4235f0 = 2131886186;

    public static int f4236f1 = 2131886265;

    public static int f4237g = 2131886092;

    public static int f4238g0 = 2131886187;

    public static int f4239g1 = 2131886266;

    public static int f4240h = 2131886093;

    public static int f4241h0 = 2131886188;

    public static int f4242h1 = 2131886267;

    public static int f4243i = 2131886094;

    public static int f4244i0 = 2131886189;

    public static int f4245i1 = 2131886268;

    public static int f4246j = 2131886095;

    public static int f4247j0 = 2131886190;

    public static int f4248j1 = 2131886269;

    public static int f4249k = 2131886096;

    public static int f4250k0 = 2131886191;

    public static int f4251k1 = 2131886270;

    public static int f4252l = 2131886097;

    public static int f4253l0 = 2131886192;

    public static int f4254l1 = 2131886271;

    public static int f4255m = 2131886098;

    public static int f4256m0 = 2131886193;

    public static int f4257m1 = 2131886272;

    public static int f4258n = 2131886099;

    public static int f4259n0 = 2131886194;

    public static int f4260n1 = 2131886273;

    public static int f4261o = 2131886100;

    public static int f4262o0 = 2131886195;

    public static int f4263o1 = 2131886274;

    public static int f4264p = 2131886101;

    public static int f4265p0 = 2131886196;

    public static int f4266p1 = 2131886275;

    public static int f4267q = 2131886102;

    public static int f4268q0 = 2131886197;

    public static int f4269q1 = 2131886276;

    public static int f4270r = 2131886105;

    public static int f4271r0 = 2131886198;

    public static int f4272r1 = 2131886277;

    public static int f4273s = 2131886106;

    public static int f4274s0 = 2131886199;

    public static int f4275s1 = 2131886278;

    public static int f4276t = 2131886107;

    public static int f4277t0 = 2131886201;

    public static int f4278t1 = 2131886279;

    public static int f4279u = 2131886109;

    public static int f4280u0 = 2131886206;

    public static int f4281u1 = 2131886280;

    public static int f4282v = 2131886110;

    public static int f4283v0 = 2131886208;

    public static int f4284v1 = 2131886282;

    public static int f4285w = 2131886111;

    public static int f4286w0 = 2131886215;

    public static int f4287w1 = 2131886283;

    public static int f4288x = 2131886112;

    public static int f4289x0 = 2131886222;

    public static int f4290x1 = 2131886285;

    public static int f4291y = 2131886116;

    public static int f4292y0 = 2131886225;

    public static int f4293y1 = 2131886287;

    public static int f4294z = 2131886117;

    public static int f4295z0 = 2131886226;

    public static int f4296z1 = 2131886288;
}
