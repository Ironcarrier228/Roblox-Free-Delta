package deobf.com.roblox.client.bh;

// dex: classes2.dex
public final class r0 {

    public static int f4300a = 2131952287;
    public static int b = 2131952294;

    public static int f4301c = 2131952299;
}
