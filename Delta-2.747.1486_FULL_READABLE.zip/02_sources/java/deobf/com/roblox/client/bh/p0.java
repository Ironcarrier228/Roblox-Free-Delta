package deobf.com.roblox.client.bh;

// dex: classes2.dex
public final class p0 {

    public static int f4218a = 2131689472;
    public static int b = 2131689474;
}
