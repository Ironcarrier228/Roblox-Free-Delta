package deobf.com.roblox.client.bh;

import deobf.com.roblox.client.al.d;
import com.github.luben.zstd.BuildConfig;
import com.roblox.protocols.telemetrybindingsplatforminterface.generated.TelemetryBackend;
import com.roblox.protocols.telemetrybindingsplatforminterface.generated.TelemetryConfig;
import com.roblox.protocols.telemetrybindingsplatforminterface.generated.TelemetryStandardizedField;
import deobf.com.roblox.universalapp.facialageestimation.fn.c;
import kotlin.Metadata;
import kotlin.jvm.functions.Function0;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(d1 = {"\u0000$\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0005\u0018\u00002\u00020\u0001B\u0007¢\u0006\u0004\b\u0002\u0010\u0003J#\u0010\b\u001a\u00020\u00072\b\u0010\u0005\u001a\u0004\u0018\u00010\u00042\b\u0010\u0006\u001a\u0004\u0018\u00010\u0004H\u0016¢\u0006\u0004\b\b\u0010\tR\u001b\u0010\u000e\u001a\u00020\n8BX\u0082\u0084\u0002¢\u0006\f\n\u0004\b\b\u0010\u000b\u001a\u0004\b\f\u0010\r¨\u0006\u000f"}, d2 = {"Lbh/x;", "Lal/d$b;", "<init>", "()V", BuildConfig.FLAVOR, "moduleID", "functionName", BuildConfig.FLAVOR, deobf.android.view.xe.a.f36648e, "(Ljava/lang/String;Ljava/lang/String;)V", "Lcom/roblox/protocols/telemetrybindingsplatforminterface/generated/TelemetryConfig;", "Lzt/h;", "c", "()Lcom/roblox/protocols/telemetrybindingsplatforminterface/generated/TelemetryConfig;", "nativeAndroidHybridModuleCommandCounter", "NativeShell_googleProdRelease"}, k = 1, mv = {2, 2, 0}, xi = 48)
// dex: classes2.dex
public final class x implements d.b {

    @NotNull
    public final deobf.com.withpersona.sdk2.inquiry.zt.h nativeAndroidHybridModuleCommandCounter = deobf.com.withpersona.sdk2.inquiry.zt.i.a(new Function0() { // from class: bh.w
        @Override // kotlin.jvm.functions.Function0
        public final Object invoke() {
            TelemetryConfig d10;
            d10 = x.d();
            return d10;
        }
    });

    public static final TelemetryConfig d() {
        deobf.com.roblox.universalapp.facialageestimation.fn.c cVar = deobf.com.roblox.universalapp.facialageestimation.fn.c.f16191a;
        deobf.com.withpersona.sdk2.inquiry.c.a aVar = new deobf.com.withpersona.sdk2.inquiry.c.a("NativeAndroidHybridModuleCommandCounter", kotlin.collections.p0.c(TelemetryBackend.COUNTER));
        aVar.b(2025, 10, 22);
        aVar.a("Counter for commands handle by Hybrid Modules on Android");
        return aVar.d();
    }

    @Override // deobf.com.roblox.client.al.d.b
    public void a(@Nullable String moduleID, @Nullable String functionName) {
        if (moduleID == null && functionName == null) {
            return;
        }
        TelemetryConfig c10 = c();
        deobf.com.roblox.universalapp.facialageestimation.fn.c cVar = deobf.com.roblox.universalapp.facialageestimation.fn.c.f16191a;
        deobf.com.withpersona.sdk2.inquiry.c.b bVar = new deobf.com.withpersona.sdk2.inquiry.c.b();
        if (moduleID != null) {
            bVar.c("moduleId", moduleID);
        }
        if (functionName != null) {
            bVar.c("functionName", functionName);
        }
        bVar.h(TelemetryStandardizedField.ADD_OS_INFO);
        deobf.com.roblox.universalapp.facialageestimation.fn.c.g(c10, bVar.l(), 0.0d, 4, null);
    }

    public final TelemetryConfig c() {
        return (TelemetryConfig) this.nativeAndroidHybridModuleCommandCounter.getValue();
    }
}
