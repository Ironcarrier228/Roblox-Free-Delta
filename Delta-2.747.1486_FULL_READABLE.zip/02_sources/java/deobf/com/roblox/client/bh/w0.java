package deobf.com.roblox.client.bh;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

// dex: classes2.dex
public class w0 extends BroadcastReceiver {
    @Override // android.content.BroadcastReceiver
    public void onReceive(Context context, Intent intent) {
        deobf.com.roblox.client.ok.q.b("rbx.broadcast", getClass().getName() + ":onReceive");
        deobf.com.roblox.client.startup.xm.a.c(context);
    }
}
