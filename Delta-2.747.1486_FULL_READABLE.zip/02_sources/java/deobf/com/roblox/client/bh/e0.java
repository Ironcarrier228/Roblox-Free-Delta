package deobf.com.roblox.client.bh;

import android.app.Dialog;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.FrameLayout;
import deobf.com.roblox.client.eh.v0;
import org.greenrobot.eventbus.ThreadMode;

// dex: classes2.dex
public class e0 extends com.roblox.client.c {
    @Override // com.roblox.client.c
    public deobf.unlinked.v0.b I3() {
        return deobf.unlinked.v0.b.f13641g;
    }

    @Override // com.roblox.client.c, deobf.com.withpersona.sdk2.inquiry.f4.q
    public View J0(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        ViewGroup viewGroup2 = (ViewGroup) layoutInflater.inflate(n0.f4199r, viewGroup, false);
        FrameLayout frameLayout = (FrameLayout) viewGroup2.findViewById(m0.E);
        frameLayout.addView(super.J0(layoutInflater, frameLayout, bundle));
        return viewGroup2;
    }

    @Override // com.roblox.client.c, deobf.com.roblox.client.bh.x0, deobf.com.withpersona.sdk2.inquiry.f4.o, deobf.com.withpersona.sdk2.inquiry.f4.q
    public void c1() {
        super.c1();
        deobf.com.roblox.client.mw.c.d().n(this);
        Dialog h22 = h2();
        if (h22 != null) {
            Window window = h22.getWindow();
            WindowManager.LayoutParams attributes = window.getAttributes();
            attributes.dimAmount = 0.0f;
            attributes.flags |= 2;
            window.setAttributes(attributes);
        }
    }

    @Override // com.roblox.client.c, deobf.com.roblox.client.bh.x0, deobf.com.withpersona.sdk2.inquiry.f4.o, deobf.com.withpersona.sdk2.inquiry.f4.q
    public void d1() {
        deobf.com.roblox.client.mw.c.d().p(this);
        super.d1();
    }

    @deobf.com.roblox.client.mw.j(threadMode = ThreadMode.MAIN)
    public void onNavigateToConversationEvent(deobf.com.roblox.client.yh.f fVar) {
        if (i2()) {
            h2().dismiss();
        }
    }

    @deobf.com.roblox.client.mw.j(threadMode = ThreadMode.MAIN)
    public void onNavigateToFeatureEvent(deobf.com.roblox.client.yh.g gVar) {
        if (i2()) {
            h2().dismiss();
        }
    }
}
