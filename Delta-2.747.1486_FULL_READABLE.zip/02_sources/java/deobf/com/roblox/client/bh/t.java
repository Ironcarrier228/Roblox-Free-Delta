package deobf.com.roblox.client.bh;

import android.content.Context;
import android.content.SharedPreferences;
import android.text.TextUtils;
import com.github.luben.zstd.BuildConfig;
import com.roblox.engine.jni.NativeSettingsInterface;

// dex: classes2.dex
public class t {

    public static String f4364a;

    public static String a(Context context) {
        if (f4364a == null) {
            d(context);
        }
        return f4364a;
    }

    public static String b(Context context) {
        c(context);
        return NativeSettingsInterface.nativeGetDevRpcConfiguration();
    }

    public static void c(Context context) {
        String str;
        if (NativeSettingsInterface.nativeIsDevRpcEnabled()) {
            String r10 = deobf.com.roblox.client.startup.uk.c.p().r();
            if (TextUtils.isEmpty(r10)) {
                str = BuildConfig.FLAVOR;
            } else {
                str = r10 + "/bundles/ip.txt";
            }
            NativeSettingsInterface.nativeConfigureDevRpc(str, a(context));
        }
    }

    public static void d(Context context) {
        f4364a = a1.U(context).getString("dev_rpc_ip_port_override", BuildConfig.FLAVOR);
    }

    public static void e(Context context, String str) {
        if (str == null) {
            str = BuildConfig.FLAVOR;
        }
        f4364a = str;
        SharedPreferences.Editor edit = a1.U(context).edit();
        edit.putString("dev_rpc_ip_port_override", str);
        edit.apply();
        c(context);
    }
}
