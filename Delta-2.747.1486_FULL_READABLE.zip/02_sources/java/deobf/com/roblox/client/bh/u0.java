package deobf.com.roblox.client.bh;

// dex: classes2.dex
public class u0 extends Exception {
    public u0() {
        super("Fragment not attached to roblox activity.");
    }
}
