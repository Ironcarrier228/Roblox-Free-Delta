package deobf.com.roblox.client.bh;

// dex: classes2.dex
public final class i0 {

    public static int f4076a = 2131034119;
}
