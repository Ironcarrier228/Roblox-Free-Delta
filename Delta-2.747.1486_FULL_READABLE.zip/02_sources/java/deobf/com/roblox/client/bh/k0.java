package deobf.com.roblox.client.bh;

// dex: classes2.dex
public final class k0 {

    public static int f4095a = 2131165279;
    public static int b = 2131165745;

    public static int f4096c = 2131165746;

    public static int f4097d = 2131166004;

    public static int f4098e = 2131166007;

    public static int f4099f = 2131166014;
}
