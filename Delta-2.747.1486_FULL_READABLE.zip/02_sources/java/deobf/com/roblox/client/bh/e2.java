package deobf.com.roblox.client.bh;

import android.R;
import android.app.Activity;
import android.app.ActivityManager;
import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.Parcel;
import android.util.DisplayMetrics;
import android.view.View;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.TextView;
import androidx.appcompat.app.a;
import com.github.luben.zstd.BuildConfig;
import com.roblox.engine.jni.model.DeviceParams;

// dex: classes2.dex
public class e2 {

    public static DisplayMetrics f4064a;

    public static /* synthetic */ void a(View view, int i10) {
        InputMethodManager inputMethodManager = (InputMethodManager) view.getContext().getSystemService("input_method");
        if (inputMethodManager == null) {
            return;
        }
        inputMethodManager.showSoftInput(view, i10);
    }

    public static void b(Context context, DeviceParams deviceParams) {
        ActivityManager activityManager;
        if (Build.VERSION.SDK_INT <= deobf.com.roblox.client.bi.h.a().H5() && (activityManager = (ActivityManager) context.getSystemService("activity")) != null) {
            ActivityManager.MemoryInfo memoryInfo = new ActivityManager.MemoryInfo();
            activityManager.getMemoryInfo(memoryInfo);
            Parcel obtain = Parcel.obtain();
            memoryInfo.writeToParcel(obtain, 0);
            if (obtain.dataSize() < 32) {
                return;
            }
            obtain.setDataPosition(obtain.dataSize() - 32);
            long readLong = obtain.readLong();
            obtain.readLong();
            obtain.readLong();
            long readLong2 = obtain.readLong();
            deviceParams.lowMemoryKillerBackgroundAppThreshold = readLong;
            deviceParams.lowMemoryKillerForegroundAppThreshold = readLong2;
        }
    }

    public static void c(Context context, DeviceParams deviceParams) {
        ActivityManager activityManager = (ActivityManager) context.getSystemService("activity");
        if (activityManager == null) {
            return;
        }
        int memoryClass = activityManager.getMemoryClass();
        int largeMemoryClass = activityManager.getLargeMemoryClass();
        boolean isLowRamDevice = activityManager.isLowRamDevice();
        deviceParams.memoryClass = memoryClass;
        deviceParams.largeMemoryClass = largeMemoryClass;
        deviceParams.isLowRamDevice = isLowRamDevice;
    }

    public static androidx.appcompat.app.a d(Context context, String str) {
        TextView textView = new TextView(context);
        textView.setText(str);
        textView.setTextAppearance(context, R.style.TextAppearance.DeviceDefault.Large);
        textView.setTextSize(20.0f);
        textView.setEllipsize(null);
        androidx.appcompat.app.a a10 = new a.C0021a(context).a();
        a10.w(textView, 150, 100, 150, 100);
        a10.setCanceledOnTouchOutside(true);
        try {
            a10.show();
        } catch (WindowManager.BadTokenException unused) {
        }
        return a10;
    }

    public static float e(Context context, int i10) {
        return i10 * f(context).density;
    }

    public static DisplayMetrics f(Context context) {
        DisplayMetrics displayMetrics = f4064a;
        if (displayMetrics != null) {
            return displayMetrics;
        }
        DisplayMetrics displayMetrics2 = context.getResources().getDisplayMetrics();
        f4064a = displayMetrics2;
        return displayMetrics2;
    }

    public static String g(Context context) {
        NetworkInfo activeNetworkInfo;
        ConnectivityManager connectivityManager = (ConnectivityManager) context.getSystemService("connectivity");
        if (connectivityManager == null || (activeNetworkInfo = connectivityManager.getActiveNetworkInfo()) == null) {
            return BuildConfig.FLAVOR;
        }
        int type = activeNetworkInfo.getType();
        if (type == 1) {
            return "WiFi";
        }
        if (type != 0) {
            return "Other";
        }
        switch (activeNetworkInfo.getSubtype()) {
        }
        return BuildConfig.FLAVOR;
    }

    public static void h(Activity activity) {
        if (activity != null) {
            ((InputMethodManager) activity.getSystemService("input_method")).hideSoftInputFromWindow(activity.findViewById(R.id.content).getWindowToken(), 0);
        }
    }

    public static void i(Context context, View view) {
        ((InputMethodManager) context.getSystemService("input_method")).hideSoftInputFromWindow(view.getWindowToken(), 0);
    }

    public static boolean j(Context context) {
        NetworkInfo activeNetworkInfo;
        ConnectivityManager connectivityManager = (ConnectivityManager) context.getSystemService("connectivity");
        return (connectivityManager == null || (activeNetworkInfo = connectivityManager.getActiveNetworkInfo()) == null || !activeNetworkInfo.isConnected()) ? false : true;
    }

    public static void k(final View view, final int i10) {
        if (view != null) {
            new Handler(Looper.getMainLooper()).post(new Runnable() { // from class: bh.d2
                @Override // java.lang.Runnable
                public final void run() {
                    deobf.androidx.constraintlayout.widget.e2.a(view, i10);
                }
            });
        }
    }
}
