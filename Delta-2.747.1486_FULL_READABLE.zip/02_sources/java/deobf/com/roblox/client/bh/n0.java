package deobf.com.roblox.client.bh;

// dex: classes2.dex
public final class n0 {
    public static int A = 2131493013;
    public static int B = 2131493014;
    public static int C = 2131493016;
    public static int D = 2131493017;
    public static int E = 2131493025;
    public static int F = 2131493027;

    public static int f4183a = 2131492893;
    public static int b = 2131492894;

    public static int f4184c = 2131492895;

    public static int f4185d = 2131492897;

    public static int f4186e = 2131492898;

    public static int f4187f = 2131492899;

    public static int f4188g = 2131492927;

    public static int f4189h = 2131492931;

    public static int f4190i = 2131492932;

    public static int f4191j = 2131492933;

    public static int f4192k = 2131492934;

    public static int f4193l = 2131492935;

    public static int f4194m = 2131492936;

    public static int f4195n = 2131492937;

    public static int f4196o = 2131492938;

    public static int f4197p = 2131492942;

    public static int f4198q = 2131492944;

    public static int f4199r = 2131493000;

    public static int f4200s = 2131493005;

    public static int f4201t = 2131493006;

    public static int f4202u = 2131493007;

    public static int f4203v = 2131493008;

    public static int f4204w = 2131493009;

    public static int f4205x = 2131493010;

    public static int f4206y = 2131493011;

    public static int f4207z = 2131493012;
}
