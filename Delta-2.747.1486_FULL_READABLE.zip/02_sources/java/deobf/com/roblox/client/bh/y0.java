package deobf.com.roblox.client.bh;

import android.animation.LayoutTransition;
import android.content.Context;
import android.graphics.Point;
import android.os.Bundle;
import android.util.TypedValue;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import deobf.com.roblox.client.eh.v0;

// dex: classes2.dex
public class y0 extends com.roblox.client.c {

    public View f4390g1;

    public class a implements View.OnClickListener {
        public a() {
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            deobf.com.withpersona.sdk2.inquiry.f4.v p8 = y0.this.p();
            if (p8 != null) {
                p8.l1().a1();
            }
        }
    }

    @Override // deobf.com.withpersona.sdk2.inquiry.f4.o, deobf.com.withpersona.sdk2.inquiry.f4.q
    public void C0(Context context) {
        super.C0(context);
        deobf.com.roblox.client.ok.q.b("RobloxModalWebFragment", "onAttach.");
    }

    @Override // com.roblox.client.c
    public void D3(boolean z10) {
        super.D3(z10);
        View view = this.f4390g1;
        if (view != null) {
            view.setVisibility(z10 ? 0 : 8);
        }
    }

    @Override // com.roblox.client.c, deobf.com.roblox.client.bh.x0, deobf.com.withpersona.sdk2.inquiry.f4.o, deobf.com.withpersona.sdk2.inquiry.f4.q
    public void F0(Bundle bundle) {
        super.F0(bundle);
    }

    @Override // com.roblox.client.c
    public void H3(deobf.unlinked.bm.a aVar) {
        super.H3(aVar);
        deobf.com.roblox.client.ok.q.b("RobloxModalWebFragment", "updateWebView.");
    }

    @Override // com.roblox.client.c
    public deobf.unlinked.v0.b I3() {
        return deobf.unlinked.v0.b.f13643i;
    }

    @Override // com.roblox.client.c, deobf.com.withpersona.sdk2.inquiry.f4.q
    public View J0(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        View J0 = super.J0(layoutInflater, viewGroup, bundle);
        deobf.com.roblox.client.ok.q.b("RobloxModalWebFragment", "onCreate.");
        LayoutTransition layoutTransition = new LayoutTransition();
        layoutTransition.enableTransitionType(2);
        layoutTransition.enableTransitionType(3);
        this.f4390g1 = J0;
        ((LinearLayout) J0).setLayoutTransition(layoutTransition);
        LinearLayout linearLayout = (LinearLayout) J0.findViewById(m0.f4173w0);
        linearLayout.setVisibility(0);
        linearLayout.findViewById(m0.f4171v0).setOnClickListener(new a());
        float f10 = S().getDisplayMetrics().widthPixels;
        float f11 = S().getDisplayMetrics().heightPixels;
        deobf.com.roblox.client.ok.q.b("RobloxModalWebFragment", "widthInPixels: " + f10 + ". heightInPixels: " + f11 + ".");
        int T1 = deobf.com.roblox.client.bi.h.a().T1() + linearLayout.getHeight();
        int J2 = deobf.com.roblox.client.bi.h.a().J2();
        int applyDimension = (int) TypedValue.applyDimension(1, (float) T1, S().getDisplayMetrics());
        int applyDimension2 = (int) TypedValue.applyDimension(1, (float) J2, S().getDisplayMetrics());
        deobf.com.roblox.client.ok.q.b("RobloxModalWebFragment", "minWidthInDip: " + applyDimension2 + ". minHeightInDip: " + applyDimension + ".");
        Point J3 = J3(f10, f11, applyDimension2, applyDimension, J2, T1);
        if (J3 != null) {
            deobf.com.roblox.client.ok.q.b("RobloxModalWebFragment", "width: " + J3.x + ". height: " + J3.y + ".");
            J0.setLayoutParams(new FrameLayout.LayoutParams(J3.x, J3.y, 17));
        }
        D3(this.X0);
        return J0;
    }

    public final Point J3(float f10, float f11, int i10, int i11, int i12, int i13) {
        if (f10 < i12 || f11 < i13) {
            return null;
        }
        int i14 = (int) (0.9f * f10);
        if (i14 > i12) {
            i12 = i14;
        }
        int i15 = (int) (0.8f * f11);
        if (i15 > i13) {
            i13 = i15;
        }
        if (i11 > f11) {
            i11 = i13;
        }
        if (i10 > f10) {
            i10 = i12;
        }
        return new Point(i10, i11);
    }

    @Override // deobf.com.withpersona.sdk2.inquiry.f4.o, deobf.com.withpersona.sdk2.inquiry.f4.q
    public void N0() {
        super.N0();
        deobf.com.roblox.client.ok.q.b("RobloxModalWebFragment", "onDetach.");
    }

    @Override // com.roblox.client.c, deobf.com.withpersona.sdk2.inquiry.f4.q
    public void V0() {
        super.V0();
        deobf.com.roblox.client.ok.q.b("RobloxModalWebFragment", "onPause.");
    }

    @Override // com.roblox.client.c, deobf.com.withpersona.sdk2.inquiry.f4.q
    public void a1() {
        super.a1();
        deobf.com.roblox.client.ok.q.b("RobloxModalWebFragment", "onResume.");
    }

    @Override // com.roblox.client.c, deobf.com.roblox.client.bh.x0, deobf.com.withpersona.sdk2.inquiry.f4.o, deobf.com.withpersona.sdk2.inquiry.f4.q
    public void c1() {
        super.c1();
    }

    @Override // deobf.com.roblox.client.bh.x0, deobf.com.withpersona.sdk2.inquiry.f4.o, deobf.com.withpersona.sdk2.inquiry.f4.q
    public void z0(Bundle bundle) {
        super.z0(bundle);
        deobf.com.roblox.client.ok.q.b("RobloxModalWebFragment", "onActivityCreated.");
    }
}
