package deobf.com.roblox.client.ei;

import android.hardware.display.DisplayManager;
import android.view.Display;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.l;
import androidx.annotation.NonNull;
import com.roblox.client.RobloxApplication;
import com.roblox.engine.jni.NativeGLInterface;
import com.roblox.engine.jni.util.AssertDialogUtil;
import com.roblox.platform.util.DeviceUtils;
import deobf.com.roblox.client.ei.a;
import java.lang.ref.WeakReference;
import deobf.com.roblox.client.startup.uk.f;

// dex: classes2.dex
public class t0 implements android.view.p, a.f, f.InterfaceC0678f, SurfaceHolder.Callback {

    public deobf.com.roblox.client.implementation.ih.a f13786c;

    public final WeakReference<com.roblox.client.a> f13788e;

    public final deobf.com.roblox.client.startup.uk.f f13789f;

    public final SurfaceView f13790g;

    public DisplayManager f13791h;

    public DisplayManager.DisplayListener f13792i;

    public u0 f13785a = u0.APP;
    public final String b = "MainScreenController";

    public Boolean f13787d = Boolean.FALSE;

    public class a implements DisplayManager.DisplayListener {
        public a() {
        }

        @Override // android.hardware.display.DisplayManager.DisplayListener
        public void onDisplayAdded(int i10) {
        }

        @Override // android.hardware.display.DisplayManager.DisplayListener
        public void onDisplayChanged(int i10) {
            if (i10 != 0 || t0.this.f13791h == null) {
                return;
            }
            t0 t0Var = t0.this;
            t0Var.n(t0Var.f13791h.getDisplay(0));
        }

        @Override // android.hardware.display.DisplayManager.DisplayListener
        public void onDisplayRemoved(int i10) {
        }
    }

    public static /* synthetic */ class b {

        public static final /* synthetic */ int[] f13794a;

        static {
            int[] iArr = new int[deobf.unlinked.l.a.values().length];
            f13794a = iArr;
            try {
                iArr[deobf.unlinked.l.a.ON_CREATE.ordinal()] = 1;
            } catch (NoSuchFieldError unused) {
            }
            try {
                f13794a[deobf.unlinked.l.a.ON_RESUME.ordinal()] = 2;
            } catch (NoSuchFieldError unused2) {
            }
            try {
                f13794a[deobf.unlinked.l.a.ON_PAUSE.ordinal()] = 3;
            } catch (NoSuchFieldError unused3) {
            }
            try {
                f13794a[deobf.unlinked.l.a.ON_STOP.ordinal()] = 4;
            } catch (NoSuchFieldError unused4) {
            }
            try {
                f13794a[deobf.unlinked.l.a.ON_DESTROY.ordinal()] = 5;
            } catch (NoSuchFieldError unused5) {
            }
        }
    }

    public t0(com.roblox.client.a aVar, SurfaceView surfaceView) {
        this.f13788e = new WeakReference<>(aVar);
        this.f13790g = surfaceView;
        deobf.com.roblox.client.startup.uk.f fVar = new deobf.com.roblox.client.startup.uk.f(aVar, surfaceView, this);
        this.f13789f = fVar;
        surfaceView.setOnTouchListener(fVar);
        surfaceView.getHolder().addCallback(this);
    }

    @Override // deobf.com.roblox.client.bh.f0
    public void H() {
    }

    @Override // deobf.com.roblox.client.bh.f0
    public boolean b() {
        return this.f13787d.booleanValue();
    }

    public final void d() {
        DisplayManager.DisplayListener displayListener;
        DisplayManager displayManager = this.f13791h;
        if (displayManager != null && (displayListener = this.f13792i) != null) {
            displayManager.unregisterDisplayListener(displayListener);
        }
        this.f13792i = null;
        this.f13791h = null;
    }

    public final void e() {
        deobf.com.roblox.client.ok.q.h("MainScreenController", "Disposing RTC audio manager.");
        deobf.com.roblox.client.implementation.ih.a aVar = this.f13786c;
        if (aVar != null) {
            aVar.a();
            this.f13786c = null;
        }
    }

    @Override // deobf.com.roblox.client.bh.f0
    public void f(boolean z10) {
        this.f13789f.H(z10);
    }

    @Override // android.view.p
    public void g(@NonNull android.view.s sVar, @NonNull deobf.unlinked.l.a aVar) {
        deobf.com.roblox.client.ok.q.b("MainScreenController", "onStateChanged: event: " + aVar);
        int i10 = b.f13794a[aVar.ordinal()];
        if (i10 == 1) {
            i((deobf.com.google.android.material.j.b) sVar);
            h();
            if (!deobf.com.roblox.client.bi.h.a().Y3() || deobf.com.roblox.client.dj.b.m()) {
                return;
            }
            this.f13788e.get().getWindow().setFlags(8192, 8192);
            return;
        }
        if (i10 == 2) {
            this.f13789f.H(false);
            deobf.com.roblox.client.bh.y.h().k().c("POST_NOTIFICATIONS", deobf.com.roblox.client.pushnotification.rj.t.g());
            deobf.com.roblox.client.bh.y.h().k().c("MEDIA_PICKER", deobf.unlinked.ej.a.e());
            if (deobf.com.roblox.client.bi.h.a().o4() && AssertDialogUtil.b()) {
                AssertDialogUtil.c(this.f13788e.get());
                return;
            }
            return;
        }
        if (i10 == 3) {
            this.f13789f.I();
            return;
        }
        if (i10 != 4) {
            if (i10 != 5) {
                return;
            }
            e();
            d();
            return;
        }
        deobf.com.roblox.client.bh.y.h().k().N("POST_NOTIFICATIONS");
        deobf.com.roblox.client.bh.y.h().k().N("MEDIA_PICKER");
        if (deobf.com.roblox.client.bi.h.a().o4() && AssertDialogUtil.b()) {
            AssertDialogUtil.c(null);
        }
    }

    public final void h() {
        com.roblox.client.a aVar = this.f13788e.get();
        if (aVar == null) {
            return;
        }
        DisplayManager displayManager = (DisplayManager) aVar.getApplicationContext().getSystemService("display");
        this.f13791h = displayManager;
        if (displayManager == null) {
            return;
        }
        a aVar2 = new a();
        this.f13792i = aVar2;
        this.f13791h.registerDisplayListener(aVar2, null);
        Display display = this.f13791h.getDisplay(0);
        if (display == null) {
            return;
        }
        n(display);
        NativeGLInterface.nativePassSupportedRefreshRates(DeviceUtils.getSupportedRefreshRates(display));
    }

    public final void i(deobf.com.google.android.material.j.b bVar) {
        deobf.com.roblox.client.ok.q.h("MainScreenController", "Initializing RTC audio manager.");
        deobf.com.roblox.client.implementation.ih.a c10 = deobf.com.roblox.client.bh.y.h().c(bVar.getApplicationContext());
        this.f13786c = c10;
        if (c10 != null) {
            c10.b(bVar);
        }
    }

    public void j(int i10) {
        if (this.f13785a == u0.EXPERIENCE) {
            deobf.com.roblox.client.ok.q.h("MainScreenController", "Handling onTrimMemory level: " + i10);
            if (i10 == 15) {
                deobf.com.roblox.client.ok.q.k("MainScreenController", "TRIM_MEMORY_RUNNING_CRITICAL: notify the engine...");
                NativeGLInterface.nativeAppBridgeV2OnLowMemory();
            }
        }
        RobloxApplication.g("MainScreenController", this.f13785a, i10);
        NativeGLInterface.nativeAppBridgeV2OnLowMemoryForRenderView(this.f13785a.ordinal(), i10);
    }

    public void k(u0 u0Var) {
        deobf.com.roblox.client.ok.q.h("MainScreenController", "Roblox has entered " + u0Var.name() + " mode.");
        this.f13785a = u0Var;
    }

    @Override // deobf.com.roblox.client.bh.f0
    public void l() {
        this.f13789f.I();
    }

    public final void n(Display display) {
        if (this.f13788e.get() == null) {
            return;
        }
        NativeGLInterface.nativePassCurrentDisplayRefreshRate(DeviceUtils.getCurrentRefreshRate(display));
    }

    @Override // android.view.SurfaceHolder.Callback
    public void surfaceChanged(@NonNull SurfaceHolder surfaceHolder, int i10, int i11, int i12) {
        deobf.com.roblox.client.ok.q.h("MainScreenController", "surfaceChanged");
    }

    @Override // android.view.SurfaceHolder.Callback
    public void surfaceCreated(@NonNull SurfaceHolder surfaceHolder) {
        deobf.com.roblox.client.ok.q.h("MainScreenController", "surfaceCreated");
        this.f13787d = Boolean.TRUE;
    }

    @Override // android.view.SurfaceHolder.Callback
    public void surfaceDestroyed(@NonNull SurfaceHolder surfaceHolder) {
        deobf.com.roblox.client.ok.q.h("MainScreenController", "surfaceDestroyed");
        this.f13787d = Boolean.FALSE;
    }
}
