package deobf.com.roblox.client.ei;

import android.os.Bundle;
import com.github.luben.zstd.BuildConfig;

// dex: classes2.dex
public class m0 {

    public int f13752a;
    public long b;

    public long f13753c;

    public String f13754d;

    public String f13755e;

    public String f13756f;

    public long f13757g;

    public String f13758h;

    public String f13759i;

    public String f13760j;

    public String f13761k;

    public String f13762l;

    public String f13763m;

    public String f13764n;

    public String f13765o;

    public String f13766p;

    public long f13767q;

    public String f13768r;

    public m0(Bundle bundle) {
        this.f13752a = 0;
        this.b = 0L;
        this.f13753c = 0L;
        this.f13754d = BuildConfig.FLAVOR;
        this.f13755e = BuildConfig.FLAVOR;
        this.f13756f = BuildConfig.FLAVOR;
        this.f13757g = 0L;
        this.f13758h = BuildConfig.FLAVOR;
        this.f13759i = BuildConfig.FLAVOR;
        this.f13760j = BuildConfig.FLAVOR;
        this.f13761k = BuildConfig.FLAVOR;
        this.f13762l = BuildConfig.FLAVOR;
        this.f13763m = BuildConfig.FLAVOR;
        this.f13764n = BuildConfig.FLAVOR;
        this.f13765o = BuildConfig.FLAVOR;
        this.f13766p = BuildConfig.FLAVOR;
        this.f13767q = 0L;
        this.f13768r = BuildConfig.FLAVOR;
        this.f13753c = bundle.getLong("roblox_placeId", 0L);
        this.f13754d = bundle.getString("roblox_accessCode");
        this.f13755e = bundle.getString("roblox_linkCode");
        this.f13756f = bundle.getString("roblox_gameId");
        this.b = bundle.getLong("roblox_userId", 0L);
        this.f13757g = bundle.getLong("roblox_conversationId", 0L);
        this.f13758h = bundle.getString("roblox_reservedServerAccessCode");
        this.f13759i = bundle.getString("roblox_callId");
        this.f13752a = bundle.getInt("roblox_joinRequestType", -1);
        this.f13760j = bundle.getString("roblox_referralPage");
        this.f13761k = bundle.getString("roblox_launchData");
        this.f13764n = bundle.getString("roblox_joinAttemptId");
        this.f13765o = bundle.getString("roblox_joinAttemptOrigin");
        this.f13766p = bundle.getString("roblox_isoContext");
        if (deobf.com.roblox.client.bi.h.a().e3()) {
            this.f13767q = bundle.getLong("roblox_referredByPlayerId", 0L);
        }
        this.f13762l = bundle.getString("roblox_gameJoinContext");
        this.f13763m = bundle.getString("roblox_event_id");
        this.f13768r = bundle.getString("game_id_to_exclude");
    }
}
