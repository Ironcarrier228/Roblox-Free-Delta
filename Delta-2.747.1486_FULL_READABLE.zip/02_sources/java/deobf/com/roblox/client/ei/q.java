package deobf.com.roblox.client.ei;

import com.github.luben.zstd.BuildConfig;
import kotlin.Metadata;

@Metadata(d1 = {"\u0000\u0010\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\u0010\u0002\n\u0002\b\u0003\bf\u0018\u00002\u00020\u0001J\u000f\u0010\u0003\u001a\u00020\u0002H'¢\u0006\u0004\b\u0003\u0010\u0004¨\u0006\u0005À\u0006\u0003"}, d2 = {"Lei/q;", BuildConfig.FLAVOR, BuildConfig.FLAVOR, "E", "()V", "NativeShell_googleProdRelease"}, k = 1, mv = {2, 2, 0}, xi = 48)
// dex: classes2.dex
public interface q {
    void E();
}
