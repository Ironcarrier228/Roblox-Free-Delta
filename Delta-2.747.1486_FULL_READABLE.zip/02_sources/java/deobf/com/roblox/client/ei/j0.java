package deobf.com.roblox.client.ei;

import android.content.Context;
import android.graphics.Point;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Surface;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewStub;
import android.widget.FrameLayout;
import com.github.luben.zstd.BuildConfig;
import com.roblox.client.game.ExperienceSession;
import com.roblox.engine.jni.NativeGLInterface;
import com.roblox.engine.jni.autovalue.StartGameParams;
import com.roblox.engine.jni.model.PlatformParams;
import com.roblox.platform.util.DeviceUtils;
import deobf.com.roblox.client.startup.ik.s2;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.function.Consumer;

// dex: classes2.dex
public class j0 implements SurfaceHolder.Callback {

    public m0 f13719a;

    public FrameLayout f13720c;

    public SurfaceView f13724g;

    public FrameLayout f13725h;

    public deobf.com.roblox.client.purchase.mj.k f13727j;

    public ExecutorService f13728k;

    public w0 f13729l;

    public ExperienceSession f13730m;
    public final String b = "rbx.game";

    public long f13721d = 0;

    public String f13722e = BuildConfig.FLAVOR;

    public boolean f13723f = false;

    public int f13726i = -1;

    public j0(ExperienceSession experienceSession, m0 m0Var) {
        this.f13730m = experienceSession;
        this.f13729l = experienceSession;
        this.f13719a = m0Var;
    }

    public View A(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        deobf.com.roblox.client.ok.q.b("rbx.game", "onCreateView: savedInstanceState = " + bundle + ", surfaceState = " + this.f13726i);
        if (!com.roblox.client.startup.a.m() && bundle != null) {
            deobf.com.roblox.client.ok.q.k("rbx.game", "onCreateView: No Settings with non-null savedInstanceState. No need to create view.");
            this.f13729l.q();
            return null;
        }
        this.f13727j = deobf.com.roblox.client.bi.h.a().L1() ? deobf.com.roblox.client.nj.a0.R(l()) : deobf.com.roblox.client.nj.m.F0(l());
        this.f13725h = (FrameLayout) q().findViewById(deobf.com.roblox.client.bh.m0.f4136e);
        if (deobf.com.roblox.client.bh.a1.k0() && bundle != null && this.f13726i == 2) {
            deobf.com.roblox.client.ok.q.h("rbx.game", "onCreateView: The game is being recreated. Keep the current surface state.");
        } else {
            this.f13726i = 0;
        }
        if (deobf.com.roblox.client.bi.h.a().O0()) {
            ViewStub viewStub = (ViewStub) this.f13725h.findViewById(deobf.com.roblox.client.bh.m0.V);
            if (viewStub != null) {
                this.f13720c = (FrameLayout) viewStub.inflate();
            } else {
                this.f13720c = (FrameLayout) this.f13725h.findViewById(deobf.com.roblox.client.bh.m0.U);
            }
        } else {
            this.f13720c = (FrameLayout) this.f13725h.findViewById(deobf.com.roblox.client.bh.m0.U);
        }
        s(null);
        deobf.com.roblox.client.startup.uk.c.p().s(new Consumer() { // from class: ei.b0
            @Override // java.util.function.Consumer
            public final void accept(Object obj) {
                j0.this.u((String) obj);
            }
        });
        return null;
    }

    public final void B(final Runnable runnable) {
        o().execute(new Runnable() { // from class: ei.g0
            @Override // java.lang.Runnable
            public final void run() {
                runnable.run();
            }
        });
    }

    public final void C(m0 m0Var) {
        deobf.com.roblox.client.ok.q.h("rbx.game", "startGame");
        Surface surface = this.f13724g.getHolder().getSurface();
        com.roblox.engine.jni.model.a aVar = new com.roblox.engine.jni.model.a(p());
        aVar.f9663d = deobf.com.roblox.client.bh.a1.r0();
        this.f13729l.b(m0Var.f13753c);
        StartGameParams.a u8 = StartGameParams.builder().w(surface).s(aVar).f(null).r(m0Var.f13753c).x(m0Var.b).c(m0Var.f13754d).q(m0Var.f13755e).h(m0Var.f13756f).k(deobf.unlinked.nk.c.c().n()).y(deobf.unlinked.nk.c.c().k()).e(m0Var.f13757g).v(m0Var.f13758h).d(m0Var.f13759i).o(m0Var.f13752a).t(m0Var.f13760j).p(m0Var.f13761k).m(m0Var.f13764n).n(m0Var.f13765o).l(m0Var.f13766p).u(m0Var.f13767q);
        if (deobf.com.roblox.client.bh.a1.E0()) {
            u8.z(q());
        }
        u8.j(m0Var.f13762l);
        u8.g(m0Var.f13763m);
        if (deobf.com.roblox.client.bi.h.a().H3()) {
            u8.i(m0Var.f13768r);
        }
        q().runOnUiThread(new Runnable() { // from class: ei.h0
            @Override // java.lang.Runnable
            public final void run() {
                j0.this.v();
            }
        });
        NativeGLInterface.nativeAppBridgeV2StartGameWithParam(u8.b());
        q().runOnUiThread(new Runnable() { // from class: ei.i0
            @Override // java.lang.Runnable
            public final void run() {
                j0.this.w();
            }
        });
        this.f13729l.e(m0Var.f13753c);
    }

    public void D() {
        B(new Runnable() { // from class: ei.e0
            @Override // java.lang.Runnable
            public final void run() {
                j0.this.x();
            }
        });
    }

    public final void x() {
        deobf.com.roblox.client.ok.q.h("rbx.game", "stopDataModel: dataModel = GAME, surfaceState = " + this.f13726i + ", graphicsStarted = " + this.f13723f);
        this.f13724g.getHolder().removeCallback(this);
        this.f13726i = -1;
    }

    public final void F() {
        deobf.com.roblox.client.ok.q.h("rbx.game", "surfaceDestroyed: surfaceState = " + this.f13726i + ", graphicsStarted = " + this.f13723f);
        if (this.f13726i != 2) {
            return;
        }
        if (this.f13723f) {
            this.f13723f = false;
            NativeGLInterface.nativeAppBridgeV2PauseGame();
        }
        com.roblox.client.a q8 = q();
        if (q8 == null || q8.isFinishing()) {
            return;
        }
        deobf.com.roblox.client.ok.q.h("rbx.game", "surfaceDestroyed() activity finishing ignore task scheduler");
        this.f13730m.b0();
    }

    public final void G() {
        deobf.com.roblox.client.ok.q.h("rbx.game", "updateSurface() surfaceState = " + this.f13726i);
        com.roblox.client.a q8 = q();
        if (q8 == null || q8.isFinishing() || q8.isDestroyed()) {
            deobf.com.roblox.client.ok.q.h("rbx.game", "updateSurface() activity finishing ignore update");
            return;
        }
        int i10 = this.f13726i;
        if (i10 == 0) {
            this.f13726i = 2;
            this.f13723f = true;
            C(this.f13719a);
            return;
        }
        if (i10 == 2) {
            Surface surface = this.f13724g.getHolder().getSurface();
            PlatformParams platformParams = new PlatformParams();
            float m10 = m();
            Point screenPhysicalSizeInMillimeters = DeviceUtils.getScreenPhysicalSizeInMillimeters(n().L());
            platformParams.dpiScale = m10;
            platformParams.viewportWidthMm = screenPhysicalSizeInMillimeters.x;
            platformParams.viewportHeightMm = screenPhysicalSizeInMillimeters.y;
            if (this.f13723f) {
                deobf.com.roblox.client.ok.q.h("rbx.game", "updateSurface: nativeUpdateGraphics");
                NativeGLInterface.nativeAppBridgeV2UpdateSurfaceGameWithPlatformParams(surface, platformParams, deobf.com.roblox.client.bh.a1.q0() ? q() : null);
            } else {
                deobf.com.roblox.client.ok.q.h("rbx.game", "updateSurface: nativeStartUpGraphics");
                this.f13723f = true;
                NativeGLInterface.nativeAppBridgeV2ResumeGameWithPlatformParams(surface, platformParams, deobf.com.roblox.client.bh.a1.q0() ? q() : null);
            }
        }
    }

    public void j(final boolean z10) {
        B(new Runnable() { // from class: ei.c0
            @Override // java.lang.Runnable
            public final void run() {
                j0.this.t(z10);
            }
        });
    }

    public FrameLayout k() {
        return this.f13725h;
    }

    public Context l() {
        return n().L();
    }

    public float m() {
        return DeviceUtils.getScreenDensity(n().L());
    }

    public ExperienceSession n() {
        return this.f13730m;
    }

    public final ExecutorService o() {
        if (this.f13728k == null) {
            this.f13728k = Executors.newSingleThreadExecutor();
        }
        return this.f13728k;
    }

    public final PlatformParams p() {
        String r10 = deobf.com.roblox.client.startup.uk.c.p().r();
        deobf.com.roblox.client.ok.q.b("rbx.game", "getPlatformParams: assetFolderPath = " + r10);
        PlatformParams platformParams = new PlatformParams();
        platformParams.assetFolderPath = r10;
        platformParams.isTouchDevice = q().getPackageManager().hasSystemFeature("android.hardware.touchscreen");
        platformParams.isMouseDevice = q().getPackageManager().hasSystemFeature("android.hardware.type.pc");
        platformParams.isKeyboardDevice = q().getPackageManager().hasSystemFeature("android.hardware.type.pc");
        platformParams.dpiScale = m();
        Point screenPhysicalSizeInMillimeters = DeviceUtils.getScreenPhysicalSizeInMillimeters(n().L());
        platformParams.viewportWidthMm = screenPhysicalSizeInMillimeters.x;
        platformParams.viewportHeightMm = screenPhysicalSizeInMillimeters.y;
        return platformParams;
    }

    public com.roblox.client.a q() {
        return (com.roblox.client.a) this.f13730m.K();
    }

    public SurfaceView r() {
        return this.f13724g;
    }

    public final void s(View view) {
        deobf.com.roblox.client.ok.q.b("rbx.game", "initSurfaceView: ...");
        SurfaceView surfaceView = (SurfaceView) q().findViewById(deobf.com.roblox.client.bh.m0.f4149k0);
        this.f13724g = surfaceView;
        surfaceView.setFocusable(true);
        this.f13724g.setFocusableInTouchMode(true);
        this.f13724g.getHolder().addCallback(this);
        if (n().P()) {
            surfaceCreated(null);
            surfaceChanged(null, 0, 0, 0);
        }
    }

    @Override // android.view.SurfaceHolder.Callback
    public void surfaceChanged(SurfaceHolder surfaceHolder, int i10, int i11, int i12) {
        deobf.com.roblox.client.ok.q.h("rbx.game", "surfaceChanged: ...");
        B(new Runnable() { // from class: ei.f0
            @Override // java.lang.Runnable
            public final void run() {
                j0.this.G();
            }
        });
    }

    @Override // android.view.SurfaceHolder.Callback
    public void surfaceCreated(SurfaceHolder surfaceHolder) {
        deobf.com.roblox.client.ok.q.h("rbx.game", "surfaceCreated: ...");
        B(new Runnable() { // from class: ei.a0
            @Override // java.lang.Runnable
            public final void run() {
                j0.this.y();
            }
        });
    }

    @Override // android.view.SurfaceHolder.Callback
    public void surfaceDestroyed(SurfaceHolder surfaceHolder) {
        try {
            this.f13728k.submit(new Runnable() { // from class: ei.d0
                @Override // java.lang.Runnable
                public final void run() {
                    j0.this.z();
                }
            }).get();
        } catch (Exception unused) {
            deobf.com.roblox.client.ok.q.h("rbx.game", "game thread times out");
        }
    }

    public final /* synthetic */ void t(boolean z10) {
        x();
        if (deobf.com.roblox.client.bi.h.a().a6() && z10 && s2.b()) {
            NativeGLInterface.nativeAppBridgeV2LeaveGameAfterIdle();
        } else {
            NativeGLInterface.nativeAppBridgeV2LeaveGame();
        }
    }

    public final /* synthetic */ void u(String str) {
        this.f13724g.setVisibility(0);
    }

    public final /* synthetic */ void v() {
        FrameLayout frameLayout = this.f13720c;
        if (frameLayout != null) {
            frameLayout.setVisibility(0);
        }
    }

    public final /* synthetic */ void w() {
        FrameLayout frameLayout;
        if (q().isDestroyed() || (frameLayout = this.f13720c) == null) {
            return;
        }
        frameLayout.setVisibility(8);
    }

    public final /* synthetic */ void y() {
        this.f13730m.a0();
    }

    public final /* synthetic */ void z() {
        if (q() == null) {
            return;
        }
        F();
    }
}
