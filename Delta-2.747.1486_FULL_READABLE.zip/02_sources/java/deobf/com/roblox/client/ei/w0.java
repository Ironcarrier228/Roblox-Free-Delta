package deobf.com.roblox.client.ei;

// dex: classes2.dex
public interface w0 {
    void b(long j10);

    void e(long j10);

    void q();
}
