package deobf.com.roblox.client.ei;

import android.content.Context;
import android.graphics.Rect;
import android.graphics.RectF;
import com.roblox.platform.util.DeviceUtils;

// dex: classes2.dex
public class y0 {

    public final Context f13809a;
    public Rect b;

    public Rect f13810c;

    public class a implements android.view.e0<Rect> {
        public a() {
        }

        @Override // android.view.e0
        public void a(Rect rect) {
            deobf.com.roblox.client.ok.q.b("SafeAreaInsetsObserver", String.format("New cutout insets: %s", String.valueOf(rect)));
            y0.this.b = rect;
            y0.this.h();
        }
    }

    public class b implements android.view.e0<Rect> {
        public b() {
        }

        @Override // android.view.e0
        public void a(Rect rect) {
            y0.this.f13810c = rect;
            y0.this.h();
        }
    }

    public class c implements android.view.e0<Rect> {
        public c() {
        }

        @Override // android.view.e0
        public void a(Rect rect) {
            deobf.com.roblox.client.ok.q.b("SafeAreaInsetsObserver", String.format("New cutout insets: %s", String.valueOf(rect)));
            if (rect == null) {
                deobf.unlinked.dn.a.b().a(0.0f, 0.0f, 0.0f, 0.0f);
                return;
            }
            Rect g10 = y0.this.g(new RectF(rect), DeviceUtils.getScreenDensity(y0.this.f13809a));
            deobf.unlinked.dn.a.b().a(g10.left, g10.top, g10.right, g10.bottom);
        }
    }

    public y0(Context context) {
        this.f13809a = context;
    }

    public final int f(float f10, float f11) {
        return (int) ((f10 / f11) + 0.5d);
    }

    public final Rect g(RectF rectF, float f10) {
        return new Rect(f(rectF.left, f10), f(rectF.top, f10), f(rectF.right, f10), f(rectF.bottom, f10));
    }

    /* JADX WARN: Removed duplicated region for block: B:30:0x00a6  */
    /* JADX WARN: Removed duplicated region for block: B:33:0x00b1  */
    public final void h() {
        /*
            Method dump skipped, instructions count: 216
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: deobf.com.roblox.client.ei.y0.h():void");
    }

    public void i(android.view.s sVar, android.view.a0<Rect> a0Var) {
        if (!deobf.com.roblox.client.bi.h.a().G0()) {
            a0Var.i(sVar, new c());
            return;
        }
        a0Var.i(sVar, new a());
        if (sVar instanceof com.roblox.client.b) {
            (deobf.com.roblox.client.bi.h.a().d1() ? ((com.roblox.client.b) sVar).G1().e() : ((com.roblox.client.b) sVar).G1().c()).i(sVar, new b());
        }
    }
}
