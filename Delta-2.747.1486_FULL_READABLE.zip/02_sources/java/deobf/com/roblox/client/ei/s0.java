package deobf.com.roblox.client.ei;

// dex: classes2.dex
public interface s0 extends deobf.com.roblox.client.purchase.mj.o {
    void a(boolean z10, long j10, String str, String str2);
}
