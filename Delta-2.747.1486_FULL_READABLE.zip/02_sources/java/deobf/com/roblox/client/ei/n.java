package deobf.com.roblox.client.ei;

import android.text.TextUtils;
import deobf.com.roblox.client.bh.c2;
import com.github.luben.zstd.BuildConfig;
import com.google.mlkit.vision.barcode.common.Barcode;
import com.roblox.client.RobloxApplication;
import com.roblox.client.startup.FlagCacheUtils;
import com.roblox.engine.jni.NativeGLInterface;
import com.roblox.engine.jni.OnAppBridgeNotificationListener;
import deobf.com.roblox.client.dj.b;
import org.json.JSONException;
import org.json.JSONObject;
import deobf.com.roblox.client.qm.a;

// dex: classes2.dex
public class n extends OnAppBridgeNotificationListener {

    public a f13770c;

    public b f13771d;

    public final String f13769a = "rbx.datamodel";
    public final String b = "OPEN_YOUTUBE_VIDEO";

    public deobf.com.roblox.client.fh.a f13772e = new deobf.com.roblox.client.fh.a();

    public interface a {
        void c(String str);
    }

    public interface b {
        deobf.com.roblox.client.bh.x0 a();
    }

    public n(a aVar, b bVar) {
        this.f13770c = aVar;
        this.f13771d = bVar;
    }

    public static /* synthetic */ void c(boolean z10, com.roblox.client.a aVar) {
        if (z10) {
            deobf.androidx.constraintlayout.widget.c2.b(aVar.getWindow());
            aVar.W1().o(u0.EXPERIENCE);
            if (deobf.com.roblox.client.bi.h.a().J3()) {
                aVar.getWindow().addFlags(Barcode.FORMAT_ITF);
                return;
            }
            return;
        }
        aVar.W1().o(u0.APP);
        if (!deobf.com.roblox.client.bh.a1.R0(aVar.getResources().getConfiguration())) {
            deobf.androidx.constraintlayout.widget.c2.c(aVar.getWindow());
        }
        if (deobf.com.roblox.client.bi.h.a().J3()) {
            aVar.getWindow().clearFlags(Barcode.FORMAT_ITF);
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    @Override // com.roblox.engine.jni.OnAppBridgeNotificationListener
    public void a(String str, String str2) {
        String str3;
        long j10;
        deobf.com.withpersona.sdk2.inquiry.f4.v p8;
        StringBuilder sb2 = new StringBuilder();
        sb2.append("onDataModelNotification() type:");
        sb2.append(str);
        if (TextUtils.isEmpty(str2)) {
            str3 = BuildConfig.FLAVOR;
        } else {
            str3 = " data:" + str2;
        }
        sb2.append(str3);
        deobf.com.roblox.client.ok.q.h("rbx.datamodel", sb2.toString());
        if (str.equals("VIEW_PROFILE")) {
            deobf.com.roblox.client.yh.g b10 = deobf.com.roblox.client.yh.g.b("PROFILE_TAG");
            b10.i(str2);
            b10.j(true);
            deobf.com.roblox.client.mw.c.d().j(b10);
            return;
        }
        if (str.equals("SCAN_QR_CODE")) {
            deobf.com.roblox.client.mw.c.d().j(new deobf.com.roblox.client.yh.g("SCAN_QR_CODE"));
            return;
        }
        if (str.equals("REPORT_ABUSE")) {
            deobf.com.roblox.client.yh.g gVar = new deobf.com.roblox.client.yh.g("ABUSE_REPORT_TAG");
            gVar.i(str2);
            gVar.j(true);
            deobf.com.roblox.client.mw.c.d().j(gVar);
            return;
        }
        if (str.equals("BACK_BUTTON_NOT_CONSUMED")) {
            deobf.com.roblox.client.mw.c.d().j(new deobf.com.roblox.client.yh.c());
            return;
        }
        if (str.equals("PURCHASE_ROBUX")) {
            new deobf.com.roblox.client.fj.e(this.f13771d.a(), "tabAvatar").g(this.f13772e);
            return;
        }
        if (str.equals("VIEW_NOTIFICATIONS")) {
            new deobf.com.roblox.client.fj.d(this.f13771d.a()).f(this.f13772e);
            return;
        }
        if (str.equals("APP_READY")) {
            this.f13770c.c(str2);
            if (deobf.com.roblox.client.bi.h.a().l2()) {
                d(str2);
            }
            if (TextUtils.isEmpty(str2) || !str2.equals("landing")) {
                return;
            }
            deobf.com.roblox.client.ok.q.h("rbx.datamodel", "Got callback to Java landing page, going to flush the client settings");
            com.roblox.client.startup.a.n();
            return;
        }
        if (str.equals("OPEN_CUSTOM_WEBVIEW")) {
            deobf.com.roblox.client.yh.g b11 = deobf.com.roblox.client.yh.g.b("CUSTOM_WEBVIEW_TAG");
            b11.g(str2);
            b11.j(true);
            deobf.com.roblox.client.mw.c.d().j(b11);
            return;
        }
        if (deobf.com.roblox.client.bi.h.a().u1() && str.equals("POST_PURCHASE")) {
            try {
                JSONObject jSONObject = new JSONObject();
                jSONObject.put("url", str2);
                deobf.com.roblox.client.yh.g b12 = deobf.com.roblox.client.yh.g.b("CUSTOM_WEBVIEW_TAG");
                b12.g(jSONObject.toString());
                b12.j(true);
                deobf.com.roblox.client.mw.c.d().j(b12);
                return;
            } catch (JSONException e10) {
                deobf.com.roblox.client.ok.q.e("rbx.datamodel", "POST_PURCHASE: failed to build JSON url=" + str2 + " error=" + e10.getMessage());
                return;
            }
        }
        if (str.equals("OPEN_BUILDERS_CLUB")) {
            new deobf.com.roblox.client.fj.b(this.f13771d.a(), "tabMore").c(this.f13772e);
            return;
        }
        if (str.equals("SEARCH_GAMES")) {
            deobf.com.roblox.client.yh.g b13 = deobf.com.roblox.client.yh.g.b("SEARCH_GAMES_TAG");
            b13.i(str2);
            b13.j(true);
            deobf.com.roblox.client.mw.c.d().j(b13);
            return;
        }
        if (str.equals("ACTION_LOG_OUT")) {
            new deobf.com.roblox.client.fj.c(this.f13771d.a()).c(this.f13772e);
            return;
        }
        if (str.equals("LUA_HOME_PAGE_LOADED")) {
            if (deobf.com.roblox.client.bi.h.a().l2()) {
                e();
            }
            FlagCacheUtils.flushPendingVersionBWrite(RobloxApplication.f());
            FlagCacheUtils.flushPendingVersionBTelemetry();
            if (deobf.com.roblox.client.bi.h.a().c1()) {
                deobf.com.roblox.client.ai.b.c();
            }
            if (!deobf.com.roblox.client.bi.h.a().W5() || (p8 = this.f13771d.a().p()) == null) {
                return;
            }
            deobf.unlinked.li.i.p(p8);
            return;
        }
        if (str.equals("LAUNCH_CONVERSATION")) {
            try {
                j10 = Long.parseLong(str2);
            } catch (NumberFormatException unused) {
                deobf.com.roblox.client.ok.q.k("rbx.datamodel", "could not parse data");
                j10 = -1;
            }
            if (j10 != -1) {
                deobf.com.roblox.client.mw.c.d().j(new deobf.com.roblox.client.yh.f(j10));
                return;
            }
            return;
        }
        if (str.equals("UNIVERSAL_FRIENDS")) {
            deobf.com.roblox.client.mw.c.d().j(new deobf.com.roblox.client.yh.g("UNIVERSAL_FRIENDS_TAG"));
            return;
        }
        if ("OPEN_YOUTUBE_VIDEO".equals(str)) {
            deobf.com.roblox.client.yh.g a10 = deobf.com.roblox.client.yh.g.a("YOUTUBE_TAG", str2);
            a10.j(true);
            deobf.com.roblox.client.mw.c.d().j(a10);
            return;
        }
        if (str.equals("ACTION_LOG_IN")) {
            deobf.com.withpersona.sdk2.inquiry.f4.v p10 = this.f13771d.a().p();
            if (p10 != null) {
                deobf.com.roblox.client.startup.ik.k0.s(p10).J();
                return;
            }
            return;
        }
        if (str.equals("DID_LOG_IN")) {
            deobf.com.withpersona.sdk2.inquiry.f4.v p11 = this.f13771d.a().p();
            if (p11 != null) {
                deobf.com.roblox.client.startup.ik.k0.G(p11, str2);
                return;
            }
            return;
        }
        if (str.equals("DID_SIGN_UP")) {
            deobf.com.withpersona.sdk2.inquiry.f4.v p12 = this.f13771d.a().p();
            if (p12 != null) {
                deobf.com.roblox.client.startup.ik.k0.s(p12).I(str2);
                return;
            }
            return;
        }
        if (str.equals("DID_LOG_OUT")) {
            if (deobf.com.roblox.client.bi.h.a().W1() && !deobf.com.roblox.client.dj.h.e().f()) {
                deobf.com.roblox.client.dj.b.f().o(b.d.LOGOUT_BY_USER_IN_LUA);
                deobf.com.roblox.client.startup.dl.j.e().g(deobf.com.roblox.client.bh.a1.O(), deobf.com.roblox.client.bh.a1.g());
            }
            deobf.com.withpersona.sdk2.inquiry.f4.v p13 = this.f13771d.a().p();
            if (p13 == null || !deobf.com.roblox.client.dj.h.e().f()) {
                return;
            }
            deobf.com.roblox.client.dj.b.f().i(p13, b.d.LOGOUT_BY_USER_IN_LUA);
            deobf.com.roblox.client.qm.a.a().c();
            if (deobf.com.roblox.client.bi.h.a().C3()) {
                NativeGLInterface.screenTimeStop();
                return;
            }
            return;
        }
        if (str.equals("DID_SWITCH_ACCOUNT")) {
            deobf.com.withpersona.sdk2.inquiry.f4.v p14 = this.f13771d.a().p();
            if (p14 != null) {
                deobf.com.roblox.client.dj.b.f().j(p14);
                deobf.com.roblox.client.qm.a.a().c();
                return;
            }
            return;
        }
        if (str.equals("NATIVE_SHARE")) {
            deobf.com.withpersona.sdk2.inquiry.f4.v p15 = this.f13771d.a().p();
            if (p15 == 0 || p15.isFinishing() || !(p15 instanceof deobf.unlinked.hk.c)) {
                return;
            }
            ((deobf.unlinked.hk.c) p15).k(str2);
            return;
        }
        if (str.equals("RESTART_LUA_APP")) {
            deobf.com.withpersona.sdk2.inquiry.f4.v p16 = this.f13771d.a().p();
            if (p16 != null) {
                p16.recreate();
                return;
            } else {
                deobf.com.roblox.client.ok.q.k("rbx.datamodel", "could not restart lua app");
                return;
            }
        }
        if (deobf.com.roblox.client.bi.h.a().l5() && str.equals("SET_STATUS_BAR_STYLE")) {
            try {
                final boolean optBoolean = new JSONObject(str2).optBoolean("hidden", false);
                deobf.com.withpersona.sdk2.inquiry.f4.v p17 = this.f13771d.a().p();
                if (p17 instanceof com.roblox.client.a) {
                    final com.roblox.client.a aVar = (com.roblox.client.a) p17;
                    aVar.runOnUiThread(new Runnable() { // from class: ei.m
                        @Override // java.lang.Runnable
                        public final void run() {
                            n.c(optBoolean, aVar);
                        }
                    });
                    return;
                }
                return;
            } catch (JSONException e11) {
                deobf.com.roblox.client.ok.q.e("rbx.datamodel", "Failed to parse SET_STATUS_BAR_STYLE data: " + e11.getMessage());
                return;
            }
        }
        if (str.equals("HOME_PAGE_INTERACTIVE")) {
            deobf.com.roblox.client.ok.q.h("rbx.datamodel", "Got callback to Java for home page is ready to interact.");
            deobf.com.withpersona.sdk2.inquiry.f4.v p18 = this.f13771d.a().p();
            if (p18 != null) {
                p18.reportFullyDrawn();
            }
            if (deobf.com.roblox.client.bi.h.a().W5() && p18 != null) {
                deobf.unlinked.li.i.o(p18);
            }
            com.roblox.client.startup.a.n();
            if (deobf.com.roblox.client.bi.h.a().v1()) {
                FlagCacheUtils.flushRetryDialogTelemetry();
                return;
            }
            return;
        }
        if (deobf.com.roblox.client.bi.h.a().X1() && str.equals("GAME_STREAMING_STATUS_CHANGED")) {
            try {
                boolean optBoolean2 = new JSONObject(str2).optBoolean("inGameStreaming", false);
                deobf.com.withpersona.sdk2.inquiry.f4.v p19 = this.f13771d.a().p();
                if (p19 != null) {
                    if (optBoolean2) {
                        deobf.unlinked.q0.f(p19);
                    } else {
                        deobf.unlinked.q0.i(p19);
                    }
                }
            } catch (JSONException e12) {
                deobf.com.roblox.client.ok.q.e("rbx.datamodel", "Failed to parse GAME_STREAMING_STATUS_CHANGED data: " + e12.getMessage());
            }
        }
    }

    public final void d(String str) {
        str.getClass();
        if (str.equals("Startup")) {
            deobf.com.roblox.client.eh.k.q().k("luaStartup");
        } else if (str.equals("Landing")) {
            deobf.com.roblox.client.eh.k.q().k("luaLandingScreen");
        }
    }

    public final void e() {
        deobf.com.roblox.client.eh.k.q().k("luaHomeScreen");
    }

    public final void f(JSONObject jSONObject) {
        deobf.com.roblox.client.bh.q.b(jSONObject, this.f13771d.a().p());
    }

    public void g() {
        if (this.f13771d.a().p() != null) {
            deobf.com.roblox.client.qm.a.a().b(new deobf.unlinked.a.b() { // from class: ei.l
                @Override // deobf.com.roblox.client.qm.a.b
                public final void a(JSONObject jSONObject) {
                    n.this.f(jSONObject);
                }
            });
        }
    }
}
