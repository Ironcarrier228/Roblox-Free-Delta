package deobf.com.roblox.client.ei;

import android.os.Bundle;
import androidx.annotation.NonNull;
import com.github.luben.zstd.BuildConfig;

// dex: classes2.dex
public class k0 {

    public long f13731a = 0;
    public long b = 0;

    public long f13732c = 0;

    public String f13733d = BuildConfig.FLAVOR;

    public String f13734e = BuildConfig.FLAVOR;

    public String f13735f = BuildConfig.FLAVOR;

    public String f13736g = BuildConfig.FLAVOR;

    public String f13737h = BuildConfig.FLAVOR;

    public String f13738i = BuildConfig.FLAVOR;

    public int f13739j = -1;

    public String f13740k = BuildConfig.FLAVOR;

    public String f13741l = BuildConfig.FLAVOR;

    public String f13742m = BuildConfig.FLAVOR;

    public String f13743n = BuildConfig.FLAVOR;

    public String f13744o = BuildConfig.FLAVOR;

    public String f13745p = BuildConfig.FLAVOR;

    public long f13746q = 0;

    public String f13747r = BuildConfig.FLAVOR;

    public static Bundle N(Bundle bundle, k0 k0Var) {
        if (k0Var == null) {
            return null;
        }
        if (bundle == null) {
            bundle = new Bundle();
        }
        bundle.putLong("mPlaceId", k0Var.p());
        bundle.putLong("mUserId", k0Var.u());
        bundle.putLong("mConversationId", k0Var.f());
        bundle.putString("mAccessCode", k0Var.d());
        bundle.putString("mLinkCode", k0Var.o());
        bundle.putString("mGameId", k0Var.h());
        bundle.putInt("mRequestType", k0Var.s());
        bundle.putString("mReferralPage", k0Var.q());
        bundle.putString("mLaunchData", k0Var.n());
        bundle.putString("mJoinAttemptId", k0Var.l());
        bundle.putString("mJoinAttemptOrigin", k0Var.m());
        bundle.putString("mIsoContext", k0Var.k());
        if (deobf.com.roblox.client.bi.h.a().e3()) {
            bundle.putLong("mReferredByPlayerId", k0Var.r());
        }
        if (deobf.com.roblox.client.bi.h.a().J0()) {
            bundle.putString("mReservedServerAccessCode", k0Var.t());
            bundle.putString("mCallId", k0Var.e());
        }
        bundle.putString("mGameJoinContext", k0Var.j());
        bundle.putString("roblox_event_id", k0Var.g());
        if (deobf.com.roblox.client.bi.h.a().H3()) {
            bundle.putString("game_id_to_exclude", k0Var.i());
        }
        return bundle;
    }

    public static Bundle O(k0 k0Var) {
        return N(null, k0Var);
    }

    public static k0 a(Long l10, Long l11, String str, String str2, String str3, String str4, String str5, Integer num, String str6, String str7, String str8, String str9, String str10, String str11, String str12, Long l12, String str13) {
        int i10;
        k0 k0Var = new k0();
        long longValue = l10 != null ? l10.longValue() : -1L;
        long longValue2 = l11 != null ? l11.longValue() : -1L;
        long longValue3 = l12 != null ? l12.longValue() : -1L;
        if (longValue2 != -1) {
            k0Var.M(longValue2);
            if (longValue != -1) {
                k0Var.H(longValue);
            }
            i10 = 1;
        } else if (longValue != -1) {
            k0Var.H(longValue);
            if (str2 != null) {
                k0Var.G(str2);
            } else if (str != null) {
                k0Var.v(str);
            } else {
                if (str3 != null) {
                    k0Var.z(str3);
                    i10 = 3;
                } else if (!deobf.com.roblox.client.bi.h.a().J0() || str4 == null) {
                    i10 = 0;
                } else {
                    k0Var.L(str4);
                    i10 = 8;
                }
                if (deobf.com.roblox.client.bi.h.a().J0() && str5 != null) {
                    k0Var.w(str5);
                }
            }
            i10 = 2;
            if (deobf.com.roblox.client.bi.h.a().J0()) {
                k0Var.w(str5);
            }
        } else {
            i10 = -1;
        }
        if (num != null) {
            k0Var.K(num.intValue());
        } else {
            k0Var.K(i10);
        }
        if (str6 != null) {
            k0Var.I(str6);
        }
        if (str7 != null) {
            k0Var.F(str7);
        }
        if (deobf.com.roblox.client.bi.h.a().e3() && longValue3 != -1) {
            k0Var.J(longValue3);
        }
        if (str8 != null) {
            k0Var.B(str8);
        }
        if (str9 != null) {
            k0Var.y(str9);
        }
        if (str10 != null) {
            k0Var.D(str10);
        }
        if (str11 != null) {
            k0Var.E(str11);
        }
        if (str12 != null) {
            k0Var.C(str12);
        }
        if (deobf.com.roblox.client.bi.h.a().H3() && str13 != null) {
            k0Var.A(str13);
        }
        return k0Var;
    }

    public static k0 b(Long l10, Long l11, String str, String str2, String str3) {
        k0 k0Var = new k0();
        long longValue = l10 != null ? l10.longValue() : -1L;
        long longValue2 = l11 != null ? l11.longValue() : -1L;
        if (longValue != -1 && longValue2 != -1) {
            k0Var.x(longValue2);
            k0Var.H(longValue);
            k0Var.K(6);
        }
        if (str != null) {
            k0Var.I(str);
        }
        if (str2 != null) {
            k0Var.D(str2);
        }
        if (str3 != null) {
            k0Var.E(str3);
        }
        return k0Var;
    }

    public static k0 c(Bundle bundle) {
        if (bundle == null) {
            return null;
        }
        k0 k0Var = new k0();
        k0Var.H(bundle.getLong("mPlaceId", 0L));
        k0Var.M(bundle.getLong("mUserId", 0L));
        k0Var.x(bundle.getLong("mConversationId", 0L));
        k0Var.v(bundle.getString("mAccessCode", BuildConfig.FLAVOR));
        k0Var.G(bundle.getString("mLinkCode", BuildConfig.FLAVOR));
        k0Var.z(bundle.getString("mGameId", BuildConfig.FLAVOR));
        k0Var.K(bundle.getInt("mRequestType", -1));
        k0Var.I(bundle.getString("mReferralPage", BuildConfig.FLAVOR));
        k0Var.F(bundle.getString("mLaunchData"));
        k0Var.D(bundle.getString("mJoinAttemptId", BuildConfig.FLAVOR));
        k0Var.E(bundle.getString("mJoinAttemptOrigin", BuildConfig.FLAVOR));
        k0Var.C(bundle.getString("mIsoContext", BuildConfig.FLAVOR));
        k0Var.B(bundle.getString("mGameJoinContext"));
        k0Var.y(bundle.getString("roblox_event_id"));
        if (deobf.com.roblox.client.bi.h.a().e3()) {
            k0Var.J(bundle.getLong("mReferredByPlayerId", 0L));
        }
        if (deobf.com.roblox.client.bi.h.a().J0()) {
            k0Var.L(bundle.getString("mReservedServerAccessCode", BuildConfig.FLAVOR));
            k0Var.w(bundle.getString("mCallId", BuildConfig.FLAVOR));
        }
        if (deobf.com.roblox.client.bi.h.a().H3()) {
            k0Var.A(bundle.getString("game_id_to_exclude", BuildConfig.FLAVOR));
        }
        return k0Var;
    }

    public void A(String str) {
        this.f13747r = str;
    }

    public void B(String str) {
        this.f13741l = str;
    }

    public void C(@NonNull String str) {
        this.f13745p = str;
    }

    public void D(String str) {
        this.f13743n = str;
    }

    public void E(String str) {
        this.f13744o = str;
    }

    public void F(String str) {
        this.f13740k = str;
    }

    public void G(String str) {
        this.f13734e = str;
    }

    public void H(long j10) {
        this.f13731a = j10;
    }

    public void I(String str) {
        this.f13738i = str;
    }

    public void J(long j10) {
        this.f13746q = j10;
    }

    public void K(int i10) {
        this.f13739j = i10;
    }

    public void L(String str) {
        this.f13736g = str;
    }

    public void M(long j10) {
        this.b = j10;
    }

    public String d() {
        return this.f13733d;
    }

    public String e() {
        return this.f13737h;
    }

    public long f() {
        return this.f13732c;
    }

    public String g() {
        return this.f13742m;
    }

    public String h() {
        return this.f13735f;
    }

    public String i() {
        return this.f13747r;
    }

    public String j() {
        return this.f13741l;
    }

    public String k() {
        return this.f13745p;
    }

    public String l() {
        return this.f13743n;
    }

    public String m() {
        return this.f13744o;
    }

    public String n() {
        return this.f13740k;
    }

    public String o() {
        return this.f13734e;
    }

    public long p() {
        return this.f13731a;
    }

    public String q() {
        return this.f13738i;
    }

    public long r() {
        return this.f13746q;
    }

    public int s() {
        return this.f13739j;
    }

    public String t() {
        return this.f13736g;
    }

    public String toString() {
        return getClass().getSimpleName() + "{ placeId:" + this.f13731a + ", userId:" + this.b + ", conversationId:" + this.f13732c + ", accessCode:" + this.f13733d + ", linkCode:" + this.f13734e + ", gameId:" + this.f13735f + ", reservedServerAccessCode:" + this.f13736g + ", callId:" + this.f13737h + ", reqType:" + this.f13739j + ", referralPage:" + this.f13738i + ", launchData:" + this.f13740k + ", gameJoinContext:" + this.f13741l + ", eventId:" + this.f13742m + ", joinAttemptId:" + this.f13743n + ", joinAttemptOrigin:" + this.f13744o + ", mIsoContext:" + this.f13745p + ", referredByPlayerId:" + this.f13746q + ", gameIdToExclude:" + this.f13747r + " }";
    }

    public long u() {
        return this.b;
    }

    public void v(String str) {
        this.f13733d = str;
    }

    public void w(String str) {
        this.f13737h = str;
    }

    public void x(long j10) {
        this.f13732c = j10;
    }

    public void y(String str) {
        this.f13742m = str;
    }

    public void z(String str) {
        this.f13735f = str;
    }
}
