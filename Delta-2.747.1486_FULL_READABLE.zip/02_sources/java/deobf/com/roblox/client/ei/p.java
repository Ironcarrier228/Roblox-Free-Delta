package deobf.com.roblox.client.ei;

import android.app.Activity;
import android.content.Context;
import android.graphics.Point;
import android.os.Build;
import deobf.com.roblox.client.bh.e2;
import com.github.luben.zstd.BuildConfig;
import com.roblox.engine.jni.model.DeviceParams;
import com.roblox.engine.jni.model.DeviceStaticParams;
import com.roblox.engine.jni.model.PlatformParams;
import com.roblox.platform.util.DeviceUtils;
import deobf.com.roblox.client.ei.f;
import java.util.Locale;

// dex: classes2.dex
public class p {

    public Context f13775a;

    public p(Context context) {
        this.f13775a = context;
    }

    public static f.d a(Context context) {
        return b(context, null);
    }

    public static f.d b(Context context, Activity activity) {
        p pVar = new p(context);
        com.roblox.engine.jni.model.a aVar = new com.roblox.engine.jni.model.a(pVar.f());
        aVar.f9661a = true;
        aVar.b = true;
        aVar.f9662c = true;
        aVar.f9663d = deobf.com.roblox.client.bh.a1.r0();
        DeviceParams d10 = pVar.d();
        f.d dVar = new f.d();
        dVar.b = aVar;
        dVar.f13697c = d10;
        dVar.f13698d = "rbxasset://places/Mobile.rbxl";
        dVar.f13699e = "LuaAppStarterScript";
        dVar.f13700f = deobf.unlinked.nk.c.c().j();
        dVar.f13701g = deobf.unlinked.nk.c.c().n();
        dVar.f13702h = deobf.unlinked.nk.c.c().k();
        dVar.f13703i = deobf.unlinked.nk.c.c().d();
        dVar.f13704j = deobf.unlinked.nk.c.c().i();
        dVar.f13696a = activity;
        return dVar;
    }

    public static DeviceParams c(Context context) {
        return new p(context).d();
    }

    public static DeviceStaticParams e() {
        String str;
        String str2;
        DeviceStaticParams deviceStaticParams = new DeviceStaticParams();
        int i10 = Build.VERSION.SDK_INT;
        deviceStaticParams.osVersion = Integer.toString(i10);
        deviceStaticParams.deviceName = deobf.com.roblox.client.bh.v.b();
        deviceStaticParams.appVersion = deobf.com.roblox.client.bh.a1.e1();
        deviceStaticParams.manufacturer = Build.MANUFACTURER;
        if (i10 >= 31) {
            str = Build.SKU;
            deviceStaticParams.deviceSku = str;
            str2 = Build.SOC_MODEL;
            deviceStaticParams.socModel = str2;
        }
        deviceStaticParams.appBuildVariant = deobf.com.roblox.client.ok.h.a();
        deviceStaticParams.cpu64Bit = Build.SUPPORTED_64_BIT_ABIS.length > 0;
        return deviceStaticParams;
    }

    public DeviceParams d() {
        String str;
        String str2;
        DeviceParams deviceParams = new DeviceParams();
        int i10 = Build.VERSION.SDK_INT;
        deviceParams.osVersion = Integer.toString(i10);
        deviceParams.deviceName = deobf.com.roblox.client.bh.v.b();
        deviceParams.appVersion = deobf.com.roblox.client.bh.a1.e1();
        Locale e10 = deobf.com.roblox.client.yi.b.f().e();
        deviceParams.country = e10 != null ? e10.getCountry() : BuildConfig.FLAVOR;
        deviceParams.manufacturer = Build.MANUFACTURER;
        deviceParams.deviceTotalMemoryMB = DeviceUtils.getDeviceTotalMegabytes(this.f13775a);
        Point screenSize = DeviceUtils.getScreenSize(this.f13775a);
        deviceParams.displayResolution = screenSize.x + "x" + screenSize.y;
        Point screenPhysicalSize = DeviceUtils.getScreenPhysicalSize(this.f13775a);
        deviceParams.displayPhysicalWidthPixels = screenPhysicalSize.x;
        deviceParams.displayPhysicalHeightPixels = screenPhysicalSize.y;
        deviceParams.networkType = e2.g(this.f13775a);
        deobf.androidx.constraintlayout.widget.e2.b(this.f13775a, deviceParams);
        deobf.androidx.constraintlayout.widget.e2.c(this.f13775a, deviceParams);
        deviceParams.isChrome = deobf.com.roblox.client.bh.a1.k0();
        deviceParams.appBuildVariant = deobf.com.roblox.client.ok.h.a();
        deviceParams.cpu64Bit = Build.SUPPORTED_64_BIT_ABIS.length > 0;
        if (i10 >= 31) {
            str = Build.SKU;
            deviceParams.deviceSku = str;
            str2 = Build.SOC_MODEL;
            deviceParams.socModel = str2;
        }
        if (deobf.com.roblox.client.bi.h.a().c2()) {
            deviceParams.testDeviceName = deobf.com.roblox.client.bh.v.c(this.f13775a);
        }
        return deviceParams;
    }

    public PlatformParams f() {
        String r10 = deobf.com.roblox.client.startup.uk.c.p().r();
        deobf.com.roblox.client.ok.q.b("DataModelParamsCreator", "getPlatformParams: assetFolderPath = " + r10);
        PlatformParams platformParams = new PlatformParams();
        platformParams.assetFolderPath = r10;
        platformParams.isTouchDevice = this.f13775a.getPackageManager().hasSystemFeature("android.hardware.touchscreen");
        platformParams.isMouseDevice = this.f13775a.getPackageManager().hasSystemFeature("android.hardware.type.pc");
        platformParams.isKeyboardDevice = this.f13775a.getPackageManager().hasSystemFeature("android.hardware.type.pc");
        platformParams.dpiScale = DeviceUtils.getScreenDensity(this.f13775a);
        Point screenPhysicalSizeInMillimeters = DeviceUtils.getScreenPhysicalSizeInMillimeters(this.f13775a);
        platformParams.viewportWidthMm = screenPhysicalSizeInMillimeters.x;
        platformParams.viewportHeightMm = screenPhysicalSizeInMillimeters.y;
        return platformParams;
    }
}
