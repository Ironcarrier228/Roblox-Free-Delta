package deobf.com.roblox.client.ei;

// dex: classes2.dex
public final /* synthetic */ class o {
}
