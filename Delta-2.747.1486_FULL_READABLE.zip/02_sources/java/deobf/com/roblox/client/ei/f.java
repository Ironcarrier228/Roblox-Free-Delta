package deobf.com.roblox.client.ei;

import android.app.Activity;
import android.content.Context;
import android.os.AsyncTask;
import android.view.Surface;
import com.roblox.client.RobloxApplication;
import com.roblox.client.startup.b;
import com.roblox.engine.jni.EngineJavaCallback2;
import com.roblox.engine.jni.EngineJavaCallbackWrapper;
import com.roblox.engine.jni.NativeGLInterface;
import com.roblox.engine.jni.NativeGLJavaInterface;
import com.roblox.engine.jni.autovalue.InitParams;
import com.roblox.engine.jni.autovalue.StartAppParams;
import com.roblox.engine.jni.model.DeviceParams;
import com.roblox.engine.jni.model.PlatformParams;
import com.roblox.universalapp.logging.LoggingProtocol;
import deobf.com.roblox.client.startup.dl.h;
import deobf.com.roblox.client.startup.ik.t2;
import java.util.Vector;
import java.util.concurrent.Callable;
import java.util.concurrent.Executors;
import java.util.function.Consumer;
import org.fmod.FMOD;

// dex: classes2.dex
public class f implements deobf.com.roblox.protocols.mediapicker.h.d {

    public boolean f13687f;

    public d f13689h;

    public AsyncTaskC0263f f13690i;

    public e f13692k;

    public final String f13683a = "rbx.appshell";
    public boolean b = false;

    public boolean f13684c = false;

    public boolean f13685d = false;

    public boolean f13686e = false;

    public boolean f13688g = false;

    public Vector<deobf.unlinked.wk.b> f13691j = new Vector<>();

    public class a implements h {

        public final /* synthetic */ h f13693a;

        public a(h hVar) {
            this.f13693a = hVar;
        }

        @Override // deobf.com.roblox.client.ei.f.h
        public void a(int i10) {
            LoggingProtocol.g("update_setting_to_app_bridge_end");
            if (i10 == 0) {
                this.f13693a.a(0);
            } else {
                this.f13693a.a(1);
            }
        }
    }

    public class b implements h {

        public final /* synthetic */ h f13694a;

        public b(h hVar) {
            this.f13694a = hVar;
        }

        @Override // deobf.com.roblox.client.ei.f.h
        public void a(int i10) {
            if (i10 == 0) {
                f.this.f13684c = true;
            }
            h hVar = this.f13694a;
            if (hVar != null) {
                hVar.a(i10);
            }
        }
    }

    public class c implements Runnable {

        public final /* synthetic */ d f13695a;

        public c(d dVar) {
            this.f13695a = dVar;
        }

        @Override // java.lang.Runnable
        public void run() {
            NativeGLInterface.initMaquettesSDK(this.f13695a.f13696a);
        }
    }

    public static class d {

        public Activity f13696a;
        public PlatformParams b;

        public DeviceParams f13697c;

        public String f13698d;

        public String f13699e;

        public long f13700f;

        public boolean f13701g;

        public String f13702h;

        public int f13703i;

        public String f13704j;

        public DeviceParams a() {
            return this.f13697c;
        }

        public PlatformParams b() {
            return this.b;
        }
    }

    public class e extends EngineJavaCallbackWrapper {
        public e(EngineJavaCallback2 engineJavaCallback2) {
            super(engineJavaCallback2);
        }

        @Override // com.roblox.engine.jni.EngineJavaCallbackWrapper, com.roblox.engine.jni.EngineJavaCallback2
        public void f(String str, String str2) {
            if (str.equals("APP_READY")) {
                f.this.q(str2);
            }
            super.f(str, str2);
        }
    }

    public static class AsyncTaskC0263f extends AsyncTask<Void, Void, Integer> {

        public h f13705a;
        public final String b = "rbx.appshell";

        public AsyncTaskC0263f(h hVar) {
            this.f13705a = hVar;
        }

        @Override // android.os.AsyncTask
        public Integer doInBackground(Void... voidArr) {
            String o10;
            b.C0155b u8 = com.roblox.client.startup.a.u();
            String d10 = u8.d();
            String e10 = u8.e();
            if (d10 == null || d10.isEmpty()) {
                return 1;
            }
            if (deobf.com.roblox.client.provider.wh.b.a()) {
                o10 = com.roblox.client.startup.a.o();
                StringBuilder sb2 = new StringBuilder();
                sb2.append("overridePayload = ");
                sb2.append(o10);
                deobf.com.roblox.client.ok.q.b("rbx.appshell", sb2.toString() != null ? o10 : "no overrides");
            } else {
                o10 = new deobf.unlinked.ek.a(RobloxApplication.f()).a();
            }
            return deobf.com.roblox.client.bi.h.a().e6() ? Integer.valueOf(NativeGLInterface.nativeInitClientSettingsSigned(d10, e10, o10, deobf.com.roblox.client.bh.a1.M())) : Integer.valueOf(NativeGLInterface.nativeInitClientSettings(d10, o10, deobf.com.roblox.client.bh.a1.M()));
        }

        @Override // android.os.AsyncTask
        public void onPostExecute(Integer num) {
            if (num.intValue() == 0) {
                NativeGLInterface.nativePostClientSettingsLoadedInitialization3(deobf.unlinked.t2.a(RobloxApplication.f()));
                deobf.com.roblox.client.ok.q.h("rbx.appshell", "GetClientSettingsTask onPostExecute initialized TaskScheduler");
            }
            h hVar = this.f13705a;
            if (hVar != null) {
                hVar.a(num.intValue());
            }
        }
    }

    public static class g {

        public static final f f13706a = new f();
    }

    public interface h {
        void a(int i10);
    }

    public static /* synthetic */ void b(deobf.androidx.camera.view.pe.e0 e0Var, String str) {
        LoggingProtocol.g("asset_unpack_end");
        e0Var.D(null);
    }

    public static /* synthetic */ void d(deobf.androidx.camera.view.pe.e0 e0Var, String str) {
        LoggingProtocol.g("asset_unpack_end");
        e0Var.D(null);
    }

    public static f j() {
        return g.f13706a;
    }

    public void A(deobf.unlinked.wk.c cVar) {
        if (this.b || (this.f13685d && deobf.com.roblox.client.bi.h.a().o2())) {
            NativeGLInterface.nativeAppBridgeV2SendAppEventOnGameLoaded(cVar.f35882a, cVar.b, cVar.f35883c);
        } else {
            deobf.com.roblox.client.ok.q.k("rbx.appshell", "ASMA.sendAppEventOnGameLoaded: The manager is not yet setup. Ignore.");
        }
    }

    public void B(boolean z10) {
        A(new deobf.unlinked.wk.a(z10));
    }

    public void C(deobf.unlinked.wk.b bVar) {
        if (bVar == null) {
            return;
        }
        this.f13691j.add(bVar);
        if (l()) {
            u(this.f13691j);
        }
    }

    public void D(EngineJavaCallback2 engineJavaCallback2) {
        e eVar = new e(engineJavaCallback2);
        this.f13692k = eVar;
        NativeGLJavaInterface.setImplementation(eVar);
    }

    public void E() {
        this.f13687f = true;
    }

    public void F(Context context) {
        deobf.com.roblox.client.ok.q.b("rbx.appshell", "ASMA.setup() " + this.b);
        if (this.b) {
            deobf.com.roblox.client.bh.a1.T0();
            return;
        }
        this.b = true;
        boolean L2 = deobf.com.roblox.client.bi.h.a().L2();
        if (L2) {
            LoggingProtocol.g("update_native_settings_begin");
        }
        deobf.com.roblox.client.bh.a1.W0();
        if (L2) {
            LoggingProtocol.g("update_native_settings_end");
        }
        if (L2) {
            LoggingProtocol.g("fmod_init_begin");
        }
        FMOD.init(context);
        if (L2) {
            LoggingProtocol.g("fmod_init_end");
        }
        if (L2) {
            LoggingProtocol.g("game_global_init_begin");
        }
        NativeGLInterface.nativeGameGlobalInit();
        if (L2) {
            LoggingProtocol.g("game_global_init_end");
        }
        deobf.com.roblox.client.bh.a1.V0();
        NativeGLInterface.nativeUpdateAdapterInit();
    }

    public void G(Surface surface) {
        if (this.f13685d) {
            this.f13688g = true;
            z();
            d i10 = i();
            StartAppParams.a h10 = StartAppParams.builder().i(surface).g(i10.b).b(i10.f13698d).c(i10.f13699e).d(i10.f13700f).e(i10.f13701g).j(i10.f13702h).f(i10.f13703i).h(i10.f13704j);
            if (deobf.com.roblox.client.bh.a1.E0()) {
                h10.k(i10.f13696a);
            }
            NativeGLInterface.nativeAppBridgeV2StartAppWithParams(h10.a());
            if (deobf.com.roblox.client.bh.a1.E0()) {
                Executors.newSingleThreadExecutor().execute(new c(i10));
            }
        }
    }

    public void H() {
        deobf.com.roblox.client.ok.q.b("rbx.appshell", "ASMA.stop");
        if (this.f13685d && this.f13688g) {
            this.f13688g = false;
            NativeGLInterface.nativeAppBridgeV2PauseApp();
            if (deobf.com.roblox.client.bh.y.h().f().i()) {
                return;
            }
            NativeGLInterface.setTaskSchedulerBackgroundMode(true, "ASMA.stop");
        }
    }

    public void I(Surface surface, float f10, int i10, int i11) {
        deobf.com.roblox.client.ok.q.b("rbx.appshell", "ASMA.updateWindowHandle");
        if (this.f13685d) {
            PlatformParams platformParams = new PlatformParams();
            platformParams.dpiScale = f10;
            platformParams.viewportWidthMm = i10;
            platformParams.viewportHeightMm = i11;
            NativeGLInterface.nativeAppBridgeV2UpdateSurfaceAppWithPlatformParams(surface, platformParams);
        }
    }

    @Override // deobf.com.roblox.client.startup.dl.h.d
    public void a() {
        deobf.com.roblox.client.ok.q.h("rbx.appshell", "onCookieChanged.");
        if (deobf.com.roblox.client.bi.h.a().W1()) {
            deobf.com.roblox.client.bh.a1.C0();
        }
        deobf.com.roblox.client.bh.a1.T0();
    }

    public void f() {
        synchronized (this) {
            g();
        }
    }

    public final void g() {
        if (this.f13685d) {
            deobf.com.roblox.client.ok.q.h("rbx.appshell", "ASMA.destroy() ....");
            NativeGLInterface.nativeAppBridgeV2DestroyApp();
        }
        v();
    }

    public final void h() {
        e eVar = this.f13692k;
        if (eVar != null) {
            NativeGLJavaInterface.setImplementation(eVar);
        }
    }

    public d i() {
        return this.f13689h;
    }

    public void k(d dVar) {
        deobf.com.roblox.client.ok.q.h("rbx.appshell", "ASMA.initializeDataModel: hasSettings:" + this.f13684c + ", isInitialized:" + this.f13685d + ", CrashWhenAppBridgeNotStarted:" + deobf.com.roblox.client.bi.h.a().v3() + ", appBridgeStarted:" + this.f13687f);
        if (!this.f13684c || this.f13685d) {
            return;
        }
        h();
        deobf.com.roblox.client.ok.q.b("rbx.appshell", "ASMA.initializeDataModel()");
        this.f13689h = dVar;
        this.f13685d = true;
        String g10 = deobf.com.roblox.client.bh.a1.g();
        InitParams.a h10 = InitParams.builder().i(dVar.b).d(dVar.f13697c).b(g10).j(deobf.com.roblox.client.bh.a1.a1()).f(deobf.com.roblox.client.bh.a1.r0()).h(0L);
        if (deobf.com.roblox.client.bi.h.a().j1()) {
            h10.c(deobf.com.roblox.client.ok.h.a());
        }
        h10.g(deobf.com.roblox.client.bh.a1.q0());
        h10.e(deobf.com.roblox.client.bh.a1.t0());
        if (dVar.b.assetFolderPath == null) {
            deobf.com.roblox.client.ok.q.e("rbx.appshell", "Asset folder path is null");
        } else {
            deobf.com.roblox.client.ok.q.h("rbx.appshell", "Asset folder path: " + dVar.b.assetFolderPath);
        }
        if (dVar.b.assetFolderPath == null) {
            throw new RuntimeException("Asset folder path is null");
        }
        if (deobf.com.roblox.client.bi.h.a().v3() && !this.f13687f) {
            throw new RuntimeException("AppBridge is not yet started");
        }
        NativeGLInterface.nativeAppBridgeV2InitWithParams(h10.a());
    }

    public boolean l() {
        return this.f13686e;
    }

    public boolean m() {
        return this.f13685d;
    }

    public final /* synthetic */ Object n(Context context, h hVar) {
        s(context, hVar, true);
        return null;
    }

    public void o(final Context context, final h hVar) {
        deobf.com.roblox.client.ok.q.h("rbx.appshell", "ASMA.loadAllAppSettings()");
        LoggingProtocol.g("asset_unpack_begin");
        final deobf.androidx.camera.view.pe.e0 H = deobf.androidx.camera.view.pe.e0.H();
        if (deobf.com.roblox.client.bi.h.a().D2()) {
            deobf.com.roblox.client.startup.uk.c.p().q().thenAccept(new Consumer() { // from class: ei.c
                @Override // java.util.function.Consumer
                public final void accept(Object obj) {
                    f.d(deobf.androidx.camera.view.pe.e0.this, (String) obj);
                }
            });
        } else {
            deobf.com.roblox.client.startup.uk.c.p().s(new Consumer() { // from class: ei.d
                @Override // java.util.function.Consumer
                public final void accept(Object obj) {
                    deobf.unlinked.f.b(deobf.androidx.camera.view.pe.e0.this, (String) obj);
                }
            });
        }
        deobf.androidx.camera.view.pe.s.o(com.roblox.client.startup.a.i(context), H).a(new Callable() { // from class: ei.e
            @Override // java.util.concurrent.Callable
            public final Object call() {
                Object n10;
                n10 = f.this.n(context, hVar);
                return n10;
            }
        }, deobf.androidx.camera.view.pe.a0.a());
    }

    public void p(h hVar) {
        deobf.com.roblox.client.ok.q.b("rbx.appshell", "ASMA.loadSettings() " + this.f13684c);
        if (this.f13684c) {
            deobf.com.roblox.client.ok.q.b("rbx.appshell", "ASMA.loadSettings() ... skipping because Init already does it!");
            if (hVar != null) {
                hVar.a(0);
                return;
            }
            return;
        }
        w();
        AsyncTaskC0263f asyncTaskC0263f = new AsyncTaskC0263f(new b(hVar));
        this.f13690i = asyncTaskC0263f;
        asyncTaskC0263f.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, new Void[0]);
    }

    public void q(String str) {
        deobf.com.roblox.client.ok.q.b("rbx.appshell", "ASMA.onAppReady() " + str);
        this.f13686e = true;
        u(this.f13691j);
    }

    public void r() {
        NativeGLInterface.nativeHandleBackPressed();
    }

    public final void s(Context context, h hVar, boolean z10) {
        if (deobf.com.roblox.client.bi.h.a().L2()) {
            LoggingProtocol.g("settings_join_resolved");
        }
        if (!z10) {
            hVar.a(1);
            return;
        }
        F(context);
        LoggingProtocol.g("update_setting_to_app_bridge_start");
        p(new a(hVar));
    }

    public void t() {
        deobf.com.roblox.client.ok.q.b("rbx.appshell", "ASMA.pause");
        if (this.f13685d) {
            deobf.com.roblox.client.ok.q.h("rbx.appshell", "ASMA.pause(): Do nothing in AppBridge refactor!");
            if (deobf.com.roblox.client.bh.y.h().f().i()) {
                return;
            }
            NativeGLInterface.setTaskSchedulerBackgroundMode(true, "ASMA.pause");
        }
    }

    public final void u(Vector<deobf.unlinked.wk.b> vector) {
        while (!vector.isEmpty()) {
            deobf.unlinked.wk.b remove = vector.remove(0);
            deobf.com.roblox.client.ok.q.b("rbx.appshell", "publishPendingReadyEvents() " + remove.f35882a + ", " + remove.b + ", " + remove.f35883c + ", " + remove.f35881d);
            NativeGLInterface.nativeAppBridgeV2SendAppEventOnAppReady(remove.f35882a, remove.b, remove.f35883c, remove.f35881d);
        }
    }

    public void v() {
        deobf.com.roblox.client.ok.q.b("rbx.appshell", "ASMA.reset()");
        this.b = false;
        this.f13685d = false;
        this.f13686e = false;
        this.f13689h = null;
        NativeGLJavaInterface.replaceImplementation(e.class, new EngineJavaCallback2());
        w();
        deobf.com.roblox.client.qm.a.a().c();
    }

    public final void w() {
        AsyncTaskC0263f asyncTaskC0263f = this.f13690i;
        if (asyncTaskC0263f != null && !asyncTaskC0263f.isCancelled()) {
            deobf.com.roblox.client.ok.q.h("rbx.appshell", "ASMA.resetTask: Cancel the current (running) task...");
            asyncTaskC0263f.cancel(true);
        }
        this.f13690i = null;
    }

    public void x(Context context, Surface surface) {
        y(context, surface, null);
    }

    public void y(Context context, Surface surface, Activity activity) {
        deobf.com.roblox.client.ok.q.h("rbx.appshell", "ASMA.restart");
        f();
        k(deobf.com.roblox.client.bh.a1.E0() ? deobf.unlinked.p.b(context, activity) : deobf.unlinked.p.a(context));
        G(surface);
    }

    public void z() {
        h();
        NativeGLInterface.setTaskSchedulerBackgroundMode(false, "ASMA.start");
    }
}
