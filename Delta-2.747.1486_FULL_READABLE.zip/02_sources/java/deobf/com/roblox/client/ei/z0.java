package deobf.com.roblox.client.ei;

// dex: classes2.dex
public abstract class z0 extends deobf.com.roblox.client.components.nh.a<Integer> {
    public z0() {
        super("rbx.game.orientation");
    }

    public static boolean j() {
        return true;
    }

    @Override // deobf.com.roblox.client.components.nh.a
    public long f() {
        return deobf.com.roblox.client.bi.h.a().n();
    }

    @Override // deobf.com.roblox.client.components.nh.a
    public int g() {
        return 3;
    }

    public abstract void h(int i10);

    @Override // deobf.com.roblox.client.components.nh.a
    public void a(Integer num) {
        h(num.intValue());
    }
}
