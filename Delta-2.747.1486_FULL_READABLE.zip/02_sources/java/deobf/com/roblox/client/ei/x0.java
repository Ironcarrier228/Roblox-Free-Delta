package deobf.com.roblox.client.ei;

import com.roblox.engine.jni.model.NativeTextBoxInfo;

// dex: classes2.dex
public interface x0 {
    void a();

    void b(long j10, boolean z10, String str, NativeTextBoxInfo nativeTextBoxInfo);

    void c();

    void d(String str);

    void e();
}
