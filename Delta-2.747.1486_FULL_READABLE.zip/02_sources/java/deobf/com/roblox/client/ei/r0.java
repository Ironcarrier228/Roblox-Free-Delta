package deobf.com.roblox.client.ei;

import android.widget.FrameLayout;
import deobf.com.roblox.client.bh.e2;
import com.roblox.client.RbxKeyboard;
import com.roblox.engine.jni.NativeGLInterface;
import com.roblox.engine.jni.model.NativeTextBoxInfo;
import java.util.Objects;

// dex: classes2.dex
public class r0 extends deobf.unlinked.fi.a {

    public NativeTextBoxInfo f13782c;

    public r0(RbxKeyboard rbxKeyboard) {
        super(rbxKeyboard);
    }

    @Override // deobf.com.roblox.client.ei.x0
    public void a() {
        deobf.com.roblox.client.ok.q.b("rbx.glview.text", "hideKeyboard()");
        this.b.e();
        this.b.setInputType(0);
        this.f13782c = null;
    }

    @Override // deobf.com.roblox.client.ei.x0
    public void b(long j10, boolean z10, String str, NativeTextBoxInfo nativeTextBoxInfo) {
        deobf.com.roblox.client.ok.q.b("rbx.glview.text", "showKeyboard() " + str);
        this.b.setCurrentTextBox(j10);
        if (deobf.com.roblox.client.bi.h.a().K2()) {
            this.b.i(nativeTextBoxInfo, str);
        }
        this.b.setText(str);
        if (z10) {
            this.f13782c = nativeTextBoxInfo;
            k(nativeTextBoxInfo, this.b);
        }
        if (deobf.com.roblox.client.bi.h.a().z1() && nativeTextBoxInfo == null) {
            this.b.setInputType(1);
            this.b.setImeOptions(268435460);
        }
        this.b.setVisibility(0);
        this.b.requestFocus();
        e2.k(this.b, 2);
        this.b.setSelection(str.length());
        j();
    }

    @Override // deobf.com.roblox.client.ei.x0
    public void c() {
        NativeTextBoxInfo nativeGetTextBoxInfo = NativeGLInterface.nativeGetTextBoxInfo();
        if (nativeGetTextBoxInfo != null) {
            deobf.com.roblox.client.ok.q.b("rbx.glview.text", "onLuaTextBoxPropertyChanged() x:" + nativeGetTextBoxInfo.f9659x + " y:" + nativeGetTextBoxInfo.f9660y + " width:" + nativeGetTextBoxInfo.width + " height:" + nativeGetTextBoxInfo.height + " fontSize:" + nativeGetTextBoxInfo.fontSize);
        }
        if (Objects.equals(nativeGetTextBoxInfo, this.f13782c)) {
            return;
        }
        this.f13782c = nativeGetTextBoxInfo;
        k(nativeGetTextBoxInfo, this.b);
        this.b.requestFocus();
    }

    @Override // deobf.com.roblox.client.ei.x0
    public void d(String str) {
        i(str);
    }

    @Override // deobf.com.roblox.client.ei.x0
    public void e() {
        RbxKeyboard rbxKeyboard = this.b;
        if (rbxKeyboard != null) {
            rbxKeyboard.h();
        }
    }

    public final void k(NativeTextBoxInfo nativeTextBoxInfo, RbxKeyboard rbxKeyboard) {
        l(nativeTextBoxInfo, rbxKeyboard);
        if (nativeTextBoxInfo != null) {
            rbxKeyboard.l(nativeTextBoxInfo);
            rbxKeyboard.m(nativeTextBoxInfo.font, nativeTextBoxInfo.fontSize, g());
        }
        rbxKeyboard.setVisibility(0);
    }

    public final void l(NativeTextBoxInfo nativeTextBoxInfo, RbxKeyboard rbxKeyboard) {
        FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) rbxKeyboard.getLayoutParams();
        float g10 = g();
        float f10 = (nativeTextBoxInfo != null ? nativeTextBoxInfo.f9659x : 0.0f) * g10;
        float f11 = (nativeTextBoxInfo != null ? nativeTextBoxInfo.f9660y : 0.0f) * g10;
        float f12 = (nativeTextBoxInfo != null ? nativeTextBoxInfo.width : 0.0f) * g10;
        float f13 = nativeTextBoxInfo != null ? nativeTextBoxInfo.height : 0.0f;
        layoutParams.topMargin = (int) f11;
        layoutParams.width = (int) f12;
        layoutParams.height = (int) (f13 * g10);
        layoutParams.leftMargin = (int) f10;
        rbxKeyboard.setLayoutParams(layoutParams);
        if (nativeTextBoxInfo != null) {
            rbxKeyboard.setPadding((int) (nativeTextBoxInfo.paddingLeft * g10), (int) (nativeTextBoxInfo.paddingTop * g10), (int) (nativeTextBoxInfo.paddingRight * g10), (int) (g10 * nativeTextBoxInfo.paddingBottom));
        } else {
            rbxKeyboard.setPadding(0, 0, 0, 0);
        }
    }
}
