package deobf.com.roblox.client.ei;

// dex: classes2.dex
public enum u0 {
    EXPERIENCE,
    APP
}
