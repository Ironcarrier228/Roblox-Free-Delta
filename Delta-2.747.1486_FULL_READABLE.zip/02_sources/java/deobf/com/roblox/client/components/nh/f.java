package deobf.com.roblox.client.components.nh;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ValueAnimator;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import android.view.animation.DecelerateInterpolator;
import deobf.com.roblox.client.bh.s0;
import com.google.mlkit.common.MlKitException;

// dex: classes2.dex
public class f {

    public View f25595a;
    public float b;

    public float f25596c;

    public float f25597d;

    public float f25598e;

    public int f25599f;

    public int f25600g;

    public int f25601h;

    public int f25602i;

    public int f25603j;

    public int f25604k;

    public int f25605l;

    public int f25606m;

    public boolean f25607n = false;

    public ValueAnimator f25608o = null;

    public ValueAnimator f25609p = null;

    public ValueAnimator f25610q = null;

    public Rect f25611r = null;

    public final int f25612s = 60;

    public final int f25613t = 10;

    public final int f25614u = 12105912;

    public final int f25615v = 3500;

    public final int f25616w = MlKitException.LOW_LIGHT_AUTO_EXPOSURE_COMPUTATION_FAILURE;

    public final float f25617x = 50.0f;

    public class a implements ValueAnimator.AnimatorUpdateListener {
        public a() {
        }

        @Override // android.animation.ValueAnimator.AnimatorUpdateListener
        public void onAnimationUpdate(ValueAnimator valueAnimator) {
            f.this.f25597d = ((Float) valueAnimator.getAnimatedValue()).floatValue();
            f.this.f25595a.invalidate();
        }
    }

    public class b implements ValueAnimator.AnimatorUpdateListener {
        public b() {
        }

        @Override // android.animation.ValueAnimator.AnimatorUpdateListener
        public void onAnimationUpdate(ValueAnimator valueAnimator) {
            f.this.f25601h = ((Integer) valueAnimator.getAnimatedValue()).intValue();
        }
    }

    public class c implements ValueAnimator.AnimatorUpdateListener {
        public c() {
        }

        @Override // android.animation.ValueAnimator.AnimatorUpdateListener
        public void onAnimationUpdate(ValueAnimator valueAnimator) {
            f.this.f25601h = ((Integer) valueAnimator.getAnimatedValue()).intValue();
            f.this.f25595a.invalidate();
        }
    }

    public class d extends AnimatorListenerAdapter {
        public d() {
        }

        @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
        public void onAnimationEnd(Animator animator) {
            super.onAnimationEnd(animator);
            f.this.f25607n = false;
            f.this.h();
        }
    }

    public f(View view, AttributeSet attributeSet) {
        this.f25595a = null;
        if (view != null) {
            this.f25595a = view;
            if (attributeSet == null) {
                this.f25597d = 50.0f;
                this.f25598e = 50.0f;
                this.f25602i = 3500;
                this.f25603j = MlKitException.LOW_LIGHT_AUTO_EXPOSURE_COMPUTATION_FAILURE;
                this.f25599f = 60;
                this.f25600g = 10;
                this.f25604k = 12105912;
                this.f25606m = 12105912;
                return;
            }
            TypedArray obtainStyledAttributes = view.getContext().obtainStyledAttributes(attributeSet, s0.B0);
            float f10 = obtainStyledAttributes.getFloat(s0.I0, 50.0f);
            this.f25597d = f10;
            this.f25598e = f10;
            this.f25602i = obtainStyledAttributes.getInt(s0.E0, 3500);
            this.f25603j = obtainStyledAttributes.getInt(s0.F0, MlKitException.LOW_LIGHT_AUTO_EXPOSURE_COMPUTATION_FAILURE);
            this.f25599f = obtainStyledAttributes.getInt(s0.G0, 60);
            this.f25600g = obtainStyledAttributes.getInt(s0.C0, 10);
            this.f25604k = obtainStyledAttributes.getColor(s0.H0, 12105912);
            this.f25606m = obtainStyledAttributes.getColor(s0.D0, 12105912);
            obtainStyledAttributes.recycle();
        }
    }

    public final boolean f() {
        ValueAnimator valueAnimator;
        ValueAnimator valueAnimator2;
        ValueAnimator valueAnimator3 = this.f25608o;
        return valueAnimator3 != null && valueAnimator3.isRunning() && (valueAnimator = this.f25609p) != null && valueAnimator.isRunning() && (valueAnimator2 = this.f25610q) != null && valueAnimator2.isRunning();
    }

    public final float g(int i10, int i11) {
        int i12;
        int i13;
        Rect rect = this.f25611r;
        if (rect != null) {
            int i14 = rect.left;
            int i15 = i10 - i14;
            int i16 = rect.right;
            i12 = i15 > i16 - i10 ? i10 - i14 : i16 - i10;
            int i17 = rect.top;
            int i18 = i11 - i17;
            int i19 = rect.bottom;
            i13 = i18 > i19 - i11 ? i11 - i17 : i19 - i11;
        } else {
            i12 = 0;
            i13 = 0;
        }
        if (i13 > i12) {
            i12 = i13;
        }
        return i12 + 300.0f;
    }

    public final void h() {
        ValueAnimator valueAnimator = this.f25608o;
        if (valueAnimator != null) {
            valueAnimator.cancel();
            this.f25608o.removeAllListeners();
        }
        ValueAnimator valueAnimator2 = this.f25609p;
        if (valueAnimator2 != null) {
            valueAnimator2.cancel();
            this.f25609p.removeAllListeners();
        }
        ValueAnimator valueAnimator3 = this.f25610q;
        if (valueAnimator3 != null) {
            valueAnimator3.cancel();
            this.f25610q.removeAllListeners();
        }
    }

    public void i(Canvas canvas) {
        if (this.f25607n) {
            Paint paint = new Paint(1);
            paint.setColor(this.f25605l);
            paint.setAlpha(this.f25601h);
            canvas.drawCircle(this.b, this.f25596c, this.f25597d, paint);
        }
    }

    public final void j() {
        if (f()) {
            h();
        }
        ValueAnimator ofInt = ValueAnimator.ofInt(this.f25601h, 0);
        this.f25609p = ofInt;
        ofInt.addUpdateListener(new c());
        this.f25609p.addListener(new d());
        this.f25609p.setDuration(this.f25603j);
        this.f25609p.setInterpolator(new DecelerateInterpolator());
        this.f25609p.start();
    }

    public final boolean k(int i10, int i11) {
        int[] iArr = new int[2];
        this.f25595a.getLocationInWindow(iArr);
        int i12 = iArr[0];
        int i13 = iArr[1];
        return i10 >= i12 && i10 <= i12 + this.f25595a.getWidth() && i11 >= i13 && i11 <= i13 + this.f25595a.getHeight();
    }

    public void l(MotionEvent motionEvent) {
        if (this.f25611r == null) {
            Rect rect = new Rect();
            this.f25611r = rect;
            this.f25595a.getDrawingRect(rect);
        }
        int action = motionEvent.getAction();
        if (action == 0) {
            this.f25607n = true;
            this.b = motionEvent.getX();
            this.f25596c = motionEvent.getY();
            m();
            return;
        }
        if (action == 1) {
            j();
            return;
        }
        if (action != 2) {
            if (action != 3) {
                return;
            }
            j();
        } else {
            if (k((int) motionEvent.getRawX(), (int) motionEvent.getRawY())) {
                return;
            }
            j();
        }
    }

    public final void m() {
        if (f()) {
            h();
        }
        float f10 = this.f25598e;
        this.f25597d = f10;
        this.f25601h = this.f25599f;
        this.f25605l = this.f25604k;
        ValueAnimator ofFloat = ValueAnimator.ofFloat(f10, g((int) this.b, (int) this.f25596c));
        this.f25608o = ofFloat;
        ofFloat.addUpdateListener(new a());
        this.f25608o.setDuration(this.f25602i);
        this.f25608o.setInterpolator(new deobf.unlinked.h4.c());
        this.f25608o.start();
        ValueAnimator ofInt = ValueAnimator.ofInt(this.f25601h, this.f25600g);
        this.f25609p = ofInt;
        ofInt.addUpdateListener(new b());
        this.f25609p.setDuration(this.f25602i);
        this.f25609p.setInterpolator(new deobf.unlinked.h4.a());
        this.f25609p.start();
    }
}
