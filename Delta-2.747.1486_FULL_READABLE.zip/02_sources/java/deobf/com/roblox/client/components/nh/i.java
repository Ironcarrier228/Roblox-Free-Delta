package deobf.com.roblox.client.components.nh;

import deobf.com.withpersona.sdk2.inquiry.av.p0;
import deobf.com.withpersona.sdk2.inquiry.av.q0;
import com.github.luben.zstd.BuildConfig;
import deobf.com.withpersona.sdk2.inquiry.gu.m;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import deobf.com.withpersona.sdk2.inquiry.zt.o;

@Metadata(d1 = {"\u0000&\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\b\u0003\u0018\u00002\u00020\u0001B\u0017\u0012\u0006\u0010\u0003\u001a\u00020\u0002\u0012\u0006\u0010\u0005\u001a\u00020\u0004¢\u0006\u0004\b\u0006\u0010\u0007J\r\u0010\t\u001a\u00020\b¢\u0006\u0004\b\t\u0010\nJ\r\u0010\u000b\u001a\u00020\b¢\u0006\u0004\b\u000b\u0010\nR\u0014\u0010\u0003\u001a\u00020\u00028\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b\f\u0010\rR\u0014\u0010\u0005\u001a\u00020\u00048\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b\t\u0010\u000eR\u0018\u0010\u0011\u001a\u0004\u0018\u00010\u000f8\u0002@\u0002X\u0082\u000e¢\u0006\u0006\n\u0004\b\u000b\u0010\u0010¨\u0006\u0012"}, d2 = {"Lnh/i;", BuildConfig.FLAVOR, "Lwl/c;", "designFoundations", "Ljava/lang/Runnable;", "onTokensChanged", "<init>", "(Lwl/c;Ljava/lang/Runnable;)V", BuildConfig.FLAVOR, deobf.android.view.k6.b.f21144e, "()V", "c", deobf.android.view.xe.a.f36648e, "Lwl/c;", "Ljava/lang/Runnable;", "Lav/p0;", "Lav/p0;", "scope", "NativeShell_googleProdRelease"}, k = 1, mv = {2, 2, 0}, xi = 48)
// dex: classes2.dex
public final class i {

    @NotNull
    public final deobf.com.roblox.protocols.designfoundations.wl.c designFoundations;

    @NotNull
    public final Runnable onTokensChanged;

    @Nullable
    public p0 scope;

    @Metadata(d1 = {"\u0000\b\n\u0000\n\u0002\u0010\u0002\n\u0000\u0010\u0000\u001a\u00020\u00012\u0006\u0010\u0002\u001a\u00020\u0001H\n"}, d2 = {"<anonymous>", BuildConfig.FLAVOR, "it"}, k = 3, mv = {2, 2, 0}, xi = 48)
    @deobf.com.withpersona.sdk2.inquiry.gu.f(c = "com.roblox.client.components.ToolbarTokensObserver$start$1", f = "ToolbarTokensObserver.kt", l = {}, m = "invokeSuspend", v = 1)
    public static final class a extends m implements Function2<Unit, deobf.kotlin.eu.b<? super Unit>, Object> {

        public int f25625t;

        public a(deobf.kotlin.eu.b<? super a> bVar) {
            super(2, bVar);
        }

        @Override // deobf.com.withpersona.sdk2.inquiry.gu.a
        public final deobf.kotlin.eu.b<Unit> create(Object obj, deobf.kotlin.eu.b<?> bVar) {
            return i.this.new a(bVar);
        }

        @Override // deobf.com.withpersona.sdk2.inquiry.gu.a
        public final Object invokeSuspend(Object obj) {
            deobf.kotlin.fu.c.e();
            if (this.f25625t != 0) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            deobf.com.google.android.material.o.b(obj);
            i.this.onTokensChanged.run();
            return Unit.f21504a;
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(Unit unit, deobf.kotlin.eu.b<? super Unit> bVar) {
            return ((a) create(unit, bVar)).invokeSuspend(Unit.f21504a);
        }
    }

    public i(@NotNull deobf.com.roblox.protocols.designfoundations.wl.c designFoundations, @NotNull Runnable onTokensChanged) {
        Intrinsics.checkNotNullParameter(designFoundations, "designFoundations");
        Intrinsics.checkNotNullParameter(onTokensChanged, "onTokensChanged");
        this.designFoundations = designFoundations;
        this.onTokensChanged = onTokensChanged;
    }

    public final void b() {
        this.scope = deobf.unlinked.q0.b();
        deobf.kotlin.dv.h E = deobf.kotlin.dv.j.E(this.designFoundations.a(), new a(null));
        p0 p0Var = this.scope;
        Intrinsics.checkNotNull(p0Var);
        deobf.kotlin.dv.j.z(E, p0Var);
    }

    public final void c() {
        p0 p0Var = this.scope;
        if (p0Var != null) {
            deobf.unlinked.q0.f(p0Var, null, 1, null);
        }
        this.scope = null;
    }
}
