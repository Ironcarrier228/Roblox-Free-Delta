package deobf.com.roblox.client.components.nh;

import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;
import deobf.com.roblox.client.ok.q;

// dex: classes2.dex
public abstract class a<T> implements Runnable {

    public AtomicBoolean f25583a = new AtomicBoolean(false);
    public AtomicInteger b = new AtomicInteger(0);

    public T f25584c;

    public ScheduledExecutorService f25585d;

    public ScheduledFuture<?> f25586e;

    public String f25587f;

    public a(String str) {
        this.f25587f = str;
    }

    public abstract void a(T t8);

    public final ScheduledExecutorService b() {
        if (this.f25585d == null) {
            this.f25585d = Executors.newSingleThreadScheduledExecutor();
        }
        return this.f25585d;
    }

    public final synchronized T c() {
        return this.f25584c;
    }

    public final void d(long j10) {
        this.f25586e = b().schedule(this, j10, TimeUnit.MILLISECONDS);
    }

    public synchronized void e(T t8) {
        try {
            if (!this.f25583a.get() && (g() <= 0 || this.b.incrementAndGet() < g())) {
                long f10 = f();
                if (f10 <= 0) {
                    a(t8);
                    return;
                }
                deobf.androidx.appcompat.widget.q.h(this.f25587f, "queue value: " + t8);
                this.f25584c = t8;
                if (this.f25586e == null) {
                    d(f10);
                }
                return;
            }
            ScheduledFuture<?> scheduledFuture = this.f25586e;
            if (scheduledFuture != null) {
                scheduledFuture.cancel(false);
            }
            this.f25584c = t8;
            deobf.androidx.appcompat.widget.q.h(this.f25587f, "set immediately: " + t8);
            a(t8);
            this.f25583a.set(true);
        } catch (Throwable th2) {
            throw th2;
        }
    }

    public abstract long f();

    public abstract int g();

    @Override // java.lang.Runnable
    public synchronized void run() {
        a(c());
        this.f25583a.set(true);
    }
}
