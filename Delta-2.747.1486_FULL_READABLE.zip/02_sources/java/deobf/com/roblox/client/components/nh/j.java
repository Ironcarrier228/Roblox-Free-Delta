package deobf.com.roblox.client.components.nh;

import android.view.MotionEvent;
import deobf.com.roblox.client.ok.q;

// dex: classes2.dex
public class j {
    public static int b = 0;

    public static int f25627c = 1;

    public static int f25628d = 2;

    public int f25629a = b;

    public void a(int i10) {
        this.f25629a = i10;
    }

    public boolean b(MotionEvent motionEvent) {
        int i10 = this.f25629a;
        if (i10 > b) {
            if (i10 == f25627c && (motionEvent.getFlags() & 1) == 1) {
                deobf.androidx.appcompat.widget.q.b("rbx.input", "WINDOW_IS_OBSCURED");
                return false;
            }
            if (this.f25629a == f25628d && (motionEvent.getFlags() & 2) == 2) {
                deobf.androidx.appcompat.widget.q.b("rbx.input", "WINDOW_IS_PARTIALLY_OBSCURED");
                return false;
            }
        }
        return true;
    }
}
