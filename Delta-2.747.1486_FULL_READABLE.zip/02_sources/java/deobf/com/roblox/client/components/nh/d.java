package deobf.com.roblox.client.components.nh;

import android.os.Handler;
import android.os.Message;
import com.google.mlkit.common.MlKitException;
import java.util.Iterator;
import java.util.Vector;
import deobf.com.roblox.client.ok.q;

// dex: classes2.dex
public abstract class d extends Handler {

    public String f25591a;
    public int b = 0;

    public Vector<a> f25592c = new Vector<>();

    public interface a {
        void start();
    }

    public d(String str) {
        this.f25591a = str;
    }

    public void a(a aVar) {
        this.f25592c.add(aVar);
        this.b++;
    }

    public abstract void b();

    public void c() {
        Iterator<a> it = this.f25592c.iterator();
        while (it.hasNext()) {
            it.next().start();
        }
    }

    public void d(String str) {
        sendMessage(obtainMessage(MlKitException.CODE_SCANNER_UNAVAILABLE, str));
    }

    public void e() {
        sendMessage(obtainMessage(100));
    }

    @Override // android.os.Handler
    public void handleMessage(Message message) {
        int i10 = message.what;
        if (i10 == 100 && this.b > 0) {
            deobf.androidx.appcompat.widget.q.i("rbx.execute", "MTCH.handleMessage() group:" + this.f25591a + " START size:" + this.b);
            c();
        } else if (i10 == 200) {
            this.b--;
            deobf.androidx.appcompat.widget.q.i("rbx.execute", "MTCH.handleMessage() task:" + message.obj + " COMPLETE size:" + this.b);
        }
        if (this.b <= 0) {
            deobf.androidx.appcompat.widget.q.i("rbx.execute", "MTCH.handleMessage() group:" + this.f25591a + " complete");
            b();
        }
    }
}
