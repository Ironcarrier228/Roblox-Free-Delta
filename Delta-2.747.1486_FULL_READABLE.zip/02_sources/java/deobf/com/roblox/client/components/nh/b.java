package deobf.com.roblox.client.components.nh;

import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;
import deobf.com.roblox.client.ok.q;

// dex: classes2.dex
public abstract class b<T> implements Runnable {

    public T f25588a;
    public ScheduledExecutorService b;

    public ScheduledFuture<?> f25589c;

    public String f25590d;

    public b(String str) {
        this.f25590d = str;
    }

    public abstract void a(T t8);

    public final ScheduledExecutorService b() {
        if (this.b == null) {
            this.b = Executors.newSingleThreadScheduledExecutor();
        }
        return this.b;
    }

    public final synchronized T c() {
        return this.f25588a;
    }

    public final void d(long j10) {
        this.f25589c = b().schedule(this, j10, TimeUnit.MILLISECONDS);
    }

    public void e(T t8, long j10) {
        ScheduledFuture<?> scheduledFuture = this.f25589c;
        if (scheduledFuture != null && !scheduledFuture.isDone()) {
            this.f25589c.cancel(true);
        }
        if (j10 <= 0) {
            a(t8);
            return;
        }
        deobf.androidx.appcompat.widget.q.h(this.f25590d, "queue value: " + t8);
        this.f25588a = t8;
        d(j10);
    }

    @Override // java.lang.Runnable
    public void run() {
        a(c());
    }
}
