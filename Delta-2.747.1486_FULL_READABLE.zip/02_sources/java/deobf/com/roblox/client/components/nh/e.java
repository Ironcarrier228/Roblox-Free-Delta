package deobf.com.roblox.client.components.nh;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Typeface;
import android.util.AttributeSet;
import android.util.Pair;
import android.widget.TextView;
import deobf.com.roblox.client.bh.s0;
import com.github.luben.zstd.BuildConfig;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Map;
import deobf.com.roblox.client.ok.n;
import deobf.com.roblox.client.ok.q;

// dex: classes2.dex
public class e {

    public static Map<Integer, Pair<String, Float>> f25593a;

    public static class a {

        public static Hashtable<String, Typeface> f25594a = new Hashtable<>();

        public static Typeface a(String str, Context context) {
            Typeface typeface = f25594a.get(str);
            if (typeface != null) {
                return typeface;
            }
            if (deobf.com.roblox.client.bi.h.a().h1()) {
                deobf.com.roblox.client.ok.d.a(str);
            }
            try {
                Typeface createFromAsset = Typeface.createFromAsset(context.getAssets(), str);
                f25594a.put(str, createFromAsset);
                return createFromAsset;
            } catch (Exception unused) {
                return null;
            }
        }
    }

    public static Map<Integer, Pair<String, Float>> a(Context context) {
        try {
            HashMap hashMap = new HashMap();
            if (deobf.com.roblox.client.bi.h.a().h1()) {
                deobf.com.roblox.client.ok.d.a("android/fonts/font-mappings.json");
            }
            deobf.com.google.android.gms.tg.a p8 = n.b().p(new BufferedReader(new InputStreamReader(context.getAssets().open("android/fonts/font-mappings.json"))));
            p8.b();
            while (p8.p()) {
                String str = BuildConfig.FLAVOR;
                p8.c();
                int i10 = -1;
                float f10 = 0.793f;
                while (p8.p()) {
                    String E = p8.E();
                    if (E.equals("enum")) {
                        i10 = p8.z();
                    } else if (E.equals("font")) {
                        str = p8.N();
                    } else if (E.equals("fromRbxFontRatio")) {
                        f10 = (float) p8.y();
                    } else {
                        p8.n0();
                    }
                }
                hashMap.put(Integer.valueOf(i10), Pair.create(str, Float.valueOf(f10)));
                p8.h();
            }
            p8.g();
            return hashMap;
        } catch (IOException e10) {
            deobf.androidx.appcompat.widget.q.f("rbx.glview.text", "Unable to parse mapping json", e10);
            return new HashMap();
        }
    }

    public static float b(int i10, Context context) {
        if (f25593a == null) {
            f25593a = a(context);
        }
        if (f25593a.containsKey(Integer.valueOf(i10))) {
            return ((Float) f25593a.get(Integer.valueOf(i10)).second).floatValue();
        }
        return 0.793f;
    }

    public static void c(TextView textView, Context context, AttributeSet attributeSet) {
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, s0.f4360y0);
        String string = obtainStyledAttributes.getString(s0.f4362z0);
        if (string == null) {
            string = "SourceSansPro-Light.ttf";
        }
        d(textView, context, string);
        obtainStyledAttributes.recycle();
    }

    public static void d(TextView textView, Context context, String str) {
        if (str != null) {
            Typeface a10 = deobf.unlinked.a.a("fonts/" + str, context);
            if (a10 != null) {
                textView.setTypeface(a10);
            }
        }
    }

    public static boolean e(TextView textView, Context context, int i10) {
        if (f25593a == null) {
            f25593a = a(context);
        }
        if (f25593a.containsKey(Integer.valueOf(i10))) {
            return f(textView, (String) f25593a.get(Integer.valueOf(i10)).first, context);
        }
        return false;
    }

    public static boolean f(TextView textView, String str, Context context) {
        if (str == null || !deobf.com.roblox.client.startup.uk.c.p().j()) {
            return false;
        }
        Typeface a10 = deobf.unlinked.a.a("content/fonts/" + str, context);
        if (a10 != null) {
            textView.setTypeface(a10);
            return true;
        }
        deobf.androidx.appcompat.widget.q.e("rbx.glview.text", String.format("Attempting to load non-existant font: %s.", str));
        return false;
    }
}
