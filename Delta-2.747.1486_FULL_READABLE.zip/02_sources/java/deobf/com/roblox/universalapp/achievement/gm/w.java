package deobf.com.roblox.universalapp.achievement.gm;

import android.util.Log;
import deobf.com.withpersona.sdk2.inquiry.av.g1;
import deobf.com.withpersona.sdk2.inquiry.av.p0;
import deobf.com.withpersona.sdk2.inquiry.av.w0;
import com.appsflyer.share.attribution.RequestError;
import com.github.luben.zstd.BuildConfig;
import java.io.Serializable;
import java.util.List;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(d1 = {"\u0000&\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0006\u0018\u0000 \f2\u00020\u0001:\u0001\rB\u0017\u0012\u0006\u0010\u0003\u001a\u00020\u0002\u0012\u0006\u0010\u0005\u001a\u00020\u0004¢\u0006\u0004\b\u0006\u0010\u0007J\u0010\u0010\t\u001a\u00020\bH\u0086@¢\u0006\u0004\b\t\u0010\nJ\u0010\u0010\f\u001a\u00020\u000bH\u0086@¢\u0006\u0004\b\f\u0010\nR\u0014\u0010\u0003\u001a\u00020\u00028\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b\r\u0010\u000eR\u0014\u0010\u0005\u001a\u00020\u00048\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b\u000f\u0010\u0010¨\u0006\u0011"}, d2 = {"Lgm/w;", BuildConfig.FLAVOR, "Lgm/b;", "local", "Lgm/v;", "remote", "<init>", "(Lgm/b;Lgm/v;)V", "Ljava/io/Serializable;", "d", "(Leu/b;)Ljava/lang/Object;", BuildConfig.FLAVOR, "c", deobf.android.view.xe.a.f36648e, "Lgm/b;", deobf.android.view.k6.b.f21144e, "Lgm/v;", "universalapp_googleProdRelease"}, k = 1, mv = {2, 2, 0}, xi = 48)
// dex: classes2.dex
public final class w {

    @NotNull
    public final deobf.com.roblox.universalapp.achievement.gm.b local;

    @NotNull
    public final v remote;

    @Metadata(d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0010\b\n\u0002\b\u0002\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\n¢\u0006\u0004\b\u0002\u0010\u0003"}, d2 = {"Lav/p0;", BuildConfig.FLAVOR, "<anonymous>", "(Lav/p0;)I"}, k = 3, mv = {2, 2, 0})
    @deobf.com.withpersona.sdk2.inquiry.gu.f(c = "com.roblox.universalapp.achievement.Replicator$syncLocalToRemote$2", f = "Replicator.kt", l = {RequestError.NO_DEV_KEY, 82}, m = "invokeSuspend", v = 1)
    public static final class b extends deobf.com.withpersona.sdk2.inquiry.gu.m implements Function2<p0, deobf.kotlin.eu.b<? super Integer>, Object> {

        public Object f17808t;

        public Object f17809u;

        public int f17810v;

        public int f17811w;

        public /* synthetic */ Object f17812x;

        @Metadata(d1 = {"\u0000\u0010\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u000e\n\u0002\b\u0002\u0010\u0003\u001a\n\u0012\u0006\u0012\u0004\u0018\u00010\u00020\u0001*\u00020\u0000H\n¢\u0006\u0004\b\u0003\u0010\u0004"}, d2 = {"Lav/p0;", "Lzt/n;", BuildConfig.FLAVOR, "<anonymous>", "(Lav/p0;)Lzt/n;"}, k = 3, mv = {2, 2, 0})
        @deobf.com.withpersona.sdk2.inquiry.gu.f(c = "com.roblox.universalapp.achievement.Replicator$syncLocalToRemote$2$2$1$1", f = "Replicator.kt", l = {54}, m = "invokeSuspend", v = 1)
        public static final class a extends deobf.com.withpersona.sdk2.inquiry.gu.m implements Function2<p0, deobf.kotlin.eu.b<? super deobf.com.withpersona.sdk2.inquiry.zt.n<? extends String>>, Object> {

            public int f17814t;

            public final /* synthetic */ w f17815u;

            public final /* synthetic */ Achievement f17816v;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            public a(w wVar, Achievement achievement, deobf.kotlin.eu.b<? super a> bVar) {
                super(2, bVar);
                this.f17815u = wVar;
                this.f17816v = achievement;
            }

            @Override // deobf.com.withpersona.sdk2.inquiry.gu.a
            public final deobf.kotlin.eu.b<Unit> create(Object obj, deobf.kotlin.eu.b<?> bVar) {
                return new a(this.f17815u, this.f17816v, bVar);
            }

            public final Object invoke2(p0 p0Var, deobf.kotlin.eu.b<? super deobf.com.withpersona.sdk2.inquiry.zt.n<String>> bVar) {
                return ((a) create(p0Var, bVar)).invokeSuspend(Unit.f21504a);
            }

            @Override // deobf.com.withpersona.sdk2.inquiry.gu.a
            public final Object invokeSuspend(Object obj) {
                Object a10;
                Object b;
                Object e10 = deobf.kotlin.fu.c.e();
                int i10 = this.f17814t;
                if (i10 == 0) {
                    deobf.com.withpersona.sdk2.inquiry.zt.o.b(obj);
                    v vVar = this.f17815u.remote;
                    Achievement achievement = this.f17816v;
                    this.f17814t = 1;
                    a10 = vVar.a(achievement, this);
                    if (a10 == e10) {
                        return e10;
                    }
                } else {
                    if (i10 != 1) {
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                    deobf.com.withpersona.sdk2.inquiry.zt.o.b(obj);
                    a10 = ((deobf.com.withpersona.sdk2.inquiry.zt.n) obj).getValue();
                }
                Achievement achievement2 = this.f17816v;
                if (deobf.com.withpersona.sdk2.inquiry.zt.n.h(a10)) {
                    boolean booleanValue = ((Boolean) a10).booleanValue();
                    if (!booleanValue) {
                        Log.w("rbx.achievement.replicator", "remote grant of " + achievement2.getCodeName() + " failed");
                    }
                    if (deobf.com.roblox.client.bi.h.a().C()) {
                        t.f17797a.n("remote", achievement2.getCodeName(), booleanValue);
                    }
                    String codeName = achievement2.getCodeName();
                    if (!booleanValue) {
                        codeName = null;
                    }
                    b = deobf.com.withpersona.sdk2.inquiry.zt.n.b(codeName);
                } else {
                    b = deobf.com.withpersona.sdk2.inquiry.zt.n.b(a10);
                }
                Achievement achievement3 = this.f17816v;
                Throwable e11 = deobf.com.withpersona.sdk2.inquiry.zt.n.e(b);
                if (e11 != null) {
                    Log.w("rbx.achievement.replicator", "granting " + achievement3.getCodeName() + " failed exceptionally", e11);
                    b = deobf.com.withpersona.sdk2.inquiry.zt.n.b(null);
                }
                return deobf.com.withpersona.sdk2.inquiry.zt.n.a(b);
            }

            @Override // kotlin.jvm.functions.Function2
            public /* bridge */ /* synthetic */ Object invoke(p0 p0Var, deobf.kotlin.eu.b<? super deobf.com.withpersona.sdk2.inquiry.zt.n<? extends String>> bVar) {
                return invoke2(p0Var, (deobf.kotlin.eu.b<? super deobf.com.withpersona.sdk2.inquiry.zt.n<String>>) bVar);
            }
        }

        @Metadata(d1 = {"\u0000\u0017\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0003*\u0001\u0000\b\n\u0018\u00002\b\u0012\u0004\u0012\u00028\u00000\u0001J\u001e\u0010\u0005\u001a\u00020\u00042\f\u0010\u0003\u001a\b\u0012\u0004\u0012\u00028\u00000\u0002H\u0096@¢\u0006\u0004\b\u0005\u0010\u0006¨\u0006\u0007"}, d2 = {"kotlinx/coroutines/flow/internal/SafeCollector_commonKt$unsafeFlow$1", "Ldv/h;", "Ldv/i;", "collector", BuildConfig.FLAVOR, "collect", "(Ldv/i;Leu/b;)Ljava/lang/Object;", "kotlinx-coroutines-core"}, k = 1, mv = {2, 2, 0}, xi = 48)
        public static final class C0323b implements deobf.kotlin.dv.h<List<? extends Achievement>> {

            public final /* synthetic */ deobf.kotlin.dv.h f17817a;

            @Metadata(k = 3, mv = {2, 2, 0}, xi = 48)
            public static final class a<T> implements deobf.kotlin.dv.i {

                public final /* synthetic */ deobf.kotlin.dv.i f17818a;

                @Metadata(k = 3, mv = {2, 2, 0}, xi = 48)
                @deobf.com.withpersona.sdk2.inquiry.gu.f(c = "com.roblox.universalapp.achievement.Replicator$syncLocalToRemote$2$invokeSuspend$$inlined$filter$1$2", f = "Replicator.kt", l = {RequestError.RESPONSE_CODE_FAILURE}, m = "emit", v = 1)
                public static final class C0324a extends deobf.com.withpersona.sdk2.inquiry.gu.d {
                    public int A;

                    public /* synthetic */ Object f17819t;

                    public int f17820u;

                    public Object f17821v;

                    public Object f17822w;

                    public Object f17824y;

                    public Object f17825z;

                    public C0324a(deobf.kotlin.eu.b bVar) {
                        super(bVar);
                    }

                    @Override // deobf.com.withpersona.sdk2.inquiry.gu.a
                    public final Object invokeSuspend(Object obj) {
                        this.f17819t = obj;
                        this.f17820u |= Integer.MIN_VALUE;
                        return a.this.emit(null, this);
                    }
                }

                public a(deobf.kotlin.dv.i iVar) {
                    this.f17818a = iVar;
                }

                /* JADX WARN: Removed duplicated region for block: B:15:0x0039  */
                /* JADX WARN: Removed duplicated region for block: B:8:0x0023  */
                @Override // deobf.kotlin.dv.i
                public final java.lang.Object emit(java.lang.Object r5, deobf.kotlin.eu.b r6) {
                    /*
                        r4 = this;
                        boolean r0 = r6 instanceof deobf.com.roblox.universalapp.achievement.gm.w.b.C0323b.a.C0324a
                        if (r0 == 0) goto L13
                        r0 = r6
                        gm.w$b$b$a$a r0 = (deobf.com.roblox.universalapp.achievement.gm.w.b.C0323b.a.C0324a) r0
                        int r1 = r0.f17820u
                        r2 = -2147483648(0xffffffff80000000, float:-0.0)
                        r3 = r1 & r2
                        if (r3 == 0) goto L13
                        int r1 = r1 - r2
                        r0.f17820u = r1
                        goto L18
                    L13:
                        gm.w$b$b$a$a r0 = new gm.w$b$b$a$a
                        r0.<init>(r6)
                    L18:
                        java.lang.Object r6 = r0.f17819t
                        java.lang.Object r1 = deobf.kotlin.fu.c.e()
                        int r2 = r0.f17820u
                        r3 = 1
                        if (r2 == 0) goto L39
                        if (r2 != r3) goto L31
                        java.lang.Object r5 = r0.f17825z
                        deobf.kotlin.dv.i r5 = (deobf.kotlin.dv.i) r5
                        java.lang.Object r5 = r0.f17822w
                        gm.w$b$b$a$a r5 = (deobf.com.roblox.universalapp.achievement.gm.w.b.C0323b.a.C0324a) r5
                        deobf.com.withpersona.sdk2.inquiry.zt.o.b(r6)
                        goto L6d
                    L31:
                        java.lang.IllegalStateException r5 = new java.lang.IllegalStateException
                        java.lang.String r6 = "call to 'resume' before 'invoke' with coroutine"
                        r5.<init>(r6)
                        throw r5
                    L39:
                        deobf.com.withpersona.sdk2.inquiry.zt.o.b(r6)
                        deobf.kotlin.dv.i r6 = r4.f17818a
                        r2 = r5
                        java.util.List r2 = (java.util.List) r2
                        java.util.Collection r2 = (java.util.Collection) r2
                        boolean r2 = r2.isEmpty()
                        if (r2 != 0) goto L6d
                        java.lang.Object r2 = deobf.com.withpersona.sdk2.inquiry.gu.l.a(r5)
                        r0.f17821v = r2
                        java.lang.Object r2 = deobf.com.withpersona.sdk2.inquiry.gu.l.a(r0)
                        r0.f17822w = r2
                        java.lang.Object r2 = deobf.com.withpersona.sdk2.inquiry.gu.l.a(r5)
                        r0.f17824y = r2
                        java.lang.Object r2 = deobf.com.withpersona.sdk2.inquiry.gu.l.a(r6)
                        r0.f17825z = r2
                        r2 = 0
                        r0.A = r2
                        r0.f17820u = r3
                        java.lang.Object r5 = r6.emit(r5, r0)
                        if (r5 != r1) goto L6d
                        return r1
                    L6d:
                        kotlin.Unit r5 = kotlin.Unit.f21504a
                        return r5
                    */
                    throw new UnsupportedOperationException("Method not decompiled: deobf.com.roblox.universalapp.achievement.gm.w.b.C0323b.a.emit(java.lang.Object, deobf.kotlin.eu.b):java.lang.Object");
                }
            }

            public C0323b(deobf.kotlin.dv.h hVar) {
                this.f17817a = hVar;
            }

            @Override // deobf.kotlin.dv.h
            public Object collect(deobf.kotlin.dv.i<? super List<? extends Achievement>> iVar, deobf.kotlin.eu.b bVar) {
                Object collect = this.f17817a.collect(new a(iVar), bVar);
                return collect == deobf.kotlin.fu.c.e() ? collect : Unit.f21504a;
            }
        }

        @Metadata(d1 = {"\u0000\u0017\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0003*\u0001\u0000\b\n\u0018\u00002\b\u0012\u0004\u0012\u00028\u00000\u0001J\u001e\u0010\u0005\u001a\u00020\u00042\f\u0010\u0003\u001a\b\u0012\u0004\u0012\u00028\u00000\u0002H\u0096@¢\u0006\u0004\b\u0005\u0010\u0006¨\u0006\u0007"}, d2 = {"kotlinx/coroutines/flow/internal/SafeCollector_commonKt$unsafeFlow$1", "Ldv/h;", "Ldv/i;", "collector", BuildConfig.FLAVOR, "collect", "(Ldv/i;Leu/b;)Ljava/lang/Object;", "kotlinx-coroutines-core"}, k = 1, mv = {2, 2, 0}, xi = 48)
        public static final class c implements deobf.kotlin.dv.h<List<? extends w0<? extends deobf.com.withpersona.sdk2.inquiry.zt.n<? extends String>>>> {

            public final /* synthetic */ deobf.kotlin.dv.h f17826a;
            public final /* synthetic */ p0 b;

            public final /* synthetic */ w f17827c;

            @Metadata(k = 3, mv = {2, 2, 0}, xi = 48)
            public static final class a<T> implements deobf.kotlin.dv.i {

                public final /* synthetic */ deobf.kotlin.dv.i f17828a;
                public final /* synthetic */ p0 b;

                public final /* synthetic */ w f17829c;

                @Metadata(k = 3, mv = {2, 2, 0}, xi = 48)
                @deobf.com.withpersona.sdk2.inquiry.gu.f(c = "com.roblox.universalapp.achievement.Replicator$syncLocalToRemote$2$invokeSuspend$$inlined$map$1$2", f = "Replicator.kt", l = {RequestError.RESPONSE_CODE_FAILURE}, m = "emit", v = 1)
                public static final class C0325a extends deobf.com.withpersona.sdk2.inquiry.gu.d {
                    public int A;

                    public /* synthetic */ Object f17830t;

                    public int f17831u;

                    public Object f17832v;

                    public Object f17834x;

                    public Object f17835y;

                    public Object f17836z;

                    public C0325a(deobf.kotlin.eu.b bVar) {
                        super(bVar);
                    }

                    @Override // deobf.com.withpersona.sdk2.inquiry.gu.a
                    public final Object invokeSuspend(Object obj) {
                        this.f17830t = obj;
                        this.f17831u |= Integer.MIN_VALUE;
                        return a.this.emit(null, this);
                    }
                }

                public a(deobf.kotlin.dv.i iVar, p0 p0Var, w wVar) {
                    this.f17828a = iVar;
                    this.b = p0Var;
                    this.f17829c = wVar;
                }

                /* JADX WARN: Removed duplicated region for block: B:15:0x003a  */
                /* JADX WARN: Removed duplicated region for block: B:8:0x0023  */
                @Override // deobf.kotlin.dv.i
                public final java.lang.Object emit(java.lang.Object r13, deobf.kotlin.eu.b r14) {
                    /*
                        r12 = this;
                        boolean r0 = r14 instanceof deobf.com.roblox.universalapp.achievement.gm.w.b.c.a.C0325a
                        if (r0 == 0) goto L13
                        r0 = r14
                        gm.w$b$c$a$a r0 = (deobf.com.roblox.universalapp.achievement.gm.w.b.c.a.C0325a) r0
                        int r1 = r0.f17831u
                        r2 = -2147483648(0xffffffff80000000, float:-0.0)
                        r3 = r1 & r2
                        if (r3 == 0) goto L13
                        int r1 = r1 - r2
                        r0.f17831u = r1
                        goto L18
                    L13:
                        gm.w$b$c$a$a r0 = new gm.w$b$c$a$a
                        r0.<init>(r14)
                    L18:
                        java.lang.Object r14 = r0.f17830t
                        java.lang.Object r1 = deobf.kotlin.fu.c.e()
                        int r2 = r0.f17831u
                        r3 = 1
                        if (r2 == 0) goto L3a
                        if (r2 != r3) goto L32
                        java.lang.Object r13 = r0.f17836z
                        deobf.kotlin.dv.i r13 = (deobf.kotlin.dv.i) r13
                        java.lang.Object r13 = r0.f17834x
                        gm.w$b$c$a$a r13 = (deobf.com.roblox.universalapp.achievement.gm.w.b.c.a.C0325a) r13
                        deobf.com.withpersona.sdk2.inquiry.zt.o.b(r14)
                        goto Lb3
                    L32:
                        java.lang.IllegalStateException r13 = new java.lang.IllegalStateException
                        java.lang.String r14 = "call to 'resume' before 'invoke' with coroutine"
                        r13.<init>(r14)
                        throw r13
                    L3a:
                        deobf.com.withpersona.sdk2.inquiry.zt.o.b(r14)
                        deobf.kotlin.dv.i r14 = r12.f17828a
                        r2 = r13
                        java.util.List r2 = (java.util.List) r2
                        java.lang.StringBuilder r4 = new java.lang.StringBuilder
                        r4.<init>()
                        java.lang.String r5 = "Syncing "
                        r4.append(r5)
                        r4.append(r2)
                        java.lang.String r5 = " achievements to remote"
                        r4.append(r5)
                        java.lang.String r4 = r4.toString()
                        java.lang.String r5 = "rbx.achievement.replicator"
                        android.util.Log.i(r5, r4)
                        java.lang.Iterable r2 = (java.lang.Iterable) r2
                        java.util.ArrayList r4 = new java.util.ArrayList
                        r5 = 10
                        int r5 = kotlin.collections.q.u(r2, r5)
                        r4.<init>(r5)
                        java.util.Iterator r2 = r2.iterator()
                    L6e:
                        boolean r5 = r2.hasNext()
                        if (r5 == 0) goto L8f
                        java.lang.Object r5 = r2.next()
                        gm.a r5 = (deobf.com.roblox.universalapp.achievement.gm.Achievement) r5
                        deobf.com.withpersona.sdk2.inquiry.av.p0 r6 = r12.b
                        gm.w$b$a r9 = new gm.w$b$a
                        deobf.com.roblox.universalapp.achievement.gm.w r7 = r12.f17829c
                        r8 = 0
                        r9.<init>(r7, r5, r8)
                        r10 = 3
                        r11 = 0
                        r7 = 0
                        deobf.com.withpersona.sdk2.inquiry.av.w0 r5 = deobf.com.withpersona.sdk2.inquiry.av.i.b(r6, r7, r8, r9, r10, r11)
                        r4.add(r5)
                        goto L6e
                    L8f:
                        java.lang.Object r2 = deobf.com.withpersona.sdk2.inquiry.gu.l.a(r13)
                        r0.f17832v = r2
                        java.lang.Object r2 = deobf.com.withpersona.sdk2.inquiry.gu.l.a(r0)
                        r0.f17834x = r2
                        java.lang.Object r13 = deobf.com.withpersona.sdk2.inquiry.gu.l.a(r13)
                        r0.f17835y = r13
                        java.lang.Object r13 = deobf.com.withpersona.sdk2.inquiry.gu.l.a(r14)
                        r0.f17836z = r13
                        r13 = 0
                        r0.A = r13
                        r0.f17831u = r3
                        java.lang.Object r13 = r14.emit(r4, r0)
                        if (r13 != r1) goto Lb3
                        return r1
                    Lb3:
                        kotlin.Unit r13 = kotlin.Unit.f21504a
                        return r13
                    */
                    throw new UnsupportedOperationException("Method not decompiled: deobf.com.roblox.universalapp.achievement.gm.w.b.c.a.emit(java.lang.Object, deobf.kotlin.eu.b):java.lang.Object");
                }
            }

            public c(deobf.kotlin.dv.h hVar, p0 p0Var, w wVar) {
                this.f17826a = hVar;
                this.b = p0Var;
                this.f17827c = wVar;
            }

            @Override // deobf.kotlin.dv.h
            public Object collect(deobf.kotlin.dv.i<? super List<? extends w0<? extends deobf.com.withpersona.sdk2.inquiry.zt.n<? extends String>>>> iVar, deobf.kotlin.eu.b bVar) {
                Object collect = this.f17826a.collect(new a(iVar, this.b, this.f17827c), bVar);
                return collect == deobf.kotlin.fu.c.e() ? collect : Unit.f21504a;
            }
        }

        @Metadata(d1 = {"\u0000\u0017\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0003*\u0001\u0000\b\n\u0018\u00002\b\u0012\u0004\u0012\u00028\u00000\u0001J\u001e\u0010\u0005\u001a\u00020\u00042\f\u0010\u0003\u001a\b\u0012\u0004\u0012\u00028\u00000\u0002H\u0096@¢\u0006\u0004\b\u0005\u0010\u0006¨\u0006\u0007"}, d2 = {"kotlinx/coroutines/flow/internal/SafeCollector_commonKt$unsafeFlow$1", "Ldv/h;", "Ldv/i;", "collector", BuildConfig.FLAVOR, "collect", "(Ldv/i;Leu/b;)Ljava/lang/Object;", "kotlinx-coroutines-core"}, k = 1, mv = {2, 2, 0}, xi = 48)
        public static final class d implements deobf.kotlin.dv.h<deobf.com.withpersona.sdk2.inquiry.zt.n<? extends Unit>> {

            public final /* synthetic */ deobf.kotlin.dv.h f17837a;
            public final /* synthetic */ p0 b;

            public final /* synthetic */ w f17838c;

            @Metadata(k = 3, mv = {2, 2, 0}, xi = 48)
            public static final class a<T> implements deobf.kotlin.dv.i {

                public final /* synthetic */ deobf.kotlin.dv.i f17839a;
                public final /* synthetic */ p0 b;

                public final /* synthetic */ w f17840c;

                @Metadata(k = 3, mv = {2, 2, 0}, xi = 48)
                @deobf.com.withpersona.sdk2.inquiry.gu.f(c = "com.roblox.universalapp.achievement.Replicator$syncLocalToRemote$2$invokeSuspend$$inlined$map$2$2", f = "Replicator.kt", l = {52, 67, RequestError.RESPONSE_CODE_FAILURE}, m = "emit", v = 1)
                public static final class C0326a extends deobf.com.withpersona.sdk2.inquiry.gu.d {
                    public Object A;
                    public Object B;
                    public Object C;
                    public Object D;
                    public Object E;
                    public int F;
                    public int G;
                    public int H;

                    public /* synthetic */ Object f17841t;

                    public int f17842u;

                    public Object f17843v;

                    public Object f17845x;

                    public Object f17846y;

                    public Object f17847z;

                    public C0326a(deobf.kotlin.eu.b bVar) {
                        super(bVar);
                    }

                    @Override // deobf.com.withpersona.sdk2.inquiry.gu.a
                    public final Object invokeSuspend(Object obj) {
                        this.f17841t = obj;
                        this.f17842u |= Integer.MIN_VALUE;
                        return a.this.emit(null, this);
                    }
                }

                public a(deobf.kotlin.dv.i iVar, p0 p0Var, w wVar) {
                    this.f17839a = iVar;
                    this.b = p0Var;
                    this.f17840c = wVar;
                }

                /* JADX WARN: Can't wrap try/catch for region: R(15:0|1|(2:3|(11:5|6|7|(1:(1:(1:(3:12|13|14)(2:16|17))(9:18|19|20|21|(1:23)|24|25|(1:27)|28))(4:35|36|37|38))(5:63|64|65|(1:67)|30)|39|40|(6:43|(1:45)|46|(2:48|49)(1:51)|50|41)|52|53|(7:55|21|(0)|24|25|(0)|28)|30))|71|6|7|(0)(0)|39|40|(1:41)|52|53|(0)|30|(1:(0))) */
                /* JADX WARN: Code restructure failed: missing block: B:29:0x0220, code lost:

                    if (r4.emit(r0, r6) == r2) goto L62;
                 */
                /* JADX WARN: Code restructure failed: missing block: B:57:0x0136, code lost:

                    r0 = th;
                 */
                /* JADX WARN: Code restructure failed: missing block: B:58:0x0137, code lost:

                    r3 = r9;
                    r5 = r14;
                 */
                /* JADX WARN: Removed duplicated region for block: B:23:0x01c3 A[Catch: all -> 0x006f, TryCatch #3 {all -> 0x006f, blocks: (B:20:0x006a, B:21:0x01b4, B:23:0x01c3, B:24:0x01cb), top: B:19:0x006a }] */
                /* JADX WARN: Removed duplicated region for block: B:27:0x01eb  */
                /* JADX WARN: Removed duplicated region for block: B:43:0x0118 A[Catch: all -> 0x0136, TryCatch #1 {all -> 0x0136, blocks: (B:40:0x0105, B:41:0x0112, B:43:0x0118, B:46:0x012a, B:48:0x0132, B:53:0x013e), top: B:39:0x0105 }] */
                /* JADX WARN: Removed duplicated region for block: B:55:0x01ae  */
                /* JADX WARN: Removed duplicated region for block: B:63:0x00ad  */
                /* JADX WARN: Removed duplicated region for block: B:9:0x002d  */
                @Override // deobf.kotlin.dv.i
                public final java.lang.Object emit(java.lang.Object r21, deobf.kotlin.eu.b r22) {
                    /*
                        Method dump skipped, instructions count: 550
                        To view this dump add '--comments-level debug' option
                    */
                    throw new UnsupportedOperationException("Method not decompiled: deobf.com.roblox.universalapp.achievement.gm.w.b.d.a.emit(java.lang.Object, deobf.kotlin.eu.b):java.lang.Object");
                }
            }

            public d(deobf.kotlin.dv.h hVar, p0 p0Var, w wVar) {
                this.f17837a = hVar;
                this.b = p0Var;
                this.f17838c = wVar;
            }

            @Override // deobf.kotlin.dv.h
            public Object collect(deobf.kotlin.dv.i<? super deobf.com.withpersona.sdk2.inquiry.zt.n<? extends Unit>> iVar, deobf.kotlin.eu.b bVar) {
                Object collect = this.f17837a.collect(new a(iVar, this.b, this.f17838c), bVar);
                return collect == deobf.kotlin.fu.c.e() ? collect : Unit.f21504a;
            }
        }

        public b(deobf.kotlin.eu.b<? super b> bVar) {
            super(2, bVar);
        }

        @Override // deobf.com.withpersona.sdk2.inquiry.gu.a
        public final deobf.kotlin.eu.b<Unit> create(Object obj, deobf.kotlin.eu.b<?> bVar) {
            b bVar2 = w.this.new b(bVar);
            bVar2.f17812x = obj;
            return bVar2;
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(p0 p0Var, deobf.kotlin.eu.b<? super Integer> bVar) {
            return ((b) create(p0Var, bVar)).invokeSuspend(Unit.f21504a);
        }

        /* JADX WARN: Code restructure failed: missing block: B:30:0x00f5, code lost:

            if (deobf.kotlin.dv.j.i(r5, r11) == r1) goto L35;
         */
        /* JADX WARN: Code restructure failed: missing block: B:31:0x00f7, code lost:

            return r1;
         */
        /* JADX WARN: Code restructure failed: missing block: B:46:0x0043, code lost:

            if (r12 == r1) goto L35;
         */
        @Override // deobf.com.withpersona.sdk2.inquiry.gu.a
        public final java.lang.Object invokeSuspend(java.lang.Object r12) {
            /*
                Method dump skipped, instructions count: 259
                To view this dump add '--comments-level debug' option
            */
            throw new UnsupportedOperationException("Method not decompiled: deobf.com.roblox.universalapp.achievement.gm.w.b.invokeSuspend(java.lang.Object):java.lang.Object");
        }
    }

    @Metadata(d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\n¢\u0006\u0004\b\u0002\u0010\u0003"}, d2 = {"Lav/p0;", "Ljava/io/Serializable;", "<anonymous>", "(Lav/p0;)Ljava/io/Serializable;"}, k = 3, mv = {2, 2, 0})
    @deobf.com.withpersona.sdk2.inquiry.gu.f(c = "com.roblox.universalapp.achievement.Replicator$syncRemoteToLocal$2", f = "Replicator.kt", l = {25, 31}, m = "invokeSuspend", v = 1)
    public static final class c extends deobf.com.withpersona.sdk2.inquiry.gu.m implements Function2<p0, deobf.kotlin.eu.b<? super Serializable>, Object> {

        public Object f17848t;

        public Object f17849u;

        public int f17850v;

        public int f17851w;

        public int f17852x;

        public /* synthetic */ Object f17853y;

        public c(deobf.kotlin.eu.b<? super c> bVar) {
            super(2, bVar);
        }

        @Override // deobf.com.withpersona.sdk2.inquiry.gu.a
        public final deobf.kotlin.eu.b<Unit> create(Object obj, deobf.kotlin.eu.b<?> bVar) {
            c cVar = w.this.new c(bVar);
            cVar.f17853y = obj;
            return cVar;
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(p0 p0Var, deobf.kotlin.eu.b<? super Serializable> bVar) {
            return ((c) create(p0Var, bVar)).invokeSuspend(Unit.f21504a);
        }

        /* JADX WARN: Code restructure failed: missing block: B:23:0x0073, code lost:

            if (r2.d(r7, r6) == r1) goto L22;
         */
        /* JADX WARN: Code restructure failed: missing block: B:24:0x0075, code lost:

            return r1;
         */
        /* JADX WARN: Code restructure failed: missing block: B:28:0x0045, code lost:

            if (r7 == r1) goto L22;
         */
        @Override // deobf.com.withpersona.sdk2.inquiry.gu.a
        public final java.lang.Object invokeSuspend(java.lang.Object r7) {
            /*
                r6 = this;
                java.lang.Object r0 = r6.f17853y
                deobf.com.withpersona.sdk2.inquiry.av.p0 r0 = (deobf.com.withpersona.sdk2.inquiry.av.p0) r0
                java.lang.Object r1 = deobf.kotlin.fu.c.e()
                int r2 = r6.f17852x
                java.lang.String r3 = "rbx.achievement.replicator"
                r4 = 2
                r5 = 1
                if (r2 == 0) goto L34
                if (r2 == r5) goto L2a
                if (r2 != r4) goto L22
                java.lang.Object r0 = r6.f17849u
                deobf.com.withpersona.sdk2.inquiry.av.p0 r0 = (deobf.com.withpersona.sdk2.inquiry.av.p0) r0
                java.lang.Object r0 = r6.f17848t
                java.util.List r0 = (java.util.List) r0
                deobf.com.withpersona.sdk2.inquiry.zt.o.b(r7)     // Catch: java.lang.Throwable -> L20
                goto L76
            L20:
                r7 = move-exception
                goto L7d
            L22:
                java.lang.IllegalStateException r7 = new java.lang.IllegalStateException
                java.lang.String r0 = "call to 'resume' before 'invoke' with coroutine"
                r7.<init>(r0)
                throw r7
            L2a:
                deobf.com.withpersona.sdk2.inquiry.zt.o.b(r7)
                deobf.com.withpersona.sdk2.inquiry.zt.n r7 = (deobf.com.withpersona.sdk2.inquiry.zt.n) r7
                java.lang.Object r7 = r7.getValue()
                goto L48
            L34:
                deobf.com.withpersona.sdk2.inquiry.zt.o.b(r7)
                deobf.com.roblox.universalapp.achievement.gm.w r7 = deobf.com.roblox.universalapp.achievement.gm.w.this
                deobf.com.roblox.universalapp.achievement.gm.v r7 = deobf.com.roblox.universalapp.achievement.gm.w.b(r7)
                r6.f17853y = r0
                r6.f17852x = r5
                java.lang.Object r7 = deobf.unlinked.r7.b(r6)
                if (r7 != r1) goto L48
                goto L75
            L48:
                deobf.com.roblox.universalapp.achievement.gm.w r2 = deobf.com.roblox.universalapp.achievement.gm.w.this
                java.lang.Throwable r5 = deobf.com.withpersona.sdk2.inquiry.zt.n.e(r7)
                if (r5 != 0) goto L97
                java.util.List r7 = (java.util.List) r7
                deobf.com.roblox.universalapp.achievement.gm.b r2 = deobf.com.roblox.universalapp.achievement.gm.w.a(r2)     // Catch: java.lang.Throwable -> L20
                java.lang.Object r5 = deobf.com.withpersona.sdk2.inquiry.gu.l.a(r0)     // Catch: java.lang.Throwable -> L20
                r6.f17853y = r5     // Catch: java.lang.Throwable -> L20
                java.lang.Object r5 = deobf.com.withpersona.sdk2.inquiry.gu.l.a(r7)     // Catch: java.lang.Throwable -> L20
                r6.f17848t = r5     // Catch: java.lang.Throwable -> L20
                java.lang.Object r0 = deobf.com.withpersona.sdk2.inquiry.gu.l.a(r0)     // Catch: java.lang.Throwable -> L20
                r6.f17849u = r0     // Catch: java.lang.Throwable -> L20
                r0 = 0
                r6.f17850v = r0     // Catch: java.lang.Throwable -> L20
                r6.f17851w = r0     // Catch: java.lang.Throwable -> L20
                r6.f17852x = r4     // Catch: java.lang.Throwable -> L20
                java.lang.Object r7 = r2.d(r7, r6)     // Catch: java.lang.Throwable -> L20
                if (r7 != r1) goto L76
            L75:
                return r1
            L76:
                kotlin.Unit r7 = kotlin.Unit.f21504a     // Catch: java.lang.Throwable -> L20
                java.lang.Object r7 = deobf.com.withpersona.sdk2.inquiry.zt.n.b(r7)     // Catch: java.lang.Throwable -> L20
                goto L87
            L7d:
                zt.n$a r0 = deobf.com.withpersona.sdk2.inquiry.zt.n.INSTANCE
                java.lang.Object r7 = deobf.com.withpersona.sdk2.inquiry.zt.o.a(r7)
                java.lang.Object r7 = deobf.com.withpersona.sdk2.inquiry.zt.n.b(r7)
            L87:
                java.lang.Throwable r0 = deobf.com.withpersona.sdk2.inquiry.zt.n.e(r7)
                if (r0 == 0) goto L92
                java.lang.String r1 = "Unable to replicate remote achievements locally"
                android.util.Log.w(r3, r1, r0)
            L92:
                deobf.com.withpersona.sdk2.inquiry.zt.n r7 = deobf.com.withpersona.sdk2.inquiry.zt.n.a(r7)
                return r7
            L97:
                java.lang.String r7 = "Unable to gather remote achievements"
                int r7 = android.util.Log.w(r3, r7, r5)
                java.lang.Integer r7 = deobf.com.withpersona.sdk2.inquiry.gu.b.c(r7)
                return r7
            */
            throw new UnsupportedOperationException("Method not decompiled: deobf.com.roblox.universalapp.achievement.gm.w.c.invokeSuspend(java.lang.Object):java.lang.Object");
        }
    }

    public w(@NotNull deobf.com.roblox.universalapp.achievement.gm.b local, @NotNull v remote) {
        Intrinsics.checkNotNullParameter(local, "local");
        Intrinsics.checkNotNullParameter(remote, "remote");
        this.local = local;
        this.remote = remote;
    }

    @Nullable
    public final Object c(@NotNull deobf.kotlin.eu.b<? super Integer> bVar) {
        return deobf.com.withpersona.sdk2.inquiry.av.i.g(g1.b(), new b(null), bVar);
    }

    @Nullable
    public final Object d(@NotNull deobf.kotlin.eu.b<? super Serializable> bVar) {
        return deobf.com.withpersona.sdk2.inquiry.av.i.g(g1.b(), new c(null), bVar);
    }
}
