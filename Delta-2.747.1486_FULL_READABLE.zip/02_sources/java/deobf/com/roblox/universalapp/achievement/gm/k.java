package deobf.com.roblox.universalapp.achievement.gm;

import com.github.luben.zstd.BuildConfig;
import kotlin.Metadata;

/* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
/* JADX WARN: Unknown enum class pattern. Please report as an issue! */
@Metadata(d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0010\u0010\n\u0002\b\u0006\b\u0082\u0081\u0002\u0018\u00002\b\u0012\u0004\u0012\u00020\u00000\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003j\u0002\b\u0004j\u0002\b\u0005j\u0002\b\u0006¨\u0006\u0007"}, d2 = {"Lgm/k;", BuildConfig.FLAVOR, "<init>", "(Ljava/lang/String;I)V", deobf.android.view.xe.a.f36648e, deobf.android.view.k6.b.f21144e, "c", "universalapp_googleProdRelease"}, k = 1, mv = {2, 2, 0}, xi = 48)
// dex: classes2.dex
public final class k {

    public static final k f17788a = new k("INITIALIZE_FAILED", 0);
    public static final k b = new k("ALREADY_INITIALIZED", 1);

    public static final k f17789c = new k("SUCCESS", 2);

    public static final /* synthetic */ k[] f17790d;

    public static final /* synthetic */ deobf.com.withpersona.sdk2.inquiry.hu.a f17791e;

    static {
        k[] a10 = a();
        f17790d = a10;
        f17791e = deobf.com.withpersona.sdk2.inquiry.hu.b.a(a10);
    }

    public k(String str, int i10) {
    }

    public static final /* synthetic */ k[] a() {
        return new k[]{f17788a, b, f17789c};
    }

    public static k valueOf(String str) {
        return (k) Enum.valueOf(k.class, str);
    }

    public static k[] values() {
        return (k[]) f17790d.clone();
    }
}
