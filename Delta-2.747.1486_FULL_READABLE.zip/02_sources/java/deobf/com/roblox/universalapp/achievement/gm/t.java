package deobf.com.roblox.universalapp.achievement.gm;

import com.appsflyer.sdk_base.referrer.Payload;
import com.github.luben.zstd.BuildConfig;
import com.roblox.protocols.telemetrybindingsplatforminterface.generated.TelemetryBackend;
import com.roblox.protocols.telemetrybindingsplatforminterface.generated.TelemetryConfig;
import deobf.com.roblox.universalapp.facialageestimation.fn.c;
import kotlin.Metadata;
import kotlin.collections.p0;
import kotlin.collections.q0;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;

@Metadata(d1 = {"\u00008\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\u0002\n\u0002\b\f\n\u0002\u0010\b\n\u0002\b\u0004\n\u0002\u0010\t\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0014\bÆ\u0002\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\u001d\u0010\t\u001a\u00020\b2\u0006\u0010\u0005\u001a\u00020\u00042\u0006\u0010\u0007\u001a\u00020\u0006¢\u0006\u0004\b\t\u0010\nJ\u001d\u0010\r\u001a\u00020\b2\u0006\u0010\u000b\u001a\u00020\u00062\u0006\u0010\f\u001a\u00020\u0004¢\u0006\u0004\b\r\u0010\u000eJ\u0015\u0010\u0010\u001a\u00020\b2\u0006\u0010\u000f\u001a\u00020\u0006¢\u0006\u0004\b\u0010\u0010\u0011J%\u0010\u0013\u001a\u00020\b2\u0006\u0010\u000b\u001a\u00020\u00062\u0006\u0010\u0012\u001a\u00020\u00062\u0006\u0010\f\u001a\u00020\u0004¢\u0006\u0004\b\u0013\u0010\u0014J\u001d\u0010\u0018\u001a\u00020\b2\u0006\u0010\u0016\u001a\u00020\u00152\u0006\u0010\u0017\u001a\u00020\u0006¢\u0006\u0004\b\u0018\u0010\u0019J%\u0010\u001c\u001a\u00020\b2\u0006\u0010\u001b\u001a\u00020\u001a2\u0006\u0010\u0016\u001a\u00020\u00152\u0006\u0010\u0017\u001a\u00020\u0006¢\u0006\u0004\b\u001c\u0010\u001dR\u001b\u0010#\u001a\u00020\u001e8BX\u0082\u0084\u0002¢\u0006\f\n\u0004\b\u001f\u0010 \u001a\u0004\b!\u0010\"R\u001b\u0010&\u001a\u00020\u001e8BX\u0082\u0084\u0002¢\u0006\f\n\u0004\b$\u0010 \u001a\u0004\b%\u0010\"R\u001b\u0010)\u001a\u00020\u001e8BX\u0082\u0084\u0002¢\u0006\f\n\u0004\b'\u0010 \u001a\u0004\b(\u0010\"R\u001b\u0010,\u001a\u00020\u001e8BX\u0082\u0084\u0002¢\u0006\f\n\u0004\b*\u0010 \u001a\u0004\b+\u0010\"R\u001b\u0010/\u001a\u00020\u001e8BX\u0082\u0084\u0002¢\u0006\f\n\u0004\b-\u0010 \u001a\u0004\b.\u0010\"R\u001b\u00101\u001a\u00020\u001e8BX\u0082\u0084\u0002¢\u0006\f\n\u0004\b!\u0010 \u001a\u0004\b0\u0010\"¨\u00062"}, d2 = {"Lgm/t;", BuildConfig.FLAVOR, "<init>", "()V", BuildConfig.FLAVOR, "isAuthenticated", BuildConfig.FLAVOR, "localeCountry", BuildConfig.FLAVOR, "m", "(ZLjava/lang/String;)V", "destination", "success", "o", "(Ljava/lang/String;Z)V", "updateType", "p", "(Ljava/lang/String;)V", "codeName", "n", "(Ljava/lang/String;Ljava/lang/String;Z)V", BuildConfig.FLAVOR, "bucket", "group", "r", "(ILjava/lang/String;)V", BuildConfig.FLAVOR, "btid", "q", "(JILjava/lang/String;)V", "Lcom/roblox/protocols/telemetrybindingsplatforminterface/generated/TelemetryConfig;", deobf.android.view.k6.b.f21144e, "Lzt/h;", "g", "()Lcom/roblox/protocols/telemetrybindingsplatforminterface/generated/TelemetryConfig;", "pgsAuthenticatedCounter", "c", "k", "pgsReplicatorCounter", "d", "l", "pgsStreakCounter", "e", "j", "pgsGrantAchievementCounter", "f", "i", "pgsExperimentStartupEvent", "h", "pgsExperimentEnrollmentEvent", "universalapp_googleProdRelease"}, k = 1, mv = {2, 2, 0}, xi = 48)
// dex: classes2.dex
public final class t {

    @NotNull
    public static final t f17797a = new t();

    @NotNull
    public static final deobf.com.withpersona.sdk2.inquiry.zt.h pgsAuthenticatedCounter = deobf.com.withpersona.sdk2.inquiry.zt.i.a(new Function0() { // from class: gm.n
        @Override // kotlin.jvm.functions.Function0
        public final Object invoke() {
            TelemetryConfig s8;
            s8 = t.s();
            return s8;
        }
    });

    @NotNull
    public static final deobf.com.withpersona.sdk2.inquiry.zt.h pgsReplicatorCounter = deobf.com.withpersona.sdk2.inquiry.zt.i.a(new Function0() { // from class: gm.o
        @Override // kotlin.jvm.functions.Function0
        public final Object invoke() {
            TelemetryConfig w5;
            w5 = t.w();
            return w5;
        }
    });

    @NotNull
    public static final deobf.com.withpersona.sdk2.inquiry.zt.h pgsStreakCounter = deobf.com.withpersona.sdk2.inquiry.zt.i.a(new Function0() { // from class: gm.p
        @Override // kotlin.jvm.functions.Function0
        public final Object invoke() {
            TelemetryConfig x5;
            x5 = t.x();
            return x5;
        }
    });

    @NotNull
    public static final deobf.com.withpersona.sdk2.inquiry.zt.h pgsGrantAchievementCounter = deobf.com.withpersona.sdk2.inquiry.zt.i.a(new Function0() { // from class: gm.q
        @Override // kotlin.jvm.functions.Function0
        public final Object invoke() {
            TelemetryConfig v8;
            v8 = t.v();
            return v8;
        }
    });

    @NotNull
    public static final deobf.com.withpersona.sdk2.inquiry.zt.h pgsExperimentStartupEvent = deobf.com.withpersona.sdk2.inquiry.zt.i.a(new Function0() { // from class: gm.r
        @Override // kotlin.jvm.functions.Function0
        public final Object invoke() {
            TelemetryConfig u8;
            u8 = t.u();
            return u8;
        }
    });

    @NotNull
    public static final deobf.com.withpersona.sdk2.inquiry.zt.h pgsExperimentEnrollmentEvent = deobf.com.withpersona.sdk2.inquiry.zt.i.a(new Function0() { // from class: gm.s
        @Override // kotlin.jvm.functions.Function0
        public final Object invoke() {
            TelemetryConfig t8;
            t8 = t.t();
            return t8;
        }
    });

    public static final TelemetryConfig s() {
        deobf.com.roblox.universalapp.facialageestimation.fn.c cVar = deobf.com.roblox.universalapp.facialageestimation.fn.c.f16191a;
        deobf.com.withpersona.sdk2.inquiry.c.a aVar = new deobf.com.withpersona.sdk2.inquiry.c.a("pgs_authenticated_counter", deobf.androidx.camera.view.p0.c(TelemetryBackend.COUNTER));
        aVar.b(2026, 10, 14);
        aVar.a("PGS authenticated counter");
        return aVar.d();
    }

    public static final TelemetryConfig t() {
        deobf.com.roblox.universalapp.facialageestimation.fn.c cVar = deobf.com.roblox.universalapp.facialageestimation.fn.c.f16191a;
        deobf.com.withpersona.sdk2.inquiry.c.a aVar = new deobf.com.withpersona.sdk2.inquiry.c.a("pgs_experiment_enrollment", deobf.unlinked.q0.g(TelemetryBackend.EVENT_INGEST, TelemetryBackend.POINTS));
        aVar.b(2026, 6, 24);
        aVar.a("PGS experiment enrollment with BTID");
        return aVar.d();
    }

    public static final TelemetryConfig u() {
        deobf.com.roblox.universalapp.facialageestimation.fn.c cVar = deobf.com.roblox.universalapp.facialageestimation.fn.c.f16191a;
        deobf.com.withpersona.sdk2.inquiry.c.a aVar = new deobf.com.withpersona.sdk2.inquiry.c.a("pgs_experiment_startup", deobf.unlinked.q0.g(TelemetryBackend.EVENT_INGEST, TelemetryBackend.POINTS));
        aVar.b(2026, 6, 24);
        aVar.a("PGS experiment dice roll at startup");
        return aVar.d();
    }

    public static final TelemetryConfig v() {
        deobf.com.roblox.universalapp.facialageestimation.fn.c cVar = deobf.com.roblox.universalapp.facialageestimation.fn.c.f16191a;
        deobf.com.withpersona.sdk2.inquiry.c.a aVar = new deobf.com.withpersona.sdk2.inquiry.c.a("pgs_grant_achievement_counter", deobf.androidx.camera.view.p0.c(TelemetryBackend.COUNTER));
        aVar.b(2026, 4, 15);
        aVar.a("PGS grant achievement counter");
        return aVar.d();
    }

    public static final TelemetryConfig w() {
        deobf.com.roblox.universalapp.facialageestimation.fn.c cVar = deobf.com.roblox.universalapp.facialageestimation.fn.c.f16191a;
        deobf.com.withpersona.sdk2.inquiry.c.a aVar = new deobf.com.withpersona.sdk2.inquiry.c.a("pgs_replicator_counter", deobf.androidx.camera.view.p0.c(TelemetryBackend.COUNTER));
        aVar.b(2026, 4, 15);
        aVar.a("PGS replicator counter");
        return aVar.d();
    }

    public static final TelemetryConfig x() {
        deobf.com.roblox.universalapp.facialageestimation.fn.c cVar = deobf.com.roblox.universalapp.facialageestimation.fn.c.f16191a;
        deobf.com.withpersona.sdk2.inquiry.c.a aVar = new deobf.com.withpersona.sdk2.inquiry.c.a("pgs_streak_counter", deobf.androidx.camera.view.p0.c(TelemetryBackend.COUNTER));
        aVar.b(2026, 4, 1);
        aVar.a("PGS streak counter");
        return aVar.d();
    }

    public final TelemetryConfig g() {
        return (TelemetryConfig) pgsAuthenticatedCounter.getValue();
    }

    public final TelemetryConfig h() {
        return (TelemetryConfig) pgsExperimentEnrollmentEvent.getValue();
    }

    public final TelemetryConfig i() {
        return (TelemetryConfig) pgsExperimentStartupEvent.getValue();
    }

    public final TelemetryConfig j() {
        return (TelemetryConfig) pgsGrantAchievementCounter.getValue();
    }

    public final TelemetryConfig k() {
        return (TelemetryConfig) pgsReplicatorCounter.getValue();
    }

    public final TelemetryConfig l() {
        return (TelemetryConfig) pgsStreakCounter.getValue();
    }

    public final void m(boolean isAuthenticated, @NotNull String localeCountry) {
        Intrinsics.checkNotNullParameter(localeCountry, "localeCountry");
        TelemetryConfig g10 = g();
        deobf.com.roblox.universalapp.facialageestimation.fn.c cVar = deobf.com.roblox.universalapp.facialageestimation.fn.c.f16191a;
        deobf.com.withpersona.sdk2.inquiry.c.b bVar = new deobf.com.withpersona.sdk2.inquiry.c.b();
        bVar.c("authenticated", String.valueOf(isAuthenticated));
        bVar.c("localeCountry", localeCountry);
        deobf.com.roblox.universalapp.facialageestimation.fn.c.g(g10, bVar.l(), 0.0d, 4, null);
    }

    public final void n(@NotNull String destination, @NotNull String codeName, boolean success) {
        Intrinsics.checkNotNullParameter(destination, "destination");
        Intrinsics.checkNotNullParameter(codeName, "codeName");
        TelemetryConfig j10 = j();
        deobf.com.roblox.universalapp.facialageestimation.fn.c cVar = deobf.com.roblox.universalapp.facialageestimation.fn.c.f16191a;
        deobf.com.withpersona.sdk2.inquiry.c.b bVar = new deobf.com.withpersona.sdk2.inquiry.c.b();
        bVar.c("destination", destination);
        bVar.c("codeName", codeName);
        bVar.c("success", String.valueOf(success));
        deobf.com.roblox.universalapp.facialageestimation.fn.c.g(j10, bVar.l(), 0.0d, 4, null);
    }

    public final void o(@NotNull String destination, boolean success) {
        Intrinsics.checkNotNullParameter(destination, "destination");
        TelemetryConfig k10 = k();
        deobf.com.roblox.universalapp.facialageestimation.fn.c cVar = deobf.com.roblox.universalapp.facialageestimation.fn.c.f16191a;
        deobf.com.withpersona.sdk2.inquiry.c.b bVar = new deobf.com.withpersona.sdk2.inquiry.c.b();
        bVar.c("destination", destination);
        bVar.c("success", String.valueOf(success));
        deobf.com.roblox.universalapp.facialageestimation.fn.c.g(k10, bVar.l(), 0.0d, 4, null);
    }

    public final void p(@NotNull String updateType) {
        Intrinsics.checkNotNullParameter(updateType, "updateType");
        TelemetryConfig l10 = l();
        deobf.com.roblox.universalapp.facialageestimation.fn.c cVar = deobf.com.roblox.universalapp.facialageestimation.fn.c.f16191a;
        deobf.com.withpersona.sdk2.inquiry.c.b bVar = new deobf.com.withpersona.sdk2.inquiry.c.b();
        bVar.c(Payload.TYPE, updateType);
        deobf.com.roblox.universalapp.facialageestimation.fn.c.g(l10, bVar.l(), 0.0d, 4, null);
    }

    public final void q(long btid, int bucket, @NotNull String group) {
        Intrinsics.checkNotNullParameter(group, "group");
        TelemetryConfig h10 = h();
        deobf.com.roblox.universalapp.facialageestimation.fn.c cVar = deobf.com.roblox.universalapp.facialageestimation.fn.c.f16191a;
        deobf.com.withpersona.sdk2.inquiry.c.b bVar = new deobf.com.withpersona.sdk2.inquiry.c.b();
        bVar.c("btid", String.valueOf(btid));
        bVar.c("bucket", String.valueOf(bucket));
        bVar.c("group", group);
        deobf.com.roblox.universalapp.facialageestimation.fn.c.h(h10, bVar.l());
    }

    public final void r(int bucket, @NotNull String group) {
        Intrinsics.checkNotNullParameter(group, "group");
        TelemetryConfig i10 = i();
        deobf.com.roblox.universalapp.facialageestimation.fn.c cVar = deobf.com.roblox.universalapp.facialageestimation.fn.c.f16191a;
        deobf.com.withpersona.sdk2.inquiry.c.b bVar = new deobf.com.withpersona.sdk2.inquiry.c.b();
        bVar.c("bucket", String.valueOf(bucket));
        bVar.c("group", group);
        deobf.com.roblox.universalapp.facialageestimation.fn.c.h(i10, bVar.l());
    }
}
