package deobf.com.roblox.platform.http.pl;

import com.roblox.platform.NoObfuscate;

// dex: classes2.dex
public class a implements NoObfuscate {
}
