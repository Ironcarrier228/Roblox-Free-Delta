package deobf.com.roblox.platform.http.pl;

// dex: classes2.dex
public class b extends a {
}
