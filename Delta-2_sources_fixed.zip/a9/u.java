package a9;

import a9.a;
import android.os.Parcel;
import android.os.Parcelable;

/* loaded from: classes.dex */
public final class u implements Parcelable.Creator {
    @Override // android.os.Parcelable.Creator
    public final /* bridge */ /* synthetic */ Object createFromParcel(Parcel parcel) {
        int D = p9.b.D(parcel);
        boolean z10 = false;
        while (parcel.dataPosition() < D) {
            int u8 = p9.b.u(parcel);
            if (p9.b.n(u8) != 1) {
                p9.b.C(parcel, u8);
            } else {
                z10 = p9.b.o(parcel, u8);
            }
        }
        p9.b.m(parcel, D);
        return new a.e(z10);
    }

    @Override // android.os.Parcelable.Creator
    public final /* synthetic */ Object[] newArray(int i10) {
        return new a.e[i10];
    }
}
