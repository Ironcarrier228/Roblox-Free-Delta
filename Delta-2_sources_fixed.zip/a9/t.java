package a9;

import a9.a;
import android.os.Parcel;
import android.os.Parcelable;

/* loaded from: classes.dex */
public final class t implements Parcelable.Creator {
    @Override // android.os.Parcelable.Creator
    public final /* bridge */ /* synthetic */ Object createFromParcel(Parcel parcel) {
        int D = p9.b.D(parcel);
        byte[] bArr = null;
        boolean z10 = false;
        String str = null;
        while (parcel.dataPosition() < D) {
            int u8 = p9.b.u(parcel);
            int n10 = p9.b.n(u8);
            if (n10 == 1) {
                z10 = p9.b.o(parcel, u8);
            } else if (n10 == 2) {
                bArr = p9.b.c(parcel, u8);
            } else if (n10 != 3) {
                p9.b.C(parcel, u8);
            } else {
                str = p9.b.h(parcel, u8);
            }
        }
        p9.b.m(parcel, D);
        return new a.d(z10, bArr, str);
    }

    @Override // android.os.Parcelable.Creator
    public final /* synthetic */ Object[] newArray(int i10) {
        return new a.d[i10];
    }
}
