package a9;

import l9.a;

/* loaded from: classes.dex */
public final class n implements a.d {
    public final boolean equals(Object obj) {
        return obj instanceof n;
    }

    public final int hashCode() {
        return o9.q.c(n.class);
    }
}
