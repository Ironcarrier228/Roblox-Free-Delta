package a9;

import android.os.Parcel;
import android.os.Parcelable;

/* loaded from: classes.dex */
public final class v implements Parcelable.Creator {
    @Override // android.os.Parcelable.Creator
    public final /* bridge */ /* synthetic */ Object createFromParcel(Parcel parcel) {
        int D = p9.b.D(parcel);
        int i10 = 0;
        k kVar = null;
        String str = null;
        while (parcel.dataPosition() < D) {
            int u8 = p9.b.u(parcel);
            int n10 = p9.b.n(u8);
            if (n10 == 1) {
                kVar = (k) p9.b.g(parcel, u8, k.CREATOR);
            } else if (n10 == 2) {
                str = p9.b.h(parcel, u8);
            } else if (n10 != 3) {
                p9.b.C(parcel, u8);
            } else {
                i10 = p9.b.w(parcel, u8);
            }
        }
        p9.b.m(parcel, D);
        return new g(kVar, str, i10);
    }

    @Override // android.os.Parcelable.Creator
    public final /* synthetic */ Object[] newArray(int i10) {
        return new g[i10];
    }
}
