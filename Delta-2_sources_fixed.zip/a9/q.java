package a9;

import android.os.Parcel;
import android.os.Parcelable;

/* loaded from: classes.dex */
public final class q implements Parcelable.Creator {
    @Override // android.os.Parcelable.Creator
    public final /* bridge */ /* synthetic */ Object createFromParcel(Parcel parcel) {
        int D = p9.b.D(parcel);
        boolean z10 = false;
        int i10 = 0;
        String str = null;
        String str2 = null;
        String str3 = null;
        String str4 = null;
        while (parcel.dataPosition() < D) {
            int u8 = p9.b.u(parcel);
            switch (p9.b.n(u8)) {
                case 1:
                    str = p9.b.h(parcel, u8);
                    break;
                case 2:
                    str2 = p9.b.h(parcel, u8);
                    break;
                case 3:
                    str3 = p9.b.h(parcel, u8);
                    break;
                case 4:
                    str4 = p9.b.h(parcel, u8);
                    break;
                case 5:
                    z10 = p9.b.o(parcel, u8);
                    break;
                case 6:
                    i10 = p9.b.w(parcel, u8);
                    break;
                default:
                    p9.b.C(parcel, u8);
                    break;
            }
        }
        p9.b.m(parcel, D);
        return new e(str, str2, str3, str4, z10, i10);
    }

    @Override // android.os.Parcelable.Creator
    public final /* synthetic */ Object[] newArray(int i10) {
        return new e[i10];
    }
}
