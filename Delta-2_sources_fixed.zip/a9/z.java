package a9;

import android.os.Parcel;
import android.os.Parcelable;

/* loaded from: classes.dex */
public final class z implements Parcelable.Creator {
    @Override // android.os.Parcelable.Creator
    public final /* bridge */ /* synthetic */ Object createFromParcel(Parcel parcel) {
        int D = p9.b.D(parcel);
        String str = null;
        String str2 = null;
        while (parcel.dataPosition() < D) {
            int u8 = p9.b.u(parcel);
            int n10 = p9.b.n(u8);
            if (n10 == 1) {
                str = p9.b.h(parcel, u8);
            } else if (n10 != 2) {
                p9.b.C(parcel, u8);
            } else {
                str2 = p9.b.h(parcel, u8);
            }
        }
        p9.b.m(parcel, D);
        return new k(str, str2);
    }

    @Override // android.os.Parcelable.Creator
    public final /* synthetic */ Object[] newArray(int i10) {
        return new k[i10];
    }
}
