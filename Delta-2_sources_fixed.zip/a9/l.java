package a9;

import a9.a;
import android.os.Parcel;
import android.os.Parcelable;

/* loaded from: classes.dex */
public final class l implements Parcelable.Creator {
    @Override // android.os.Parcelable.Creator
    public final /* bridge */ /* synthetic */ Object createFromParcel(Parcel parcel) {
        int D = p9.b.D(parcel);
        boolean z10 = false;
        int i10 = 0;
        boolean z11 = false;
        a.e eVar = null;
        a.b bVar = null;
        String str = null;
        a.d dVar = null;
        a.c cVar = null;
        while (parcel.dataPosition() < D) {
            int u8 = p9.b.u(parcel);
            switch (p9.b.n(u8)) {
                case 1:
                    eVar = (a.e) p9.b.g(parcel, u8, a.e.CREATOR);
                    break;
                case 2:
                    bVar = (a.b) p9.b.g(parcel, u8, a.b.CREATOR);
                    break;
                case 3:
                    str = p9.b.h(parcel, u8);
                    break;
                case 4:
                    z10 = p9.b.o(parcel, u8);
                    break;
                case 5:
                    i10 = p9.b.w(parcel, u8);
                    break;
                case 6:
                    dVar = (a.d) p9.b.g(parcel, u8, a.d.CREATOR);
                    break;
                case 7:
                    cVar = (a.c) p9.b.g(parcel, u8, a.c.CREATOR);
                    break;
                case 8:
                    z11 = p9.b.o(parcel, u8);
                    break;
                default:
                    p9.b.C(parcel, u8);
                    break;
            }
        }
        p9.b.m(parcel, D);
        return new a(eVar, bVar, str, z10, i10, dVar, cVar, z11);
    }

    @Override // android.os.Parcelable.Creator
    public final /* synthetic */ Object[] newArray(int i10) {
        return new a[i10];
    }
}
