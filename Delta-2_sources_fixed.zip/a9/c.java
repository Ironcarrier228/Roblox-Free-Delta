package a9;

import androidx.annotation.NonNull;
import com.google.android.gms.tasks.Task;

/* loaded from: classes.dex */
public interface c extends l9.i<n> {
    @NonNull
    @Deprecated
    Task<h> l(@NonNull g gVar);
}
