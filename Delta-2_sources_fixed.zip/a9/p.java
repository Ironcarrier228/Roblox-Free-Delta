package a9;

import android.os.Parcel;
import android.os.Parcelable;

/* loaded from: classes.dex */
public final class p implements Parcelable.Creator {
    @Override // android.os.Parcelable.Creator
    public final /* bridge */ /* synthetic */ Object createFromParcel(Parcel parcel) {
        int D = p9.b.D(parcel);
        int i10 = 0;
        while (parcel.dataPosition() < D) {
            int u8 = p9.b.u(parcel);
            if (p9.b.n(u8) != 1) {
                p9.b.C(parcel, u8);
            } else {
                i10 = p9.b.w(parcel, u8);
            }
        }
        p9.b.m(parcel, D);
        return new d(i10);
    }

    @Override // android.os.Parcelable.Creator
    public final /* synthetic */ Object[] newArray(int i10) {
        return new d[i10];
    }
}
