package a9;

import l9.a;

/* loaded from: classes.dex */
public final class y implements a.d {
    public final boolean equals(Object obj) {
        return obj instanceof y;
    }

    public final int hashCode() {
        return o9.q.c(y.class);
    }
}
