package a9;

import android.app.PendingIntent;
import android.os.Parcel;
import android.os.Parcelable;

/* loaded from: classes.dex */
public final class m implements Parcelable.Creator {
    @Override // android.os.Parcelable.Creator
    public final /* bridge */ /* synthetic */ Object createFromParcel(Parcel parcel) {
        int D = p9.b.D(parcel);
        PendingIntent pendingIntent = null;
        while (parcel.dataPosition() < D) {
            int u8 = p9.b.u(parcel);
            if (p9.b.n(u8) != 1) {
                p9.b.C(parcel, u8);
            } else {
                pendingIntent = (PendingIntent) p9.b.g(parcel, u8, PendingIntent.CREATOR);
            }
        }
        p9.b.m(parcel, D);
        return new b(pendingIntent);
    }

    @Override // android.os.Parcelable.Creator
    public final /* synthetic */ Object[] newArray(int i10) {
        return new b[i10];
    }
}
