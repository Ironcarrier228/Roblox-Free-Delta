package a9;

import a9.a;
import android.os.Parcel;
import android.os.Parcelable;
import java.util.ArrayList;

/* loaded from: classes.dex */
public final class r implements Parcelable.Creator {
    @Override // android.os.Parcelable.Creator
    public final /* bridge */ /* synthetic */ Object createFromParcel(Parcel parcel) {
        int D = p9.b.D(parcel);
        boolean z10 = false;
        boolean z11 = false;
        boolean z12 = false;
        String str = null;
        String str2 = null;
        String str3 = null;
        ArrayList<String> arrayList = null;
        while (parcel.dataPosition() < D) {
            int u8 = p9.b.u(parcel);
            switch (p9.b.n(u8)) {
                case 1:
                    z10 = p9.b.o(parcel, u8);
                    break;
                case 2:
                    str = p9.b.h(parcel, u8);
                    break;
                case 3:
                    str2 = p9.b.h(parcel, u8);
                    break;
                case 4:
                    z11 = p9.b.o(parcel, u8);
                    break;
                case 5:
                    str3 = p9.b.h(parcel, u8);
                    break;
                case 6:
                    arrayList = p9.b.j(parcel, u8);
                    break;
                case 7:
                    z12 = p9.b.o(parcel, u8);
                    break;
                default:
                    p9.b.C(parcel, u8);
                    break;
            }
        }
        p9.b.m(parcel, D);
        return new a.b(z10, str, str2, z11, str3, arrayList, z12);
    }

    @Override // android.os.Parcelable.Creator
    public final /* synthetic */ Object[] newArray(int i10) {
        return new a.b[i10];
    }
}
