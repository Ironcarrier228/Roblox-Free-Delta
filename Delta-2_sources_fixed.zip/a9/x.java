package a9;

import android.net.Uri;
import android.os.Parcel;
import android.os.Parcelable;

/* loaded from: classes.dex */
public final class x implements Parcelable.Creator {
    @Override // android.os.Parcelable.Creator
    public final /* bridge */ /* synthetic */ Object createFromParcel(Parcel parcel) {
        int D = p9.b.D(parcel);
        String str = null;
        String str2 = null;
        String str3 = null;
        String str4 = null;
        Uri uri = null;
        String str5 = null;
        String str6 = null;
        String str7 = null;
        da.q qVar = null;
        while (parcel.dataPosition() < D) {
            int u8 = p9.b.u(parcel);
            switch (p9.b.n(u8)) {
                case 1:
                    str = p9.b.h(parcel, u8);
                    break;
                case 2:
                    str2 = p9.b.h(parcel, u8);
                    break;
                case 3:
                    str3 = p9.b.h(parcel, u8);
                    break;
                case 4:
                    str4 = p9.b.h(parcel, u8);
                    break;
                case 5:
                    uri = (Uri) p9.b.g(parcel, u8, Uri.CREATOR);
                    break;
                case 6:
                    str5 = p9.b.h(parcel, u8);
                    break;
                case 7:
                    str6 = p9.b.h(parcel, u8);
                    break;
                case 8:
                    str7 = p9.b.h(parcel, u8);
                    break;
                case 9:
                    qVar = (da.q) p9.b.g(parcel, u8, da.q.CREATOR);
                    break;
                default:
                    p9.b.C(parcel, u8);
                    break;
            }
        }
        p9.b.m(parcel, D);
        return new j(str, str2, str3, str4, uri, str5, str6, str7, qVar);
    }

    @Override // android.os.Parcelable.Creator
    public final /* synthetic */ Object[] newArray(int i10) {
        return new j[i10];
    }
}
