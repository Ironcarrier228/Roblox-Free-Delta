package ah;

/* loaded from: classes3.dex */
public final class a {

    /* renamed from: a, reason: collision with root package name */
    public final byte[] f430a;
    public final byte[] b;

    public a(byte[] bArr, byte[] bArr2) {
        this.f430a = bArr;
        this.b = bArr2;
    }

    public byte[] a() {
        return this.f430a;
    }

    public byte[] b() {
        return this.b;
    }
}
