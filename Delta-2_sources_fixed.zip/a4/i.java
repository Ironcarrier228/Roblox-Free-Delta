package a4;

import android.annotation.SuppressLint;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Typeface;
import androidx.annotation.NonNull;

/* loaded from: classes.dex */
public class i {

    /* renamed from: d, reason: collision with root package name */
    public static final ThreadLocal<b4.a> f113d = new ThreadLocal<>();

    /* renamed from: a, reason: collision with root package name */
    public final int f114a;

    @NonNull
    public final androidx.emoji2.text.f b;

    /* renamed from: c, reason: collision with root package name */
    public volatile int f115c = 0;

    public i(@NonNull androidx.emoji2.text.f fVar, int i10) {
        this.b = fVar;
        this.f114a = i10;
    }

    public void a(@NonNull Canvas canvas, float f10, float f11, @NonNull Paint paint) {
        Typeface g10 = this.b.g();
        Typeface typeface = paint.getTypeface();
        paint.setTypeface(g10);
        canvas.drawText(this.b.c(), this.f114a * 2, 2, f10, f11, paint);
        paint.setTypeface(typeface);
    }

    public int b(int i10) {
        return g().h(i10);
    }

    public int c() {
        return g().i();
    }

    @SuppressLint({"KotlinPropertyAccess"})
    public int d() {
        return this.f115c & 3;
    }

    public int e() {
        return g().k();
    }

    public int f() {
        return g().l();
    }

    public final b4.a g() {
        ThreadLocal<b4.a> threadLocal = f113d;
        b4.a aVar = threadLocal.get();
        if (aVar == null) {
            aVar = new b4.a();
            threadLocal.set(aVar);
        }
        this.b.d().j(aVar, this.f114a);
        return aVar;
    }

    public short h() {
        return g().m();
    }

    public int i() {
        return g().n();
    }

    public boolean j() {
        return g().j();
    }

    public boolean k() {
        return (this.f115c & 4) > 0;
    }

    public void l(boolean z10) {
        int d10 = d();
        if (z10) {
            this.f115c = d10 | 4;
        } else {
            this.f115c = d10;
        }
    }

    @SuppressLint({"KotlinPropertyAccess"})
    public void m(boolean z10) {
        int i10 = this.f115c & 4;
        this.f115c = z10 ? i10 | 2 : i10 | 1;
    }

    @NonNull
    public String toString() {
        StringBuilder sb2 = new StringBuilder();
        sb2.append(super.toString());
        sb2.append(", id:");
        sb2.append(Integer.toHexString(f()));
        sb2.append(", codepoints:");
        int c10 = c();
        for (int i10 = 0; i10 < c10; i10++) {
            sb2.append(Integer.toHexString(b(i10)));
            sb2.append(" ");
        }
        return sb2.toString();
    }
}
