package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.util.SparseBooleanArray;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import androidx.annotation.NonNull;
import androidx.appcompat.view.menu.ActionMenuItemView;
import androidx.appcompat.view.menu.g;
import androidx.appcompat.view.menu.h;
import androidx.appcompat.view.menu.i;
import androidx.appcompat.view.menu.j;
import androidx.appcompat.view.menu.l;
import androidx.appcompat.widget.ActionMenuView;
import androidx.core.view.b;
import java.util.ArrayList;
import q.f1;
import q.o0;
import q.q;

/* loaded from: classes.dex */
public class a extends androidx.appcompat.view.menu.a implements b.a {
    public c A;
    public b B;
    public final f C;
    public int D;

    /* renamed from: k, reason: collision with root package name */
    public d f1053k;

    /* renamed from: l, reason: collision with root package name */
    public Drawable f1054l;

    /* renamed from: m, reason: collision with root package name */
    public boolean f1055m;

    /* renamed from: n, reason: collision with root package name */
    public boolean f1056n;

    /* renamed from: o, reason: collision with root package name */
    public boolean f1057o;

    /* renamed from: p, reason: collision with root package name */
    public int f1058p;

    /* renamed from: q, reason: collision with root package name */
    public int f1059q;

    /* renamed from: r, reason: collision with root package name */
    public int f1060r;

    /* renamed from: s, reason: collision with root package name */
    public boolean f1061s;

    /* renamed from: t, reason: collision with root package name */
    public boolean f1062t;

    /* renamed from: u, reason: collision with root package name */
    public boolean f1063u;

    /* renamed from: v, reason: collision with root package name */
    public boolean f1064v;

    /* renamed from: w, reason: collision with root package name */
    public int f1065w;

    /* renamed from: x, reason: collision with root package name */
    public final SparseBooleanArray f1066x;

    /* renamed from: y, reason: collision with root package name */
    public e f1067y;

    /* renamed from: z, reason: collision with root package name */
    public C0023a f1068z;

    /* renamed from: androidx.appcompat.widget.a$a, reason: collision with other inner class name */
    public class C0023a extends h {
        public C0023a(Context context, l lVar, View view) {
            super(context, lVar, view, false, i.a.f18738m);
            if (!((g) lVar.getItem()).l()) {
                View view2 = a.this.f1053k;
                f(view2 == null ? (View) a.this.f692i : view2);
            }
            j(a.this.C);
        }

        @Override // androidx.appcompat.view.menu.h
        public void e() {
            a aVar = a.this;
            aVar.f1068z = null;
            aVar.D = 0;
            super.e();
        }
    }

    public class b extends ActionMenuItemView.b {
        public b() {
        }

        @Override // androidx.appcompat.view.menu.ActionMenuItemView.b
        public p.f a() {
            C0023a c0023a = a.this.f1068z;
            if (c0023a != null) {
                return c0023a.c();
            }
            return null;
        }
    }

    public class c implements Runnable {

        /* renamed from: a, reason: collision with root package name */
        public e f1071a;

        public c(e eVar) {
            this.f1071a = eVar;
        }

        @Override // java.lang.Runnable
        public void run() {
            if (a.this.f686c != null) {
                a.this.f686c.d();
            }
            View view = (View) a.this.f692i;
            if (view != null && view.getWindowToken() != null && this.f1071a.m()) {
                a.this.f1067y = this.f1071a;
            }
            a.this.A = null;
        }
    }

    public class d extends q implements ActionMenuView.a {

        /* renamed from: androidx.appcompat.widget.a$d$a, reason: collision with other inner class name */
        public class C0024a extends o0 {

            /* renamed from: j, reason: collision with root package name */
            public final /* synthetic */ a f1073j;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            public C0024a(View view, a aVar) {
                super(view);
                this.f1073j = aVar;
            }

            @Override // q.o0
            public p.f b() {
                e eVar = a.this.f1067y;
                if (eVar == null) {
                    return null;
                }
                return eVar.c();
            }

            @Override // q.o0
            public boolean c() {
                a.this.L();
                return true;
            }

            @Override // q.o0
            public boolean d() {
                a aVar = a.this;
                if (aVar.A != null) {
                    return false;
                }
                aVar.C();
                return true;
            }
        }

        public d(Context context) {
            super(context, null, i.a.f18737l);
            setClickable(true);
            setFocusable(true);
            setVisibility(0);
            setEnabled(true);
            f1.a(this, getContentDescription());
            setOnTouchListener(new C0024a(this, a.this));
        }

        @Override // androidx.appcompat.widget.ActionMenuView.a
        public boolean a() {
            return false;
        }

        @Override // androidx.appcompat.widget.ActionMenuView.a
        public boolean b() {
            return false;
        }

        @Override // android.view.View
        public boolean performClick() {
            if (super.performClick()) {
                return true;
            }
            playSoundEffect(0);
            a.this.L();
            return true;
        }

        @Override // android.widget.ImageView
        public boolean setFrame(int i10, int i11, int i12, int i13) {
            boolean frame = super.setFrame(i10, i11, i12, i13);
            Drawable drawable = getDrawable();
            Drawable background = getBackground();
            if (drawable != null && background != null) {
                int width = getWidth();
                int height = getHeight();
                int max = Math.max(width, height) / 2;
                int paddingLeft = (width + (getPaddingLeft() - getPaddingRight())) / 2;
                int paddingTop = (height + (getPaddingTop() - getPaddingBottom())) / 2;
                q2.a.l(background, paddingLeft - max, paddingTop - max, paddingLeft + max, paddingTop + max);
            }
            return frame;
        }
    }

    public class e extends h {
        public e(Context context, androidx.appcompat.view.menu.e eVar, View view, boolean z10) {
            super(context, eVar, view, z10, i.a.f18738m);
            h(8388613);
            j(a.this.C);
        }

        @Override // androidx.appcompat.view.menu.h
        public void e() {
            if (a.this.f686c != null) {
                a.this.f686c.close();
            }
            a.this.f1067y = null;
            super.e();
        }
    }

    public class f implements i.a {
        public f() {
        }

        @Override // androidx.appcompat.view.menu.i.a
        public void b(@NonNull androidx.appcompat.view.menu.e eVar, boolean z10) {
            if (eVar instanceof l) {
                eVar.D().e(false);
            }
            i.a n10 = a.this.n();
            if (n10 != null) {
                n10.b(eVar, z10);
            }
        }

        @Override // androidx.appcompat.view.menu.i.a
        public boolean c(@NonNull androidx.appcompat.view.menu.e eVar) {
            if (eVar == a.this.f686c) {
                return false;
            }
            a.this.D = ((l) eVar).getItem().getItemId();
            i.a n10 = a.this.n();
            if (n10 != null) {
                return n10.c(eVar);
            }
            return false;
        }
    }

    public a(Context context) {
        super(context, i.g.f18821c, i.g.b);
        this.f1066x = new SparseBooleanArray();
        this.C = new f();
    }

    /* JADX WARN: Multi-variable type inference failed */
    public final View A(MenuItem menuItem) {
        ViewGroup viewGroup = (ViewGroup) this.f692i;
        if (viewGroup == null) {
            return null;
        }
        int childCount = viewGroup.getChildCount();
        for (int i10 = 0; i10 < childCount; i10++) {
            View childAt = viewGroup.getChildAt(i10);
            if ((childAt instanceof j.a) && ((j.a) childAt).getItemData() == menuItem) {
                return childAt;
            }
        }
        return null;
    }

    public Drawable B() {
        d dVar = this.f1053k;
        if (dVar != null) {
            return dVar.getDrawable();
        }
        if (this.f1055m) {
            return this.f1054l;
        }
        return null;
    }

    public boolean C() {
        Object obj;
        c cVar = this.A;
        if (cVar != null && (obj = this.f692i) != null) {
            ((View) obj).removeCallbacks(cVar);
            this.A = null;
            return true;
        }
        e eVar = this.f1067y;
        if (eVar == null) {
            return false;
        }
        eVar.b();
        return true;
    }

    public boolean D() {
        C0023a c0023a = this.f1068z;
        if (c0023a == null) {
            return false;
        }
        c0023a.b();
        return true;
    }

    public boolean E() {
        return this.A != null || F();
    }

    public boolean F() {
        e eVar = this.f1067y;
        return eVar != null && eVar.d();
    }

    public void G(Configuration configuration) {
        if (!this.f1061s) {
            this.f1060r = o.a.b(this.b).d();
        }
        androidx.appcompat.view.menu.e eVar = this.f686c;
        if (eVar != null) {
            eVar.L(true);
        }
    }

    public void H(boolean z10) {
        this.f1064v = z10;
    }

    public void I(ActionMenuView actionMenuView) {
        this.f692i = actionMenuView;
        actionMenuView.a(this.f686c);
    }

    public void J(Drawable drawable) {
        d dVar = this.f1053k;
        if (dVar != null) {
            dVar.setImageDrawable(drawable);
        } else {
            this.f1055m = true;
            this.f1054l = drawable;
        }
    }

    public void K(boolean z10) {
        this.f1056n = z10;
        this.f1057o = true;
    }

    public boolean L() {
        androidx.appcompat.view.menu.e eVar;
        if (!this.f1056n || F() || (eVar = this.f686c) == null || this.f692i == null || this.A != null || eVar.z().isEmpty()) {
            return false;
        }
        c cVar = new c(new e(this.b, this.f686c, this.f1053k, true));
        this.A = cVar;
        ((View) this.f692i).post(cVar);
        return true;
    }

    @Override // androidx.core.view.b.a
    public void a(boolean z10) {
        if (z10) {
            super.e(null);
            return;
        }
        androidx.appcompat.view.menu.e eVar = this.f686c;
        if (eVar != null) {
            eVar.e(false);
        }
    }

    @Override // androidx.appcompat.view.menu.a, androidx.appcompat.view.menu.i
    public void b(androidx.appcompat.view.menu.e eVar, boolean z10) {
        z();
        super.b(eVar, z10);
    }

    @Override // androidx.appcompat.view.menu.a, androidx.appcompat.view.menu.i
    public boolean e(l lVar) {
        boolean z10 = false;
        if (!lVar.hasVisibleItems()) {
            return false;
        }
        l lVar2 = lVar;
        while (lVar2.f0() != this.f686c) {
            lVar2 = (l) lVar2.f0();
        }
        View A = A(lVar2.getItem());
        if (A == null) {
            return false;
        }
        this.D = lVar.getItem().getItemId();
        int size = lVar.size();
        int i10 = 0;
        while (true) {
            if (i10 >= size) {
                break;
            }
            MenuItem item = lVar.getItem(i10);
            if (item.isVisible() && item.getIcon() != null) {
                z10 = true;
                break;
            }
            i10++;
        }
        C0023a c0023a = new C0023a(this.b, lVar, A);
        this.f1068z = c0023a;
        c0023a.g(z10);
        this.f1068z.k();
        super.e(lVar);
        return true;
    }

    @Override // androidx.appcompat.view.menu.a, androidx.appcompat.view.menu.i
    public void f(boolean z10) {
        super.f(z10);
        ((View) this.f692i).requestLayout();
        androidx.appcompat.view.menu.e eVar = this.f686c;
        boolean z11 = false;
        if (eVar != null) {
            ArrayList<g> s8 = eVar.s();
            int size = s8.size();
            for (int i10 = 0; i10 < size; i10++) {
                androidx.core.view.b a10 = s8.get(i10).a();
                if (a10 != null) {
                    a10.i(this);
                }
            }
        }
        androidx.appcompat.view.menu.e eVar2 = this.f686c;
        ArrayList<g> z12 = eVar2 != null ? eVar2.z() : null;
        if (this.f1056n && z12 != null) {
            int size2 = z12.size();
            if (size2 == 1) {
                z11 = !z12.get(0).isActionViewExpanded();
            } else if (size2 > 0) {
                z11 = true;
            }
        }
        if (z11) {
            if (this.f1053k == null) {
                this.f1053k = new d(this.f685a);
            }
            ViewGroup viewGroup = (ViewGroup) this.f1053k.getParent();
            if (viewGroup != this.f692i) {
                if (viewGroup != null) {
                    viewGroup.removeView(this.f1053k);
                }
                ActionMenuView actionMenuView = (ActionMenuView) this.f692i;
                actionMenuView.addView(this.f1053k, actionMenuView.D());
            }
        } else {
            d dVar = this.f1053k;
            if (dVar != null) {
                Object parent = dVar.getParent();
                Object obj = this.f692i;
                if (parent == obj) {
                    ((ViewGroup) obj).removeView(this.f1053k);
                }
            }
        }
        ((ActionMenuView) this.f692i).setOverflowReserved(this.f1056n);
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r3v0 */
    /* JADX WARN: Type inference failed for: r3v1, types: [int] */
    /* JADX WARN: Type inference failed for: r3v12 */
    @Override // androidx.appcompat.view.menu.i
    public boolean g() {
        ArrayList<g> arrayList;
        int i10;
        int i11;
        int i12;
        boolean z10;
        int i13;
        a aVar = this;
        androidx.appcompat.view.menu.e eVar = aVar.f686c;
        View view = null;
        var r32 = 0;
        if (eVar != null) {
            arrayList = eVar.E();
            i10 = arrayList.size();
        } else {
            arrayList = null;
            i10 = 0;
        }
        int i14 = aVar.f1060r;
        int i15 = aVar.f1059q;
        int makeMeasureSpec = View.MeasureSpec.makeMeasureSpec(0, 0);
        ViewGroup viewGroup = (ViewGroup) aVar.f692i;
        boolean z11 = false;
        int i16 = 0;
        int i17 = 0;
        for (int i18 = 0; i18 < i10; i18++) {
            g gVar = arrayList.get(i18);
            if (gVar.o()) {
                i16++;
            } else if (gVar.n()) {
                i17++;
            } else {
                z11 = true;
            }
            if (aVar.f1064v && gVar.isActionViewExpanded()) {
                i14 = 0;
            }
        }
        if (aVar.f1056n && (z11 || i17 + i16 > i14)) {
            i14--;
        }
        int i19 = i14 - i16;
        SparseBooleanArray sparseBooleanArray = aVar.f1066x;
        sparseBooleanArray.clear();
        if (aVar.f1062t) {
            int i20 = aVar.f1065w;
            i12 = i15 / i20;
            i11 = i20 + ((i15 % i20) / i12);
        } else {
            i11 = 0;
            i12 = 0;
        }
        int i21 = 0;
        int i22 = 0;
        while (i21 < i10) {
            g gVar2 = arrayList.get(i21);
            if (gVar2.o()) {
                View o10 = aVar.o(gVar2, view, viewGroup);
                if (aVar.f1062t) {
                    i12 -= ActionMenuView.J(o10, i11, i12, makeMeasureSpec, r32);
                } else {
                    o10.measure(makeMeasureSpec, makeMeasureSpec);
                }
                int measuredWidth = o10.getMeasuredWidth();
                i15 -= measuredWidth;
                if (i22 == 0) {
                    i22 = measuredWidth;
                }
                int groupId = gVar2.getGroupId();
                if (groupId != 0) {
                    sparseBooleanArray.put(groupId, true);
                }
                gVar2.u(true);
                z10 = r32;
                i13 = i10;
            } else if (gVar2.n()) {
                int groupId2 = gVar2.getGroupId();
                boolean z12 = sparseBooleanArray.get(groupId2);
                boolean z13 = (i19 > 0 || z12) && i15 > 0 && (!aVar.f1062t || i12 > 0);
                boolean z14 = z13;
                i13 = i10;
                if (z13) {
                    View o11 = aVar.o(gVar2, null, viewGroup);
                    if (aVar.f1062t) {
                        int J = ActionMenuView.J(o11, i11, i12, makeMeasureSpec, 0);
                        i12 -= J;
                        if (J == 0) {
                            z14 = false;
                        }
                    } else {
                        o11.measure(makeMeasureSpec, makeMeasureSpec);
                    }
                    boolean z15 = z14;
                    int measuredWidth2 = o11.getMeasuredWidth();
                    i15 -= measuredWidth2;
                    if (i22 == 0) {
                        i22 = measuredWidth2;
                    }
                    z13 = z15 & (!aVar.f1062t ? i15 + i22 <= 0 : i15 < 0);
                }
                if (z13 && groupId2 != 0) {
                    sparseBooleanArray.put(groupId2, true);
                } else if (z12) {
                    sparseBooleanArray.put(groupId2, false);
                    for (int i23 = 0; i23 < i21; i23++) {
                        g gVar3 = arrayList.get(i23);
                        if (gVar3.getGroupId() == groupId2) {
                            if (gVar3.l()) {
                                i19++;
                            }
                            gVar3.u(false);
                        }
                    }
                }
                if (z13) {
                    i19--;
                }
                gVar2.u(z13);
                z10 = false;
            } else {
                z10 = r32;
                i13 = i10;
                gVar2.u(z10);
            }
            i21++;
            r32 = z10;
            i10 = i13;
            view = null;
            aVar = this;
        }
        return true;
    }

    @Override // androidx.appcompat.view.menu.a, androidx.appcompat.view.menu.i
    public void i(@NonNull Context context, androidx.appcompat.view.menu.e eVar) {
        super.i(context, eVar);
        Resources resources = context.getResources();
        o.a b10 = o.a.b(context);
        if (!this.f1057o) {
            this.f1056n = b10.h();
        }
        if (!this.f1063u) {
            this.f1058p = b10.c();
        }
        if (!this.f1061s) {
            this.f1060r = b10.d();
        }
        int i10 = this.f1058p;
        if (this.f1056n) {
            if (this.f1053k == null) {
                d dVar = new d(this.f685a);
                this.f1053k = dVar;
                if (this.f1055m) {
                    dVar.setImageDrawable(this.f1054l);
                    this.f1054l = null;
                    this.f1055m = false;
                }
                int makeMeasureSpec = View.MeasureSpec.makeMeasureSpec(0, 0);
                this.f1053k.measure(makeMeasureSpec, makeMeasureSpec);
            }
            i10 -= this.f1053k.getMeasuredWidth();
        } else {
            this.f1053k = null;
        }
        this.f1059q = i10;
        this.f1065w = (int) (resources.getDisplayMetrics().density * 56.0f);
    }

    @Override // androidx.appcompat.view.menu.a
    public void k(g gVar, j.a aVar) {
        aVar.c(gVar, 0);
        ActionMenuItemView actionMenuItemView = (ActionMenuItemView) aVar;
        actionMenuItemView.setItemInvoker((ActionMenuView) this.f692i);
        if (this.B == null) {
            this.B = new b();
        }
        actionMenuItemView.setPopupCallback(this.B);
    }

    @Override // androidx.appcompat.view.menu.a
    public boolean m(ViewGroup viewGroup, int i10) {
        if (viewGroup.getChildAt(i10) == this.f1053k) {
            return false;
        }
        return super.m(viewGroup, i10);
    }

    @Override // androidx.appcompat.view.menu.a
    public View o(g gVar, View view, ViewGroup viewGroup) {
        View actionView = gVar.getActionView();
        if (actionView == null || gVar.j()) {
            actionView = super.o(gVar, view, viewGroup);
        }
        actionView.setVisibility(gVar.isActionViewExpanded() ? 8 : 0);
        ActionMenuView actionMenuView = (ActionMenuView) viewGroup;
        ViewGroup.LayoutParams layoutParams = actionView.getLayoutParams();
        if (!actionMenuView.checkLayoutParams(layoutParams)) {
            actionView.setLayoutParams(actionMenuView.generateLayoutParams(layoutParams));
        }
        return actionView;
    }

    @Override // androidx.appcompat.view.menu.a
    public j p(ViewGroup viewGroup) {
        j jVar = this.f692i;
        j p8 = super.p(viewGroup);
        if (jVar != p8) {
            ((ActionMenuView) p8).setPresenter(this);
        }
        return p8;
    }

    @Override // androidx.appcompat.view.menu.a
    public boolean r(int i10, g gVar) {
        return gVar.l();
    }

    public boolean z() {
        return C() | D();
    }


    // --- восстановлено из DEX (androidx/appcompat/widget/a$d$a) ---
    public static class a extends q.o0 {
        androidx.appcompat.widget.a j;
        androidx.appcompat.widget.a.d k;
        public a(androidx.appcompat.widget.a.d p0, android.view.View p1, androidx.appcompat.widget.a p2) { }
        public p.f b() { throw new UnsupportedOperationException("stub"); }
        public boolean c() { throw new UnsupportedOperationException("stub"); }
        public boolean d() { throw new UnsupportedOperationException("stub"); }
    }
}
