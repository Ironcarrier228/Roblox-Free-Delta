package androidx.credentials.playservices.controllers;

import android.content.Intent;
import android.os.CancellationSignal;
import android.util.Log;
import androidx.credentials.playservices.controllers.CredentialProviderBaseController;
import androidx.credentials.playservices.controllers.CredentialProviderController;
import androidx.credentials.playservices.controllers.ResponseUtils;
import com.github.luben.zstd.BuildConfig;
import e3.l0;
import e3.p;
import f3.n;
import f3.q;
import java.util.concurrent.Executor;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import o3.a;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0004\b\u0001\u0018\u0000 \u00042\u00020\u0001:\u0001\u0004B\u0007¢\u0006\u0004\b\u0002\u0010\u0003¨\u0006\u0005"}, d2 = {"Landroidx/credentials/playservices/controllers/ResponseUtils;", BuildConfig.FLAVOR, "<init>", "()V", "Companion", "credentials-play-services-auth_release"}, k = 1, mv = {2, 1, 0}, xi = 48)
/* loaded from: classes.dex */
public final class ResponseUtils {

    /* renamed from: Companion, reason: from kotlin metadata */
    @NotNull
    public static final Companion INSTANCE = new Companion(null);

    @NotNull
    private static final String TAG = "GetCredentialController";

    @Metadata(d1 = {"\u0000D\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\b\u0003\b\u0086\u0003\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003JO\u0010\u0012\u001a\u00020\u00112\u0006\u0010\u0005\u001a\u00020\u00042\u0006\u0010\u0006\u001a\u00020\u00042\b\u0010\b\u001a\u0004\u0018\u00010\u00072\u0006\u0010\n\u001a\u00020\t2\u0012\u0010\u000e\u001a\u000e\u0012\u0004\u0012\u00020\f\u0012\u0004\u0012\u00020\r0\u000b2\b\u0010\u0010\u001a\u0004\u0018\u00010\u000fH\u0007¢\u0006\u0004\b\u0012\u0010\u0013R\u0014\u0010\u0015\u001a\u00020\u00148\u0002X\u0082T¢\u0006\u0006\n\u0004\b\u0015\u0010\u0016¨\u0006\u0017"}, d2 = {"Landroidx/credentials/playservices/controllers/ResponseUtils$Companion;", BuildConfig.FLAVOR, "<init>", "()V", BuildConfig.FLAVOR, "uniqueRequestCode", "resultCode", "Landroid/content/Intent;", "data", "Ljava/util/concurrent/Executor;", "executor", "Le3/p;", "Le3/l0;", "Lf3/n;", "callback", "Landroid/os/CancellationSignal;", "cancellationSignal", BuildConfig.FLAVOR, "handleGetCredentialResponse", "(IILandroid/content/Intent;Ljava/util/concurrent/Executor;Le3/p;Landroid/os/CancellationSignal;)V", BuildConfig.FLAVOR, "TAG", "Ljava/lang/String;", "credentials-play-services-auth_release"}, k = 1, mv = {2, 1, 0}, xi = 48)
    public static final class Companion {
        public /* synthetic */ Companion(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static final Unit handleGetCredentialResponse$lambda$0(CancellationSignal cancellationSignal, Function0 f10) {
            Intrinsics.checkNotNullParameter(f10, "f");
            CredentialProviderController.INSTANCE.cancelOrCallbackExceptionOrResult$credentials_play_services_auth_release(cancellationSignal, f10);
            return Unit.f21504a;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static final Unit handleGetCredentialResponse$lambda$2(Executor executor, final p pVar, final n e10) {
            Intrinsics.checkNotNullParameter(e10, "e");
            executor.execute(new Runnable() { // from class: k3.m
                @Override // java.lang.Runnable
                public final void run() {
                    p.this.a(e10);
                }
            });
            return Unit.f21504a;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static final Unit handleGetCredentialResponse$lambda$4(Executor executor, final p pVar) {
            executor.execute(new Runnable() { // from class: k3.e
                @Override // java.lang.Runnable
                public final void run() {
                    ResponseUtils.Companion.handleGetCredentialResponse$lambda$4$lambda$3(p.this);
                }
            });
            return Unit.f21504a;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static final void handleGetCredentialResponse$lambda$4$lambda$3(p pVar) {
            pVar.a(new q("No provider data returned."));
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static final Unit handleGetCredentialResponse$lambda$6(Executor executor, final p pVar, final l0 l0Var) {
            executor.execute(new Runnable() { // from class: k3.g
                @Override // java.lang.Runnable
                public final void run() {
                    p.this.onResult(l0Var);
                }
            });
            return Unit.f21504a;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static final Unit handleGetCredentialResponse$lambda$8(Executor executor, final p pVar, final n nVar) {
            executor.execute(new Runnable() { // from class: k3.f
                @Override // java.lang.Runnable
                public final void run() {
                    ResponseUtils.Companion.handleGetCredentialResponse$lambda$8$lambda$7(p.this, nVar);
                }
            });
            return Unit.f21504a;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static final void handleGetCredentialResponse$lambda$8$lambda$7(p pVar, n nVar) {
            if (nVar == null) {
                nVar = new q("No provider data returned");
            }
            pVar.a(nVar);
        }

        public final void handleGetCredentialResponse(int uniqueRequestCode, int resultCode, @Nullable Intent data, @NotNull final Executor executor, @NotNull final p<l0, n> callback, @Nullable CancellationSignal cancellationSignal) {
            Intrinsics.checkNotNullParameter(executor, "executor");
            Intrinsics.checkNotNullParameter(callback, "callback");
            CredentialProviderBaseController.Companion companion = CredentialProviderBaseController.INSTANCE;
            if (uniqueRequestCode != companion.getCONTROLLER_REQUEST_CODE$credentials_play_services_auth_release()) {
                Log.w(ResponseUtils.TAG, "Returned request code " + companion.getCONTROLLER_REQUEST_CODE$credentials_play_services_auth_release() + " which  does not match what was given " + uniqueRequestCode);
                return;
            }
            CredentialProviderController.Companion companion2 = CredentialProviderController.INSTANCE;
            if (companion2.maybeReportErrorResultCodeGet$credentials_play_services_auth_release(resultCode, new Function2() { // from class: k3.h
                @Override // kotlin.jvm.functions.Function2
                public final Object invoke(Object obj, Object obj2) {
                    Unit handleGetCredentialResponse$lambda$0;
                    handleGetCredentialResponse$lambda$0 = ResponseUtils.Companion.handleGetCredentialResponse$lambda$0((CancellationSignal) obj, (Function0) obj2);
                    return handleGetCredentialResponse$lambda$0;
                }
            }, new Function1() { // from class: k3.i
                @Override // kotlin.jvm.functions.Function1
                public final Object invoke(Object obj) {
                    Unit handleGetCredentialResponse$lambda$2;
                    handleGetCredentialResponse$lambda$2 = ResponseUtils.Companion.handleGetCredentialResponse$lambda$2(executor, callback, (n) obj);
                    return handleGetCredentialResponse$lambda$2;
                }
            }, cancellationSignal)) {
                return;
            }
            if (data == null) {
                companion2.cancelOrCallbackExceptionOrResult$credentials_play_services_auth_release(cancellationSignal, new Function0() { // from class: k3.j
                    @Override // kotlin.jvm.functions.Function0
                    public final Object invoke() {
                        Unit handleGetCredentialResponse$lambda$4;
                        handleGetCredentialResponse$lambda$4 = ResponseUtils.Companion.handleGetCredentialResponse$lambda$4(executor, callback);
                        return handleGetCredentialResponse$lambda$4;
                    }
                });
                return;
            }
            a.Companion companion3 = a.INSTANCE;
            final l0 d10 = companion3.d(data);
            if (d10 != null) {
                companion2.cancelOrCallbackExceptionOrResult$credentials_play_services_auth_release(cancellationSignal, new Function0() { // from class: k3.k
                    @Override // kotlin.jvm.functions.Function0
                    public final Object invoke() {
                        Unit handleGetCredentialResponse$lambda$6;
                        handleGetCredentialResponse$lambda$6 = ResponseUtils.Companion.handleGetCredentialResponse$lambda$6(executor, callback, d10);
                        return handleGetCredentialResponse$lambda$6;
                    }
                });
            } else {
                final n c10 = companion3.c(data);
                companion2.cancelOrCallbackExceptionOrResult$credentials_play_services_auth_release(cancellationSignal, new Function0() { // from class: k3.l
                    @Override // kotlin.jvm.functions.Function0
                    public final Object invoke() {
                        Unit handleGetCredentialResponse$lambda$8;
                        handleGetCredentialResponse$lambda$8 = ResponseUtils.Companion.handleGetCredentialResponse$lambda$8(executor, callback, c10);
                        return handleGetCredentialResponse$lambda$8;
                    }
                });
            }
        }

        private Companion() {
        }
    }

    public static final void handleGetCredentialResponse(int i10, int i11, @Nullable Intent intent, @NotNull Executor executor, @NotNull p<l0, n> pVar, @Nullable CancellationSignal cancellationSignal) {
        INSTANCE.handleGetCredentialResponse(i10, i11, intent, executor, pVar, cancellationSignal);
    }
}
