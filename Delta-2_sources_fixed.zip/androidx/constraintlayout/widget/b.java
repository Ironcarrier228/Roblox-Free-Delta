package androidx.constraintlayout.widget;

import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.util.AttributeSet;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import c2.i;
import java.util.Arrays;
import java.util.HashMap;

/* loaded from: classes.dex */
public abstract class b extends View {

    /* renamed from: a, reason: collision with root package name */
    public int[] f1393a;
    public int b;

    /* renamed from: c, reason: collision with root package name */
    public Context f1394c;

    /* renamed from: d, reason: collision with root package name */
    public i f1395d;

    /* renamed from: e, reason: collision with root package name */
    public boolean f1396e;

    /* renamed from: f, reason: collision with root package name */
    public String f1397f;

    /* renamed from: g, reason: collision with root package name */
    public String f1398g;

    /* renamed from: h, reason: collision with root package name */
    public View[] f1399h;

    /* renamed from: i, reason: collision with root package name */
    public HashMap<Integer, String> f1400i;

    public b(Context context) {
        super(context);
        this.f1393a = new int[32];
        this.f1396e = false;
        this.f1399h = null;
        this.f1400i = new HashMap<>();
        this.f1394c = context;
        m(null);
    }

    public final void d(String str) {
        if (str == null || str.length() == 0 || this.f1394c == null) {
            return;
        }
        String trim = str.trim();
        int k10 = k(trim);
        if (k10 != 0) {
            this.f1400i.put(Integer.valueOf(k10), trim);
            e(k10);
            return;
        }
        Log.w("ConstraintHelper", "Could not find id of \"" + trim + "\"");
    }

    public final void e(int i10) {
        if (i10 == getId()) {
            return;
        }
        int i11 = this.b + 1;
        int[] iArr = this.f1393a;
        if (i11 > iArr.length) {
            this.f1393a = Arrays.copyOf(iArr, iArr.length * 2);
        }
        int[] iArr2 = this.f1393a;
        int i12 = this.b;
        iArr2[i12] = i10;
        this.b = i12 + 1;
    }

    public final void f(String str) {
        if (str == null || str.length() == 0 || this.f1394c == null) {
            return;
        }
        String trim = str.trim();
        ConstraintLayout constraintLayout = getParent() instanceof ConstraintLayout ? (ConstraintLayout) getParent() : null;
        if (constraintLayout == null) {
            Log.w("ConstraintHelper", "Parent not a ConstraintLayout");
            return;
        }
        int childCount = constraintLayout.getChildCount();
        for (int i10 = 0; i10 < childCount; i10++) {
            View childAt = constraintLayout.getChildAt(i10);
            ViewGroup.LayoutParams layoutParams = childAt.getLayoutParams();
            if ((layoutParams instanceof ConstraintLayout.b) && trim.equals(((ConstraintLayout.b) layoutParams).f1325c0)) {
                if (childAt.getId() == -1) {
                    Log.w("ConstraintHelper", "to use ConstraintTag view " + childAt.getClass().getSimpleName() + " must have an ID");
                } else {
                    e(childAt.getId());
                }
            }
        }
    }

    public void g() {
        ViewParent parent = getParent();
        if (parent == null || !(parent instanceof ConstraintLayout)) {
            return;
        }
        h((ConstraintLayout) parent);
    }

    public int[] getReferencedIds() {
        return Arrays.copyOf(this.f1393a, this.b);
    }

    public void h(ConstraintLayout constraintLayout) {
        int visibility = getVisibility();
        float elevation = getElevation();
        for (int i10 = 0; i10 < this.b; i10++) {
            View q8 = constraintLayout.q(this.f1393a[i10]);
            if (q8 != null) {
                q8.setVisibility(visibility);
                if (elevation > 0.0f) {
                    q8.setTranslationZ(q8.getTranslationZ() + elevation);
                }
            }
        }
    }

    public void i(ConstraintLayout constraintLayout) {
    }

    public final int j(ConstraintLayout constraintLayout, String str) {
        Resources resources;
        String str2;
        if (str == null || constraintLayout == null || (resources = this.f1394c.getResources()) == null) {
            return 0;
        }
        int childCount = constraintLayout.getChildCount();
        for (int i10 = 0; i10 < childCount; i10++) {
            View childAt = constraintLayout.getChildAt(i10);
            if (childAt.getId() != -1) {
                try {
                    str2 = resources.getResourceEntryName(childAt.getId());
                } catch (Resources.NotFoundException unused) {
                    str2 = null;
                }
                if (str.equals(str2)) {
                    return childAt.getId();
                }
            }
        }
        return 0;
    }

    public final int k(String str) {
        ConstraintLayout constraintLayout = getParent() instanceof ConstraintLayout ? (ConstraintLayout) getParent() : null;
        int i10 = 0;
        if (isInEditMode() && constraintLayout != null) {
            Object l10 = constraintLayout.l(0, str);
            if (l10 instanceof Integer) {
                i10 = ((Integer) l10).intValue();
            }
        }
        if (i10 == 0 && constraintLayout != null) {
            i10 = j(constraintLayout, str);
        }
        if (i10 == 0) {
            try {
                i10 = g2.c.class.getField(str).getInt(null);
            } catch (Exception unused) {
            }
        }
        return i10 == 0 ? this.f1394c.getResources().getIdentifier(str, "id", this.f1394c.getPackageName()) : i10;
    }

    public View[] l(ConstraintLayout constraintLayout) {
        View[] viewArr = this.f1399h;
        if (viewArr == null || viewArr.length != this.b) {
            this.f1399h = new View[this.b];
        }
        for (int i10 = 0; i10 < this.b; i10++) {
            this.f1399h[i10] = constraintLayout.q(this.f1393a[i10]);
        }
        return this.f1399h;
    }

    public void m(AttributeSet attributeSet) {
        if (attributeSet != null) {
            TypedArray obtainStyledAttributes = getContext().obtainStyledAttributes(attributeSet, g2.d.V0);
            int indexCount = obtainStyledAttributes.getIndexCount();
            for (int i10 = 0; i10 < indexCount; i10++) {
                int index = obtainStyledAttributes.getIndex(i10);
                if (index == g2.d.f17176o1) {
                    String string = obtainStyledAttributes.getString(index);
                    this.f1397f = string;
                    setIds(string);
                } else if (index == g2.d.f17185p1) {
                    String string2 = obtainStyledAttributes.getString(index);
                    this.f1398g = string2;
                    setReferenceTags(string2);
                }
            }
            obtainStyledAttributes.recycle();
        }
    }

    public void n(c2.e eVar, boolean z10) {
    }

    public void o(ConstraintLayout constraintLayout) {
    }

    @Override // android.view.View
    public void onAttachedToWindow() {
        super.onAttachedToWindow();
        String str = this.f1397f;
        if (str != null) {
            setIds(str);
        }
        String str2 = this.f1398g;
        if (str2 != null) {
            setReferenceTags(str2);
        }
    }

    @Override // android.view.View
    public void onDraw(@NonNull Canvas canvas) {
    }

    @Override // android.view.View
    public void onMeasure(int i10, int i11) {
        if (this.f1396e) {
            super.onMeasure(i10, i11);
        } else {
            setMeasuredDimension(0, 0);
        }
    }

    public void p(ConstraintLayout constraintLayout) {
    }

    public void q(ConstraintLayout constraintLayout) {
    }

    public void r(ConstraintLayout constraintLayout) {
        String str;
        int j10;
        if (isInEditMode()) {
            setIds(this.f1397f);
        }
        i iVar = this.f1395d;
        if (iVar == null) {
            return;
        }
        iVar.c();
        for (int i10 = 0; i10 < this.b; i10++) {
            int i11 = this.f1393a[i10];
            View q8 = constraintLayout.q(i11);
            if (q8 == null && (j10 = j(constraintLayout, (str = this.f1400i.get(Integer.valueOf(i11))))) != 0) {
                this.f1393a[i10] = j10;
                this.f1400i.put(Integer.valueOf(j10), str);
                q8 = constraintLayout.q(j10);
            }
            if (q8 != null) {
                this.f1395d.a(constraintLayout.r(q8));
            }
        }
        this.f1395d.b(constraintLayout.f1298c);
    }

    public void s() {
        if (this.f1395d == null) {
            return;
        }
        ViewGroup.LayoutParams layoutParams = getLayoutParams();
        if (layoutParams instanceof ConstraintLayout.b) {
            ((ConstraintLayout.b) layoutParams).f1363v0 = (c2.e) this.f1395d;
        }
    }

    public void setIds(String str) {
        this.f1397f = str;
        if (str == null) {
            return;
        }
        int i10 = 0;
        this.b = 0;
        while (true) {
            int indexOf = str.indexOf(44, i10);
            if (indexOf == -1) {
                d(str.substring(i10));
                return;
            } else {
                d(str.substring(i10, indexOf));
                i10 = indexOf + 1;
            }
        }
    }

    public void setReferenceTags(String str) {
        this.f1398g = str;
        if (str == null) {
            return;
        }
        int i10 = 0;
        this.b = 0;
        while (true) {
            int indexOf = str.indexOf(44, i10);
            if (indexOf == -1) {
                f(str.substring(i10));
                return;
            } else {
                f(str.substring(i10, indexOf));
                i10 = indexOf + 1;
            }
        }
    }

    public void setReferencedIds(int[] iArr) {
        this.f1397f = null;
        this.b = 0;
        for (int i10 : iArr) {
            e(i10);
        }
    }

    @Override // android.view.View
    public void setTag(int i10, Object obj) {
        super.setTag(i10, obj);
        if (obj == null && this.f1397f == null) {
            e(i10);
        }
    }

    public b(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.f1393a = new int[32];
        this.f1396e = false;
        this.f1399h = null;
        this.f1400i = new HashMap<>();
        this.f1394c = context;
        m(attributeSet);
    }
}
