package androidx.constraintlayout.widget;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.util.Log;
import android.util.SparseArray;
import android.util.SparseIntArray;
import android.view.View;
import android.view.ViewGroup;
import androidx.annotation.NonNull;
import backtraceio.library.services.BacktraceMetrics;
import c2.d;
import c2.e;
import c2.f;
import c2.h;
import c2.k;
import c2.l;
import com.appsflyer.share.attribution.RequestError;
import com.google.mlkit.common.MlKitException;
import com.google.mlkit.vision.barcode.common.Barcode;
import com.google.mlkit.vision.common.InputImage;
import d2.b;
import java.util.ArrayList;
import java.util.HashMap;
import y5.w;

/* loaded from: classes.dex */
public class ConstraintLayout extends ViewGroup {

    /* renamed from: y, reason: collision with root package name */
    public static g2.e f1296y;

    /* renamed from: a, reason: collision with root package name */
    public SparseArray<View> f1297a;
    public ArrayList<androidx.constraintlayout.widget.b> b;

    /* renamed from: c, reason: collision with root package name */
    public f f1298c;

    /* renamed from: d, reason: collision with root package name */
    public int f1299d;

    /* renamed from: e, reason: collision with root package name */
    public int f1300e;

    /* renamed from: f, reason: collision with root package name */
    public int f1301f;

    /* renamed from: g, reason: collision with root package name */
    public int f1302g;

    /* renamed from: h, reason: collision with root package name */
    public boolean f1303h;

    /* renamed from: i, reason: collision with root package name */
    public int f1304i;

    /* renamed from: j, reason: collision with root package name */
    public androidx.constraintlayout.widget.c f1305j;

    /* renamed from: k, reason: collision with root package name */
    public g2.a f1306k;

    /* renamed from: l, reason: collision with root package name */
    public int f1307l;

    /* renamed from: m, reason: collision with root package name */
    public HashMap<String, Integer> f1308m;

    /* renamed from: n, reason: collision with root package name */
    public int f1309n;

    /* renamed from: o, reason: collision with root package name */
    public int f1310o;

    /* renamed from: p, reason: collision with root package name */
    public int f1311p;

    /* renamed from: q, reason: collision with root package name */
    public int f1312q;

    /* renamed from: r, reason: collision with root package name */
    public int f1313r;

    /* renamed from: s, reason: collision with root package name */
    public int f1314s;

    /* renamed from: t, reason: collision with root package name */
    public SparseArray<c2.e> f1315t;

    /* renamed from: u, reason: collision with root package name */
    public c f1316u;

    /* renamed from: v, reason: collision with root package name */
    public int f1317v;

    /* renamed from: w, reason: collision with root package name */
    public int f1318w;

    /* renamed from: x, reason: collision with root package name */
    public ArrayList<d> f1319x;

    public static /* synthetic */ class a {

        /* renamed from: a, reason: collision with root package name */
        public static final /* synthetic */ int[] f1320a;

        static {
            int[] iArr = new int[e.b.values().length];
            f1320a = iArr;
            try {
                iArr[e.b.FIXED.ordinal()] = 1;
            } catch (NoSuchFieldError unused) {
            }
            try {
                f1320a[e.b.WRAP_CONTENT.ordinal()] = 2;
            } catch (NoSuchFieldError unused2) {
            }
            try {
                f1320a[e.b.MATCH_PARENT.ordinal()] = 3;
            } catch (NoSuchFieldError unused3) {
            }
            try {
                f1320a[e.b.MATCH_CONSTRAINT.ordinal()] = 4;
            } catch (NoSuchFieldError unused4) {
            }
        }
    }

    public class c implements d2.b.InterfaceC0208b {

        /* renamed from: a, reason: collision with root package name */
        public ConstraintLayout f1370a;
        public int b;

        /* renamed from: c, reason: collision with root package name */
        public int f1371c;

        /* renamed from: d, reason: collision with root package name */
        public int f1372d;

        /* renamed from: e, reason: collision with root package name */
        public int f1373e;

        /* renamed from: f, reason: collision with root package name */
        public int f1374f;

        /* renamed from: g, reason: collision with root package name */
        public int f1375g;

        public c(ConstraintLayout constraintLayout) {
            this.f1370a = constraintLayout;
        }

        @Override // d2.b.InterfaceC0208b
        public final void a() {
            int childCount = this.f1370a.getChildCount();
            for (int i10 = 0; i10 < childCount; i10++) {
                View childAt = this.f1370a.getChildAt(i10);
                if (childAt instanceof e) {
                    ((e) childAt).a(this.f1370a);
                }
            }
            int size = this.f1370a.b.size();
            if (size > 0) {
                for (int i11 = 0; i11 < size; i11++) {
                    ((androidx.constraintlayout.widget.b) this.f1370a.b.get(i11)).p(this.f1370a);
                }
            }
        }

        @Override // d2.b.InterfaceC0208b
        @SuppressLint({"WrongCall"})
        public final void b(c2.e eVar, d2.b.a aVar) {
            int makeMeasureSpec;
            int makeMeasureSpec2;
            int baseline;
            int max;
            int max2;
            int i10;
            if (eVar == null) {
                return;
            }
            if (eVar.V() == 8 && !eVar.j0()) {
                aVar.f11676e = 0;
                aVar.f11677f = 0;
                aVar.f11678g = 0;
                return;
            }
            if (eVar.K() == null) {
                return;
            }
            ConstraintLayout.b(ConstraintLayout.this);
            e.b bVar = aVar.f11673a;
            e.b bVar2 = aVar.b;
            int i11 = aVar.f11674c;
            int i12 = aVar.f11675d;
            int i13 = this.b + this.f1371c;
            int i14 = this.f1372d;
            View view = (View) eVar.s();
            int[] iArr = a.f1320a;
            int i15 = iArr[bVar.ordinal()];
            if (i15 == 1) {
                makeMeasureSpec = View.MeasureSpec.makeMeasureSpec(i11, 1073741824);
            } else if (i15 == 2) {
                makeMeasureSpec = ViewGroup.getChildMeasureSpec(this.f1374f, i14, -2);
            } else if (i15 == 3) {
                makeMeasureSpec = ViewGroup.getChildMeasureSpec(this.f1374f, i14 + eVar.B(), -1);
            } else if (i15 != 4) {
                makeMeasureSpec = 0;
            } else {
                makeMeasureSpec = ViewGroup.getChildMeasureSpec(this.f1374f, i14, -2);
                boolean z10 = eVar.f4696w == 1;
                int i16 = aVar.f11681j;
                if (i16 == d2.b.a.f11671l || i16 == d2.b.a.f11672m) {
                    boolean z11 = view.getMeasuredHeight() == eVar.x();
                    if (aVar.f11681j == d2.b.a.f11672m || !z10 || ((z10 && z11) || (view instanceof e) || eVar.n0())) {
                        makeMeasureSpec = View.MeasureSpec.makeMeasureSpec(eVar.W(), 1073741824);
                    }
                }
            }
            int i17 = iArr[bVar2.ordinal()];
            if (i17 == 1) {
                makeMeasureSpec2 = View.MeasureSpec.makeMeasureSpec(i12, 1073741824);
            } else if (i17 == 2) {
                makeMeasureSpec2 = ViewGroup.getChildMeasureSpec(this.f1375g, i13, -2);
            } else if (i17 == 3) {
                makeMeasureSpec2 = ViewGroup.getChildMeasureSpec(this.f1375g, i13 + eVar.U(), -1);
            } else if (i17 != 4) {
                makeMeasureSpec2 = 0;
            } else {
                makeMeasureSpec2 = ViewGroup.getChildMeasureSpec(this.f1375g, i13, -2);
                boolean z12 = eVar.f4698x == 1;
                int i18 = aVar.f11681j;
                if (i18 == d2.b.a.f11671l || i18 == d2.b.a.f11672m) {
                    boolean z13 = view.getMeasuredWidth() == eVar.W();
                    if (aVar.f11681j == d2.b.a.f11672m || !z12 || ((z12 && z13) || (view instanceof e) || eVar.o0())) {
                        makeMeasureSpec2 = View.MeasureSpec.makeMeasureSpec(eVar.x(), 1073741824);
                    }
                }
            }
            f fVar = (f) eVar.K();
            if (fVar != null && k.b(ConstraintLayout.this.f1304i, Barcode.FORMAT_QR_CODE) && view.getMeasuredWidth() == eVar.W() && view.getMeasuredWidth() < fVar.W() && view.getMeasuredHeight() == eVar.x() && view.getMeasuredHeight() < fVar.x() && view.getBaseline() == eVar.p() && !eVar.m0() && d(eVar.C(), makeMeasureSpec, eVar.W()) && d(eVar.D(), makeMeasureSpec2, eVar.x())) {
                aVar.f11676e = eVar.W();
                aVar.f11677f = eVar.x();
                aVar.f11678g = eVar.p();
                return;
            }
            e.b bVar3 = e.b.MATCH_CONSTRAINT;
            boolean z14 = bVar == bVar3;
            boolean z15 = bVar2 == bVar3;
            e.b bVar4 = e.b.MATCH_PARENT;
            boolean z16 = bVar2 == bVar4 || bVar2 == e.b.FIXED;
            boolean z17 = bVar == bVar4 || bVar == e.b.FIXED;
            boolean z18 = z14 && eVar.f4659d0 > 0.0f;
            boolean z19 = z15 && eVar.f4659d0 > 0.0f;
            if (view == null) {
                return;
            }
            b bVar5 = (b) view.getLayoutParams();
            int i19 = aVar.f11681j;
            if (i19 != d2.b.a.f11671l && i19 != d2.b.a.f11672m && z14 && eVar.f4696w == 0 && z15 && eVar.f4698x == 0) {
                i10 = -1;
                max2 = 0;
                baseline = 0;
                max = 0;
            } else {
                if ((view instanceof g2.f) && (eVar instanceof l)) {
                    ((g2.f) view).t((l) eVar, makeMeasureSpec, makeMeasureSpec2);
                } else {
                    view.measure(makeMeasureSpec, makeMeasureSpec2);
                }
                eVar.W0(makeMeasureSpec, makeMeasureSpec2);
                int measuredWidth = view.getMeasuredWidth();
                int measuredHeight = view.getMeasuredHeight();
                baseline = view.getBaseline();
                int i20 = eVar.f4702z;
                max = i20 > 0 ? Math.max(i20, measuredWidth) : measuredWidth;
                int i21 = eVar.A;
                if (i21 > 0) {
                    max = Math.min(i21, max);
                }
                int i22 = eVar.C;
                max2 = i22 > 0 ? Math.max(i22, measuredHeight) : measuredHeight;
                boolean z20 = z17;
                int i23 = eVar.D;
                if (i23 > 0) {
                    max2 = Math.min(i23, max2);
                }
                boolean z21 = z16;
                if (!k.b(ConstraintLayout.this.f1304i, 1)) {
                    if (z18 && z21) {
                        max = (int) ((max2 * eVar.f4659d0) + 0.5f);
                    } else if (z19 && z20) {
                        max2 = (int) ((max / eVar.f4659d0) + 0.5f);
                    }
                }
                if (measuredWidth != max || measuredHeight != max2) {
                    if (measuredWidth != max) {
                        makeMeasureSpec = View.MeasureSpec.makeMeasureSpec(max, 1073741824);
                    }
                    if (measuredHeight != max2) {
                        makeMeasureSpec2 = View.MeasureSpec.makeMeasureSpec(max2, 1073741824);
                    }
                    view.measure(makeMeasureSpec, makeMeasureSpec2);
                    eVar.W0(makeMeasureSpec, makeMeasureSpec2);
                    max = view.getMeasuredWidth();
                    max2 = view.getMeasuredHeight();
                    baseline = view.getBaseline();
                }
                i10 = -1;
            }
            boolean z22 = baseline != i10;
            aVar.f11680i = (max == aVar.f11674c && max2 == aVar.f11675d) ? false : true;
            if (bVar5.f1333g0) {
                z22 = true;
            }
            if (z22 && baseline != -1 && eVar.p() != baseline) {
                aVar.f11680i = true;
            }
            aVar.f11676e = max;
            aVar.f11677f = max2;
            aVar.f11679h = z22;
            aVar.f11678g = baseline;
            ConstraintLayout.b(ConstraintLayout.this);
        }

        public void c(int i10, int i11, int i12, int i13, int i14, int i15) {
            this.b = i12;
            this.f1371c = i13;
            this.f1372d = i14;
            this.f1373e = i15;
            this.f1374f = i10;
            this.f1375g = i11;
        }

        public final boolean d(int i10, int i11, int i12) {
            if (i10 == i11) {
                return true;
            }
            int mode = View.MeasureSpec.getMode(i10);
            int mode2 = View.MeasureSpec.getMode(i11);
            int size = View.MeasureSpec.getSize(i11);
            if (mode2 == 1073741824) {
                return (mode == Integer.MIN_VALUE || mode == 0) && i12 == size;
            }
            return false;
        }
    }

    public interface d {
        boolean a(int i10, int i11, int i12, View view, b bVar);
    }

    public ConstraintLayout(@NonNull Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.f1297a = new SparseArray<>();
        this.b = new ArrayList<>(4);
        this.f1298c = new f();
        this.f1299d = 0;
        this.f1300e = 0;
        this.f1301f = Integer.MAX_VALUE;
        this.f1302g = Integer.MAX_VALUE;
        this.f1303h = true;
        this.f1304i = 257;
        this.f1305j = null;
        this.f1306k = null;
        this.f1307l = -1;
        this.f1308m = new HashMap<>();
        this.f1309n = -1;
        this.f1310o = -1;
        this.f1311p = -1;
        this.f1312q = -1;
        this.f1313r = 0;
        this.f1314s = 0;
        this.f1315t = new SparseArray<>();
        this.f1316u = new c(this);
        this.f1317v = 0;
        this.f1318w = 0;
        s(attributeSet, 0, 0);
    }

    public static /* synthetic */ z1.e b(ConstraintLayout constraintLayout) {
        constraintLayout.getClass();
        return null;
    }

    private int getPaddingWidth() {
        int max = Math.max(0, getPaddingLeft()) + Math.max(0, getPaddingRight());
        int max2 = Math.max(0, getPaddingStart()) + Math.max(0, getPaddingEnd());
        return max2 > 0 ? max2 : max;
    }

    public static g2.e getSharedValues() {
        if (f1296y == null) {
            f1296y = new g2.e();
        }
        return f1296y;
    }

    private void s(AttributeSet attributeSet, int i10, int i11) {
        this.f1298c.C0(this);
        this.f1298c.X1(this.f1316u);
        this.f1297a.put(getId(), this);
        this.f1305j = null;
        if (attributeSet != null) {
            TypedArray obtainStyledAttributes = getContext().obtainStyledAttributes(attributeSet, g2.d.V0, i10, i11);
            int indexCount = obtainStyledAttributes.getIndexCount();
            for (int i12 = 0; i12 < indexCount; i12++) {
                int index = obtainStyledAttributes.getIndex(i12);
                if (index == g2.d.f17095f1) {
                    this.f1299d = obtainStyledAttributes.getDimensionPixelOffset(index, this.f1299d);
                } else if (index == g2.d.f17104g1) {
                    this.f1300e = obtainStyledAttributes.getDimensionPixelOffset(index, this.f1300e);
                } else if (index == g2.d.f17077d1) {
                    this.f1301f = obtainStyledAttributes.getDimensionPixelOffset(index, this.f1301f);
                } else if (index == g2.d.f17086e1) {
                    this.f1302g = obtainStyledAttributes.getDimensionPixelOffset(index, this.f1302g);
                } else if (index == g2.d.O2) {
                    this.f1304i = obtainStyledAttributes.getInt(index, this.f1304i);
                } else if (index == g2.d.J1) {
                    int resourceId = obtainStyledAttributes.getResourceId(index, 0);
                    if (resourceId != 0) {
                        try {
                            v(resourceId);
                        } catch (Resources.NotFoundException unused) {
                            this.f1306k = null;
                        }
                    }
                } else if (index == g2.d.f17167n1) {
                    int resourceId2 = obtainStyledAttributes.getResourceId(index, 0);
                    try {
                        androidx.constraintlayout.widget.c cVar = new androidx.constraintlayout.widget.c();
                        this.f1305j = cVar;
                        cVar.t(getContext(), resourceId2);
                    } catch (Resources.NotFoundException unused2) {
                        this.f1305j = null;
                    }
                    this.f1307l = resourceId2;
                }
            }
            obtainStyledAttributes.recycle();
        }
        this.f1298c.Y1(this.f1304i);
    }

    public void A(f fVar, int i10, int i11, int i12, int i13) {
        e.b bVar;
        c cVar = this.f1316u;
        int i14 = cVar.f1373e;
        int i15 = cVar.f1372d;
        e.b bVar2 = e.b.FIXED;
        int childCount = getChildCount();
        if (i10 == Integer.MIN_VALUE) {
            bVar = e.b.WRAP_CONTENT;
            if (childCount == 0) {
                i11 = Math.max(0, this.f1299d);
            }
        } else if (i10 == 0) {
            bVar = e.b.WRAP_CONTENT;
            if (childCount == 0) {
                i11 = Math.max(0, this.f1299d);
            }
            i11 = 0;
        } else if (i10 != 1073741824) {
            bVar = bVar2;
            i11 = 0;
        } else {
            i11 = Math.min(this.f1301f - i15, i11);
            bVar = bVar2;
        }
        if (i12 == Integer.MIN_VALUE) {
            bVar2 = e.b.WRAP_CONTENT;
            if (childCount == 0) {
                i13 = Math.max(0, this.f1300e);
            }
        } else if (i12 != 0) {
            if (i12 == 1073741824) {
                i13 = Math.min(this.f1302g - i14, i13);
            }
            i13 = 0;
        } else {
            bVar2 = e.b.WRAP_CONTENT;
            if (childCount == 0) {
                i13 = Math.max(0, this.f1300e);
            }
            i13 = 0;
        }
        if (i11 != fVar.W() || i13 != fVar.x()) {
            fVar.P1();
        }
        fVar.n1(0);
        fVar.o1(0);
        fVar.Y0(this.f1301f - i15);
        fVar.X0(this.f1302g - i14);
        fVar.b1(0);
        fVar.a1(0);
        fVar.Q0(bVar);
        fVar.l1(i11);
        fVar.h1(bVar2);
        fVar.M0(i13);
        fVar.b1(this.f1299d - i15);
        fVar.a1(this.f1300e - i14);
    }

    public final void B(c2.e eVar, b bVar, SparseArray<c2.e> sparseArray, int i10, d.a aVar) {
        View view = this.f1297a.get(i10);
        c2.e eVar2 = sparseArray.get(i10);
        if (eVar2 == null || view == null || !(view.getLayoutParams() instanceof b)) {
            return;
        }
        bVar.f1333g0 = true;
        d.a aVar2 = d.a.BASELINE;
        if (aVar == aVar2) {
            b bVar2 = (b) view.getLayoutParams();
            bVar2.f1333g0 = true;
            bVar2.f1363v0.L0(true);
        }
        eVar.o(aVar2).b(eVar2.o(aVar), bVar.D, bVar.C, true);
        eVar.L0(true);
        eVar.o(d.a.TOP).q();
        eVar.o(d.a.BOTTOM).q();
    }

    public final boolean C() {
        int childCount = getChildCount();
        boolean z10 = false;
        int i10 = 0;
        while (true) {
            if (i10 >= childCount) {
                break;
            }
            if (getChildAt(i10).isLayoutRequested()) {
                z10 = true;
                break;
            }
            i10++;
        }
        if (z10) {
            y();
        }
        return z10;
    }

    @Override // android.view.ViewGroup
    public boolean checkLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return layoutParams instanceof b;
    }

    @Override // android.view.ViewGroup, android.view.View
    public void dispatchDraw(Canvas canvas) {
        Object tag;
        int size;
        ArrayList<androidx.constraintlayout.widget.b> arrayList = this.b;
        if (arrayList != null && (size = arrayList.size()) > 0) {
            for (int i10 = 0; i10 < size; i10++) {
                this.b.get(i10).q(this);
            }
        }
        super.dispatchDraw(canvas);
        if (isInEditMode()) {
            float width = getWidth();
            float height = getHeight();
            int childCount = getChildCount();
            for (int i11 = 0; i11 < childCount; i11++) {
                View childAt = getChildAt(i11);
                if (childAt.getVisibility() != 8 && (tag = childAt.getTag()) != null && (tag instanceof String)) {
                    String[] split = ((String) tag).split(",");
                    if (split.length == 4) {
                        int parseInt = Integer.parseInt(split[0]);
                        int parseInt2 = Integer.parseInt(split[1]);
                        int parseInt3 = Integer.parseInt(split[2]);
                        int i12 = (int) ((parseInt / 1080.0f) * width);
                        int i13 = (int) ((parseInt2 / 1920.0f) * height);
                        Paint paint = new Paint();
                        paint.setColor(-65536);
                        float f10 = i12;
                        float f11 = i13;
                        float f12 = i12 + ((int) ((parseInt3 / 1080.0f) * width));
                        canvas.drawLine(f10, f11, f12, f11, paint);
                        float parseInt4 = i13 + ((int) ((Integer.parseInt(split[3]) / 1920.0f) * height));
                        canvas.drawLine(f12, f11, f12, parseInt4, paint);
                        canvas.drawLine(f12, parseInt4, f10, parseInt4, paint);
                        canvas.drawLine(f10, parseInt4, f10, f11, paint);
                        paint.setColor(-16711936);
                        canvas.drawLine(f10, f11, f12, parseInt4, paint);
                        canvas.drawLine(f10, parseInt4, f12, f11, paint);
                    }
                }
            }
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:85:0x0174  */
    /* JADX WARN: Removed duplicated region for block: B:88:0x017d  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public void e(boolean r15, android.view.View r16, c2.e r17, androidx.constraintlayout.widget.ConstraintLayout.b r18, android.util.SparseArray<c2.e> r19) {
        /*
            Method dump skipped, instructions count: 597
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.constraintlayout.widget.ConstraintLayout.e(boolean, android.view.View, c2.e, androidx.constraintlayout.widget.ConstraintLayout$b, android.util.SparseArray):void");
    }

    public boolean f(int i10, int i11) {
        if (this.f1319x == null) {
            return false;
        }
        int size = View.MeasureSpec.getSize(i10);
        int size2 = View.MeasureSpec.getSize(i11);
        ArrayList<d> arrayList = this.f1319x;
        int size3 = arrayList.size();
        boolean z10 = false;
        int i12 = 0;
        while (i12 < size3) {
            int i13 = i12 + 1;
            d dVar = arrayList.get(i12);
            ArrayList<c2.e> s12 = this.f1298c.s1();
            int size4 = s12.size();
            for (int i14 = 0; i14 < size4; i14++) {
                View view = (View) s12.get(i14).s();
                z10 |= dVar.a(size, size2, view.getId(), view, (b) view.getLayoutParams());
            }
            i12 = i13;
        }
        return z10;
    }

    @Override // android.view.View
    public void forceLayout() {
        u();
        super.forceLayout();
    }

    @Override // android.view.ViewGroup
    /* renamed from: g, reason: merged with bridge method [inline-methods] */
    public b generateDefaultLayoutParams() {
        return new b(-2, -2);
    }

    public int getMaxHeight() {
        return this.f1302g;
    }

    public int getMaxWidth() {
        return this.f1301f;
    }

    public int getMinHeight() {
        return this.f1300e;
    }

    public int getMinWidth() {
        return this.f1299d;
    }

    public int getOptimizationLevel() {
        return this.f1298c.L1();
    }

    public String getSceneString() {
        int id2;
        StringBuilder sb2 = new StringBuilder();
        if (this.f1298c.f4680o == null) {
            int id3 = getId();
            if (id3 != -1) {
                this.f1298c.f4680o = getContext().getResources().getResourceEntryName(id3);
            } else {
                this.f1298c.f4680o = "parent";
            }
        }
        if (this.f1298c.t() == null) {
            f fVar = this.f1298c;
            fVar.D0(fVar.f4680o);
            Log.v("ConstraintLayout", " setDebugName " + this.f1298c.t());
        }
        ArrayList<c2.e> s12 = this.f1298c.s1();
        int size = s12.size();
        int i10 = 0;
        while (i10 < size) {
            c2.e eVar = s12.get(i10);
            i10++;
            c2.e eVar2 = eVar;
            View view = (View) eVar2.s();
            if (view != null) {
                if (eVar2.f4680o == null && (id2 = view.getId()) != -1) {
                    eVar2.f4680o = getContext().getResources().getResourceEntryName(id2);
                }
                if (eVar2.t() == null) {
                    eVar2.D0(eVar2.f4680o);
                    Log.v("ConstraintLayout", " setDebugName " + eVar2.t());
                }
            }
        }
        this.f1298c.O(sb2);
        return sb2.toString();
    }

    @Override // android.view.ViewGroup
    /* renamed from: h, reason: merged with bridge method [inline-methods] */
    public b generateLayoutParams(AttributeSet attributeSet) {
        return new b(getContext(), attributeSet);
    }

    public Object l(int i10, Object obj) {
        if (i10 != 0 || !(obj instanceof String)) {
            return null;
        }
        String str = (String) obj;
        HashMap<String, Integer> hashMap = this.f1308m;
        if (hashMap == null || !hashMap.containsKey(str)) {
            return null;
        }
        return this.f1308m.get(str);
    }

    @Override // android.view.ViewGroup, android.view.View
    public void onLayout(boolean z10, int i10, int i11, int i12, int i13) {
        View content;
        int childCount = getChildCount();
        boolean isInEditMode = isInEditMode();
        for (int i14 = 0; i14 < childCount; i14++) {
            View childAt = getChildAt(i14);
            b bVar = (b) childAt.getLayoutParams();
            c2.e eVar = bVar.f1363v0;
            if ((childAt.getVisibility() != 8 || bVar.f1335h0 || bVar.f1337i0 || bVar.f1341k0 || isInEditMode) && !bVar.f1339j0) {
                int X = eVar.X();
                int Y = eVar.Y();
                int W = eVar.W() + X;
                int x5 = eVar.x() + Y;
                childAt.layout(X, Y, W, x5);
                if ((childAt instanceof e) && (content = ((e) childAt).getContent()) != null) {
                    content.setVisibility(0);
                    content.layout(X, Y, W, x5);
                }
            }
        }
        int size = this.b.size();
        if (size > 0) {
            for (int i15 = 0; i15 < size; i15++) {
                this.b.get(i15).o(this);
            }
        }
    }

    @Override // android.view.View
    public void onMeasure(int i10, int i11) {
        boolean f10 = this.f1303h | f(i10, i11);
        this.f1303h = f10;
        if (!f10) {
            int childCount = getChildCount();
            int i12 = 0;
            while (true) {
                if (i12 >= childCount) {
                    break;
                }
                if (getChildAt(i12).isLayoutRequested()) {
                    this.f1303h = true;
                    break;
                }
                i12++;
            }
        }
        this.f1317v = i10;
        this.f1318w = i11;
        this.f1298c.a2(t());
        if (this.f1303h) {
            this.f1303h = false;
            if (C()) {
                this.f1298c.c2();
            }
        }
        this.f1298c.J1(null);
        x(this.f1298c, this.f1304i, i10, i11);
        w(i10, i11, this.f1298c.W(), this.f1298c.x(), this.f1298c.S1(), this.f1298c.Q1());
    }

    @Override // android.view.ViewGroup
    public void onViewAdded(View view) {
        super.onViewAdded(view);
        c2.e r10 = r(view);
        if ((view instanceof Guideline) && !(r10 instanceof h)) {
            b bVar = (b) view.getLayoutParams();
            h hVar = new h();
            bVar.f1363v0 = hVar;
            bVar.f1335h0 = true;
            hVar.B1(bVar.Z);
        }
        if (view instanceof androidx.constraintlayout.widget.b) {
            androidx.constraintlayout.widget.b bVar2 = (androidx.constraintlayout.widget.b) view;
            bVar2.s();
            ((b) view.getLayoutParams()).f1337i0 = true;
            if (!this.b.contains(bVar2)) {
                this.b.add(bVar2);
            }
        }
        this.f1297a.put(view.getId(), view);
        this.f1303h = true;
    }

    @Override // android.view.ViewGroup
    public void onViewRemoved(View view) {
        super.onViewRemoved(view);
        this.f1297a.remove(view.getId());
        this.f1298c.u1(r(view));
        this.b.remove(view);
        this.f1303h = true;
    }

    public final c2.e p(int i10) {
        if (i10 == 0) {
            return this.f1298c;
        }
        View view = this.f1297a.get(i10);
        if (view == null && (view = findViewById(i10)) != null && view != this && view.getParent() == this) {
            onViewAdded(view);
        }
        if (view == this) {
            return this.f1298c;
        }
        if (view == null) {
            return null;
        }
        return ((b) view.getLayoutParams()).f1363v0;
    }

    public View q(int i10) {
        return this.f1297a.get(i10);
    }

    public final c2.e r(View view) {
        if (view == this) {
            return this.f1298c;
        }
        if (view == null) {
            return null;
        }
        if (view.getLayoutParams() instanceof b) {
            return ((b) view.getLayoutParams()).f1363v0;
        }
        view.setLayoutParams(generateLayoutParams(view.getLayoutParams()));
        if (view.getLayoutParams() instanceof b) {
            return ((b) view.getLayoutParams()).f1363v0;
        }
        return null;
    }

    @Override // android.view.View, android.view.ViewParent
    public void requestLayout() {
        u();
        super.requestLayout();
    }

    public void setConstraintSet(androidx.constraintlayout.widget.c cVar) {
        this.f1305j = cVar;
    }

    @Override // android.view.View
    public void setId(int i10) {
        this.f1297a.remove(getId());
        super.setId(i10);
        this.f1297a.put(getId(), this);
    }

    public void setMaxHeight(int i10) {
        if (i10 == this.f1302g) {
            return;
        }
        this.f1302g = i10;
        requestLayout();
    }

    public void setMaxWidth(int i10) {
        if (i10 == this.f1301f) {
            return;
        }
        this.f1301f = i10;
        requestLayout();
    }

    public void setMinHeight(int i10) {
        if (i10 == this.f1300e) {
            return;
        }
        this.f1300e = i10;
        requestLayout();
    }

    public void setMinWidth(int i10) {
        if (i10 == this.f1299d) {
            return;
        }
        this.f1299d = i10;
        requestLayout();
    }

    public void setOnConstraintsChanged(g2.b bVar) {
        g2.a aVar = this.f1306k;
        if (aVar != null) {
            aVar.c(bVar);
        }
    }

    public void setOptimizationLevel(int i10) {
        this.f1304i = i10;
        this.f1298c.Y1(i10);
    }

    @Override // android.view.ViewGroup
    public boolean shouldDelayChildPressedState() {
        return false;
    }

    public boolean t() {
        return (getContext().getApplicationInfo().flags & 4194304) != 0 && 1 == getLayoutDirection();
    }

    public final void u() {
        this.f1303h = true;
        this.f1309n = -1;
        this.f1310o = -1;
        this.f1311p = -1;
        this.f1312q = -1;
        this.f1313r = 0;
        this.f1314s = 0;
    }

    public void v(int i10) {
        this.f1306k = new g2.a(getContext(), this, i10);
    }

    public void w(int i10, int i11, int i12, int i13, boolean z10, boolean z11) {
        c cVar = this.f1316u;
        int i14 = cVar.f1373e;
        int resolveSizeAndState = View.resolveSizeAndState(i12 + cVar.f1372d, i10, 0);
        int resolveSizeAndState2 = View.resolveSizeAndState(i13 + i14, i11, 0) & 16777215;
        int min = Math.min(this.f1301f, resolveSizeAndState & 16777215);
        int min2 = Math.min(this.f1302g, resolveSizeAndState2);
        if (z10) {
            min |= 16777216;
        }
        if (z11) {
            min2 |= 16777216;
        }
        setMeasuredDimension(min, min2);
        this.f1309n = min;
        this.f1310o = min2;
    }

    public void x(f fVar, int i10, int i11, int i12) {
        int i13;
        int mode = View.MeasureSpec.getMode(i11);
        int size = View.MeasureSpec.getSize(i11);
        int mode2 = View.MeasureSpec.getMode(i12);
        int size2 = View.MeasureSpec.getSize(i12);
        int max = Math.max(0, getPaddingTop());
        int max2 = Math.max(0, getPaddingBottom());
        int i14 = max + max2;
        int paddingWidth = getPaddingWidth();
        this.f1316u.c(i11, i12, max, max2, paddingWidth, i14);
        int max3 = Math.max(0, getPaddingStart());
        int max4 = Math.max(0, getPaddingEnd());
        if (max3 <= 0 && max4 <= 0) {
            max3 = Math.max(0, getPaddingLeft());
        } else if (t()) {
            i13 = max4;
            int i15 = size - paddingWidth;
            int i16 = size2 - i14;
            A(fVar, mode, i15, mode2, i16);
            fVar.T1(i10, mode, i15, mode2, i16, this.f1309n, this.f1310o, i13, max);
        }
        i13 = max3;
        int i152 = size - paddingWidth;
        int i162 = size2 - i14;
        A(fVar, mode, i152, mode2, i162);
        fVar.T1(i10, mode, i152, mode2, i162, this.f1309n, this.f1310o, i13, max);
    }

    public final void y() {
        boolean isInEditMode = isInEditMode();
        int childCount = getChildCount();
        for (int i10 = 0; i10 < childCount; i10++) {
            c2.e r10 = r(getChildAt(i10));
            if (r10 != null) {
                r10.t0();
            }
        }
        if (isInEditMode) {
            for (int i11 = 0; i11 < childCount; i11++) {
                View childAt = getChildAt(i11);
                try {
                    String resourceName = getResources().getResourceName(childAt.getId());
                    z(0, resourceName, Integer.valueOf(childAt.getId()));
                    int indexOf = resourceName.indexOf(47);
                    if (indexOf != -1) {
                        resourceName = resourceName.substring(indexOf + 1);
                    }
                    p(childAt.getId()).D0(resourceName);
                } catch (Resources.NotFoundException unused) {
                }
            }
        }
        if (this.f1307l != -1) {
            for (int i12 = 0; i12 < childCount; i12++) {
                View childAt2 = getChildAt(i12);
                if (childAt2.getId() == this.f1307l && (childAt2 instanceof androidx.constraintlayout.widget.d)) {
                    this.f1305j = ((androidx.constraintlayout.widget.d) childAt2).getConstraintSet();
                }
            }
        }
        androidx.constraintlayout.widget.c cVar = this.f1305j;
        if (cVar != null) {
            cVar.d(this, true);
        }
        this.f1298c.v1();
        int size = this.b.size();
        if (size > 0) {
            for (int i13 = 0; i13 < size; i13++) {
                this.b.get(i13).r(this);
            }
        }
        for (int i14 = 0; i14 < childCount; i14++) {
            View childAt3 = getChildAt(i14);
            if (childAt3 instanceof e) {
                ((e) childAt3).b(this);
            }
        }
        this.f1315t.clear();
        this.f1315t.put(0, this.f1298c);
        this.f1315t.put(getId(), this.f1298c);
        for (int i15 = 0; i15 < childCount; i15++) {
            View childAt4 = getChildAt(i15);
            this.f1315t.put(childAt4.getId(), r(childAt4));
        }
        for (int i16 = 0; i16 < childCount; i16++) {
            View childAt5 = getChildAt(i16);
            c2.e r11 = r(childAt5);
            if (r11 != null) {
                b bVar = (b) childAt5.getLayoutParams();
                this.f1298c.a(r11);
                e(isInEditMode, childAt5, r11, bVar, this.f1315t);
            }
        }
    }

    public void z(int i10, Object obj, Object obj2) {
        if (i10 == 0 && (obj instanceof String) && (obj2 instanceof Integer)) {
            if (this.f1308m == null) {
                this.f1308m = new HashMap<>();
            }
            String str = (String) obj;
            int indexOf = str.indexOf("/");
            if (indexOf != -1) {
                str = str.substring(indexOf + 1);
            }
            this.f1308m.put(str, (Integer) obj2);
        }
    }

    @Override // android.view.ViewGroup
    public ViewGroup.LayoutParams generateLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return new b(layoutParams);
    }

    public ConstraintLayout(@NonNull Context context, AttributeSet attributeSet, int i10) {
        super(context, attributeSet, i10);
        this.f1297a = new SparseArray<>();
        this.b = new ArrayList<>(4);
        this.f1298c = new f();
        this.f1299d = 0;
        this.f1300e = 0;
        this.f1301f = Integer.MAX_VALUE;
        this.f1302g = Integer.MAX_VALUE;
        this.f1303h = true;
        this.f1304i = 257;
        this.f1305j = null;
        this.f1306k = null;
        this.f1307l = -1;
        this.f1308m = new HashMap<>();
        this.f1309n = -1;
        this.f1310o = -1;
        this.f1311p = -1;
        this.f1312q = -1;
        this.f1313r = 0;
        this.f1314s = 0;
        this.f1315t = new SparseArray<>();
        this.f1316u = new c(this);
        this.f1317v = 0;
        this.f1318w = 0;
        s(attributeSet, i10, 0);
    }

    public static class b extends ViewGroup.MarginLayoutParams {
        public int A;
        public int B;
        public int C;
        public int D;
        public boolean E;
        public boolean F;
        public float G;
        public float H;
        public String I;
        public float J;
        public int K;
        public float L;
        public float M;
        public int N;
        public int O;
        public int P;
        public int Q;
        public int R;
        public int S;
        public int T;
        public int U;
        public float V;
        public float W;
        public int X;
        public int Y;
        public int Z;

        /* renamed from: a, reason: collision with root package name */
        public int f1321a;

        /* renamed from: a0, reason: collision with root package name */
        public boolean f1322a0;
        public int b;

        /* renamed from: b0, reason: collision with root package name */
        public boolean f1323b0;

        /* renamed from: c, reason: collision with root package name */
        public float f1324c;

        /* renamed from: c0, reason: collision with root package name */
        public String f1325c0;

        /* renamed from: d, reason: collision with root package name */
        public boolean f1326d;

        /* renamed from: d0, reason: collision with root package name */
        public int f1327d0;

        /* renamed from: e, reason: collision with root package name */
        public int f1328e;

        /* renamed from: e0, reason: collision with root package name */
        public boolean f1329e0;

        /* renamed from: f, reason: collision with root package name */
        public int f1330f;

        /* renamed from: f0, reason: collision with root package name */
        public boolean f1331f0;

        /* renamed from: g, reason: collision with root package name */
        public int f1332g;

        /* renamed from: g0, reason: collision with root package name */
        public boolean f1333g0;

        /* renamed from: h, reason: collision with root package name */
        public int f1334h;

        /* renamed from: h0, reason: collision with root package name */
        public boolean f1335h0;

        /* renamed from: i, reason: collision with root package name */
        public int f1336i;

        /* renamed from: i0, reason: collision with root package name */
        public boolean f1337i0;

        /* renamed from: j, reason: collision with root package name */
        public int f1338j;

        /* renamed from: j0, reason: collision with root package name */
        public boolean f1339j0;

        /* renamed from: k, reason: collision with root package name */
        public int f1340k;

        /* renamed from: k0, reason: collision with root package name */
        public boolean f1341k0;

        /* renamed from: l, reason: collision with root package name */
        public int f1342l;

        /* renamed from: l0, reason: collision with root package name */
        public int f1343l0;

        /* renamed from: m, reason: collision with root package name */
        public int f1344m;

        /* renamed from: m0, reason: collision with root package name */
        public int f1345m0;

        /* renamed from: n, reason: collision with root package name */
        public int f1346n;

        /* renamed from: n0, reason: collision with root package name */
        public int f1347n0;

        /* renamed from: o, reason: collision with root package name */
        public int f1348o;

        /* renamed from: o0, reason: collision with root package name */
        public int f1349o0;

        /* renamed from: p, reason: collision with root package name */
        public int f1350p;

        /* renamed from: p0, reason: collision with root package name */
        public int f1351p0;

        /* renamed from: q, reason: collision with root package name */
        public int f1352q;

        /* renamed from: q0, reason: collision with root package name */
        public int f1353q0;

        /* renamed from: r, reason: collision with root package name */
        public float f1354r;

        /* renamed from: r0, reason: collision with root package name */
        public float f1355r0;

        /* renamed from: s, reason: collision with root package name */
        public int f1356s;

        /* renamed from: s0, reason: collision with root package name */
        public int f1357s0;

        /* renamed from: t, reason: collision with root package name */
        public int f1358t;

        /* renamed from: t0, reason: collision with root package name */
        public int f1359t0;

        /* renamed from: u, reason: collision with root package name */
        public int f1360u;

        /* renamed from: u0, reason: collision with root package name */
        public float f1361u0;

        /* renamed from: v, reason: collision with root package name */
        public int f1362v;

        /* renamed from: v0, reason: collision with root package name */
        public c2.e f1363v0;

        /* renamed from: w, reason: collision with root package name */
        public int f1364w;

        /* renamed from: w0, reason: collision with root package name */
        public boolean f1365w0;

        /* renamed from: x, reason: collision with root package name */
        public int f1366x;

        /* renamed from: y, reason: collision with root package name */
        public int f1367y;

        /* renamed from: z, reason: collision with root package name */
        public int f1368z;

        public static class a {

            /* renamed from: a, reason: collision with root package name */
            public static final SparseIntArray f1369a;

            static {
                SparseIntArray sparseIntArray = new SparseIntArray();
                f1369a = sparseIntArray;
                sparseIntArray.append(g2.d.f17265z2, 64);
                sparseIntArray.append(g2.d.f17069c2, 65);
                sparseIntArray.append(g2.d.f17150l2, 8);
                sparseIntArray.append(g2.d.f17159m2, 9);
                sparseIntArray.append(g2.d.f17177o2, 10);
                sparseIntArray.append(g2.d.f17186p2, 11);
                sparseIntArray.append(g2.d.f17235v2, 12);
                sparseIntArray.append(g2.d.f17227u2, 13);
                sparseIntArray.append(g2.d.S1, 14);
                sparseIntArray.append(g2.d.R1, 15);
                sparseIntArray.append(g2.d.N1, 16);
                sparseIntArray.append(g2.d.P1, 52);
                sparseIntArray.append(g2.d.O1, 53);
                sparseIntArray.append(g2.d.T1, 2);
                sparseIntArray.append(g2.d.V1, 3);
                sparseIntArray.append(g2.d.U1, 4);
                sparseIntArray.append(g2.d.E2, 49);
                sparseIntArray.append(g2.d.F2, 50);
                sparseIntArray.append(g2.d.Z1, 5);
                sparseIntArray.append(g2.d.f17052a2, 6);
                sparseIntArray.append(g2.d.f17060b2, 7);
                sparseIntArray.append(g2.d.I1, 67);
                sparseIntArray.append(g2.d.W0, 1);
                sparseIntArray.append(g2.d.f17195q2, 17);
                sparseIntArray.append(g2.d.f17203r2, 18);
                sparseIntArray.append(g2.d.Y1, 19);
                sparseIntArray.append(g2.d.X1, 20);
                sparseIntArray.append(g2.d.J2, 21);
                sparseIntArray.append(g2.d.M2, 22);
                sparseIntArray.append(g2.d.K2, 23);
                sparseIntArray.append(g2.d.H2, 24);
                sparseIntArray.append(g2.d.L2, 25);
                sparseIntArray.append(g2.d.I2, 26);
                sparseIntArray.append(g2.d.G2, 55);
                sparseIntArray.append(g2.d.N2, 54);
                sparseIntArray.append(g2.d.f17114h2, 29);
                sparseIntArray.append(g2.d.f17243w2, 30);
                sparseIntArray.append(g2.d.W1, 44);
                sparseIntArray.append(g2.d.f17132j2, 45);
                sparseIntArray.append(g2.d.f17257y2, 46);
                sparseIntArray.append(g2.d.f17123i2, 47);
                sparseIntArray.append(g2.d.f17250x2, 48);
                sparseIntArray.append(g2.d.L1, 27);
                sparseIntArray.append(g2.d.K1, 28);
                sparseIntArray.append(g2.d.A2, 31);
                sparseIntArray.append(g2.d.f17078d2, 32);
                sparseIntArray.append(g2.d.C2, 33);
                sparseIntArray.append(g2.d.B2, 34);
                sparseIntArray.append(g2.d.D2, 35);
                sparseIntArray.append(g2.d.f17096f2, 36);
                sparseIntArray.append(g2.d.f17087e2, 37);
                sparseIntArray.append(g2.d.f17105g2, 38);
                sparseIntArray.append(g2.d.f17141k2, 39);
                sparseIntArray.append(g2.d.f17219t2, 40);
                sparseIntArray.append(g2.d.f17168n2, 41);
                sparseIntArray.append(g2.d.Q1, 42);
                sparseIntArray.append(g2.d.M1, 43);
                sparseIntArray.append(g2.d.f17211s2, 51);
                sparseIntArray.append(g2.d.P2, 66);
            }
        }

        @SuppressLint({"ClassVerificationFailure"})
        public b(ViewGroup.LayoutParams layoutParams) {
            super(layoutParams);
            this.f1321a = -1;
            this.b = -1;
            this.f1324c = -1.0f;
            this.f1326d = true;
            this.f1328e = -1;
            this.f1330f = -1;
            this.f1332g = -1;
            this.f1334h = -1;
            this.f1336i = -1;
            this.f1338j = -1;
            this.f1340k = -1;
            this.f1342l = -1;
            this.f1344m = -1;
            this.f1346n = -1;
            this.f1348o = -1;
            this.f1350p = -1;
            this.f1352q = 0;
            this.f1354r = 0.0f;
            this.f1356s = -1;
            this.f1358t = -1;
            this.f1360u = -1;
            this.f1362v = -1;
            this.f1364w = Integer.MIN_VALUE;
            this.f1366x = Integer.MIN_VALUE;
            this.f1367y = Integer.MIN_VALUE;
            this.f1368z = Integer.MIN_VALUE;
            this.A = Integer.MIN_VALUE;
            this.B = Integer.MIN_VALUE;
            this.C = Integer.MIN_VALUE;
            this.D = 0;
            this.E = true;
            this.F = true;
            this.G = 0.5f;
            this.H = 0.5f;
            this.I = null;
            this.J = 0.0f;
            this.K = 1;
            this.L = -1.0f;
            this.M = -1.0f;
            this.N = 0;
            this.O = 0;
            this.P = 0;
            this.Q = 0;
            this.R = 0;
            this.S = 0;
            this.T = 0;
            this.U = 0;
            this.V = 1.0f;
            this.W = 1.0f;
            this.X = -1;
            this.Y = -1;
            this.Z = -1;
            this.f1322a0 = false;
            this.f1323b0 = false;
            this.f1325c0 = null;
            this.f1327d0 = 0;
            this.f1329e0 = true;
            this.f1331f0 = true;
            this.f1333g0 = false;
            this.f1335h0 = false;
            this.f1337i0 = false;
            this.f1339j0 = false;
            this.f1341k0 = false;
            this.f1343l0 = -1;
            this.f1345m0 = -1;
            this.f1347n0 = -1;
            this.f1349o0 = -1;
            this.f1351p0 = Integer.MIN_VALUE;
            this.f1353q0 = Integer.MIN_VALUE;
            this.f1355r0 = 0.5f;
            this.f1363v0 = new c2.e();
            this.f1365w0 = false;
            if (layoutParams instanceof ViewGroup.MarginLayoutParams) {
                ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) layoutParams;
                ((ViewGroup.MarginLayoutParams) this).leftMargin = marginLayoutParams.leftMargin;
                ((ViewGroup.MarginLayoutParams) this).rightMargin = marginLayoutParams.rightMargin;
                ((ViewGroup.MarginLayoutParams) this).topMargin = marginLayoutParams.topMargin;
                ((ViewGroup.MarginLayoutParams) this).bottomMargin = marginLayoutParams.bottomMargin;
                setMarginStart(marginLayoutParams.getMarginStart());
                setMarginEnd(marginLayoutParams.getMarginEnd());
            }
            if (layoutParams instanceof b) {
                b bVar = (b) layoutParams;
                this.f1321a = bVar.f1321a;
                this.b = bVar.b;
                this.f1324c = bVar.f1324c;
                this.f1326d = bVar.f1326d;
                this.f1328e = bVar.f1328e;
                this.f1330f = bVar.f1330f;
                this.f1332g = bVar.f1332g;
                this.f1334h = bVar.f1334h;
                this.f1336i = bVar.f1336i;
                this.f1338j = bVar.f1338j;
                this.f1340k = bVar.f1340k;
                this.f1342l = bVar.f1342l;
                this.f1344m = bVar.f1344m;
                this.f1346n = bVar.f1346n;
                this.f1348o = bVar.f1348o;
                this.f1350p = bVar.f1350p;
                this.f1352q = bVar.f1352q;
                this.f1354r = bVar.f1354r;
                this.f1356s = bVar.f1356s;
                this.f1358t = bVar.f1358t;
                this.f1360u = bVar.f1360u;
                this.f1362v = bVar.f1362v;
                this.f1364w = bVar.f1364w;
                this.f1366x = bVar.f1366x;
                this.f1367y = bVar.f1367y;
                this.f1368z = bVar.f1368z;
                this.A = bVar.A;
                this.B = bVar.B;
                this.C = bVar.C;
                this.D = bVar.D;
                this.G = bVar.G;
                this.H = bVar.H;
                this.I = bVar.I;
                this.J = bVar.J;
                this.K = bVar.K;
                this.L = bVar.L;
                this.M = bVar.M;
                this.N = bVar.N;
                this.O = bVar.O;
                this.f1322a0 = bVar.f1322a0;
                this.f1323b0 = bVar.f1323b0;
                this.P = bVar.P;
                this.Q = bVar.Q;
                this.R = bVar.R;
                this.T = bVar.T;
                this.S = bVar.S;
                this.U = bVar.U;
                this.V = bVar.V;
                this.W = bVar.W;
                this.X = bVar.X;
                this.Y = bVar.Y;
                this.Z = bVar.Z;
                this.f1329e0 = bVar.f1329e0;
                this.f1331f0 = bVar.f1331f0;
                this.f1333g0 = bVar.f1333g0;
                this.f1335h0 = bVar.f1335h0;
                this.f1343l0 = bVar.f1343l0;
                this.f1345m0 = bVar.f1345m0;
                this.f1347n0 = bVar.f1347n0;
                this.f1349o0 = bVar.f1349o0;
                this.f1351p0 = bVar.f1351p0;
                this.f1353q0 = bVar.f1353q0;
                this.f1355r0 = bVar.f1355r0;
                this.f1325c0 = bVar.f1325c0;
                this.f1327d0 = bVar.f1327d0;
                this.f1363v0 = bVar.f1363v0;
                this.E = bVar.E;
                this.F = bVar.F;
            }
        }

        public void a() {
            this.f1335h0 = false;
            this.f1329e0 = true;
            this.f1331f0 = true;
            int i10 = ((ViewGroup.MarginLayoutParams) this).width;
            if (i10 == -2 && this.f1322a0) {
                this.f1329e0 = false;
                if (this.P == 0) {
                    this.P = 1;
                }
            }
            int i11 = ((ViewGroup.MarginLayoutParams) this).height;
            if (i11 == -2 && this.f1323b0) {
                this.f1331f0 = false;
                if (this.Q == 0) {
                    this.Q = 1;
                }
            }
            if (i10 == 0 || i10 == -1) {
                this.f1329e0 = false;
                if (i10 == 0 && this.P == 1) {
                    ((ViewGroup.MarginLayoutParams) this).width = -2;
                    this.f1322a0 = true;
                }
            }
            if (i11 == 0 || i11 == -1) {
                this.f1331f0 = false;
                if (i11 == 0 && this.Q == 1) {
                    ((ViewGroup.MarginLayoutParams) this).height = -2;
                    this.f1323b0 = true;
                }
            }
            if (this.f1324c == -1.0f && this.f1321a == -1 && this.b == -1) {
                return;
            }
            this.f1335h0 = true;
            this.f1329e0 = true;
            this.f1331f0 = true;
            if (!(this.f1363v0 instanceof h)) {
                this.f1363v0 = new h();
            }
            ((h) this.f1363v0).B1(this.Z);
        }

        /* JADX WARN: Removed duplicated region for block: B:12:0x004a  */
        /* JADX WARN: Removed duplicated region for block: B:15:0x0051  */
        /* JADX WARN: Removed duplicated region for block: B:18:0x0058  */
        /* JADX WARN: Removed duplicated region for block: B:21:0x005e  */
        /* JADX WARN: Removed duplicated region for block: B:24:0x0064  */
        /* JADX WARN: Removed duplicated region for block: B:33:0x007a  */
        /* JADX WARN: Removed duplicated region for block: B:34:0x0082  */
        @Override // android.view.ViewGroup.MarginLayoutParams, android.view.ViewGroup.LayoutParams
        /*
            Code decompiled incorrectly, please refer to instructions dump.
            To view partially-correct add '--show-bad-code' argument
        */
        public void resolveLayoutDirection(int r11) {
            /*
                Method dump skipped, instructions count: 259
                To view this dump add '--comments-level debug' option
            */
            throw new UnsupportedOperationException("Method not decompiled: androidx.constraintlayout.widget.ConstraintLayout.b.resolveLayoutDirection(int):void");
        }

        public b(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
            this.f1321a = -1;
            this.b = -1;
            this.f1324c = -1.0f;
            this.f1326d = true;
            this.f1328e = -1;
            this.f1330f = -1;
            this.f1332g = -1;
            this.f1334h = -1;
            this.f1336i = -1;
            this.f1338j = -1;
            this.f1340k = -1;
            this.f1342l = -1;
            this.f1344m = -1;
            this.f1346n = -1;
            this.f1348o = -1;
            this.f1350p = -1;
            this.f1352q = 0;
            this.f1354r = 0.0f;
            this.f1356s = -1;
            this.f1358t = -1;
            this.f1360u = -1;
            this.f1362v = -1;
            this.f1364w = Integer.MIN_VALUE;
            this.f1366x = Integer.MIN_VALUE;
            this.f1367y = Integer.MIN_VALUE;
            this.f1368z = Integer.MIN_VALUE;
            this.A = Integer.MIN_VALUE;
            this.B = Integer.MIN_VALUE;
            this.C = Integer.MIN_VALUE;
            this.D = 0;
            this.E = true;
            this.F = true;
            this.G = 0.5f;
            this.H = 0.5f;
            this.I = null;
            this.J = 0.0f;
            this.K = 1;
            this.L = -1.0f;
            this.M = -1.0f;
            this.N = 0;
            this.O = 0;
            this.P = 0;
            this.Q = 0;
            this.R = 0;
            this.S = 0;
            this.T = 0;
            this.U = 0;
            this.V = 1.0f;
            this.W = 1.0f;
            this.X = -1;
            this.Y = -1;
            this.Z = -1;
            this.f1322a0 = false;
            this.f1323b0 = false;
            this.f1325c0 = null;
            this.f1327d0 = 0;
            this.f1329e0 = true;
            this.f1331f0 = true;
            this.f1333g0 = false;
            this.f1335h0 = false;
            this.f1337i0 = false;
            this.f1339j0 = false;
            this.f1341k0 = false;
            this.f1343l0 = -1;
            this.f1345m0 = -1;
            this.f1347n0 = -1;
            this.f1349o0 = -1;
            this.f1351p0 = Integer.MIN_VALUE;
            this.f1353q0 = Integer.MIN_VALUE;
            this.f1355r0 = 0.5f;
            this.f1363v0 = new c2.e();
            this.f1365w0 = false;
            TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, g2.d.V0);
            int indexCount = obtainStyledAttributes.getIndexCount();
            for (int i10 = 0; i10 < indexCount; i10++) {
                int index = obtainStyledAttributes.getIndex(i10);
                int i11 = a.f1369a.get(index);
                switch (i11) {
                    case 1:
                        this.Z = obtainStyledAttributes.getInt(index, this.Z);
                        break;
                    case 2:
                        int resourceId = obtainStyledAttributes.getResourceId(index, this.f1350p);
                        this.f1350p = resourceId;
                        if (resourceId == -1) {
                            this.f1350p = obtainStyledAttributes.getInt(index, -1);
                            break;
                        } else {
                            break;
                        }
                    case 3:
                        this.f1352q = obtainStyledAttributes.getDimensionPixelSize(index, this.f1352q);
                        break;
                    case 4:
                        float f10 = obtainStyledAttributes.getFloat(index, this.f1354r) % 360.0f;
                        this.f1354r = f10;
                        if (f10 < 0.0f) {
                            this.f1354r = (360.0f - f10) % 360.0f;
                            break;
                        } else {
                            break;
                        }
                    case 5:
                        this.f1321a = obtainStyledAttributes.getDimensionPixelOffset(index, this.f1321a);
                        break;
                    case 6:
                        this.b = obtainStyledAttributes.getDimensionPixelOffset(index, this.b);
                        break;
                    case 7:
                        this.f1324c = obtainStyledAttributes.getFloat(index, this.f1324c);
                        break;
                    case 8:
                        int resourceId2 = obtainStyledAttributes.getResourceId(index, this.f1328e);
                        this.f1328e = resourceId2;
                        if (resourceId2 == -1) {
                            this.f1328e = obtainStyledAttributes.getInt(index, -1);
                            break;
                        } else {
                            break;
                        }
                    case 9:
                        int resourceId3 = obtainStyledAttributes.getResourceId(index, this.f1330f);
                        this.f1330f = resourceId3;
                        if (resourceId3 == -1) {
                            this.f1330f = obtainStyledAttributes.getInt(index, -1);
                            break;
                        } else {
                            break;
                        }
                    case 10:
                        int resourceId4 = obtainStyledAttributes.getResourceId(index, this.f1332g);
                        this.f1332g = resourceId4;
                        if (resourceId4 == -1) {
                            this.f1332g = obtainStyledAttributes.getInt(index, -1);
                            break;
                        } else {
                            break;
                        }
                    case 11:
                        int resourceId5 = obtainStyledAttributes.getResourceId(index, this.f1334h);
                        this.f1334h = resourceId5;
                        if (resourceId5 == -1) {
                            this.f1334h = obtainStyledAttributes.getInt(index, -1);
                            break;
                        } else {
                            break;
                        }
                    case 12:
                        int resourceId6 = obtainStyledAttributes.getResourceId(index, this.f1336i);
                        this.f1336i = resourceId6;
                        if (resourceId6 == -1) {
                            this.f1336i = obtainStyledAttributes.getInt(index, -1);
                            break;
                        } else {
                            break;
                        }
                    case 13:
                        int resourceId7 = obtainStyledAttributes.getResourceId(index, this.f1338j);
                        this.f1338j = resourceId7;
                        if (resourceId7 == -1) {
                            this.f1338j = obtainStyledAttributes.getInt(index, -1);
                            break;
                        } else {
                            break;
                        }
                    case 14:
                        int resourceId8 = obtainStyledAttributes.getResourceId(index, this.f1340k);
                        this.f1340k = resourceId8;
                        if (resourceId8 == -1) {
                            this.f1340k = obtainStyledAttributes.getInt(index, -1);
                            break;
                        } else {
                            break;
                        }
                    case 15:
                        int resourceId9 = obtainStyledAttributes.getResourceId(index, this.f1342l);
                        this.f1342l = resourceId9;
                        if (resourceId9 == -1) {
                            this.f1342l = obtainStyledAttributes.getInt(index, -1);
                            break;
                        } else {
                            break;
                        }
                    case 16:
                        int resourceId10 = obtainStyledAttributes.getResourceId(index, this.f1344m);
                        this.f1344m = resourceId10;
                        if (resourceId10 == -1) {
                            this.f1344m = obtainStyledAttributes.getInt(index, -1);
                            break;
                        } else {
                            break;
                        }
                    case 17:
                        int resourceId11 = obtainStyledAttributes.getResourceId(index, this.f1356s);
                        this.f1356s = resourceId11;
                        if (resourceId11 == -1) {
                            this.f1356s = obtainStyledAttributes.getInt(index, -1);
                            break;
                        } else {
                            break;
                        }
                    case MlKitException.UNSUPPORTED /* 18 */:
                        int resourceId12 = obtainStyledAttributes.getResourceId(index, this.f1358t);
                        this.f1358t = resourceId12;
                        if (resourceId12 == -1) {
                            this.f1358t = obtainStyledAttributes.getInt(index, -1);
                            break;
                        } else {
                            break;
                        }
                    case 19:
                        int resourceId13 = obtainStyledAttributes.getResourceId(index, this.f1360u);
                        this.f1360u = resourceId13;
                        if (resourceId13 == -1) {
                            this.f1360u = obtainStyledAttributes.getInt(index, -1);
                            break;
                        } else {
                            break;
                        }
                    case w.f37552c /* 20 */:
                        int resourceId14 = obtainStyledAttributes.getResourceId(index, this.f1362v);
                        this.f1362v = resourceId14;
                        if (resourceId14 == -1) {
                            this.f1362v = obtainStyledAttributes.getInt(index, -1);
                            break;
                        } else {
                            break;
                        }
                    case 21:
                        this.f1364w = obtainStyledAttributes.getDimensionPixelSize(index, this.f1364w);
                        break;
                    case 22:
                        this.f1366x = obtainStyledAttributes.getDimensionPixelSize(index, this.f1366x);
                        break;
                    case 23:
                        this.f1367y = obtainStyledAttributes.getDimensionPixelSize(index, this.f1367y);
                        break;
                    case 24:
                        this.f1368z = obtainStyledAttributes.getDimensionPixelSize(index, this.f1368z);
                        break;
                    case 25:
                        this.A = obtainStyledAttributes.getDimensionPixelSize(index, this.A);
                        break;
                    case 26:
                        this.B = obtainStyledAttributes.getDimensionPixelSize(index, this.B);
                        break;
                    case 27:
                        this.f1322a0 = obtainStyledAttributes.getBoolean(index, this.f1322a0);
                        break;
                    case 28:
                        this.f1323b0 = obtainStyledAttributes.getBoolean(index, this.f1323b0);
                        break;
                    case 29:
                        this.G = obtainStyledAttributes.getFloat(index, this.G);
                        break;
                    case BacktraceMetrics.defaultTimeIntervalInMin /* 30 */:
                        this.H = obtainStyledAttributes.getFloat(index, this.H);
                        break;
                    case 31:
                        int i12 = obtainStyledAttributes.getInt(index, 0);
                        this.P = i12;
                        if (i12 == 1) {
                            Log.e("ConstraintLayout", "layout_constraintWidth_default=\"wrap\" is deprecated.\nUse layout_width=\"WRAP_CONTENT\" and layout_constrainedWidth=\"true\" instead.");
                            break;
                        } else {
                            break;
                        }
                    case Barcode.FORMAT_EAN_13 /* 32 */:
                        int i13 = obtainStyledAttributes.getInt(index, 0);
                        this.Q = i13;
                        if (i13 == 1) {
                            Log.e("ConstraintLayout", "layout_constraintHeight_default=\"wrap\" is deprecated.\nUse layout_height=\"WRAP_CONTENT\" and layout_constrainedHeight=\"true\" instead.");
                            break;
                        } else {
                            break;
                        }
                    case 33:
                        try {
                            this.R = obtainStyledAttributes.getDimensionPixelSize(index, this.R);
                            break;
                        } catch (Exception unused) {
                            if (obtainStyledAttributes.getInt(index, this.R) == -2) {
                                this.R = -2;
                                break;
                            } else {
                                break;
                            }
                        }
                    case 34:
                        try {
                            this.T = obtainStyledAttributes.getDimensionPixelSize(index, this.T);
                            break;
                        } catch (Exception unused2) {
                            if (obtainStyledAttributes.getInt(index, this.T) == -2) {
                                this.T = -2;
                                break;
                            } else {
                                break;
                            }
                        }
                    case InputImage.IMAGE_FORMAT_YUV_420_888 /* 35 */:
                        this.V = Math.max(0.0f, obtainStyledAttributes.getFloat(index, this.V));
                        this.P = 2;
                        break;
                    case 36:
                        try {
                            this.S = obtainStyledAttributes.getDimensionPixelSize(index, this.S);
                            break;
                        } catch (Exception unused3) {
                            if (obtainStyledAttributes.getInt(index, this.S) == -2) {
                                this.S = -2;
                                break;
                            } else {
                                break;
                            }
                        }
                    case 37:
                        try {
                            this.U = obtainStyledAttributes.getDimensionPixelSize(index, this.U);
                            break;
                        } catch (Exception unused4) {
                            if (obtainStyledAttributes.getInt(index, this.U) == -2) {
                                this.U = -2;
                                break;
                            } else {
                                break;
                            }
                        }
                    case 38:
                        this.W = Math.max(0.0f, obtainStyledAttributes.getFloat(index, this.W));
                        this.Q = 2;
                        break;
                    default:
                        switch (i11) {
                            case 44:
                                androidx.constraintlayout.widget.c.y(this, obtainStyledAttributes.getString(index));
                                break;
                            case 45:
                                this.L = obtainStyledAttributes.getFloat(index, this.L);
                                break;
                            case 46:
                                this.M = obtainStyledAttributes.getFloat(index, this.M);
                                break;
                            case 47:
                                this.N = obtainStyledAttributes.getInt(index, 0);
                                break;
                            case 48:
                                this.O = obtainStyledAttributes.getInt(index, 0);
                                break;
                            case 49:
                                this.X = obtainStyledAttributes.getDimensionPixelOffset(index, this.X);
                                break;
                            case RequestError.RESPONSE_CODE_FAILURE /* 50 */:
                                this.Y = obtainStyledAttributes.getDimensionPixelOffset(index, this.Y);
                                break;
                            case 51:
                                this.f1325c0 = obtainStyledAttributes.getString(index);
                                break;
                            case 52:
                                int resourceId15 = obtainStyledAttributes.getResourceId(index, this.f1346n);
                                this.f1346n = resourceId15;
                                if (resourceId15 == -1) {
                                    this.f1346n = obtainStyledAttributes.getInt(index, -1);
                                    break;
                                } else {
                                    break;
                                }
                            case 53:
                                int resourceId16 = obtainStyledAttributes.getResourceId(index, this.f1348o);
                                this.f1348o = resourceId16;
                                if (resourceId16 == -1) {
                                    this.f1348o = obtainStyledAttributes.getInt(index, -1);
                                    break;
                                } else {
                                    break;
                                }
                            case 54:
                                this.D = obtainStyledAttributes.getDimensionPixelSize(index, this.D);
                                break;
                            case 55:
                                this.C = obtainStyledAttributes.getDimensionPixelSize(index, this.C);
                                break;
                            default:
                                switch (i11) {
                                    case Barcode.FORMAT_EAN_8 /* 64 */:
                                        androidx.constraintlayout.widget.c.w(this, obtainStyledAttributes, index, 0);
                                        this.E = true;
                                        break;
                                    case 65:
                                        androidx.constraintlayout.widget.c.w(this, obtainStyledAttributes, index, 1);
                                        this.F = true;
                                        break;
                                    case 66:
                                        this.f1327d0 = obtainStyledAttributes.getInt(index, this.f1327d0);
                                        break;
                                    case 67:
                                        this.f1326d = obtainStyledAttributes.getBoolean(index, this.f1326d);
                                        break;
                                }
                        }
                }
            }
            obtainStyledAttributes.recycle();
            a();
        }

        public b(int i10, int i11) {
            super(i10, i11);
            this.f1321a = -1;
            this.b = -1;
            this.f1324c = -1.0f;
            this.f1326d = true;
            this.f1328e = -1;
            this.f1330f = -1;
            this.f1332g = -1;
            this.f1334h = -1;
            this.f1336i = -1;
            this.f1338j = -1;
            this.f1340k = -1;
            this.f1342l = -1;
            this.f1344m = -1;
            this.f1346n = -1;
            this.f1348o = -1;
            this.f1350p = -1;
            this.f1352q = 0;
            this.f1354r = 0.0f;
            this.f1356s = -1;
            this.f1358t = -1;
            this.f1360u = -1;
            this.f1362v = -1;
            this.f1364w = Integer.MIN_VALUE;
            this.f1366x = Integer.MIN_VALUE;
            this.f1367y = Integer.MIN_VALUE;
            this.f1368z = Integer.MIN_VALUE;
            this.A = Integer.MIN_VALUE;
            this.B = Integer.MIN_VALUE;
            this.C = Integer.MIN_VALUE;
            this.D = 0;
            this.E = true;
            this.F = true;
            this.G = 0.5f;
            this.H = 0.5f;
            this.I = null;
            this.J = 0.0f;
            this.K = 1;
            this.L = -1.0f;
            this.M = -1.0f;
            this.N = 0;
            this.O = 0;
            this.P = 0;
            this.Q = 0;
            this.R = 0;
            this.S = 0;
            this.T = 0;
            this.U = 0;
            this.V = 1.0f;
            this.W = 1.0f;
            this.X = -1;
            this.Y = -1;
            this.Z = -1;
            this.f1322a0 = false;
            this.f1323b0 = false;
            this.f1325c0 = null;
            this.f1327d0 = 0;
            this.f1329e0 = true;
            this.f1331f0 = true;
            this.f1333g0 = false;
            this.f1335h0 = false;
            this.f1337i0 = false;
            this.f1339j0 = false;
            this.f1341k0 = false;
            this.f1343l0 = -1;
            this.f1345m0 = -1;
            this.f1347n0 = -1;
            this.f1349o0 = -1;
            this.f1351p0 = Integer.MIN_VALUE;
            this.f1353q0 = Integer.MIN_VALUE;
            this.f1355r0 = 0.5f;
            this.f1363v0 = new c2.e();
            this.f1365w0 = false;
        }
    }


    // --- восстановлено из DEX (androidx/constraintlayout/widget/ConstraintLayout$b$a) ---
    public static class a {
        android.util.SparseIntArray a;
    }
}
