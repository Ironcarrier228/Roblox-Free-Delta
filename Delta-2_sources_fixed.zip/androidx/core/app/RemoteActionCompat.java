package androidx.core.app;

import android.app.PendingIntent;
import androidx.core.graphics.drawable.IconCompat;
import r5.c;

/* loaded from: classes.dex */
public final class RemoteActionCompat implements c {

    /* renamed from: a, reason: collision with root package name */
    public IconCompat f1553a;
    public CharSequence b;

    /* renamed from: c, reason: collision with root package name */
    public CharSequence f1554c;

    /* renamed from: d, reason: collision with root package name */
    public PendingIntent f1555d;

    /* renamed from: e, reason: collision with root package name */
    public boolean f1556e;

    /* renamed from: f, reason: collision with root package name */
    public boolean f1557f;
}
