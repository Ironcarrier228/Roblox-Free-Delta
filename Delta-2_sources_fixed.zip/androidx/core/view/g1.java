package androidx.core.view;

/* loaded from: classes.dex */
public final /* synthetic */ class g1 {
    public static /* synthetic */ void a() {
    }
}
