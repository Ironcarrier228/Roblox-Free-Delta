package androidx.core.google.shortcuts;

import android.content.Context;
import android.os.PersistableBundle;
import androidx.annotation.NonNull;
import androidx.core.graphics.drawable.IconCompat;
import com.github.luben.zstd.BuildConfig;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import m2.b;
import m2.c;
import re.p;
import w8.a;
import w8.g;
import w8.h;

/* loaded from: classes.dex */
public class ShortcutInfoChangeListenerImpl extends b {

    /* renamed from: a, reason: collision with root package name */
    public final Context f1559a;
    public final w8.b b;

    /* renamed from: c, reason: collision with root package name */
    public final h f1560c;

    /* renamed from: d, reason: collision with root package name */
    public final p f1561d;

    public static class a {
        @NonNull
        public static o2.a a(@NonNull String str, PersistableBundle persistableBundle) {
            String[] stringArray;
            o2.a g10 = new o2.a().g(str);
            if (persistableBundle != null && (stringArray = persistableBundle.getStringArray(str)) != null) {
                ArrayList arrayList = new ArrayList();
                for (String str2 : stringArray) {
                    o2.b g11 = new o2.b().g(str2);
                    String[] stringArray2 = persistableBundle.getStringArray(str + "/" + str2);
                    if (stringArray2 != null && stringArray2.length != 0) {
                        g11.l(stringArray2);
                        arrayList.add(g11);
                    }
                }
                if (arrayList.size() > 0) {
                    g10.l((o2.b[]) arrayList.toArray(new o2.b[0]));
                }
            }
            return g10;
        }
    }

    public ShortcutInfoChangeListenerImpl(Context context, w8.b bVar, h hVar, p pVar) {
        this.f1559a = context;
        this.b = bVar;
        this.f1560c = hVar;
        this.f1561d = pVar;
    }

    @NonNull
    public static ShortcutInfoChangeListenerImpl getInstance(@NonNull Context context) {
        return new ShortcutInfoChangeListenerImpl(context, w8.b.a(context), h.b(context), p2.a.c(context));
    }

    @Override // m2.b
    public void a() {
        this.b.b();
    }

    @Override // m2.b
    public void b(@NonNull List<c> list) {
        ArrayList arrayList = new ArrayList();
        Iterator<c> it = list.iterator();
        while (it.hasNext()) {
            arrayList.add(e(it.next()).a());
        }
        this.b.c((g[]) arrayList.toArray(new g[0]));
    }

    @Override // m2.b
    public void c(@NonNull List<String> list) {
        Iterator<String> it = list.iterator();
        while (it.hasNext()) {
            this.f1560c.a(d(p2.a.b(this.f1559a, it.next())));
        }
    }

    @NonNull
    public final w8.a d(@NonNull String str) {
        return new w8.a.C0735a("ViewAction").b(BuildConfig.FLAVOR, str).a();
    }

    @NonNull
    public final o2.c e(@NonNull c cVar) {
        String b = p2.a.b(this.f1559a, cVar.f());
        o2.c o10 = new o2.c().e(cVar.f()).h(b).n(cVar.m().toString()).o(p2.a.a(this.f1559a, cVar.g(), this.f1561d));
        if (cVar.j() != null) {
            o10.m(cVar.j().toString());
        }
        if (cVar.c() != null) {
            ArrayList arrayList = new ArrayList();
            for (String str : cVar.c()) {
                if (p2.a.d(str)) {
                    arrayList.add(w8.a.a(str, cVar.d()));
                }
            }
            if (!arrayList.isEmpty()) {
                o10.l((o2.a[]) arrayList.toArray(new o2.a[0]));
            }
        }
        if (cVar.e() != null) {
            IconCompat e10 = cVar.e();
            if (e10.i() == 6 || e10.i() == 4) {
                o10.f(e10.j().toString());
            }
        }
        return o10;
    }
}
