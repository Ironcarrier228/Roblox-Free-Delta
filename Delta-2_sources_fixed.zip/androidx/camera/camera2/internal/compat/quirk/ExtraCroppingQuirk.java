package androidx.camera.camera2.internal.compat.quirk;

import android.os.Build;
import android.util.Range;
import android.util.Size;
import com.appsflyer.sdk_base.referrer.Payload;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import n0.SurfaceConfig;
import n0.g3;

/* loaded from: classes.dex */
public class ExtraCroppingQuirk implements g3 {

    /* renamed from: a, reason: collision with root package name */
    public static final Map<String, Range<Integer>> f1132a;

    public static /* synthetic */ class a {

        /* renamed from: a, reason: collision with root package name */
        public static final /* synthetic */ int[] f1133a;

        static {
            int[] iArr = new int[SurfaceConfig.d.values().length];
            f1133a = iArr;
            try {
                iArr[SurfaceConfig.d.f25225a.ordinal()] = 1;
            } catch (NoSuchFieldError unused) {
            }
            try {
                f1133a[SurfaceConfig.d.b.ordinal()] = 2;
            } catch (NoSuchFieldError unused2) {
            }
            try {
                f1133a[SurfaceConfig.d.f25226c.ordinal()] = 3;
            } catch (NoSuchFieldError unused3) {
            }
        }
    }

    static {
        HashMap hashMap = new HashMap();
        f1132a = hashMap;
        hashMap.put("SM-T580", null);
        hashMap.put("SM-J710MN", new Range(21, 26));
        hashMap.put("SM-A320FL", null);
        hashMap.put("SM-G570M", null);
        hashMap.put("SM-G610F", null);
        hashMap.put("SM-G610M", new Range(21, 26));
    }

    public static boolean h() {
        if (!Payload.SOURCE_SAMSUNG.equalsIgnoreCase(Build.BRAND)) {
            return false;
        }
        Map<String, Range<Integer>> map = f1132a;
        String str = Build.MODEL;
        Locale locale = Locale.US;
        if (!map.containsKey(str.toUpperCase(locale))) {
            return false;
        }
        Range<Integer> range = map.get(str.toUpperCase(locale));
        if (range == null) {
            return true;
        }
        return range.contains((Range<Integer>) Integer.valueOf(Build.VERSION.SDK_INT));
    }

    public static boolean i() {
        return h();
    }

    public Size g(SurfaceConfig.d dVar) {
        if (!h()) {
            return null;
        }
        int i10 = a.f1133a[dVar.ordinal()];
        if (i10 == 1) {
            return new Size(1920, 1080);
        }
        if (i10 == 2) {
            return new Size(1280, 720);
        }
        if (i10 != 3) {
            return null;
        }
        return new Size(3264, 1836);
    }
}
