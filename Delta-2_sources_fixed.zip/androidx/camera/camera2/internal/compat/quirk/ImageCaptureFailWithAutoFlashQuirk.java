package androidx.camera.camera2.internal.compat.quirk;

import a0.c0;
import android.hardware.camera2.CameraCharacteristics;
import android.os.Build;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import n0.g3;

/* loaded from: classes.dex */
public class ImageCaptureFailWithAutoFlashQuirk implements g3 {

    /* renamed from: a, reason: collision with root package name */
    public static final List<String> f1139a = Arrays.asList("sm-j700f", "sm-j710f");

    public static boolean g(c0 c0Var) {
        return f1139a.contains(Build.MODEL.toLowerCase(Locale.US)) && ((Integer) c0Var.a(CameraCharacteristics.LENS_FACING)).intValue() == 0;
    }
}
