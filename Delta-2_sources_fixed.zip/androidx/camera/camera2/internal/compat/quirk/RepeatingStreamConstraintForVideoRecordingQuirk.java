package androidx.camera.camera2.internal.compat.quirk;

import android.os.Build;
import n0.g3;

/* loaded from: classes.dex */
public class RepeatingStreamConstraintForVideoRecordingQuirk implements g3 {
    public static boolean g() {
        return "Huawei".equalsIgnoreCase(Build.BRAND) && "mha-l29".equalsIgnoreCase(Build.MODEL);
    }

    public static boolean h() {
        return g();
    }
}
