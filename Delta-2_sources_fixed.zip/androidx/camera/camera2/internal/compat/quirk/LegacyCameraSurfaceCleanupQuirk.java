package androidx.camera.camera2.internal.compat.quirk;

import a0.c0;
import android.hardware.camera2.CameraCharacteristics;
import android.os.Build;
import n0.g3;

/* loaded from: classes.dex */
public class LegacyCameraSurfaceCleanupQuirk implements g3 {
    public static boolean g(c0 c0Var) {
        Integer num = (Integer) c0Var.a(CameraCharacteristics.INFO_SUPPORTED_HARDWARE_LEVEL);
        return num != null && num.intValue() == 2;
    }

    public static boolean h(c0 c0Var) {
        return Build.VERSION.SDK_INT < 29 && g(c0Var);
    }
}
