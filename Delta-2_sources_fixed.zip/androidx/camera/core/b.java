package androidx.camera.core;

import android.graphics.Rect;
import android.media.Image;
import androidx.camera.core.d;
import g0.i1;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

/* loaded from: classes.dex */
public abstract class b implements d {
    public final d b;

    /* renamed from: a, reason: collision with root package name */
    public final Object f1169a = new Object();

    /* renamed from: c, reason: collision with root package name */
    public final Set<a> f1170c = new HashSet();

    public interface a {
        void a(d dVar);
    }

    public b(d dVar) {
        this.b = dVar;
    }

    @Override // androidx.camera.core.d
    public d.a[] H1() {
        return this.b.H1();
    }

    @Override // androidx.camera.core.d
    public i1 L2() {
        return this.b.L2();
    }

    @Override // androidx.camera.core.d
    public void N0(Rect rect) {
        this.b.N0(rect);
    }

    public void a(a aVar) {
        synchronized (this.f1169a) {
            this.f1170c.add(aVar);
        }
    }

    public void b() {
        HashSet hashSet;
        synchronized (this.f1169a) {
            hashSet = new HashSet(this.f1170c);
        }
        Iterator it = hashSet.iterator();
        while (it.hasNext()) {
            ((a) it.next()).a(this);
        }
    }

    @Override // androidx.camera.core.d, java.lang.AutoCloseable
    public void close() {
        this.b.close();
        b();
    }

    @Override // androidx.camera.core.d
    public int getFormat() {
        return this.b.getFormat();
    }

    @Override // androidx.camera.core.d
    public int getHeight() {
        return this.b.getHeight();
    }

    @Override // androidx.camera.core.d
    public int getWidth() {
        return this.b.getWidth();
    }

    @Override // androidx.camera.core.d
    public Image q() {
        return this.b.q();
    }
}
