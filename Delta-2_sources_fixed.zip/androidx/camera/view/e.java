package androidx.camera.view;

import android.graphics.Bitmap;
import android.graphics.SurfaceTexture;
import android.util.Size;
import android.view.Surface;
import android.view.TextureView;
import android.view.View;
import android.widget.FrameLayout;
import androidx.camera.view.c;
import g0.r1;
import g0.v2;
import java.util.Objects;
import java.util.concurrent.Executor;
import java.util.concurrent.atomic.AtomicReference;
import pe.x;
import r0.n;
import x2.g;
import y1.c;

/* loaded from: classes.dex */
public final class e extends c {

    /* renamed from: e, reason: collision with root package name */
    public TextureView f1272e;

    /* renamed from: f, reason: collision with root package name */
    public SurfaceTexture f1273f;

    /* renamed from: g, reason: collision with root package name */
    public x<v2.g> f1274g;

    /* renamed from: h, reason: collision with root package name */
    public v2 f1275h;

    /* renamed from: i, reason: collision with root package name */
    public boolean f1276i;

    /* renamed from: j, reason: collision with root package name */
    public SurfaceTexture f1277j;

    /* renamed from: k, reason: collision with root package name */
    public AtomicReference<c.a<Void>> f1278k;

    /* renamed from: l, reason: collision with root package name */
    public c.a f1279l;

    /* renamed from: m, reason: collision with root package name */
    public Executor f1280m;

    public class a implements TextureView.SurfaceTextureListener {

        /* renamed from: androidx.camera.view.e$a$a, reason: collision with other inner class name */
        public class C0029a implements r0.c<v2.g> {

            /* renamed from: a, reason: collision with root package name */
            public final /* synthetic */ SurfaceTexture f1282a;

            public C0029a(SurfaceTexture surfaceTexture) {
                this.f1282a = surfaceTexture;
            }

            @Override // r0.c
            /* renamed from: a, reason: merged with bridge method [inline-methods] */
            public void onSuccess(v2.g gVar) {
                g.j(gVar.a() != 3, "Unexpected result from SurfaceRequest. Surface was provided twice.");
                r1.a("TextureViewImpl", "SurfaceTexture about to manually be destroyed");
                this.f1282a.release();
                e eVar = e.this;
                if (eVar.f1277j != null) {
                    eVar.f1277j = null;
                }
            }

            @Override // r0.c
            public void onFailure(Throwable th2) {
                throw new IllegalStateException("SurfaceReleaseFuture did not complete nicely.", th2);
            }
        }

        public a() {
        }

        @Override // android.view.TextureView.SurfaceTextureListener
        public void onSurfaceTextureAvailable(SurfaceTexture surfaceTexture, int i10, int i11) {
            r1.a("TextureViewImpl", "SurfaceTexture available. Size: " + i10 + "x" + i11);
            e eVar = e.this;
            eVar.f1273f = surfaceTexture;
            if (eVar.f1274g == null) {
                eVar.q();
                return;
            }
            g.g(eVar.f1275h);
            r1.a("TextureViewImpl", "Surface invalidated " + e.this.f1275h);
            e.this.f1275h.n().d();
        }

        @Override // android.view.TextureView.SurfaceTextureListener
        public boolean onSurfaceTextureDestroyed(SurfaceTexture surfaceTexture) {
            e eVar = e.this;
            eVar.f1273f = null;
            x<v2.g> xVar = eVar.f1274g;
            if (xVar == null) {
                r1.a("TextureViewImpl", "SurfaceTexture about to be destroyed");
                return true;
            }
            n.j(xVar, new C0029a(surfaceTexture), l2.b.i(e.this.f1272e.getContext()));
            e.this.f1277j = surfaceTexture;
            return false;
        }

        @Override // android.view.TextureView.SurfaceTextureListener
        public void onSurfaceTextureSizeChanged(SurfaceTexture surfaceTexture, int i10, int i11) {
            r1.a("TextureViewImpl", "SurfaceTexture size changed: " + i10 + "x" + i11);
        }

        @Override // android.view.TextureView.SurfaceTextureListener
        public void onSurfaceTextureUpdated(SurfaceTexture surfaceTexture) {
            c.a<Void> andSet = e.this.f1278k.getAndSet(null);
            if (andSet != null) {
                andSet.c(null);
            }
            e.this.getClass();
            Executor executor = e.this.f1280m;
        }
    }

    public e(FrameLayout frameLayout, b bVar) {
        super(frameLayout, bVar);
        this.f1276i = false;
        this.f1278k = new AtomicReference<>();
    }

    public static /* synthetic */ Object j(e eVar, Surface surface, final c.a aVar) {
        eVar.getClass();
        r1.a("TextureViewImpl", "Surface set on Preview.");
        v2 v2Var = eVar.f1275h;
        Executor b = q0.c.b();
        Objects.requireNonNull(aVar);
        v2Var.w(surface, b, new x2.a() { // from class: p1.p0
            @Override // x2.a
            public final void accept(Object obj) {
                c.a.this.c((v2.g) obj);
            }
        });
        return "provideSurface[request=" + eVar.f1275h + " surface=" + surface + "]";
    }

    public static /* synthetic */ void k(e eVar, Surface surface, x xVar, v2 v2Var) {
        eVar.getClass();
        r1.a("TextureViewImpl", "Safe to release surface.");
        eVar.o();
        surface.release();
        if (eVar.f1274g == xVar) {
            eVar.f1274g = null;
        }
        if (eVar.f1275h == v2Var) {
            eVar.f1275h = null;
        }
    }

    public static /* synthetic */ void l(e eVar, v2 v2Var) {
        v2 v2Var2 = eVar.f1275h;
        if (v2Var2 != null && v2Var2 == v2Var) {
            eVar.f1275h = null;
            eVar.f1274g = null;
        }
        eVar.o();
    }

    public static /* synthetic */ Object m(e eVar, c.a aVar) {
        eVar.f1278k.set(aVar);
        return "textureViewImpl_waitForNextFrame";
    }

    @Override // androidx.camera.view.c
    public View b() {
        return this.f1272e;
    }

    @Override // androidx.camera.view.c
    public Bitmap c() {
        TextureView textureView = this.f1272e;
        if (textureView == null || !textureView.isAvailable()) {
            return null;
        }
        return this.f1272e.getBitmap();
    }

    @Override // androidx.camera.view.c
    public void d() {
        p();
    }

    @Override // androidx.camera.view.c
    public void e() {
        this.f1276i = true;
    }

    @Override // androidx.camera.view.c
    public void g(final v2 v2Var, c.a aVar) {
        this.f1260a = v2Var.q();
        n();
        v2 v2Var2 = this.f1275h;
        if (v2Var2 != null && v2Var2.z()) {
            o();
        }
        this.f1275h = v2Var;
        this.f1279l = aVar;
        v2Var.k(l2.b.i(this.f1272e.getContext()), new Runnable() { // from class: p1.l0
            @Override // java.lang.Runnable
            public final void run() {
                androidx.camera.view.e.l(androidx.camera.view.e.this, v2Var);
            }
        });
        q();
    }

    @Override // androidx.camera.view.c
    public x<Void> i() {
        return y1.c.a(new c.InterfaceC0761c() { // from class: p1.m0
            @Override // y1.c.InterfaceC0761c
            public final Object a(c.a aVar) {
                return androidx.camera.view.e.m(androidx.camera.view.e.this, aVar);
            }
        });
    }

    public void n() {
        g.g(this.b);
        g.g(this.f1260a);
        TextureView textureView = new TextureView(this.b.getContext());
        this.f1272e = textureView;
        textureView.setLayoutParams(new FrameLayout.LayoutParams(this.f1260a.getWidth(), this.f1260a.getHeight()));
        this.f1272e.setSurfaceTextureListener(new a());
        this.b.removeAllViews();
        this.b.addView(this.f1272e);
    }

    public final void o() {
        c.a aVar = this.f1279l;
        if (aVar != null) {
            aVar.a();
            this.f1279l = null;
        }
    }

    public final void p() {
        if (!this.f1276i || this.f1277j == null) {
            return;
        }
        SurfaceTexture surfaceTexture = this.f1272e.getSurfaceTexture();
        SurfaceTexture surfaceTexture2 = this.f1277j;
        if (surfaceTexture != surfaceTexture2) {
            this.f1272e.setSurfaceTexture(surfaceTexture2);
            this.f1277j = null;
            this.f1276i = false;
        }
    }

    public void q() {
        SurfaceTexture surfaceTexture;
        Size size = this.f1260a;
        if (size == null || (surfaceTexture = this.f1273f) == null || this.f1275h == null) {
            return;
        }
        surfaceTexture.setDefaultBufferSize(size.getWidth(), this.f1260a.getHeight());
        final Surface surface = new Surface(this.f1273f);
        final v2 v2Var = this.f1275h;
        final x<v2.g> a10 = y1.c.a(new c.InterfaceC0761c() { // from class: p1.n0
            @Override // y1.c.InterfaceC0761c
            public final Object a(c.a aVar) {
                return androidx.camera.view.e.j(androidx.camera.view.e.this, surface, aVar);
            }
        });
        this.f1274g = a10;
        a10.a(new Runnable() { // from class: p1.o0
            @Override // java.lang.Runnable
            public final void run() {
                androidx.camera.view.e.k(androidx.camera.view.e.this, surface, a10, v2Var);
            }
        }, l2.b.i(this.f1272e.getContext()));
        f();
    }
}
