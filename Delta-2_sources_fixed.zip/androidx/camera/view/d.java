package androidx.camera.view;

import android.graphics.Bitmap;
import android.os.Handler;
import android.os.HandlerThread;
import android.util.Size;
import android.view.PixelCopy;
import android.view.Surface;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.widget.FrameLayout;
import androidx.camera.view.c;

import g0.r1;
import g0.v2;
import java.util.Objects;
import java.util.concurrent.Semaphore;
import java.util.concurrent.TimeUnit;
import pe.x;
import r0.n;
import x2.g;

/* loaded from: classes.dex */
public final class d extends c {

    /* renamed from: e, reason: collision with root package name */
    public SurfaceView f1263e;

    /* renamed from: f, reason: collision with root package name */
    public final b f1264f;

    public static class a {
        public static void a(SurfaceView surfaceView, Bitmap bitmap, PixelCopy.OnPixelCopyFinishedListener onPixelCopyFinishedListener, Handler handler) {
            PixelCopy.request(surfaceView, bitmap, onPixelCopyFinishedListener, handler);
        }
    }

    public class b implements SurfaceHolder.Callback {

        /* renamed from: a, reason: collision with root package name */
        public Size f1265a;
        public v2 b;

        /* renamed from: c, reason: collision with root package name */
        public v2 f1266c;

        /* renamed from: d, reason: collision with root package name */
        public c.a f1267d;

        /* renamed from: e, reason: collision with root package name */
        public Size f1268e;

        /* renamed from: f, reason: collision with root package name */
        public boolean f1269f = false;

        /* renamed from: g, reason: collision with root package name */
        public boolean f1270g = false;

        public b() {
        }

        public static /* synthetic */ void a(c.a aVar, v2.g gVar) {
            r1.a("SurfaceViewImpl", "Safe to release surface.");
            if (aVar != null) {
                aVar.a();
            }
        }

        public final boolean b() {
            return (this.f1269f || this.b == null || !Objects.equals(this.f1265a, this.f1268e)) ? false : true;
        }

        public final void c() {
            c.a aVar;
            if (this.b != null) {
                r1.a("SurfaceViewImpl", "Request canceled: " + this.b);
                if (!this.b.z() || (aVar = this.f1267d) == null) {
                    return;
                }
                aVar.a();
            }
        }

        public final void d() {
            if (this.b != null) {
                r1.a("SurfaceViewImpl", "Surface closed " + this.b);
                this.b.n().d();
            }
        }

        public void e(v2 v2Var, c.a aVar) {
            c();
            if (this.f1270g) {
                this.f1270g = false;
                v2Var.t();
                return;
            }
            this.b = v2Var;
            this.f1267d = aVar;
            Size q8 = v2Var.q();
            this.f1265a = q8;
            this.f1269f = false;
            if (f()) {
                return;
            }
            r1.a("SurfaceViewImpl", "Wait for new Surface creation.");
            d.this.f1263e.getHolder().setFixedSize(q8.getWidth(), q8.getHeight());
        }

        public final boolean f() {
            Surface surface = d.this.f1263e.getHolder().getSurface();
            if (!b()) {
                return false;
            }
            r1.a("SurfaceViewImpl", "Surface set on Preview.");
            final c.a aVar = this.f1267d;
            v2 v2Var = this.b;
            Objects.requireNonNull(v2Var);
            v2Var.w(surface, l2.b.i(d.this.f1263e.getContext()), new x2.a() { // from class: p1.j0
                @Override // x2.a
                public final void accept(Object obj) {
                    d.b.a(c.a.this, (v2.g) obj);
                }
            });
            this.f1269f = true;
            d.this.f();
            return true;
        }

        @Override // android.view.SurfaceHolder.Callback
        public void surfaceChanged(SurfaceHolder surfaceHolder, int i10, int i11, int i12) {
            r1.a("SurfaceViewImpl", "Surface changed. Size: " + i11 + "x" + i12);
            this.f1268e = new Size(i11, i12);
            f();
        }

        @Override // android.view.SurfaceHolder.Callback
        public void surfaceCreated(SurfaceHolder surfaceHolder) {
            v2 v2Var;
            r1.a("SurfaceViewImpl", "Surface created.");
            if (!this.f1270g || (v2Var = this.f1266c) == null) {
                return;
            }
            v2Var.t();
            this.f1266c = null;
            this.f1270g = false;
        }

        @Override // android.view.SurfaceHolder.Callback
        public void surfaceDestroyed(SurfaceHolder surfaceHolder) {
            r1.a("SurfaceViewImpl", "Surface destroyed.");
            if (this.f1269f) {
                d();
            } else {
                c();
            }
            this.f1270g = true;
            v2 v2Var = this.b;
            if (v2Var != null) {
                this.f1266c = v2Var;
            }
            this.f1269f = false;
            this.b = null;
            this.f1267d = null;
            this.f1268e = null;
            this.f1265a = null;
        }
    }

    public d(FrameLayout frameLayout, androidx.camera.view.b bVar) {
        super(frameLayout, bVar);
        this.f1264f = new b();
    }

    public static /* synthetic */ void k(Semaphore semaphore, int i10) {
        if (i10 == 0) {
            r1.a("SurfaceViewImpl", "PreviewView.SurfaceViewImplementation.getBitmap() succeeded");
        } else {
            r1.c("SurfaceViewImpl", "PreviewView.SurfaceViewImplementation.getBitmap() failed with error " + i10);
        }
        semaphore.release();
    }

    public static boolean m(SurfaceView surfaceView, Size size, v2 v2Var) {
        return surfaceView != null && Objects.equals(size, v2Var.q());
    }

    @Override // androidx.camera.view.c
    public View b() {
        return this.f1263e;
    }

    @Override // androidx.camera.view.c
    public Bitmap c() {
        SurfaceView surfaceView = this.f1263e;
        if (surfaceView == null || surfaceView.getHolder().getSurface() == null || !this.f1263e.getHolder().getSurface().isValid()) {
            return null;
        }
        final Semaphore semaphore = new Semaphore(0);
        Bitmap createBitmap = Bitmap.createBitmap(this.f1263e.getWidth(), this.f1263e.getHeight(), Bitmap.Config.ARGB_8888);
        HandlerThread handlerThread = new HandlerThread("pixelCopyRequest Thread");
        handlerThread.start();
        a.a(this.f1263e, createBitmap, new PixelCopy.OnPixelCopyFinishedListener() { // from class: p1.i0
            @Override // android.view.PixelCopy.OnPixelCopyFinishedListener
            public final void onPixelCopyFinished(int i10) {
                androidx.camera.view.d.k(semaphore, i10);
            }
        }, new Handler(handlerThread.getLooper()));
        try {
            if (!semaphore.tryAcquire(1, 100L, TimeUnit.MILLISECONDS)) {
                r1.c("SurfaceViewImpl", "Timed out while trying to acquire screenshot.");
            }
            return createBitmap;
        } catch (InterruptedException e10) {
            r1.d("SurfaceViewImpl", "Interrupted while trying to acquire screenshot.", e10);
            return createBitmap;
        } finally {
            handlerThread.quitSafely();
        }
    }

    @Override // androidx.camera.view.c
    public void d() {
    }

    @Override // androidx.camera.view.c
    public void e() {
    }

    @Override // androidx.camera.view.c
    public void g(final v2 v2Var, final c.a aVar) {
        if (!m(this.f1263e, this.f1260a, v2Var)) {
            this.f1260a = v2Var.q();
            l();
        }
        if (aVar != null) {
            v2Var.k(l2.b.i(this.f1263e.getContext()), new Runnable() { // from class: p1.g0
                @Override // java.lang.Runnable
                public final void run() {
                    c.a.this.a();
                }
            });
        }
        this.f1263e.post(new Runnable() { // from class: p1.h0
            @Override // java.lang.Runnable
            public final void run() {
                androidx.camera.view.d.this.f1264f.e(v2Var, aVar);
            }
        });
    }

    @Override // androidx.camera.view.c
    public x<Void> i() {
        return n.p(null);
    }

    public void l() {
        g.g(this.b);
        g.g(this.f1260a);
        SurfaceView surfaceView = new SurfaceView(this.b.getContext());
        this.f1263e = surfaceView;
        surfaceView.setLayoutParams(new FrameLayout.LayoutParams(this.f1260a.getWidth(), this.f1260a.getHeight()));
        this.b.removeAllViews();
        this.b.addView(this.f1263e);
        this.f1263e.getHolder().addCallback(this.f1264f);
    }
}
