package androidx.camera.video.internal.compat.quirk;

import android.os.Build;
import java.util.Arrays;
import java.util.List;
import n0.g3;

/* loaded from: classes.dex */
public class EncoderNotUsePersistentInputSurfaceQuirk implements g3 {

    /* renamed from: a, reason: collision with root package name */
    public static final List<String> f1207a = Arrays.asList("SM-N9208", "SM-G920V");

    public static boolean g() {
        return f1207a.contains(Build.MODEL.toUpperCase());
    }
}
