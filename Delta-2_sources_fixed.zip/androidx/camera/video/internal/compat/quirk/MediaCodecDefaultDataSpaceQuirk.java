package androidx.camera.video.internal.compat.quirk;

import m1.q1;
import n0.g3;

/* loaded from: classes.dex */
public class MediaCodecDefaultDataSpaceQuirk implements g3 {
    public static boolean h() {
        return true;
    }

    public q1 g() {
        return q1.f22847c;
    }
}
