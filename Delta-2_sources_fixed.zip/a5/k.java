package a5;

import com.github.luben.zstd.BuildConfig;
import java.util.Arrays;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import y4.u;

@Metadata(d1 = {"\u0000*\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\u0011\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\u001aM\u0010\f\u001a\b\u0012\u0004\u0012\u00028\u00000\u000b\"\u0004\b\u0000\u0010\u00002\u0006\u0010\u0002\u001a\u00020\u00012\u0006\u0010\u0004\u001a\u00020\u00032\f\u0010\u0007\u001a\b\u0012\u0004\u0012\u00020\u00060\u00052\u0012\u0010\n\u001a\u000e\u0012\u0004\u0012\u00020\t\u0012\u0004\u0012\u00028\u00000\bH\u0007¢\u0006\u0004\b\f\u0010\r¨\u0006\u000e"}, d2 = {"R", "Ly4/u;", "db", BuildConfig.FLAVOR, "inTransaction", BuildConfig.FLAVOR, BuildConfig.FLAVOR, "tableNames", "Lkotlin/Function1;", "Lg5/b;", "block", "Ldv/h;", xe.a.f36648e, "(Ly4/u;Z[Ljava/lang/String;Lkotlin/jvm/functions/Function1;)Ldv/h;", "room-runtime"}, k = 2, mv = {2, 1, 0}, xi = 48)
/* loaded from: classes.dex */
public final class k {

    /* JADX INFO: Add missing generic type declarations: [R] */
    @Metadata(d1 = {"\u0000\u0017\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0003*\u0001\u0000\b\n\u0018\u00002\b\u0012\u0004\u0012\u00028\u00000\u0001J\u001e\u0010\u0005\u001a\u00020\u00042\f\u0010\u0003\u001a\b\u0012\u0004\u0012\u00028\u00000\u0002H\u0096@¢\u0006\u0004\b\u0005\u0010\u0006¨\u0006\u0007"}, d2 = {"kotlinx/coroutines/flow/internal/SafeCollector_commonKt$unsafeFlow$1", "Ldv/h;", "Ldv/i;", "collector", BuildConfig.FLAVOR, "collect", "(Ldv/i;Leu/b;)Ljava/lang/Object;", "kotlinx-coroutines-core"}, k = 1, mv = {2, 1, 0}, xi = 48)
    public static final class a<R> implements dv.h<R> {

        /* renamed from: a, reason: collision with root package name */
        public final /* synthetic */ dv.h f150a;
        public final /* synthetic */ u b;

        /* renamed from: c, reason: collision with root package name */
        public final /* synthetic */ boolean f151c;

        /* renamed from: d, reason: collision with root package name */
        public final /* synthetic */ Function1 f152d;

        @Metadata(d1 = {"\u0000\f\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0002\b\u0003\u0010\u0006\u001a\u00020\u0003\"\u0004\b\u0000\u0010\u0000\"\u0004\b\u0001\u0010\u00012\u0006\u0010\u0002\u001a\u00028\u0000H\u008a@¢\u0006\u0004\b\u0004\u0010\u0005"}, d2 = {"T", "R", "value", BuildConfig.FLAVOR, "emit", "(Ljava/lang/Object;Leu/b;)Ljava/lang/Object;", "<anonymous>"}, k = 3, mv = {2, 1, 0})
        /* renamed from: a5.k$a$a, reason: collision with other inner class name */
        public static final class C0001a<T> implements dv.i {

            /* renamed from: a, reason: collision with root package name */
            public final /* synthetic */ dv.i f153a;
            public final /* synthetic */ u b;

            /* renamed from: c, reason: collision with root package name */
            public final /* synthetic */ boolean f154c;

            /* renamed from: d, reason: collision with root package name */
            public final /* synthetic */ Function1 f155d;

            @Metadata(k = 3, mv = {2, 1, 0}, xi = 48)
            @gu.f(c = "androidx.room.coroutines.FlowUtil$createFlow$$inlined$map$1$2", f = "FlowBuilder.kt", l = {220, 219}, m = "emit")
            /* renamed from: a5.k$a$a$a, reason: collision with other inner class name */
            public static final class C0002a extends gu.d {

                /* renamed from: t, reason: collision with root package name */
                public /* synthetic */ Object f156t;

                /* renamed from: u, reason: collision with root package name */
                public int f157u;

                /* renamed from: v, reason: collision with root package name */
                public Object f158v;

                public C0002a(eu.b bVar) {
                    super(bVar);
                }

                @Override // gu.a
                @Nullable
                public final Object invokeSuspend(@NotNull Object obj) {
                    this.f156t = obj;
                    this.f157u |= Integer.MIN_VALUE;
                    return C0001a.this.emit(null, this);
                }
            }

            public C0001a(dv.i iVar, u uVar, boolean z10, Function1 function1) {
                this.f153a = iVar;
                this.b = uVar;
                this.f154c = z10;
                this.f155d = function1;
            }

            /* JADX WARN: Code restructure failed: missing block: B:18:0x0060, code lost:
            
                if (r8.emit(r9, r0) != r1) goto L23;
             */
            /* JADX WARN: Removed duplicated region for block: B:20:0x003c  */
            /* JADX WARN: Removed duplicated region for block: B:8:0x0024  */
            @Override // dv.i
            @org.jetbrains.annotations.Nullable
            /*
                Code decompiled incorrectly, please refer to instructions dump.
                To view partially-correct add '--show-bad-code' argument
            */
            public final java.lang.Object emit(java.lang.Object r8, @org.jetbrains.annotations.NotNull eu.b r9) {
                /*
                    r7 = this;
                    boolean r0 = r9 instanceof a5.k.a.C0001a.C0002a
                    if (r0 == 0) goto L13
                    r0 = r9
                    a5.k$a$a$a r0 = (a5.k.a.C0001a.C0002a) r0
                    int r1 = r0.f157u
                    r2 = -2147483648(0xffffffff80000000, float:-0.0)
                    r3 = r1 & r2
                    if (r3 == 0) goto L13
                    int r1 = r1 - r2
                    r0.f157u = r1
                    goto L18
                L13:
                    a5.k$a$a$a r0 = new a5.k$a$a$a
                    r0.<init>(r9)
                L18:
                    java.lang.Object r9 = r0.f156t
                    java.lang.Object r1 = fu.c.e()
                    int r2 = r0.f157u
                    r3 = 2
                    r4 = 1
                    if (r2 == 0) goto L3c
                    if (r2 == r4) goto L34
                    if (r2 != r3) goto L2c
                    zt.o.b(r9)
                    goto L63
                L2c:
                    java.lang.IllegalStateException r8 = new java.lang.IllegalStateException
                    java.lang.String r9 = "call to 'resume' before 'invoke' with coroutine"
                    r8.<init>(r9)
                    throw r8
                L34:
                    java.lang.Object r8 = r0.f158v
                    dv.i r8 = (dv.i) r8
                    zt.o.b(r9)
                    goto L57
                L3c:
                    zt.o.b(r9)
                    dv.i r9 = r7.f153a
                    java.util.Set r8 = (java.util.Set) r8
                    y4.u r8 = r7.b
                    boolean r2 = r7.f154c
                    kotlin.jvm.functions.Function1 r5 = r7.f155d
                    r0.f158v = r9
                    r0.f157u = r4
                    java.lang.Object r8 = d5.a.e(r8, r4, r2, r5, r0)
                    if (r8 != r1) goto L54
                    goto L62
                L54:
                    r6 = r9
                    r9 = r8
                    r8 = r6
                L57:
                    r2 = 0
                    r0.f158v = r2
                    r0.f157u = r3
                    java.lang.Object r8 = r8.emit(r9, r0)
                    if (r8 != r1) goto L63
                L62:
                    return r1
                L63:
                    kotlin.Unit r8 = kotlin.Unit.f21504a
                    return r8
                */
                throw new UnsupportedOperationException("Method not decompiled: a5.k.a.C0001a.emit(java.lang.Object, eu.b):java.lang.Object");
            }
        }

        public a(dv.h hVar, u uVar, boolean z10, Function1 function1) {
            this.f150a = hVar;
            this.b = uVar;
            this.f151c = z10;
            this.f152d = function1;
        }

        @Override // dv.h
        @Nullable
        public Object collect(@NotNull dv.i iVar, @NotNull eu.b bVar) {
            Object collect = this.f150a.collect(new C0001a(iVar, this.b, this.f151c, this.f152d), bVar);
            return collect == fu.c.e() ? collect : Unit.f21504a;
        }
    }

    @NotNull
    public static final <R> dv.h<R> a(@NotNull u db2, boolean z10, @NotNull String[] tableNames, @NotNull Function1<? super g5.b, ? extends R> block) {
        Intrinsics.checkNotNullParameter(db2, "db");
        Intrinsics.checkNotNullParameter(tableNames, "tableNames");
        Intrinsics.checkNotNullParameter(block, "block");
        return new a(dv.j.k(db2.t().j((String[]) Arrays.copyOf(tableNames, tableNames.length), true)), db2, z10, block);
    }
}
