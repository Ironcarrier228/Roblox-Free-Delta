package a5;

import av.p0;
import com.github.luben.zstd.BuildConfig;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.coroutines.CoroutineContext;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import y4.g0;

@Metadata(d1 = {"\u0000N\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0002\b\b\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0004\b\u0000\u0018\u00002\u00020\u0001:\u0001\u0018B[\u0012\u0006\u0010\u0003\u001a\u00020\u0002\u0012\u0006\u0010\u0005\u001a\u00020\u0004\u0012B\b\u0002\u0010\u000b\u001a<\b\u0001\u0012\u0018\u0012\u0016\b\u0001\u0012\b\u0012\u0006\u0012\u0002\b\u00030\b\u0012\u0006\u0012\u0004\u0018\u00010\t0\u0007\u0012\b\u0012\u0006\u0012\u0002\b\u00030\b\u0012\u0006\u0012\u0004\u0018\u00010\t\u0018\u00010\u0006j\b\u0012\u0002\b\u0003\u0018\u0001`\n¢\u0006\u0004\b\f\u0010\rJB\u0010\u0013\u001a\u00028\u0000\"\u0004\b\u0000\u0010\u000e2\u0006\u0010\u0010\u001a\u00020\u000f2\"\u0010\u0012\u001a\u001e\b\u0001\u0012\u0004\u0012\u00020\u0011\u0012\n\u0012\b\u0012\u0004\u0012\u00028\u00000\b\u0012\u0006\u0012\u0004\u0018\u00010\t0\u0006H\u0096@¢\u0006\u0004\b\u0013\u0010\u0014J\u000f\u0010\u0016\u001a\u00020\u0015H\u0016¢\u0006\u0004\b\u0016\u0010\u0017R\u0014\u0010\u0003\u001a\u00020\u00028\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b\u0018\u0010\u0019R\u0014\u0010\u0005\u001a\u00020\u00048\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b\u001a\u0010\u001bRN\u0010\u000b\u001a<\b\u0001\u0012\u0018\u0012\u0016\b\u0001\u0012\b\u0012\u0006\u0012\u0002\b\u00030\b\u0012\u0006\u0012\u0004\u0018\u00010\t0\u0007\u0012\b\u0012\u0006\u0012\u0002\b\u00030\b\u0012\u0006\u0012\u0004\u0018\u00010\t\u0018\u00010\u0006j\b\u0012\u0002\b\u0003\u0018\u0001`\n8\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b\u001c\u0010\u001dR\u001a\u0010\"\u001a\b\u0012\u0004\u0012\u00020\u001f0\u001e8\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b \u0010!¨\u0006#"}, d2 = {"La5/n;", "La5/c;", "Lg5/c;", "driver", BuildConfig.FLAVOR, "fileName", "Lkotlin/Function2;", "Lkotlin/Function1;", "Leu/b;", BuildConfig.FLAVOR, "Landroidx/room/coroutines/TransactionWrapper;", "transactionWrapper", "<init>", "(Lg5/c;Ljava/lang/String;Lkotlin/jvm/functions/Function2;)V", "R", BuildConfig.FLAVOR, "isReadOnly", "Ly4/g0;", "block", "r1", "(ZLkotlin/jvm/functions/Function2;Leu/b;)Ljava/lang/Object;", BuildConfig.FLAVOR, "close", "()V", xe.a.f36648e, "Lg5/c;", k6.b.f21144e, "Ljava/lang/String;", "c", "Lkotlin/jvm/functions/Function2;", "Lzt/h;", "Lg5/b;", "d", "Lzt/h;", "connection", "room-runtime"}, k = 1, mv = {2, 1, 0}, xi = 48)
/* loaded from: classes.dex */
public final class n implements c {

    /* renamed from: a, reason: collision with root package name and from kotlin metadata */
    @NotNull
    public final g5.c driver;

    /* renamed from: b, reason: from kotlin metadata */
    @NotNull
    public final String fileName;

    /* renamed from: c, reason: collision with root package name and from kotlin metadata */
    @Nullable
    public final Function2<Function1<? super eu.b<Object>, ? extends Object>, eu.b<Object>, Object> transactionWrapper;

    /* renamed from: d, reason: collision with root package name and from kotlin metadata */
    @NotNull
    public final zt.h<g5.b> connection;

    @Metadata(d1 = {"\u0000\u0018\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\b\u0005\b\u0002\u0018\u0000 \r2\u00020\u0001:\u0001\u0006B\u000f\u0012\u0006\u0010\u0003\u001a\u00020\u0002¢\u0006\u0004\b\u0004\u0010\u0005R\u0017\u0010\u0003\u001a\u00020\u00028\u0006¢\u0006\f\n\u0004\b\u0006\u0010\u0007\u001a\u0004\b\u0006\u0010\bR\u001a\u0010\f\u001a\b\u0012\u0004\u0012\u00020\u00000\t8VX\u0096\u0004¢\u0006\u0006\u001a\u0004\b\n\u0010\u000b¨\u0006\u000e"}, d2 = {"La5/n$a;", "Lkotlin/coroutines/CoroutineContext$Element;", "La5/l;", "connectionWrapper", "<init>", "(La5/l;)V", xe.a.f36648e, "La5/l;", "()La5/l;", "Lkotlin/coroutines/CoroutineContext$b;", "getKey", "()Lkotlin/coroutines/CoroutineContext$b;", "key", k6.b.f21144e, "room-runtime"}, k = 1, mv = {2, 1, 0}, xi = 48)
    public static final class a implements CoroutineContext.Element {

        /* renamed from: b, reason: from kotlin metadata */
        @NotNull
        public static final Companion INSTANCE = new Companion(null);

        /* renamed from: a, reason: collision with root package name and from kotlin metadata */
        @NotNull
        public final l connectionWrapper;

        @Metadata(d1 = {"\u0000\u0010\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\b\u0086\u0003\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0003\u0010\u0004¨\u0006\u0005"}, d2 = {"La5/n$a$a;", "Lkotlin/coroutines/CoroutineContext$b;", "La5/n$a;", "<init>", "()V", "room-runtime"}, k = 1, mv = {2, 1, 0}, xi = 48)
        /* renamed from: a5.n$a$a, reason: collision with other inner class name and from kotlin metadata */
        public static final class Companion implements CoroutineContext.b<a> {
            public /* synthetic */ Companion(DefaultConstructorMarker defaultConstructorMarker) {
                this();
            }

            public Companion() {
            }
        }

        public a(@NotNull l connectionWrapper) {
            Intrinsics.checkNotNullParameter(connectionWrapper, "connectionWrapper");
            this.connectionWrapper = connectionWrapper;
        }

        @NotNull
        /* renamed from: a, reason: from getter */
        public final l getConnectionWrapper() {
            return this.connectionWrapper;
        }

        @Override // kotlin.coroutines.CoroutineContext
        public <R> R fold(R r10, @NotNull Function2<? super R, ? super CoroutineContext.Element, ? extends R> function2) {
            return (R) CoroutineContext.Element.a.a(this, r10, function2);
        }

        @Override // kotlin.coroutines.CoroutineContext.Element, kotlin.coroutines.CoroutineContext
        @Nullable
        public <E extends CoroutineContext.Element> E get(@NotNull CoroutineContext.b<E> bVar) {
            return (E) CoroutineContext.Element.a.b(this, bVar);
        }

        @Override // kotlin.coroutines.CoroutineContext.Element
        @NotNull
        public CoroutineContext.b<a> getKey() {
            return INSTANCE;
        }

        @Override // kotlin.coroutines.CoroutineContext
        @NotNull
        public CoroutineContext minusKey(@NotNull CoroutineContext.b<?> bVar) {
            return CoroutineContext.Element.a.c(this, bVar);
        }

        @Override // kotlin.coroutines.CoroutineContext
        @NotNull
        public CoroutineContext plus(@NotNull CoroutineContext coroutineContext) {
            return CoroutineContext.Element.a.d(this, coroutineContext);
        }
    }

    /* JADX INFO: Add missing generic type declarations: [R] */
    @Metadata(d1 = {"\u0000\b\n\u0000\n\u0002\u0018\u0002\n\u0000\u0010\u0002\u001a\u00028\u0000\"\u0004\b\u0000\u0010\u0000*\u00020\u0001H\n"}, d2 = {"R", "Lav/p0;", "<anonymous>"}, k = 3, mv = {2, 1, 0})
    @gu.f(c = "androidx.room.coroutines.PassthroughConnectionPool$useConnection$2", f = "PassthroughConnectionPool.kt", l = {59}, m = "invokeSuspend")
    public static final class b<R> extends gu.m implements Function2<p0, eu.b<? super R>, Object> {

        /* renamed from: t, reason: collision with root package name */
        public int f187t;

        /* renamed from: u, reason: collision with root package name */
        public final /* synthetic */ Function2<g0, eu.b<? super R>, Object> f188u;

        /* renamed from: v, reason: collision with root package name */
        public final /* synthetic */ l f189v;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        /* JADX WARN: Multi-variable type inference failed */
        public b(Function2<? super g0, ? super eu.b<? super R>, ? extends Object> function2, l lVar, eu.b<? super b> bVar) {
            super(2, bVar);
            this.f188u = function2;
            this.f189v = lVar;
        }

        @Override // gu.a
        public final eu.b<Unit> create(Object obj, eu.b<?> bVar) {
            return new b(this.f188u, this.f189v, bVar);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(p0 p0Var, eu.b<? super R> bVar) {
            return ((b) create(p0Var, bVar)).invokeSuspend(Unit.f21504a);
        }

        @Override // gu.a
        public final Object invokeSuspend(Object obj) {
            Object e10 = fu.c.e();
            int i10 = this.f187t;
            if (i10 != 0) {
                if (i10 != 1) {
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                zt.o.b(obj);
                return obj;
            }
            zt.o.b(obj);
            Function2<g0, eu.b<? super R>, Object> function2 = this.f188u;
            l lVar = this.f189v;
            this.f187t = 1;
            Object invoke = function2.invoke(lVar, this);
            return invoke == e10 ? e10 : invoke;
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    public n(@NotNull g5.c driver, @NotNull String fileName, @Nullable Function2<? super Function1<? super eu.b<Object>, ? extends Object>, ? super eu.b<Object>, ? extends Object> function2) {
        Intrinsics.checkNotNullParameter(driver, "driver");
        Intrinsics.checkNotNullParameter(fileName, "fileName");
        this.driver = driver;
        this.fileName = fileName;
        this.transactionWrapper = function2;
        this.connection = zt.i.a(new Function0() { // from class: a5.m
            @Override // kotlin.jvm.functions.Function0
            public final Object invoke() {
                g5.b b10;
                b10 = n.b(n.this);
                return b10;
            }
        });
    }

    public static final g5.b b(n nVar) {
        return nVar.driver.a(nVar.fileName);
    }

    @Override // a5.c, java.lang.AutoCloseable
    public void close() {
        if (this.connection.isInitialized()) {
            this.connection.getValue().close();
        }
    }

    @Override // a5.c
    @Nullable
    public <R> Object r1(boolean z10, @NotNull Function2<? super g0, ? super eu.b<? super R>, ? extends Object> function2, @NotNull eu.b<? super R> bVar) {
        a aVar = (a) bVar.getContext().get(a.INSTANCE);
        l connectionWrapper = aVar != null ? aVar.getConnectionWrapper() : null;
        if (connectionWrapper != null) {
            return function2.invoke(connectionWrapper, bVar);
        }
        l lVar = new l(this.transactionWrapper, this.connection.getValue());
        return av.i.g(new a(lVar), new b(function2, lVar, null), bVar);
    }


    // --- восстановлено из DEX (a5/n$a$a) ---
    public static class a implements kotlin.coroutines.CoroutineContext.b {
        public a() { }
        public a(kotlin.jvm.internal.DefaultConstructorMarker p0) { }
    }
}
