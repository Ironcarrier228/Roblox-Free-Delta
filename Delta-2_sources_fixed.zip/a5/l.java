package a5;

import com.appsflyer.sdk_base.referrer.Payload;
import com.github.luben.zstd.BuildConfig;
import java.util.concurrent.atomic.AtomicInteger;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import y4.f0;
import y4.g0;

@Metadata(d1 = {"\u0000Z\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0002\b\t\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0007\b\u0002\u0018\u00002\u00020\u00012\u00020\u0002:\u0001\u0012BQ\u0012@\u0010\b\u001a<\b\u0001\u0012\u0018\u0012\u0016\b\u0001\u0012\b\u0012\u0006\u0012\u0002\b\u00030\u0005\u0012\u0006\u0012\u0004\u0018\u00010\u00060\u0004\u0012\b\u0012\u0006\u0012\u0002\b\u00030\u0005\u0012\u0006\u0012\u0004\u0018\u00010\u0006\u0018\u00010\u0003j\b\u0012\u0002\b\u0003\u0018\u0001`\u0007\u0012\u0006\u0010\n\u001a\u00020\t¢\u0006\u0004\b\u000b\u0010\fJ2\u0010\u0012\u001a\u00028\u0000\"\u0004\b\u0000\u0010\r2\u0006\u0010\u000f\u001a\u00020\u000e2\u0012\u0010\u0011\u001a\u000e\u0012\u0004\u0012\u00020\u0010\u0012\u0004\u0012\u00028\u00000\u0004H\u0096@¢\u0006\u0004\b\u0012\u0010\u0013JH\u0010\u0017\u001a\u00028\u0000\"\u0004\b\u0000\u0010\r2\u0006\u0010\u0015\u001a\u00020\u00142(\u0010\u0011\u001a$\b\u0001\u0012\n\u0012\b\u0012\u0004\u0012\u00028\u00000\u0016\u0012\n\u0012\b\u0012\u0004\u0012\u00028\u00000\u0005\u0012\u0006\u0012\u0004\u0018\u00010\u00060\u0003H\u0096@¢\u0006\u0004\b\u0017\u0010\u0018J\u0010\u0010\u001a\u001a\u00020\u0019H\u0096@¢\u0006\u0004\b\u001a\u0010\u001bJH\u0010\u001c\u001a\u00028\u0000\"\u0004\b\u0000\u0010\r2\u0006\u0010\u0015\u001a\u00020\u00142(\u0010\u0011\u001a$\b\u0001\u0012\n\u0012\b\u0012\u0004\u0012\u00028\u00000\u0016\u0012\n\u0012\b\u0012\u0004\u0012\u00028\u00000\u0005\u0012\u0006\u0012\u0004\u0018\u00010\u00060\u0003H\u0082@¢\u0006\u0004\b\u001c\u0010\u0018RQ\u0010\b\u001a<\b\u0001\u0012\u0018\u0012\u0016\b\u0001\u0012\b\u0012\u0006\u0012\u0002\b\u00030\u0005\u0012\u0006\u0012\u0004\u0018\u00010\u00060\u0004\u0012\b\u0012\u0006\u0012\u0002\b\u00030\u0005\u0012\u0006\u0012\u0004\u0018\u00010\u0006\u0018\u00010\u0003j\b\u0012\u0002\b\u0003\u0018\u0001`\u00078\u0006¢\u0006\f\n\u0004\b\u0012\u0010\u001d\u001a\u0004\b\u001e\u0010\u001fR\u0017\u0010\n\u001a\u00020\t8\u0006¢\u0006\f\n\u0004\b\u001a\u0010 \u001a\u0004\b!\u0010\"R\u001a\u0010&\u001a\u00060#j\u0002`$8\u0002@\u0002X\u0082\u000e¢\u0006\u0006\n\u0004\b\u0017\u0010%R\u0018\u0010)\u001a\u0004\u0018\u00010\u00148\u0002@\u0002X\u0082\u000e¢\u0006\u0006\n\u0004\b'\u0010(R\u0014\u0010*\u001a\u00020\t8VX\u0096\u0004¢\u0006\u0006\u001a\u0004\b'\u0010\"¨\u0006+"}, d2 = {"La5/l;", "Ly4/g0;", "La5/q;", "Lkotlin/Function2;", "Lkotlin/Function1;", "Leu/b;", BuildConfig.FLAVOR, "Landroidx/room/coroutines/TransactionWrapper;", "transactionWrapper", "Lg5/b;", "delegate", "<init>", "(Lkotlin/jvm/functions/Function2;Lg5/b;)V", "R", BuildConfig.FLAVOR, "sql", "Lg5/d;", "block", xe.a.f36648e, "(Ljava/lang/String;Lkotlin/jvm/functions/Function1;Leu/b;)Ljava/lang/Object;", "Ly4/g0$a;", Payload.TYPE, "Ly4/f0;", "c", "(Ly4/g0$a;Lkotlin/jvm/functions/Function2;Leu/b;)Ljava/lang/Object;", BuildConfig.FLAVOR, k6.b.f21144e, "(Leu/b;)Ljava/lang/Object;", "g", "Lkotlin/jvm/functions/Function2;", "getTransactionWrapper", "()Lkotlin/jvm/functions/Function2;", "Lg5/b;", "f", "()Lg5/b;", "Ljava/util/concurrent/atomic/AtomicInteger;", "Landroidx/room/concurrent/AtomicInt;", "Ljava/util/concurrent/atomic/AtomicInteger;", "nestedTransactionCount", "d", "Ly4/g0$a;", "currentTransactionType", "rawConnection", "room-runtime"}, k = 1, mv = {2, 1, 0}, xi = 48)
/* loaded from: classes.dex */
public final class l implements g0, q {

    /* renamed from: a, reason: collision with root package name and from kotlin metadata */
    @Nullable
    public final Function2<Function1<? super eu.b<Object>, ? extends Object>, eu.b<Object>, Object> transactionWrapper;

    /* renamed from: b, reason: from kotlin metadata */
    @NotNull
    public final g5.b delegate;

    /* renamed from: c, reason: collision with root package name and from kotlin metadata */
    @NotNull
    public AtomicInteger nestedTransactionCount;

    /* renamed from: d, reason: collision with root package name and from kotlin metadata */
    @Nullable
    public g0.a currentTransactionType;

    @Metadata(d1 = {"\u0000,\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0004\b\u0082\u0004\u0018\u0000*\u0004\b\u0000\u0010\u00012\b\u0012\u0004\u0012\u00028\u00000\u00022\u00020\u0003B\u0007¢\u0006\u0004\b\u0004\u0010\u0005J2\u0010\f\u001a\u00028\u0001\"\u0004\b\u0001\u0010\u00062\u0006\u0010\b\u001a\u00020\u00072\u0012\u0010\u000b\u001a\u000e\u0012\u0004\u0012\u00020\n\u0012\u0004\u0012\u00028\u00010\tH\u0096@¢\u0006\u0004\b\f\u0010\rR\u0014\u0010\u0011\u001a\u00020\u000e8VX\u0096\u0004¢\u0006\u0006\u001a\u0004\b\u000f\u0010\u0010¨\u0006\u0012"}, d2 = {"La5/l$a;", "T", "Ly4/f0;", "La5/q;", "<init>", "(La5/l;)V", "R", BuildConfig.FLAVOR, "sql", "Lkotlin/Function1;", "Lg5/d;", "block", xe.a.f36648e, "(Ljava/lang/String;Lkotlin/jvm/functions/Function1;Leu/b;)Ljava/lang/Object;", "Lg5/b;", "d", "()Lg5/b;", "rawConnection", "room-runtime"}, k = 1, mv = {2, 1, 0}, xi = 48)
    public final class a<T> implements f0<T>, q {
        public a() {
        }

        @Override // y4.m
        @Nullable
        public <R> Object a(@NotNull String str, @NotNull Function1<? super g5.d, ? extends R> function1, @NotNull eu.b<? super R> bVar) {
            return l.this.a(str, function1, bVar);
        }

        @Override // a5.q
        @NotNull
        /* renamed from: d */
        public g5.b getDelegate() {
            return l.this.getDelegate();
        }
    }

    @Metadata(k = 3, mv = {2, 1, 0}, xi = 48)
    public static final /* synthetic */ class b {

        /* renamed from: a, reason: collision with root package name */
        public static final /* synthetic */ int[] f164a;

        static {
            int[] iArr = new int[g0.a.values().length];
            try {
                iArr[g0.a.f37281a.ordinal()] = 1;
            } catch (NoSuchFieldError unused) {
            }
            try {
                iArr[g0.a.b.ordinal()] = 2;
            } catch (NoSuchFieldError unused2) {
            }
            try {
                iArr[g0.a.f37282c.ordinal()] = 3;
            } catch (NoSuchFieldError unused3) {
            }
            f164a = iArr;
        }
    }

    @Metadata(k = 3, mv = {2, 1, 0}, xi = 48)
    @gu.f(c = "androidx.room.coroutines.PassthroughConnection", f = "PassthroughConnectionPool.kt", l = {127}, m = "transaction")
    public static final class c<R> extends gu.d {

        /* renamed from: t, reason: collision with root package name */
        public int f165t;

        /* renamed from: u, reason: collision with root package name */
        public /* synthetic */ Object f166u;

        /* renamed from: w, reason: collision with root package name */
        public int f168w;

        public c(eu.b<? super c> bVar) {
            super(bVar);
        }

        @Override // gu.a
        @Nullable
        public final Object invokeSuspend(@NotNull Object obj) {
            this.f166u = obj;
            this.f168w |= Integer.MIN_VALUE;
            return l.this.g(null, null, this);
        }
    }

    @Metadata(k = 3, mv = {2, 1, 0}, xi = 48)
    @gu.f(c = "androidx.room.coroutines.PassthroughConnection", f = "PassthroughConnectionPool.kt", l = {89, 91}, m = "usePrepared")
    public static final class d<R> extends gu.d {

        /* renamed from: t, reason: collision with root package name */
        public Object f169t;

        /* renamed from: u, reason: collision with root package name */
        public Object f170u;

        /* renamed from: v, reason: collision with root package name */
        public /* synthetic */ Object f171v;

        /* renamed from: x, reason: collision with root package name */
        public int f173x;

        public d(eu.b<? super d> bVar) {
            super(bVar);
        }

        @Override // gu.a
        @Nullable
        public final Object invokeSuspend(@NotNull Object obj) {
            this.f171v = obj;
            this.f173x |= Integer.MIN_VALUE;
            return l.this.a(null, null, this);
        }
    }

    @Metadata(d1 = {"\u0000\u0006\n\u0000\n\u0002\u0010\u0000\u0010\u0000\u001a\u0004\u0018\u00010\u0001H\n"}, d2 = {"<anonymous>", BuildConfig.FLAVOR}, k = 3, mv = {2, 1, 0}, xi = 48)
    @gu.f(c = "androidx.room.coroutines.PassthroughConnection$usePrepared$2", f = "PassthroughConnectionPool.kt", l = {}, m = "invokeSuspend")
    public static final class e extends gu.m implements Function1<eu.b<? super Object>, Object> {

        /* renamed from: t, reason: collision with root package name */
        public int f174t;

        /* renamed from: v, reason: collision with root package name */
        public final /* synthetic */ String f176v;

        /* renamed from: w, reason: collision with root package name */
        public final /* synthetic */ Function1<g5.d, R> f177w;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        /* JADX WARN: Multi-variable type inference failed */
        public e(String str, Function1<? super g5.d, ? extends R> function1, eu.b<? super e> bVar) {
            super(1, bVar);
            this.f176v = str;
            this.f177w = function1;
        }

        @Override // gu.a
        public final eu.b<Unit> create(eu.b<?> bVar) {
            return l.this.new e(this.f176v, this.f177w, bVar);
        }

        @Override // gu.a
        public final Object invokeSuspend(Object obj) {
            fu.c.e();
            if (this.f174t != 0) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            zt.o.b(obj);
            g5.d w32 = l.this.f().w3(this.f176v);
            try {
                Object invoke = this.f177w.invoke(w32);
                nu.a.a(w32, null);
                return invoke;
            } finally {
            }
        }

        @Override // kotlin.jvm.functions.Function1
        /* renamed from: m, reason: merged with bridge method [inline-methods] */
        public final Object invoke(eu.b<Object> bVar) {
            return ((e) create(bVar)).invokeSuspend(Unit.f21504a);
        }
    }

    @Metadata(d1 = {"\u0000\u0006\n\u0000\n\u0002\u0010\u0000\u0010\u0000\u001a\u0004\u0018\u00010\u0001H\n"}, d2 = {"<anonymous>", BuildConfig.FLAVOR}, k = 3, mv = {2, 1, 0}, xi = 48)
    @gu.f(c = "androidx.room.coroutines.PassthroughConnection$withTransaction$2", f = "PassthroughConnectionPool.kt", l = {103}, m = "invokeSuspend")
    public static final class f extends gu.m implements Function1<eu.b<? super Object>, Object> {

        /* renamed from: t, reason: collision with root package name */
        public int f178t;

        /* renamed from: v, reason: collision with root package name */
        public final /* synthetic */ g0.a f180v;

        /* renamed from: w, reason: collision with root package name */
        public final /* synthetic */ Function2<f0<R>, eu.b<? super R>, Object> f181w;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        /* JADX WARN: Multi-variable type inference failed */
        public f(g0.a aVar, Function2<? super f0<R>, ? super eu.b<? super R>, ? extends Object> function2, eu.b<? super f> bVar) {
            super(1, bVar);
            this.f180v = aVar;
            this.f181w = function2;
        }

        @Override // gu.a
        public final eu.b<Unit> create(eu.b<?> bVar) {
            return l.this.new f(this.f180v, this.f181w, bVar);
        }

        @Override // gu.a
        public final Object invokeSuspend(Object obj) {
            Object e10 = fu.c.e();
            int i10 = this.f178t;
            if (i10 != 0) {
                if (i10 != 1) {
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                zt.o.b(obj);
                return obj;
            }
            zt.o.b(obj);
            l lVar = l.this;
            g0.a aVar = this.f180v;
            Function2<f0<R>, eu.b<? super R>, Object> function2 = this.f181w;
            this.f178t = 1;
            Object g10 = lVar.g(aVar, function2, this);
            return g10 == e10 ? e10 : g10;
        }

        @Override // kotlin.jvm.functions.Function1
        /* renamed from: m, reason: merged with bridge method [inline-methods] */
        public final Object invoke(eu.b<Object> bVar) {
            return ((f) create(bVar)).invokeSuspend(Unit.f21504a);
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    public l(@Nullable Function2<? super Function1<? super eu.b<Object>, ? extends Object>, ? super eu.b<Object>, ? extends Object> function2, @NotNull g5.b delegate) {
        Intrinsics.checkNotNullParameter(delegate, "delegate");
        this.transactionWrapper = function2;
        this.delegate = delegate;
        this.nestedTransactionCount = new AtomicInteger(0);
    }

    /* JADX WARN: Code restructure failed: missing block: B:38:0x004e, code lost:
    
        if (r8 == r1) goto L26;
     */
    /* JADX WARN: Removed duplicated region for block: B:37:0x0041  */
    /* JADX WARN: Removed duplicated region for block: B:8:0x0024  */
    @Override // y4.m
    @org.jetbrains.annotations.Nullable
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public <R> java.lang.Object a(@org.jetbrains.annotations.NotNull java.lang.String r6, @org.jetbrains.annotations.NotNull kotlin.jvm.functions.Function1<? super g5.d, ? extends R> r7, @org.jetbrains.annotations.NotNull eu.b<? super R> r8) {
        /*
            r5 = this;
            boolean r0 = r8 instanceof a5.l.d
            if (r0 == 0) goto L13
            r0 = r8
            a5.l$d r0 = (a5.l.d) r0
            int r1 = r0.f173x
            r2 = -2147483648(0xffffffff80000000, float:-0.0)
            r3 = r1 & r2
            if (r3 == 0) goto L13
            int r1 = r1 - r2
            r0.f173x = r1
            goto L18
        L13:
            a5.l$d r0 = new a5.l$d
            r0.<init>(r8)
        L18:
            java.lang.Object r8 = r0.f171v
            java.lang.Object r1 = fu.c.e()
            int r2 = r0.f173x
            r3 = 2
            r4 = 1
            if (r2 == 0) goto L41
            if (r2 == r4) goto L34
            if (r2 != r3) goto L2c
            zt.o.b(r8)
            return r8
        L2c:
            java.lang.IllegalStateException r6 = new java.lang.IllegalStateException
            java.lang.String r7 = "call to 'resume' before 'invoke' with coroutine"
            r6.<init>(r7)
            throw r6
        L34:
            java.lang.Object r6 = r0.f170u
            r7 = r6
            kotlin.jvm.functions.Function1 r7 = (kotlin.jvm.functions.Function1) r7
            java.lang.Object r6 = r0.f169t
            java.lang.String r6 = (java.lang.String) r6
            zt.o.b(r8)
            goto L51
        L41:
            zt.o.b(r8)
            r0.f169t = r6
            r0.f170u = r7
            r0.f173x = r4
            java.lang.Object r8 = r5.b(r0)
            if (r8 != r1) goto L51
            goto L6f
        L51:
            java.lang.Boolean r8 = (java.lang.Boolean) r8
            boolean r8 = r8.booleanValue()
            r2 = 0
            if (r8 == 0) goto L71
            kotlin.jvm.functions.Function2<kotlin.jvm.functions.Function1<? super eu.b<java.lang.Object>, ? extends java.lang.Object>, eu.b<java.lang.Object>, java.lang.Object> r8 = r5.transactionWrapper
            if (r8 == 0) goto L71
            a5.l$e r4 = new a5.l$e
            r4.<init>(r6, r7, r2)
            r0.f169t = r2
            r0.f170u = r2
            r0.f173x = r3
            java.lang.Object r6 = r8.invoke(r4, r0)
            if (r6 != r1) goto L70
        L6f:
            return r1
        L70:
            return r6
        L71:
            g5.b r8 = r5.delegate
            g5.d r6 = r8.w3(r6)
            java.lang.Object r7 = r7.invoke(r6)     // Catch: java.lang.Throwable -> L7f
            nu.a.a(r6, r2)
            return r7
        L7f:
            r7 = move-exception
            throw r7     // Catch: java.lang.Throwable -> L81
        L81:
            r8 = move-exception
            nu.a.a(r6, r7)
            throw r8
        */
        throw new UnsupportedOperationException("Method not decompiled: a5.l.a(java.lang.String, kotlin.jvm.functions.Function1, eu.b):java.lang.Object");
    }

    @Override // y4.g0
    @Nullable
    public Object b(@NotNull eu.b<? super Boolean> bVar) {
        return gu.b.a(this.currentTransactionType != null || this.delegate.G());
    }

    @Override // y4.g0
    @Nullable
    public <R> Object c(@NotNull g0.a aVar, @NotNull Function2<? super f0<R>, ? super eu.b<? super R>, ? extends Object> function2, @NotNull eu.b<? super R> bVar) {
        Function2<Function1<? super eu.b<Object>, ? extends Object>, eu.b<Object>, Object> function22 = this.transactionWrapper;
        if (function22 == null) {
            return g(aVar, function2, bVar);
        }
        Object invoke = function22.invoke(new f(aVar, function2, null), bVar);
        fu.c.e();
        return invoke;
    }

    @Override // a5.q
    @NotNull
    /* renamed from: d, reason: from getter */
    public g5.b getDelegate() {
        return this.delegate;
    }

    @NotNull
    public final g5.b f() {
        return this.delegate;
    }

    /* JADX WARN: Removed duplicated region for block: B:14:0x008a  */
    /* JADX WARN: Removed duplicated region for block: B:16:0x008e  */
    /* JADX WARN: Removed duplicated region for block: B:19:0x0096  */
    /* JADX WARN: Removed duplicated region for block: B:24:0x0038  */
    /* JADX WARN: Removed duplicated region for block: B:9:0x0026  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final <R> java.lang.Object g(y4.g0.a r8, kotlin.jvm.functions.Function2<? super y4.f0<R>, ? super eu.b<? super R>, ? extends java.lang.Object> r9, eu.b<? super R> r10) {
        /*
            Method dump skipped, instructions count: 216
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: a5.l.g(y4.g0$a, kotlin.jvm.functions.Function2, eu.b):java.lang.Object");
    }
}
