package a7;

import com.appsflyer.sdk_base.referrer.Payload;
import com.github.luben.zstd.BuildConfig;
import ew.h;
import kotlin.Metadata;
import org.jetbrains.annotations.NotNull;

@Metadata(d1 = {"\u0000\u001a\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0005\u001a\u0019\u0010\u0004\u001a\u00020\u0003*\u00020\u00002\u0006\u0010\u0002\u001a\u00020\u0001¢\u0006\u0004\b\u0004\u0010\u0005\"\u0014\u0010\b\u001a\u00020\u00068\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b\u0004\u0010\u0007\"\u0014\u0010\n\u001a\u00020\u00068\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b\t\u0010\u0007¨\u0006\u000b"}, d2 = {"Ln6/h;", "Lew/g;", Payload.SOURCE, BuildConfig.FLAVOR, xe.a.f36648e, "(Ln6/h;Lew/g;)Z", "Lew/h;", "Lew/h;", "SVG_TAG", k6.b.f21144e, "LEFT_ANGLE_BRACKET", "coil-svg_release"}, k = 2, mv = {2, 2, 0}, xi = 48)
/* loaded from: classes.dex */
public final class a {

    /* renamed from: a, reason: collision with root package name */
    @NotNull
    public static final ew.h f276a;

    @NotNull
    public static final ew.h b;

    static {
        h.Companion companion = ew.h.INSTANCE;
        f276a = companion.d("<svg");
        b = companion.d("<");
    }

    public static final boolean a(@NotNull n6.h hVar, @NotNull ew.g gVar) {
        return gVar.V1(0L, b) && gVar.K1(f276a, 0L, 1024L) != -1;
    }
}
