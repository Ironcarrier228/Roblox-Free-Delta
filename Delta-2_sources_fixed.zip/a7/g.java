package a7;

import a7.c;
import android.content.Context;
import av.a2;
import com.appsflyer.sdk_base.referrer.Payload;
import com.github.luben.zstd.BuildConfig;
import com.google.mlkit.vision.barcode.common.Barcode;
import f7.r;
import kotlin.Metadata;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import l6.n;
import l6.v;
import n6.DecodeResult;
import n6.i;
import n6.s;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import p6.SourceFetchResult;
import y6.Options;

@Metadata(d1 = {"\u0000<\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u0007\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\b\u0015\u0018\u0000 (2\u00020\u0001:\u0002\u0018\u0015BO\u0012\u0006\u0010\u0003\u001a\u00020\u0002\u0012\u0006\u0010\u0005\u001a\u00020\u0004\u0012\b\b\u0002\u0010\u0007\u001a\u00020\u0006\u0012\u0018\b\u0002\u0010\f\u001a\u0012\u0012\b\u0012\u00060\tj\u0002`\n\u0012\u0004\u0012\u00020\u000b0\b\u0012\b\b\u0002\u0010\u000e\u001a\u00020\r\u0012\b\b\u0002\u0010\u000f\u001a\u00020\r¢\u0006\u0004\b\u0010\u0010\u0011B7\b\u0016\u0012\u0006\u0010\u0003\u001a\u00020\u0002\u0012\u0006\u0010\u0005\u001a\u00020\u0004\u0012\b\b\u0002\u0010\u000e\u001a\u00020\r\u0012\b\b\u0002\u0010\u000f\u001a\u00020\r\u0012\b\b\u0002\u0010\u0012\u001a\u00020\r¢\u0006\u0004\b\u0010\u0010\u0013J\u0010\u0010\u0015\u001a\u00020\u0014H\u0096@¢\u0006\u0004\b\u0015\u0010\u0016R\u0014\u0010\u0003\u001a\u00020\u00028\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b\u0015\u0010\u0017R\u0014\u0010\u0005\u001a\u00020\u00048\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b\u0018\u0010\u0019R\u0017\u0010\u0007\u001a\u00020\u00068\u0006¢\u0006\f\n\u0004\b\u001a\u0010\u001b\u001a\u0004\b\u001c\u0010\u001dR'\u0010\f\u001a\u0012\u0012\b\u0012\u00060\tj\u0002`\n\u0012\u0004\u0012\u00020\u000b0\b8\u0006¢\u0006\f\n\u0004\b\u001e\u0010\u001f\u001a\u0004\b \u0010!R\u0017\u0010\u000e\u001a\u00020\r8\u0006¢\u0006\f\n\u0004\b\"\u0010#\u001a\u0004\b$\u0010%R\u0017\u0010\u000f\u001a\u00020\r8\u0006¢\u0006\f\n\u0004\b&\u0010#\u001a\u0004\b'\u0010%¨\u0006)"}, d2 = {"La7/g;", "Ln6/i;", "Ln6/s;", Payload.SOURCE, "Ly6/p;", "options", "La7/c$a;", "parser", "Lkotlin/Function1;", "Landroid/content/Context;", "Lcoil3/PlatformContext;", BuildConfig.FLAVOR, "density", BuildConfig.FLAVOR, "useViewBoundsAsIntrinsicSize", "renderToBitmap", "<init>", "(Ln6/s;Ly6/p;La7/c$a;Lkotlin/jvm/functions/Function1;ZZ)V", "scaleToDensity", "(Ln6/s;Ly6/p;ZZZ)V", "Ln6/g;", xe.a.f36648e, "(Leu/b;)Ljava/lang/Object;", "Ln6/s;", k6.b.f21144e, "Ly6/p;", "c", "La7/c$a;", "getParser", "()La7/c$a;", "d", "Lkotlin/jvm/functions/Function1;", "getDensity", "()Lkotlin/jvm/functions/Function1;", "e", "Z", "getUseViewBoundsAsIntrinsicSize", "()Z", "f", "getRenderToBitmap", "g", "coil-svg_release"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* loaded from: classes.dex */
public final class g implements n6.i {

    /* renamed from: h, reason: collision with root package name */
    @NotNull
    public static final Function1<Context, Float> f287h = new Function1() { // from class: a7.d
        @Override // kotlin.jvm.functions.Function1
        public final Object invoke(Object obj) {
            float e10;
            e10 = g.e((Context) obj);
            return Float.valueOf(e10);
        }
    };

    /* renamed from: i, reason: collision with root package name */
    @NotNull
    public static final Function1<Context, Float> f288i = new Function1() { // from class: a7.e
        @Override // kotlin.jvm.functions.Function1
        public final Object invoke(Object obj) {
            float f10;
            f10 = g.f((Context) obj);
            return Float.valueOf(f10);
        }
    };

    /* renamed from: a, reason: collision with root package name and from kotlin metadata */
    @NotNull
    public final s source;

    /* renamed from: b, reason: from kotlin metadata */
    @NotNull
    public final Options options;

    /* renamed from: c, reason: collision with root package name and from kotlin metadata */
    @NotNull
    public final c.a parser;

    /* renamed from: d, reason: collision with root package name and from kotlin metadata */
    @NotNull
    public final Function1<Context, Float> density;

    /* renamed from: e, reason: collision with root package name and from kotlin metadata */
    public final boolean useViewBoundsAsIntrinsicSize;

    /* renamed from: f, reason: collision with root package name and from kotlin metadata */
    public final boolean renderToBitmap;

    /* JADX WARN: Multi-variable type inference failed */
    public g(@NotNull s sVar, @NotNull Options options, @NotNull c.a aVar, @NotNull Function1<? super Context, Float> function1, boolean z10, boolean z11) {
        this.source = sVar;
        this.options = options;
        this.parser = aVar;
        this.density = function1;
        this.useViewBoundsAsIntrinsicSize = z10;
        this.renderToBitmap = z11;
    }

    public static final float e(Context context) {
        return 1.0f;
    }

    public static final float f(Context context) {
        return b7.d.a(context);
    }

    public static final DecodeResult g(g gVar) {
        Throwable th2;
        c cVar;
        float width;
        float height;
        ew.g l32 = gVar.source.l3();
        try {
            cVar = gVar.parser.a(l32);
            if (l32 != null) {
                try {
                    l32.close();
                } catch (Throwable th3) {
                    th2 = th3;
                }
            }
            th2 = null;
        } catch (Throwable th4) {
            if (l32 != null) {
                try {
                    l32.close();
                } catch (Throwable th5) {
                    zt.a.a(th4, th5);
                }
            }
            th2 = th4;
            cVar = null;
        }
        if (th2 != null) {
            throw th2;
        }
        c.ViewBox d10 = cVar.d();
        if (!gVar.useViewBoundsAsIntrinsicSize || d10 == null) {
            width = cVar.getWidth();
            height = cVar.getHeight();
        } else {
            width = i.b(d10);
            height = i.a(d10);
        }
        if (z6.h.b(gVar.options.getSize())) {
            float floatValue = gVar.density.invoke(gVar.options.getContext()).floatValue();
            if (width > 0.0f) {
                width *= floatValue;
            }
            if (height > 0.0f) {
                height *= floatValue;
            }
        }
        int i10 = Barcode.FORMAT_UPC_A;
        int d11 = width > 0.0f ? su.b.d(width) : 512;
        if (height > 0.0f) {
            i10 = su.b.d(height);
        }
        long b10 = n6.h.b(d11, i10, gVar.options.getSize(), gVar.options.getScale(), y6.i.g(gVar.options));
        int c10 = r.c(b10);
        int d12 = r.d(b10);
        if (width > 0.0f && height > 0.0f) {
            float e10 = n6.h.e(width, height, c10, d12, gVar.options.getScale());
            c10 = (int) (e10 * width);
            d12 = (int) (e10 * height);
            if (d10 == null) {
                cVar.a(new c.ViewBox(0.0f, 0.0f, width, height));
            }
        }
        cVar.b("100%");
        cVar.c("100%");
        cVar.e(gVar.options);
        n f10 = cVar.f(c10, d12);
        if (gVar.renderToBitmap) {
            f10 = v.d(v.g(f10, 0, 0, 3, null), false, 1, null);
        }
        return new DecodeResult(f10, gVar.renderToBitmap);
    }

    @Override // n6.i
    @Nullable
    public Object a(@NotNull eu.b<? super DecodeResult> bVar) {
        return a2.b(kotlin.coroutines.e.f21546a, new Function0() { // from class: a7.f
            @Override // kotlin.jvm.functions.Function0
            public final Object invoke() {
                DecodeResult g10;
                g10 = g.g(g.this);
                return g10;
            }
        }, bVar);
    }

    @Metadata(d1 = {"\u0000B\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u0007\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0011\u0018\u00002\u00020\u0001B?\u0012\b\b\u0002\u0010\u0003\u001a\u00020\u0002\u0012\u0018\b\u0002\u0010\b\u001a\u0012\u0012\b\u0012\u00060\u0005j\u0002`\u0006\u0012\u0004\u0012\u00020\u00070\u0004\u0012\b\b\u0002\u0010\n\u001a\u00020\t\u0012\b\b\u0002\u0010\u000b\u001a\u00020\t¢\u0006\u0004\b\f\u0010\rB'\b\u0016\u0012\b\b\u0002\u0010\n\u001a\u00020\t\u0012\b\b\u0002\u0010\u000b\u001a\u00020\t\u0012\b\b\u0002\u0010\u000e\u001a\u00020\t¢\u0006\u0004\b\f\u0010\u000fJ)\u0010\u0017\u001a\u0004\u0018\u00010\u00162\u0006\u0010\u0011\u001a\u00020\u00102\u0006\u0010\u0013\u001a\u00020\u00122\u0006\u0010\u0015\u001a\u00020\u0014H\u0016¢\u0006\u0004\b\u0017\u0010\u0018J\u0017\u0010\u0019\u001a\u00020\t2\u0006\u0010\u0011\u001a\u00020\u0010H\u0002¢\u0006\u0004\b\u0019\u0010\u001aR\u0017\u0010\u0003\u001a\u00020\u00028\u0006¢\u0006\f\n\u0004\b\u0017\u0010\u001b\u001a\u0004\b\u001c\u0010\u001dR'\u0010\b\u001a\u0012\u0012\b\u0012\u00060\u0005j\u0002`\u0006\u0012\u0004\u0012\u00020\u00070\u00048\u0006¢\u0006\f\n\u0004\b\u0019\u0010\u001e\u001a\u0004\b\u001f\u0010 R\u0017\u0010\n\u001a\u00020\t8\u0006¢\u0006\f\n\u0004\b!\u0010\"\u001a\u0004\b#\u0010$R\u0017\u0010\u000b\u001a\u00020\t8\u0006¢\u0006\f\n\u0004\b%\u0010\"\u001a\u0004\b&\u0010$¨\u0006'"}, d2 = {"La7/g$b;", "Ln6/i$a;", "La7/c$a;", "parser", "Lkotlin/Function1;", "Landroid/content/Context;", "Lcoil3/PlatformContext;", BuildConfig.FLAVOR, "density", BuildConfig.FLAVOR, "useViewBoundsAsIntrinsicSize", "renderToBitmap", "<init>", "(La7/c$a;Lkotlin/jvm/functions/Function1;ZZ)V", "scaleToDensity", "(ZZZ)V", "Lp6/o;", "result", "Ly6/p;", "options", "Ll6/s;", "imageLoader", "Ln6/i;", xe.a.f36648e, "(Lp6/o;Ly6/p;Ll6/s;)Ln6/i;", k6.b.f21144e, "(Lp6/o;)Z", "La7/c$a;", "getParser", "()La7/c$a;", "Lkotlin/jvm/functions/Function1;", "getDensity", "()Lkotlin/jvm/functions/Function1;", "c", "Z", "getUseViewBoundsAsIntrinsicSize", "()Z", "d", "getRenderToBitmap", "coil-svg_release"}, k = 1, mv = {2, 2, 0}, xi = 48)
    public static final class b implements i.a {

        /* renamed from: a, reason: collision with root package name and from kotlin metadata */
        @NotNull
        public final c.a parser;

        /* renamed from: b, reason: from kotlin metadata */
        @NotNull
        public final Function1<Context, Float> density;

        /* renamed from: c, reason: collision with root package name and from kotlin metadata */
        public final boolean useViewBoundsAsIntrinsicSize;

        /* renamed from: d, reason: collision with root package name and from kotlin metadata */
        public final boolean renderToBitmap;

        /* JADX WARN: Multi-variable type inference failed */
        public b(@NotNull c.a aVar, @NotNull Function1<? super Context, Float> function1, boolean z10, boolean z11) {
            this.parser = aVar;
            this.density = function1;
            this.useViewBoundsAsIntrinsicSize = z10;
            this.renderToBitmap = z11;
        }

        @Override // n6.i.a
        @Nullable
        public n6.i a(@NotNull SourceFetchResult result, @NotNull Options options, @NotNull l6.s imageLoader) {
            if (b(result)) {
                return new g(result.getSource(), options, this.parser, this.density, this.useViewBoundsAsIntrinsicSize, this.renderToBitmap);
            }
            return null;
        }

        public final boolean b(SourceFetchResult result) {
            return Intrinsics.c(result.getMimeType(), "image/svg+xml") || a.a(n6.h.f25432a, result.getSource().l3());
        }

        public /* synthetic */ b(boolean z10, boolean z11, boolean z12, int i10, DefaultConstructorMarker defaultConstructorMarker) {
            this((i10 & 1) != 0 ? true : z10, (i10 & 2) != 0 ? true : z11, (i10 & 4) != 0 ? false : z12);
        }

        public b(boolean z10, boolean z11, boolean z12) {
            this(c.a.f279yo, z12 ? g.f288i : g.f287h, z10, z11);
        }
    }

    public /* synthetic */ g(s sVar, Options options, boolean z10, boolean z11, boolean z12, int i10, DefaultConstructorMarker defaultConstructorMarker) {
        this(sVar, options, (i10 & 4) != 0 ? true : z10, (i10 & 8) != 0 ? true : z11, (i10 & 16) != 0 ? false : z12);
    }

    public g(@NotNull s sVar, @NotNull Options options, boolean z10, boolean z11, boolean z12) {
        this(sVar, options, c.a.f279yo, z12 ? f288i : f287h, z10, z11);
    }


    // --- восстановлено из DEX (a7/g$a) ---
    public static class a {
        public a() { }
        public a(kotlin.jvm.internal.DefaultConstructorMarker p0) { }
    }
}
