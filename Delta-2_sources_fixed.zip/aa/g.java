package aa;

import android.database.Cursor;

/* loaded from: classes.dex */
public final class g {

    /* renamed from: a, reason: collision with root package name */
    public Cursor f387a;

    public g() {
        throw null;
    }

    public /* synthetic */ g(byte[] bArr) {
    }
}
