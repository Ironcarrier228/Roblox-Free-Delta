package aa;

import dalvik.system.DelegateLastClassLoader;

/* loaded from: classes.dex */
public final /* synthetic */ class a {
    public static /* synthetic */ DelegateLastClassLoader a(String str, ClassLoader classLoader) {
        return new DelegateLastClassLoader(str, classLoader);
    }
}
