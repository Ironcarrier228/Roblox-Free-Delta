package aa;

/* loaded from: classes.dex */
public final /* synthetic */ class b {
    public static /* synthetic */ void a() {
    }
}
