package a;

import com.github.luben.zstd.BuildConfig;
import kotlin.Metadata;
import org.jetbrains.annotations.NotNull;

@Metadata(d1 = {"\u0000\u0014\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\b\u0000\u0018\u00002\u00020\u0001B\u0007¢\u0006\u0004\b\u0002\u0010\u0003J\r\u0010\u0005\u001a\u00020\u0004¢\u0006\u0004\b\u0005\u0010\u0006¨\u0006\u0007"}, d2 = {"La/a;", BuildConfig.FLAVOR, "<init>", "()V", "Ljava/lang/StackTraceElement;", xe.a.f36648e, "()Ljava/lang/StackTraceElement;", "kotlinx-coroutines-core"}, k = 1, mv = {2, 1, 0}, xi = 48)
/* loaded from: classes.dex */
public final class a {
    @NotNull
    public final StackTraceElement a() {
        StackTraceElement b;
        b = b.b(new Exception(), c.class.getSimpleName());
        return b;
    }
}
