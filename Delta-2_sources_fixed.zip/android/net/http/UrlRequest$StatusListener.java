package android.net.http;

/* loaded from: classes.dex */
public interface StatusListener {
}

