package android.os;

/* loaded from: classes.dex */
public interface OutcomeReceiver {
}

