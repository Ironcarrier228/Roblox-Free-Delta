package android.view;

import android.view.a1;
import android.view.x0;
import com.github.luben.zstd.BuildConfig;
import k6.b;
import kotlin.Metadata;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.internal.Intrinsics;
import l4.CreationExtras;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import xe.a;
import xu.c;
import zt.h;

@Metadata(d1 = {"\u00004\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u000b\n\u0002\b\u000e\u0018\u0000*\b\b\u0000\u0010\u0002*\u00020\u00012\b\u0012\u0004\u0012\u00028\u00000\u0003BC\b\u0007\u0012\f\u0010\u0005\u001a\b\u0012\u0004\u0012\u00028\u00000\u0004\u0012\f\u0010\b\u001a\b\u0012\u0004\u0012\u00020\u00070\u0006\u0012\f\u0010\n\u001a\b\u0012\u0004\u0012\u00020\t0\u0006\u0012\u000e\b\u0002\u0010\f\u001a\b\u0012\u0004\u0012\u00020\u000b0\u0006¢\u0006\u0004\b\r\u0010\u000eJ\u000f\u0010\u0010\u001a\u00020\u000fH\u0016¢\u0006\u0004\b\u0010\u0010\u0011R\u001a\u0010\u0005\u001a\b\u0012\u0004\u0012\u00028\u00000\u00048\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b\u0012\u0010\u0013R\u001a\u0010\b\u001a\b\u0012\u0004\u0012\u00020\u00070\u00068\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b\u0014\u0010\u0015R\u001a\u0010\n\u001a\b\u0012\u0004\u0012\u00020\t0\u00068\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b\u0016\u0010\u0015R\u001a\u0010\f\u001a\b\u0012\u0004\u0012\u00020\u000b0\u00068\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b\u0017\u0010\u0015R\u0018\u0010\u001a\u001a\u0004\u0018\u00018\u00008\u0002@\u0002X\u0082\u000e¢\u0006\u0006\n\u0004\b\u0018\u0010\u0019R\u0014\u0010\u001c\u001a\u00028\u00008VX\u0096\u0004¢\u0006\u0006\u001a\u0004\b\u0012\u0010\u001b¨\u0006\u001d"}, d2 = {"Landroidx/lifecycle/z0;", "Landroidx/lifecycle/x0;", "VM", "Lzt/h;", "Lxu/c;", "viewModelClass", "Lkotlin/Function0;", "Landroidx/lifecycle/b1;", "storeProducer", "Landroidx/lifecycle/a1$c;", "factoryProducer", "Ll4/a;", "extrasProducer", "<init>", "(Lxu/c;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;)V", BuildConfig.FLAVOR, "isInitialized", "()Z", a.f36648e, "Lxu/c;", b.f21144e, "Lkotlin/jvm/functions/Function0;", "c", "d", "e", "Landroidx/lifecycle/x0;", "cached", "()Landroidx/lifecycle/x0;", "value", "lifecycle-viewmodel"}, k = 1, mv = {2, 0, 0}, xi = 48)
/* loaded from: classes.dex */
public final class z0<VM extends x0> implements h<VM> {

    /* renamed from: a, reason: collision with root package name and from kotlin metadata */
    @NotNull
    public final c<VM> viewModelClass;

    /* renamed from: b, reason: from kotlin metadata */
    @NotNull
    public final Function0<b1> storeProducer;

    /* renamed from: c, reason: collision with root package name and from kotlin metadata */
    @NotNull
    public final Function0<a1.c> factoryProducer;

    /* renamed from: d, reason: collision with root package name and from kotlin metadata */
    @NotNull
    public final Function0<CreationExtras> extrasProducer;

    /* renamed from: e, reason: collision with root package name and from kotlin metadata */
    @Nullable
    public VM cached;

    /* JADX WARN: Multi-variable type inference failed */
    public z0(@NotNull c<VM> viewModelClass, @NotNull Function0<? extends b1> storeProducer, @NotNull Function0<? extends a1.c> factoryProducer, @NotNull Function0<? extends CreationExtras> extrasProducer) {
        Intrinsics.checkNotNullParameter(viewModelClass, "viewModelClass");
        Intrinsics.checkNotNullParameter(storeProducer, "storeProducer");
        Intrinsics.checkNotNullParameter(factoryProducer, "factoryProducer");
        Intrinsics.checkNotNullParameter(extrasProducer, "extrasProducer");
        this.viewModelClass = viewModelClass;
        this.storeProducer = storeProducer;
        this.factoryProducer = factoryProducer;
        this.extrasProducer = extrasProducer;
    }

    @Override // zt.h
    @NotNull
    /* renamed from: a, reason: merged with bridge method [inline-methods] */
    public VM getValue() {
        VM vm2 = this.cached;
        if (vm2 != null) {
            return vm2;
        }
        VM vm3 = (VM) a1.INSTANCE.a(this.storeProducer.invoke(), this.factoryProducer.invoke(), this.extrasProducer.invoke()).c(this.viewModelClass);
        this.cached = vm3;
        return vm3;
    }

    @Override // zt.h
    public boolean isInitialized() {
        return this.cached != null;
    }
}
