package android.view;

import android.view.l;
import av.d2;
import av.g1;
import av.i;
import av.k;
import av.n;
import av.n2;
import av.p0;
import av.q0;
import com.github.luben.zstd.BuildConfig;
import fu.c;
import gu.f;
import gu.m;
import k6.b;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.c0;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import zt.n;
import zt.o;

@Metadata(d1 = {"\u0000*\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0003\u001a@\u0010\t\u001a\u00020\u0006*\u00020\u00002\u0006\u0010\u0002\u001a\u00020\u00012\"\u0010\b\u001a\u001e\b\u0001\u0012\u0004\u0012\u00020\u0004\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00060\u0005\u0012\u0006\u0012\u0004\u0018\u00010\u00070\u0003H\u0086@¢\u0006\u0004\b\t\u0010\n\u001a@\u0010\f\u001a\u00020\u0006*\u00020\u000b2\u0006\u0010\u0002\u001a\u00020\u00012\"\u0010\b\u001a\u001e\b\u0001\u0012\u0004\u0012\u00020\u0004\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00060\u0005\u0012\u0006\u0012\u0004\u0018\u00010\u00070\u0003H\u0086@¢\u0006\u0004\b\f\u0010\r¨\u0006\u000e"}, d2 = {"Landroidx/lifecycle/l;", "Landroidx/lifecycle/l$b;", "state", "Lkotlin/Function2;", "Lav/p0;", "Leu/b;", BuildConfig.FLAVOR, BuildConfig.FLAVOR, "block", xe.a.f36648e, "(Landroidx/lifecycle/l;Landroidx/lifecycle/l$b;Lkotlin/jvm/functions/Function2;Leu/b;)Ljava/lang/Object;", "Landroidx/lifecycle/s;", b.f21144e, "(Landroidx/lifecycle/s;Landroidx/lifecycle/l$b;Lkotlin/jvm/functions/Function2;Leu/b;)Ljava/lang/Object;", "lifecycle-runtime"}, k = 2, mv = {2, 0, 0}, xi = 48)
/* loaded from: classes.dex */
public final class j0 {

    @Metadata(d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0002\b\u0002\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\n¢\u0006\u0004\b\u0002\u0010\u0003"}, d2 = {"Lav/p0;", BuildConfig.FLAVOR, "<anonymous>", "(Lav/p0;)V"}, k = 3, mv = {2, 0, 0})
    @f(c = "androidx.lifecycle.RepeatOnLifecycleKt$repeatOnLifecycle$3", f = "RepeatOnLifecycle.kt", l = {83}, m = "invokeSuspend", v = 1)
    public static final class a extends m implements Function2<p0, eu.b<? super Unit>, Object> {

        /* renamed from: t, reason: collision with root package name */
        public int f2331t;

        /* renamed from: u, reason: collision with root package name */
        public /* synthetic */ Object f2332u;

        /* renamed from: v, reason: collision with root package name */
        public final /* synthetic */ l f2333v;

        /* renamed from: w, reason: collision with root package name */
        public final /* synthetic */ l.b f2334w;

        /* renamed from: x, reason: collision with root package name */
        public final /* synthetic */ Function2<p0, eu.b<? super Unit>, Object> f2335x;

        @Metadata(d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0002\b\u0002\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\n¢\u0006\u0004\b\u0002\u0010\u0003"}, d2 = {"Lav/p0;", BuildConfig.FLAVOR, "<anonymous>", "(Lav/p0;)V"}, k = 3, mv = {2, 0, 0})
        @f(c = "androidx.lifecycle.RepeatOnLifecycleKt$repeatOnLifecycle$3$1", f = "RepeatOnLifecycle.kt", l = {161}, m = "invokeSuspend", v = 1)
        /* renamed from: androidx.lifecycle.j0$a$a, reason: collision with other inner class name */
        public static final class C0047a extends m implements Function2<p0, eu.b<? super Unit>, Object> {
            public final /* synthetic */ l A;
            public final /* synthetic */ l.b B;
            public final /* synthetic */ p0 C;
            public final /* synthetic */ Function2<p0, eu.b<? super Unit>, Object> D;

            /* renamed from: t, reason: collision with root package name */
            public Object f2336t;

            /* renamed from: u, reason: collision with root package name */
            public Object f2337u;

            /* renamed from: v, reason: collision with root package name */
            public Object f2338v;

            /* renamed from: w, reason: collision with root package name */
            public Object f2339w;

            /* renamed from: x, reason: collision with root package name */
            public Object f2340x;

            /* renamed from: y, reason: collision with root package name */
            public Object f2341y;

            /* renamed from: z, reason: collision with root package name */
            public int f2342z;

            @Metadata(k = 3, mv = {2, 0, 0}, xi = 48)
            /* renamed from: androidx.lifecycle.j0$a$a$a, reason: collision with other inner class name */
            public static final class C0048a implements p {

                /* renamed from: a, reason: collision with root package name */
                public final /* synthetic */ l.a f2343a;
                public final /* synthetic */ c0<d2> b;

                /* renamed from: c, reason: collision with root package name */
                public final /* synthetic */ p0 f2344c;

                /* renamed from: d, reason: collision with root package name */
                public final /* synthetic */ l.a f2345d;

                /* renamed from: e, reason: collision with root package name */
                public final /* synthetic */ n<Unit> f2346e;

                /* renamed from: f, reason: collision with root package name */
                public final /* synthetic */ kv.a f2347f;

                /* renamed from: g, reason: collision with root package name */
                public final /* synthetic */ Function2<p0, eu.b<? super Unit>, Object> f2348g;

                @Metadata(d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0002\b\u0002\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\n¢\u0006\u0004\b\u0002\u0010\u0003"}, d2 = {"Lav/p0;", BuildConfig.FLAVOR, "<anonymous>", "(Lav/p0;)V"}, k = 3, mv = {2, 0, 0})
                @f(c = "androidx.lifecycle.RepeatOnLifecycleKt$repeatOnLifecycle$3$1$1$1$1", f = "RepeatOnLifecycle.kt", l = {166, 110}, m = "invokeSuspend", v = 1)
                /* renamed from: androidx.lifecycle.j0$a$a$a$a, reason: collision with other inner class name */
                public static final class C0049a extends m implements Function2<p0, eu.b<? super Unit>, Object> {

                    /* renamed from: t, reason: collision with root package name */
                    public Object f2349t;

                    /* renamed from: u, reason: collision with root package name */
                    public Object f2350u;

                    /* renamed from: v, reason: collision with root package name */
                    public int f2351v;

                    /* renamed from: w, reason: collision with root package name */
                    public final /* synthetic */ kv.a f2352w;

                    /* renamed from: x, reason: collision with root package name */
                    public final /* synthetic */ Function2<p0, eu.b<? super Unit>, Object> f2353x;

                    @Metadata(d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0002\b\u0002\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\n¢\u0006\u0004\b\u0002\u0010\u0003"}, d2 = {"Lav/p0;", BuildConfig.FLAVOR, "<anonymous>", "(Lav/p0;)V"}, k = 3, mv = {2, 0, 0})
                    @f(c = "androidx.lifecycle.RepeatOnLifecycleKt$repeatOnLifecycle$3$1$1$1$1$1$1", f = "RepeatOnLifecycle.kt", l = {110}, m = "invokeSuspend", v = 1)
                    /* renamed from: androidx.lifecycle.j0$a$a$a$a$a, reason: collision with other inner class name */
                    public static final class C0050a extends m implements Function2<p0, eu.b<? super Unit>, Object> {

                        /* renamed from: t, reason: collision with root package name */
                        public int f2354t;

                        /* renamed from: u, reason: collision with root package name */
                        public /* synthetic */ Object f2355u;

                        /* renamed from: v, reason: collision with root package name */
                        public final /* synthetic */ Function2<p0, eu.b<? super Unit>, Object> f2356v;

                        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                        /* JADX WARN: Multi-variable type inference failed */
                        public C0050a(Function2<? super p0, ? super eu.b<? super Unit>, ? extends Object> function2, eu.b<? super C0050a> bVar) {
                            super(2, bVar);
                            this.f2356v = function2;
                        }

                        @Override // gu.a
                        public final eu.b<Unit> create(Object obj, eu.b<?> bVar) {
                            C0050a c0050a = new C0050a(this.f2356v, bVar);
                            c0050a.f2355u = obj;
                            return c0050a;
                        }

                        @Override // kotlin.jvm.functions.Function2
                        public final Object invoke(p0 p0Var, eu.b<? super Unit> bVar) {
                            return ((C0050a) create(p0Var, bVar)).invokeSuspend(Unit.f21504a);
                        }

                        @Override // gu.a
                        public final Object invokeSuspend(Object obj) {
                            Object e10 = c.e();
                            int i10 = this.f2354t;
                            if (i10 == 0) {
                                o.b(obj);
                                p0 p0Var = (p0) this.f2355u;
                                Function2<p0, eu.b<? super Unit>, Object> function2 = this.f2356v;
                                this.f2354t = 1;
                                if (function2.invoke(p0Var, this) == e10) {
                                    return e10;
                                }
                            } else {
                                if (i10 != 1) {
                                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                                }
                                o.b(obj);
                            }
                            return Unit.f21504a;
                        }
                    }

                    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                    /* JADX WARN: Multi-variable type inference failed */
                    public C0049a(kv.a aVar, Function2<? super p0, ? super eu.b<? super Unit>, ? extends Object> function2, eu.b<? super C0049a> bVar) {
                        super(2, bVar);
                        this.f2352w = aVar;
                        this.f2353x = function2;
                    }

                    @Override // gu.a
                    public final eu.b<Unit> create(Object obj, eu.b<?> bVar) {
                        return new C0049a(this.f2352w, this.f2353x, bVar);
                    }

                    @Override // kotlin.jvm.functions.Function2
                    public final Object invoke(p0 p0Var, eu.b<? super Unit> bVar) {
                        return ((C0049a) create(p0Var, bVar)).invokeSuspend(Unit.f21504a);
                    }

                    /* JADX WARN: Code restructure failed: missing block: B:28:0x003f, code lost:
                    
                        if (r7.d(null, r6) == r0) goto L19;
                     */
                    @Override // gu.a
                    /*
                        Code decompiled incorrectly, please refer to instructions dump.
                        To view partially-correct add '--show-bad-code' argument
                    */
                    public final java.lang.Object invokeSuspend(java.lang.Object r7) {
                        /*
                            r6 = this;
                            java.lang.Object r0 = fu.c.e()
                            int r1 = r6.f2351v
                            r2 = 2
                            r3 = 1
                            r4 = 0
                            if (r1 == 0) goto L2e
                            if (r1 == r3) goto L21
                            if (r1 != r2) goto L19
                            java.lang.Object r0 = r6.f2349t
                            kv.a r0 = (kv.a) r0
                            zt.o.b(r7)     // Catch: java.lang.Throwable -> L17
                            goto L55
                        L17:
                            r7 = move-exception
                            goto L61
                        L19:
                            java.lang.IllegalStateException r7 = new java.lang.IllegalStateException
                            java.lang.String r0 = "call to 'resume' before 'invoke' with coroutine"
                            r7.<init>(r0)
                            throw r7
                        L21:
                            java.lang.Object r1 = r6.f2350u
                            kotlin.jvm.functions.Function2 r1 = (kotlin.jvm.functions.Function2) r1
                            java.lang.Object r3 = r6.f2349t
                            kv.a r3 = (kv.a) r3
                            zt.o.b(r7)
                            r7 = r3
                            goto L42
                        L2e:
                            zt.o.b(r7)
                            kv.a r7 = r6.f2352w
                            kotlin.jvm.functions.Function2<av.p0, eu.b<? super kotlin.Unit>, java.lang.Object> r1 = r6.f2353x
                            r6.f2349t = r7
                            r6.f2350u = r1
                            r6.f2351v = r3
                            java.lang.Object r3 = r7.d(r4, r6)
                            if (r3 != r0) goto L42
                            goto L53
                        L42:
                            androidx.lifecycle.j0$a$a$a$a$a r3 = new androidx.lifecycle.j0$a$a$a$a$a     // Catch: java.lang.Throwable -> L5d
                            r3.<init>(r1, r4)     // Catch: java.lang.Throwable -> L5d
                            r6.f2349t = r7     // Catch: java.lang.Throwable -> L5d
                            r6.f2350u = r4     // Catch: java.lang.Throwable -> L5d
                            r6.f2351v = r2     // Catch: java.lang.Throwable -> L5d
                            java.lang.Object r1 = av.q0.g(r3, r6)     // Catch: java.lang.Throwable -> L5d
                            if (r1 != r0) goto L54
                        L53:
                            return r0
                        L54:
                            r0 = r7
                        L55:
                            kotlin.Unit r7 = kotlin.Unit.f21504a     // Catch: java.lang.Throwable -> L17
                            r0.f(r4)
                            kotlin.Unit r7 = kotlin.Unit.f21504a
                            return r7
                        L5d:
                            r0 = move-exception
                            r5 = r0
                            r0 = r7
                            r7 = r5
                        L61:
                            r0.f(r4)
                            throw r7
                        */
                        throw new UnsupportedOperationException("Method not decompiled: androidx.lifecycle.j0.a.C0047a.C0048a.C0049a.invokeSuspend(java.lang.Object):java.lang.Object");
                    }
                }

                /* JADX WARN: Multi-variable type inference failed */
                public C0048a(l.a aVar, c0<d2> c0Var, p0 p0Var, l.a aVar2, n<? super Unit> nVar, kv.a aVar3, Function2<? super p0, ? super eu.b<? super Unit>, ? extends Object> function2) {
                    this.f2343a = aVar;
                    this.b = c0Var;
                    this.f2344c = p0Var;
                    this.f2345d = aVar2;
                    this.f2346e = nVar;
                    this.f2347f = aVar3;
                    this.f2348g = function2;
                }

                /* JADX WARN: Type inference failed for: r9v5, types: [T, av.d2] */
                @Override // android.view.p
                public final void g(s sVar, l.a event) {
                    Object d10 = null;
                    Intrinsics.checkNotNullParameter(sVar, "<unused var>");
                    Intrinsics.checkNotNullParameter(event, "event");
                    if (event == this.f2343a) {
                        c0<d2> c0Var = this.b;
                        d10 = k.d(this.f2344c, null, null, new C0049a(this.f2347f, this.f2348g, null), 3, null);
                        c0Var.f21573a = d10;
                        return;
                    }
                    if (event == this.f2345d) {
                        d2 d2Var = this.b.f21573a;
                        if (d2Var != null) {
                            d2.a.a(d2Var, null, 1, null);
                        }
                        this.b.f21573a = null;
                    }
                    if (event == l.a.ON_DESTROY) {
                        n<Unit> nVar = this.f2346e;
                        n.Companion companion = zt.n.INSTANCE;
                        nVar.resumeWith(zt.n.b(Unit.f21504a));
                    }
                }
            }

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            /* JADX WARN: Multi-variable type inference failed */
            public C0047a(l lVar, l.b bVar, p0 p0Var, Function2<? super p0, ? super eu.b<? super Unit>, ? extends Object> function2, eu.b<? super C0047a> bVar2) {
                super(2, bVar2);
                this.A = lVar;
                this.B = bVar;
                this.C = p0Var;
                this.D = function2;
            }

            @Override // gu.a
            public final eu.b<Unit> create(Object obj, eu.b<?> bVar) {
                return new C0047a(this.A, this.B, this.C, this.D, bVar);
            }

            @Override // kotlin.jvm.functions.Function2
            public final Object invoke(p0 p0Var, eu.b<? super Unit> bVar) {
                return ((C0047a) create(p0Var, bVar)).invokeSuspend(Unit.f21504a);
            }

            /* JADX WARN: Removed duplicated region for block: B:21:0x00c6  */
            /* JADX WARN: Removed duplicated region for block: B:24:0x00cf  */
            /* JADX WARN: Removed duplicated region for block: B:26:? A[SYNTHETIC] */
            /* JADX WARN: Type inference failed for: r4v3, types: [T, androidx.lifecycle.j0$a$a$a, java.lang.Object] */
            @Override // gu.a
            /*
                Code decompiled incorrectly, please refer to instructions dump.
                To view partially-correct add '--show-bad-code' argument
            */
            public final java.lang.Object invokeSuspend(java.lang.Object r14) {
                /*
                    r13 = this;
                    java.lang.Object r0 = fu.c.e()
                    int r1 = r13.f2342z
                    r2 = 0
                    r3 = 1
                    if (r1 == 0) goto L37
                    if (r1 != r3) goto L2f
                    java.lang.Object r0 = r13.f2341y
                    kotlin.jvm.functions.Function2 r0 = (kotlin.jvm.functions.Function2) r0
                    java.lang.Object r0 = r13.f2340x
                    av.p0 r0 = (av.p0) r0
                    java.lang.Object r0 = r13.f2339w
                    androidx.lifecycle.l r0 = (android.view.l) r0
                    java.lang.Object r0 = r13.f2338v
                    androidx.lifecycle.l$b r0 = (androidx.lifecycle.l.b) r0
                    java.lang.Object r0 = r13.f2337u
                    r1 = r0
                    kotlin.jvm.internal.c0 r1 = (kotlin.jvm.internal.c0) r1
                    java.lang.Object r0 = r13.f2336t
                    r4 = r0
                    kotlin.jvm.internal.c0 r4 = (kotlin.jvm.internal.c0) r4
                    zt.o.b(r14)     // Catch: java.lang.Throwable -> L2b
                    goto La9
                L2b:
                    r0 = move-exception
                    r14 = r0
                    goto Lc0
                L2f:
                    java.lang.IllegalStateException r14 = new java.lang.IllegalStateException
                    java.lang.String r0 = "call to 'resume' before 'invoke' with coroutine"
                    r14.<init>(r0)
                    throw r14
                L37:
                    zt.o.b(r14)
                    androidx.lifecycle.l r14 = r13.A
                    androidx.lifecycle.l$b r14 = r14.getState()
                    androidx.lifecycle.l$b r1 = androidx.lifecycle.l.b.f2363a
                    if (r14 != r1) goto L47
                    kotlin.Unit r14 = kotlin.Unit.f21504a
                    return r14
                L47:
                    kotlin.jvm.internal.c0 r6 = new kotlin.jvm.internal.c0
                    r6.<init>()
                    kotlin.jvm.internal.c0 r1 = new kotlin.jvm.internal.c0
                    r1.<init>()
                    androidx.lifecycle.l$b r14 = r13.B     // Catch: java.lang.Throwable -> La1
                    androidx.lifecycle.l r12 = r13.A     // Catch: java.lang.Throwable -> La1
                    av.p0 r7 = r13.C     // Catch: java.lang.Throwable -> La1
                    kotlin.jvm.functions.Function2<av.p0, eu.b<? super kotlin.Unit>, java.lang.Object> r11 = r13.D     // Catch: java.lang.Throwable -> La1
                    r13.f2336t = r6     // Catch: java.lang.Throwable -> La1
                    r13.f2337u = r1     // Catch: java.lang.Throwable -> La1
                    r13.f2338v = r14     // Catch: java.lang.Throwable -> La1
                    r13.f2339w = r12     // Catch: java.lang.Throwable -> La1
                    r13.f2340x = r7     // Catch: java.lang.Throwable -> La1
                    r13.f2341y = r11     // Catch: java.lang.Throwable -> La1
                    r13.f2342z = r3     // Catch: java.lang.Throwable -> La1
                    av.p r9 = new av.p     // Catch: java.lang.Throwable -> La1
                    eu.b r4 = fu.b.c(r13)     // Catch: java.lang.Throwable -> La1
                    r9.<init>(r4, r3)     // Catch: java.lang.Throwable -> La1
                    r9.G()     // Catch: java.lang.Throwable -> La1
                    androidx.lifecycle.l$a$a r4 = androidx.lifecycle.l.a.INSTANCE     // Catch: java.lang.Throwable -> La1
                    androidx.lifecycle.l$a r5 = r4.c(r14)     // Catch: java.lang.Throwable -> La1
                    androidx.lifecycle.l$a r8 = r4.a(r14)     // Catch: java.lang.Throwable -> La1
                    r14 = 0
                    kv.a r10 = kv.g.b(r14, r3, r2)     // Catch: java.lang.Throwable -> La1
                    androidx.lifecycle.j0$a$a$a r4 = new androidx.lifecycle.j0$a$a$a     // Catch: java.lang.Throwable -> La1
                    r4.<init>(r5, r6, r7, r8, r9, r10, r11)     // Catch: java.lang.Throwable -> La1
                    r1.f21573a = r4     // Catch: java.lang.Throwable -> La1
                    java.lang.String r14 = "null cannot be cast to non-null type androidx.lifecycle.LifecycleEventObserver"
                    kotlin.jvm.internal.Intrinsics.d(r4, r14)     // Catch: java.lang.Throwable -> La1
                    androidx.lifecycle.p r4 = (android.view.p) r4     // Catch: java.lang.Throwable -> La1
                    r12.a(r4)     // Catch: java.lang.Throwable -> La1
                    java.lang.Object r14 = r9.y()     // Catch: java.lang.Throwable -> La1
                    java.lang.Object r4 = fu.c.e()     // Catch: java.lang.Throwable -> La1
                    if (r14 != r4) goto La5
                    gu.h.c(r13)     // Catch: java.lang.Throwable -> La1
                    goto La5
                La1:
                    r0 = move-exception
                    r14 = r0
                    r4 = r6
                    goto Lc0
                La5:
                    if (r14 != r0) goto La8
                    return r0
                La8:
                    r4 = r6
                La9:
                    T r14 = r4.f21573a
                    av.d2 r14 = (av.d2) r14
                    if (r14 == 0) goto Lb2
                    av.d2.a.a(r14, r2, r3, r2)
                Lb2:
                    T r14 = r1.f21573a
                    androidx.lifecycle.p r14 = (android.view.p) r14
                    if (r14 == 0) goto Lbd
                    androidx.lifecycle.l r0 = r13.A
                    r0.d(r14)
                Lbd:
                    kotlin.Unit r14 = kotlin.Unit.f21504a
                    return r14
                Lc0:
                    T r0 = r4.f21573a
                    av.d2 r0 = (av.d2) r0
                    if (r0 == 0) goto Lc9
                    av.d2.a.a(r0, r2, r3, r2)
                Lc9:
                    T r0 = r1.f21573a
                    androidx.lifecycle.p r0 = (android.view.p) r0
                    if (r0 == 0) goto Ld4
                    androidx.lifecycle.l r1 = r13.A
                    r1.d(r0)
                Ld4:
                    throw r14
                */
                throw new UnsupportedOperationException("Method not decompiled: androidx.lifecycle.j0.a.C0047a.invokeSuspend(java.lang.Object):java.lang.Object");
            }
        }

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        /* JADX WARN: Multi-variable type inference failed */
        public a(l lVar, l.b bVar, Function2<? super p0, ? super eu.b<? super Unit>, ? extends Object> function2, eu.b<? super a> bVar2) {
            super(2, bVar2);
            this.f2333v = lVar;
            this.f2334w = bVar;
            this.f2335x = function2;
        }

        @Override // gu.a
        public final eu.b<Unit> create(Object obj, eu.b<?> bVar) {
            a aVar = new a(this.f2333v, this.f2334w, this.f2335x, bVar);
            aVar.f2332u = obj;
            return aVar;
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(p0 p0Var, eu.b<? super Unit> bVar) {
            return ((a) create(p0Var, bVar)).invokeSuspend(Unit.f21504a);
        }

        @Override // gu.a
        public final Object invokeSuspend(Object obj) {
            Object e10 = c.e();
            int i10 = this.f2331t;
            if (i10 == 0) {
                o.b(obj);
                p0 p0Var = (p0) this.f2332u;
                n2 immediate = g1.c().getImmediate();
                C0047a c0047a = new C0047a(this.f2333v, this.f2334w, p0Var, this.f2335x, null);
                this.f2331t = 1;
                if (i.g(immediate, c0047a, this) == e10) {
                    return e10;
                }
            } else {
                if (i10 != 1) {
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                o.b(obj);
            }
            return Unit.f21504a;
        }
    }

    @Nullable
    public static final Object a(@NotNull l lVar, @NotNull l.b bVar, @NotNull Function2<? super p0, ? super eu.b<? super Unit>, ? extends Object> function2, @NotNull eu.b<? super Unit> bVar2) {
        Object g10;
        if (bVar != l.b.b) {
            return (lVar.getState() != l.b.f2363a && (g10 = q0.g(new a(lVar, bVar, function2, null), bVar2)) == c.e()) ? g10 : Unit.f21504a;
        }
        throw new IllegalArgumentException("repeatOnLifecycle cannot start work with the INITIALIZED lifecycle state.");
    }

    @Nullable
    public static final Object b(@NotNull s sVar, @NotNull l.b bVar, @NotNull Function2<? super p0, ? super eu.b<? super Unit>, ? extends Object> function2, @NotNull eu.b<? super Unit> bVar2) {
        Object a10 = a(sVar.a(), bVar, function2, bVar2);
        return a10 == c.e() ? a10 : Unit.f21504a;
    }
}
