package android.view;

import android.annotation.SuppressLint;
import com.github.luben.zstd.BuildConfig;
import kotlin.Metadata;
import r.c;
import xe.a;

@Metadata(d1 = {"\u0000\b\n\u0002\u0010\u000b\n\u0002\b\u0003\u001a\u000f\u0010\u0001\u001a\u00020\u0000H\u0001¢\u0006\u0004\b\u0001\u0010\u0002¨\u0006\u0003"}, d2 = {BuildConfig.FLAVOR, a.f36648e, "()Z", "lifecycle-runtime"}, k = 2, mv = {2, 0, 0}, xi = 48)
/* loaded from: classes.dex */
public final class x {
    @SuppressLint({"RestrictedApi"})
    public static final boolean a() {
        return c.g().b();
    }
}
