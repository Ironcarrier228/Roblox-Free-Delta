package android.window;

/* loaded from: classes.dex */
public interface OnBackInvokedCallback {
}

