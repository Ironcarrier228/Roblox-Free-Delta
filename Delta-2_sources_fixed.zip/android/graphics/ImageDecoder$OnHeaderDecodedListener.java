package android.graphics;

/* loaded from: classes.dex */
public interface OnHeaderDecodedListener {
}

