package af;

import java.security.GeneralSecurityException;
import we.b;

/* loaded from: classes2.dex */
public final class h implements ze.g {
    public static final b.EnumC0736b b = b.EnumC0736b.b;

    /* renamed from: a, reason: collision with root package name */
    public final ze.i f419a;

    public h(ze.i iVar) {
        if (!b.a()) {
            throw new GeneralSecurityException("Can not use HMAC in FIPS-mode, as BoringCrypto module is not available.");
        }
        this.f419a = iVar;
    }
}
